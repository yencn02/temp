City.new(:country_id => "27", :name => "Tchaourou", :aliases => "Chauru,Tchaourou,Tchaourou", :latitude => "8.88333", :longitude => "2.6").save
City.new(:country_id => "27", :name => "Tanguieta", :aliases => "Tangoueita,Tangueita,Tanguieta,TanguiÃ©ta,TanguiÃ©ta", :latitude => "10.61972", :longitude => "1.26444").save
City.new(:country_id => "27", :name => "Save", :aliases => "Save,SavÃ©,SavÃ©", :latitude => "8.03333", :longitude => "2.48333").save
City.new(:country_id => "27", :name => "Savalou", :aliases => "Savalou,Savalu,Savalou", :latitude => "7.93333", :longitude => "1.96667").save
City.new(:country_id => "27", :name => "Sakete", :aliases => ",SakÃ©tÃ©", :latitude => "6.71667", :longitude => "2.66667").save
City.new(:country_id => "27", :name => "Porto-Novo", :aliases => "Porto Nobo,Porto Novas,Porto Novo,Porto-Novo,PÃ´rto-Novo,bo duo nuo fu,poleutonobo,porutonobo,pwrtw nwbw,pwrtw nwww,xin gang,Î ÏÏÏÎ¿ ÎÏÎ²Î¿,ÐÐ¾ÑÑÐ¾ ÐÐ¾Ð²Ð¾,ÐÐ¾ÑÑÐ¾-ÐÐ¾Ð²Ð¾,×¤××¨×× × ×××,Ù¾ÙØ±ØªÙ ÙÙÙÙ,áá­á¶ áá®,ãã«ããã,æ°æ¸¯,æ³¢å¤è¯ºä¼,í¬ë¥´í ë¸ë³´,Porto-Novo", :latitude => "6.49646", :longitude => "2.60359").save
City.new(:country_id => "27", :name => "Pobe", :aliases => "Ipobe,Pobe,PobÃ©,PobÃ©", :latitude => "6.96667", :longitude => "2.68333").save
City.new(:country_id => "27", :name => "Parakou", :aliases => "Parakou,Paraku,ÐÐ°ÑÐ°ÐºÑ,Parakou", :latitude => "9.35", :longitude => "2.61667").save
City.new(:country_id => "27", :name => "Ouidah", :aliases => "Fortaleza de Sao Joao Baptista de Ajuda,Fortaleza de SÃ£o JoÃ£o Baptista de AjudÃ¡,Ouidah,Sao Joao Baptista de Ajuda,SÃ£o JoÃ£o Baptista de AjudÃ¡,Vidy,Whydah,Wida,sheng yue han bao,ÐÐ¸Ð´Ñ,å£çº¦ç¿°å ¡,Ouidah", :latitude => "6.36667", :longitude => "2.08333").save
City.new(:country_id => "27", :name => "Nikki", :aliases => "Nikki,ÐÐ¸ÐºÐºÐ¸,Nikki", :latitude => "9.93389", :longitude => "3.20444").save
City.new(:country_id => "27", :name => "Natitingou", :aliases => "Natitingou,Natitingu,ÐÐ°ÑÐ¸ÑÐ¸Ð½Ð³Ñ,Natitingou", :latitude => "10.30667", :longitude => "1.375").save
City.new(:country_id => "27", :name => "Malanville", :aliases => "Malanvilem,Malanville,Mallanville,ÐÐ°Ð»Ð°Ð½Ð²Ð¸Ð»ÐµÐ¼,Malanville", :latitude => "11.86411", :longitude => "3.38967").save
City.new(:country_id => "27", :name => "Lokossa", :aliases => "Locossa,Lokossa,Lokossa", :latitude => "6.63333", :longitude => "1.71667").save
City.new(:country_id => "27", :name => "Ketou", :aliases => "Ketou,Ketu,KÃ©tou,KÃ©tou", :latitude => "7.36667", :longitude => "2.6").save
City.new(:country_id => "27", :name => "Kandi", :aliases => "Kandi,ÐÐ°Ð½Ð´Ð¸,Kandi", :latitude => "11.13417", :longitude => "2.93861").save
City.new(:country_id => "27", :name => "Dogbo", :aliases => ",Dogbo", :latitude => "6.81667", :longitude => "1.78333").save
City.new(:country_id => "27", :name => "Djougou", :aliases => "Djougou,Jugu,Djougou", :latitude => "9.705", :longitude => "1.66694").save
City.new(:country_id => "27", :name => "Dassa-Zoume", :aliases => "Dassa Zume,Dassa-Zoume,Dassa-ZoumÃ©,Dassa-ZoumÃ©", :latitude => "7.75", :longitude => "2.18333").save
City.new(:country_id => "27", :name => "Cove", :aliases => "Kove,KovÃ©,CovÃ©", :latitude => "7.22097", :longitude => "2.34017").save
City.new(:country_id => "27", :name => "Cotonou", :aliases => "Appi,Catonou,Cotonou,Cotonu,CotonÃº,Kotonou,Kotonu,ke tuo nu,kotonu,qwtwnw,ÐÐ¾ÑÐ¾Ð½Ñ,×§×××× ×,ã³ããã¼,ç§æåª,Cotonou", :latitude => "6.35", :longitude => "2.43333").save
City.new(:country_id => "27", :name => "Come", :aliases => "Come,ComÃ©,Kome,KomÃ©,ComÃ©", :latitude => "6.4", :longitude => "1.88333").save
City.new(:country_id => "27", :name => "Bohicon", :aliases => "Bohicon,Bohicon", :latitude => "7.2", :longitude => "2.06667").save
City.new(:country_id => "27", :name => "Bembereke", :aliases => "Bembereke,BembÃ¨rÃ¨kÃ¨,Bimbereke,BimbÃ©rÃ©kÃ©,BembÃ¨rÃ¨kÃ¨", :latitude => "10.22889", :longitude => "2.66528").save
City.new(:country_id => "27", :name => "Bassila", :aliases => "Bassila,Bassila", :latitude => "9.01667", :longitude => "1.66667").save
City.new(:country_id => "27", :name => "Banikoara", :aliases => "Banikoara,Banikoara", :latitude => "11.3", :longitude => "2.43333").save
City.new(:country_id => "27", :name => "Aplahoue", :aliases => "Aplahoue,AplahouÃ©,Parahoue,ParahouÃ©,Parahue,AplahouÃ©", :latitude => "6.93333", :longitude => "1.68333").save
City.new(:country_id => "27", :name => "Allada", :aliases => "Allada,Allada", :latitude => "6.65", :longitude => "2.15").save
City.new(:country_id => "27", :name => "Abomey-Calavi", :aliases => "Abome Calavi,Abomej-Kalavi,Abomey-Calavi,Kalavi,ÐÐ±Ð¾Ð¼ÐµÐ¹-ÐÐ°Ð»Ð°Ð²Ð¸,Abomey-Calavi", :latitude => "6.45", :longitude => "2.35").save
City.new(:country_id => "27", :name => "Abomey", :aliases => "Abome,Abomei,Abomej,Abomey,Palacios Reais de Abomei,PalÃ¡cios Reais de Abomei,ÐÐ±Ð¾Ð¼ÐµÐ¹,Abomey", :latitude => "7.18333", :longitude => "1.98333").save
