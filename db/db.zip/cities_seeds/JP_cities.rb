City.new(:country_id => "116", :name => "Shingu", :aliases => "Schingu,Shingu,Shingui,ShingÅ«,Sing,Singu,SingÅ«,Ð¡Ð¸Ð½Ð³,ShingÅ«", :latitude => "33.73333", :longitude => "135.98333").save
City.new(:country_id => "116", :name => "Atsugi", :aliases => "Acugi,Atsugi,Atsuki,Atugi,asseugi si,hou mu shi,ÐÑÑÐ³Ð¸,åæ¨å¸,ìì°ê¸° ì,Atsugi", :latitude => "35.43889", :longitude => "139.35972").save
City.new(:country_id => "116", :name => "Akashi", :aliases => "Akashi,Akasi,ÐÐºÐ°ÑÐ¸,Akashi", :latitude => "34.63333", :longitude => "134.98333").save
City.new(:country_id => "116", :name => "Zushi", :aliases => "Zushi,Zushi", :latitude => "35.29167", :longitude => "139.58556").save
City.new(:country_id => "116", :name => "Zama", :aliases => "Zama,ÐÐ°Ð¼Ð°,Zama", :latitude => "35.48889", :longitude => "139.38861").save
City.new(:country_id => "116", :name => "Yuza", :aliases => "Yusa,Yusamachi,Yuza,Yuzamachi,Yuza", :latitude => "39", :longitude => "139.91667").save
City.new(:country_id => "116", :name => "Yukuhashi", :aliases => "Yukihashi,Yukuhashi,xing qiao shi,è¡æ©å¸,Yukuhashi", :latitude => "33.73333", :longitude => "130.98333").save
City.new(:country_id => "116", :name => "Yuki", :aliases => "Juki,Yuki,YÅ«ki,Ð®ÐºÐ¸,YÅ«ki", :latitude => "36.3", :longitude => "139.88333").save
City.new(:country_id => "116", :name => "Yugawara", :aliases => "Yugawara,Yugawara", :latitude => "35.15", :longitude => "139.06667").save
City.new(:country_id => "116", :name => "Yoshikawa", :aliases => "Esikava,Yoshikawa,ÐÑÐ¸ÐºÐ°Ð²Ð°,Yoshikawa", :latitude => "35.88528", :longitude => "139.83944").save
City.new(:country_id => "116", :name => "Yoshii", :aliases => ",Yoshii", :latitude => "36.25", :longitude => "138.98333").save
City.new(:country_id => "116", :name => "Yoshida", :aliases => ",Yoshida", :latitude => "37.68333", :longitude => "138.88333").save
City.new(:country_id => "116", :name => "Yorii", :aliases => "Yorii,Yorii", :latitude => "36.11667", :longitude => "139.2").save
City.new(:country_id => "116", :name => "Yono", :aliases => ",Yono", :latitude => "35.88333", :longitude => "139.63333").save
City.new(:country_id => "116", :name => "Yonago", :aliases => "Yonago,mi zi shi,ç±³å­å¸,Yonago", :latitude => "35.43333", :longitude => "133.33333").save
City.new(:country_id => "116", :name => "Yokosuka", :aliases => "Jokosuka,Yokosuka,ÐÐ¾ÐºÐ¾ÑÑÐºÐ°,Yokosuka", :latitude => "35.28361", :longitude => "139.66722").save
City.new(:country_id => "116", :name => "Yokohama-shi", :aliases => "Iokogama,Jokohama,Jokohamo,Jokokhama,Yokohama,Yokohama-shi,heng bin shi,yoa koa ha ma,yokohama si,ywkwhama,ywqwhmh,ÐÐ¾ÐºÐ¾ÑÐ°Ð¼Ð°,ÐÐ¾ÐºÐ¾Ð³Ð°Ð¼Ð°,ÐÐ¾ÐºÐ¾ÑÐ°Ð¼Ð°,×××§××××,ÙÙÙÙÙØ§ÙØ§,à¹à¸¢à¸°à¹à¸à¸°à¸®à¸°à¸¡à¸°,ááááá°ááá,ããã¯ã¾ã,æ¨ªæµå¸,æ¨ªæ»¨å¸,ìì½íë§ ì,Yokohama-shi", :latitude => "35.44778", :longitude => "139.6425").save
City.new(:country_id => "116", :name => "Yokkaichi", :aliases => "Jokkaichi,Yokkaichi,Yokkaiti,ÐÐ¾ÐºÐºÐ°Ð¸ÑÐ¸,Yokkaichi", :latitude => "34.96667", :longitude => "136.61667").save
City.new(:country_id => "116", :name => "Youkaichi", :aliases => "Yokaichicho,Yokkaichi,YÅkaichichÅ,Youkaichi", :latitude => "35.11626", :longitude => "136.19768").save
City.new(:country_id => "116", :name => "Yawata", :aliases => "Yahata,Yahatanosho,YahatanoshÅ,Yahatasho,YahatashÅ,Yawata", :latitude => "34.87009", :longitude => "135.7027").save
City.new(:country_id => "116", :name => "Yatsushiro", :aliases => "Jacusiro,Yatsushiro,Yatusiro,Ð¯ÑÑÑÐ¸ÑÐ¾,Yatsushiro", :latitude => "32.5", :longitude => "130.6").save
City.new(:country_id => "116", :name => "Yatsuo", :aliases => ",Yatsuo", :latitude => "36.56667", :longitude => "137.13333").save
City.new(:country_id => "116", :name => "Yasugi", :aliases => "Yasugi,Yasugi", :latitude => "35.43333", :longitude => "133.25").save
City.new(:country_id => "116", :name => "Yasu", :aliases => "Jasu,Ð¯ÑÑ,Yasu", :latitude => "35.06801", :longitude => "136.02327").save
City.new(:country_id => "116", :name => "Yashiro", :aliases => ",Yashiro", :latitude => "34.91667", :longitude => "134.96667").save
City.new(:country_id => "116", :name => "Yashio-shi", :aliases => "Yashio,ba chao,ba chao shi,å«æ½®,å«æ½®å¸,Yashio-shi", :latitude => "35.82255", :longitude => "139.83905").save
City.new(:country_id => "116", :name => "Yao", :aliases => "Jao,Yao,Yaocho,YaochÅ,ba wei shi,Ð¯Ð¾,å«å°¾å¸,Yao", :latitude => "34.61667", :longitude => "135.6").save
City.new(:country_id => "116", :name => "Yanai", :aliases => "Janai,Yanai,Ð¯Ð½Ð°Ð¸,Yanai", :latitude => "33.96667", :longitude => "132.11667").save
City.new(:country_id => "116", :name => "Yanagawa", :aliases => "Janagava,Yanagawa,Ð¯Ð½Ð°Ð³Ð°Ð²Ð°,Yanagawa", :latitude => "33.16667", :longitude => "130.4").save
City.new(:country_id => "116", :name => "Yamasaki", :aliases => ",Yamasaki", :latitude => "35", :longitude => "134.55").save
City.new(:country_id => "116", :name => "Yamaguchi-shi", :aliases => "Jamaguci,Jamaguti,JamaguÄi,Yamaguchi,Yamaguchi-shi,Yamaguti,yamaghwtshy,yamaguchi si,Ð¯Ð¼Ð°Ð³ÑÑÐ¸,ÙØ§ÙØ§ØºÙØªØ´Ù,ãã¾ãã¡ã,å±±å£å¸,ì¼ë§êµ¬ì¹ ì,Yamaguchi-shi", :latitude => "34.18583", :longitude => "131.47139").save
City.new(:country_id => "116", :name => "Yamaga", :aliases => "Jamaga,Yamaga,Ð¯Ð¼Ð°Ð³Ð°,Yamaga", :latitude => "33.01667", :longitude => "130.68333").save
City.new(:country_id => "116", :name => "Yaizu", :aliases => "Jaidzu,Yaidu,Yaizu,Yaizu Mati,shao jin shi,Ð¯Ð¸Ð´Ð·Ñ,ç¼æ´¥å¸,Yaizu", :latitude => "34.86667", :longitude => "138.33333").save
City.new(:country_id => "116", :name => "Yaita", :aliases => "Yaita,Yaita", :latitude => "36.8", :longitude => "139.93333").save
City.new(:country_id => "116", :name => "Warabi", :aliases => "Warabi,Warabimachi,Warabi", :latitude => "35.82639", :longitude => "139.70444").save
City.new(:country_id => "116", :name => "Waki", :aliases => "Waki,Wakimachi,Waki", :latitude => "34.06667", :longitude => "134.15").save
City.new(:country_id => "116", :name => "Utsunomiya-shi", :aliases => "Ucunomija,Utsunomiya,Utsunomiya-shi,usseunomiya si,Ð£ÑÑÐ½Ð¾Ð¼Ð¸Ñ,ãã¤ã®ã¿ãã,å®é½å®®å¸,ì°ì°ë¸ë¯¸ì¼ ì,Utsunomiya-shi", :latitude => "36.56583", :longitude => "139.88361").save
City.new(:country_id => "116", :name => "Uto", :aliases => "Udo,Uto,Uto", :latitude => "32.68333", :longitude => "130.66667").save
City.new(:country_id => "116", :name => "Usuki", :aliases => "Usuki,jiu chu shi,è¼æµå¸,Usuki", :latitude => "33.10806", :longitude => "131.78778").save
City.new(:country_id => "116", :name => "Ushibuka", :aliases => "Ushibuka,Usibuka,Ushibuka", :latitude => "32.19056", :longitude => "130.02278").save
City.new(:country_id => "116", :name => "Ureshino", :aliases => "Ureshino,Ureshino", :latitude => "33.1", :longitude => "129.98333").save
City.new(:country_id => "116", :name => "Urayasu", :aliases => "Urajasu,Urayasu,pu an shi,Ð£ÑÐ°ÑÑÑ,æµ¦å®å¸,Urayasu", :latitude => "35.67056", :longitude => "139.88861").save
City.new(:country_id => "116", :name => "Uozu", :aliases => "Oozu,Owatsu,Uozo,Uozu,Uozu", :latitude => "36.8", :longitude => "137.4").save
City.new(:country_id => "116", :name => "Umi", :aliases => "Umi,Umi", :latitude => "33.56667", :longitude => "130.5").save
City.new(:country_id => "116", :name => "Ujiie", :aliases => ",Ujiie", :latitude => "36.68333", :longitude => "139.96667").save
City.new(:country_id => "116", :name => "Uji", :aliases => "Udzi,Uji,Uji-cho,Uji-chÅ,yu zhi shi,Ð£Ð´Ð·Ð¸,å®æ²»å¸,Uji", :latitude => "34.88333", :longitude => "135.8").save
City.new(:country_id => "116", :name => "Uenohara", :aliases => "Uenohara,Uenohara", :latitude => "35.61667", :longitude => "139.11667").save
City.new(:country_id => "116", :name => "Ueno", :aliases => ",Ueno", :latitude => "34.75", :longitude => "136.13333").save
City.new(:country_id => "116", :name => "Ueki", :aliases => "Ueki,Ueki", :latitude => "32.9", :longitude => "130.68333").save
City.new(:country_id => "116", :name => "Ueda", :aliases => "Ueda,Ueda, Nagano,Uehda,shang tian shi,ueda si,Ð£ÑÐ´Ð°,ä¸ç°å¸,ì°ìë¤ ì,Ueda", :latitude => "36.4", :longitude => "138.26667").save
City.new(:country_id => "116", :name => "Ube", :aliases => "Ube,Ubi,Ð£Ð±Ðµ,Ube", :latitude => "33.94306", :longitude => "131.25111").save
City.new(:country_id => "116", :name => "Tsuyama", :aliases => "Cujama,Tsuyama,Tuyama,jin shan shi,Ð¦ÑÑÐ¼Ð°,æ´¥å±±å¸,Tsuyama", :latitude => "35.05", :longitude => "134").save
City.new(:country_id => "116", :name => "Tsushima", :aliases => "Cusima,Tsushima,Tsushima cho,Tsushima chÅ,Ð¦ÑÑÐ¸Ð¼Ð°,Tsushima", :latitude => "35.16667", :longitude => "136.71667").save
City.new(:country_id => "116", :name => "Tsuruoka", :aliases => "Curuoka,Tsuruoka,Turuoka,he gang shi,Ð¦ÑÑÑÐ¾ÐºÐ°,é¶´å²¡å¸,Tsuruoka", :latitude => "38.72167", :longitude => "139.82167").save
City.new(:country_id => "116", :name => "Tsurugi", :aliases => ",Tsurugi", :latitude => "36.45", :longitude => "136.63333").save
City.new(:country_id => "116", :name => "Tsuruga", :aliases => "Curuga,Tsuruga,Turuga,dun he shi,sseuluga si,Ð¦ÑÑÑÐ³Ð°,æ¦è³å¸,ì°ë£¨ê° ì,Tsuruga", :latitude => "35.64547", :longitude => "136.0558").save
City.new(:country_id => "116", :name => "Tsuma", :aliases => "Tsuma,Tuma,Tsuma", :latitude => "32.1", :longitude => "131.4").save
City.new(:country_id => "116", :name => "Tsukumi", :aliases => "Tsukumi,Tukumi,Tsukumi", :latitude => "33.07056", :longitude => "131.85722").save
City.new(:country_id => "116", :name => "Tsukawaki", :aliases => "Kusu,Tsukawaki,Tsukawaki", :latitude => "33.26667", :longitude => "131.15").save
City.new(:country_id => "116", :name => "Tsubata", :aliases => "Tsubata,Tsubata", :latitude => "36.66667", :longitude => "136.73333").save
City.new(:country_id => "116", :name => "Tsubame", :aliases => "Cubameh,Tsubamemachi,Ð¦ÑÐ±Ð°Ð¼Ñ,Tsubame", :latitude => "37.65", :longitude => "138.93333").save
City.new(:country_id => "116", :name => "Tsu-shi", :aliases => "Cu,Tsu,Tsu-shi,Tu,jin shi,sseu si,Ð¦Ñ,ã¤ã,æ´¥å¸,ì° ì,Tsu-shi", :latitude => "34.73028", :longitude => "136.50861").save
City.new(:country_id => "116", :name => "Toyota", :aliases => "Koromo,Toyoda,Toyota,è±ç°,Toyota", :latitude => "35.08333", :longitude => "137.15").save
City.new(:country_id => "116", :name => "Toyoshina", :aliases => ",Toyoshina", :latitude => "36.29991", :longitude => "137.90108").save
City.new(:country_id => "116", :name => "Toyooka", :aliases => "Toyooka,Toyooka", :latitude => "35.53333", :longitude => "134.83333").save
City.new(:country_id => "116", :name => "Toyonaka", :aliases => ",Toyonaka", :latitude => "34.78244", :longitude => "135.46932").save
City.new(:country_id => "116", :name => "Toyokawa", :aliases => "Toyokawa,li chuan shi,è±å·å¸,Toyokawa", :latitude => "34.81667", :longitude => "137.4").save
City.new(:country_id => "116", :name => "Toyohashi", :aliases => "Tojokhashi,Toyohashi,Toyohasi,Ð¢Ð¾Ð¹Ð¾ÑÐ°ÑÐ¸,Toyohashi", :latitude => "34.76667", :longitude => "137.38333").save
City.new(:country_id => "116", :name => "Toyohama", :aliases => ",Toyohama", :latitude => "34.7", :longitude => "136.93333").save
City.new(:country_id => "116", :name => "Toyama-shi", :aliases => "Tojama,Toyama-shi,Ð¢Ð¾ÑÐ¼Ð°,ã¨ãã¾ã,å¯å±±å¸,Toyama-shi", :latitude => "36.69528", :longitude => "137.21139").save
City.new(:country_id => "116", :name => "Tottori", :aliases => ",Tottori", :latitude => "35.5", :longitude => "134.23333").save
City.new(:country_id => "116", :name => "Tosu", :aliases => "Tosu,doseu si,niao qi shi,é³¥æ å¸,ëì¤ ì,Tosu", :latitude => "33.36667", :longitude => "130.51667").save
City.new(:country_id => "116", :name => "Tonosho", :aliases => "Tonosho,TonoshÅ,Tonosyo,TonosyÅ,TonoshÅ", :latitude => "34.48333", :longitude => "134.18333").save
City.new(:country_id => "116", :name => "Tondabayashi", :aliases => "Tondabayashi,fu tian lin shi,å¯ç°æå¸,Tondabayashi", :latitude => "34.5", :longitude => "135.6").save
City.new(:country_id => "116", :name => "Tomioka", :aliases => "Tomioka,Tomioka", :latitude => "36.25", :longitude => "138.9").save
City.new(:country_id => "116", :name => "Tomigusuku", :aliases => "Gusuku,Temigusuku,Timigusuku,Tomigusuki,Tomigusuku,Tomigusuku", :latitude => "26.185", :longitude => "127.675").save
City.new(:country_id => "116", :name => "Tokyo", :aliases => "Edo (historical),TYO,Tochiu,Tocio,Tokija,Tokijas,Tokio,TokiÃ³,Tokjo,Tokyo,Toquio,Toquio - dong jing,Toquio - æ±äº¬,TÃ²quio,TÃ³kÃ½Ã³,TÃ³quio,TÅkyÅ,dokyo,dong jing,dong jing dou,tokeiyw,tokkiyo,tokyo,twkyw,twqyw,Î¤ÏÎºÎ¹Î¿,Ð¢Ð¾ÐºÐ¸Ð¾,Ð¢Ð¾ÐºÑ,Ð¢Ð¾ÐºÑÐ¾,ÕÕ¸Õ¯Õ«Õ¸,×××§××,ØªÙÙÙÙ,ØªÙÚ©ÛÙ,Ø·ÙÙÙÙ,ÜÜÜÜÜ,ÜÜÜÜÜ,à¤à¥à¤à¥à¤¯à¥,à®à¯à®à¯à®à®¿à®¯à¯,à¹à¸à¹à¸à¸µà¸¢à¸§,á¢áááá,ä¸äº¬,æ±äº¬,æ±äº¬é½,ëì¿,Tokyo", :latitude => "35.61488", :longitude => "139.5813").save
City.new(:country_id => "116", :name => "Tokuyama", :aliases => "Kakuyama,Tokuyama,Tokuyama", :latitude => "34.05", :longitude => "131.81667").save
City.new(:country_id => "116", :name => "Tokushima-shi", :aliases => "Tokushima,Tokushima - de dao shi,Tokushima - å¾³å³¶å¸,Tokushima-shi,Tokusima,TokuÅ¡ima,dokusima si,Ð¢Ð¾ÐºÑÑÐ¸Ð¼Ð°,ã¨ããã¾ã,å¾³å³¶å¸,ëì¿ ìë§ ì,Tokushima-shi", :latitude => "34.06583", :longitude => "134.55944").save
City.new(:country_id => "116", :name => "Tokorozawa", :aliases => "Tokorosava,Tokorozawa,suo ze shi,Ð¢Ð¾ÐºÐ¾ÑÐ¾ÑÐ°Ð²Ð°,ææ²¢å¸,Tokorozawa", :latitude => "35.79916", :longitude => "139.46903").save
City.new(:country_id => "116", :name => "Tokoname", :aliases => "Tokoname,Tokoname-cho,Tokoname-chÅ,Tokonameh,chang hua shi,Ð¢Ð¾ÐºÐ¾Ð½Ð°Ð¼Ñ,å¸¸æ»å¸,Tokoname", :latitude => "34.88333", :longitude => "136.85").save
City.new(:country_id => "116", :name => "Toki", :aliases => "Toka,Toki,Tokitsu-cho,Tokitsu-chÅ,tu qi shi,Ð¢Ð¾ÐºÐ°,åå²å¸,Toki", :latitude => "35.35", :longitude => "137.18333").save
City.new(:country_id => "116", :name => "Tokamachi", :aliases => "Toka,Tokamachi,Tokamati,TÅka,TÅkamachi,Ð¢Ð¾ÐºÐ°Ð¼Ð°ÑÐ¸,TÅkamachi", :latitude => "37.13333", :longitude => "138.76667").save
City.new(:country_id => "116", :name => "Togitsu", :aliases => "Togitsu,Tokitsu,Togitsu", :latitude => "32.83333", :longitude => "129.85").save
City.new(:country_id => "116", :name => "Tochio", :aliases => "Tochio,Tochiomachi,Tochio", :latitude => "37.46667", :longitude => "139").save
City.new(:country_id => "116", :name => "Tochigi", :aliases => "Tochigi,Totigi,Ð¢Ð¾ÑÐ¸Ð³Ð¸,Tochigi", :latitude => "36.38333", :longitude => "139.73333").save
City.new(:country_id => "116", :name => "Toba", :aliases => "Toba,Ð¢Ð¾Ð±Ð°,Toba", :latitude => "34.48333", :longitude => "136.85").save
City.new(:country_id => "116", :name => "Tenri", :aliases => "Tehnri,Tenri,Ð¢ÑÐ½ÑÐ¸,Tenri", :latitude => "34.58333", :longitude => "135.83333").save
City.new(:country_id => "116", :name => "Tenno", :aliases => ",TennÅ", :latitude => "39.9", :longitude => "139.96667").save
City.new(:country_id => "116", :name => "Tawaramoto", :aliases => "Taharamoto,Tawaramoto,Tawaramoto", :latitude => "34.55", :longitude => "135.8").save
City.new(:country_id => "116", :name => "Tatsuno", :aliases => ",Tatsuno", :latitude => "35.98426", :longitude => "137.99721").save
City.new(:country_id => "116", :name => "Tatsuno", :aliases => "Tatsuno,Tatsuno", :latitude => "34.86667", :longitude => "134.55").save
City.new(:country_id => "116", :name => "Tateyama", :aliases => "Hojo,HÅjÅ,Tateyama,Tateyamahojo,Tateyamahozyo,TateyamahÅjÅ,TateyamahÅzyÅ,guan shan,é¤¨å±±,Tateyama", :latitude => "34.98333", :longitude => "139.86667").save
City.new(:country_id => "116", :name => "Tatebayashi", :aliases => "Tatebayashi,Tatebayashi", :latitude => "36.25", :longitude => "139.53333").save
City.new(:country_id => "116", :name => "Tarumizu", :aliases => "Tarumi,Tarumizu", :latitude => "31.48333", :longitude => "130.7").save
City.new(:country_id => "116", :name => "Tarui", :aliases => "Tarui,Ð¢Ð°ÑÑÐ¸,Tarui", :latitude => "35.36667", :longitude => "136.53333").save
City.new(:country_id => "116", :name => "Tanushimaru", :aliases => ",Tanushimaru", :latitude => "33.35", :longitude => "130.68333").save
City.new(:country_id => "116", :name => "Tanuma", :aliases => "Tanuma,Tanuma", :latitude => "36.36667", :longitude => "139.58333").save
City.new(:country_id => "116", :name => "Nishi-Tokyo-shi", :aliases => "Hoya,Hoya-shi,Nishitokyo-shi,Tanashi,Tanashi-machi,bao gu shi,tian wu shi,xi dong jing shi,ä¿è°·å¸,ç°ç¡å¸,è¥¿æ±äº¬å¸,Nishi-Tokyo-shi", :latitude => "35.72526", :longitude => "139.5383").save
City.new(:country_id => "116", :name => "Tanashi", :aliases => ",Tanashi", :latitude => "35.72389", :longitude => "139.52222").save
City.new(:country_id => "116", :name => "Tanabe", :aliases => ",Tanabe", :latitude => "34.81667", :longitude => "135.76667").save
City.new(:country_id => "116", :name => "Tanabe", :aliases => "Tanabe,Tanabeh,Ð¢Ð°Ð½Ð°Ð±Ñ,Tanabe", :latitude => "33.73333", :longitude => "135.36667").save
City.new(:country_id => "116", :name => "Tamano", :aliases => "Tamano,Ð¢Ð°Ð¼Ð°Ð½Ð¾,Tamano", :latitude => "34.48333", :longitude => "133.95").save
City.new(:country_id => "116", :name => "Tamana", :aliases => "Tamana,Tamano,Ð¢Ð°Ð¼Ð°Ð½Ð°,Tamana", :latitude => "32.91667", :longitude => "130.56667").save
City.new(:country_id => "116", :name => "Tamamura", :aliases => ",Tamamura", :latitude => "36.3", :longitude => "139.11667").save
City.new(:country_id => "116", :name => "Taketoyo", :aliases => "Taketoyo,Taketoyocho,TaketoyochÅ,Taketoyo", :latitude => "34.85", :longitude => "136.91667").save
City.new(:country_id => "116", :name => "Takeo", :aliases => "Takeo,Ð¢Ð°ÐºÐµÐ¾,Takeo", :latitude => "33.2", :longitude => "130.01667").save
City.new(:country_id => "116", :name => "Takehara", :aliases => "Takehara,Takekara,Takehara", :latitude => "34.33833", :longitude => "132.91667").save
City.new(:country_id => "116", :name => "Takefu", :aliases => "Takebo,Takebu,Takefu,Takehu,wu sheng shi,æ­¦çå¸,Takefu", :latitude => "35.90393", :longitude => "136.16687").save
City.new(:country_id => "116", :name => "Takedamachi", :aliases => "Takeda,Takedamachi,Taketa,Taketa-machi,Takedamachi", :latitude => "32.96667", :longitude => "131.4").save
City.new(:country_id => "116", :name => "Takayama", :aliases => "Takajama,Takayama,fei tuono gao shan,gao shan,takayama,Ð¢Ð°ÐºÐ°ÑÐ¼Ð°,ãããã¾,é£é¨¨ã®é«å±±,é«å±±,Takayama", :latitude => "36.13333", :longitude => "137.25").save
City.new(:country_id => "116", :name => "Takatsuki", :aliases => "Takacuki,Takatsuki,Takatuki,gao gui shi,é«æ§»å¸,Takatsuki", :latitude => "34.84833", :longitude => "135.61678").save
City.new(:country_id => "116", :name => "Takasaki", :aliases => "Takasaki,gao qi shi,é«å´å¸,Takasaki", :latitude => "36.33333", :longitude => "139.01667").save
City.new(:country_id => "116", :name => "Takarazuka", :aliases => ",Takarazuka", :latitude => "34.79936", :longitude => "135.35697").save
City.new(:country_id => "116", :name => "Takaoka", :aliases => "Takaoka,Takaoka", :latitude => "36.75", :longitude => "137.01667").save
City.new(:country_id => "116", :name => "Takanabe", :aliases => "Takanabe,Takanabecho,TakanabechÅ,Takanabe", :latitude => "32.13333", :longitude => "131.5").save
City.new(:country_id => "116", :name => "Takamatsu-shi", :aliases => "Takamacu,Takamatsu,Takamatsu-shi,Takamatu,dakamasseu si,Ð¢Ð°ÐºÐ°Ð¼Ð°ÑÑ,ããã¾ã¤ã,é«æ¾å¸,ë¤ì¹´ë§ì° ì,Takamatsu-shi", :latitude => "34.34028", :longitude => "134.04333").save
City.new(:country_id => "116", :name => "Takaishi", :aliases => "Takaishi,Takaishi-kita,Takashi-kita,Takaishi", :latitude => "34.51667", :longitude => "135.43333").save
City.new(:country_id => "116", :name => "Takahashi", :aliases => "Takahashi,Takahasi,Takakhasi,Ð¢Ð°ÐºÐ°ÑÐ°ÑÐ¸,Takahashi", :latitude => "34.78333", :longitude => "133.61667").save
City.new(:country_id => "116", :name => "Takahama", :aliases => "Takahama-cho,Takahama-chÅ,Takakhama,Ð¢Ð°ÐºÐ°ÑÐ°Ð¼Ð°,Takahama", :latitude => "34.91667", :longitude => "136.98333").save
City.new(:country_id => "116", :name => "Bungo-Takada-shi", :aliases => "Bungo-Takada,Bungo-Takata,Takata,gao tian,li hou gao tian,li hou gao tian shi,è±å¾é«ç°,è±å¾é«ç°å¸,é«ç°,Bungo-Takada-shi", :latitude => "33.5567", :longitude => "131.44506").save
City.new(:country_id => "116", :name => "Tajimi", :aliases => "Tadimi,Tajima,Tajimi,Tajumi,Tazimi,Tajimi", :latitude => "35.31667", :longitude => "137.13333").save
City.new(:country_id => "116", :name => "Tahara", :aliases => "Tahara,Tawara,Tahara", :latitude => "34.66667", :longitude => "137.26667").save
City.new(:country_id => "116", :name => "Tagawa", :aliases => "Tagava,Tagawa,Takawa,Ð¢Ð°Ð³Ð°Ð²Ð°,Tagawa", :latitude => "33.63333", :longitude => "130.8").save
City.new(:country_id => "116", :name => "Tadotsu", :aliases => "Tadotsu,Tadotsucho,TadotsuchÅ,Tadotsu", :latitude => "34.275", :longitude => "133.75").save
City.new(:country_id => "116", :name => "Tachikawa", :aliases => "Tachikawa,Tatikawa,Tachikawa", :latitude => "35.69278", :longitude => "139.41806").save
City.new(:country_id => "116", :name => "Suzuka", :aliases => "Kambe,Suzuka,ling lu shi,é´é¹¿å¸,Suzuka", :latitude => "34.88333", :longitude => "136.58333").save
City.new(:country_id => "116", :name => "Suzaka", :aliases => "Susaka,Suzaka,Suzaka", :latitude => "36.65", :longitude => "138.31667").save
City.new(:country_id => "116", :name => "Suwa", :aliases => "Kamisuwa,Suva,Ð¡ÑÐ²Ð°,Suwa", :latitude => "36.03799", :longitude => "138.11308").save
City.new(:country_id => "116", :name => "Susaki", :aliases => "Susaki,Susaki", :latitude => "33.36667", :longitude => "133.28333").save
City.new(:country_id => "116", :name => "Sumoto", :aliases => "Sumoto,Ð¡ÑÐ¼Ð¾ÑÐ¾,Sumoto", :latitude => "34.35", :longitude => "134.9").save
City.new(:country_id => "116", :name => "Sukumo", :aliases => "Sukumo,Sukumo", :latitude => "32.93333", :longitude => "132.73333").save
City.new(:country_id => "116", :name => "Suita", :aliases => "Suika,Suita,chui tian shi,seu-ita si,Ð¡ÑÐ¸ÑÐ°,å¹ç°å¸,ì¤ì´í ì,Suita", :latitude => "34.76143", :longitude => "135.51567").save
City.new(:country_id => "116", :name => "Suibara", :aliases => ",Suibara", :latitude => "37.83333", :longitude => "139.23333").save
City.new(:country_id => "116", :name => "Sugito", :aliases => "Sugito,Sugito", :latitude => "36.03333", :longitude => "139.73333").save
City.new(:country_id => "116", :name => "Sueyoshi", :aliases => ",Sueyoshi", :latitude => "31.65", :longitude => "131.01667").save
City.new(:country_id => "116", :name => "Soka", :aliases => "Sok,Soka,SÅka,Ð¡Ð¾Ðº,SÅka", :latitude => "35.82028", :longitude => "139.80444").save
City.new(:country_id => "116", :name => "Soja", :aliases => "Soja,Sozya,SÅja,SÅzya,SÅja", :latitude => "34.66667", :longitude => "133.75").save
City.new(:country_id => "116", :name => "Sobue", :aliases => ",Sobue", :latitude => "35.25", :longitude => "136.71667").save
City.new(:country_id => "116", :name => "Shobu", :aliases => "Sebu,Shobu,ShÅbu,Ð¡ÐµÐ±Ñ,ShÅbu", :latitude => "36.06667", :longitude => "139.6").save
City.new(:country_id => "116", :name => "Shobara", :aliases => "Shobara,ShÅbara,ShÅbara", :latitude => "34.85", :longitude => "133.01667").save
City.new(:country_id => "116", :name => "Shizuoka-shi", :aliases => "Shizuoka,Shizuoka-shi,Siduoka,Sidzuoka,Sizuoka,jing gang shi,shyzwawka,sijeuoka si,Åizuoka,Å izuoka,Ð¡Ð¸Ð´Ð·ÑÐ¾ÐºÐ°,Ø´ÙØ²ÙØ£ÙÙØ§,ããããã,éå²¡å¸,éå²¡å¸,ìì¦ì¤ì¹´ ì,Shizuoka-shi", :latitude => "34.97694", :longitude => "138.38306").save
City.new(:country_id => "116", :name => "Shirone", :aliases => ",Shirone", :latitude => "37.76667", :longitude => "139.01667").save
City.new(:country_id => "116", :name => "Shiraoka", :aliases => "Shiraoka,Shiraoka", :latitude => "36.01667", :longitude => "139.66667").save
City.new(:country_id => "116", :name => "Shirahama", :aliases => "Shirahama,Shirahama-ku,Shirakhama,Ð¨Ð¸ÑÐ°ÑÐ°Ð¼Ð°,Shirahama", :latitude => "34.78333", :longitude => "134.71667").save
City.new(:country_id => "116", :name => "Shiozawa", :aliases => ",Shiozawa", :latitude => "37.03333", :longitude => "138.85").save
City.new(:country_id => "116", :name => "Shiojiri", :aliases => "Shiojiri,Sioziri,Shiojiri", :latitude => "36.1", :longitude => "137.96667").save
City.new(:country_id => "116", :name => "Shinshiro", :aliases => "Shinshiro,Shinshiro", :latitude => "34.9", :longitude => "137.5").save
City.new(:country_id => "116", :name => "Shinichi", :aliases => ",Shinichi", :latitude => "34.55", :longitude => "133.26667").save
City.new(:country_id => "116", :name => "Shingu", :aliases => "Shingu,ShingÅ«,Sing,Singu,SingÅ«,Ð¡Ð¸Ð½Ð³,ShingÅ«", :latitude => "33.71667", :longitude => "130.43333").save
City.new(:country_id => "116", :name => "Shinagawa-ku", :aliases => "Shinagawa,pin chuan,pin chuan qu,åå·,åå·åº,Shinagawa-ku", :latitude => "35.60902", :longitude => "139.73017").save
City.new(:country_id => "116", :name => "Shimonoseki", :aliases => "Shimonoseki,Simonoseki,Ð¡Ð¸Ð¼Ð¾Ð½Ð¾ÑÐµÐºÐ¸,Shimonoseki", :latitude => "33.95", :longitude => "130.95").save
City.new(:country_id => "116", :name => "Shimodate", :aliases => "Shimodate,Simodate,Shimodate", :latitude => "36.3", :longitude => "139.98333").save
City.new(:country_id => "116", :name => "Shimoda", :aliases => "Shimoda,Simoda,Ð¡Ð¸Ð¼Ð¾Ð´Ð°,Shimoda", :latitude => "34.66667", :longitude => "138.95").save
City.new(:country_id => "116", :name => "Shimminatocho", :aliases => "Shimminatocho,ShimminatochÅ,Shinkomachi,ShinkÅmachi,ShimminatochÅ", :latitude => "34.18333", :longitude => "135.2").save
City.new(:country_id => "116", :name => "Shimminato", :aliases => "Shimminato,Shinminato,Shimminato", :latitude => "36.78333", :longitude => "137.06667").save
City.new(:country_id => "116", :name => "Shimada", :aliases => "Shimada,Simada,Ð¡Ð¸Ð¼Ð°Ð´Ð°,Shimada", :latitude => "34.81667", :longitude => "138.18333").save
City.new(:country_id => "116", :name => "Shimabara", :aliases => "Shimabara,Simabara,Shimabara", :latitude => "32.78333", :longitude => "130.36667").save
City.new(:country_id => "116", :name => "Shiki", :aliases => "Shiki,Siki,zhi mu shi,Ð¡Ð¸ÐºÐ¸,å¿æ¨å¸,Shiki", :latitude => "35.83333", :longitude => "139.58333").save
City.new(:country_id => "116", :name => "Shido", :aliases => ",Shido", :latitude => "34.32333", :longitude => "134.17333").save
City.new(:country_id => "116", :name => "Shibushi", :aliases => "Sibusi,Shibushi", :latitude => "31.46667", :longitude => "131.105").save
City.new(:country_id => "116", :name => "Shibukawa", :aliases => "Shibukawa,Shibukawa", :latitude => "36.48333", :longitude => "139").save
City.new(:country_id => "116", :name => "Shibata", :aliases => "Shibata,sibata,Ð¨Ð¸Ð±Ð°ÑÐ°,Shibata", :latitude => "37.95", :longitude => "139.33333").save
City.new(:country_id => "116", :name => "Seto", :aliases => "Seto,Setu,lai hu shi,Ð¡ÐµÑÑ,ç¬æ¸å¸,Seto", :latitude => "35.23333", :longitude => "137.1").save
City.new(:country_id => "116", :name => "Setaka", :aliases => "Sedaka,Setaka,Setaka", :latitude => "33.15", :longitude => "130.46667").save
City.new(:country_id => "116", :name => "Sendai", :aliases => "Sendai,Sendaj,Sendajus,chuan nei,chuan nei shi,sendai si,sndayy,Ð¡ÐµÐ½Ð´Ð°Ð¹,Ð¡ÐµÐ½Ð´Ð°Ñ,Ø³ÙØ¯Ø§Ø¦Ù,å·å,å·åå¸,ì¼ë¤ì´ ì,Sendai", :latitude => "31.81667", :longitude => "130.3").save
City.new(:country_id => "116", :name => "Satte", :aliases => "Satte,Satte", :latitude => "36.06667", :longitude => "139.71667").save
City.new(:country_id => "116", :name => "Sasebo", :aliases => "Sasebo,Sasebum,Saseho,sasebo si,zuo shi bao shi,Ð¡Ð°ÑÐµÐ±Ð¾,ä½ä¸ä¿å¸,ì¬ì¸ë³´ ì,Sasebo", :latitude => "33.15917", :longitude => "129.72278").save
City.new(:country_id => "116", :name => "Sasayama", :aliases => "Sasajama,Sasayama,Ð¡Ð°ÑÐ°ÑÐ¼Ð°,Sasayama", :latitude => "35.06667", :longitude => "135.21667").save
City.new(:country_id => "116", :name => "Sasaguri", :aliases => "Sasaguri,Sasaguri", :latitude => "33.61667", :longitude => "130.53333").save
City.new(:country_id => "116", :name => "Sano", :aliases => "Sana,Sano,Ð¡Ð°Ð½Ð°,Sano", :latitude => "36.31667", :longitude => "139.58333").save
City.new(:country_id => "116", :name => "Sanjo", :aliases => "Sandscho,Sandyo,Sandze,Sanjo,SanjÅ,Sanzyo,SanzyÅ,Ð¡Ð°Ð½Ð´Ð·Ðµ,SanjÅ", :latitude => "37.61667", :longitude => "138.95").save
City.new(:country_id => "116", :name => "Sanda", :aliases => "Sanda,Ð¡Ð°Ð½Ð´Ð°,Sanda", :latitude => "34.88333", :longitude => "135.23333").save
City.new(:country_id => "116", :name => "Sakurai", :aliases => "Sakurai,Sakuri,Ð¡Ð°ÐºÑÑÐ°Ð¸,Sakurai", :latitude => "34.5", :longitude => "135.85").save
City.new(:country_id => "116", :name => "Saku", :aliases => "Saku,Saku", :latitude => "36.21667", :longitude => "138.48333").save
City.new(:country_id => "116", :name => "Sakata", :aliases => "Sakata,Ð¡Ð°ÐºÐ°ÑÐ°,Sakata", :latitude => "38.91667", :longitude => "139.855").save
City.new(:country_id => "116", :name => "Sakaiminato", :aliases => "Sakae,Sakai,Sakaiminato,Sakaiminato", :latitude => "35.55", :longitude => "133.23333").save
City.new(:country_id => "116", :name => "Sakaide", :aliases => "Sakaide,Sakaide-cho,Sakaide-chÅ,Sakaidecho,SakaidechÅ,Sakaide", :latitude => "34.31667", :longitude => "133.85").save
City.new(:country_id => "116", :name => "Sakai", :aliases => ",Sakai", :latitude => "36.26667", :longitude => "139.25").save
City.new(:country_id => "116", :name => "Sakai", :aliases => "Sakai,Ð¡Ð°ÐºÐ°Ð¸,Sakai", :latitude => "36.1", :longitude => "139.8").save
City.new(:country_id => "116", :name => "Sakai", :aliases => "Sacaia,Sacaium,Sakai,jie shi,sakai si,Ð¡Ð°ÐºÐ°Ð¸,å ºå¸,ì¬ì¹´ì´ ì,Sakai", :latitude => "34.58333", :longitude => "135.46667").save
City.new(:country_id => "116", :name => "Sakado", :aliases => "Sakado,ban hu shi,åæ¸å¸,Sakado", :latitude => "35.95694", :longitude => "139.38889").save
City.new(:country_id => "116", :name => "Saiki", :aliases => "Saeki,Saiki,Saiki", :latitude => "32.95", :longitude => "131.9").save
City.new(:country_id => "116", :name => "Sagara", :aliases => ",Sagara", :latitude => "34.68333", :longitude => "138.2").save
City.new(:country_id => "116", :name => "Sagamihara", :aliases => "Sagamihara,Sagamikhare,xiang mo yuan shi,Ð¡Ð°Ð³Ð°Ð¼Ð¸ÑÐ°ÑÐµ,ç¸æ¨¡åå¸,Sagamihara", :latitude => "35.55306", :longitude => "139.35444").save
City.new(:country_id => "116", :name => "Saga-shi", :aliases => "Saga,Saga Japonija,Saga-shi,zuo he,Ð¡Ð°Ð³Ð° Ð¯Ð¿Ð¾Ð½Ð¸Ñ,ããã,ä½è³,ä½è³å¸,Saga-shi", :latitude => "33.24932", :longitude => "130.2988").save
City.new(:country_id => "116", :name => "Sabae", :aliases => "Sabae,qing jiang shi,é¯æ±å¸,Sabae", :latitude => "35.94647", :longitude => "136.18498").save
City.new(:country_id => "116", :name => "Ryuo", :aliases => ",RyÅ«Å", :latitude => "35.65", :longitude => "138.5").save
City.new(:country_id => "116", :name => "Ryotsu", :aliases => "Ryotsu,Ryotu,Ryozu,RyÅtsu,RyÅzu,RyÅtsu", :latitude => "38.08333", :longitude => "138.43333").save
City.new(:country_id => "116", :name => "Ozu", :aliases => "Odzu,Otsu,Ozu,Åzu,ÐÐ´Ð·Ñ,Åzu", :latitude => "32.86667", :longitude => "130.86667").save
City.new(:country_id => "116", :name => "Oyama", :aliases => "Ojama,Oyama,ÐÑÐ¼Ð°,Oyama", :latitude => "36.3", :longitude => "139.8").save
City.new(:country_id => "116", :name => "Oyama", :aliases => ",Åyama", :latitude => "34.6", :longitude => "138.21667").save
City.new(:country_id => "116", :name => "Owase", :aliases => "Otaka,Ovaseh,Owase,Owashi,ÐÐ²Ð°ÑÑ,Owase", :latitude => "34.06667", :longitude => "136.2").save
City.new(:country_id => "116", :name => "Otsuki", :aliases => "Ocuki,Otsuki,Åtsuki,ÐÑÑÐºÐ¸,Åtsuki", :latitude => "35.6", :longitude => "138.93333").save
City.new(:country_id => "116", :name => "Otsu-shi", :aliases => "Ocu,Otsu,Otsu-shi,Otu,da jin shi,osseu si,Ãcu,Åtsu,Åtsu-shi,Åtu,ÐÑÑ,ããã¤ã,å¤§æ´¥å¸,ì¤ì° ì,Åtsu-shi", :latitude => "35.00444", :longitude => "135.86833").save
City.new(:country_id => "116", :name => "Otake", :aliases => "Otake,Otakeh,Åtake,ÐÑÐ°ÐºÑ,Åtake", :latitude => "34.2", :longitude => "132.21667").save
City.new(:country_id => "116", :name => "Ota", :aliases => "Ota,Åta,ÐÑÐ°,Åta", :latitude => "36.3", :longitude => "139.36667").save
City.new(:country_id => "116", :name => "Osaka-shi", :aliases => "OSA,Osaca,Osaca - da ban shi,Osaca - å¤§éªå¸,Osaka,Osaka-shi,Osako,Oszaka,awsaka,awzaka,da ban shi,osaka,osaka si,xo sa ka,ywsaka,Ãsaka,Ãszaka,Åsaka,Åsaka-shi,ÐÑÐ°ÐºÐ°,×××¡×§×,Ø£ÙØ³Ø§ÙØ§,Ø¦ÙØ³Ø§ÙØ§,Ø§ÙØ²Ø§Ú©Ø§,à¦à¦¸à¦¾à¦à¦¾,à¹à¸­à¸à¸°à¸à¸°,áá¡ááá,ããããã,å¤§éªå¸,ì¤ì¬ì¹´ ì,Åsaka-shi", :latitude => "34.69374", :longitude => "135.50218").save
City.new(:country_id => "116", :name => "Onomichi", :aliases => "Onomichi,Onomiti,onomichi si,wei dao shi,å°¾éå¸,ì¤ë¸ë¯¸ì¹ ì,Onomichi", :latitude => "34.41667", :longitude => "133.2").save
City.new(:country_id => "116", :name => "Onoda", :aliases => ",Onoda", :latitude => "34.00139", :longitude => "131.18361").save
City.new(:country_id => "116", :name => "Ono", :aliases => "Ono,ÐÐ½Ð¾,Ono", :latitude => "35.98106", :longitude => "136.48727").save
City.new(:country_id => "116", :name => "Ono", :aliases => "Ono,Onocho,OnochÅ,ÐÐ½Ð¾,Ono", :latitude => "34.85", :longitude => "134.93333").save
City.new(:country_id => "116", :name => "Ono", :aliases => "Hama,Ono,Åno,ÐÐ½Ð¾,Åno", :latitude => "34.28333", :longitude => "132.26667").save
City.new(:country_id => "116", :name => "Omuta", :aliases => "Omuda,Omuta,da mou tian shi,Åmuda,Åmuta,ÐÐ¼ÑÑÐ°,å¤§çç°å¸,Åmuta", :latitude => "33.03333", :longitude => "130.45").save
City.new(:country_id => "116", :name => "Omura", :aliases => "Omura,Åmura,ÐÐ¼ÑÑÐ°,Åmura", :latitude => "32.92139", :longitude => "129.95389").save
City.new(:country_id => "116", :name => "Ome", :aliases => "Ome,Åme,ÐÐ¼Ðµ,Åme", :latitude => "35.78389", :longitude => "139.24306").save
City.new(:country_id => "116", :name => "Omama", :aliases => ",Åmama", :latitude => "36.43333", :longitude => "139.28333").save
City.new(:country_id => "116", :name => "Omachi", :aliases => "Omachi,da ting,Åmachi,å¤§çº,Åmachi", :latitude => "36.5", :longitude => "137.86667").save
City.new(:country_id => "116", :name => "Okuchi", :aliases => "Oguchi,Okuti,Åguchi,Åkuti,Åkuchi", :latitude => "32.06667", :longitude => "130.61667").save
City.new(:country_id => "116", :name => "Okegawa", :aliases => "Okegawa,Okugawamachi,tong chuan shi,æ¡¶å·å¸,Okegawa", :latitude => "36", :longitude => "139.55722").save
City.new(:country_id => "116", :name => "Okazaki", :aliases => "Okadzaki,Okazaki,gang qi shi,okajaki si,ÐÐºÐ°Ð´Ð·Ð°ÐºÐ¸,å²¡å´å¸,ì¤ì¹´ìí¤ ì,Okazaki", :latitude => "34.95", :longitude => "137.16667").save
City.new(:country_id => "116", :name => "Okayama-shi", :aliases => "Okajama,Okayama,Okayama-shi,okayama si,ÐÐºÐ°ÑÐ¼Ð°,ãããã¾ã,å²¡å±±å¸,ì¤ì¹´ì¼ë§ ì,Okayama-shi", :latitude => "34.66167", :longitude => "133.935").save
City.new(:country_id => "116", :name => "Okaya", :aliases => "Hirano,Okaya", :latitude => "36.05659", :longitude => "138.0451").save
City.new(:country_id => "116", :name => "Okawa", :aliases => "Okava,Okawa,Åkawa,ÐÐºÐ°Ð²Ð°,Åkawa", :latitude => "33.2", :longitude => "130.35").save
City.new(:country_id => "116", :name => "Ojiya", :aliases => "Ojiya,Ojiya", :latitude => "37.3", :longitude => "138.8").save
City.new(:country_id => "116", :name => "Oita-shi", :aliases => "Oita,Oita-shi,oita si,Ãita,Åita,Åita-shi,ÐÐ¸ÑÐ°,ããããã,å¤§åå¸,ì¤ì´í ì,Åita-shi", :latitude => "33.23806", :longitude => "131.6125").save
City.new(:country_id => "116", :name => "Oiso", :aliases => "Oiso,Oiso-machi,Åiso,Åiso-machi,Åiso", :latitude => "35.30306", :longitude => "139.30278").save
City.new(:country_id => "116", :name => "Oi", :aliases => "Oi,Åi,Åi", :latitude => "35.85111", :longitude => "139.51667").save
City.new(:country_id => "116", :name => "Ogori", :aliases => ",OgÅri", :latitude => "34.1", :longitude => "131.4").save
City.new(:country_id => "116", :name => "Ogawa", :aliases => "Ogava,Ogawa,ÐÐ³Ð°Ð²Ð°,Ogawa", :latitude => "36.05", :longitude => "139.26667").save
City.new(:country_id => "116", :name => "Ogaki", :aliases => "Oaki,Ogaki,Ågaki,Ågaki", :latitude => "35.35", :longitude => "136.61667").save
City.new(:country_id => "116", :name => "Odawara", :aliases => "Odavara,Odawara,ÐÐ´Ð°Ð²Ð°ÑÐ°,Odawara", :latitude => "35.25556", :longitude => "139.15972").save
City.new(:country_id => "116", :name => "Oda", :aliases => "Oda,Ota,da tian shi,Åda,Åta,ÐÐ´Ð°,å¤§ç°å¸,Åda", :latitude => "35.18333", :longitude => "132.5").save
City.new(:country_id => "116", :name => "Obu", :aliases => "Obu,Ofu,Åbu,Åfu,ÐÐ±Ñ,Åbu", :latitude => "35", :longitude => "136.96667").save
City.new(:country_id => "116", :name => "Obita", :aliases => "Nagayo,Obita,Obita", :latitude => "32.81667", :longitude => "129.88333").save
City.new(:country_id => "116", :name => "Obama", :aliases => "Obama,Ohama,ÐÐ±Ð°Ð¼Ð°,Obama", :latitude => "35.49576", :longitude => "135.74604").save
City.new(:country_id => "116", :name => "Nyuzen", :aliases => "Nyuzen,NyÅ«zen,NyÅ«zen", :latitude => "36.93333", :longitude => "137.5").save
City.new(:country_id => "116", :name => "Numazu", :aliases => "Numadu,Numazu,zhao jin shi,æ²¼æ´¥å¸,Numazu", :latitude => "35.1", :longitude => "138.86667").save
City.new(:country_id => "116", :name => "Numata", :aliases => "Numata,Numata", :latitude => "36.63333", :longitude => "139.05").save
City.new(:country_id => "116", :name => "Nonoichi", :aliases => "Nonoichi,ÐÐ¾Ð½Ð¾Ð¸ÑÐ¸,Nonoichi", :latitude => "36.53333", :longitude => "136.61667").save
City.new(:country_id => "116", :name => "Nogata", :aliases => "Naogata,Naokata,Nogata,NÅgata,NÅgata", :latitude => "33.73333", :longitude => "130.73333").save
City.new(:country_id => "116", :name => "Noda", :aliases => "Noda,ÐÐ¾Ð´Ð°,Noda", :latitude => "35.94111", :longitude => "139.85806").save
City.new(:country_id => "116", :name => "Nobeoka", :aliases => "Nobeoka,yan gang shi,ÐÐ¾Ð±ÐµÐ¾ÐºÐ°,å»¶å²¡å¸,Nobeoka", :latitude => "32.58333", :longitude => "131.66667").save
City.new(:country_id => "116", :name => "Nishiwaki", :aliases => "Nishivaki,Nishiwaki,ÐÐ¸ÑÐ¸Ð²Ð°ÐºÐ¸,Nishiwaki", :latitude => "34.98333", :longitude => "134.96667").save
City.new(:country_id => "116", :name => "Nishio", :aliases => "Nishio,Nisio,ÐÐ¸ÑÐ¸Ð¾,Nishio", :latitude => "34.86667", :longitude => "137.05").save
City.new(:country_id => "116", :name => "Nishinoomote", :aliases => "Nisinoomote,Nishinoomote", :latitude => "30.73333", :longitude => "131").save
City.new(:country_id => "116", :name => "Nishinomiya", :aliases => "Nishinomiya,Nisinomija,xi gong shi,ÐÐ¸ÑÐ¸Ð½Ð¾Ð¼Ð¸Ñ,è¥¿å®®å¸,Nishinomiya", :latitude => "34.71667", :longitude => "135.33333").save
City.new(:country_id => "116", :name => "Nirasaki", :aliases => "Nirasaki,Nirasakimachi,Nirazaki,Nirazakimachi,Nirasaki", :latitude => "35.7", :longitude => "138.45").save
City.new(:country_id => "116", :name => "Ninomiya", :aliases => "Ninomija,Ninomiya,ÐÐ¸Ð½Ð¾Ð¼Ð¸Ñ,Ninomiya", :latitude => "35.30333", :longitude => "139.25333").save
City.new(:country_id => "116", :name => "Nikko", :aliases => "Nikko,NikkÃ³,NikkÅ,nisko si,nykw,ri guang shi,ÙÙÙÙ,æ¥åå¸,ëì½ ì,NikkÅ", :latitude => "36.75", :longitude => "139.61667").save
City.new(:country_id => "116", :name => "Niitsu", :aliases => "Niitsu,Niitu,Niizu,xin jin shi,æ°æ´¥å¸,Niitsu", :latitude => "37.8", :longitude => "139.11667").save
City.new(:country_id => "116", :name => "Niimi", :aliases => "Niimi,ÐÐ¸Ð¸Ð¼Ð¸,Niimi", :latitude => "34.98333", :longitude => "133.46667").save
City.new(:country_id => "116", :name => "Niihama", :aliases => "Niihama,niihama,xin ju bang,ã«ãã¯ã¾,æ°å±æµ,Niihama", :latitude => "33.95933", :longitude => "133.31672").save
City.new(:country_id => "116", :name => "Niigata-shi", :aliases => "Niahi-niigata,Niigata,Niigata-shi,nigata si,ÐÐ¸Ð¸Ð³Ð°ÑÐ°,ã«ãããã,æ°æ½å¸,ëê°í ì,Niigata-shi", :latitude => "37.90222", :longitude => "139.02361").save
City.new(:country_id => "116", :name => "Nichinan", :aliases => "Nichinan,Nitinan,ÐÐ¸ÑÐ¸Ð½Ð°Ð½,Nichinan", :latitude => "31.6", :longitude => "131.36667").save
City.new(:country_id => "116", :name => "Nerima", :aliases => "Minamimachi,Nerima,lian ma,ç·´é¦¬,Nerima", :latitude => "35.73333", :longitude => "139.65").save
City.new(:country_id => "116", :name => "Naze", :aliases => "Nase,Naze,Naze", :latitude => "28.36667", :longitude => "129.48333").save
City.new(:country_id => "116", :name => "Naruto", :aliases => "Muya,Naruto,Naruto", :latitude => "34.18333", :longitude => "134.61667").save
City.new(:country_id => "116", :name => "Nara-shi", :aliases => "Nara,Nara, Nara,Nara-shi,nai liang shi,nala si,nara,ÐÐ°ÑÐ°,ÐÐ°ÑÐ°, ÐÐ°ÑÐ°,ÙØ§Ø±Ø§,ãªãã,å¥è¯å¸,ëë¼ ì,Nara-shi", :latitude => "34.68505", :longitude => "135.80485").save
City.new(:country_id => "116", :name => "Nanao", :aliases => "Nanao,ÐÐ°Ð½Ð°Ð¾,Nanao", :latitude => "37.05", :longitude => "136.96667").save
City.new(:country_id => "116", :name => "Namerikawa", :aliases => "Namehrikava,Namerigawa,Namerikawa,ÐÐ°Ð¼ÑÑÐ¸ÐºÐ°Ð²Ð°,Namerikawa", :latitude => "36.76667", :longitude => "137.33333").save
City.new(:country_id => "116", :name => "Nakatsugawa", :aliases => "Nakatsu,Nakatsugawa,Nakatsugawa", :latitude => "35.48333", :longitude => "137.5").save
City.new(:country_id => "116", :name => "Nakatsu", :aliases => "Nakatsu,Nakatu,Nakatsu", :latitude => "33.60139", :longitude => "131.18417").save
City.new(:country_id => "116", :name => "Nakanojo", :aliases => ",NakanojÅ", :latitude => "36.58333", :longitude => "138.85").save
City.new(:country_id => "116", :name => "Nakano", :aliases => "Nakano,ÐÐ°ÐºÐ°Ð½Ð¾,Nakano", :latitude => "36.75", :longitude => "138.36667").save
City.new(:country_id => "116", :name => "Nakamura", :aliases => "Nakamura,Nakamuramachi,ÐÐ°ÐºÐ°Ð¼ÑÑÐ°,Nakamura", :latitude => "32.98333", :longitude => "132.93333").save
City.new(:country_id => "116", :name => "Nakama", :aliases => "Nakama,Nakama", :latitude => "33.81667", :longitude => "130.7").save
City.new(:country_id => "116", :name => "Naha-shi", :aliases => "Nafa,Naha,Naha-shi,Nakha,Nawa,na ba shi,naha si,nhh,ÐÐ°ÑÐ°,× ××,ãªã¯ã,é£è¦å¸,é£é¸å¸,ëí ì,Naha-shi", :latitude => "26.2125", :longitude => "127.68111").save
City.new(:country_id => "116", :name => "Nagoya-shi", :aliases => "Nagoia,Nagoia - ming gu wu shi,Nagoia - åå¤å±å¸,Nagoja,Nagoja Urbo,Nagoya,Nagoya-shi,ming gu wu shi,na ko ya,naghwya,nagoya si,nagwya,ÐÐ°Ð³Ð¾Ñ,ÙØ§ØºÙÙØ§,ÙØ§Ú¯ÙÛØ§,à¸à¸²à¹à¸à¸¢à¹à¸²,ãªããã,åå¤å±å¸,ëê³ ì¼ ì,Nagoya-shi", :latitude => "35.18147", :longitude => "136.90641").save
City.new(:country_id => "116", :name => "Nago", :aliases => "Naga,Nago,Nagu,Okaneku,Ãkaneku,ÐÐ°Ð³Ð°,Nago", :latitude => "26.58806", :longitude => "127.97611").save
City.new(:country_id => "116", :name => "Nagasaki-shi", :aliases => "Nagasacium,Nagasaki,Nagasaki-shi,Nagasakis,Nagasako,Nagaszaki,nagasaki,nagasaki si,nagazaky,naghasaky,najazaky,zhang qi shi,ÐÐ°Ð³Ð°ÑÐ°ÐºÐ¸,× ××¡××§×,ÙØ§Ø¬Ø§Ø²Ø§ÙÙ,ÙØ§ØºØ§Ø³Ø§ÙÙ,ÙØ§Ú¯Ø§Ø²Ø§Ú©Û,à¤¨à¤¾à¤à¤¾à¤¸à¤¾à¤à¥,ááááá¡ááá,ãªãããã,é·å´å¸,é¿å´å¸,ëê°ì¬í¤ ì,Nagasaki-shi", :latitude => "32.74472", :longitude => "129.87361").save
City.new(:country_id => "116", :name => "Nagareyama", :aliases => "Nagareyama,liu shan,liu shan shi,æµå±±,æµå±±å¸,Nagareyama", :latitude => "35.8563", :longitude => "139.90266").save
City.new(:country_id => "116", :name => "Nagaoka", :aliases => "Nagaoka,ÐÐ°Ð³Ð°Ð¾ÐºÐ°,Nagaoka", :latitude => "37.45", :longitude => "138.85").save
City.new(:country_id => "116", :name => "Nagano-shi", :aliases => "Nagano,Nagano-shi,zhang ye,ÐÐ°Ð³Ð°Ð½Ð¾,ãªãã®ã,é·é,é·éå¸,Nagano-shi", :latitude => "36.65139", :longitude => "138.18111").save
City.new(:country_id => "116", :name => "Nagahama", :aliases => "Nagahama,Nagakhama,ÐÐ°Ð³Ð°ÑÐ°Ð¼Ð°,Nagahama", :latitude => "35.38333", :longitude => "136.26667").save
City.new(:country_id => "116", :name => "Nabari", :aliases => "Nabari,ming zhang shi,åå¼µå¸,Nabari", :latitude => "34.61667", :longitude => "136.08333").save
City.new(:country_id => "116", :name => "Musashino", :aliases => "Musashino,Musasino,musasino si,wu cang ye shi,wu zang ye shi,ÐÑÑÐ°ÑÐ¸Ð½Ð¾,æ­¦èµéå¸,æ­¦èéå¸,ë¬´ì¬ìë¸ ì,Musashino", :latitude => "35.70611", :longitude => "139.55944").save
City.new(:country_id => "116", :name => "Muroto", :aliases => "Muroto,Muroto", :latitude => "33.28333", :longitude => "134.15").save
City.new(:country_id => "116", :name => "Muramatsu", :aliases => ",Muramatsu", :latitude => "37.68333", :longitude => "139.18333").save
City.new(:country_id => "116", :name => "Murakami", :aliases => "Murakami,Murakamimachi,ÐÑÑÐ°ÐºÐ°Ð¼Ð¸,Murakami", :latitude => "38.23333", :longitude => "139.48333").save
City.new(:country_id => "116", :name => "Muko", :aliases => "Muka,ÐÑÐºÐ°,MukÅ", :latitude => "34.96545", :longitude => "135.70415").save
City.new(:country_id => "116", :name => "Muikamachi", :aliases => "Muika,Muikamachi,Muikamachi", :latitude => "37.06667", :longitude => "138.88333").save
City.new(:country_id => "116", :name => "Morohongo", :aliases => "Morohongo,MorohongÅ,Moroyama,MorohongÅ", :latitude => "35.93556", :longitude => "139.30444").save
City.new(:country_id => "116", :name => "Moriyama", :aliases => "Morijama,Moriyama,ÐÐ¾ÑÐ¸ÑÐ¼Ð°,Moriyama", :latitude => "35.06667", :longitude => "135.98333").save
City.new(:country_id => "116", :name => "Moriguchi", :aliases => "Moriguchi,shou kou shi,å®å£å¸,Moriguchi", :latitude => "34.73333", :longitude => "135.56667").save
City.new(:country_id => "116", :name => "Mori", :aliases => "More,Mori,ÐÐ¾ÑÐµ,Mori", :latitude => "34.83333", :longitude => "137.93333").save
City.new(:country_id => "116", :name => "Mizunami", :aliases => "Mizunami,Mizunami-cho,Mizunami-chÅ,Mizunami", :latitude => "35.36667", :longitude => "137.25").save
City.new(:country_id => "116", :name => "Miyoshi", :aliases => ",Miyoshi", :latitude => "35.08333", :longitude => "137.06667").save
City.new(:country_id => "116", :name => "Miyoshi", :aliases => "Miyoshi,Miyosi,Miyoshi", :latitude => "34.8", :longitude => "132.85").save
City.new(:country_id => "116", :name => "Miyazu", :aliases => "Miyazu,Miyazu", :latitude => "35.53333", :longitude => "135.18333").save
City.new(:country_id => "116", :name => "Miyazaki-shi", :aliases => "Mijadzaki,Miyazaki-shi,gong qi,ÐÐ¸ÑÐ´Ð·Ð°ÐºÐ¸,ã¿ãããã,å®®å´,å®®å´å¸,Miyazaki-shi", :latitude => "31.91111", :longitude => "131.42389").save
City.new(:country_id => "116", :name => "Miyakonojo", :aliases => "Miyakonojo,MiyakonojÅ,Miyakonozyo,MiyakonozyÅ,dou cheng,é½å,MiyakonojÅ", :latitude => "31.73333", :longitude => "131.06667").save
City.new(:country_id => "116", :name => "Miyada", :aliases => "Miyada,Miyata,Miyada", :latitude => "33.71667", :longitude => "130.66667").save
City.new(:country_id => "116", :name => "Mitsuke", :aliases => "Mitsuke,Mitsuke", :latitude => "37.53333", :longitude => "138.93333").save
City.new(:country_id => "116", :name => "Mitsukaido", :aliases => "Mitsukaido,MitsukaidÅ,Mizukaido,MizukaidÅ,MitsukaidÅ", :latitude => "36.01667", :longitude => "139.98333").save
City.new(:country_id => "116", :name => "Mitake", :aliases => "Mitake,Mitake-cho,Mitake-chÅ,Mitake", :latitude => "35.41667", :longitude => "137.13333").save
City.new(:country_id => "116", :name => "Mitaka-shi", :aliases => "Mitaka,san ying,san ying shi,ä¸é·¹,ä¸é·¹å¸,Mitaka-shi", :latitude => "35.68351", :longitude => "139.55963").save
City.new(:country_id => "116", :name => "Mishima", :aliases => "Mishima,Misima,ÐÐ¸ÑÐ¸Ð¼Ð°,Mishima", :latitude => "35.11667", :longitude => "138.91667").save
City.new(:country_id => "116", :name => "Mino", :aliases => "Mino-shi,Minoh City,ji mian,ji mian shi,ç®é¢,ç®é¢å¸,Mino", :latitude => "34.82691", :longitude => "135.47057").save
City.new(:country_id => "116", :name => "Mino", :aliases => "Mina,Mino,Minomachi,ÐÐ¸Ð½Ð°,Mino", :latitude => "35.53333", :longitude => "136.91667").save
City.new(:country_id => "116", :name => "Minami-rinkan", :aliases => "Minami Rinkan Yamato,Minami-rinkan,Minami-rinkan", :latitude => "35.48333", :longitude => "139.45").save
City.new(:country_id => "116", :name => "Minamata", :aliases => "Minamata,Mizumata,minamata si,shui yu shi,ÐÐ¸Ð½Ð°Ð¼Ð°ÑÐ°,æ°´ä¿£å¸,ë¯¸ëë§í ì,Minamata", :latitude => "32.21667", :longitude => "130.4").save
City.new(:country_id => "116", :name => "Minakuchi", :aliases => ",Minakuchi", :latitude => "34.96667", :longitude => "136.16667").save
City.new(:country_id => "116", :name => "Mikuni", :aliases => ",Mikuni", :latitude => "36.21706", :longitude => "136.15185").save
City.new(:country_id => "116", :name => "Miki", :aliases => "Miki,ÐÐ¸ÐºÐ¸,Miki", :latitude => "34.8", :longitude => "134.98333").save
City.new(:country_id => "116", :name => "Mihara", :aliases => "Mihama,Mihara,Mihara", :latitude => "34.4", :longitude => "133.08333").save
City.new(:country_id => "116", :name => "Mibu", :aliases => "Mibu,ÐÐ¸Ð±Ñ,Mibu", :latitude => "36.41667", :longitude => "139.8").save
City.new(:country_id => "116", :name => "Menuma", :aliases => "Menuma,Menuma", :latitude => "36.21667", :longitude => "139.38333").save
City.new(:country_id => "116", :name => "Matsuto", :aliases => "Matsuto,MatsutÅ,Matto,MattÅ,MatsutÅ", :latitude => "36.51667", :longitude => "136.56667").save
City.new(:country_id => "116", :name => "Matsuzaka", :aliases => "Matsusaka,Matsuzaka,song ban shi,æ¾éªå¸,Matsuzaka", :latitude => "34.56667", :longitude => "136.53333").save
City.new(:country_id => "116", :name => "Matsumoto", :aliases => "Fukase,Fukashi,Macumoto,Matsumoto,Matumoto,Shonai,song ben,song ben shi,ÐÐ°ÑÑÐ¼Ð¾ÑÐ¾,æ¾æ¬,æ¾æ¬å¸,Matsumoto", :latitude => "36.23333", :longitude => "137.96667").save
City.new(:country_id => "116", :name => "Matsue-shi", :aliases => "Macueh,Matsu,Matsue-shi,Matue,ÐÐ°ÑÑÑ,ã¾ã¤ãã,æ¾æ±å¸,Matsue-shi", :latitude => "35.47222", :longitude => "133.05056").save
City.new(:country_id => "116", :name => "Matsudo", :aliases => "Macudo,Matsudo,masseudo si,song hu shi,ÐÐ°ÑÑÐ´Ð¾,æ¾æ¶å¸,æ¾æ¸å¸,ë§ì°ë ì,Matsudo", :latitude => "35.78333", :longitude => "139.9").save
City.new(:country_id => "116", :name => "Matsubase", :aliases => ",Matsubase", :latitude => "32.65", :longitude => "130.66667").save
City.new(:country_id => "116", :name => "Matsubara", :aliases => "Matsubara,Matsubara", :latitude => "34.56667", :longitude => "135.55").save
City.new(:country_id => "116", :name => "Masuda", :aliases => "Masud,Masuda,ÐÐ°ÑÑÐ´,Masuda", :latitude => "34.66667", :longitude => "131.85").save
City.new(:country_id => "116", :name => "Maruoka", :aliases => ",Maruoka", :latitude => "36.1534", :longitude => "136.27029").save
City.new(:country_id => "116", :name => "Maruko", :aliases => "Mariko,Maruko,ÐÐ°ÑÑÐºÐ¾,Maruko", :latitude => "36.31667", :longitude => "138.26667").save
City.new(:country_id => "116", :name => "Marugame", :aliases => "Marugame,Marukame,wan gui shi,ä¸¸äºå¸,Marugame", :latitude => "34.28333", :longitude => "133.78333").save
City.new(:country_id => "116", :name => "Makurazaki", :aliases => "Makurasaki,Mazuraki,Makurazaki", :latitude => "31.26667", :longitude => "130.31667").save
City.new(:country_id => "116", :name => "Maki", :aliases => ",Maki", :latitude => "37.75", :longitude => "138.88333").save
City.new(:country_id => "116", :name => "Maizuru", :aliases => "Maidsuru,Maiduru,Maizuru,Majdzuru,maijeulu si,wu he shi,ÐÐ°Ð¹Ð´Ð·ÑÑÑ,èé¶´å¸,èé¹¤å¸,ë§ì´ì¦ë£¨ ì,Maizuru", :latitude => "35.45", :longitude => "135.33333").save
City.new(:country_id => "116", :name => "Maebashi-shi", :aliases => "Maebashi,Maebashi-shi,Maebasi,MaebaÅ¡i,Maehbasi,ma-ebasi si,ÐÐ°ÑÐ±Ð°ÑÐ¸,ã¾ãã°ãã,åæ©å¸,ë§ìë°ì ì,Maebashi-shi", :latitude => "36.39111", :longitude => "139.06083").save
City.new(:country_id => "116", :name => "Maebaru", :aliases => "Maebaru,Maeharu,Maebaru", :latitude => "33.55", :longitude => "130.2").save
City.new(:country_id => "116", :name => "Machida", :aliases => "Machida,ting tian shi,ÐÐ°ÑÐ¸Ð´Ð°,çºç°å¸,Machida", :latitude => "35.54028", :longitude => "139.45083").save
City.new(:country_id => "116", :name => "Kyoto", :aliases => "Kiotas,Kioto,Kjoto,KjÃ³to,Kyoto,Kyoto-shi,Kyotum,KyÅto,KyÅto-shi,Quioto,Quioto - jing dou shi,Quioto - äº¬é½å¸,gyoto si,jing dou,jing dou shi,kywtw,qywtw,ÎÎ¹ÏÏÎ¿,ÐÐ¸Ð¾ÑÐ¾,ÐÑÐ¾ÑÐ¾,ÐÑÐ¾ÑÐ¾,×§××××,ÙÙÙØªÙ,áááá¢á,ãããã¨ã,äº¬é½,äº¬é½å¸,êµí  ì,Kyoto", :latitude => "35.02107", :longitude => "135.75385").save
City.new(:country_id => "116", :name => "Kuwana", :aliases => "Kumana,Kuwana,sang ming shi,æ¡åå¸,Kuwana", :latitude => "35.06667", :longitude => "136.7").save
City.new(:country_id => "116", :name => "Kushikino", :aliases => "Kushigino,Kushikino,Kusiki-no,Kushikino", :latitude => "31.71667", :longitude => "130.26667").save
City.new(:country_id => "116", :name => "Kusatsu", :aliases => "Kusacu,Kusatsu,Kusatsu-cho,Kusatsu-chÅ,Kusatu,Susatsu,ÐÑÑÐ°ÑÑ,Kusatsu", :latitude => "35.01667", :longitude => "135.96667").save
City.new(:country_id => "116", :name => "Kurume", :aliases => "Kurume,ÐÑÑÑÐ¼Ðµ,Kurume", :latitude => "33.31667", :longitude => "130.51667").save
City.new(:country_id => "116", :name => "Kuroda", :aliases => "Kisogawa,Kuroda,ÐÑÑÐ¾Ð´Ð°,Kuroda", :latitude => "35.35", :longitude => "136.78333").save
City.new(:country_id => "116", :name => "Kurihashi", :aliases => "Kurihashi,Kurihashi", :latitude => "36.13333", :longitude => "139.7").save
City.new(:country_id => "116", :name => "Kure", :aliases => "Kure,wu shi,ÐÑÑÐµ,åå¸,Kure", :latitude => "34.23333", :longitude => "132.56667").save
City.new(:country_id => "116", :name => "Kurayoshi", :aliases => "Kurayoshi,Kurayoshi", :latitude => "35.43333", :longitude => "133.81667").save
City.new(:country_id => "116", :name => "Kurashiki", :aliases => "Kurashiki,Kurasiki,cang fu shi,ÐÑÑÐ°ÑÐ¸ÐºÐ¸,åæ·å¸,Kurashiki", :latitude => "34.58333", :longitude => "133.76667").save
City.new(:country_id => "116", :name => "Kumamoto-shi", :aliases => "Kumamoto,Kumamoto-shi,gumamoto si,xiong ben shi,ÐÑÐ¼Ð°Ð¼Ð¾ÑÐ¾,ãã¾ãã¨ã,çæ¬å¸,êµ¬ë§ëª¨í  ì,Kumamoto-shi", :latitude => "32.78972", :longitude => "130.74167").save
City.new(:country_id => "116", :name => "Kumagaya", :aliases => "Kumagai,Kumagaya,gumagaya si,xiong gu shi,çè°·å¸,êµ¬ë§ê°ì¼ ì,Kumagaya", :latitude => "36.13333", :longitude => "139.38333").save
City.new(:country_id => "116", :name => "Kuki", :aliases => "Kuki,ÐÑÐºÐ¸,Kuki", :latitude => "36.06667", :longitude => "139.66667").save
City.new(:country_id => "116", :name => "Kudamatsu", :aliases => "Kudamatsu,Kudamatsu", :latitude => "34", :longitude => "131.86667").save
City.new(:country_id => "116", :name => "Kozakai-cho", :aliases => "Kozakai,Kozakai-cho,Kozakai-chÅ,ããããã¡ãã,å°åäºçº,Kozakai-chÅ", :latitude => "34.8", :longitude => "137.35889").save
City.new(:country_id => "116", :name => "Kosugi", :aliases => ",Kosugi", :latitude => "36.71667", :longitude => "137.1").save
City.new(:country_id => "116", :name => "Koshigaya", :aliases => "Koshigaya,yue gu shi,è¶è°·å¸,Koshigaya", :latitude => "35.88333", :longitude => "139.78333").save
City.new(:country_id => "116", :name => "Kosai-shi", :aliases => "Kosai,Kosai-shi,hu xi,hu xi shi,æ¹è¥¿,æ¹è¥¿å¸,Kosai-shi", :latitude => "34.7184", :longitude => "137.53175").save
City.new(:country_id => "116", :name => "Konosu", :aliases => "Konosu,KÅnosu,hong chao,é´»å·£,KÅnosu", :latitude => "36.05", :longitude => "139.51667").save
City.new(:country_id => "116", :name => "Konan", :aliases => "Konan,ÐÐ¾Ð½Ð°Ð½,KÅnan", :latitude => "35.33165", :longitude => "136.87042").save
City.new(:country_id => "116", :name => "Komoro", :aliases => "Komoro,Komoro", :latitude => "36.31667", :longitude => "138.43333").save
City.new(:country_id => "116", :name => "Komono", :aliases => "Komono,Komono", :latitude => "35", :longitude => "136.51667").save
City.new(:country_id => "116", :name => "Komatsushima", :aliases => "Komatsujima,Komatsushima,Komatusima,Komatsushima", :latitude => "34", :longitude => "134.58333").save
City.new(:country_id => "116", :name => "Komatsu", :aliases => ",Komatsu", :latitude => "36.40263", :longitude => "136.45088").save
City.new(:country_id => "116", :name => "Komaki", :aliases => "Komaki,ÐÐ¾Ð¼Ð°ÐºÐ¸,Komaki", :latitude => "35.28333", :longitude => "136.91667").save
City.new(:country_id => "116", :name => "Kokubunji", :aliases => "Kokubundzi,Kokubunji,ÐÐ¾ÐºÑÐ±ÑÐ½Ð´Ð·Ð¸,Kokubunji", :latitude => "35.70222", :longitude => "139.47556").save
City.new(:country_id => "116", :name => "Kokubu", :aliases => "Kokubo,Kokubu,Kokubun,guo fen,ÐÐ¾ÐºÑÐ±Ñ,å½å,Kokubu", :latitude => "31.73333", :longitude => "130.76667").save
City.new(:country_id => "116", :name => "Koganei", :aliases => "Koganei,xiao jin jing shi,å°éäºå¸,Koganei", :latitude => "35.69139", :longitude => "139.50111").save
City.new(:country_id => "116", :name => "Koga", :aliases => "Koga,ÐÐ¾Ð³Ð°,Koga", :latitude => "36.18333", :longitude => "139.71667").save
City.new(:country_id => "116", :name => "Koga", :aliases => "Koga,ÐÐ¾Ð³Ð°,Koga", :latitude => "33.73333", :longitude => "130.46667").save
City.new(:country_id => "116", :name => "Kofu-shi", :aliases => "Kofe,Kofu,Kofu-shi,Kohu,KÃ³fu,KÅfu,KÅfu-shi,KÅhu,gohu si,jia fu shi,ÐÐ¾ÑÐµ,ãããµã,ç²åºå¸,ê³ í ì,KÅfu-shi", :latitude => "35.66389", :longitude => "138.56833").save
City.new(:country_id => "116", :name => "Kodama", :aliases => "Kodama,ÐÐ¾Ð´Ð°Ð¼Ð°,Kodama", :latitude => "36.18333", :longitude => "139.13333").save
City.new(:country_id => "116", :name => "Kodaira", :aliases => "Kodaira,Kodairy,ÐÐ¾Ð´Ð°Ð¸ÑÑ,Kodaira", :latitude => "35.72639", :longitude => "139.48389").save
City.new(:country_id => "116", :name => "Kochi-shi", :aliases => "Kochi-shi,Kochin,Koti,KÃ´ti,KÅchi-shi,ÐÐ¾ÑÐ¸Ð½,ããã¡ã,é«ç¥å¸,KÅchi-shi", :latitude => "33.55972", :longitude => "133.53111").save
City.new(:country_id => "116", :name => "Kobe-shi", :aliases => "Kobe,Kobe-shi,Kobeh,KobÄ,KÃ³be,KÅbe,KÅbe-shi,gobe si,kobe,kwbh,qwbh,shen hu shi,ÐÐ¾Ð±Ðµ,ÐÐ¾Ð±Ñ,×§×××,ÙÙØ¨Ù,à¤à¥à¤¬à¥,ããã¹ã,ç¥æ·å¸,ç¥æ¸å¸,ê³ ë²  ì,KÅbe-shi", :latitude => "34.6913", :longitude => "135.183").save
City.new(:country_id => "116", :name => "Kobayashi", :aliases => "Kobajasi,Kobayashi,Kobayashi-cho,Kobayashi-chÅ,ÐÐ¾Ð±Ð°ÑÑÐ¸,Kobayashi", :latitude => "31.98333", :longitude => "130.98333").save
City.new(:country_id => "116", :name => "Kitsuki", :aliases => "Kicuki,Kitsuki,ÐÐ¸ÑÑÐºÐ¸,Kitsuki", :latitude => "33.41667", :longitude => "131.61667").save
City.new(:country_id => "116", :name => "Kitakyushu", :aliases => "Kitakiusuo,KitakiuÅuo,Kitakjushu,Kitakjusju,Kitakjusu,KitakjÃºsÃº,KitakjÃºÅ¡Ãº,Kitakyushu,KitakyÅ«shÅ«,bei jiu zhou shi,gitakyusyu si,ÐÐ¸ÑÐ°ÐºÑÑÑ,ÐÐ¸ÑÐ°ÐºÑÑÑÑ,åä¹å·å¸,ê¸°ííì ì,KitakyÅ«shÅ«", :latitude => "33.83333", :longitude => "130.83333").save
City.new(:country_id => "116", :name => "Kitakata", :aliases => "Kitagata,Kitakata,ÐÐ¸ÑÐ°ÐºÐ°ÑÐ°,Kitakata", :latitude => "37.65", :longitude => "139.86667").save
City.new(:country_id => "116", :name => "Kitahama", :aliases => ",Kitahama", :latitude => "35.16667", :longitude => "135.91667").save
City.new(:country_id => "116", :name => "Kishiwada", :aliases => "Kishiwada,Kisivada,Kisiwada,an he tian shi,gisiwada si,ÐÐ¸ÑÐ¸Ð²Ð°Ð´Ð°,å²¸åç°å¸,ê¸°ììë¤ ì,Kishiwada", :latitude => "34.46667", :longitude => "135.36667").save
City.new(:country_id => "116", :name => "Kisarazu", :aliases => "Kisaradu,Kisarazu,Kizarazu,gisalajeu si,mu geng jin shi,æ¨æ´æ´¥å¸,ê¸°ì¬ë¼ì¦ ì,Kisarazu", :latitude => "35.37472", :longitude => "139.9225").save
City.new(:country_id => "116", :name => "Kisai", :aliases => "Kisai,Kisai", :latitude => "36.1", :longitude => "139.58333").save
City.new(:country_id => "116", :name => "Kiryu", :aliases => "Kiri,Kiriu,Kiryu,KiryÅ«,ÐÐ¸ÑÐ¸,KiryÅ«", :latitude => "36.4", :longitude => "139.33333").save
City.new(:country_id => "116", :name => "Kikuchi", :aliases => "Kikuchi,Kikuti,ÐÐ¸ÐºÑÑÐ¸,Kikuchi", :latitude => "32.98333", :longitude => "130.81667").save
City.new(:country_id => "116", :name => "Kazo", :aliases => "Kazo,jia xu shi,å é å¸,Kazo", :latitude => "36.11667", :longitude => "139.6").save
City.new(:country_id => "116", :name => "Kawasaki", :aliases => "Kauasaki,Kavasakis,Kawasaki,Kawasaki Si,KaÅ­asaki,chuan qi shi,gawasaki si,kawasaky,ÙØ§ÙØ§Ø³Ø§ÙÙ,å·å´å¸,ê°ìì¬í¤ ì,Kawasaki", :latitude => "35.52056", :longitude => "139.71722").save
City.new(:country_id => "116", :name => "Kawasaki", :aliases => "Kawasaki,Kawasaki", :latitude => "33.58333", :longitude => "130.83333").save
City.new(:country_id => "116", :name => "Kawanishi", :aliases => "Kawanishi,Kawanishi", :latitude => "34.81667", :longitude => "135.41667").save
City.new(:country_id => "116", :name => "Kawaguchi", :aliases => "Kavaguti,Kawaguchi,chuan kou shi,ÐÐ°Ð²Ð°Ð³ÑÑÐ¸,å·å£å¸,Kawaguchi", :latitude => "35.805", :longitude => "139.72056").save
City.new(:country_id => "116", :name => "Kawagoe", :aliases => "Kawagoe,Kawagoe", :latitude => "35.90861", :longitude => "139.48528").save
City.new(:country_id => "116", :name => "Katsuyama", :aliases => ",Katsuyama", :latitude => "36.06173", :longitude => "136.50101").save
City.new(:country_id => "116", :name => "Kasukabe", :aliases => "Kasukabe,chun ri bu shi,gaseukabe si,æ¥æ¥é¨å¸,ê°ì¤ì¹´ë²  ì,Kasukabe", :latitude => "35.97639", :longitude => "139.75361").save
City.new(:country_id => "116", :name => "Kasugai", :aliases => "Kasugaj,ÐÐ°ÑÑÐ³Ð°Ð¹,Kasugai", :latitude => "35.24762", :longitude => "136.97229").save
City.new(:country_id => "116", :name => "Kashiwazaki", :aliases => "Kashiwazaki,Kasivadzaki,ÐÐ°ÑÐ¸Ð²Ð°Ð´Ð·Ð°ÐºÐ¸,Kashiwazaki", :latitude => "37.36667", :longitude => "138.55").save
City.new(:country_id => "116", :name => "Kashiwa", :aliases => "Kashiwa,Kasiva,bai shi,gasiwa si,ÐÐ°ÑÐ¸Ð²Ð°,æå¸,ê°ìì ì,Kashiwa", :latitude => "35.85444", :longitude => "139.96889").save
City.new(:country_id => "116", :name => "Kashima", :aliases => "Kashima,Kasima,ÐÐ°ÑÐ¸Ð¼Ð°,Kashima", :latitude => "33.10611", :longitude => "130.09056").save
City.new(:country_id => "116", :name => "Kashihara-shi", :aliases => "Kashihara,Kashihara-shi,jiang yuan,jiang yuan shi,æ©¿å,æ©¿åå¸,Kashihara-shi", :latitude => "34.50896", :longitude => "135.7929").save
City.new(:country_id => "116", :name => "Kashihara", :aliases => "Kashihara,Kashiharacho,KashiharachÅ,Kashiwabara,Kashiwara,Kashihara", :latitude => "34.58333", :longitude => "135.61667").save
City.new(:country_id => "116", :name => "Kaseda", :aliases => ",Kaseda", :latitude => "31.41667", :longitude => "130.31667").save
City.new(:country_id => "116", :name => "Kasaoka", :aliases => "Kasaoka,Kasaoka", :latitude => "34.5", :longitude => "133.5").save
City.new(:country_id => "116", :name => "Kasamatsucho", :aliases => "Kasamatsu,Kasamatsucho,KasamatsuchÅ,KasamatsuchÅ", :latitude => "35.36667", :longitude => "136.76667").save
City.new(:country_id => "116", :name => "Kariya", :aliases => "Karija,Kariya,Kariya-cho,Kariya-chÅ,ÐÐ°ÑÐ¸Ñ,Kariya", :latitude => "34.98333", :longitude => "136.98333").save
City.new(:country_id => "116", :name => "Karatsu", :aliases => "Karacu,Karatsu,Karatu,Karatu Si,tang jin shi,ÐÐ°ÑÐ°ÑÑ,åæ´¥å¸,Karatsu", :latitude => "33.4425", :longitude => "129.96972").save
City.new(:country_id => "116", :name => "Kanzaki", :aliases => "Kanzaki,Kanzaki", :latitude => "33.3", :longitude => "130.36667").save
City.new(:country_id => "116", :name => "Kanuma", :aliases => "Kamima,Kanuma,lu zhao shi,ÐÐ°Ð½ÑÐ¼Ð°,é¹¿æ²¼å¸,Kanuma", :latitude => "36.55", :longitude => "139.73333").save
City.new(:country_id => "116", :name => "Kanoya", :aliases => "Kanoja,Kanoya,ganoya si,lu wu shi,ÐÐ°Ð½Ð¾Ñ,é¹¿å±å¸,ê°ë¸ì¼ ì,Kanoya", :latitude => "31.38333", :longitude => "130.85").save
City.new(:country_id => "116", :name => "Kanonji", :aliases => "Kannonji,Kannonzi,Kanonji,Kanonji-cho,Kanonji-chÅ,Kanonji", :latitude => "34.11667", :longitude => "133.65").save
City.new(:country_id => "116", :name => "Kannabe", :aliases => ",Kannabe", :latitude => "34.53333", :longitude => "133.38333").save
City.new(:country_id => "116", :name => "Kanie", :aliases => "Kanie,Kanie", :latitude => "35.13333", :longitude => "136.8").save
City.new(:country_id => "116", :name => "Kaneko", :aliases => ",Kaneko", :latitude => "36.4", :longitude => "139").save
City.new(:country_id => "116", :name => "Kanda", :aliases => "Kanda,Karita,ÐÐ°Ð½Ð´Ð°,Kanda", :latitude => "33.78333", :longitude => "130.98333").save
City.new(:country_id => "116", :name => "Kanazawa-shi", :aliases => "Canasava,Kanadzava,Kanazaua,Kanazawa,Kanazawa-shi,Kanazawa-si,KanazaÅ­a,ganajawa si,jin ze shi,ÐÐ°Ð½Ð°Ð´Ð·Ð°Ð²Ð°,ããªããã,éæ²¢å¸,éæ¾¤å¸,ê°ëìì ì,Kanazawa-shi", :latitude => "36.59444", :longitude => "136.62556").save
City.new(:country_id => "116", :name => "Kanaya", :aliases => ",Kanaya", :latitude => "34.81667", :longitude => "138.13333").save
City.new(:country_id => "116", :name => "Kamojima", :aliases => "Kamojima,Kamoshima,Kamojima", :latitude => "34.06667", :longitude => "134.35").save
City.new(:country_id => "116", :name => "Kamogata", :aliases => "Kamogata,Kamokata,Kamogata", :latitude => "34.53333", :longitude => "133.58333").save
City.new(:country_id => "116", :name => "Kamo", :aliases => "Kamo,ÐÐ°Ð¼Ð¾,Kamo", :latitude => "37.65", :longitude => "139.05").save
City.new(:country_id => "116", :name => "Kami-renjaku", :aliases => "Kami-renjaku,Mitaka,Mitaka-machi,Mitaka-mura,ÐÐ¸ÑÐ°ÐºÐ°,Kami-renjaku", :latitude => "35.68333", :longitude => "139.55").save
City.new(:country_id => "116", :name => "Kaminokawa", :aliases => "Kaminokawa,Kaminokawa", :latitude => "36.43333", :longitude => "139.91667").save
City.new(:country_id => "116", :name => "Kamiichi", :aliases => "Kamiichi,Kamiichi", :latitude => "36.7", :longitude => "137.36667").save
City.new(:country_id => "116", :name => "Kameyama", :aliases => "Kameyama,Kameyama", :latitude => "34.85", :longitude => "136.45").save
City.new(:country_id => "116", :name => "Kameoka", :aliases => "Kameoka,ÐÐ°Ð¼ÐµÐ¾ÐºÐ°,Kameoka", :latitude => "35", :longitude => "135.58333").save
City.new(:country_id => "116", :name => "Kameda", :aliases => ",Kameda", :latitude => "37.86667", :longitude => "139.11667").save
City.new(:country_id => "116", :name => "Kamakura", :aliases => "Kamakura,gamakula si,kamakwra,lian cang shi,ÐÐ°Ð¼Ð°ÐºÑÑÐ°,ÙØ§ÙØ§ÙÙØ±Ø§,éåå¸,ê°ë§ì¿ ë¼ ì,Kamakura", :latitude => "35.30889", :longitude => "139.55028").save
City.new(:country_id => "116", :name => "Kakogawa", :aliases => "Kakogawa,gakogawa si,jia gu chuan shi,å å¤å·å¸,ê°ì½ê°ì ì,Kakogawa", :latitude => "34.76667", :longitude => "134.85").save
City.new(:country_id => "116", :name => "Kakegawa", :aliases => "Kakegawa,Kakehgava,gua chuan shi,ÐÐ°ÐºÑÐ³Ð°Ð²Ð°,æå·å¸,Kakegawa", :latitude => "34.76667", :longitude => "138.01667").save
City.new(:country_id => "116", :name => "Kakamigahara", :aliases => "Kagamigahara,Kagamihara,Kakamigahara,gakamigahala si,ge wu yuan shi,åååå¸,ê°ì¹´ë¯¸ê°íë¼ ì,Kakamigahara", :latitude => "35.41667", :longitude => "136.86667").save
City.new(:country_id => "116", :name => "Kashima-shi", :aliases => "Kashima,lu dao,lu dao shi,é¹¿å³¶,é¹¿å³¶å¸,é¹¿å¶,é¹¿å¶å¸,Kashima-shi", :latitude => "35.96536", :longitude => "140.64474").save
City.new(:country_id => "116", :name => "Kajiki", :aliases => "Kajiki-cho,Kajiki-chÅ,Kajiki", :latitude => "31.73333", :longitude => "130.66667").save
City.new(:country_id => "116", :name => "Kaizuka", :aliases => "Kaitsuka,Kaizuka,bei zhong shi,è²å¡å¸,Kaizuka", :latitude => "34.45", :longitude => "135.35").save
City.new(:country_id => "116", :name => "Kainan", :aliases => "Kainan,Kainan", :latitude => "34.15", :longitude => "135.2").save
City.new(:country_id => "116", :name => "Kagoshima-shi", :aliases => "Kagoshima,Kagoshima-shi,Kagosima,KagoÅ¡ima,gagosima si,kaghwshyma,lu r dao shi,ÐÐ°Ð³Ð¾ÑÐ¸Ð¼Ð°,ÙØ§ØºÙØ´ÙÙØ§,ãããã¾ã,é¹¿å¿å²å¸,é¹¿åå³¶å¸,ê°ê³ ìë§ ì,Kagoshima-shi", :latitude => "31.56018", :longitude => "130.55814").save
City.new(:country_id => "116", :name => "Kadoma", :aliases => "Kadoma,Kadome,men zhen shi,ÐÐ°Ð´Ð¾Ð¼Ðµ,éçå¸,Kadoma", :latitude => "34.73333", :longitude => "135.58333").save
City.new(:country_id => "116", :name => "Izumo", :aliases => "Idzumo,Itsumo,Izumo,ÐÐ´Ð·ÑÐ¼Ð¾,Izumo", :latitude => "35.36667", :longitude => "132.76667").save
City.new(:country_id => "116", :name => "Izumiotsu", :aliases => "Ebisucho,EbisuchÅ,Idzumotsu,Izumiotsu,IzumiÅtsu,Otsu,Åtsu,ÐÐ´Ð·ÑÐ¼Ð¾ÑÑÑ,IzumiÅtsu", :latitude => "34.5", :longitude => "135.4").save
City.new(:country_id => "116", :name => "Izumi", :aliases => ",Izumi", :latitude => "34.48333", :longitude => "135.43333").save
City.new(:country_id => "116", :name => "Izumi", :aliases => "Izumi,chu shui,ÐÐ·ÑÐ¼Ð¸,åºæ°´,Izumi", :latitude => "32.08333", :longitude => "130.36667").save
City.new(:country_id => "116", :name => "Iwatsuki", :aliases => "Iwatsuki,Iwatsuki", :latitude => "35.94278", :longitude => "139.69194").save
City.new(:country_id => "116", :name => "Iwata", :aliases => "Ivata,Iwata,pan tian,ÐÐ²Ð°ÑÐ°,ç£ç°,Iwata", :latitude => "34.7", :longitude => "137.85").save
City.new(:country_id => "116", :name => "Iwakura", :aliases => ",Iwakura", :latitude => "35.28333", :longitude => "136.86667").save
City.new(:country_id => "116", :name => "Iwakuni", :aliases => "Ivakuni,Iwakuni,ÐÐ²Ð°ÐºÑÐ½Ð¸,Iwakuni", :latitude => "34.15", :longitude => "132.18333").save
City.new(:country_id => "116", :name => "Iwai", :aliases => ",Iwai", :latitude => "36.05", :longitude => "139.9").save
City.new(:country_id => "116", :name => "Iwade", :aliases => "Iwade,Iwade", :latitude => "34.25", :longitude => "135.31667").save
City.new(:country_id => "116", :name => "Itsukaichi", :aliases => ",Itsukaichi", :latitude => "35.72528", :longitude => "139.21778").save
City.new(:country_id => "116", :name => "Itoman", :aliases => "Ichuman,Itoman,mi man,ç³¸æº,Itoman", :latitude => "26.12472", :longitude => "127.66944").save
City.new(:country_id => "116", :name => "Itoigawa", :aliases => "Itoigawa,Itoikawa,Itoigawa", :latitude => "37.03333", :longitude => "137.85").save
City.new(:country_id => "116", :name => "Ito", :aliases => "Ito,ItÅ,yi dong shi,ÐÑÐ¾,ä¼æ±å¸,ItÅ", :latitude => "34.96667", :longitude => "139.08333").save
City.new(:country_id => "116", :name => "Itami", :aliases => "Itami,Itan,itami si,yi dan shi,ÐÑÐ°Ð¼Ð¸,ä¼ä¸¹å¸,ì´íë¯¸ ì,Itami", :latitude => "34.78427", :longitude => "135.40126").save
City.new(:country_id => "116", :name => "Ishiki", :aliases => "Ishiki,Isshiki,Ishiki", :latitude => "34.8", :longitude => "137.01667").save
City.new(:country_id => "116", :name => "Ishikawa", :aliases => "Ishikawa,Ishiza,Isikava,ÐÑÐ¸ÐºÐ°Ð²Ð°,Ishikawa", :latitude => "26.42333", :longitude => "127.82139").save
City.new(:country_id => "116", :name => "Ishii", :aliases => "Ishii,Isii,ÐÑÐ¸Ð¸,Ishii", :latitude => "34.06667", :longitude => "134.43333").save
City.new(:country_id => "116", :name => "Ishige", :aliases => "Ishige,Moto-ishige,Ishige", :latitude => "36.11667", :longitude => "139.96667").save
City.new(:country_id => "116", :name => "Ishigaki", :aliases => "Ishigachi,Ishigaki,Isigaki,Shika,ishigaki,shi yuan,ÐÑÐ¸Ð³Ð°ÐºÐ¸,ãããã,ç³å£,Ishigaki", :latitude => "24.34478", :longitude => "124.15717").save
City.new(:country_id => "116", :name => "Isesaki", :aliases => "Isesaki,Isezaki,Isesaki", :latitude => "36.31667", :longitude => "139.2").save
City.new(:country_id => "116", :name => "Isehara", :aliases => "Isehara,Isehara", :latitude => "35.39056", :longitude => "139.30778").save
City.new(:country_id => "116", :name => "Ise", :aliases => "Ise,Iseh,Udiyamada,Uji,Uji-Yamada,Uziyamada,Yamada,ÐÑÑ,Ise", :latitude => "34.48333", :longitude => "136.7").save
City.new(:country_id => "116", :name => "Isawa", :aliases => ",Isawa", :latitude => "35.65", :longitude => "138.63333").save
City.new(:country_id => "116", :name => "Isahaya", :aliases => "Isahara,Isahaya,jian zao shi,è««æ©å¸,Isahaya", :latitude => "32.84111", :longitude => "130.04306").save
City.new(:country_id => "116", :name => "Inuyama", :aliases => "Inujama,Inuyama,Inuyama-cho,Inuyama-chÅ,quan shan shi,ÐÐ½ÑÑÐ¼Ð°,ç¬å±±å¸,Inuyama", :latitude => "35.37995", :longitude => "136.94295").save
City.new(:country_id => "116", :name => "Ino", :aliases => "Ino,Inocho,InochÅ,ÐÐ½Ð¾,Ino", :latitude => "33.55", :longitude => "133.43333").save
City.new(:country_id => "116", :name => "Innoshima", :aliases => ",Innoshima", :latitude => "34.28333", :longitude => "133.18333").save
City.new(:country_id => "116", :name => "Inazawa", :aliases => "Inasawa,Inasawacho,InasawachÅ,Inazawa,Inazawacho,InazawachÅ,Inazawa", :latitude => "35.25", :longitude => "136.78333").save
City.new(:country_id => "116", :name => "Ina", :aliases => "Ina,yi na shi,ÐÐ½Ð°,ä¼é£å¸,Ina", :latitude => "35.82756", :longitude => "137.95378").save
City.new(:country_id => "116", :name => "Imari", :aliases => "Imari,Imarimachi,ÐÐ¼Ð°ÑÐ¸,Imari", :latitude => "33.26667", :longitude => "129.88333").save
City.new(:country_id => "116", :name => "Imaichi", :aliases => ",Imaichi", :latitude => "36.71667", :longitude => "139.68333").save
City.new(:country_id => "116", :name => "Ikoma", :aliases => "Ikoma,Ikuma,ÐÐºÐ¾Ð¼Ð°,Ikoma", :latitude => "34.68333", :longitude => "135.7").save
City.new(:country_id => "116", :name => "Ikeda", :aliases => "Ikeda,chi tian,chi tian shi,ÐÐºÐµÐ´Ð°,æ± ç°,æ± ç°å¸,Ikeda", :latitude => "34.82208", :longitude => "135.4298").save
City.new(:country_id => "116", :name => "Ikeda", :aliases => ",Ikeda", :latitude => "34.01667", :longitude => "133.8").save
City.new(:country_id => "116", :name => "Ijuin", :aliases => "Ijuin,IjÅ«in,Izyuin,IzyÅ«in,IjÅ«in", :latitude => "31.61667", :longitude => "130.4").save
City.new(:country_id => "116", :name => "Iizuka", :aliases => "Iidzuka,Iizuka,ÐÐ¸Ð´Ð·ÑÐºÐ°,Iizuka", :latitude => "33.63333", :longitude => "130.68333").save
City.new(:country_id => "116", :name => "Iiyama", :aliases => "Iiyama,Iyama,Iiyama", :latitude => "36.85", :longitude => "138.36667").save
City.new(:country_id => "116", :name => "Iida", :aliases => "Iida,ÐÐ¸Ð´Ð°,Iida", :latitude => "35.51965", :longitude => "137.82074").save
City.new(:country_id => "116", :name => "Iga", :aliases => "Iga-shi,Igano-kuni,yi he,yi he shi,ä¼è³,ä¼è³å¸,Iga", :latitude => "34.76855", :longitude => "136.13013").save
City.new(:country_id => "116", :name => "Ichinomiya", :aliases => "Ichinomiya,Itinomiya,Owari-ichinomiya,ichinomiya si,yi gong shi,ä¸å®®å¸,ì´ì¹ë¸ë¯¸ì¼ ì,Ichinomiya", :latitude => "35.3", :longitude => "136.8").save
City.new(:country_id => "116", :name => "Ichikawa", :aliases => "Ichikawa,Itikava,ichikawa si,shi chuan shi,ÐÑÐ¸ÐºÐ°Ð²Ð°,å¸å·å¸,ì´ì¹ì¹´ì ì,Ichikawa", :latitude => "35.71972", :longitude => "139.92472").save
City.new(:country_id => "116", :name => "Ibusuki", :aliases => ",Ibusuki", :latitude => "31.23333", :longitude => "130.65").save
City.new(:country_id => "116", :name => "Ibaraki", :aliases => "Ibaragi,Ibaraki,ci cheng shi,ci mu,ci mu shi,ÐÐ±Ð°ÑÐ°ÐºÐ¸,è¨åå¸,è¨æ¨,è¨æ¨å¸,Ibaraki", :latitude => "34.81641", :longitude => "135.56828").save
City.new(:country_id => "116", :name => "Ibara", :aliases => "Ibara,Ihara,Ibara", :latitude => "34.6", :longitude => "133.46667").save
City.new(:country_id => "116", :name => "Hotaka", :aliases => ",Hotaka", :latitude => "36.3396", :longitude => "137.88254").save
City.new(:country_id => "116", :name => "Honjo", :aliases => "Honjo,HonjÅ,HonjÅ", :latitude => "36.23333", :longitude => "139.18333").save
City.new(:country_id => "116", :name => "Hondo", :aliases => "Hondo,Khondo,Ð¥Ð¾Ð½Ð´Ð¾,Hondo", :latitude => "32.45", :longitude => "130.2").save
City.new(:country_id => "116", :name => "Hofu", :aliases => "Bofu,Bohu,BÅfu,BÅhu,Hofu,HÅfu,HÅfu", :latitude => "34.05", :longitude => "131.56667").save
City.new(:country_id => "116", :name => "Hitoyoshi", :aliases => "Hitoyoshi,Hitoyosi,Hitoyoshi", :latitude => "32.21667", :longitude => "130.75").save
City.new(:country_id => "116", :name => "Hita", :aliases => "Hida,Hita,Khity,Ð¥Ð¸ÑÑ,Hita", :latitude => "33.31667", :longitude => "130.93333").save
City.new(:country_id => "116", :name => "Hisai", :aliases => ",Hisai", :latitude => "34.66667", :longitude => "136.46667").save
City.new(:country_id => "116", :name => "Hiroshima-shi", :aliases => "Chirosima,Hiroshima,Hiroshima-shi,Hirosima,Hirosimo,Hiroxima - guang dao shi,Hiroxima - åºå³¶å¸,HiroÅimo,HiroÅima,HiroÅ¡ima,Khiroshima,Khirosima,canghwad hi roa chi ma,guang dao shi,hi ro chi ma,hilosima si,hiroshima,hirosima,hyrwshyma,hyrwsymh,Î§Î¹ÏÎ¿ÏÎ¯Î¼Î±,Ð¥Ð¸ÑÐ¾ÑÐ¸Ð¼Ð°,Ð¥Ð¸ÑÐ¾ÑÐ¸Ð¼Ð°,Ð¥ÑÑÐ¾ÑÑÐ¼Ð°,×××¨××©×××,ÙÙØ±ÙØ´ÙÙØ§,ÙÛØ±ÙØ´ÛÙØ§,à¤¹à¤¿à¤°à¥à¤¶à¤¿à¤®à¤¾,à¸à¸±à¸à¸«à¸§à¸±à¸à¸®à¸´à¹à¸£à¸°à¸à¸´à¸¡à¸°,à¸®à¸´à¹à¸£à¸à¸´à¸¡à¸²,á°áá áá¡ááá,á°áá áá¨ááá,ã²ããã¾ã,åºå³¶å¸,å»£å³¶å¸,íë¡ìë§ ì,Hiroshima-shi", :latitude => "34.39627", :longitude => "132.45937").save
City.new(:country_id => "116", :name => "Hiratsuka", :aliases => "Hiratsuka,Hiratuka,Khiracuka,ping zhong shi,Ð¥Ð¸ÑÐ°ÑÑÐºÐ°,å¹³å¡å¸,Hiratsuka", :latitude => "35.32306", :longitude => "139.34222").save
City.new(:country_id => "116", :name => "Hirata", :aliases => ",Hirata", :latitude => "35.43333", :longitude => "132.81667").save
City.new(:country_id => "116", :name => "Hirara", :aliases => "Hirara,Taira,Hirara", :latitude => "24.8", :longitude => "125.28333").save
City.new(:country_id => "116", :name => "Hirakata", :aliases => "Hirakata,hilakata si,hyrakata, awsaka,mei fang shi,ÙÙØ±Ø§ÙØ§ØªØ§Ø Ø£ÙØ³Ø§ÙØ§,ææ¹å¸,íë¼ì¹´í ì,Hirakata", :latitude => "34.81352", :longitude => "135.64914").save
City.new(:country_id => "116", :name => "Hirado", :aliases => "Hirado,Hirato,Khirado,Ð¥Ð¸ÑÐ°Ð´Ð¾,Hirado", :latitude => "33.35972", :longitude => "129.55306").save
City.new(:country_id => "116", :name => "Hino", :aliases => "Hino,Hino", :latitude => "35.67306", :longitude => "139.40028").save
City.new(:country_id => "116", :name => "Hino", :aliases => ",Hino", :latitude => "35", :longitude => "136.25").save
City.new(:country_id => "116", :name => "Himi", :aliases => "Himi,Khimi,bing jian,Ð¥Ð¸Ð¼Ð¸,æ°·è¦,Himi", :latitude => "36.85", :longitude => "136.98333").save
City.new(:country_id => "116", :name => "Himeji", :aliases => "Hime,Himedi,Himeji,Himezi,Khimehdzi,himeji si,hymyjy,ji lu shi,Ð¥Ð¸Ð¼ÑÐ´Ð·Ð¸,ÙÙÙÙØ¬Ù,å§«è·¯å¸,íë©ì§ ì,Himeji", :latitude => "34.81667", :longitude => "134.7").save
City.new(:country_id => "116", :name => "Hikone", :aliases => "Hikone,Khikoneh,yan gen shi,Ð¥Ð¸ÐºÐ¾Ð½Ñ,å½¦æ ¹å¸,Hikone", :latitude => "35.25", :longitude => "136.25").save
City.new(:country_id => "116", :name => "Hiji", :aliases => "Higi,Hiji,Hinode,Hizi,Hiji", :latitude => "33.36667", :longitude => "131.53333").save
City.new(:country_id => "116", :name => "Hekinan", :aliases => "Hekinan,bi nan shi,ç¢§åå¸,Hekinan", :latitude => "34.88333", :longitude => "136.98333").save
City.new(:country_id => "116", :name => "Hayama", :aliases => "Hayama,Khajama,Ð¥Ð°ÑÐ¼Ð°,Hayama", :latitude => "35.26667", :longitude => "139.58333").save
City.new(:country_id => "116", :name => "Hatsukaichi", :aliases => "Hatsukaichi,Hatukaiti,hasseukaichi si,nian ri shi shi,å»¿æ¥å¸å¸,íì°ì¹´ì´ì¹ ì,Hatsukaichi", :latitude => "34.35", :longitude => "132.33333").save
City.new(:country_id => "116", :name => "Hatogaya", :aliases => "Hatagayacho,HatagayachÅ,Hatogaya,Hatogayamachi,Hatogaya", :latitude => "35.83417", :longitude => "139.73639").save
City.new(:country_id => "116", :name => "Hashimoto", :aliases => "Hashimoto,Hasimoto,Khasimoto,Ð¥Ð°ÑÐ¸Ð¼Ð¾ÑÐ¾,Hashimoto", :latitude => "34.31667", :longitude => "135.61667").save
City.new(:country_id => "116", :name => "Hanyu", :aliases => "Hanyu,HanyÅ«,Khan'juj,Ð¥Ð°Ð½ÑÑÐ¹,HanyÅ«", :latitude => "36.16667", :longitude => "139.53333").save
City.new(:country_id => "116", :name => "Hanno", :aliases => "Hanno,HannÅ,Khanno,Ð¥Ð°Ð½Ð½Ð¾,HannÅ", :latitude => "35.85194", :longitude => "139.31806").save
City.new(:country_id => "116", :name => "Handa", :aliases => "Handa,Khanda,Manda,ban tian shi,Ð¥Ð°Ð½Ð´Ð°,åç°å¸,Handa", :latitude => "34.88333", :longitude => "136.93333").save
City.new(:country_id => "116", :name => "Hamanoichi", :aliases => "Hama-no-iti,Hamanoichi,Hayato,Hamanoichi", :latitude => "31.71667", :longitude => "130.73333").save
City.new(:country_id => "116", :name => "Hamamatsu", :aliases => "Hamamacu,Hamamatsu,Hamamatu,bang song shi,bin song shi,hamamasseu si,æµæ¾å¸,æ»¨æ¾å¸,íë§ë§ì° ì,Hamamatsu", :latitude => "34.7", :longitude => "137.73333").save
City.new(:country_id => "116", :name => "Hamakita", :aliases => ",Hamakita", :latitude => "34.8", :longitude => "137.78333").save
City.new(:country_id => "116", :name => "Hamada", :aliases => "Hamada,Khamada,Ð¥Ð°Ð¼Ð°Ð´Ð°,Hamada", :latitude => "34.88333", :longitude => "132.08333").save
City.new(:country_id => "116", :name => "Hakui", :aliases => "Hagui,Hakui,Hakui", :latitude => "36.88333", :longitude => "136.78333").save
City.new(:country_id => "116", :name => "Haibara", :aliases => "Hagihara,Hagiwara,Haibara,Haibara", :latitude => "34.53333", :longitude => "135.95").save
City.new(:country_id => "116", :name => "Hagi", :aliases => ",Hagi", :latitude => "34.4", :longitude => "131.41667").save
City.new(:country_id => "116", :name => "Haebaru", :aliases => "Haebaru,Hiebaru,Haebaru", :latitude => "26.33694", :longitude => "127.87194").save
City.new(:country_id => "116", :name => "Hadano", :aliases => "Hadano,Hatano,Hatano-machi,hadano si,qin ye shi,ç§¦éå¸,íë¤ë¸ ì,Hadano", :latitude => "35.37111", :longitude => "139.22361").save
City.new(:country_id => "116", :name => "Hachioji", :aliases => "Hachioji,HachiÅji,Hatiozi,HatiÃ´zi,Khatiodzi,ba wang zi shi,hachioji si,Ð¥Ð°ÑÐ¸Ð¾Ð´Ð·Ð¸,å«çå­å¸,íì¹ì¤ì§ ì,HachiÅji", :latitude => "35.65583", :longitude => "139.32389").save
City.new(:country_id => "116", :name => "Omihachiman", :aliases => "Omihachiman-shi,jin jiang ba fan,jin jiang ba fan shi,Åmihachiman-shi,è¿æ±å«å¹¡,è¿æ±å«å¹¡å¸,Åmihachiman", :latitude => "35.12861", :longitude => "136.0976").save
City.new(:country_id => "116", :name => "Gyoda", :aliases => "Gyoda,GyÅda,GyÅda", :latitude => "36.13333", :longitude => "139.45").save
City.new(:country_id => "116", :name => "Gushikawa", :aliases => "Geshicha,GeshichÄ,Gushichaa,Gushikawa,Gusikawa,Gushikawa", :latitude => "26.35444", :longitude => "127.86861").save
City.new(:country_id => "116", :name => "Gotsu", :aliases => "Gatsu,Gotsu,Gotu,Gozu,GÅtsu,GÅtu,GÅzu,GÅtsu", :latitude => "35", :longitude => "132.21667").save
City.new(:country_id => "116", :name => "Gotemba", :aliases => "Gotemba,Kyu-gotemba,KyÅ«-gotemba,ÐÐ¾ÑÐµÐ¼Ð±Ð°,Gotemba", :latitude => "35.3", :longitude => "138.93333").save
City.new(:country_id => "116", :name => "Gosen", :aliases => "Gosen,ÐÐ¾ÑÐµÐ½,Gosen", :latitude => "37.73333", :longitude => "139.16667").save
City.new(:country_id => "116", :name => "Gose", :aliases => "Gose,Gosecho,Gosho,Goze,GÅsechÅ,Gose", :latitude => "34.45", :longitude => "135.73333").save
City.new(:country_id => "116", :name => "Gojo", :aliases => "Goio,GoiÅ,Gojo,GojÅ,GojÅ", :latitude => "34.35", :longitude => "135.7").save
City.new(:country_id => "116", :name => "Godo", :aliases => "Goda,Godo,Godo-cho,GÅdo,GÅdÅ-chÅ,ÐÐ¾Ð´Ð°,GÅdo", :latitude => "35.41667", :longitude => "136.6").save
City.new(:country_id => "116", :name => "Gobo", :aliases => "Gobo,GobÅ,Hidaka,ÐÐ¾Ð±Ð¾,GobÅ", :latitude => "33.88333", :longitude => "135.15").save
City.new(:country_id => "116", :name => "Ginowan", :aliases => "Chinon,ChinÅn,Ginowan,Jinon,JinÅn,ginowan,ginowan si,yi ye wan,yi ye wan shi,ãã®ãã,å®éæ¹¾,å®éæ¹¾å¸,å®éç£å¸,ê¸°ë¸ì ì,Ginowan", :latitude => "26.26265", :longitude => "127.76147").save
City.new(:country_id => "116", :name => "Gifu-shi", :aliases => "Gifu,Gifu-shi,Gihu,gihu si,qi fu shi,ÐÐ¸ÑÑ,ããµã,å²éå¸,ê¸°í ì,Gifu-shi", :latitude => "35.42291", :longitude => "136.76039").save
City.new(:country_id => "116", :name => "Gamagori", :aliases => ",GamagÅri", :latitude => "34.83333", :longitude => "137.23333").save
City.new(:country_id => "116", :name => "Futtsu", :aliases => "Futtso,Futtsu,Futtsu", :latitude => "35.30528", :longitude => "139.81861").save
City.new(:country_id => "116", :name => "Funabashi", :aliases => "Funabashi,Furabeshi,Hunabasi,chuan qiao shi,è¹æ©å¸,Funabashi", :latitude => "35.69306", :longitude => "139.98333").save
City.new(:country_id => "116", :name => "Fukuyama", :aliases => "Fukujama,Fukuyama,Hukuyama,Ð¤ÑÐºÑÑÐ¼Ð°,Fukuyama", :latitude => "34.48333", :longitude => "133.36667").save
City.new(:country_id => "116", :name => "Fukuroi", :aliases => "Fukuroi,dai jing shi,Ð¤ÑÐºÑÑÐ¾Ð¸,è¢äºå¸,Fukuroi", :latitude => "34.75", :longitude => "137.91667").save
City.new(:country_id => "116", :name => "Fukura", :aliases => "Fukura,Hukura,Fukura", :latitude => "34.25", :longitude => "134.71667").save
City.new(:country_id => "116", :name => "Fukuoka-shi", :aliases => "Fucuoca,Fukuoka,Fukuoka-shi,Hukuoka,fu gang shi,fwkwka,hukuoka si,Ð¤ÑÐºÑÐ¾ÐºÐ°,ÙÙÙÙÙØ§,ãµãããã,ç¦å²¡å¸,íì¿ ì¤ì¹´ ì,Fukuoka-shi", :latitude => "33.60639", :longitude => "130.41806").save
City.new(:country_id => "116", :name => "Fukumitsu", :aliases => "Fukumitsu,Fukumitsumachi,Fukumitsu", :latitude => "36.55", :longitude => "136.86667").save
City.new(:country_id => "116", :name => "Fukuma", :aliases => ",Fukuma", :latitude => "33.76667", :longitude => "130.46667").save
City.new(:country_id => "116", :name => "Fukui-shi", :aliases => "Fukui-shi,Fukuj,Hukui,Ð¤ÑÐºÑÐ¹,ãµããã,ç¦äºå¸,Fukui-shi", :latitude => "36.06443", :longitude => "136.22257").save
City.new(:country_id => "116", :name => "Fukue", :aliases => "Fukae,Fukaye,Fukue,Fukuego,Hukae,Hukue,Fukue", :latitude => "32.68806", :longitude => "128.84194").save
City.new(:country_id => "116", :name => "Fukuchiyama", :aliases => "Fukuchiyama,Hukutiyama,fu zhi shan shi,ç¦ç¥å±±å¸,Fukuchiyama", :latitude => "35.3", :longitude => "135.11667").save
City.new(:country_id => "116", :name => "Fukiage", :aliases => "Fukiage,Fukiage", :latitude => "36.1", :longitude => "139.45").save
City.new(:country_id => "116", :name => "Fukaya", :aliases => "Fukaya,Fukaya", :latitude => "36.2", :longitude => "139.28333").save
City.new(:country_id => "116", :name => "Fujisawa", :aliases => ",Fujisawa", :latitude => "35.34194", :longitude => "139.47").save
City.new(:country_id => "116", :name => "Fujioka", :aliases => "Fudzioka,Fujioka,Ð¤ÑÐ´Ð·Ð¸Ð¾ÐºÐ°,Fujioka", :latitude => "36.25", :longitude => "139.65").save
City.new(:country_id => "116", :name => "Fujioka", :aliases => "Fudzioka,Fujioka,Ð¤ÑÐ´Ð·Ð¸Ð¾ÐºÐ°,Fujioka", :latitude => "36.25", :longitude => "139.08333").save
City.new(:country_id => "116", :name => "Fujinomiya", :aliases => "Fujimiya,Fujinomiya,Omiya,fu shi gong shi,Åmiya,å¯å£«å®®å¸,Fujinomiya", :latitude => "35.21667", :longitude => "138.61667").save
City.new(:country_id => "116", :name => "Fujieda", :aliases => "Fudziehda,Fujieda,teng zhi shi,Ð¤ÑÐ´Ð·Ð¸ÑÐ´Ð°,è¤æå¸,Fujieda", :latitude => "34.86667", :longitude => "138.26667").save
City.new(:country_id => "116", :name => "Fuji", :aliases => "Fuji,Fuji", :latitude => "35.16667", :longitude => "138.68333").save
City.new(:country_id => "116", :name => "Fuchu", :aliases => "Fuchu,FuchÅ«,Ð¤ÑÑÑ,FuchÅ«", :latitude => "35.66667", :longitude => "139.48333").save
City.new(:country_id => "116", :name => "Fuchu", :aliases => "Fuchu,FuchÅ«,Ð¤ÑÑÑ,FuchÅ«", :latitude => "34.56667", :longitude => "133.23333").save
City.new(:country_id => "116", :name => "Enzan", :aliases => ",Enzan", :latitude => "35.7", :longitude => "138.73333").save
City.new(:country_id => "116", :name => "Daito", :aliases => ",DaitÅ", :latitude => "34.7", :longitude => "135.61667").save
City.new(:country_id => "116", :name => "Chofu", :aliases => "Chofu,ChÅfu,ChÅfu", :latitude => "35.65556", :longitude => "139.55222").save
City.new(:country_id => "116", :name => "Chiryu", :aliases => "Chiryu,Chiryu-cho,ChiryÅ«,ChiryÅ«-chÅ,ChiryÅ«", :latitude => "35", :longitude => "137.03333").save
City.new(:country_id => "116", :name => "Chino", :aliases => ",Chino", :latitude => "35.9944", :longitude => "138.15428").save
City.new(:country_id => "116", :name => "Chikushino-shi", :aliases => "chikushino,zhu zi ye,zhu zi ye shi,ç­ç´«é,ç­ç´«éå¸,Chikushino-shi", :latitude => "33.49631", :longitude => "130.5156").save
City.new(:country_id => "116", :name => "Chigasaki", :aliases => "Chigaraki,Chigasaki,mao~ke qi shi,èã¶å´å¸,Chigasaki", :latitude => "35.32611", :longitude => "139.40389").save
City.new(:country_id => "116", :name => "Chichibu", :aliases => "Chichibu,Titibu,Titubunomiya,Chichibu", :latitude => "35.99028", :longitude => "139.07639").save
City.new(:country_id => "116", :name => "Chatan", :aliases => "Chatan,Tyatan,Chatan", :latitude => "26.30944", :longitude => "127.77028").save
City.new(:country_id => "116", :name => "Beppu", :aliases => "Behppu,Beppu,ÐÑÐ¿Ð¿Ñ,Beppu", :latitude => "33.27361", :longitude => "131.49194").save
City.new(:country_id => "116", :name => "Ayabe", :aliases => "Ajabe,Ayabe,ÐÑÐ±Ðµ,Ayabe", :latitude => "35.3", :longitude => "135.25").save
City.new(:country_id => "116", :name => "Atami", :aliases => "Atami,ÐÑÐ°Ð¼Ð¸,Atami", :latitude => "35.08944", :longitude => "139.06861").save
City.new(:country_id => "116", :name => "Ashiya", :aliases => "Ashiya,lu wu shi,è¦å±å¸,Ashiya", :latitude => "34.72807", :longitude => "135.30264").save
City.new(:country_id => "116", :name => "Ashikaga", :aliases => "Ashikaga,Ashikaga - zu li shi,Ashikaga - è¶³å©å¸,Asikaga,zu li shi,ÐÑÐ¸ÐºÐ°Ð³Ð°,è¶³å©å¸,Ashikaga", :latitude => "36.33333", :longitude => "139.45").save
City.new(:country_id => "116", :name => "Arai", :aliases => ",Arai", :latitude => "37.01667", :longitude => "138.25").save
City.new(:country_id => "116", :name => "Annaka", :aliases => "Annaka,Annaka", :latitude => "36.31667", :longitude => "138.9").save
City.new(:country_id => "116", :name => "Anjo", :aliases => "Andzso,AndzsÃ³,Anjo,AnjÅ,Anziyan,an cheng,an cheng shi,å®å,å®åå¸,AnjÅ", :latitude => "34.95828", :longitude => "137.08054").save
City.new(:country_id => "116", :name => "Anan", :aliases => "Anan,ÐÐ½Ð°Ð½,Anan", :latitude => "33.91667", :longitude => "134.65").save
City.new(:country_id => "116", :name => "Amagi", :aliases => "Amagi,Amaki,Amagi", :latitude => "33.41667", :longitude => "130.65").save
City.new(:country_id => "116", :name => "Amagasaki", :aliases => "Amagasaki,ni qi shi,å°¼å´å¸,Amagasaki", :latitude => "34.71667", :longitude => "135.41667").save
City.new(:country_id => "116", :name => "Akune", :aliases => "a jiu gen,é¿ä¹æ ¹,Akune", :latitude => "32.01667", :longitude => "130.2").save
City.new(:country_id => "116", :name => "Ako", :aliases => "Akaho,Ako,AkÅ,Kariya,ÐÐºÐ¾,AkÅ", :latitude => "34.75", :longitude => "134.4").save
City.new(:country_id => "116", :name => "Aki", :aliases => "Aki,Akii,ÐÐºÐ¸,Aki", :latitude => "33.5", :longitude => "133.9").save
City.new(:country_id => "116", :name => "Aioi-shi", :aliases => "Aioi,Aioi-shi,O,Å,ããããã,ç¸çå¸,Aioi-shi", :latitude => "34.80361", :longitude => "134.46806").save
City.new(:country_id => "116", :name => "Ageo", :aliases => "Ageo,Ageomura,shang wei shi,ä¸å°¾å¸,Ageo", :latitude => "35.96972", :longitude => "139.58861").save
City.new(:country_id => "116", :name => "Okinawa", :aliases => "Okinava,Okinawa,chong sheng shi,okinawa si,ÐÐºÐ¸Ð½Ð°Ð²Ð°,æ²ç¸å¸,æ²ç¹©å¸,ì¤í¤ëì ì,Okinawa", :latitude => "26.33583", :longitude => "127.80139").save
City.new(:country_id => "116", :name => "Kushima", :aliases => ",Kushima", :latitude => "31.45833", :longitude => "131.23333").save
City.new(:country_id => "116", :name => "Hikari", :aliases => "Hikari,Khikari,Ð¥Ð¸ÐºÐ°ÑÐ¸,Hikari", :latitude => "33.955", :longitude => "131.95").save
City.new(:country_id => "116", :name => "Kaita", :aliases => "Kaita,Kejt,ÐÐµÐ¹Ñ,Kaita", :latitude => "34.36667", :longitude => "132.55").save
City.new(:country_id => "116", :name => "Nagato", :aliases => "Nagato,ÐÐ°Ð³Ð°ÑÐ¾,Nagato", :latitude => "34.38333", :longitude => "131.2").save
City.new(:country_id => "116", :name => "Hasuda", :aliases => "Hasuda,lian tian shi,è®ç°å¸,Hasuda", :latitude => "35.97556", :longitude => "139.65083").save
City.new(:country_id => "116", :name => "Kamifukuoka", :aliases => "Kamifukuoka,Kamifukuoka", :latitude => "35.8725", :longitude => "139.50972").save
City.new(:country_id => "116", :name => "Sayama", :aliases => "Irumagawa,Sajama,Sayama,sayama si,xia shan shi,Ð¡Ð°ÑÐ¼Ð°,ç­å±±å¸,ì¬ì¼ë§ ì,Sayama", :latitude => "35.85295", :longitude => "139.41212").save
City.new(:country_id => "116", :name => "Fussa", :aliases => "Fussa,fu sheng shi,ç¦çå¸,Fussa", :latitude => "35.73667", :longitude => "139.32361").save
City.new(:country_id => "116", :name => "Kunitachi", :aliases => "Kunitachi,guo li shi,å½ç«å¸,Kunitachi", :latitude => "35.67444", :longitude => "139.435").save
City.new(:country_id => "116", :name => "Asaka", :aliases => "Asaka,asaka si,chao xia shi,ÐÑÐ°ÐºÐ°,æéå¸,ìì¬ì¹´ ì,Asaka", :latitude => "35.80472", :longitude => "139.60194").save
City.new(:country_id => "116", :name => "Wako", :aliases => "Vako,Wako,ÐÐ°ÐºÐ¾,Wako", :latitude => "35.78944", :longitude => "139.62333").save
City.new(:country_id => "116", :name => "Toda", :aliases => "Toda,hu tian shi,Ð¢Ð¾Ð´Ð°,æ¸ç°å¸,Toda", :latitude => "35.80944", :longitude => "139.6925").save
City.new(:country_id => "116", :name => "Komae", :aliases => "Komae,po jiang shi,çæ±å¸,Komae", :latitude => "35.63639", :longitude => "139.57444").save
City.new(:country_id => "116", :name => "Kimitsu", :aliases => "Kimitsu,jun jin shi,åæ´¥å¸,Kimitsu", :latitude => "35.32528", :longitude => "139.89111").save
City.new(:country_id => "116", :name => "Miura", :aliases => "Miura,san pu,ÐÐ¸ÑÑÐ°,ä¸æµ¦,Miura", :latitude => "35.14", :longitude => "139.61917").save
City.new(:country_id => "116", :name => "Wakayama-shi", :aliases => "Vakajama,Wakayama,Wakayama-shi,ÐÐ°ÐºÐ°ÑÐ¼Ð°,ãããã¾ã,åæ­å±±å¸,Wakayama-shi", :latitude => "34.22611", :longitude => "135.1675").save
City.new(:country_id => "116", :name => "Iyo", :aliases => "Ie,Iyo,ÐÐµ,Iyo", :latitude => "33.75139", :longitude => "132.70139").save
City.new(:country_id => "116", :name => "Uwajima", :aliases => "Uwazima,Uwajima", :latitude => "33.22375", :longitude => "132.56001").save
City.new(:country_id => "116", :name => "Saijo", :aliases => "Saijo,SaijÅ,Saizyo,SaizyÃ´,SaijÅ", :latitude => "33.91667", :longitude => "133.18333").save
City.new(:country_id => "116", :name => "Ozu", :aliases => "Odzu,Osu,Ozu,Åsu,Åzu,ÐÐ´Ð·Ñ,Åzu", :latitude => "33.5", :longitude => "132.55").save
City.new(:country_id => "116", :name => "Matsuyama-shi", :aliases => "Macujama,Matsujamo,Matsuyama,Matsuyama-shi,Matuyama,masseuyama si,matswyama,song shan,song shan shi,ÙØ§ØªØ³ÙÙØ§ÙØ§,ã¾ã¤ãã¾ã,æ¾å±±,æ¾å±±å¸,ë§ì°ì¼ë§ ì,Matsuyama-shi", :latitude => "33.83916", :longitude => "132.76574").save
City.new(:country_id => "116", :name => "Masaki-cho", :aliases => "Masaki,song qian ting,æ¾åçº,Masaki-chÅ", :latitude => "33.78757", :longitude => "132.71124").save
City.new(:country_id => "116", :name => "Kawanoe", :aliases => "Kawanoe,Kawanoe", :latitude => "34.01667", :longitude => "133.56667").save
City.new(:country_id => "116", :name => "Hojo", :aliases => "Khodze,Ð¥Ð¾Ð´Ð·Ðµ,HÅjÅ", :latitude => "33.97661", :longitude => "132.77767").save
City.new(:country_id => "116", :name => "Yuzawa", :aliases => "Judzava,Yuzawa,Ð®Ð´Ð·Ð°Ð²Ð°,Yuzawa", :latitude => "39.16667", :longitude => "140.5").save
City.new(:country_id => "116", :name => "Yotsukaido", :aliases => ",YotsukaidÅ", :latitude => "35.65", :longitude => "140.16667").save
City.new(:country_id => "116", :name => "Yonezawa", :aliases => "Jonezava,Yonezawa,mi ze shi,ÐÐ¾Ð½ÐµÐ·Ð°Ð²Ð°,ç±³æ²¢å¸,Yonezawa", :latitude => "37.91667", :longitude => "140.11667").save
City.new(:country_id => "116", :name => "Yokote", :aliases => "Jokote,Yokote,Yokote", :latitude => "39.3", :longitude => "140.56667").save
City.new(:country_id => "116", :name => "Yokaichiba", :aliases => ",YÅkaichiba", :latitude => "35.7", :longitude => "140.55").save
City.new(:country_id => "116", :name => "Yanagawa", :aliases => "Janagava,Yanagawa,Yanakawa,Ð¯Ð½Ð°Ð³Ð°Ð²Ð°,Yanagawa", :latitude => "37.85", :longitude => "140.6").save
City.new(:country_id => "116", :name => "Yamoto", :aliases => ",Yamoto", :latitude => "38.41667", :longitude => "141.21667").save
City.new(:country_id => "116", :name => "Yamagata-shi", :aliases => "Jamagata,Yamagata-shi,shan xing,Ð¯Ð¼Ð°Ð³Ð°ÑÐ°,ãã¾ããã,å±±å½¢,å±±å½¢å¸,Yamagata-shi", :latitude => "38.24056", :longitude => "140.36333").save
City.new(:country_id => "116", :name => "Yamada", :aliases => "Jamada,Yamada,Yamatamachi,Ð¯Ð¼Ð°Ð´Ð°,Yamada", :latitude => "39.46667", :longitude => "141.95").save
City.new(:country_id => "116", :name => "Yachimata", :aliases => "Yachimata,ba jie shi,å«è¡å¸,Yachimata", :latitude => "35.65", :longitude => "140.31667").save
City.new(:country_id => "116", :name => "Watari", :aliases => "Vatari,Watari,ÐÐ°ÑÐ°ÑÐ¸,Watari", :latitude => "38.035", :longitude => "140.85111").save
City.new(:country_id => "116", :name => "Wakuya", :aliases => "Wakuya,Wakuya", :latitude => "38.53333", :longitude => "141.13333").save
City.new(:country_id => "116", :name => "Ushiku", :aliases => "Ushiku,niu jiu,çä¹,Ushiku", :latitude => "35.96667", :longitude => "140.13333").save
City.new(:country_id => "116", :name => "Tsukuba", :aliases => ",Tsukuba", :latitude => "36.2", :longitude => "140.1").save
City.new(:country_id => "116", :name => "Toride", :aliases => "Toride,Torite,åæ,Toride", :latitude => "35.9", :longitude => "140.08333").save
City.new(:country_id => "116", :name => "Tono", :aliases => "Nambu,Tona,Tono,TÅno,Ð¢Ð¾Ð½Ð°,TÅno", :latitude => "39.31667", :longitude => "141.53333").save
City.new(:country_id => "116", :name => "Tomobe", :aliases => ",Tomobe", :latitude => "36.35", :longitude => "140.3").save
City.new(:country_id => "116", :name => "Tomiya", :aliases => "Tomiya,Tomiya", :latitude => "38.39306", :longitude => "140.88611").save
City.new(:country_id => "116", :name => "Togane", :aliases => "Togane,Toganemachi,TÅgane,TÅganemachi,TÅgane", :latitude => "35.55", :longitude => "140.36667").save
City.new(:country_id => "116", :name => "Tendo", :aliases => "Tendo,TendÅ,Ð¢ÐµÐ½Ð´Ð¾,TendÅ", :latitude => "38.35361", :longitude => "140.36972").save
City.new(:country_id => "116", :name => "Takahata", :aliases => "Takahata,Takakhata,Ð¢Ð°ÐºÐ°ÑÐ°ÑÐ°,Takahata", :latitude => "38.0025", :longitude => "140.19111").save
City.new(:country_id => "116", :name => "Takahagi", :aliases => "Takahagi,Takahagi", :latitude => "36.71667", :longitude => "140.71667").save
City.new(:country_id => "116", :name => "Sukagawa", :aliases => "Sukagawa,xu he chuan shi,é è³å·å¸,Sukagawa", :latitude => "37.28333", :longitude => "140.38333").save
City.new(:country_id => "116", :name => "Shizukuishi", :aliases => "Shizukuishi,Shizukuishi", :latitude => "39.68333", :longitude => "140.98333").save
City.new(:country_id => "116", :name => "Shisui", :aliases => "Shisui,Shisuimachi,Shusui,Shisui", :latitude => "35.71667", :longitude => "140.26667").save
City.new(:country_id => "116", :name => "Shiroishi", :aliases => "Shiroishi,Siroisi,Shiroishi", :latitude => "38.00333", :longitude => "140.61833").save
City.new(:country_id => "116", :name => "Shiroi", :aliases => "Shiroi,Shiroi", :latitude => "35.8", :longitude => "140.06667").save
City.new(:country_id => "116", :name => "Shiogama", :aliases => "Schiogama,Shiogama,Siogama,yan zao,Ð¡Ð¸Ð¾Ð³Ð°Ð¼Ð°,å¡©ç«,Shiogama", :latitude => "38.31667", :longitude => "141.03333").save
City.new(:country_id => "116", :name => "Shinjo", :aliases => "Shinjo,ShinjÅ,Sindscho,Sindze,Sinzyo,Ð¡Ð¸Ð½Ð´Ð·Ðµ,ShinjÅ", :latitude => "38.75861", :longitude => "140.30083").save
City.new(:country_id => "116", :name => "Sendai-shi", :aliases => "Sendai-shi,Sendaj,xian tai,Ð¡ÐµÐ½Ð´Ð°Ð¹,ããã ãã,ä»å°,ä»å°å¸,Sendai-shi", :latitude => "38.26889", :longitude => "140.87194").save
City.new(:country_id => "116", :name => "Sawara", :aliases => "Sawara,Sawara", :latitude => "35.88333", :longitude => "140.5").save
City.new(:country_id => "116", :name => "Sakura", :aliases => "Sakura,Ð¡Ð°ÐºÑÑÐ°,Sakura", :latitude => "35.71667", :longitude => "140.23333").save
City.new(:country_id => "116", :name => "Sagae", :aliases => "Sagae,Sagae", :latitude => "38.3725", :longitude => "140.2725").save
City.new(:country_id => "116", :name => "Ryugasaki", :aliases => "Ryugasaki,RyÅ«gasaki,RyÅ«gasaki", :latitude => "35.9", :longitude => "140.18333").save
City.new(:country_id => "116", :name => "Rifu", :aliases => "Rifu,Rifuhongo,RifuhongÅ,Ritu,Rifu", :latitude => "38.32361", :longitude => "140.97444").save
City.new(:country_id => "116", :name => "Otsuchi", :aliases => "Otsuchi,Ozuchi,Ozuti,Åtsuchi,Åtsuchi", :latitude => "39.36667", :longitude => "141.9").save
City.new(:country_id => "116", :name => "Otawara", :aliases => "Otahara,Otawara,Åtawara,Åtawara", :latitude => "36.86667", :longitude => "140.03333").save
City.new(:country_id => "116", :name => "Omiya", :aliases => ",Åmiya", :latitude => "36.55", :longitude => "140.41667").save
City.new(:country_id => "116", :name => "Omigawa", :aliases => "Omigawa,Omikawa,Omigawa", :latitude => "35.85", :longitude => "140.61667").save
City.new(:country_id => "116", :name => "Omagari", :aliases => ",Åmagari", :latitude => "39.45", :longitude => "140.48333").save
City.new(:country_id => "116", :name => "Okunoya", :aliases => ",Okunoya", :latitude => "36.28333", :longitude => "140.41667").save
City.new(:country_id => "116", :name => "Okawara", :aliases => "Ogawara,Okawara,Åkawara,Åkawara", :latitude => "38.05", :longitude => "140.73361").save
City.new(:country_id => "116", :name => "Ohara", :aliases => ",Åhara", :latitude => "35.25", :longitude => "140.38333").save
City.new(:country_id => "116", :name => "Ofunato", :aliases => "Ofunato,da chuan du,Åfunato,å¤§è¹æ¸¡,Åfunato", :latitude => "39.07167", :longitude => "141.71667").save
City.new(:country_id => "116", :name => "Obanazawa", :aliases => "Obanasawa,Obanazawa,Obanazawa", :latitude => "38.60333", :longitude => "140.40194").save
City.new(:country_id => "116", :name => "Oarai", :aliases => "Oarai,da xi,Åarai,å¤§æ´,Åarai", :latitude => "36.31667", :longitude => "140.6").save
City.new(:country_id => "116", :name => "Oami", :aliases => ",Åami", :latitude => "35.51667", :longitude => "140.31667").save
City.new(:country_id => "116", :name => "Nihommatsu", :aliases => "Nihommatsu,Nihonmatsu,Nihommatsu", :latitude => "37.58333", :longitude => "140.43333").save
City.new(:country_id => "116", :name => "Naruto", :aliases => ",NarutÅ", :latitude => "35.6", :longitude => "140.41667").save
City.new(:country_id => "116", :name => "Narita", :aliases => "Narita,cheng tian shi,na ri ta,nalita si,ÐÐ°ÑÐ¸ÑÐ°,à¸à¸²à¸£à¸´à¸à¸°,æç°å¸,ëë¦¬í ì,Narita", :latitude => "35.78333", :longitude => "140.31667").save
City.new(:country_id => "116", :name => "Narashino", :aliases => "Narashino,xi zhi ye shi,ç¿å¿éå¸,Narashino", :latitude => "35.68333", :longitude => "140.03333").save
City.new(:country_id => "116", :name => "Namie", :aliases => "Namie,Namie", :latitude => "37.48333", :longitude => "141").save
City.new(:country_id => "116", :name => "Naka", :aliases => "Naka,Nakamuracho,NakamurachÅ,Naka", :latitude => "36.05", :longitude => "140.16667").save
City.new(:country_id => "116", :name => "Nagai", :aliases => "Nagai,ÐÐ°Ð³Ð°Ð¸,Nagai", :latitude => "38.10361", :longitude => "140.035").save
City.new(:country_id => "116", :name => "Motomiya", :aliases => "Motomiya,Motomiya", :latitude => "37.51667", :longitude => "140.4").save
City.new(:country_id => "116", :name => "Motegi", :aliases => "Motegi,Motegi", :latitude => "36.51667", :longitude => "140.18333").save
City.new(:country_id => "116", :name => "Moriya", :aliases => "Morija,Moriya,ÐÐ¾ÑÐ¸Ñ,Moriya", :latitude => "35.93333", :longitude => "140").save
City.new(:country_id => "116", :name => "Morioka-shi", :aliases => "Morioka,Morioka-shi,molioka si,ÐÐ¾ÑÐ¸Ð¾ÐºÐ°,ããããã,çå²¡å¸,ëª¨ë¦¬ì¤ì¹´ ì,Morioka-shi", :latitude => "39.70361", :longitude => "141.1525").save
City.new(:country_id => "116", :name => "Mooka", :aliases => "Moka,Mooka,MÅka,zhen gang shi,çå²¡å¸,Mooka", :latitude => "36.43333", :longitude => "140.01667").save
City.new(:country_id => "116", :name => "Mobara", :aliases => "Mobara,Mobaramachi,Mohara,mao yuan shi,èåå¸,Mobara", :latitude => "35.41667", :longitude => "140.3").save
City.new(:country_id => "116", :name => "Mizusawa", :aliases => "Midzusava,Mizusawa,Mizuzawa,ÐÐ¸Ð´Ð·ÑÑÐ°Ð²Ð°,Mizusawa", :latitude => "39.13333", :longitude => "141.13333").save
City.new(:country_id => "116", :name => "Miyako", :aliases => "Mijako,Miyako,ÐÐ¸ÑÐºÐ¾,Miyako", :latitude => "39.63667", :longitude => "141.9525").save
City.new(:country_id => "116", :name => "Mito-shi", :aliases => "Mito-shi,ã¿ã¨ã,æ°´æ¸å¸,Mito-shi", :latitude => "36.34139", :longitude => "140.44667").save
City.new(:country_id => "116", :name => "Miharu", :aliases => "Miharu,Miharu", :latitude => "37.43333", :longitude => "140.48333").save
City.new(:country_id => "116", :name => "Matsushima", :aliases => "Macusima,Matsushima,Matsusima,song dao,ÐÐ°ÑÑÑÐ¸Ð¼Ð°,æ¾å³¶,Matsushima", :latitude => "38.36667", :longitude => "141.07167").save
City.new(:country_id => "116", :name => "Mashiko", :aliases => "Mashiko,yi zi,çå­,Mashiko", :latitude => "36.46667", :longitude => "140.1").save
City.new(:country_id => "116", :name => "Marumori", :aliases => "Marumori,Marumori", :latitude => "37.91667", :longitude => "140.76667").save
City.new(:country_id => "116", :name => "Makabe", :aliases => "Makabe,Makabe", :latitude => "36.26667", :longitude => "140.1").save
City.new(:country_id => "116", :name => "Kuroiso", :aliases => ",Kuroiso", :latitude => "36.96667", :longitude => "140.05").save
City.new(:country_id => "116", :name => "Koriyama", :aliases => "Korijama,Koriyama,KÅriyama,ÐÐ¾ÑÐ¸ÑÐ¼Ð°,KÅriyama", :latitude => "37.4", :longitude => "140.38333").save
City.new(:country_id => "116", :name => "Kogota", :aliases => "Kogota,Kogota", :latitude => "38.55", :longitude => "141.05").save
City.new(:country_id => "116", :name => "Kitakami", :aliases => "Kitakami,bei shang shi,ÐÐ¸ÑÐ°ÐºÐ°Ð¼Ð¸,åä¸å¸,Kitakami", :latitude => "39.28333", :longitude => "141.11667").save
City.new(:country_id => "116", :name => "Kitaibaraki", :aliases => "Kitaibaragi,Kitaibaraki,Kitaibaraki", :latitude => "36.78333", :longitude => "140.75").save
City.new(:country_id => "116", :name => "Kawaguchi", :aliases => "Kavaguti,Kawaguchi,ya chuan,ÐÐ°Ð²Ð°Ð³ÑÑÐ¸,é´¨å·,Kawaguchi", :latitude => "35.1", :longitude => "140.1").save
City.new(:country_id => "116", :name => "Katsuura", :aliases => "Kacuura,Katsuura,ÐÐ°ÑÑÑÑÐ°,Katsuura", :latitude => "35.13333", :longitude => "140.3").save
City.new(:country_id => "116", :name => "Katsuta", :aliases => ",Katsuta", :latitude => "36.38333", :longitude => "140.53333").save
City.new(:country_id => "116", :name => "Katori-shi", :aliases => "Katori,Sawara,Sawara-shi,xiang qu,xiang qu shi,zuo yuan shi,ä½åå¸,é¦å,é¦åå¸,Katori-shi", :latitude => "35.89767", :longitude => "140.49943").save
City.new(:country_id => "116", :name => "Kasama", :aliases => "Kasama,li jian,ÐÐ°ÑÐ°Ð¼Ð°,ç¬ é,Kasama", :latitude => "36.38333", :longitude => "140.26667").save
City.new(:country_id => "116", :name => "Karasuyama", :aliases => ",Karasuyama", :latitude => "36.65", :longitude => "140.15").save
City.new(:country_id => "116", :name => "Kaminoyama", :aliases => "Kaminoyama,Kaminoyama", :latitude => "38.15389", :longitude => "140.27361").save
City.new(:country_id => "116", :name => "Kamaishi", :aliases => "Kamaischi,Kamaishi,Kamaisi,fu shi,ÐÐ°Ð¼Ð°Ð¸ÑÐ¸,éç³,Kamaishi", :latitude => "39.26667", :longitude => "141.88333").save
City.new(:country_id => "116", :name => "Kakuda", :aliases => "Kakuda,Kakudskij,ÐÐ°ÐºÑÐ´ÑÐºÐ¸Ð¹,Kakuda", :latitude => "37.96667", :longitude => "140.78333").save
City.new(:country_id => "116", :name => "Iwase", :aliases => "Ivaseh,Iwase,ÐÐ²Ð°ÑÑ,Iwase", :latitude => "36.35", :longitude => "140.1").save
City.new(:country_id => "116", :name => "Iwanuma", :aliases => "Iwanuma,Iwanuma", :latitude => "38.10472", :longitude => "140.85944").save
City.new(:country_id => "116", :name => "Iwaki", :aliases => "Ivaki,Iwaki,ÐÐ²Ð°ÐºÐ¸,Iwaki", :latitude => "37.05", :longitude => "140.88333").save
City.new(:country_id => "116", :name => "Itako", :aliases => "Idako,Itako,Itako", :latitude => "35.93333", :longitude => "140.55").save
City.new(:country_id => "116", :name => "Ishioka", :aliases => "Ishioka,Isioka,ÐÑÐ¸Ð¾ÐºÐ°,Ishioka", :latitude => "36.18333", :longitude => "140.26667").save
City.new(:country_id => "116", :name => "Ishinomaki", :aliases => "Ishinomachi,Ishinomaki,Isinomaki,isinomaki si,shi juan shi,ç³å·»å¸,ì´ìë¸ë§í¤ ì,Ishinomaki", :latitude => "38.41667", :longitude => "141.3").save
City.new(:country_id => "116", :name => "Ishikawa", :aliases => "Ishikawa,Isikava,ÐÑÐ¸ÐºÐ°Ð²Ð°,Ishikawa", :latitude => "37.15", :longitude => "140.45").save
City.new(:country_id => "116", :name => "Inawashiro", :aliases => "Inawashiro,Inawashiro", :latitude => "37.56667", :longitude => "140.11667").save
City.new(:country_id => "116", :name => "Ichinoseki", :aliases => "Ichinoseki,Itinoseki,Itschinoseki,Ichinoseki", :latitude => "38.91667", :longitude => "141.13333").save
City.new(:country_id => "116", :name => "Ichihara", :aliases => "Ichihara,Itikhara,shi yuan shi,ÐÑÐ¸ÑÐ°ÑÐ°,å¸åå¸,Ichihara", :latitude => "35.51667", :longitude => "140.08333").save
City.new(:country_id => "116", :name => "Hobara", :aliases => "Hobara,Hobara", :latitude => "37.81667", :longitude => "140.55").save
City.new(:country_id => "116", :name => "Hitachi", :aliases => "Hidachi,Hitachi,ri li,æ¥ç«,Hitachi", :latitude => "36.6", :longitude => "140.65").save
City.new(:country_id => "116", :name => "Higashine", :aliases => "Higashine,Higashine", :latitude => "38.43889", :longitude => "140.40056").save
City.new(:country_id => "116", :name => "Hasaki", :aliases => "Hasaki,Hazaki,Namisaki,Hasaki", :latitude => "35.73333", :longitude => "140.83333").save
City.new(:country_id => "116", :name => "Hanamaki", :aliases => "Hanamaki,hua juan shi,è±å·»å¸,Hanamaki", :latitude => "39.38333", :longitude => "141.11667").save
City.new(:country_id => "116", :name => "Furukawa", :aliases => "Furukawa,Hurukawa,Furukawa", :latitude => "38.57167", :longitude => "140.95556").save
City.new(:country_id => "116", :name => "Funehiki", :aliases => "Funahiki,Funehiki,Funehiki", :latitude => "37.43333", :longitude => "140.58333").save
City.new(:country_id => "116", :name => "Funaishikawa", :aliases => "Funaishikawa,Tokai-mura,TÅkai-mura,Funaishikawa", :latitude => "36.46667", :longitude => "140.56667").save
City.new(:country_id => "116", :name => "Fukushima-shi", :aliases => "Fukushima-shi,Fukusima,Furukawa,Hukusima,Ð¤ÑÐºÑÑÐ¸Ð¼Ð°,ãµããã¾ã,ç¦å³¶å¸,Fukushima-shi", :latitude => "37.75", :longitude => "140.46778").save
City.new(:country_id => "116", :name => "Fujishiro", :aliases => ",Fujishiro", :latitude => "35.91667", :longitude => "140.11667").save
City.new(:country_id => "116", :name => "Edosaki", :aliases => "Edosaki,Edosaki", :latitude => "35.95", :longitude => "140.31667").save
City.new(:country_id => "116", :name => "Daigo", :aliases => "Daigo,ÐÐ°Ð¸Ð³Ð¾,Daigo", :latitude => "36.76667", :longitude => "140.35").save
City.new(:country_id => "116", :name => "Chiba-shi", :aliases => "Chiba,Chiba-shi,Ciba,Tiba,jiba si,qian ye shi,tshyba,Äiba,Äiba,Ð§Ð¸Ð±Ð°,ØªØ´ÙØ¨Ø§,ã¡ã°ã,åèå¸,ì§ë° ì,Chiba-shi", :latitude => "35.60472", :longitude => "140.12333").save
City.new(:country_id => "116", :name => "Asahi", :aliases => "Asahi,Asahi", :latitude => "35.71667", :longitude => "140.65").save
City.new(:country_id => "116", :name => "Ami", :aliases => "Ami,ÐÐ¼Ð¸,Ami", :latitude => "36.03333", :longitude => "140.2").save
City.new(:country_id => "116", :name => "Akita", :aliases => "Akita,Akita", :latitude => "39.71667", :longitude => "140.11667").save
City.new(:country_id => "116", :name => "Abiko", :aliases => "Abiko,wo sun zi shi,ÐÐ±Ð¸ÐºÐ¾,æå­«å­å¸,Abiko", :latitude => "35.86667", :longitude => "140.01667").save
City.new(:country_id => "116", :name => "Akita-shi", :aliases => "Akita-shi,ãããã,ç§ç°å¸,Akita-shi", :latitude => "39.71806", :longitude => "140.10333").save
City.new(:country_id => "116", :name => "Bihoro", :aliases => "Biboro,Biholo,Bihoro,Biporo,Bihoro", :latitude => "43.82278", :longitude => "144.10444").save
City.new(:country_id => "116", :name => "Wakkanai", :aliases => "Inai,VAKKANAJ,Vakkanaj,Wakkanai,waskanai si,zhi nei shi,ÐÐÐÐÐÐÐÐ,ÐÐ°ÐºÐºÐ°Ð½Ð°Ð¹,ç¨åå¸,ìì¹´ëì´ ì,Wakkanai", :latitude => "45.40944", :longitude => "141.67389").save
City.new(:country_id => "116", :name => "Tomakomai", :aliases => "Tomakomai,Tomakomaj,shan xiao mu,Ð¢Ð¾Ð¼Ð°ÐºÐ¾Ð¼Ð°Ð¹,è«å°ç§,Tomakomai", :latitude => "42.63694", :longitude => "141.60333").save
City.new(:country_id => "116", :name => "Tobetsu", :aliases => "Tobetsu,TÅbetsu,TÅbetsu", :latitude => "43.21694", :longitude => "141.51694").save
City.new(:country_id => "116", :name => "Mutsu", :aliases => "Mucu,Mutsu,Tanabe,Tanabu,mutsu,ÐÑÑÑ,ãã¤,Mutsu", :latitude => "41.28944", :longitude => "141.21694").save
City.new(:country_id => "116", :name => "Takikawa", :aliases => "Takigawa,Takikawa,Takikawa", :latitude => "43.55278", :longitude => "141.90639").save
City.new(:country_id => "116", :name => "Takanosu", :aliases => ",Takanosu", :latitude => "40.22194", :longitude => "140.36944").save
City.new(:country_id => "116", :name => "Sunagawa", :aliases => "Sunagawa,Sunakawa,Sunigawa,Sunagawa", :latitude => "43.48639", :longitude => "141.90556").save
City.new(:country_id => "116", :name => "Shizunai", :aliases => "Shimo geho,Shimo-kebo,Shimo-kebÅ,Shimo-keho,Shimo-kehÅ,Shizunai,Shizunai", :latitude => "42.33389", :longitude => "142.36694").save
City.new(:country_id => "116", :name => "Shiraoi", :aliases => "Shiraoi,Shiraoi", :latitude => "42.55", :longitude => "141.35").save
City.new(:country_id => "116", :name => "Shimo-furano", :aliases => "Shimo-furano,Shimo-furanoshigai,Shimo-furano", :latitude => "43.35", :longitude => "142.38333").save
City.new(:country_id => "116", :name => "Shibetsu", :aliases => "Sibetsu,Sibetu,Sipetu,biao jin,æ¨æ´¥,Shibetsu", :latitude => "43.65899", :longitude => "145.13197").save
City.new(:country_id => "116", :name => "Sapporo-shi", :aliases => "Saporas,Saporo,Sapporia,Sapporo,Sapporo-shi,capporo,sabwrw,sap poa roa,saspolo si,zha huang shi,Ð¡Ð°Ð¿Ð¾ÑÐ¾,Ð¡Ð°Ð¿Ð¿Ð¾ÑÐ¾,Ø³Ø§Ø¨ÙØ±Ù,à®à®ªà¯à®ªà¯à®°à¯,à¸à¸±à¸à¹à¸à¸°à¹à¸£à¸°,á¡áááá á,ãã£ã½ãã,æ­å¹å¸,ì¿í¬ë¡ ì,Sapporo-shi", :latitude => "43.06417", :longitude => "141.34694").save
City.new(:country_id => "116", :name => "Rumoi", :aliases => "Rumoe,Rumoi,Rumoi", :latitude => "43.93444", :longitude => "141.64278").save
City.new(:country_id => "116", :name => "Otofuke", :aliases => "Otopuke,Otofuke", :latitude => "42.99167", :longitude => "143.20028").save
City.new(:country_id => "116", :name => "Otaru", :aliases => "Otaru,otalu si,xiao zun shi,ÐÑÐ°ÑÑ,å°æ¨½å¸,ì¤íë£¨ ì,Otaru", :latitude => "43.18944", :longitude => "141.00222").save
City.new(:country_id => "116", :name => "Odate", :aliases => "Odate,Otate,Ådate,Åtate,Ådate", :latitude => "40.26861", :longitude => "140.56833").save
City.new(:country_id => "116", :name => "Obihiro", :aliases => "Obibiro,Obihiro,Obikhiro,dai guang,ÐÐ±Ð¸ÑÐ¸ÑÐ¾,å¸¯åº,Obihiro", :latitude => "42.91722", :longitude => "143.20444").save
City.new(:country_id => "116", :name => "Noshiro", :aliases => "Noshiro,Noshirominato,Nosiro,Nosirskij,ÐÐ¾ÑÐ¸ÑÑÐºÐ¸Ð¹,Noshiro", :latitude => "40.20389", :longitude => "140.02417").save
City.new(:country_id => "116", :name => "Nemuro", :aliases => "Nehmuro,Nemuro,gen shi shi,nemulo si,ÐÑÐ¼ÑÑÐ¾,æ ¹å®¤å¸,ë¤ë¬´ë¡ ì,Nemuro", :latitude => "43.32361", :longitude => "145.575").save
City.new(:country_id => "116", :name => "Nayoro", :aliases => "NAERO,Nayoro,Nayoru,ÐÐÐÐ Ð,Nayoro", :latitude => "44.35056", :longitude => "142.45778").save
City.new(:country_id => "116", :name => "Nanae", :aliases => "Nanae,Nanae", :latitude => "41.88333", :longitude => "140.68333").save
City.new(:country_id => "116", :name => "Namioka", :aliases => "Namioka,ÐÐ°Ð¼Ð¸Ð¾ÐºÐ°,Namioka", :latitude => "40.70722", :longitude => "140.58944").save
City.new(:country_id => "116", :name => "Muroran", :aliases => "Muroran,shi lan,ÐÑÑÐ¾ÑÐ°Ð½,å®¤è­,Muroran", :latitude => "42.31722", :longitude => "140.98806").save
City.new(:country_id => "116", :name => "Mombetsu", :aliases => "MOMBECU,Mobetsu,Mombecu,Mombetsu,Monbetsu,Monbetu,wen bie,ÐÐÐÐÐÐ¦Ð£,ÐÐ¾Ð¼Ð±ÐµÑÑ,ç´å¥,Mombetsu", :latitude => "44.3525", :longitude => "143.3525").save
City.new(:country_id => "116", :name => "Misawa", :aliases => "Misava,Misawa,Omisawa,san ze,Åmisawa,ÐÐ¸ÑÐ°Ð²Ð°,ä¸æ²¢,Misawa", :latitude => "40.68361", :longitude => "141.35972").save
City.new(:country_id => "116", :name => "Yoichi", :aliases => "Minatomachi,Yoichi,Yoichicho,YoichichÅ,Yoiti,Yoichi", :latitude => "43.20389", :longitude => "140.77028").save
City.new(:country_id => "116", :name => "Makubetsu", :aliases => ",Makubetsu", :latitude => "45.37139", :longitude => "141.82111").save
City.new(:country_id => "116", :name => "Kushiro", :aliases => "Kushira,Kushiro,Kusiro,chuan lu shi,ÐÑÑÐ¸ÑÐ¾,é§è·¯å¸,Kushiro", :latitude => "42.975", :longitude => "144.37472").save
City.new(:country_id => "116", :name => "Kuroishi", :aliases => "Kuroishi,hei shi,é»ç³,Kuroishi", :latitude => "40.63889", :longitude => "140.59222").save
City.new(:country_id => "116", :name => "Kizukuri", :aliases => "Kizukuri,Kizukuri", :latitude => "40.80611", :longitude => "140.38611").save
City.new(:country_id => "116", :name => "Kitami", :aliases => "Kitami,Kity,Nokkeushi,Nokkeusi,Notsukeushi,Nupukeushi-mura,ÐÐ¸ÑÑ,Kitami", :latitude => "43.80306", :longitude => "143.89083").save
City.new(:country_id => "116", :name => "Kamiiso", :aliases => ",Kamiiso", :latitude => "41.81667", :longitude => "140.65").save
City.new(:country_id => "116", :name => "Iwanai", :aliases => "Iwanai,Iwanai", :latitude => "42.97444", :longitude => "140.50889").save
City.new(:country_id => "116", :name => "Iwamizawa", :aliases => "Iwamisawa,Iwamizawa,Twamizawa,iwamizawa,yan jian ze,ããã¿ãã,ã¤ã¯ãã¶ã¯,å²©è¦æ²¢,ï½²ï¾ï¾ï½»ï¾ï¾,Iwamizawa", :latitude => "43.20028", :longitude => "141.75972").save
City.new(:country_id => "116", :name => "Ishikari", :aliases => "Ishikari,Isikari,ÐÑÐ¸ÐºÐ°ÑÐ¸,Ishikari", :latitude => "43.23972", :longitude => "141.35389").save
City.new(:country_id => "116", :name => "Ichinohe", :aliases => "Ehinohe,Ichinobe,Ichinohe,Itinohe,Itschinohe,Ichinohe", :latitude => "40.20694", :longitude => "141.30167").save
City.new(:country_id => "116", :name => "Kitahiroshima", :aliases => "Hiroshima,Khirosima,Kitahiroshima,Nakaosawa,Ð¥Ð¸ÑÐ¾ÑÐ¸Ð¼Ð°,ååºå³¶,Kitahiroshima", :latitude => "42.97583", :longitude => "141.56722").save
City.new(:country_id => "116", :name => "Hirosaki", :aliases => "Hirosaki,Khirosaki,hilosaki si,hong qian shi,Ð¥Ð¸ÑÐ¾ÑÐ°ÐºÐ¸,å¼åå¸,íë¡ì¬í¤ ì,Hirosaki", :latitude => "40.59306", :longitude => "140.4725").save
City.new(:country_id => "116", :name => "Kazuno", :aliases => "Hanawa,Kazuno,Kazuno", :latitude => "40.18361", :longitude => "140.78722").save
City.new(:country_id => "116", :name => "Hakodate", :aliases => "Hakodate,Hokodate,Khakodate,ha ko da tea,hakodate si,hakwdath,han guan shi,Ð¥Ð°ÐºÐ¾Ð´Ð°ÑÐµ,ÙØ§ÙÙØ¯Ø§ØªÙ,à¸®à¸²à¹à¸à¸à¸²à¹à¸à¸°,å½é¤¨å¸,íì½ë¤í ì,Hakodate", :latitude => "41.77583", :longitude => "140.73667").save
City.new(:country_id => "116", :name => "Hachinohe", :aliases => "Hachinohe,ba hu,å«æ¸,Hachinohe", :latitude => "40.5", :longitude => "141.5").save
City.new(:country_id => "116", :name => "Fukagawa", :aliases => "Fukagava,Fukagawa,Hukagawa,Ð¤ÑÐºÐ°Ð³Ð°Ð²Ð°,Fukagawa", :latitude => "43.70806", :longitude => "142.03917").save
City.new(:country_id => "116", :name => "Ebetsu", :aliases => "Ebetsu,Ebetsu", :latitude => "43.10806", :longitude => "141.55056").save
City.new(:country_id => "116", :name => "Date", :aliases => "Date,Nishi-mombetsu,Date", :latitude => "42.46806", :longitude => "140.86806").save
City.new(:country_id => "116", :name => "Chitose", :aliases => "Chitose,Chitose", :latitude => "42.81944", :longitude => "141.65222").save
City.new(:country_id => "116", :name => "Bibai", :aliases => "Bibai,Numakai,Bibai", :latitude => "43.32472", :longitude => "141.85861").save
City.new(:country_id => "116", :name => "Ashibetsu", :aliases => "Ashibetsu,Shimo-ashibetsu,Ashibetsu", :latitude => "43.50972", :longitude => "142.18556").save
City.new(:country_id => "116", :name => "Asahikawa", :aliases => "Asahigawa,Asahikawa,Asakhigava,Asakhikava,xu chuan,ÐÑÐ°ÑÐ¸ÐºÐ°Ð²Ð°,æ­å·,Asahikawa", :latitude => "43.76778", :longitude => "142.37028").save
City.new(:country_id => "116", :name => "Aomori-shi", :aliases => "Aomori,Aomori - qing sen shi,Aomori - éæ£®å¸,Aomori-shi,aomoli si,awmwry,qing sen shi,ÐÐ¾Ð¼Ð¾ÑÐ¸,Ø¢ÙÙÙØ±Ù,ããããã,éæ£®å¸,ìì¤ëª¨ë¦¬ ì,Aomori-shi", :latitude => "40.82444", :longitude => "140.74").save
City.new(:country_id => "116", :name => "Abashiri", :aliases => "ABASIRI,Abashiri,Abasiri,Aburatsu,wang zou,ÐÐÐÐ¡ÐÐ Ð,ç¶²èµ°,Abashiri", :latitude => "44.02127", :longitude => "144.26971").save
City.new(:country_id => "116", :name => "Goshogawara", :aliases => "Goshogawara,Goshogawara", :latitude => "40.80444", :longitude => "140.44139").save
City.new(:country_id => "116", :name => "Nanto-shi", :aliases => "Nanto,nan li shi,åç ºå¸,Nanto-shi", :latitude => "36.56922", :longitude => "136.91162").save
City.new(:country_id => "116", :name => "Kawage", :aliases => ",Kawage", :latitude => "34.80447", :longitude => "136.54645").save
City.new(:country_id => "116", :name => "Neyagawa", :aliases => "Neyagawa-shi,qin wu chuan,qin wu chuan shi,å¯å±å·,å¯å±å·å¸,Neyagawa", :latitude => "34.76615", :longitude => "135.62759").save
City.new(:country_id => "116", :name => "Hitachi-Naka", :aliases => "hitachinaka,hitachinaka shi,hitachinaka-shi,ã²ãã¡ãªã,ã²ãã¡ãªãå¸,Hitachi-Naka", :latitude => "36.39659", :longitude => "140.53479").save
City.new(:country_id => "116", :name => "Inashiki", :aliases => "dao fu,dao fu shi,sakuragawa,sakuragawa-mura,ç¨²æ·,ç¨²æ·å¸,Inashiki", :latitude => "35.95633", :longitude => "140.32356").save
City.new(:country_id => "116", :name => "Akiruno-shi", :aliases => "akiru ye,akiru ye shi,akiruno,ãããé,ãããéå¸,Akiruno-shi", :latitude => "35.72878", :longitude => "139.29415").save
City.new(:country_id => "116", :name => "Onojo", :aliases => "da ye cheng,da ye cheng shi,å¤§éå,å¤§éåå¸,ÅnojÅ", :latitude => "33.53567", :longitude => "130.47861").save
City.new(:country_id => "116", :name => "Kamagaya-shi", :aliases => "Kamagaya,lian~ke gu,lian~ke gu shi,éã¶è°·,éã¶è°·å¸,Kamagaya-shi", :latitude => "35.77674", :longitude => "140.00075").save
City.new(:country_id => "116", :name => "Minokamo", :aliases => "Minokamo,mei nong jia mao,ÐÐ¸Ð½Ð¾ÐºÐ°Ð¼Ð¾,ç¾æ¿å è,Minokamo", :latitude => "35.48199", :longitude => "137.02166").save
City.new(:country_id => "116", :name => "Gujo", :aliases => "Gudzjo,Gujo,GujÅ,jun shang,ÐÑÐ´Ð·Ñ,é¡ä¸,GujÅ", :latitude => "35.73691", :longitude => "136.95852").save
City.new(:country_id => "116", :name => "Joetsu", :aliases => "Joetsu,Joetsu-shi,shang yue,shang yue shi,ä¸è¶,ä¸è¶å¸,JÅetsu", :latitude => "37.14828", :longitude => "138.23642").save
City.new(:country_id => "116", :name => "Saitama", :aliases => "Saitama,Ð¡Ð°Ð¸ÑÐ°Ð¼Ð°,Saitama", :latitude => "35.90807", :longitude => "139.65657").save
City.new(:country_id => "116", :name => "Higashimurayama-shi", :aliases => "Higashi-Murayama,Higashi-Murayama-shi,Higashimurayama,dong cun shan,dong cun shan shi,æ±æå±±,æ±æå±±å¸,Higashimurayama-shi", :latitude => "35.75459", :longitude => "139.46852").save
City.new(:country_id => "116", :name => "Kunisaki-shi", :aliases => "Kunisaki,guo dong,guo dong shi,å½æ±,å½æ±å¸,Kunisaki-shi", :latitude => "33.56543", :longitude => "131.73157").save
City.new(:country_id => "116", :name => "Fujikawaguchiko", :aliases => "Fudzikavagutiko,Ð¤ÑÐ´Ð·Ð¸ÐºÐ°Ð²Ð°Ð³ÑÑÐ¸ÐºÐ¾,Fujikawaguchiko", :latitude => "35.48933", :longitude => "138.68832").save
