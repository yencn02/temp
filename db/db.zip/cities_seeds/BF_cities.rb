City.new(:country_id => "23", :name => "Zorgho", :aliases => "Zorgo,Zorogo,Zorgho", :latitude => "12.24889", :longitude => "-0.61583").save
City.new(:country_id => "23", :name => "Yako", :aliases => "Jako,Yako,Ð¯ÐºÐ¾,Yako", :latitude => "12.96667", :longitude => "-2.26667").save
City.new(:country_id => "23", :name => "Tougan", :aliases => "Tougan,Tugan,Tougan", :latitude => "13.06667", :longitude => "-3.06667").save
City.new(:country_id => "23", :name => "Titao", :aliases => ",Titao", :latitude => "13.76667", :longitude => "-2.06667").save
City.new(:country_id => "23", :name => "Tenkodogo", :aliases => "Tenkodogo,Tenkodogo", :latitude => "11.78", :longitude => "-0.36972").save
City.new(:country_id => "23", :name => "Reo", :aliases => "Reo,RÃ©o,Ð ÐµÐ¾,RÃ©o", :latitude => "12.31667", :longitude => "-2.46667").save
City.new(:country_id => "23", :name => "Po", :aliases => "Po,PÃ´,PÃ´", :latitude => "11.16972", :longitude => "-1.145").save
City.new(:country_id => "23", :name => "Ouahigouya", :aliases => "Ouahigouya,Waiguya,Ouahigouya", :latitude => "13.58278", :longitude => "-2.42158").save
City.new(:country_id => "23", :name => "Ouagadougou", :aliases => "Ouagadouga,Ouagadougou,Ouankantounkou,Uagadougou,Uagadugu,Uagaduguo,UagadugÃº,Vagadugu,Wagadugu,awagadwgw,wa jia du gu,wagado~ugu,wagadugu,waghadwghw,ÎÏÎ±Î³ÎºÎ±Î½ÏÎ¿ÏÎ³ÎºÎ¿Ï,Ð£Ð°Ð³Ð°Ð´ÑÐ³Ñ,××××××××,Ø§ÙØ¢Ú¯Ø§Ø¯ÙÚ¯Ù,ÙØ§ØºØ§Ø¯ÙØºÙ,ááá±á,ã¯ã¬ãã¥ã°ã¼,ç¦å æå¤,ìê°ëêµ¬,Ouagadougou", :latitude => "12.36423", :longitude => "-1.53834").save
City.new(:country_id => "23", :name => "Nouna", :aliases => "Nouna,Nouna", :latitude => "12.73333", :longitude => "-3.86667").save
City.new(:country_id => "23", :name => "Manga", :aliases => ",Manga", :latitude => "11.66361", :longitude => "-1.07306").save
City.new(:country_id => "23", :name => "Leo", :aliases => "Leo,Lev,LÃ©o,ÐÐµÐ²,LÃ©o", :latitude => "11.1", :longitude => "-2.1").save
City.new(:country_id => "23", :name => "Koupela", :aliases => "Kupela,KoupÃ©la", :latitude => "12.17944", :longitude => "-0.35167").save
City.new(:country_id => "23", :name => "Koudougou", :aliases => "Kondougou,Koudougou,Kudugu,ÐÑÐ´ÑÐ³Ñ,Koudougou", :latitude => "12.25", :longitude => "-2.36667").save
City.new(:country_id => "23", :name => "Kongoussi", :aliases => "Kongoussi,Kongoussi", :latitude => "13.32583", :longitude => "-1.53472").save
City.new(:country_id => "23", :name => "Kombissiri", :aliases => "Kombisiri,Kombissiguiri,Kombissiri,Kombissiri", :latitude => "12.06556", :longitude => "-1.3375").save
City.new(:country_id => "23", :name => "Kokologo", :aliases => "Kokolgho,Kokologo,Kokologo", :latitude => "12.18972", :longitude => "-1.88556").save
City.new(:country_id => "23", :name => "Kaya", :aliases => "Kaja,Kaya,ÐÐ°Ñ,Kaya", :latitude => "13.09167", :longitude => "-1.08444").save
City.new(:country_id => "23", :name => "Hounde", :aliases => "Hounde,HoundÃ©,Hunde,HoundÃ©", :latitude => "11.5", :longitude => "-3.51667").save
City.new(:country_id => "23", :name => "Gourcy", :aliases => "Gourcy,Goursi,Gursi,Gourcy", :latitude => "13.21667", :longitude => "-2.35").save
City.new(:country_id => "23", :name => "Garango", :aliases => "Garango,Garango", :latitude => "11.8", :longitude => "-0.55056").save
City.new(:country_id => "23", :name => "Fada N'Gourma", :aliases => "Fada N'Gourma,Fada N'gourma,Fada NâGourma,Fada-Ngourma,Fada-n-Gurma,Fada NâGourma", :latitude => "12.06222", :longitude => "0.35778").save
City.new(:country_id => "23", :name => "Dori", :aliases => "Dori,ÐÐ¾ÑÐ¸,Dori", :latitude => "14.0354", :longitude => "-0.0345").save
City.new(:country_id => "23", :name => "Djibo", :aliases => "Djibo,Dzhibo,Jibo,ÐÐ¶Ð¸Ð±Ð¾,Djibo", :latitude => "14.10222", :longitude => "-1.63056").save
City.new(:country_id => "23", :name => "Diapaga", :aliases => "Diapaga,ÐÐ¸Ð°Ð¿Ð°Ð³Ð°,Diapaga", :latitude => "12.07083", :longitude => "1.78889").save
City.new(:country_id => "23", :name => "Dedougou", :aliases => "Dedougou,Dedugu,DÃ©dougou,DÃ©dougou", :latitude => "12.46667", :longitude => "-3.46667").save
City.new(:country_id => "23", :name => "Bousse", :aliases => "Busse,BoussÃ©", :latitude => "12.66056", :longitude => "-1.89222").save
City.new(:country_id => "23", :name => "Boulsa", :aliases => "Boulsa,Boulssa,Bulsa,Boulsa", :latitude => "12.6675", :longitude => "-0.57583").save
City.new(:country_id => "23", :name => "Bobo-Dioulasso", :aliases => "Bobo Dioulasso,Bobo-Dioulasso,Bobo-Diulasso,Bobodjulaso,ããã»ãã£ã¦ã©ãã½,Bobo-Dioulasso", :latitude => "11.17715", :longitude => "-4.2979").save
City.new(:country_id => "23", :name => "Banfora", :aliases => "Banfora,Banforu,ÐÐ°Ð½ÑÐ¾ÑÑ,Banfora", :latitude => "10.63333", :longitude => "-4.76667").save
City.new(:country_id => "23", :name => "Gaoua", :aliases => ",Gaoua", :latitude => "10.29917", :longitude => "-3.25083").save
City.new(:country_id => "23", :name => "Orodara", :aliases => "Orodaro,Orodara", :latitude => "10.94917", :longitude => "-4.93417").save
