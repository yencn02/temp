City.new(:country_id => "-1", :name => "Philipsburg", :aliases => "Filipsburg,Great Bay,Philipsburg,Ð¤Ð¸Ð»Ð¸Ð¿ÑÐ±ÑÑÐ³,Philipsburg", :latitude => "18.026", :longitude => "-63.04582").save
