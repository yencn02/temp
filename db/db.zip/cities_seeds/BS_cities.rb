City.new(:country_id => "33", :name => "Nassau", :aliases => "City of Nassau,Nasau,Nassaou,Nassau,Nassau City,na sao,naso,nasso,ÎÎ±ÏÏÎ¬Î¿Ï,ÐÐ°ÑÑÐ°Ñ,× ×¡××,áá¶,ããã½ã¼,æ¿éª,ëì,Nassau", :latitude => "25.05823", :longitude => "-77.34306").save
City.new(:country_id => "33", :name => "Lucaya", :aliases => "Lucaya,Lucaya", :latitude => "26.53333", :longitude => "-78.66667").save
City.new(:country_id => "33", :name => "Freeport", :aliases => "Freeport,Freeport City,Freeport", :latitude => "26.53333", :longitude => "-78.7").save
