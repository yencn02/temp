City.new(:country_id => "156", :name => "Vacoas", :aliases => "Vacoa,Vacoas,Vacoas", :latitude => "-20.29806", :longitude => "57.47833").save
City.new(:country_id => "156", :name => "Triolet", :aliases => "Triolet,Ð¢ÑÐ¸Ð¾Ð»ÐµÑ,Triolet", :latitude => "-20.05472", :longitude => "57.54528").save
City.new(:country_id => "156", :name => "Saint Pierre", :aliases => "Saint Pierre,Saint Pierre Village,Saint Pierre", :latitude => "-20.2175", :longitude => "57.52083").save
City.new(:country_id => "156", :name => "Quatre Bornes", :aliases => "Quatre Bornes,Quatre Bornes", :latitude => "-20.26444", :longitude => "57.47194").save
City.new(:country_id => "156", :name => "Port Louis", :aliases => "Por Loui,Port Louis,Port Louis Town,Port Luis Mauricijus,Port Luisas,Port-Louis,Port-Lui,bwr lwys,lu yi gang,poteulu-iseu,potoruisu,Î Î¿Ï ÎÎ¿ÏÎ¯,ÐÐ¾ÑÑ ÐÑÐ¸Ñ ÐÐ°ÑÑÐ¸ÑÐ¸ÑÑÑ,ÐÐ¾ÑÑ-ÐÑÐ¸,×¤××¨× ×××××¡,Ø¨ÙØ± ÙÙÙØ³,Ù¾ÙØ±ØªâÙÙØ¦ÛØ³,áá­áµ áááµ,ãã¼ãã«ã¤ã¹,è·¯ææ¸¯,í¬í¸ë£¨ì´ì¤,Port Louis", :latitude => "-20.16194", :longitude => "57.49889").save
City.new(:country_id => "156", :name => "Mahebourg", :aliases => "Mahebourg,MahÃ©bourg,MahÃ©bourg", :latitude => "-20.40806", :longitude => "57.7").save
City.new(:country_id => "156", :name => "Goodlands", :aliases => ",Goodlands", :latitude => "-20.035", :longitude => "57.64306").save
City.new(:country_id => "156", :name => "Curepipe", :aliases => "Curepipe,Kurepipe,ÐÑÑÐµÐ¿Ð¸Ð¿Ðµ,Curepipe", :latitude => "-20.31472", :longitude => "57.52028").save
City.new(:country_id => "156", :name => "Centre de Flacq", :aliases => "Centre of Flacq,Flacq,Centre de Flacq", :latitude => "-20.18972", :longitude => "57.71444").save
City.new(:country_id => "156", :name => "Bel Air", :aliases => "Bel Air,Riviere Seche,RiviÃ¨re SÃ¨che,Bel Air", :latitude => "-20.25417", :longitude => "57.74528").save
City.new(:country_id => "156", :name => "Le Hochet", :aliases => ",Le Hochet", :latitude => "-20.135", :longitude => "57.52111").save
