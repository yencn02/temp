City.new(:country_id => "172", :name => "Alofi", :aliases => "Alofi,Alofis,alwfy,arofi,ÐÐ»Ð¾ÑÐ¸Ñ,Ø§ÙÙÙÛ,ã¢ã­ãã£,Alofi", :latitude => "-19.05952", :longitude => "-169.91867").save
