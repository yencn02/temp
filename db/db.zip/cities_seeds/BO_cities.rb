City.new(:country_id => "31", :name => "Yacuiba", :aliases => "Jakuiba,Yacuiba,Ð¯ÐºÑÐ¸Ð±Ð°,Yacuiba", :latitude => "-22.03333", :longitude => "-63.68333").save
City.new(:country_id => "31", :name => "Warnes", :aliases => ",Warnes", :latitude => "-17.5", :longitude => "-63.16667").save
City.new(:country_id => "31", :name => "Villazon", :aliases => ",VillazÃ³n", :latitude => "-22.08659", :longitude => "-65.59422").save
City.new(:country_id => "31", :name => "Villa Yapacani", :aliases => ",Villa YapacanÃ­", :latitude => "-17.4", :longitude => "-63.83333").save
City.new(:country_id => "31", :name => "Villamontes", :aliases => "Villamontes,Villamontes", :latitude => "-21.25", :longitude => "-63.5").save
City.new(:country_id => "31", :name => "Tupiza", :aliases => "Tupiza,Turpiza,Tupiza", :latitude => "-21.45", :longitude => "-65.71667").save
City.new(:country_id => "31", :name => "La Santisima Trinidad", :aliases => "Ciudad Trinidad,Trinidad,te li ni da,torinida,Ð¢ÑÐ¸Ð½Ð¸Ð´Ð°Ð´,ããªãã,ç¹ç«å°¼è¾¾,La Santisima Trinidad", :latitude => "-14.83333", :longitude => "-64.9").save
City.new(:country_id => "31", :name => "Tarija", :aliases => "Ciudad Tarija,Tarija,Tarikha,Ð¢Ð°ÑÐ¸ÑÐ°,Tarija", :latitude => "-21.53549", :longitude => "-64.72956").save
City.new(:country_id => "31", :name => "Sucre", :aliases => "Chuqichaka,Chuquisaca,Ciudad Sucre,Sucre,Sukre,Sukri,Sukro,SukrÄ,su ke lei,sukeule,sukure,swqrh,Ð¡ÑÐºÑÐµ,×¡××§×¨×,ã¹ã¯ã¬,èåé·,ìí¬ë ,Sucre", :latitude => "-19.03332", :longitude => "-65.26274").save
City.new(:country_id => "31", :name => "Santiago del Torno", :aliases => "El Torno,Santiago del Torno,Torno,Santiago del Torno", :latitude => "-17.98333", :longitude => "-63.38333").save
City.new(:country_id => "31", :name => "Santa Cruz de la Sierra", :aliases => "Ciudad Santa Cruz,Ciudad de Santa Cruz de la Sierra,Santa Cruz,Santa Cruz de la Sierra,Santa-Krus-de-la-Sierra,santakurusu,Ð¡Ð°Ð½ÑÐ°-ÐÑÑÑ-Ð´Ðµ-Ð»Ð°-Ð¡Ð¸ÐµÑÑÐ°,Ø³Ø§ÙØªØ§ Ú©Ø±ÙØ² Ø¯ÙØ§Ø³ÛÙâØ±Ø§,ãµã³ã¿ã¯ã«ã¹,Santa Cruz de la Sierra", :latitude => "-17.8", :longitude => "-63.16667").save
City.new(:country_id => "31", :name => "San Ignacio de Velasco", :aliases => "San Ignacio,San Ignacio Velasco,San Ignacio de Loyola,San Ignacio de Velasco,San Ignacio de Velasco", :latitude => "-16.36667", :longitude => "-60.95").save
City.new(:country_id => "31", :name => "San Borja", :aliases => ",San Borja", :latitude => "-14.81667", :longitude => "-66.85").save
City.new(:country_id => "31", :name => "Riberalta", :aliases => "Riberalta,riberaruta,ãªãã©ã«ã¿,Riberalta", :latitude => "-10.98333", :longitude => "-66.1").save
City.new(:country_id => "31", :name => "Punata", :aliases => "Ciudad Punata,Punata,Punata", :latitude => "-17.55", :longitude => "-65.83333").save
City.new(:country_id => "31", :name => "Potosi", :aliases => "Ciudad Potosi,P'utuqsi,Potosi,PotosÃ­,Putusi,potoshi,pwtwsy,ÐÐ¾ÑÐ¾ÑÐ¸,×¤××××¡×,ããã·,PotosÃ­", :latitude => "-19.58361", :longitude => "-65.75306").save
City.new(:country_id => "31", :name => "Oruro", :aliases => "Ciudad Oruro,Gruro,Oruro,Ururu,ÐÑÑÑÐ¾,Oruro", :latitude => "-17.98333", :longitude => "-67.15").save
City.new(:country_id => "31", :name => "Montero", :aliases => "Montero,Vibora,VÃ­bora,ÐÐ¾Ð½ÑÐµÑÐ¾,Montero", :latitude => "-17.33333", :longitude => "-63.25").save
City.new(:country_id => "31", :name => "Mizque", :aliases => "Ciudad Mizque,Ciudad de Mizqu,Ciudad de Mizque,Mizque", :latitude => "-17.94101", :longitude => "-65.34016").save
City.new(:country_id => "31", :name => "Llallagua", :aliases => ",Llallagua", :latitude => "-18.41667", :longitude => "-66.63333").save
City.new(:country_id => "31", :name => "La Paz", :aliases => "Chukiyapu,Chukiyawu,Ciudad La Paz,Civitas Pacis,La Pasas,La Paz,La-Pas,La-Pazo,Soukre/La Paz,la ba si,labaz,lapas,lapaseu,rapasu,Î£Î¿ÏÎºÏÎµ/ÎÎ± Î Î±Î¶,ÐÐ°-ÐÐ°Ñ,×× ×¤××¡,ÙØ§Ø¨Ø§Ø²,à¸¥à¸²à¸à¸²à¸,ááá,ã©ãã¹,æå·´æ¯,ë¼íì¤,La Paz", :latitude => "-16.5", :longitude => "-68.15").save
City.new(:country_id => "31", :name => "Huanuni", :aliases => "Huanuni,Villa Huanuni,Huanuni", :latitude => "-18.26667", :longitude => "-66.85").save
City.new(:country_id => "31", :name => "Guayaramerin", :aliases => "Guajara-Mirim,Guayaramerin,GuayaramerÃ­n,Puerto Sucre,GuayaramerÃ­n", :latitude => "-10.8", :longitude => "-65.38333").save
City.new(:country_id => "31", :name => "Cotoca", :aliases => ",Cotoca", :latitude => "-17.81667", :longitude => "-63.05").save
City.new(:country_id => "31", :name => "Cochabamba", :aliases => "Ciudad Cochabamba,Cochabamba,Kochabamba,Kuchawampa,Quchapampa,kochabanba,qwz'bmbh,ÐÐ¾ÑÐ°Ð±Ð°Ð¼Ð±Ð°,×§××¦'××××,ã³ãã£ãã³ã,Cochabamba", :latitude => "-17.3895", :longitude => "-66.1568").save
City.new(:country_id => "31", :name => "Cobija", :aliases => "Cobija,Cobila,Cobya,Kobikha,Puerto Cobija,ÐÐ¾Ð±Ð¸ÑÐ°,Cobija", :latitude => "-11.02671", :longitude => "-68.76918").save
City.new(:country_id => "31", :name => "Camiri", :aliases => "Camiri,Kamiri,Refineria Camiri,ÐÐ°Ð¼Ð¸ÑÐ¸,Camiri", :latitude => "-20.05", :longitude => "-63.51667").save
