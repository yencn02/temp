City.new(:country_id => "216", :name => "Port-aux-Francais", :aliases => "Port-o-Franseh,ÐÐ¾ÑÑ-Ð¾-Ð¤ÑÐ°Ð½ÑÑ,Port-aux-FranÃ§ais", :latitude => "-49.35", :longitude => "70.21667").save
