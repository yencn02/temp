City.new(:country_id => "88", :name => "Tougue", :aliases => "Tongue,Tougue,TouguÃ©,TouguÃ©", :latitude => "11.45", :longitude => "-11.68333").save
City.new(:country_id => "88", :name => "Telimele", :aliases => "Telimele,TÃ©limÃ©lÃ©,TÃ©limÃ©lÃ©", :latitude => "10.9", :longitude => "-13.03333").save
City.new(:country_id => "88", :name => "Siguiri", :aliases => "Sigiri,Siguiri,Ð¡Ð¸Ð³Ð¸ÑÐ¸,Siguiri", :latitude => "11.41667", :longitude => "-9.16667").save
City.new(:country_id => "88", :name => "Pita", :aliases => ",Pita", :latitude => "11.08333", :longitude => "-12.4").save
City.new(:country_id => "88", :name => "Nzerekore", :aliases => "Nzerekore,NzÃ©rÃ©korÃ©,ÐÐ·ÐµÑÐµÐºÐ¾ÑÐµ,NzÃ©rÃ©korÃ©", :latitude => "7.74722", :longitude => "-8.82389").save
City.new(:country_id => "88", :name => "Mamou", :aliases => ",Mamou", :latitude => "10.38333", :longitude => "-12.08333").save
City.new(:country_id => "88", :name => "Macenta", :aliases => "Macenta,Magenta,Masenta,ÐÐ°ÑÐµÐ½ÑÐ°,Macenta", :latitude => "8.54611", :longitude => "-9.46944").save
City.new(:country_id => "88", :name => "Labe", :aliases => "Laba,Labe,LabÃ©,ÐÐ°Ð±Ð°,LabÃ©", :latitude => "11.31667", :longitude => "-12.28333").save
City.new(:country_id => "88", :name => "Kissidougou", :aliases => "Kisidugu,Kissidougou,Kissidugu,ÐÐ¸ÑÐ¸Ð´ÑÐ³Ñ,Kissidougou", :latitude => "9.18333", :longitude => "-10.1").save
City.new(:country_id => "88", :name => "Kindia", :aliases => "Kindia,Kindla,ÐÐ¸Ð½Ð´Ð¸Ð°,Kindia", :latitude => "10.06667", :longitude => "-12.85").save
City.new(:country_id => "88", :name => "Kankan", :aliases => "Kankan,ÐÐ°Ð½ÐºÐ°Ð½,Kankan", :latitude => "10.38333", :longitude => "-9.3").save
City.new(:country_id => "88", :name => "Kamsar", :aliases => "Kamissar,Kamsar,Kansar,Kamsar", :latitude => "10.66667", :longitude => "-14.6").save
City.new(:country_id => "88", :name => "Gueckedou", :aliases => "Gueckedou,Guekedou,GuÃ©ckÃ©dou,GuÃ©kÃ©dou,GuÃ©ckÃ©dou", :latitude => "8.5625", :longitude => "-10.1325").save
City.new(:country_id => "88", :name => "Fria", :aliases => "Firiya,Fria,Ð¤ÑÐ¸Ð°,Fria", :latitude => "10.45", :longitude => "-13.53333").save
City.new(:country_id => "88", :name => "Coyah", :aliases => "Coya,Coyah,Koyah,Coyah", :latitude => "9.70556", :longitude => "-13.37694").save
City.new(:country_id => "88", :name => "Conakry", :aliases => "Conacri,Conakry,Konakri,Konakrio,Konakris,Konakry,ke na ke li,konakeuli,konakuri,ÎÏÎ½Î±ÎºÏÎ¹,ÐÐ¾Ð½Ð°ÐºÑÐ¸,×§×× ××§×¨×,ã³ãã¯ãª,ç§ç´åé,ì½ëí¬ë¦¬,Conakry", :latitude => "9.53795", :longitude => "-13.67729").save
City.new(:country_id => "88", :name => "Camayenne", :aliases => "Camayen,Camayenne,Camayenne", :latitude => "9.535", :longitude => "-13.68778").save
City.new(:country_id => "88", :name => "Boke", :aliases => "Boke,BokÃ©,Boque,BoquÃ©,BokÃ©", :latitude => "10.93333", :longitude => "-14.3").save
