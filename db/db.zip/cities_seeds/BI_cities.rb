City.new(:country_id => "26", :name => "Makamba", :aliases => "Makamba,ÐÐ°ÐºÐ°Ð¼Ð±Ð°,Makamba", :latitude => "-4.1348", :longitude => "29.804").save
City.new(:country_id => "26", :name => "Bururi", :aliases => "Bururi,Mont Bururi,ÐÑÑÑÑÐ¸,Bururi", :latitude => "-3.94877", :longitude => "29.62438").save
City.new(:country_id => "26", :name => "Bujumbura", :aliases => "Budzumbura,Bujumbura,Bujumburo,BujÂ·umbura,Buzhumbura,Buzumbura,BuÄµumburo,BuÅ¼umbura,BuÅ¾umbÅ«ra,Mpouzoumpoura,Usumbura,bu qiong bu la,bujumbula,bujunbura,bwg'wmbwrh,bwjwmbra,bwjwmbwra,ÎÏÎ¿ÏÎ¶Î¿ÏÎ¼ÏÎ¿ÏÏÎ±,ÐÑÐ¶ÑÐ¼Ð±ÑÑÐ°,ÐÑÑÑÐ¼Ð±ÑÑÐ°,Ô²Õ¸ÖÕªÕ¸ÖÕ´Õ¢Õ¸ÖÖÕ¡,×××'×××××¨×,Ø¨ÙØ¬ÙÙØ¨Ø±Ø§,Ø¨ÙØ¬ÙÙØ¨ÙØ±Ø§,á¡ááá¡á«,ãã¸ã¥ã³ãã©,å¸ç¼å¸æ,ë¶ì¤ë¶ë¼,Bujumbura", :latitude => "-3.3822", :longitude => "29.3644").save
City.new(:country_id => "26", :name => "Muramvya", :aliases => ",Muramvya", :latitude => "-3.2682", :longitude => "29.6079").save
City.new(:country_id => "26", :name => "Gitega", :aliases => "Gitega,Gitege,Kitega,ÐÐ¸ÑÐµÐ³Ðµ,Gitega", :latitude => "-3.4264", :longitude => "29.9308").save
City.new(:country_id => "26", :name => "Ruyigi", :aliases => "Rujigi,Ruyigi,Ð ÑÐ¹Ð¸Ð³Ð¸,Ruyigi", :latitude => "-3.47639", :longitude => "30.24861").save
City.new(:country_id => "26", :name => "Ngozi", :aliases => "Ngozi,ÐÐ³Ð¾Ð·Ð¸,Ngozi", :latitude => "-2.9075", :longitude => "29.8306").save
City.new(:country_id => "26", :name => "Kayanza", :aliases => "Kayanza,Kayanza", :latitude => "-2.9221", :longitude => "29.6293").save
City.new(:country_id => "26", :name => "Muyinga", :aliases => "Mujinga,Muyinga,ÐÑÐ¹Ð¸Ð½Ð³Ð°,Muyinga", :latitude => "-2.84944", :longitude => "30.33611").save
City.new(:country_id => "26", :name => "Rutana", :aliases => "Rutana,Ð ÑÑÐ°Ð½Ð°,Rutana", :latitude => "-3.9279", :longitude => "29.992").save
