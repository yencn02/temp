City.new(:country_id => "238", :name => "La Asuncion", :aliases => "La Asuncion,La AsunciÃ³n,La-Asuns'on,ÐÐ°-ÐÑÑÐ½ÑÑÐ¾Ð½,La AsunciÃ³n", :latitude => "11.03333", :longitude => "-63.86278").save
City.new(:country_id => "238", :name => "Anaco", :aliases => "Anaco,Anaco", :latitude => "9.43889", :longitude => "-64.47278").save
City.new(:country_id => "238", :name => "Alto Barinas", :aliases => ",Alto Barinas", :latitude => "8.5931", :longitude => "-70.2261").save
City.new(:country_id => "238", :name => "Zaraza", :aliases => "Zaraza,ÐÐ°ÑÐ°Ð·Ð°,Zaraza", :latitude => "9.35029", :longitude => "-65.32452").save
City.new(:country_id => "238", :name => "Yaritagua", :aliases => ",Yaritagua", :latitude => "10.08", :longitude => "-69.12611").save
City.new(:country_id => "238", :name => "Villa de Cura", :aliases => ",Villa de Cura", :latitude => "10.03863", :longitude => "-67.48938").save
City.new(:country_id => "238", :name => "Villa Bruzual", :aliases => "Turen,TurÃ©n,Villa Bruzual,Villa Bruzual", :latitude => "9.33278", :longitude => "-69.12083").save
City.new(:country_id => "238", :name => "Valle de La Pascua", :aliases => "Val'e-de-La-Paskua,Valle de La Pascua,Valle de Pascua,ÐÐ°Ð»ÑÐµ-Ð´Ðµ-ÐÐ°-ÐÐ°ÑÐºÑÐ°,Valle de La Pascua", :latitude => "9.21667", :longitude => "-66").save
City.new(:country_id => "238", :name => "Valera", :aliases => "Valera,ÐÐ°Ð»ÐµÑÐ°,Valera", :latitude => "9.31778", :longitude => "-70.60361").save
City.new(:country_id => "238", :name => "Valencia", :aliases => "Balenzia,Valencia,Valencio,Valensija,ValÃªncia,ba lun xi ya,barenshia,ÐÐ°Ð»ÐµÐ½ÑÐ¸Ñ,ãã¬ã³ã·ã¢,å·´ä¼¦è¥¿äº,Valencia", :latitude => "10.16202", :longitude => "-68.00765").save
City.new(:country_id => "238", :name => "Upata", :aliases => ",Upata", :latitude => "8.00861", :longitude => "-62.39889").save
City.new(:country_id => "238", :name => "Turmero", :aliases => ",Turmero", :latitude => "10.22388", :longitude => "-67.47288").save
City.new(:country_id => "238", :name => "Tucupita", :aliases => "Tucupita,Tukupita,Ð¢ÑÐºÑÐ¿Ð¸ÑÐ°,Tucupita", :latitude => "9.06222", :longitude => "-62.05102").save
City.new(:country_id => "238", :name => "Trujillo", :aliases => ",Trujillo", :latitude => "9.37084", :longitude => "-70.43472").save
City.new(:country_id => "238", :name => "Tinaquillo", :aliases => ",Tinaquillo", :latitude => "9.91861", :longitude => "-68.30472").save
City.new(:country_id => "238", :name => "Tariba", :aliases => ",TÃ¡riba", :latitude => "7.8188", :longitude => "-72.22427").save
City.new(:country_id => "238", :name => "Santa Teresa", :aliases => ",Santa Teresa", :latitude => "10.23139", :longitude => "-66.66361").save
City.new(:country_id => "238", :name => "Santa Rita", :aliases => ",Santa Rita", :latitude => "10.53806", :longitude => "-71.51694").save
City.new(:country_id => "238", :name => "San Mateo", :aliases => ",San Mateo", :latitude => "10.21302", :longitude => "-67.42365").save
City.new(:country_id => "238", :name => "San Juan de los Morros", :aliases => "San Juan de Los Morros,San Juan de los Moros,San Juan de los Morros,San Juan de los Morros", :latitude => "9.91111", :longitude => "-67.35833").save
City.new(:country_id => "238", :name => "San Juan de Colon", :aliases => "Colon,ColÃ³n,San Juan de Colon,San Juan de ColÃ³n,San Juan de ColÃ³n", :latitude => "8.03125", :longitude => "-72.26053").save
City.new(:country_id => "238", :name => "San Jose de Guanipa", :aliases => "El Tigrito,San Jose de Guanipa,San JosÃ© de Guanipa,San JosÃ© de Guanipa", :latitude => "8.88724", :longitude => "-64.16512").save
City.new(:country_id => "238", :name => "San Joaquin", :aliases => ",San JoaquÃ­n", :latitude => "10.263", :longitude => "-67.7858").save
City.new(:country_id => "238", :name => "San Felipe", :aliases => "San Felipe,San Felipe", :latitude => "10.33991", :longitude => "-68.74247").save
City.new(:country_id => "238", :name => "San Cristobal", :aliases => "San Cristobal,San CristÃ³bal,San CristÃ³bal", :latitude => "7.76694", :longitude => "-72.225").save
City.new(:country_id => "238", :name => "San Carlos del Zulia", :aliases => "Del Zulia,San Carlos,San Carlos del Zulia,San Carlos del Zulia", :latitude => "9.00003", :longitude => "-71.91352").save
City.new(:country_id => "238", :name => "San Carlos", :aliases => ",San Carlos", :latitude => "9.66667", :longitude => "-68.6").save
City.new(:country_id => "238", :name => "San Antonio del Tachira", :aliases => "San Antonio,San Antonio de Tachira,San Antonio de TÃ¡chira,San Antonio del Tachira,San Antonio del TÃ¡chira,San Antonio del TÃ¡chira", :latitude => "7.81454", :longitude => "-72.4431").save
City.new(:country_id => "238", :name => "San Antonio de Los Altos", :aliases => ",San Antonio de Los Altos", :latitude => "10.36667", :longitude => "-66.93333").save
City.new(:country_id => "238", :name => "Rubio", :aliases => "Rubio,Ð ÑÐ±Ð¸Ð¾,Rubio", :latitude => "7.70131", :longitude => "-72.35569").save
City.new(:country_id => "238", :name => "Rosario", :aliases => "La Villa del Rosario,Rosario,Villa del Rosario,Ð Ð¾ÑÐ°ÑÐ¸Ð¾,Rosario", :latitude => "10.31667", :longitude => "-72.31667").save
City.new(:country_id => "238", :name => "Quibor", :aliases => ",QuÃ­bor", :latitude => "9.92556", :longitude => "-69.62028").save
City.new(:country_id => "238", :name => "Punto Fijo", :aliases => "Punto Fijo,Punto Fijo", :latitude => "11.69972", :longitude => "-70.19917").save
City.new(:country_id => "238", :name => "Punta Cardon", :aliases => "Cardon,Cordon,El Cardon,El CardÃ³n,Puerto Cardon,Punta Cardon,Punta CardÃ³n,Punta-Kardon,ÐÑÐ½ÑÐ°-ÐÐ°ÑÐ´Ð¾Ð½,Punta CardÃ³n", :latitude => "11.65806", :longitude => "-70.215").save
City.new(:country_id => "238", :name => "Puerto La Cruz", :aliases => "Puehrto La Kruz,Puerto de La Cruz,ÐÑÑÑÑÐ¾ ÐÐ° ÐÑÑÐ·,Puerto La Cruz", :latitude => "10.21667", :longitude => "-64.61667").save
City.new(:country_id => "238", :name => "Puerto Cabello", :aliases => "Puerto Cabello,Puerto Kabello,ÐÑÐµÑÑÐ¾ ÐÐ°Ð±ÐµÐ»Ð»Ð¾,Puerto Cabello", :latitude => "10.47306", :longitude => "-68.0125").save
City.new(:country_id => "238", :name => "Puerto Ayacucho", :aliases => "Puerto Ayacucho,Puerto Ayacucho", :latitude => "5.66389", :longitude => "-67.62361").save
City.new(:country_id => "238", :name => "Porlamar", :aliases => "Porlamar,ÐÐ¾ÑÐ»Ð°Ð¼Ð°Ñ,Porlamar", :latitude => "10.95796", :longitude => "-63.84906").save
City.new(:country_id => "238", :name => "Petare", :aliases => "Petare,petare qu,ÐÐµÑÐ°ÑÐµ,ãã¿ã¬åº,Petare", :latitude => "10.48333", :longitude => "-66.81667").save
City.new(:country_id => "238", :name => "Palo Negro", :aliases => ",Palo Negro", :latitude => "10.17389", :longitude => "-67.54194").save
City.new(:country_id => "238", :name => "Ocumare del Tuy", :aliases => "Ocumare,Ocumare del Tuy,Ocumare del Tuy", :latitude => "10.12167", :longitude => "-66.77167").save
City.new(:country_id => "238", :name => "Nirgua", :aliases => ",Nirgua", :latitude => "10.15526", :longitude => "-68.5663").save
City.new(:country_id => "238", :name => "Mucumpiz", :aliases => ",Mucumpiz", :latitude => "8.41667", :longitude => "-71.13333").save
City.new(:country_id => "238", :name => "Moron", :aliases => ",MorÃ³n", :latitude => "10.48889", :longitude => "-68.20028").save
City.new(:country_id => "238", :name => "Merida", :aliases => "Merida,MÃ©rida,merida,mrydh,ÐÐµÑÐ¸Ð´Ð°,××¨×××,MÃ©rida", :latitude => "8.59833", :longitude => "-71.145").save
City.new(:country_id => "238", :name => "Mariara", :aliases => ",Mariara", :latitude => "10.29644", :longitude => "-67.71813").save
City.new(:country_id => "238", :name => "Maracay", :aliases => ",Maracay", :latitude => "10.24694", :longitude => "-67.59583").save
City.new(:country_id => "238", :name => "Maracaibo", :aliases => "Maracaibo,Marakaibo,Marakajbo,marakaibo,ÐÐ°ÑÐ°ÐºÐ°Ð¸Ð±Ð¾,ãã©ã«ã¤ã,Maracaibo", :latitude => "10.63167", :longitude => "-71.64056").save
City.new(:country_id => "238", :name => "Maiquetia", :aliases => "Maiquetia,MaiquetÃ­a,MaiquetÃ­a", :latitude => "10.6", :longitude => "-66.95").save
City.new(:country_id => "238", :name => "Machiques", :aliases => "Machiques,Machiques", :latitude => "10.06444", :longitude => "-72.545").save
City.new(:country_id => "238", :name => "Los Rastrojos", :aliases => "Los Rastrojos,Rastrojo,Rastrojos,Los Rastrojos", :latitude => "10.02588", :longitude => "-69.24166").save
City.new(:country_id => "238", :name => "Los Dos Caminos", :aliases => "Dos Caminos,Los Dos Caminos,Los Dos Caminos", :latitude => "10.51667", :longitude => "-66.83333").save
City.new(:country_id => "238", :name => "La Victoria", :aliases => ",La Victoria", :latitude => "10.23333", :longitude => "-67.33333").save
City.new(:country_id => "238", :name => "Las Tejerias", :aliases => "Las Tejerias,Las TejerÃ­as,Tejerias,Las TejerÃ­as", :latitude => "10.25", :longitude => "-67.16667").save
City.new(:country_id => "238", :name => "Lagunillas", :aliases => ",Lagunillas", :latitude => "10.14083", :longitude => "-71.26139").save
City.new(:country_id => "238", :name => "La Guaira", :aliases => "La Guaira,La Guayra,raguaira,ã©ã°ã¢ã¤ã©,La Guaira", :latitude => "10.59901", :longitude => "-66.9346").save
City.new(:country_id => "238", :name => "Juan Griego", :aliases => "Juan Griego,Juan Griego", :latitude => "11.08333", :longitude => "-63.95").save
City.new(:country_id => "238", :name => "Guigue", :aliases => ",GÃ¼igÃ¼e", :latitude => "10.08528", :longitude => "-67.77917").save
City.new(:country_id => "238", :name => "Guatire", :aliases => ",Guatire", :latitude => "10.46667", :longitude => "-66.53333").save
City.new(:country_id => "238", :name => "Guarenas", :aliases => "Guarenas,Guarenas", :latitude => "10.46667", :longitude => "-66.61667").save
City.new(:country_id => "238", :name => "Guanare", :aliases => ",Guanare", :latitude => "9.05", :longitude => "-69.75").save
City.new(:country_id => "238", :name => "Guacara", :aliases => "Guacara,Guacara", :latitude => "10.22609", :longitude => "-67.877").save
City.new(:country_id => "238", :name => "El Vigia", :aliases => ",El VigÃ­a", :latitude => "8.61366", :longitude => "-71.65284").save
City.new(:country_id => "238", :name => "El Tocuyo", :aliases => "El Tocuyo,Tocuyo,El Tocuyo", :latitude => "9.78611", :longitude => "-69.78944").save
City.new(:country_id => "238", :name => "El Tigre", :aliases => ",El Tigre", :latitude => "8.88752", :longitude => "-64.24544").save
City.new(:country_id => "238", :name => "El Limon", :aliases => ",El LimÃ³n", :latitude => "10.30589", :longitude => "-67.63212").save
City.new(:country_id => "238", :name => "El Hatillo", :aliases => ",El Hatillo", :latitude => "10.43333", :longitude => "-66.81667").save
City.new(:country_id => "238", :name => "Ejido", :aliases => "Egido,Ehkhido,Ejido,Ð­ÑÐ¸Ð´Ð¾,Ejido", :latitude => "8.55139", :longitude => "-71.2375").save
City.new(:country_id => "238", :name => "Cumana", :aliases => "Cumana,CumanÃ¡,Kumana,ÐÑÐ¼Ð°Ð½Ð°,CumanÃ¡", :latitude => "10.46667", :longitude => "-64.16667").save
City.new(:country_id => "238", :name => "Cua", :aliases => "Cua,CÃºa,Kua,ÐÑÐ°,CÃºa", :latitude => "10.16222", :longitude => "-66.88528").save
City.new(:country_id => "238", :name => "Coro", :aliases => "Coro,Koro,Santa Ana de Coro,korotosono gang,ÐÐ¾ÑÐ¾,ã³ã­ã¨ãã®æ¸¯,Coro", :latitude => "11.4045", :longitude => "-69.67344").save
City.new(:country_id => "238", :name => "Ciudad Guayana", :aliases => "Ciudad Guayana,Ciudad Guiana,Guayana,Guayana City,S'judad-Guajana,San Felix de Guayana,San FÃ©lix de Guayana,San Tome,San Tome de Guayana,San TomÃ©,San TomÃ© de Guayana,Santo Tome de Guayana,Santo Tomo,Santo TomÃ© de Guayana,Ð¡ÑÑÐ´Ð°Ð´-ÐÑÐ°ÑÐ½Ð°,Ciudad Guayana", :latitude => "8.35122", :longitude => "-62.64102").save
City.new(:country_id => "238", :name => "Ciudad Bolivar", :aliases => "Angostura,Bolivar,BolÃ­var,Ciudad Bolivar,Ciudad BolÃ­var,S'judad-Bolivar,Ziuda Bolivar,ZiudÃ¡ BolÃ­var,bo li wa er cheng,Ð¡ÑÑÐ´Ð°Ð´-ÐÐ¾Ð»Ð¸Ð²Ð°Ñ,ã·ã¦ãã»ããªãã«,ç»å©ç¦å°å,Ciudad BolÃ­var", :latitude => "8.12923", :longitude => "-63.54086").save
City.new(:country_id => "238", :name => "Chivacoa", :aliases => "Chivacoa,Chivacoa", :latitude => "10.16028", :longitude => "-68.895").save
City.new(:country_id => "238", :name => "Charallave", :aliases => ",Charallave", :latitude => "10.24833", :longitude => "-66.85667").save
City.new(:country_id => "238", :name => "Chacao", :aliases => ",Chacao", :latitude => "10.5", :longitude => "-66.85").save
City.new(:country_id => "238", :name => "Tacarigua", :aliases => "Central Tacarigua,Central Tacariqua,Tacarigua,Tacarigua", :latitude => "10.08621", :longitude => "-67.91982").save
City.new(:country_id => "238", :name => "Caucaguito", :aliases => "Caucaguita,Caucaguito,CaucagÃ¼ito,CaucagÃ¼ito", :latitude => "10.48333", :longitude => "-66.73333").save
City.new(:country_id => "238", :name => "Catia La Mar", :aliases => "Catia La Mar,Catia de la Mar,Catia La Mar", :latitude => "10.6", :longitude => "-67.03333").save
City.new(:country_id => "238", :name => "Carupano", :aliases => "Carupano,CarÃºpano,CarÃºpano", :latitude => "10.66781", :longitude => "-63.25849").save
City.new(:country_id => "238", :name => "Carrizal", :aliases => "Carrizal,Carrizales,Karrisal',ÐÐ°ÑÑÐ¸ÑÐ°Ð»Ñ,Carrizal", :latitude => "10.35", :longitude => "-66.98333").save
City.new(:country_id => "238", :name => "Carora", :aliases => "Carora,Carora", :latitude => "10.17778", :longitude => "-70.08056").save
City.new(:country_id => "238", :name => "Caracas", :aliases => "Caracae,Caracas,Caraques,Gorad Karakas,Karakas,Karakasa,Karakasas,Karakaso,ka la ka si,kalakaseu,karakas,karakasa,karakasu,kharakas,krakas,kraks,ÎÎ±ÏÎ¬ÎºÎ±Ï,ÐÐ¾ÑÐ°Ð´ ÐÐ°ÑÐ°ÐºÐ°Ñ,ÐÐ°ÑÐ°ÐºÐ°Ñ,Ô¿Õ¡ÖÕ¡Õ¯Õ¡Õ½,×§××¨××§××¡,×§×¨××§×¡,ÙØ±Ø§ÙØ§Ø³,Ú©Ø§Ø±Ø§Ú©Ø§Ø³,Ú©Ø±Ø§Ú©Ø³,à¤à¤¾à¤°à¤¾à¤à¤¾à¤¸,à¦à¦¾à¦°à¦¾à¦à¦¾à¦¸,àªàª¾àª°àª¾àªàª¾àª¸,à²à²°à²¾à²à²¸à³,à¸à¸²à¸£à¸²à¸à¸±à¸ª,à½à¼à½¢à¼à½à¼à½¦à½²,ááá áááá¡á,á«á«á«áµ,ã«ã©ã«ã¹,å¡æå¡æ¯,ì¹´ë¼ì¹´ì¤,Caracas", :latitude => "10.5", :longitude => "-66.91667").save
City.new(:country_id => "238", :name => "Caraballeda", :aliases => ",Caraballeda", :latitude => "10.61667", :longitude => "-66.83333").save
City.new(:country_id => "238", :name => "Cantaura", :aliases => "Cantaura,Cantura,Cantaura", :latitude => "9.30571", :longitude => "-64.35841").save
City.new(:country_id => "238", :name => "Calabozo", :aliases => "Calabozo,Calabozo", :latitude => "8.93444", :longitude => "-67.42667").save
City.new(:country_id => "238", :name => "Cagua", :aliases => "Cagua,Cagua", :latitude => "10.18634", :longitude => "-67.45935").save
City.new(:country_id => "238", :name => "Cabimas", :aliases => "Cabimas,Caramas,Kabimas,ÐÐ°Ð±Ð¸Ð¼Ð°Ñ,Cabimas", :latitude => "10.40194", :longitude => "-71.44611").save
City.new(:country_id => "238", :name => "Baruta", :aliases => "Baruta,Baruta", :latitude => "10.43333", :longitude => "-66.88333").save
City.new(:country_id => "238", :name => "Barquisimeto", :aliases => "Barkisimeto,Barquisimeto,Barquisimito,ÐÐ°ÑÐºÐ¸ÑÐ¸Ð¼ÐµÑÐ¾,Barquisimeto", :latitude => "10.07389", :longitude => "-69.32278").save
City.new(:country_id => "238", :name => "Barinitas", :aliases => ",Barinitas", :latitude => "8.76222", :longitude => "-70.41111").save
City.new(:country_id => "238", :name => "Barcelona", :aliases => "Barcelona,Barselona,ÐÐ°ÑÑÐµÐ»Ð¾Ð½Ð°,Barcelona", :latitude => "10.13333", :longitude => "-64.7").save
City.new(:country_id => "238", :name => "Araure", :aliases => "Araure,Araure", :latitude => "9.56667", :longitude => "-69.21667").save
City.new(:country_id => "238", :name => "Altagracia de Orituco", :aliases => ",Altagracia de Orituco", :latitude => "9.86222", :longitude => "-66.38056").save
City.new(:country_id => "238", :name => "Acarigua", :aliases => "Acarigua,Acarigua", :latitude => "9.55972", :longitude => "-69.20194").save
City.new(:country_id => "238", :name => "Maturin", :aliases => "Maturin,MaturÃ­n,ÐÐ°ÑÑÑÐ¸Ð½,MaturÃ­n", :latitude => "9.75", :longitude => "-63.17667").save
City.new(:country_id => "238", :name => "La Fria", :aliases => ",La FrÃ­a", :latitude => "8.22027", :longitude => "-72.2439").save
City.new(:country_id => "238", :name => "El Cafetal", :aliases => ",El Cafetal", :latitude => "10.46667", :longitude => "-66.82778").save
City.new(:country_id => "238", :name => "Caucaguita", :aliases => ",Caucaguita", :latitude => "10.36111", :longitude => "-66.80833").save
City.new(:country_id => "238", :name => "La Dolorita", :aliases => ",La Dolorita", :latitude => "10.49056", :longitude => "-66.78333").save
City.new(:country_id => "238", :name => "Guasdalito", :aliases => "Guasdalito,Guasdualito,Guasdalito", :latitude => "7.24722", :longitude => "-70.72944").save
City.new(:country_id => "238", :name => "San Fernando Apure", :aliases => "San Fernando Apure,San Fernando de Apure,San Fernando Apure", :latitude => "7.89667", :longitude => "-67.46722").save
