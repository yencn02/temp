City.new(:country_id => "248", :name => "Nchelenge", :aliases => "Nchelenge,ÐÑÐµÐ»ÐµÐ½Ð³Ðµ,Nchelenge", :latitude => "-9.35", :longitude => "28.73333").save
City.new(:country_id => "248", :name => "Mbala", :aliases => "Abercorn,Mbala,ÐÐ±Ð°Ð»Ð°,Mbala", :latitude => "-8.84024", :longitude => "31.36587").save
City.new(:country_id => "248", :name => "Kawambwa", :aliases => "Kawambwa,Kawamowa,Kawambwa", :latitude => "-9.7915", :longitude => "29.07913").save
City.new(:country_id => "248", :name => "Siavonga", :aliases => "Chapvonga,Siavonga,Siavonga", :latitude => "-16.53818", :longitude => "28.70876").save
City.new(:country_id => "248", :name => "Sesheke", :aliases => "Sesheke,Shesheke,Sisheke,Ð¨ÐµÑÐµÐºÐµ,Sesheke", :latitude => "-17.46667", :longitude => "24.3").save
City.new(:country_id => "248", :name => "Samfya", :aliases => "Samfya,Samfya", :latitude => "-11.36491", :longitude => "29.55652").save
City.new(:country_id => "248", :name => "Petauke", :aliases => "Petauke,Petauke", :latitude => "-14.24264", :longitude => "31.3253").save
City.new(:country_id => "248", :name => "Ndola", :aliases => "Ndola,ÐÐ´Ð¾Ð»Ð°,Ndola", :latitude => "-12.95867", :longitude => "28.63659").save
City.new(:country_id => "248", :name => "Mumbwa", :aliases => ",Mumbwa", :latitude => "-14.97832", :longitude => "27.06188").save
City.new(:country_id => "248", :name => "Mufulira", :aliases => "Mufulira,Mufulire,ÐÑÑÑÐ»Ð¸ÑÐµ,Mufulira", :latitude => "-12.55", :longitude => "28.23333").save
City.new(:country_id => "248", :name => "Mpika", :aliases => "Mpika,Mpika", :latitude => "-11.83431", :longitude => "31.45287").save
City.new(:country_id => "248", :name => "Monze", :aliases => "Monze,Monze", :latitude => "-16.28333", :longitude => "27.48333").save
City.new(:country_id => "248", :name => "Mongu", :aliases => "Mongu,Mungu,ÐÐ¾Ð½Ð³Ñ,Mongu", :latitude => "-15.24835", :longitude => "23.12741").save
City.new(:country_id => "248", :name => "Mazabuka", :aliases => "Mazabuka,ÐÐ°Ð·Ð°Ð±ÑÐºÐ°,Mazabuka", :latitude => "-15.85601", :longitude => "27.748").save
City.new(:country_id => "248", :name => "Mansa", :aliases => "Fort Rosebery,Mansa,Mbila,Roseberry,ÐÐ°Ð½ÑÐ°,Mansa", :latitude => "-11.19976", :longitude => "28.89431").save
City.new(:country_id => "248", :name => "Lusaka", :aliases => "Lousaka,Lusaka,Lusako,LÃºsaka,lu sha ka,lusaka,lwsaka,lwsqh,rusaka,ÎÎ¿ÏÏÎ¬ÎºÎ±,ÐÑÑÐ°ÐºÐ°,×××¡×§×,ÙÙØ³Ø§Ú©Ø§,áá³á«,ã«ãµã«,è·¯æ²å¡,ë£¨ì¬ì¹´,Lusaka", :latitude => "-15.40809", :longitude => "28.28636").save
City.new(:country_id => "248", :name => "Luanshya", :aliases => "Luanshya,Luanshyo,Luanshya", :latitude => "-13.13667", :longitude => "28.41661").save
City.new(:country_id => "248", :name => "Livingstone", :aliases => "Livingston,Livingstone,Livingstore,Maramba,ÐÐ¸Ð²Ð¸Ð½Ð³ÑÑÐ¾Ð½,Livingstone", :latitude => "-17.84221", :longitude => "25.86336").save
City.new(:country_id => "248", :name => "Kitwe", :aliases => "Kitve,Kitwe,Kitwe Nkana,Nkana-Kitwe,kitou~e,ÐÐ¸ÑÐ²Ðµ,ã­ãã¦ã§,Kitwe", :latitude => "-12.81667", :longitude => "28.2").save
City.new(:country_id => "248", :name => "Kasama", :aliases => "Arcidiocesi di Kasama,Kasama,ÐÐ°ÑÐ°Ð¼Ð°,Kasama", :latitude => "-10.21289", :longitude => "31.18084").save
City.new(:country_id => "248", :name => "Kapiri Mposhi", :aliases => "Kapiri Imposhi,Kapiri Mposhi,Kapiri Mposhi", :latitude => "-13.96518", :longitude => "28.68086").save
City.new(:country_id => "248", :name => "Kansanshi", :aliases => "Kansanshi,Kansanshi Mine,Kansenshi,Kansanshi", :latitude => "-12.1", :longitude => "26.43333").save
City.new(:country_id => "248", :name => "Kalulushi", :aliases => "Kalulshi,Kalulushi,Kalulushi", :latitude => "-12.83333", :longitude => "28.08333").save
City.new(:country_id => "248", :name => "Kafue", :aliases => "Kafe,Kafue,ÐÐ°ÑÐµ,Kafue", :latitude => "-15.76911", :longitude => "28.18136").save
City.new(:country_id => "248", :name => "Kabwe", :aliases => "Broken Hill,Kabve,Kabwe,ÐÐ°Ð±Ð²Ðµ,Kabwe", :latitude => "-14.44322", :longitude => "28.45174").save
City.new(:country_id => "248", :name => "Choma", :aliases => "Choma,Choma", :latitude => "-16.81667", :longitude => "26.98333").save
City.new(:country_id => "248", :name => "Chipata", :aliases => "Chipata,Fort Jameson,Ð§Ð¸Ð¿Ð°ÑÐ°,Chipata", :latitude => "-13.63333", :longitude => "32.65").save
City.new(:country_id => "248", :name => "Chingola", :aliases => "Chingola,Ð§Ð¸Ð½Ð³Ð¾Ð»Ð°,Chingola", :latitude => "-12.53333", :longitude => "27.85").save
City.new(:country_id => "248", :name => "Chililabombwe", :aliases => "Bancroft,Chilabombwe,Chiliabombwe,Chiliadomewe,Chililabombwe,Chililabombwe", :latitude => "-12.36667", :longitude => "27.83333").save
