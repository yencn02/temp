City.new(:country_id => "76", :name => "Yerres", :aliases => "Jerre,Yerres,ierr,ÐÐµÑÑ,ÐÐµÑÑÐµ,Yerres", :latitude => "48.71667", :longitude => "2.5").save
City.new(:country_id => "76", :name => "Wittenheim", :aliases => "Wittenheim,Wittenheim", :latitude => "47.81667", :longitude => "7.33333").save
City.new(:country_id => "76", :name => "Wattrelos", :aliases => "Wattrelos,Wattrelos", :latitude => "50.7", :longitude => "3.21667").save
City.new(:country_id => "76", :name => "Wasquehal", :aliases => "Wasquehal,Wasquehal", :latitude => "50.66667", :longitude => "3.15").save
City.new(:country_id => "76", :name => "Voiron", :aliases => "Voiron,Voiron", :latitude => "45.36667", :longitude => "5.58333").save
City.new(:country_id => "76", :name => "Vitry-sur-Seine", :aliases => "Port-de-Marat,Vitri-sjur-Sen,Vitry,Vitry-sur-Seine,ÐÐ¸ÑÑÐ¸-ÑÑÑ-Ð¡ÐµÐ½,Vitry-sur-Seine", :latitude => "48.78333", :longitude => "2.4").save
City.new(:country_id => "76", :name => "Vitry-le-Francois", :aliases => "Vitri-le-Fransua,Vitry-le-Francois,Vitry-le-FranÃ§ois,Vitry-sur-Marne,ÐÐ¸ÑÑÐ¸-Ð»Ðµ-Ð¤ÑÐ°Ð½ÑÑÐ°,Vitry-le-FranÃ§ois", :latitude => "48.73333", :longitude => "4.58333").save
City.new(:country_id => "76", :name => "Vitrolles", :aliases => "Vitrol',Vitrolles,ÐÐ¸ÑÑÐ¾Ð»Ñ,Vitrolles", :latitude => "43.46", :longitude => "5.24861").save
City.new(:country_id => "76", :name => "Vitre", :aliases => "Bitre,Gwitreg,Vitre,Vitreh,VitrÃ©,fytry,vu~itore,wei te lei,ÎÎ¹ÏÏÎ­,ÐÐ¸ÑÑÑ,ÙÙØªØ±Ù,ã´ã£ãã¬,ç»´ç¹é·,VitrÃ©", :latitude => "48.13333", :longitude => "-1.2").save
City.new(:country_id => "76", :name => "Viry-Chatillon", :aliases => "Viri-Shatillon,Viry,Viry-Chatillon,Viry-ChÃ¢tillon,ÐÐ¸ÑÐ¸-Ð¨Ð°ÑÐ¸Ð»Ð»Ð¾Ð½,Viry-ChÃ¢tillon", :latitude => "48.66667", :longitude => "2.38333").save
City.new(:country_id => "76", :name => "Viroflay", :aliases => "Viroflay,Viroflay", :latitude => "48.8", :longitude => "2.16667").save
City.new(:country_id => "76", :name => "Vincennes", :aliases => "Vincennes,Vincennes", :latitude => "48.85", :longitude => "2.43333").save
City.new(:country_id => "76", :name => "Villiers-sur-Marne", :aliases => "Vil'e-sjur-Marn,Villiers,Villiers-sur-Marne,ÐÐ¸Ð»ÑÐµ-ÑÑÑ-ÐÐ°ÑÐ½,Villiers-sur-Marne", :latitude => "48.83333", :longitude => "2.55").save
City.new(:country_id => "76", :name => "Villiers-le-Bel", :aliases => "Vil'e-le-Bel',Villiers,Villiers-le-Bel,ÐÐ¸Ð»ÑÐµ-Ð»Ðµ-ÐÐµÐ»Ñ,Villiers-le-Bel", :latitude => "49.00875", :longitude => "2.39819").save
City.new(:country_id => "76", :name => "Villeurbanne", :aliases => "Villerban,Villeurbanne,ÐÐ¸Ð»Ð»ÐµÑÐ±Ð°Ð½,Villeurbanne", :latitude => "45.76667", :longitude => "4.88333").save
City.new(:country_id => "76", :name => "Villers-les-Nancy", :aliases => "Villers,Villers-les-Nancy,Villers-lÃ¨s-Nancy,Villers-lÃ¨s-Nancy", :latitude => "48.66667", :longitude => "6.15").save
City.new(:country_id => "76", :name => "Villepinte", :aliases => "Villepinte,Villepinte", :latitude => "48.96203", :longitude => "2.53253").save
City.new(:country_id => "76", :name => "Villeparisis", :aliases => "Vil'parizi,Villeparisis,ÐÐ¸Ð»ÑÐ¿Ð°ÑÐ¸Ð·Ð¸,Villeparisis", :latitude => "48.94208", :longitude => "2.61463").save
City.new(:country_id => "76", :name => "Villeneuve-sur-Lot", :aliases => "Vil'nev-sjur-Lo,Villeneuve,Villeneuve-sur-Lot,ÐÐ¸Ð»ÑÐ½ÐµÐ²-ÑÑÑ-ÐÐ¾,Villeneuve-sur-Lot", :latitude => "44.4", :longitude => "0.71667").save
City.new(:country_id => "76", :name => "Villeneuve-Saint-Georges", :aliases => "Villeneuve,Villeneuve-Saint-Georges,Villeneuve-la-Montagne,Villeneuve-Saint-Georges", :latitude => "48.73333", :longitude => "2.45").save
City.new(:country_id => "76", :name => "Villeneuve-le-Roi", :aliases => "Villeneuve,Villeneuve-le-Roi,Villeneuve-sur-Seine,Villeneuve-le-Roi", :latitude => "48.73333", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Villeneuve-la-Garenne", :aliases => "Villeneuve,Villeneuve-la-Garenne,Villeneuve-la-Garenne", :latitude => "48.93935", :longitude => "2.31478").save
City.new(:country_id => "76", :name => "Villenave-d'Ornon", :aliases => "Vilanava,Villenave,Villenave-d'Ornon,Villenave-d'Ornon", :latitude => "44.76667", :longitude => "-0.55").save
City.new(:country_id => "76", :name => "Villemomble", :aliases => "Villemomble,Villemonble,Villemomble", :latitude => "48.88333", :longitude => "2.5").save
City.new(:country_id => "76", :name => "Villejuif", :aliases => "Villejuif,Villejuif", :latitude => "48.8", :longitude => "2.36667").save
City.new(:country_id => "76", :name => "Villefranche-sur-Saone", :aliases => "Commune-Franche,Vil'fransh-sjur-Son,Ville-Libre-sur-Saone,Ville-Libre-sur-SaÃ´ne,Villefranche,Villefranche sobre Saona,Villefranche-sur-Saone,Villefranche-sur-SaÃ´ne,ÐÐ¸Ð»ÑÑÑÐ°Ð½Ñ-ÑÑÑ-Ð¡Ð¾Ð½,Villefranche-sur-SaÃ´ne", :latitude => "45.98333", :longitude => "4.71667").save
City.new(:country_id => "76", :name => "Villefontaine", :aliases => "Villefontaine,Villefontaine", :latitude => "45.61667", :longitude => "5.15").save
City.new(:country_id => "76", :name => "Vigneux-sur-Seine", :aliases => "Vigneux,Vigneux-sur-Seine,Vigneux-sur-Seine", :latitude => "48.7", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Vierzon", :aliases => "V'erzon,Vierzon,Vierzon-Ville,ÐÑÐµÑÐ·Ð¾Ð½,Vierzon", :latitude => "47.21667", :longitude => "2.08333").save
City.new(:country_id => "76", :name => "Vienne", :aliases => "V'enn,Viana,Viena,Viena del Delfinat,Vienne,Vienne-la-Patriote,ViÃ¨na,ÐÑÐµÐ½Ð½,Vienne", :latitude => "45.51667", :longitude => "4.86667").save
City.new(:country_id => "76", :name => "Vichy", :aliases => "Vishi,ÐÐ¸ÑÐ¸,Vichy", :latitude => "46.11667", :longitude => "3.41667").save
City.new(:country_id => "76", :name => "Vesoul", :aliases => "Vesoul,vuzu,ã´ãºã¼,Vesoul", :latitude => "47.63333", :longitude => "6.16667").save
City.new(:country_id => "76", :name => "Vertou", :aliases => "Gwerzhav,Vertou,Vertou", :latitude => "47.16667", :longitude => "-1.48333").save
City.new(:country_id => "76", :name => "Versailles", :aliases => "Berceau-de-la-Liberte,Berceau-de-la-LibertÃ©,Bersallies,Versailles,Versaj,Versajlo,Versal',Versalhes,Versalia,Versaliae,Versalis,Versalles,Wersal,beleusayu,vu~erusaiyu,ÎÎµÏÏÎ±Î»Î»Î¯ÎµÏ,ÐÐµÑÑÐ°Ð¹,ÐÐµÑÑÐ°Ð»Ñ,××¨×¡××,ã´ã§ã«ãµã¤ã¦,ë² ë¥´ì¬ì ,Versailles", :latitude => "48.8", :longitude => "2.13333").save
City.new(:country_id => "76", :name => "Verrieres-le-Buisson", :aliases => "Verrieres,Verrieres-le-Buisson,VerriÃ¨res,VerriÃ¨res-le-Buisson,VerriÃ¨res-le-Buisson", :latitude => "48.75", :longitude => "2.26667").save
City.new(:country_id => "76", :name => "Vernon", :aliases => "Vernon,Vernon", :latitude => "49.09292", :longitude => "1.46332").save
City.new(:country_id => "76", :name => "Verneuil-sur-Seine", :aliases => "Verneuil,Verneuil-sur-Seine", :latitude => "48.97388", :longitude => "1.9648").save
City.new(:country_id => "76", :name => "Verdun", :aliases => "Verdan,Verden,Verdun-sur-Meuse,vu~erudan,ÐÐµÑÐ´Ð°Ð½,ÐÐµÑÐ´ÐµÐ½,ã´ã§ã«ãã³,Verdun", :latitude => "49.16667", :longitude => "5.38333").save
City.new(:country_id => "76", :name => "Venissieux", :aliases => "Venis'e,Venissieux,VÃ©nissieux,ÐÐµÐ½Ð¸ÑÑÐµ,VÃ©nissieux", :latitude => "45.68333", :longitude => "4.88333").save
City.new(:country_id => "76", :name => "Vendome", :aliases => "Vendome-Regenere,VendÃ´me-RegÃ©nÃ©rÃ©,VendÃ´me", :latitude => "47.8", :longitude => "1.06667").save
City.new(:country_id => "76", :name => "Vence", :aliases => "Vence,Vence", :latitude => "43.71667", :longitude => "7.11667").save
City.new(:country_id => "76", :name => "Velizy-Villacoublay", :aliases => "Velizy,Velizy-Villacoublay,Villacoublay,VÃ©lizy,VÃ©lizy-Villacoublay,VÃ©lizy-Villacoublay", :latitude => "48.8", :longitude => "2.18333").save
City.new(:country_id => "76", :name => "Vaureal", :aliases => "Lieux,Vaureal,VaurÃ©al,VaurÃ©al", :latitude => "49.03333", :longitude => "2.03333").save
City.new(:country_id => "76", :name => "Vaulx-en-Velin", :aliases => "Vaulx,Vaulx-en-Velin,Vaulx-en-Velin", :latitude => "45.78333", :longitude => "4.93333").save
City.new(:country_id => "76", :name => "Vanves", :aliases => "Vanves,Vanves", :latitude => "48.83333", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Vannes", :aliases => "Gwened,Vann,Vannes,Venetens,vu~an'nu,ÐÐ°Ð½Ð½,ã´ã¡ã³ã,Vannes", :latitude => "47.66667", :longitude => "-2.75").save
City.new(:country_id => "76", :name => "Vandoeuvre-les-Nancy", :aliases => "Vandoeuvre,VandÅuvre-lÃ¨s-Nancy", :latitude => "48.65", :longitude => "6.18333").save
City.new(:country_id => "76", :name => "Vallauris", :aliases => "Vallauris,Vallauris", :latitude => "43.58333", :longitude => "7.05").save
City.new(:country_id => "76", :name => "Valenciennes", :aliases => "Valans'en,Valansien,Valenciennes,wa lang xie ne,ÐÐ°Ð»Ð°Ð½ÑÐ¸ÐµÐ½,ÐÐ°Ð»Ð°Ð½ÑÑÐµÐ½,×××× ×¡×××,ç¦æè¬è¨¥,Valenciennes", :latitude => "50.35", :longitude => "3.53333").save
City.new(:country_id => "76", :name => "Valence", :aliases => "Valenca,Valence,Valencia,ValenÃ§a,valansa,vu~aransu,à¤µà¤²à¤¾à¤à¤¸,ã´ã¡ã©ã³ã¹,Valence", :latitude => "44.93333", :longitude => "4.9").save
City.new(:country_id => "76", :name => "Tulle", :aliases => "Tjul',Tula,Tulle,Tyll,churu,Ð¢ÑÐ»Ñ,ãã¥ã¼ã«,Tulle", :latitude => "45.26667", :longitude => "1.76667").save
City.new(:country_id => "76", :name => "Troyes", :aliases => "Troyes,Trua,te lu wa,torowa,trwa,Ð¢ÑÑÐ°,ØªØ±ÙØ§,ãã­ã¯,ç¹é²ç¦,Troyes", :latitude => "48.3", :longitude => "4.08333").save
City.new(:country_id => "76", :name => "Tremblay-en-France", :aliases => "Tremblay-sans-Culottes,Tremblay-en-France", :latitude => "48.94956", :longitude => "2.5684").save
City.new(:country_id => "76", :name => "Trappes", :aliases => "Trappes,Trappes", :latitude => "48.78333", :longitude => "2").save
City.new(:country_id => "76", :name => "Tours", :aliases => "Augusta-Turonum,La Reunion-du-Nord,La RÃ©union-du-Nord,Tours,Tur,Turonum,to~uru,tu er,twr,Ð¢ÑÑ,×××¨,ãã¥ã¼ã«,å¾å°,Tours", :latitude => "47.38333", :longitude => "0.68333").save
City.new(:country_id => "76", :name => "Tournefeuille", :aliases => "Brumaire,Frimaire,Fructidor,Germinal,Messidor,Nivose,NivÃ´se,Prairial,Tournefeuille,Vendemiaire,VendÃ©miaire,Ventose,VentÃ´se,Tournefeuille", :latitude => "43.58872", :longitude => "1.31922").save
City.new(:country_id => "76", :name => "Tourlaville", :aliases => "Tourlaville,Tourlaville", :latitude => "49.63333", :longitude => "-1.56667").save
City.new(:country_id => "76", :name => "Tourcoing", :aliases => "Toerkonje,Tourcoing,Turcundium,to~urukowan,ãã¥ã¼ã«ã³ã¯ã³,Tourcoing", :latitude => "50.71667", :longitude => "3.15").save
City.new(:country_id => "76", :name => "Toulouse", :aliases => "Tolosa,Tolosa de Francia,Tolosa de Llenguadoc,Toulouse,Tuluz,Tuluza,Tuluzo,TulÅ«za,to~uruzu,tu lu zi,tullujeu,twlwz,Ð¢ÑÐ»ÑÐ·,Ð¢ÑÐ»ÑÐ·Ð°,×××××,ØªÙÙÙØ²,ãã¥ã¼ã«ã¼ãº,åç§è²,í´ë£¨ì¦,Toulouse", :latitude => "43.60426", :longitude => "1.44367").save
City.new(:country_id => "76", :name => "Toulon", :aliases => "Port-la-Montagne,Telo Martius,Tolo,Tolon,Tolone,TolÃ³,TolÃ³n,Toulon,Toulon-sur-Mer,Tulon,to~uron,tu lun,tulom,twlwn,Ð¢ÑÐ»Ð¾Ð½,×××××,Ø·ÙÙÙÙ,à¤¤à¥à¤²à¥à¤,ãã¥ã¼ã­ã³,åä¼¦,Toulon", :latitude => "43.11667", :longitude => "5.93333").save
City.new(:country_id => "76", :name => "Toul", :aliases => "La Moselle,La Paix,Toul,Tul',Ð¢ÑÐ»Ñ,Toul", :latitude => "48.68333", :longitude => "5.9").save
City.new(:country_id => "76", :name => "Torcy", :aliases => ",Torcy", :latitude => "48.85", :longitude => "2.65").save
City.new(:country_id => "76", :name => "Thonon-les-Bains", :aliases => "Thonon,Thonon-les-Bains,Tonon-le-Ben,Ð¢Ð¾Ð½Ð¾Ð½-Ð»Ðµ-ÐÐµÐ½,Thonon-les-Bains", :latitude => "46.36667", :longitude => "6.48333").save
City.new(:country_id => "76", :name => "Thionville", :aliases => "Diddenuewen,Diedenhofen,Thionville,Thionville", :latitude => "49.36667", :longitude => "6.16667").save
City.new(:country_id => "76", :name => "Thiais", :aliases => "Thiais,Thiais", :latitude => "48.76667", :longitude => "2.38333").save
City.new(:country_id => "76", :name => "Tergnier", :aliases => "Tergnier,Tergnier", :latitude => "49.65607", :longitude => "3.30107").save
City.new(:country_id => "76", :name => "Taverny", :aliases => "Taverny,Taverny", :latitude => "49.02542", :longitude => "2.21691").save
City.new(:country_id => "76", :name => "Tassin-la-Demi-Lune", :aliases => "Tassin,Tassin la Demi Lena,Tassin-la-Demi-Lune,Tassin-la-Lune,Tassin-la-LÃ»ne,Tassin-la-Demi-Lune", :latitude => "45.76667", :longitude => "4.78333").save
City.new(:country_id => "76", :name => "Tarbes", :aliases => "Tarba,Tarbes,tarubu,ã¿ã«ã,Tarbes", :latitude => "43.23333", :longitude => "0.08333").save
City.new(:country_id => "76", :name => "Talence", :aliases => "Talenca,Talence,TalenÃ§a,Talence", :latitude => "44.81667", :longitude => "-0.6").save
City.new(:country_id => "76", :name => "Suresnes", :aliases => "Siren,Sjuren,Suresnes,Ð¡Ð¸ÑÐµÐ½,Ð¡ÑÑÐµÐ½,Suresnes", :latitude => "48.87143", :longitude => "2.22929").save
City.new(:country_id => "76", :name => "Sucy-en-Brie", :aliases => "Sucy,Sucy-en-Brie,Sucy-en-Brie", :latitude => "48.76667", :longitude => "2.53333").save
City.new(:country_id => "76", :name => "Strasbourg", :aliases => "Argentoratum,Estrasburg,Estrasburgo,Estrasburgo - Strasbourg,Lungsod ng Strasbourg,Straatsburg,Strasborg,Strasbourg,Strasbourgo,Strasbura,Strasburas,Strasburg,Strasburgo,Strasburgu,Strasburk,StrasbÃ´rg,StrasbÅ«ra,StrasbÅ«ras,Strassborg,Strassbourg,Strassburg,Straszburg,Strazbur,Strazburg,StraÃburg,Stroossbuerg,seuteulaseubuleu,si te la si bao,strasabarga,strasbwrgh,strsbwrg,sutorasuburu,Å trasburg,Å trasburk,Î£ÏÏÎ±ÏÎ²Î¿ÏÏÎ³Î¿,Ð¡ÑÑÐ°Ð·Ð±ÑÑ,Ð¡ÑÑÐ°ÑÐ±ÑÑÐ³,×©××¨×¡×××¨×,Ø³ØªØ±Ø§Ø³Ø¨ÙØ±Øº,à¤¸à¥à¤à¥à¤°à¤¾à¤¸à¤¬à¤°à¥à¤,ã¹ãã©ã¹ãã¼ã«,æ¯ç¹ææ¯å ¡,ì¤í¸ë¼ì¤ë¶ë¥´,Strasbourg", :latitude => "48.58342", :longitude => "7.74296").save
City.new(:country_id => "76", :name => "Stains", :aliases => "Stains,Stains", :latitude => "48.95", :longitude => "2.38333").save
City.new(:country_id => "76", :name => "Sotteville-les-Rouen", :aliases => "Sottevil'-le-Ruan,Sotteville,Sotteville-les-Rouen,Sotteville-lÃ¨s-Rouen,Sottville-les-Rouen,Ð¡Ð¾ÑÑÐµÐ²Ð¸Ð»Ñ-Ð»Ðµ-Ð ÑÐ°Ð½,Sotteville-lÃ¨s-Rouen", :latitude => "49.40972", :longitude => "1.09006").save
City.new(:country_id => "76", :name => "Sorgues", :aliases => "Sorgues,Sorgues", :latitude => "44.01023", :longitude => "4.87381").save
City.new(:country_id => "76", :name => "Soisy-sous-Montmorency", :aliases => "Emile,Mont-Emile,Soisy,Soisy-sous-Montmorency,Soisy-sous-Montmorency", :latitude => "48.98813", :longitude => "2.30156").save
City.new(:country_id => "76", :name => "Soissons", :aliases => "Soissons,Suasson,sowason,Ð¡ÑÐ°ÑÑÐ¾Ð½,ã½ã¯ã½ã³,Soissons", :latitude => "49.38167", :longitude => "3.32361").save
City.new(:country_id => "76", :name => "Six-Fours-les-Plages", :aliases => "Six Fours,Six-Fours-les-Plages", :latitude => "43.1", :longitude => "5.85").save
City.new(:country_id => "76", :name => "Sin-le-Noble", :aliases => "Sin,Sin-le-Noble,Sin-les-Douai,Sin-lÃ¨s-Douai,Sin-le-Noble", :latitude => "50.36667", :longitude => "3.11667").save
City.new(:country_id => "76", :name => "Seynod", :aliases => "Seynod,Seynod", :latitude => "45.88333", :longitude => "6.08333").save
City.new(:country_id => "76", :name => "Sevres", :aliases => "Sevr,Sevres,SÃ¨vres,sebeuleu,sevuru,Ð¡ÐµÐ²Ñ,ã»ã¼ã´ã«,ì¸ë¸ë¥´,SÃ¨vres", :latitude => "48.81667", :longitude => "2.2").save
City.new(:country_id => "76", :name => "Sevran", :aliases => "Sevran,Sevran", :latitude => "48.94472", :longitude => "2.52746").save
City.new(:country_id => "76", :name => "Sete", :aliases => "Cette,Set,Sete,SÃ¨te,Ð¡ÐµÑ,SÃ¨te", :latitude => "43.40176", :longitude => "3.6966").save
City.new(:country_id => "76", :name => "Sens", :aliases => "Agedincum,Sens,Sens-sur-Yonne,Sens", :latitude => "48.2", :longitude => "3.28333").save
City.new(:country_id => "76", :name => "Senlis", :aliases => "Senlis,Senlis", :latitude => "49.2", :longitude => "2.58333").save
City.new(:country_id => "76", :name => "Selestat", :aliases => "Schlestadt,Schlettstadt,Selestat,SÃ©lestat,SÃ©lestat", :latitude => "48.26667", :longitude => "7.45").save
City.new(:country_id => "76", :name => "Sedan", :aliases => "Sedan,sudan,Ð¡ÐµÐ´Ð°Ð½,ã¹ãã³,Sedan", :latitude => "49.7", :longitude => "4.95").save
City.new(:country_id => "76", :name => "Schiltigheim", :aliases => "Schiltigheim,Schiltighein,schilfigheim,Schiltigheim", :latitude => "48.60749", :longitude => "7.74931").save
City.new(:country_id => "76", :name => "Sceaux", :aliases => "Sceaux,Sceaux-l'Unite,Sceaux-l'UnitÃ©,Sceaux", :latitude => "48.78333", :longitude => "2.28333").save
City.new(:country_id => "76", :name => "Savigny-sur-Orge", :aliases => "Savigny,Savigny-sur-Orge,Savigny-sur-Orge", :latitude => "48.66667", :longitude => "2.35").save
City.new(:country_id => "76", :name => "Savigny-le-Temple", :aliases => "Savigny,Savigny-le-Port,Savigny-le-Temple,Savigny-sur-Balory,Savin'i-le-khram,Ð¡Ð°Ð²Ð¸Ð½ÑÐ¸-Ð»Ðµ-ÑÑÐ°Ð¼,Savigny-le-Temple", :latitude => "48.56667", :longitude => "2.58333").save
City.new(:country_id => "76", :name => "Saumur", :aliases => "Saumur,Somjur,somyuru,Ð¡Ð¾Ð¼ÑÑ,ã½ãã¥ã¼ã«,Saumur", :latitude => "47.26667", :longitude => "-0.08333").save
City.new(:country_id => "76", :name => "Sartrouville", :aliases => "Sartrouville,Sartrouville", :latitude => "48.9482", :longitude => "2.19169").save
City.new(:country_id => "76", :name => "Sarreguemines", :aliases => "Saargemines,Saargemuend,Saargemund,SaargemÃ¼nd,Sargemin,Sarreguemines,Sarrequemines,saruguminu,Ð¡Ð°ÑÐ³ÐµÐ¼Ð¸Ð½,ãµã«ã°ãã¼ã,Sarreguemines", :latitude => "49.10995", :longitude => "7.06747").save
City.new(:country_id => "76", :name => "Sarcelles", :aliases => "Sarcelles,Sarcelles-Lochere,Sarcelles-LochÃ¨re,Sarsel',Ð¡Ð°ÑÑÐµÐ»Ñ,Sarcelles", :latitude => "49", :longitude => "2.38333").save
City.new(:country_id => "76", :name => "Saran", :aliases => "Saran,Saran", :latitude => "47.95", :longitude => "1.88333").save
City.new(:country_id => "76", :name => "Sannois", :aliases => "Sannois,Sannois", :latitude => "48.96667", :longitude => "2.25").save
City.new(:country_id => "76", :name => "Sanary-sur-Mer", :aliases => "Sanary,Sanary-sur-Mer,Sanary-sur-Mer", :latitude => "43.11667", :longitude => "5.8").save
City.new(:country_id => "76", :name => "Salon-de-Provence", :aliases => "Salon,Salon-de-Provans,Salon-de-Provence,saron=do=purovu~ansu,Ð¡Ð°Ð»Ð¾Ð½-Ð´Ðµ-ÐÑÐ¾Ð²Ð°Ð½Ñ,ãµã­ã³ï¼ãï¼ãã­ã´ã¡ã³ã¹,Salon-de-Provence", :latitude => "43.63333", :longitude => "5.1").save
City.new(:country_id => "76", :name => "Sallanches", :aliases => ",Sallanches", :latitude => "45.94423", :longitude => "6.63162").save
City.new(:country_id => "76", :name => "Saint-Sebastien-sur-Loire", :aliases => "Saint-Sebastien,Saint-Sebastien-sur-Loire,Saint-SÃ©bastien,Saint-SÃ©bastien-sur-Loire,San Sebastian sobre Loira,San SebastiÃ¡n sobre Loira,Sankt-Sebast'jan-sjur-Luar,Sant-Sebastian-an-Enk,Ð¡Ð°Ð½ÐºÑ-Ð¡ÐµÐ±Ð°ÑÑÑÑÐ½-ÑÑÑ-ÐÑÐ°Ñ,Saint-SÃ©bastien-sur-Loire", :latitude => "47.20768", :longitude => "-1.50332").save
City.new(:country_id => "76", :name => "Saint-Raphael", :aliases => "Barraton,Saint Raphell,Saint-Raphael,Saint-RaphaÃ«l,Sent-Rafaehl',Ð¡ÐµÐ½Ñ-Ð Ð°ÑÐ°ÑÐ»Ñ,Saint-RaphaÃ«l", :latitude => "43.42332", :longitude => "6.7735").save
City.new(:country_id => "76", :name => "Saint-Quentin", :aliases => "Egalite-sur-Somme,EgalitÃ©-sur-Somme,Linon-sur-Somme,Saint-Quentin,Somme-Libre,Saint-Quentin", :latitude => "49.84889", :longitude => "3.28757").save
City.new(:country_id => "76", :name => "Saint-Priest", :aliases => "Beau-Priest,Saint-Priest,Zele-Patriote,ZÃ©lÃ©-Patriote,Saint-Priest", :latitude => "45.7", :longitude => "4.95").save
City.new(:country_id => "76", :name => "Saint-Pol-sur-Mer", :aliases => "Saint-Pol,Saint-Pol-sur-Mer,Sen-Pol'-sjur-Mer,Ð¡ÐµÐ½-ÐÐ¾Ð»Ñ-ÑÑÑ-ÐÐµÑ,Saint-Pol-sur-Mer", :latitude => "51.03116", :longitude => "2.33984").save
City.new(:country_id => "76", :name => "Saint-Pierre-des-Corps", :aliases => "La Clarte-Republicaine,La ClartÃ©-RÃ©publicaine,Saint-Pierre,Saint-Pierre-des-Corps,Saint-Pierre-des-Corps", :latitude => "47.38623", :longitude => "0.74849").save
City.new(:country_id => "76", :name => "Saint-Ouen-l'Aumone", :aliases => "L'Aumone-la-Montagne,L'AumÃ´ne-la-Montagne,Montagne-sur-Oise,Saint-Ouen-l'Aumone,Saint-Ouen-l'AumÃ´ne,Saint-Ouen-l'AumÃ´ne", :latitude => "49.04353", :longitude => "2.12134").save
City.new(:country_id => "76", :name => "Saint-Ouen", :aliases => "Bain-sur-Seine,Saint-Ouen,Saint-Ouen-sur-Seine,Sankt-Ouehn,Ð¡Ð°Ð½ÐºÑ-ÐÑÑÐ½,Saint-Ouen", :latitude => "48.9", :longitude => "2.33333").save
City.new(:country_id => "76", :name => "Saint-Omer", :aliases => "Saint-Omer,Sint-Omaars,Saint-Omer", :latitude => "50.75", :longitude => "2.25").save
City.new(:country_id => "76", :name => "Saint-Nazaire", :aliases => "Saint-Nazaire,Sant-Nazer,Sen-Nazer,Ð¡ÐµÐ½-ÐÐ°Ð·ÐµÑ,Saint-Nazaire", :latitude => "47.28333", :longitude => "-2.2").save
City.new(:country_id => "76", :name => "Saint-Michel-sur-Orge", :aliases => "Saint-Michel,Saint-Michel-sur-Orge,Saint-Michel-sur-Orge", :latitude => "48.63333", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Saint-Medard-en-Jalles", :aliases => "Fulminant,Saint-Medard,Saint-Medard-en-Jalles,Saint-MÃ©dard,Saint-MÃ©dard-en-Jalles,Sankt-Medard-an-Zhall',Sent Medard,Ð¡Ð°Ð½ÐºÑ-ÐÐµÐ´Ð°ÑÐ´-Ð°Ð½-ÐÐ°Ð»Ð»Ñ,Saint-MÃ©dard-en-Jalles", :latitude => "44.9", :longitude => "-0.73333").save
City.new(:country_id => "76", :name => "Saint-Maximin-la-Sainte-Baume", :aliases => "Marathon,Saint-Maximin,Saint-Maximin-la-Sainte-Baume,Saint-Maximin-la-Sainte-Baume", :latitude => "43.45", :longitude => "5.86667").save
City.new(:country_id => "76", :name => "Saint-Maur-des-Fosses", :aliases => "Saint-Maur,Saint-Maur-des-Fosses,Saint-Maur-des-FossÃ©s,Saint-Maur-les-Fosses,Saint-Maur-les-FossÃ©s,Vivant-sur-Marne,Saint-Maur-des-FossÃ©s", :latitude => "48.8", :longitude => "2.5").save
City.new(:country_id => "76", :name => "Saint-Martin-d'Heres", :aliases => "Heres-la-Montagne,HÃ¨res-la-Montagne,Saint-Martin,Saint-Martin-d'Heres,Saint-Martin-d'HÃ¨res,Saint-Martin-d'HÃ¨res", :latitude => "45.16528", :longitude => "5.76337").save
City.new(:country_id => "76", :name => "Saint-Mande", :aliases => "Saint-Mande,Saint-MandÃ©,Sankt-Mande,Sant Manden,st Mande,st MandÃ©,st mande,Ð¡Ð°Ð½ÐºÑ-ÐÐ°Ð½Ð´Ðµ,Saint-MandÃ©", :latitude => "48.83333", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Saint-Malo", :aliases => "Commune-de-la-Victoire,Mont-Mamet,Port-Malo,Saint Malo,Saint MÃ¢lo,Saint-Malo,Sant-Malou,Sant-MaloÃ¹,Sen Malo,Sen-Malo,sheng ma luo,Ð¡ÐµÐ½ ÐÐ°Ð»Ð¾,Ð¡ÐµÐ½-ÐÐ°Ð»Ð¾,å£é©¬æ´,Saint-Malo", :latitude => "48.65", :longitude => "-2.01667").save
City.new(:country_id => "76", :name => "Saint-Louis", :aliases => "Saint-Louis,Saint-Ludwig,Sen-Lui,St.Ludwig,Ð¡ÐµÐ½-ÐÑÐ¸,Saint-Louis", :latitude => "47.58333", :longitude => "7.56667").save
City.new(:country_id => "76", :name => "Saint-Lo", :aliases => "Rocher-de-la-Liberte,Rocher-de-la-LibertÃ©,Saint-Lo,Saint-LÃ´,Sen-Lo,san=ro,Ð¡ÐµÐ½-ÐÐ¾,ãµã³ï¼ã­ã¼,Saint-LÃ´", :latitude => "49.11624", :longitude => "-1.09031").save
City.new(:country_id => "76", :name => "Saint-Leu-la-Foret", :aliases => "Claire-Fontaine,Saint-Leu,Saint-Leu-la-Foret,Saint-Leu-la-ForÃªt,Saint-Leu-la-ForÃªt", :latitude => "49.01667", :longitude => "2.25").save
City.new(:country_id => "76", :name => "Saint-Leu", :aliases => ",Saint-Leu", :latitude => "46.7306", :longitude => "4.50083").save
City.new(:country_id => "76", :name => "Saint-Laurent-du-Var", :aliases => "Saint-Laurent,Saint-Laurent-du-Var,Sen-Loran-dju-Var,Ð¡ÐµÐ½-ÐÐ¾ÑÐ°Ð½-Ð´Ñ-ÐÐ°Ñ,Saint-Laurent-du-Var", :latitude => "43.66667", :longitude => "7.18333").save
City.new(:country_id => "76", :name => "Saint-Jean-de-la-Ruelle", :aliases => "Saint-Jean,Saint-Jean-de-la-Ruelle,Saint-Jean-de-la-Ruelle", :latitude => "47.91667", :longitude => "1.86667").save
City.new(:country_id => "76", :name => "Saint-Jean-de-Braye", :aliases => "Saint-Jean-de-Braye,Saint-Jean-de-Braye", :latitude => "47.9", :longitude => "1.96667").save
City.new(:country_id => "76", :name => "Saint-Herblain", :aliases => "Saint-Herblain,Sant-Ervlan,Saint-Herblain", :latitude => "47.21667", :longitude => "-1.65").save
City.new(:country_id => "76", :name => "Saint-Gratien", :aliases => "Saint-Gratien,Saint-Gratien", :latitude => "48.9735", :longitude => "2.28729").save
City.new(:country_id => "76", :name => "Saint-Germain-en-Laye", :aliases => "Montagne-du-Bon-Air,Saint-Germain,Saint-Germain-en-Laye,Sen-Zhermen-an-Leh,saengjeleumaeng-angle,san=jeruman=an=re,sheng ri er man ang lai,Ð¡ÐµÐ½-ÐÐµÑÐ¼ÐµÐ½-Ð°Ð½-ÐÑ,ãµã³ï¼ã¸ã§ã«ãã³ï¼ã¢ã³ï¼ã¬ã¼,å£æ¥è³æ¼æè±,ìì ë¥´ë§¹ìë ,Saint-Germain-en-Laye", :latitude => "48.9", :longitude => "2.08333").save
City.new(:country_id => "76", :name => "Saint-Genis-Laval", :aliases => "Genis-le-Patriote,Saint Genis,Saint-Genis-Laval,Sen-Zheni-Laval',Ð¡ÐµÐ½-ÐÐµÐ½Ð¸-ÐÐ°Ð²Ð°Ð»Ñ,Saint-Genis-Laval", :latitude => "45.68333", :longitude => "4.8").save
City.new(:country_id => "76", :name => "Saint-Fons", :aliases => "Saint-Fons,Saint-Fons", :latitude => "45.7", :longitude => "4.86667").save
City.new(:country_id => "76", :name => "Saint-Etienne-du-Rouvray", :aliases => "Saint-Etienne,Saint-Etienne-du-Rouvray,Saint-Ãtienne,Saint-Ãtienne-du-Rouvray,Sent-Eht'en-dju-Ruvreh,Ð¡ÐµÐ½Ñ-Ð­ÑÑÐµÐ½-Ð´Ñ-Ð ÑÐ²ÑÑ,Saint-Ãtienne-du-Rouvray", :latitude => "49.37794", :longitude => "1.10467").save
City.new(:country_id => "76", :name => "Saint-Etienne", :aliases => "Armes-Ville,Canton-d'Armes,Commune-d'Armes,Libre-Ville,Lungsod ng Saint-Etienne,Lungsod ng Saint-Ãtienne,Saint-Etienne,Saint-Ãtienne,Sant-Etieve,Sant-EtiÃ¨ve,Sent Etien,Sent-Eht'en,san=techien'nu,san=tetien'nu,sant atyyn,sheng ai di an,Ð¡ÐµÐ½Ñ ÐÑÐ¸ÐµÐ½,Ð¡ÐµÐ½Ñ-Ð­ÑÑÐµÐ½,Ø³Ø§ÙØª Ø¥ØªÙÙÙ,ãµã³ï¼ããã¨ã³ã,ãµã³ï¼ããã£ã¨ã³ã,å£è¾èå®,Saint-Ãtienne", :latitude => "45.43333", :longitude => "4.4").save
City.new(:country_id => "76", :name => "Saintes", :aliases => "Xantes,Saintes", :latitude => "45.75", :longitude => "-0.63333").save
City.new(:country_id => "76", :name => "Sainte-Genevieve-des-Bois", :aliases => "Colbert-la-Reunion,Colbert-la-RÃ©union,Sainte-Genevieve,Sainte-Genevieve-des-Bois,Sainte-GeneviÃ¨ve,Sainte-GeneviÃ¨ve-des-Bois,Sent-Zhenev'ev-de-Bua,Ð¡ÐµÐ½Ñ-ÐÐµÐ½ÐµÐ²ÑÐµÐ²-Ð´Ðµ-ÐÑÐ°,Sainte-GeneviÃ¨ve-des-Bois", :latitude => "48.63333", :longitude => "2.33333").save
City.new(:country_id => "76", :name => "Sainte-Foy-les-Lyon", :aliases => "Beauvais-l'Isle-Barbe,Bonnefey,Canton-Chalier,Canton-Egalite,Canton-EgalitÃ©,Canton-de-Marat,Canton-de-la-Convention,Canton-de-la-Federation,Canton-de-la-FÃ©dÃ©ration,Canton-de-la-Liberte,Canton-de-la-LibertÃ©,Canton-de-la-Montagne,Canton-de-la-Raison,Canton-le-Peletier,Canton-sans-Culotte,Commune-Affranchie,Commune-Chalier,Mont-Chalier,Quartier-de-la-Montagne,Saint-Foy,Sainte-Foy,Sainte-Foy-les-Lyon,Sainte-Foy-lez-Lyon,Sainte-Foy-lÃ¨s-Lyon,Sent-Fua-le-Lion,Ð¡ÐµÐ½Ñ-Ð¤ÑÐ°-Ð»Ðµ-ÐÐ¸Ð¾Ð½,Sainte-Foy-lÃ¨s-Lyon", :latitude => "45.73333", :longitude => "4.8").save
City.new(:country_id => "76", :name => "Saint-Egreve", :aliases => "Saint Egreve,San Egreve,Vence,Saint-ÃgrÃ¨ve", :latitude => "45.23333", :longitude => "5.68333").save
City.new(:country_id => "76", :name => "Saint-Dizier", :aliases => "Saint-Dizier,Sankt-Diz'e,Ð¡Ð°Ð½ÐºÑ-ÐÐ¸Ð·ÑÐµ,Saint-Dizier", :latitude => "48.63333", :longitude => "4.95").save
City.new(:country_id => "76", :name => "Saint-Die-des-Vosges", :aliases => "Sen-D'e-de-Vozh,Ð¡ÐµÐ½-ÐÑÐµ-Ð´Ðµ-ÐÐ¾Ð¶,Saint-DiÃ©-des-Vosges", :latitude => "48.28333", :longitude => "6.95").save
City.new(:country_id => "76", :name => "Saint-Denis", :aliases => "Saint-Denis,Sen-Deni,Ð¡ÐµÐ½-ÐÐµÐ½Ð¸,Saint-Denis", :latitude => "48.93333", :longitude => "2.36667").save
City.new(:country_id => "76", :name => "Saint-Cyr-sur-Loire", :aliases => "Belle-Cote,Belle-CÃ´te,Saint-Cyr,Saint-Cyr-sur-Loire,Saint-Cyr-sur-Loire", :latitude => "47.4", :longitude => "0.66667").save
City.new(:country_id => "76", :name => "Saint-Cyr-l'Ecole", :aliases => "Libreval,Saint-Cyr,Saint-Cyr-l'Ecole,Saint-Cyr-l'Ãcole,Val-Libre,Saint-Cyr-l'Ãcole", :latitude => "48.8", :longitude => "2.06667").save
City.new(:country_id => "76", :name => "Saint-Cloud", :aliases => "La Montagne-Cherie,La Montagne-ChÃ©rie,Pont-la-Montagne,Saint-Cloud,Sen-Klu,Ð¡ÐµÐ½-ÐÐ»Ñ,Saint-Cloud", :latitude => "48.83333", :longitude => "2.18333").save
City.new(:country_id => "76", :name => "Saint-Chamond", :aliases => "Mont-Rousseau,Saint-Chamond,Val-Rousseau,Vallee-Roussean,VallÃ©e-Roussean,Saint-Chamond", :latitude => "45.46667", :longitude => "4.5").save
City.new(:country_id => "76", :name => "Saint-Brieuc", :aliases => "Port-Brieuc,Saint-Brieu,Saint-Brieuc,Sant-Brieg,Sent-Brie,san=buriyu,Ð¡ÐµÐ½Ñ-ÐÑÐ¸Ðµ,ãµã³ï¼ããªã¦ã¼,Saint-Brieuc", :latitude => "48.51667", :longitude => "-2.78333").save
City.new(:country_id => "76", :name => "Saint-Avold", :aliases => "Rosselgene,RosselgÃ¨ne,Saint-Avold,Trimonts,Saint-Avold", :latitude => "49.1", :longitude => "6.7").save
City.new(:country_id => "76", :name => "Saint-Avertin", :aliases => "Saint-Avertin,Vancay,Vansay,VanÃ§ay,Saint-Avertin", :latitude => "47.36357", :longitude => "0.73993").save
City.new(:country_id => "76", :name => "Saint-Amand-les-Eaux", :aliases => "Elnon-Libre,Saint-Amand,Saint-Amand-les-Eaux,Saint-Amand-les-Eaux", :latitude => "50.43333", :longitude => "3.43333").save
City.new(:country_id => "76", :name => "Rueil-Malmaison", :aliases => "Rueil,Rueil-Malmaison,Rueil-Malmaison", :latitude => "48.8765", :longitude => "2.18967").save
City.new(:country_id => "76", :name => "Royan", :aliases => "Royan,Royan", :latitude => "45.63333", :longitude => "-1.03333").save
City.new(:country_id => "76", :name => "Rouen", :aliases => "Erruan,Rothomagus,Rouen,Ruan,Ruan - Rouen,Ruao,Ruduborg,RuÃ¡n,RuÃ¡n - Rouen,RuÃ£o,RÃºÃ°uborg,lu ang,luang,ru'am,ruan,rwan,Ð ÑÐ°Ð½,Ø±ÙØ§Ù,à¤°à¥à¤à¤,ã«ã¼ã¢ã³,é²æ,ë£¨ì,Rouen", :latitude => "49.44313", :longitude => "1.09932").save
City.new(:country_id => "76", :name => "Roubaix", :aliases => "Robaais,Roubaix,lu bei,é²è´,Roubaix", :latitude => "50.7", :longitude => "3.16667").save
City.new(:country_id => "76", :name => "Rosny-sous-Bois", :aliases => "Roni-su-Bua,Rosny,Rosny-sous-Bois,Ð Ð¾Ð½Ð¸-ÑÑ-ÐÑÐ°,Rosny-sous-Bois", :latitude => "48.87017", :longitude => "2.4991").save
City.new(:country_id => "76", :name => "Ronchin", :aliases => "Ronchin,Ronchin", :latitude => "50.6", :longitude => "3.1").save
City.new(:country_id => "76", :name => "Romorantin-Lanthenay", :aliases => "Romarantin,Romorantin,Romorantin-Lanthenay", :latitude => "47.36667", :longitude => "1.75").save
City.new(:country_id => "76", :name => "Romans-sur-Isere", :aliases => "Roman-sjur-Izer,Romans,Romans-sur-Isere,Romans-sur-IsÃ¨re,Romas sur Isere,Romas sur IsÃ¨re,Ð Ð¾Ð¼Ð°Ð½-ÑÑÑ-ÐÐ·ÐµÑ,Romans-sur-IsÃ¨re", :latitude => "45.05", :longitude => "5.05").save
City.new(:country_id => "76", :name => "Romainville", :aliases => "Romainville,Romenvil',Ð Ð¾Ð¼ÐµÐ½Ð²Ð¸Ð»Ñ,Romainville", :latitude => "48.8854", :longitude => "2.43482").save
City.new(:country_id => "76", :name => "Roissy-en-Brie", :aliases => "Roissy,Roissy-en-Brie,Roissy-les-Friches,Ruassi-an-Bri,Ð ÑÐ°ÑÑÐ¸-Ð°Ð½-ÐÑÐ¸,Roissy-en-Brie", :latitude => "48.8", :longitude => "2.65").save
City.new(:country_id => "76", :name => "Rodez", :aliases => "Rodes,Rodez,RodÃ©s,rodezu,Ð Ð¾Ð´ÐµÐ·,ã­ããº,ã­ãã¼ãº,Rodez", :latitude => "44.35258", :longitude => "2.57338").save
City.new(:country_id => "76", :name => "Rochefort", :aliases => "Rochefort-sur-Mer,Roshfor,Ð Ð¾ÑÑÐ¾Ñ,Rochefort", :latitude => "45.93333", :longitude => "-0.98333").save
City.new(:country_id => "76", :name => "Roanne", :aliases => "Roann,Roanne,Rodumna,Rouana,Ð Ð¾Ð°Ð½Ð½,Roanne", :latitude => "46.03333", :longitude => "4.06667").save
City.new(:country_id => "76", :name => "Ris-Orangis", :aliases => "Brutus,Ris,Ris-Orangis,Ris-Orangis", :latitude => "48.65", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Riom", :aliases => "Riom,rion,ãªãªã³,Riom", :latitude => "45.9", :longitude => "3.11667").save
City.new(:country_id => "76", :name => "Rillieux-la-Pape", :aliases => "Rilliehuks-la-Pap,Ð Ð¸Ð»Ð»Ð¸ÑÑÐºÑ-Ð»Ð°-ÐÐ°Ð¿,Rillieux-la-Pape", :latitude => "45.81667", :longitude => "4.9").save
City.new(:country_id => "76", :name => "Reze", :aliases => "Reudied,Reza,Reze,RezÃ©,Ð ÐµÐ·Ð°,RezÃ©", :latitude => "47.2", :longitude => "-1.56667").save
City.new(:country_id => "76", :name => "Rennes", :aliases => "Ren,Renes,Renn,Rennes,Roazhon,lei en,ren'nu,ryn,Ð ÐµÐ½,Ð ÐµÐ½Ð½,Ø±ÙÙ,ã¬ã³ã,é·æ©,Rennes", :latitude => "48.08333", :longitude => "-1.68333").save
City.new(:country_id => "76", :name => "Reims", :aliases => "Rejms,Rheims,Ð ÐµÐ¹Ð¼Ñ,Reims", :latitude => "49.25", :longitude => "4.03333").save
City.new(:country_id => "76", :name => "Rambouillet", :aliases => "Rambouillet,Rambouillet-forhandlingerne,Rambuje,ranbuie,Ð Ð°Ð¼Ð±ÑÐ¹Ðµ,ã©ã³ãã¤ã¨,Rambouillet", :latitude => "48.65", :longitude => "1.83333").save
City.new(:country_id => "76", :name => "Quimper", :aliases => "Kemper,Montagne-sur-Odet,Quimper,kanperu,ÐÐµÐ¼Ð¿ÐµÑ,ã«ã³ãã¼ã«,Quimper", :latitude => "48", :longitude => "-4.1").save
City.new(:country_id => "76", :name => "Puteaux", :aliases => "Puteaux,Puteux,Puteaux", :latitude => "48.88341", :longitude => "2.23894").save
City.new(:country_id => "76", :name => "Port-de-Bouc", :aliases => "Port-de-Boue,Port-de-Bouc", :latitude => "43.40657", :longitude => "4.9809").save
City.new(:country_id => "76", :name => "Pontoise", :aliases => "Pontisara,Pontoise,pontowazu,ãã³ãã¯ã¼ãº,Pontoise", :latitude => "49.05", :longitude => "2.1").save
City.new(:country_id => "76", :name => "Pontivy", :aliases => "Pondi,Pondivi,Pontivy,Pontivy", :latitude => "48.06667", :longitude => "-2.98333").save
City.new(:country_id => "76", :name => "Pontarlier", :aliases => "Pontarlier,Pontarlier", :latitude => "46.90347", :longitude => "6.35542").save
City.new(:country_id => "76", :name => "Pont-a-Mousson", :aliases => "Pont-a-Mousson,Pont-a-Musson,Pont-Ã -Mousson,ÐÐ¾Ð½Ñ-Ð°-ÐÑÑÑÐ¾Ð½,Pont-Ã -Mousson", :latitude => "48.9", :longitude => "6.06667").save
City.new(:country_id => "76", :name => "Poitiers", :aliases => "Peitieus,Poatie,Poitiers,Pouatie,Pouetiers,PouÃ¨tiÃ©rs,Puat'e,powachie,pu wa jie,Î Î¿ÏÎ±ÏÎ¹Î­,ÐÐ¾Ð°ÑÐ¸Ðµ,ÐÑÐ°ÑÑÐµ,ãã¯ãã¨,æ®ç¦æ·,Poitiers", :latitude => "46.58333", :longitude => "0.33333").save
City.new(:country_id => "76", :name => "Poissy", :aliases => "Poissy,Puassi,ÐÑÐ°ÑÑÐ¸,Poissy", :latitude => "48.92902", :longitude => "2.04952").save
City.new(:country_id => "76", :name => "Ploemeur", :aliases => "Planvour,PlaÃ±vour,Ploemeur,Ploemeur", :latitude => "47.73333", :longitude => "-3.43333").save
City.new(:country_id => "76", :name => "Plaisir", :aliases => "Plaisir,Plaisir", :latitude => "48.81667", :longitude => "1.95").save
City.new(:country_id => "76", :name => "Plaisance-du-Touch", :aliases => "Plaisance,Plaisance-du-Touch,Plaisance-du-Touch", :latitude => "43.56667", :longitude => "1.3").save
City.new(:country_id => "76", :name => "Pierrefitte-sur-Seine", :aliases => "Pierrefitte,Pierrefitte-sur-Seine,Pierrefitte-sur-Seine", :latitude => "48.96691", :longitude => "2.36104").save
City.new(:country_id => "76", :name => "Pessac", :aliases => "Pecac,Pessac,Pessake,PeÃ§ac,ÐÐµÑÑÐ°ÐºÐµ,Pessac", :latitude => "44.8", :longitude => "-0.61667").save
City.new(:country_id => "76", :name => "Pertuis", :aliases => "Pertuis,Pertuis", :latitude => "43.68333", :longitude => "5.5").save
City.new(:country_id => "76", :name => "Perpignan", :aliases => "Perpignan,Perpignan la Catalane,Perpignano,Perpin'jan,Perpinan,Perpinha,Perpinhan,PerpinhÃ£,Perpinjan,Perpinya,Perpinya la Catalana,PerpinyÃ ,PerpinyÃ  la Catalana,PerpiÃ±Ã¡n,Villa Perpiniarum,perupinyan,ÐÐµÑÐ¿Ð¸Ð½ÑÑÐ½,ÐÐµÑÐ¿Ð¸Ð½ÑÐ½,ãã«ããã£ã³,Perpignan", :latitude => "42.69764", :longitude => "2.89541").save
City.new(:country_id => "76", :name => "Perigueux", :aliases => "Perige,Perigueers,Periguers,Perigueux,Periguex,PerigÃ¼ers,PÃ©rigueux,PÃ©riguex,perigu,ÐÐµÑÐ¸Ð³Ðµ,ããªã°ã¼,PÃ©rigueux", :latitude => "45.18333", :longitude => "0.71667").save
City.new(:country_id => "76", :name => "Pau", :aliases => "Pau,Paue,po,ÐÐ°Ñ,ãã¼,Pau", :latitude => "43.3", :longitude => "-0.36667").save
City.new(:country_id => "76", :name => "Paris", :aliases => "75091,Lungsod ng Paris,Lutece,Lutetia Parisorum,PAR,Pa-ri,Paarys,Paname,Pantruche,Paraeis,Paras,Pari,Paries,Pariggi,Parigi,Pariis,Pariisi,Parijs,Paris,Paris - Paris,Parisi,Pariz,Parize,Parizh,Parizo,Parizs,Parys,Paryz,Paryzh,Paryzius,ParyÅ¼,ParyÅ¾ius,ParÃ¤is,ParÃ­s,ParÃ­s - Paris,ParÃ­Å¾,ParÃ®s,ParÄ«ze,PaÅÃ­Å¾,PÃ¡ras,PÃ¡rizs,Ville-Lumiere,Ville-LumiÃ¨re,ba li,barys,pali si,pari,paris,parys,paryzh,perisa,prys,pryz,pyaris,pyrs,Î Î±ÏÎ¯ÏÎ¹,ÐÐ°ÑÐ¸Ð¶,ÐÐ°ÑÐ¸Ð·,ÐÐ°ÑÑÐ¶,ÕÕ¡ÖÕ«Õ¦,×¤×¨××,Ø¨Ø§Ø±ÙØ³,Ù¾Ø§Ø±ÙÚ,Ù¾Ø§Ø±ÛØ³,Ù¾ÛØ±Ø³,Ü¦ÜªÜÜ£,à¤ªà¥à¤°à¤¿à¤¸,à®ªà®¾à®°à®¿à®¸à¯,à²ªà³à²¯à²¾à²°à²¿à²¸à³,à¸à¸²à¸£à¸µà¸ª,ááá ááá,ááªáµ,ããª,å·´é»,íë¦¬ ì,Paris", :latitude => "48.85341", :longitude => "2.3488").save
City.new(:country_id => "76", :name => "Pantin", :aliases => "Pantin,ÐÐ°Ð½ÑÐ¸Ð½,Pantin", :latitude => "48.89437", :longitude => "2.40935").save
City.new(:country_id => "76", :name => "Pamiers", :aliases => "Pamias,Pamiers,Pamies,PÃ mias,PÃ mies,pamie,ããã¨,Pamiers", :latitude => "43.11667", :longitude => "1.6").save
City.new(:country_id => "76", :name => "Palaiseau", :aliases => "Palaiseau,Paliseau,Palaiseau", :latitude => "48.71667", :longitude => "2.25").save
City.new(:country_id => "76", :name => "Ozoir-la-Ferriere", :aliases => "Ozoir,Ozoir-la-Ferriere,Ozoir-la-FerriÃ¨re,Ozoir-la-Raison,Ozoir-la-FerriÃ¨re", :latitude => "48.76667", :longitude => "2.66667").save
City.new(:country_id => "76", :name => "Oyonnax", :aliases => "Oyannax,Oyonnax,Oyonnax", :latitude => "46.25917", :longitude => "5.65727").save
City.new(:country_id => "76", :name => "Outreau", :aliases => "Outreau,Outreau", :latitude => "50.70535", :longitude => "1.5897").save
City.new(:country_id => "76", :name => "Oullins", :aliases => "Oullins,Oullins", :latitude => "45.71667", :longitude => "4.8").save
City.new(:country_id => "76", :name => "Osny", :aliases => "Osny,Osny", :latitude => "49.05937", :longitude => "2.06183").save
City.new(:country_id => "76", :name => "Orvault", :aliases => "Orvault,Orvez,Orvo,ÐÑÐ²Ð¾,Orvault", :latitude => "47.26667", :longitude => "-1.61667").save
City.new(:country_id => "76", :name => "Orsay", :aliases => "Orsay,Orsay", :latitude => "48.7", :longitude => "2.18333").save
City.new(:country_id => "76", :name => "Orly", :aliases => "Orly,Orly", :latitude => "48.75", :longitude => "2.4").save
City.new(:country_id => "76", :name => "Orleans", :aliases => "Aurelia,Orleaes,Orlean,Orleans,Orleans La Source,OrleÃ¡ns,OrleÃ£es,OrlÃ¨ans,OrlÃ©ans,OrlÃ©ans La Source,ao er liang,oleulleang,orurean,ÐÑÐ»ÐµÐ°Ð½,×××¨××××,ãªã«ã¬ã¢ã³,å¥¥å°è¯,ì¤ë¥¼ë ì,OrlÃ©ans", :latitude => "47.91667", :longitude => "1.9").save
City.new(:country_id => "76", :name => "Orange", :aliases => "Arauzion,Aurenja,Orange,Oranzas,OranÅ¾as,oranju,ÐÑÐ°ÑÐ·Ð¸Ð¾Ð½,ãªã©ã³ã¸ã¥,Orange", :latitude => "44.13333", :longitude => "4.8").save
City.new(:country_id => "76", :name => "Olivet", :aliases => "Oliva,Olivet,ÐÐ»Ð¸Ð²Ð°,Olivet", :latitude => "47.86667", :longitude => "1.9").save
City.new(:country_id => "76", :name => "Octeville", :aliases => ",Octeville", :latitude => "49.61667", :longitude => "-1.65").save
City.new(:country_id => "76", :name => "Noyon", :aliases => "Noyon,Nuajon,Nyon,ÐÑÐ°Ð¹Ð¾Ð½,Noyon", :latitude => "49.58333", :longitude => "3").save
City.new(:country_id => "76", :name => "Noisy-le-Sec", :aliases => "Noisy,Noisy-le-Sec,Shumnaja-le-Sek,Ð¨ÑÐ¼Ð½Ð°Ñ-Ð»Ðµ-Ð¡ÐµÐº,Noisy-le-Sec", :latitude => "48.89148", :longitude => "2.46451").save
City.new(:country_id => "76", :name => "Noisy-le-Grand", :aliases => "Noisy,Noisy-le-Grand,Shumnaja-le-Gran,Ð¨ÑÐ¼Ð½Ð°Ñ-Ð»Ðµ-ÐÑÐ°Ð½,Noisy-le-Grand", :latitude => "48.85", :longitude => "2.56667").save
City.new(:country_id => "76", :name => "Noisiel", :aliases => "Noisiel,Noisiel", :latitude => "48.85", :longitude => "2.63333").save
City.new(:country_id => "76", :name => "Nogent-sur-Oise", :aliases => "Nogent,Nogent-sur-Oise,Nogent-sur-Oise", :latitude => "49.27158", :longitude => "2.47074").save
City.new(:country_id => "76", :name => "Nogent-sur-Marne", :aliases => "Nogent,Nozhan-sjur-Marn,ÐÐ¾Ð¶Ð°Ð½-ÑÑÑ-ÐÐ°ÑÐ½,Nogent-sur-Marne", :latitude => "48.83333", :longitude => "2.48333").save
City.new(:country_id => "76", :name => "Niort", :aliases => "Niort,nioru,ããªã¼ã«,Niort", :latitude => "46.32313", :longitude => "-0.45877").save
City.new(:country_id => "76", :name => "Nimes", :aliases => "Nemausus,Nim,Nimes,Nismes,NÃ®mes,ni mu,nimu,nym,ÐÐ¸Ð¼,× ××,ãã¼ã ,å°¼å§,NÃ®mes", :latitude => "43.83333", :longitude => "4.35").save
City.new(:country_id => "76", :name => "Nice", :aliases => "Nica,Nicaea,Nicca,Nice,Nicea,Nico,Nisa,Niza,Nizza,NiÃ§a,ni si,nisa,nisu,nitsa,nys,ÐÐ¸ÑÐ°,ÐÐ¸ÑÑÐ°,× ××¡,ÙÙØ³,à¤¨à¥à¤¸,áááªá,ãã¼ã¹,å°¼æ¯,Nice", :latitude => "43.70313", :longitude => "7.26608").save
City.new(:country_id => "76", :name => "Nevers", :aliases => "Never,Nevers,nuvu~eru,ÐÐµÐ²ÐµÑ,ãã´ã§ã¼ã«,Nevers", :latitude => "46.98956", :longitude => "3.159").save
City.new(:country_id => "76", :name => "Neuilly-sur-Seine", :aliases => "N'oj sjur Sen,Neuilly,Neuilly-sur-Seine,nyuiishurusenu,sai na he pan na yi,ÐÑÐ¾Ð¹ ÑÑÑ Ð¡ÐµÐ½,ãã¥ã¤ã¤ã·ã¥ã¼ã«ã»ã¼ã,å¡çº³æ²³ççº³ä¼,Neuilly-sur-Seine", :latitude => "48.88333", :longitude => "2.26667").save
City.new(:country_id => "76", :name => "Neuilly-sur-Marne", :aliases => "Neji-sjur-Marn,Neuilly,Neuilly-sur-Marne,ÐÐµÐ¹Ð¸-ÑÑÑ-ÐÐ°ÑÐ½,Neuilly-sur-Marne", :latitude => "48.85", :longitude => "2.53333").save
City.new(:country_id => "76", :name => "Neuilly-Plaisance", :aliases => ",Neuilly-Plaisance", :latitude => "48.86342", :longitude => "2.506").save
City.new(:country_id => "76", :name => "Narbonne", :aliases => "Narbo,Narbona,Narbonna,Narbonne,ÐÐ°ÑÐ±Ð¾Ð½Ð½Ð°,Narbonne", :latitude => "43.18333", :longitude => "3").save
City.new(:country_id => "76", :name => "Nantes", :aliases => "Nant,Nante,Nantes,Nanto,Naoned,Portus Namnetus,nan te,nant,nanta,nanto,ÐÐ°Ð½Ñ,× ×× ×,ÙØ§ÙØª,à¤¨à¤¾à¤à¤¤,ãã³ã,åç¹,Nantes", :latitude => "47.21725", :longitude => "-1.55336").save
City.new(:country_id => "76", :name => "Nanterre", :aliases => "Nanter,Nanterre,nanteru,ÐÐ°Ð½ÑÐµÑ,ãã³ãã¼ã«,Nanterre", :latitude => "48.9", :longitude => "2.2").save
City.new(:country_id => "76", :name => "Nancy", :aliases => "Nanceium,Nancio,Nancy,Nansi,Nanzeg,nan xi,nanshi,nansi,nansy,ÐÐ°Ð½ÑÐ¸,× ×× ×¡×,ÙØ§ÙØ³Ù,ÙØ§ÙØ³Û,à¤¨à¤¾à¤à¤¸à¥,ãã³ã·ã¼,åå¸,Nancy", :latitude => "48.68333", :longitude => "6.2").save
City.new(:country_id => "76", :name => "Muret", :aliases => "Muret,Mureth,MurÃ¨th,Muret", :latitude => "43.46667", :longitude => "1.35").save
City.new(:country_id => "76", :name => "Mulhouse", :aliases => "Miluza,Mjuluz,Muelhausen,Mulhouse,Mulhousen,MÃ¼lhausen,mi lu si,myuruzu,ÐÑÐ»ÑÐ·,ãã¥ã«ã¼ãº,ç±³å¢æ¯,Mulhouse", :latitude => "47.75", :longitude => "7.33333").save
City.new(:country_id => "76", :name => "Moulins", :aliases => "Molins,Moulins,Mulin,muran,ÐÑÐ»Ð¸Ð½,ã ã¼ã©ã³,Moulins", :latitude => "46.56667", :longitude => "3.33333").save
City.new(:country_id => "76", :name => "Mougins", :aliases => "Mougins,Mougins", :latitude => "43.6", :longitude => "7").save
City.new(:country_id => "76", :name => "Morsang-sur-Orge", :aliases => "Morsang,Morsang-sur-Orge,Morsang-sur-Orge", :latitude => "48.66667", :longitude => "2.35").save
City.new(:country_id => "76", :name => "Morlaix", :aliases => "Montroulez,Morlaix,Morlaix", :latitude => "48.58333", :longitude => "-3.83333").save
City.new(:country_id => "76", :name => "Mont-Saint-Aignan", :aliases => "Le Mont-Libre,Mont-Saint-Aignan,Mont-Saint-Aignan", :latitude => "49.46307", :longitude => "1.09364").save
City.new(:country_id => "76", :name => "Montrouge", :aliases => "Monruzh,Montrouge,ÐÐ¾Ð½ÑÑÐ¶,Montrouge", :latitude => "48.81667", :longitude => "2.31667").save
City.new(:country_id => "76", :name => "Montreuil", :aliases => "Montrej,Montreuil,Montreuil-sous-Bois,ÐÐ¾Ð½ÑÑÐµÐ¹,Montreuil", :latitude => "48.86415", :longitude => "2.44322").save
City.new(:country_id => "76", :name => "Montpellier", :aliases => "Monpel'e,Monpele,Monpelie,Montpelhier,MontpelhiÃ¨r,Montpeller,Montpellier,meng bi li ai,mongpellie,monperie,mwnbylyyh,mwnplyyh,ÐÐ¾Ð½Ð¿ÐµÐ»Ð¸Ðµ,ÐÐ¾Ð½Ð¿ÐµÐ»ÑÐµ,ÐÐ¾Ð½Ð¿ÐµÑÐµ,××× ×¤××××,ÙÙÙØ¨ÙÙÙÙÙ,ã¢ã³ããªã¨,èå½¼å©å,ëª½í ë¦¬ì,Montpellier", :latitude => "43.6", :longitude => "3.88333").save
City.new(:country_id => "76", :name => "Montmorency", :aliases => "Monmoransi,Montmorency,ÐÐ¾Ð½Ð¼Ð¾ÑÐ°Ð½ÑÐ¸,Montmorency", :latitude => "48.98826", :longitude => "2.3434").save
City.new(:country_id => "76", :name => "Montlucon", :aliases => "Monljuson,Montlucon,MontluÃ§on,monryuson,ÐÐ¾Ð½Ð»ÑÑÐ¾Ð½,ã¢ã³ãªã¥ã½ã³,MontluÃ§on", :latitude => "46.33333", :longitude => "2.6").save
City.new(:country_id => "76", :name => "Montivilliers", :aliases => "Brutus-Villiers,Montivilliers,Montivilliers", :latitude => "49.54518", :longitude => "0.18769").save
City.new(:country_id => "76", :name => "Montigny-les-Metz", :aliases => "Metz-les-Montigny,Metz-lÃ¨s-Montigny,Montigny,Montigny-les-Metz,Montigny-lÃ¨s-Metz,Montigny-lÃ¨s-Metz", :latitude => "49.1", :longitude => "6.15").save
City.new(:country_id => "76", :name => "Montigny-les-Cormeilles", :aliases => "Montigny,Montigny-les-Cormeilles,Montigny-lÃ¨s-Cormeilles,Montigny-lÃ¨s-Cormeilles", :latitude => "48.98202", :longitude => "2.20035").save
City.new(:country_id => "76", :name => "Montigny-le-Bretonneux", :aliases => "Montigny,Montigny-le-Bretonneux,Montigny-le-Bretonneux", :latitude => "48.76667", :longitude => "2.03333").save
City.new(:country_id => "76", :name => "Montgeron", :aliases => "Montgeron,Monzherone,ÐÐ¾Ð½Ð¶ÐµÑÐ¾Ð½Ðµ,Montgeron", :latitude => "48.7", :longitude => "2.45").save
City.new(:country_id => "76", :name => "Montfermeil", :aliases => "Montfermeil,Montfermeil", :latitude => "48.8982", :longitude => "2.57913").save
City.new(:country_id => "76", :name => "Montesson", :aliases => "Montesson,Montesson", :latitude => "48.90924", :longitude => "2.13754").save
City.new(:country_id => "76", :name => "Montereau-Fault-Yonne", :aliases => "Montereau,Montereau-Fault-Yonne", :latitude => "48.38333", :longitude => "2.95").save
City.new(:country_id => "76", :name => "Montelimar", :aliases => "Acumum,Montelimar,Montelimare,MontÃ©limar,ÐÐ¾Ð½ÑÐµÐ»Ð¸Ð¼Ð°ÑÐµ,MontÃ©limar", :latitude => "44.56667", :longitude => "4.75").save
City.new(:country_id => "76", :name => "Mont-de-Marsan", :aliases => "Mon-de-Marsan,Mont-Marat,Mont-de-Marat,Mont-de-Marsan,mon=do=marusan,ÐÐ¾Ð½-Ð´Ðµ-ÐÐ°ÑÑÐ°Ð½,ã¢ã³ï¼ãï¼ãã«ãµã³,Mont-de-Marsan", :latitude => "43.89022", :longitude => "-0.49713").save
City.new(:country_id => "76", :name => "Montceau-les-Mines", :aliases => "Monke-le-Mine,Montceau,Montceau-les-Mines,ÐÐ¾Ð½ÐºÐµ-Ð»Ðµ-ÐÐ¸Ð½Ðµ,Montceau-les-Mines", :latitude => "46.66667", :longitude => "4.36667").save
City.new(:country_id => "76", :name => "Montbrison", :aliases => "Montbrise,MontbrisÃ©,Montbrison", :latitude => "45.6", :longitude => "4.05").save
City.new(:country_id => "76", :name => "Montbeliard", :aliases => "Mont-Reuni,Mont-RÃ©uni,Montbeliard,MontbÃ©liard,Montoeliard,meng bei li ya er,èè´å©äºå°,MontbÃ©liard", :latitude => "47.51667", :longitude => "6.8").save
City.new(:country_id => "76", :name => "Montauban", :aliases => "Montalban,Montauban,Montoban,Rive-Civique,montoban,ÐÐ¾Ð½ÑÐ¾Ð±Ð°Ð½,ã¢ã³ãã¼ãã³,Montauban", :latitude => "44.01667", :longitude => "1.35").save
City.new(:country_id => "76", :name => "Montargis", :aliases => "Mont-Coulounies,Montargis,Montargis", :latitude => "48", :longitude => "2.75").save
City.new(:country_id => "76", :name => "Mons-en-Baroeul", :aliases => "Mons,Mons-en-Baroeul,Mons-en-BarÅul,Mons-en-BarÅul", :latitude => "50.63333", :longitude => "3.11667").save
City.new(:country_id => "76", :name => "Moissy-Cramayel", :aliases => "Mois-la-Plaine,Moissy,Moissy-Cramayel,Moissy-Gramayel,Moissy-Cramayel", :latitude => "48.61667", :longitude => "2.6").save
City.new(:country_id => "76", :name => "Mitry-Mory", :aliases => "Mitry-Mory,Mitry-Mory", :latitude => "48.98333", :longitude => "2.61667").save
City.new(:country_id => "76", :name => "Miramas", :aliases => "Mirama,Miramas,Miramas Gare,mirama,ÐÐ¸ÑÐ°Ð¼Ð°,ãã©ã,Miramas", :latitude => "43.58333", :longitude => "5").save
City.new(:country_id => "76", :name => "Millau", :aliases => "Mijo,Millan,Millau,ÐÐ¸Ð¹Ð¾,Millau", :latitude => "44.1", :longitude => "3.08333").save
City.new(:country_id => "76", :name => "Meyzieu", :aliases => "Meyzieu,Meyzieu", :latitude => "45.76667", :longitude => "5").save
City.new(:country_id => "76", :name => "Meylan", :aliases => "Meylan,Meylan", :latitude => "45.23333", :longitude => "5.78333").save
City.new(:country_id => "76", :name => "Meudon", :aliases => "Meudon,Rabelais,Meudon", :latitude => "48.81667", :longitude => "2.23333").save
City.new(:country_id => "76", :name => "Metz", :aliases => "Divodurum,Mec,Mediomatricum,Mettis,Metz,mei si,mesu,ÐÐµÑ,ã¡ã¹,æ¢æ¯,Metz", :latitude => "49.11911", :longitude => "6.17269").save
City.new(:country_id => "76", :name => "Merignac", :aliases => "Meirinhac,Merignac,Merignae,MÃ©rignac,MÃ©rignac", :latitude => "44.83333", :longitude => "-0.63333").save
City.new(:country_id => "76", :name => "Menton", :aliases => "Menton,Mentona,Mentone,ÐÐµÐ½ÑÐ¾Ð½Ð°,Menton", :latitude => "43.77649", :longitude => "7.50435").save
City.new(:country_id => "76", :name => "Melun", :aliases => "Melun,muran,ã ã©ã³,Melun", :latitude => "48.53333", :longitude => "2.66667").save
City.new(:country_id => "76", :name => "Meaux", :aliases => "Mo,ÐÐ¾,Meaux", :latitude => "48.95", :longitude => "2.86667").save
City.new(:country_id => "76", :name => "Mayenne", :aliases => ",Mayenne", :latitude => "48.3", :longitude => "-0.61667").save
City.new(:country_id => "76", :name => "Maurepas", :aliases => "Maurepas,Maurepas", :latitude => "48.76667", :longitude => "1.91667").save
City.new(:country_id => "76", :name => "Mauguio", :aliases => "Condado de Melguelh,Mauguio,Melguelh,Mont-Salaison,Mauguio", :latitude => "43.61667", :longitude => "4.01667").save
City.new(:country_id => "76", :name => "Maubeuge", :aliases => "Maubeuge,Maubeuge", :latitude => "50.27875", :longitude => "3.97267").save
City.new(:country_id => "76", :name => "Massy", :aliases => "Massa,Massy,ÐÐ°ÑÑÐ°,Massy", :latitude => "48.73333", :longitude => "2.28333").save
City.new(:country_id => "76", :name => "Martigues", :aliases => "Martigues,Martigues", :latitude => "43.40735", :longitude => "5.05526").save
City.new(:country_id => "76", :name => "Marseille", :aliases => "Marseilla,Marseille,Marseilles,Marsej,Marsejlo,Marsel',Marsela,Marselha,Marselis,Marsella,Marsella - Marseille,Marselye,Marseya,MarseÄ¼a,Marsigghia,Marsiggia,Marsiglia,Marsiho,Marsilha,Marsilia,Marsilija,Marsilya,Marsylia,Massalia,Massilia,ma sai,maleuseyu,mar se,mar sey,marsaiya,marseli,marsy,marsylya,maruseiyu,mrsyy,ÎÎ±ÏÏÎ±Î»Î¯Î±,ÐÐ°ÑÑÐµÐ»Ñ,ÐÐ°ÑÑÐµÑ,ÐÐ°ÑÑÐ¸Ð»Ð¸Ñ,××¨×¡××,ÙØ§Ø±Ø³ÙÙÙØ§,ÙØ§Ø±Ø³Û,à¤®à¤¾à¤°à¥à¤¸à¥à¤¯,à¸¡à¸²à¸£à¹à¹à¸,à¸¡à¸²à¸£à¹à¹à¸à¸¢à¹,ááá á¡ááá,ãã«ã»ã¤ã¦,é©¬èµ,ë§ë¥´ì¸ì ,Marseille", :latitude => "43.29695", :longitude => "5.38107").save
City.new(:country_id => "76", :name => "Marmande", :aliases => "Marmande,Marmande", :latitude => "44.5", :longitude => "0.16667").save
City.new(:country_id => "76", :name => "Marly-le-Roi", :aliases => "Marly,Marly-la-Machine,Marly-le-Roi,Marly-le-Roi", :latitude => "48.86667", :longitude => "2.08333").save
City.new(:country_id => "76", :name => "Marignane", :aliases => "Marignanc,Marignane,marinyanu,ããªãã£ã¼ã,Marignane", :latitude => "43.41667", :longitude => "5.21667").save
City.new(:country_id => "76", :name => "Marcq-en-Baroeul", :aliases => "Marcq,Marcq-en-Baroeul,Marcq-en-BarÅul,Marq,Marq-en-Baroeul,Marquette-en-Baroeul,Marcq-en-BarÅul", :latitude => "50.66667", :longitude => "3.08333").save
City.new(:country_id => "76", :name => "Mantes-la-Ville", :aliases => "Mantes-la-Ville,Mantes-la-Ville", :latitude => "48.97374", :longitude => "1.70253").save
City.new(:country_id => "76", :name => "Mantes-la-Jolie", :aliases => "Mant-lja-Zholi,Mantes,Mantes-Gassicourt,Mantes-Sur-Seine,Mantes-la-Jolie,ÐÐ°Ð½Ñ-Ð»Ñ-ÐÐ¾Ð»Ð¸,Mantes-la-Jolie", :latitude => "48.98333", :longitude => "1.71667").save
City.new(:country_id => "76", :name => "Manosque", :aliases => "Manosca,Manoske,Manosque,ManÃ²sca,ÐÐ°Ð½Ð¾ÑÐºÐµ,Manosque", :latitude => "43.82883", :longitude => "5.78688").save
City.new(:country_id => "76", :name => "Mandelieu-la-Napoule", :aliases => ",Mandelieu-la-Napoule", :latitude => "43.55", :longitude => "6.93333").save
City.new(:country_id => "76", :name => "Malakoff", :aliases => "Malakoff,Malakoff", :latitude => "48.81667", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Maisons-Laffitte", :aliases => "Maisons-Laffitte,Mezon-Lafit,ÐÐµÐ·Ð¾Ð½-ÐÐ°ÑÐ¸Ñ,Maisons-Laffitte", :latitude => "48.95264", :longitude => "2.14521").save
City.new(:country_id => "76", :name => "Maisons-Alfort", :aliases => "Maisons-Alfort,Maisons-Alfort", :latitude => "48.8", :longitude => "2.43333").save
City.new(:country_id => "76", :name => "Macon", :aliases => "Grosne-les-Macon,Grosne-lÃ¨s-Macon,Macon,Makon,Makonas,MÃ¢con,makon,ÐÐ°ÐºÐ¾Ð½,ãã³ã³,MÃ¢con", :latitude => "46.3", :longitude => "4.83333").save
City.new(:country_id => "76", :name => "Lyon", :aliases => "Lio,Lion,Lion - Lyon,Liona,Lionas,Lione,Lioni,Liyon,LiÃ³,LiÃ³n - Lyon,Lugdunum,Lyon,Lyons,LyÃ³n,li ang,liong,lyom,lywn,riyon,ÎÏÏÎ½,ÐÐ¸Ð¾Ð½,××××,ÙÙÙÙ,ÙÛÙÙ,à¤²à¥à¤¯à¥à¤,ãªã¨ã³,éæ,ë¦¬ì¹,Lyon", :latitude => "45.75", :longitude => "4.85").save
City.new(:country_id => "76", :name => "Luneville", :aliases => "Ljunevil',Luneville,LunÃ©ville,ÐÑÐ½ÐµÐ²Ð¸Ð»Ñ,LunÃ©ville", :latitude => "48.6", :longitude => "6.5").save
City.new(:country_id => "76", :name => "Lunel", :aliases => "Ljunel',Lunel,ÐÑÐ½ÐµÐ»Ñ,Lunel", :latitude => "43.67778", :longitude => "4.13611").save
City.new(:country_id => "76", :name => "Luce", :aliases => "Luce,LucÃ©,LucÃ©", :latitude => "48.43333", :longitude => "1.46667").save
City.new(:country_id => "76", :name => "Louviers", :aliases => "Louviers,Louviers", :latitude => "49.21667", :longitude => "1.16667").save
City.new(:country_id => "76", :name => "Lourdes", :aliases => "La Montagne,Lapurdum,Lorda,Lourdes,lu er de,rurudo,ã«ã«ã,ç§ç¾å¾·,Lourdes", :latitude => "43.1", :longitude => "-0.05").save
City.new(:country_id => "76", :name => "Lormont", :aliases => "Lormont,Lormont", :latitude => "44.86667", :longitude => "-0.53333").save
City.new(:country_id => "76", :name => "Lorient", :aliases => "An Oriant,Lor'jan,Lorient,ÐÐ¾ÑÑÑÐ½,Lorient", :latitude => "47.75", :longitude => "-3.36667").save
City.new(:country_id => "76", :name => "Loos", :aliases => "Loos,Loos", :latitude => "50.61667", :longitude => "3.01667").save
City.new(:country_id => "76", :name => "Lons-le-Saunier", :aliases => "Franciade,Lons-le-Saunier,ron=ru=sonie,ã­ã³ï¼ã«ï¼ã½ã¼ãã¨,Lons-le-Saunier", :latitude => "46.66667", :longitude => "5.55").save
City.new(:country_id => "76", :name => "Longjumeau", :aliases => "Longjumeau,Lonzhjumo,ÐÐ¾Ð½Ð¶ÑÐ¼Ð¾,Longjumeau", :latitude => "48.7", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Lomme", :aliases => "Lomm,Lomme,ÐÐ¾Ð¼Ð¼,Lomme", :latitude => "50.65", :longitude => "2.98333").save
City.new(:country_id => "76", :name => "Lognes", :aliases => "Lognes,Lognes", :latitude => "48.83333", :longitude => "2.61667").save
City.new(:country_id => "76", :name => "Livry-Gargan", :aliases => "Livry,Livry-Gargan,Livry-en-Aulnoye,Livry-en-Launois,Livry-Gargan", :latitude => "48.9193", :longitude => "2.54305").save
City.new(:country_id => "76", :name => "L'Isle-sur-la-Sorgue", :aliases => "Isle sur Sorgue,L'Isle,L'Isle-sur-la-Sorgue,L'Isle-sur-la-Sorgue", :latitude => "43.91667", :longitude => "5.05").save
City.new(:country_id => "76", :name => "Lisieux", :aliases => "Lexovium,Lisieux,Lisieux", :latitude => "49.1466", :longitude => "0.22925").save
City.new(:country_id => "76", :name => "Lingolsheim", :aliases => "Lingolsheim,Tanneries,Lingolsheim", :latitude => "48.58155", :longitude => "7.70245").save
City.new(:country_id => "76", :name => "Limoges", :aliases => "Augustoritum,Limages,Limoges,Limogo,LimogÂ·es,Limotges,Limoz,Limozh,LimoÄo,LimÃ²tges,Llemotges,li meng,limoja,lymwz',lymwzh,rimoju,ÎÎ¹Î¼ÏÎ¶,ÐÐ¸Ð¼Ð¾Ð¶,×××××',ÙÛÙÙÚ,à¤²à¤¿à¤®à¥à¤,ãªã¢ã¼ã¸ã¥,éè,Limoges", :latitude => "45.83153", :longitude => "1.2578").save
City.new(:country_id => "76", :name => "Limeil-Brevannes", :aliases => "Limeil,Limeil-Brevannes,Limeil-Breyannes,Limeil-BrÃ©vannes,Limeil-BrÃ©vannes", :latitude => "48.73333", :longitude => "2.48333").save
City.new(:country_id => "76", :name => "Limay", :aliases => "Limay,Limay", :latitude => "48.99553", :longitude => "1.74081").save
City.new(:country_id => "76", :name => "Lille", :aliases => "Insula,Lil,Lila,Lill',Lilla,Lille,Riesel,Rijsel,li er,lil,lila,lyl,riru,ÐÐ¸Ð»,ÐÐ¸Ð»Ð»Ñ,×××,ÙÙÙ,ÙÛÙ,à¤²à¤¿à¤²,ãªã¼ã«,éå°,ë¦´,Lille", :latitude => "50.63333", :longitude => "3.06667").save
City.new(:country_id => "76", :name => "Lievin", :aliases => "Lieven,Lievin,LiÃ©vin,ÐÐ¸ÐµÐ²ÐµÐ½,LiÃ©vin", :latitude => "50.41667", :longitude => "2.76667").save
City.new(:country_id => "76", :name => "Libourne", :aliases => "Liborna,Libourne,Liburn,riburunu,ÐÐ¸Ð±ÑÑÐ½,ãªãã«ã,Libourne", :latitude => "44.91667", :longitude => "-0.23333").save
City.new(:country_id => "76", :name => "L'Hay-les-Roses", :aliases => "L'Hay,L'Hay-les-Roses,L'HaÃ¿-les-Roses,L'HaÃ¿-les-Roses", :latitude => "48.78333", :longitude => "2.33333").save
City.new(:country_id => "76", :name => "Le Vesinet", :aliases => "Le Vesinet,Le VÃ©sinet,Le VÃ©sinet", :latitude => "48.89281", :longitude => "2.13308").save
City.new(:country_id => "76", :name => "Levallois-Perret", :aliases => "Levallois,Levallois-Perret,Levallois-Perret", :latitude => "48.89389", :longitude => "2.28864").save
City.new(:country_id => "76", :name => "Les Sables-d'Olonne", :aliases => "Les Sables-d'Olonne,Sables-d'Olonne,Les Sables-d'Olonne", :latitude => "46.5", :longitude => "-1.78333").save
City.new(:country_id => "76", :name => "Les Pennes-Mirabeau", :aliases => "Les Pennes,Les Pennes-Mirabeau", :latitude => "43.41028", :longitude => "5.31306").save
City.new(:country_id => "76", :name => "Les Pavillons-sous-Bois", :aliases => "Les Pavillons-sous-Bois,Pavillons,Pavillons-sous-Bois,les Pavillons,Les Pavillons-sous-Bois", :latitude => "48.90683", :longitude => "2.50648").save
City.new(:country_id => "76", :name => "Les Mureaux", :aliases => "Les Mureaux,Les Mureaux", :latitude => "48.99173", :longitude => "1.90972").save
City.new(:country_id => "76", :name => "Les Lilas", :aliases => "Les Lilas,Les Lilas", :latitude => "48.87992", :longitude => "2.42057").save
City.new(:country_id => "76", :name => "Les Herbiers", :aliases => "Les Herbiers,Les Petits-Herbiers,Les Herbiers", :latitude => "46.86667", :longitude => "-1.01667").save
City.new(:country_id => "76", :name => "Les Clayes-sous-Bois", :aliases => "Les Clayes,Les Clayes-sous-Bois,Les Clayes-sous-Bois", :latitude => "48.81667", :longitude => "1.98333").save
City.new(:country_id => "76", :name => "Le Puy-en-Velay", :aliases => "Le Puy,Lo Puei de Velai,Lo PuÃ¨i de Velai,Pjui-an-Vele,Puy-en-Velay,ÐÑÐ¸-Ð°Ð½-ÐÐµÐ»Ðµ,ã«ã»ãã¥ã¤ï¼ã¢ã³ï¼ã´ã¬,Le Puy-en-Velay", :latitude => "45.04366", :longitude => "3.88523").save
City.new(:country_id => "76", :name => "Le Pre-Saint-Gervais", :aliases => "Le Pre-Saint-Gervais,Le PrÃ©-Saint-Gervais,Les Pres-le-Peletier,Les PrÃ©s-le-Peletier,Pre Saint Gervais,PrÃ© Saint Gervais,Le PrÃ©-Saint-Gervais", :latitude => "48.88549", :longitude => "2.40422").save
City.new(:country_id => "76", :name => "Le Pontet", :aliases => "Le Pontet,Le Pontet", :latitude => "43.96119", :longitude => "4.86008").save
City.new(:country_id => "76", :name => "Le Plessis-Trevise", :aliases => "Le Plessis-Trevise,Le Plessis-TrÃ©vise,Plessis-Trevise,Plessis-TrÃ©vise,Le Plessis-TrÃ©vise", :latitude => "48.81667", :longitude => "2.56667").save
City.new(:country_id => "76", :name => "Le Plessis-Robinson", :aliases => "Le Plessis-Robinson,Plessis-Robinson,Le Plessis-Robinson", :latitude => "48.78333", :longitude => "2.26667").save
City.new(:country_id => "76", :name => "Le Petit-Quevilly", :aliases => "Le Petit-Quevilly,Petit-Quevilly,Quevilly le Petit,Le Petit-Quevilly", :latitude => "49.41338", :longitude => "1.06155").save
City.new(:country_id => "76", :name => "Le Perreux-sur-Marne", :aliases => "Perreux-Sur-Marne,le Perreux,Le Perreux-sur-Marne", :latitude => "48.85", :longitude => "2.5").save
City.new(:country_id => "76", :name => "Le Pecq", :aliases => "Le Pecq,Le Pecq-sur-Seine,Pecq,Le Pecq", :latitude => "48.89317", :longitude => "2.10371").save
City.new(:country_id => "76", :name => "Lens", :aliases => "Lens,lans,ransu,ÐÐ°Ð½Ñ,ã©ã³ã¹,Lens", :latitude => "50.43302", :longitude => "2.82791").save
City.new(:country_id => "76", :name => "Le Mee-sur-Seine", :aliases => "Le Mee,Le Mee-sur-Seine,Le MÃ©e,Le MÃ©e-sur-Seine,Le MÃ©e-sur-Seine", :latitude => "48.53333", :longitude => "2.63333").save
City.new(:country_id => "76", :name => "Le Mans", :aliases => "L'Unite-sur-Sarthe,L'UnitÃ©-sur-Sarthe,L'o Man,Le Mans,Le-Man,lei mang,ÐÐµ-ÐÐ°Ð½,ÐÑÐ¾ ÐÐ°Ð½,ã«ã»ãã³,åè,Le Mans", :latitude => "48", :longitude => "0.2").save
City.new(:country_id => "76", :name => "Le Kremlin-Bicetre", :aliases => "Kremlin-Bicetre,Kremlin-BicÃªtre,Le Kremlin-Bicetre,Le Kremlin-BicÃªtre,Le Kremlin-BicÃªtre", :latitude => "48.81667", :longitude => "2.36667").save
City.new(:country_id => "76", :name => "Le Havre", :aliases => "Chabre,El Havre,Franciscopolis,Gavr,Grasville-Lheure,Havre,Havro,Hawr,Khavur,La Havro,Le Havre,Saint-Jean-sur-Mer,lei a fu er,lw hafr,Î§Î¬Î²ÏÎ·,ÐÐ°Ð²Ñ,Ð¥Ð°Ð²ÑÑ,ÙÙ ÙØ§ÙØ±,ã«ã»ã¢ã¼ã´ã«,åé¿å¼å°,Le Havre", :latitude => "49.4938", :longitude => "0.10767").save
City.new(:country_id => "76", :name => "Le Grand-Quevilly", :aliases => "Gran-Kevilli,Grand-Quevilly,Le Grand-Quevilly,Quevilly le Grand,ÐÑÐ°Ð½-ÐÐµÐ²Ð¸Ð»Ð»Ð¸,Le Grand-Quevilly", :latitude => "49.40076", :longitude => "1.04582").save
City.new(:country_id => "76", :name => "Le Creusot", :aliases => "Creusot,Le Creusot,Le Creusot", :latitude => "46.80714", :longitude => "4.41632").save
City.new(:country_id => "76", :name => "Le Chesnay", :aliases => "Le Chesnay,Le Chesney,Le Chesnay", :latitude => "48.83333", :longitude => "2.11667").save
City.new(:country_id => "76", :name => "Le Cannet", :aliases => "Cannet,Le Cannet,Lo Canet,Le Cannet", :latitude => "43.57662", :longitude => "7.01912").save
City.new(:country_id => "76", :name => "Le Bouscat", :aliases => "Bouscat,Le Bouscat,Le Bouscat", :latitude => "44.86667", :longitude => "-0.61667").save
City.new(:country_id => "76", :name => "Le Blanc-Mesnil", :aliases => "Le Blanc-Mesnil,Le Blanc-Mesnil", :latitude => "48.93872", :longitude => "2.46138").save
City.new(:country_id => "76", :name => "Laxou", :aliases => "Laxou,Laxou", :latitude => "48.68333", :longitude => "6.15").save
City.new(:country_id => "76", :name => "La Valette-du-Var", :aliases => "La Valette,La Valette-du-Var,La Valette-du-Var", :latitude => "43.13333", :longitude => "5.98333").save
City.new(:country_id => "76", :name => "Laval", :aliases => "Laval',ÐÐ°Ð²Ð°Ð»Ñ,Laval", :latitude => "48.06667", :longitude => "-0.76667").save
City.new(:country_id => "76", :name => "Lattes", :aliases => "Lattes,Lattes", :latitude => "43.56667", :longitude => "3.9").save
City.new(:country_id => "76", :name => "La Teste-de-Buch", :aliases => "La Testa,La Teste,La Teste-de-Buch,La TÃ¨sta,La-Test-de-Bukha,ÐÐ°-Ð¢ÐµÑÑ-Ð´Ðµ-ÐÑÑÐ°,La Teste-de-Buch", :latitude => "44.63333", :longitude => "-1.15").save
City.new(:country_id => "76", :name => "La Seyne-sur-Mer", :aliases => "La Seyne,La Seyne-sur-Mer,La Seyne-sur-Mer", :latitude => "43.1", :longitude => "5.88333").save
City.new(:country_id => "76", :name => "La Roche-sur-Yon", :aliases => "La Roche-sur-Yon,La-Rosh-sjur-Jon,Les Fromages,Les Mineraux,Les MinÃ©raux,Roche-sur-Yon,ÐÐ°-Ð Ð¾Ñ-ÑÑÑ-ÐÐ¾Ð½,ã©ã»ã­ãã·ã¥ï¼ã·ã¥ã«ï¼ã¨ã³,La Roche-sur-Yon", :latitude => "46.66667", :longitude => "-1.43333").save
City.new(:country_id => "76", :name => "La Rochelle", :aliases => "Arroxela,La Cote,La CÃ´te,La Rochelle,La Roshel,La-Roshel',Proclamation,lh rwsl,ÐÐ° Ð Ð¾ÑÐµÐ»,ÐÐ°-Ð Ð¾ÑÐµÐ»Ñ,×× ×¨××©×,ã©ã»ã­ã·ã§ã«,La Rochelle", :latitude => "46.16667", :longitude => "-1.15").save
City.new(:country_id => "76", :name => "Laon", :aliases => "Lana,Laon,ran,ÐÐ°Ð½Ð°,ã©ã³,Laon", :latitude => "49.56667", :longitude => "3.61667").save
City.new(:country_id => "76", :name => "Lannion", :aliases => "Lannion,Lannuon,lanywn,ÐÐ°Ð½Ð½Ð¸Ð¾Ð½,ÙØ§ÙÙÙÙ,Lannion", :latitude => "48.73333", :longitude => "-3.46667").save
City.new(:country_id => "76", :name => "Lanester", :aliases => "Lanester,Lannarster,LannarstÃªr,Lanester", :latitude => "47.75", :longitude => "-3.35").save
City.new(:country_id => "76", :name => "Landerneau", :aliases => "Landerne,Landerneau,Landerneau", :latitude => "48.45252", :longitude => "-4.25252").save
City.new(:country_id => "76", :name => "Lambersart", :aliases => "Lambersar,Lambersart,ÐÐ°Ð¼Ð±ÐµÑÑÐ°Ñ,Lambersart", :latitude => "50.65", :longitude => "3.03333").save
City.new(:country_id => "76", :name => "La Madeleine", :aliases => "La Madeleine,La Madeleine-les-Lille,Madeleine,Madlen,ÐÐ°Ð´Ð»ÐµÐ½,La Madeleine", :latitude => "50.64603", :longitude => "3.07585").save
City.new(:country_id => "76", :name => "Lagny-sur-Marne", :aliases => ",Lagny-sur-Marne", :latitude => "48.86667", :longitude => "2.71667").save
City.new(:country_id => "76", :name => "La Garenne-Colombes", :aliases => "La Garenne,La Garenne-Colombes,La Garenne-Colombes", :latitude => "48.90472", :longitude => "2.2469").save
City.new(:country_id => "76", :name => "La Garde", :aliases => "La Garde,La Garde-pres-Toulon,La Garde-prÃ¨s-Toulon,La Garde", :latitude => "43.11667", :longitude => "6.01667").save
City.new(:country_id => "76", :name => "La Fleche", :aliases => ",La FlÃ¨che", :latitude => "47.69815", :longitude => "-0.07553").save
City.new(:country_id => "76", :name => "La Defense", :aliases => "La Defense,Lja Defans,Paris La Defense,Paris La defense,Paris La dÃ©fense,ÐÑ ÐÐµÑÐ°Ð½Ñ,La DÃ©fense", :latitude => "48.89187", :longitude => "2.23898").save
City.new(:country_id => "76", :name => "La Crau", :aliases => "La Crau,La Crau", :latitude => "43.15", :longitude => "6.06667").save
City.new(:country_id => "76", :name => "La Courneuve", :aliases => "La Courneuve,La-Kurnev,ÐÐ°-ÐÑÑÐ½ÐµÐ²,La Courneuve", :latitude => "48.92805", :longitude => "2.39627").save
City.new(:country_id => "76", :name => "La Ciotat", :aliases => "La Ciotat,Sans-Nom,Ville-sans-Nom,La Ciotat", :latitude => "43.17476", :longitude => "5.60449").save
City.new(:country_id => "76", :name => "La Chapelle-sur-Erdre", :aliases => "Chapel-Erzh,La Chapelle-sur-Erdre,La Chapelle-sur-Erdre", :latitude => "47.3", :longitude => "-1.55").save
City.new(:country_id => "76", :name => "La Celle-Saint-Cloud", :aliases => "La Celle,La Celle-Saint-Cloud,La Celle-les-Bruyeres,La Celle-les-BruyÃ¨res,La Celle-Saint-Cloud", :latitude => "48.85", :longitude => "2.15").save
City.new(:country_id => "76", :name => "Jouy-le-Moutier", :aliases => "Jouy,Jouy-le-Moutier,Jouy-le-Moutier", :latitude => "49.01068", :longitude => "2.04028").save
City.new(:country_id => "76", :name => "Joue-les-Tours", :aliases => "Joue,Joue-les-Tours,JouÃ©,JouÃ©-lÃ¨s-Tours,JouÃ©-lÃ©s-Tours,Zhu-le-Tur,ÐÑ-Ð»Ðµ-Ð¢ÑÑ,JouÃ©-lÃ©s-Tours", :latitude => "47.35223", :longitude => "0.66906").save
City.new(:country_id => "76", :name => "Joinville-le-Pont", :aliases => "Joinville,Joinville-le-Pont,La Branche-du-Pont-de-Saint-Maur,Joinville-le-Pont", :latitude => "48.81667", :longitude => "2.46667").save
City.new(:country_id => "76", :name => "Ivry-sur-Seine", :aliases => "Ivri-sjur-Sen,Ivry,Ivry sobre Sena,Ivry-sur-Seine,ivuri=shuru=senu,ÐÐ²ÑÐ¸-ÑÑÑ-Ð¡ÐµÐ½,ã¤ã´ãªã¼ï¼ã·ã¥ã«ï¼ã»ã¼ã,Ivry-sur-Seine", :latitude => "48.81667", :longitude => "2.38333").save
City.new(:country_id => "76", :name => "Istres", :aliases => "Istra,Istre,Istres,isutoru,ÐÑÑÑÐ°,ã¤ã¹ãã«,Istres", :latitude => "43.51667", :longitude => "4.98333").save
City.new(:country_id => "76", :name => "Issy-les-Moulineaux", :aliases => "Issi-le-Mulino,Issy,Issy-les-Moulineau,Issy-les-Moulineaux,L'Union,ÐÑÑÐ¸-Ð»Ðµ-ÐÑÐ»Ð¸Ð½Ð¾,Issy-les-Moulineaux", :latitude => "48.81667", :longitude => "2.26667").save
City.new(:country_id => "76", :name => "Issoire", :aliases => "Issoire,Issoire", :latitude => "45.55", :longitude => "3.25").save
City.new(:country_id => "76", :name => "Illzach", :aliases => "Illzach,Illzach", :latitude => "47.78333", :longitude => "7.33333").save
City.new(:country_id => "76", :name => "Illkirch-Graffenstaden", :aliases => "Illkirch,Illkirch-Graffenstaden,Illkirch-Graffenstaden", :latitude => "48.52894", :longitude => "7.71523").save
City.new(:country_id => "76", :name => "Hyeres", :aliases => "Hyeres,HyerÃ¨s,HyÃ¨res,Ier,ÐÐµÑ,HyÃ¨res", :latitude => "43.11667", :longitude => "6.11667").save
City.new(:country_id => "76", :name => "Houilles", :aliases => "Houilles,Houilles", :latitude => "48.92161", :longitude => "2.19263").save
City.new(:country_id => "76", :name => "Herouville-Saint-Clair", :aliases => "Ehruvil'-Sen-Kler,Herouville,Herouville Saint-Clair,Herouville-Saint-Clair,HÃ©rouville,HÃ©rouville Saint-Clair,HÃ©rouville-Saint-Clair,Ð­ÑÑÐ²Ð¸Ð»Ñ-Ð¡ÐµÐ½-ÐÐ»ÐµÑ,HÃ©rouville-Saint-Clair", :latitude => "49.21088", :longitude => "-0.30653").save
City.new(:country_id => "76", :name => "Herblay", :aliases => "Herblay,Herblay", :latitude => "48.98994", :longitude => "2.1699").save
City.new(:country_id => "76", :name => "Henin-Beaumont", :aliases => "Ehnen-Bomon,Henin-Beaumont,Henin-Lietard,HÃ©nin-Beaumont,HÃ©nin-LiÃ©tard,L'Humanite,L'HumanitÃ©,Ð­Ð½ÐµÐ½-ÐÐ¾Ð¼Ð¾Ð½,HÃ©nin-Beaumont", :latitude => "50.41667", :longitude => "2.93333").save
City.new(:country_id => "76", :name => "Hem", :aliases => ",Hem", :latitude => "50.65256", :longitude => "3.18681").save
City.new(:country_id => "76", :name => "Hazebrouck", :aliases => "Azebruk,Hazebroek,Hazebrouck,Oazebroek,ÐÐ·ÐµÐ±ÑÑÐº,Hazebrouck", :latitude => "50.71667", :longitude => "2.53333").save
City.new(:country_id => "76", :name => "Hayange", :aliases => "Hayange,Hyange,Hayange", :latitude => "49.33333", :longitude => "6.05").save
City.new(:country_id => "76", :name => "Hautmont", :aliases => ",Hautmont", :latitude => "50.25077", :longitude => "3.92143").save
City.new(:country_id => "76", :name => "Yutz", :aliases => "Yutz Haute,Yutz", :latitude => "49.35571", :longitude => "6.1926").save
City.new(:country_id => "76", :name => "Haubourdin", :aliases => "Haubourdin,Haubourdin", :latitude => "50.6", :longitude => "2.98333").save
City.new(:country_id => "76", :name => "Halluin", :aliases => "Halluin,Halluin", :latitude => "50.78333", :longitude => "3.13333").save
City.new(:country_id => "76", :name => "Haguenau", :aliases => "Agenu,Agijeno,Hagenau,Haguenau,Khaguenau,ÐÐ³ÐµÐ½Ñ,ÐÐ³Ð¸ÑÐµÐ½Ð¾,Ð¥Ð°Ð³ÑÐµÐ½Ð°Ñ,Haguenau", :latitude => "48.81557", :longitude => "7.79051").save
City.new(:country_id => "76", :name => "Guyancourt", :aliases => "Guyancourt,Guyancourt", :latitude => "48.76667", :longitude => "2.06667").save
City.new(:country_id => "76", :name => "Gujan-Mestras", :aliases => "Gujan,Gujan-Mestras,Gujan-et-Mestras,Gujan-Mestras", :latitude => "44.63333", :longitude => "-1.06667").save
City.new(:country_id => "76", :name => "Gueret", :aliases => ",GuÃ©ret", :latitude => "46.16667", :longitude => "1.86667").save
City.new(:country_id => "76", :name => "Guerande", :aliases => "Guerande,GuÃ©rande,Gwenrann,GuÃ©rande", :latitude => "47.32911", :longitude => "-2.42829").save
City.new(:country_id => "76", :name => "Grigny", :aliases => "Grigny,Grigny", :latitude => "48.65", :longitude => "2.38333").save
City.new(:country_id => "76", :name => "Grenoble", :aliases => "Grelibre,Grenobel,Grenobl',Grenoble,Grenoblo,Grenobul,GrenÃ²ble,ge lei nuo bu er,ghrwnwbl,grenobla,grnwbl,grwnwbl,gurunoburu,ÐÑeÐ½Ð¾Ð±Ð»Ñ,ÐÑÐµÐ½Ð¾Ð±Ð»Ñ,ÐÑÐµÐ½Ð¾Ð±ÑÐ»,××¨× ×××,ØºØ±ÙÙÙØ¨Ù,Ú¯Ø±ÙÙÙØ¨Ù,à¤à¥à¤°à¥à¤¨à¥à¤¬à¥à¤²,ã°ã«ãã¼ãã«,æ ¼åè¯ºå¸å°,Grenoble", :latitude => "45.16667", :longitude => "5.71667").save
City.new(:country_id => "76", :name => "Grasse", :aliases => "Gras,Grassa,Grasse,gurasu,ÐÑÐ°Ñ,ã°ã©ã¼ã¹,Grasse", :latitude => "43.66667", :longitude => "6.91667").save
City.new(:country_id => "76", :name => "Grande-Synthe", :aliases => "Grande-Synthe,Grande-Synthe", :latitude => "51.0154", :longitude => "2.29975").save
City.new(:country_id => "76", :name => "Gradignan", :aliases => "Gradignan,Gradin'jan,ÐÑÐ°Ð´Ð¸Ð½ÑÑÐ½,Gradignan", :latitude => "44.76667", :longitude => "-0.61667").save
City.new(:country_id => "76", :name => "Goussainville", :aliases => "Goussainville,Goussainville", :latitude => "49.01367", :longitude => "2.46595").save
City.new(:country_id => "76", :name => "Gonesse", :aliases => "Gones,Gonesse,ÐÐ¾Ð½ÐµÑ,Gonesse", :latitude => "48.98693", :longitude => "2.44892").save
City.new(:country_id => "76", :name => "Givors", :aliases => "Givors,Givors", :latitude => "45.58333", :longitude => "4.76667").save
City.new(:country_id => "76", :name => "Gif-sur-Yvette", :aliases => "Gif,Gif-sur-Yvette,Zhif sir Ivet,ÐÐ¸Ñ ÑÐ¸Ñ ÐÐ²ÐµÑ,Gif-sur-Yvette", :latitude => "48.68333", :longitude => "2.13333").save
City.new(:country_id => "76", :name => "Gien", :aliases => "Gien,Gien", :latitude => "47.69332", :longitude => "2.63094").save
City.new(:country_id => "76", :name => "Gentilly", :aliases => "Gentilly,Gentilly", :latitude => "48.81667", :longitude => "2.33333").save
City.new(:country_id => "76", :name => "Gennevilliers", :aliases => "Genneville,Gennevillers,Gennevilliers,Gennevilliers", :latitude => "48.93333", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Garges-les-Gonesse", :aliases => "Garges,Garges-les-Gonesse,Garges-lÃ¨s-Gonesse,Garges-lÃ¨s-Gonesse", :latitude => "48.96791", :longitude => "2.39781").save
City.new(:country_id => "76", :name => "Gardanne", :aliases => "Gardanne,Gardanne", :latitude => "43.45491", :longitude => "5.46913").save
City.new(:country_id => "76", :name => "Garches", :aliases => "Garches,Garches", :latitude => "48.85", :longitude => "2.18333").save
City.new(:country_id => "76", :name => "Gap", :aliases => "Gap,gyappu,ÐÐ°Ð¿,ã®ã£ãã,Gap", :latitude => "44.56667", :longitude => "6.08333").save
City.new(:country_id => "76", :name => "Gagny", :aliases => "Gagny,Gagny", :latitude => "48.88333", :longitude => "2.53333").save
City.new(:country_id => "76", :name => "Frontignan", :aliases => "Frontignan,Frontin'jan,Ð¤ÑÐ¾Ð½ÑÐ¸Ð½ÑÑÐ½,Frontignan", :latitude => "43.45", :longitude => "3.75").save
City.new(:country_id => "76", :name => "Fresnes", :aliases => "Fren,Ð¤ÑÐµÐ½,Fresnes", :latitude => "48.75568", :longitude => "2.32241").save
City.new(:country_id => "76", :name => "Frejus", :aliases => "Forum Iulii,Frejus,FrejÃºs,Frezhjus,FrÃ©jus,Ð¤ÑÐµÐ¶ÑÑ,FrÃ©jus", :latitude => "43.43333", :longitude => "6.73333").save
City.new(:country_id => "76", :name => "Franconville", :aliases => "Franconville,Franconville-la-Garenne,Franconville-la-Libre,Franconville", :latitude => "48.98333", :longitude => "2.23333").save
City.new(:country_id => "76", :name => "Fougeres", :aliases => "Felger,Fougeres,FougÃ¨res,Fuzher,Ð¤ÑÐ¶ÐµÑ,FougÃ¨res", :latitude => "48.35", :longitude => "-1.2").save
City.new(:country_id => "76", :name => "Fos-sur-Mer", :aliases => "Fos,Fos-sur-Mer,FÃ²s,fosu=shuru=meru,ãã©ã¹ï¼ã·ã¥ã«ï¼ã¡ã¼ã«,Fos-sur-Mer", :latitude => "43.43774", :longitude => "4.94457").save
City.new(:country_id => "76", :name => "Forbach", :aliases => "Forbach,Forbakh,Ð¤Ð¾ÑÐ±Ð°Ñ,Forbach", :latitude => "49.18333", :longitude => "6.9").save
City.new(:country_id => "76", :name => "Fontenay-sous-Bois", :aliases => "Fontenay,Fontenay-sous-Bois,Fontne su Boa,Ð¤Ð¾Ð½ÑÐ½Ðµ ÑÑ ÐÐ¾Ð°,Fontenay-sous-Bois", :latitude => "48.85", :longitude => "2.48333").save
City.new(:country_id => "76", :name => "Fontenay-le-Comte", :aliases => "Fontenay-le-Peuple,Fontenay-le-Comte", :latitude => "46.46667", :longitude => "-0.81667").save
City.new(:country_id => "76", :name => "Fontenay-aux-Roses", :aliases => "Fontenay,Fontenay-aux-Roses,Fontne o Roz,Ð¤Ð¾Ð½ÑÐ½Ðµ Ð¾ Ð Ð¾Ð·,Fontenay-aux-Roses", :latitude => "48.78333", :longitude => "2.28333").save
City.new(:country_id => "76", :name => "Fontainebleau", :aliases => "Fontaine-la-Montagne,Fontaine-le-Vallon,Fontainebleau,Fontenblo,fontenuburo,Ð¤Ð¾Ð½ÑÐµÐ½Ð±Ð»Ð¾,ãã©ã³ãããã­ã¼,ãã©ã³ãã¼ããã­ã¼,Fontainebleau", :latitude => "48.4", :longitude => "2.7").save
City.new(:country_id => "76", :name => "Fontaine", :aliases => "Fontaine,Fontejn,Ð¤Ð¾Ð½ÑÐµÐ¹Ð½,Fontaine", :latitude => "45.19839", :longitude => "5.68265").save
City.new(:country_id => "76", :name => "Floirac", :aliases => "Floirac,Floirac", :latitude => "44.83333", :longitude => "-0.53333").save
City.new(:country_id => "76", :name => "Fleury-les-Aubrais", :aliases => "Fleury-les-Aubrais,Les Aubrais,Fleury-les-Aubrais", :latitude => "47.93333", :longitude => "1.91667").save
City.new(:country_id => "76", :name => "Flers", :aliases => "Flers,Flers-de-l'Orne,Flers", :latitude => "48.75", :longitude => "-0.56667").save
City.new(:country_id => "76", :name => "Firminy", :aliases => "Firminy,Firminy", :latitude => "45.38333", :longitude => "4.3").save
City.new(:country_id => "76", :name => "Fecamp", :aliases => "Fecamp,FÃ©camp,Secamp,SÃ¨camp,FÃ©camp", :latitude => "49.75787", :longitude => "0.37457").save
City.new(:country_id => "76", :name => "Faches-Thumesnil", :aliases => "Faches,Faches-Thumesnil", :latitude => "50.58333", :longitude => "3.06667").save
City.new(:country_id => "76", :name => "Eysines", :aliases => "Eysines,Eysines", :latitude => "44.88333", :longitude => "-0.65").save
City.new(:country_id => "76", :name => "Evry", :aliases => "Evry,Evry-Petit-Bourg,evuri,Ãvry,Ãvry-Petit-Bourg,ã¨ã´ãªã¼,Ãvry", :latitude => "48.63333", :longitude => "2.45").save
City.new(:country_id => "76", :name => "Evreux", :aliases => "Evre,Evreaux,Evreux,Evreux-le-Coudray,evuru,Ãvreux,ÐÐ²ÑÐµ,ã¨ã´ã«ã¼,Ãvreux", :latitude => "49.02414", :longitude => "1.15082").save
City.new(:country_id => "76", :name => "Etampes", :aliases => "Ehtamp,Etampes,Ãtampes,Ð­ÑÐ°Ð¼Ð¿,Ãtampes", :latitude => "48.43333", :longitude => "2.15").save
City.new(:country_id => "76", :name => "La Baule-Escoublac", :aliases => "Ar Baol-Skoubleg,Baule-Escoublac,Escoublac,Escoublac-la-Baule,La Baule,La Baule-Escoublac,La Baule-Escoublac", :latitude => "47.29221", :longitude => "-2.36395").save
City.new(:country_id => "76", :name => "Ermont", :aliases => "Ermont,Ermont", :latitude => "48.99004", :longitude => "2.25804").save
City.new(:country_id => "76", :name => "Eragny", :aliases => "Eragny,Ãragny,Ãragny", :latitude => "49.01667", :longitude => "2.1").save
City.new(:country_id => "76", :name => "Equeurdreville-Hainneville", :aliases => "Equeurdreville,Ãqueurdreville-Hainneville", :latitude => "49.64868", :longitude => "-1.65306").save
City.new(:country_id => "76", :name => "Epinay-sur-Seine", :aliases => "Epinay,Epinay-sur-Seine,Epine sir Sen,Ãpinay-sur-Seine,ÐÐ¿Ð¸Ð½Ðµ ÑÐ¸Ñ Ð¡ÐµÐ½,Ãpinay-sur-Seine", :latitude => "48.9535", :longitude => "2.31514").save
City.new(:country_id => "76", :name => "Epinal", :aliases => "Epinal,Spinalium,Spinalo,abynal,epinaru,Ãpinal,ÐÐ¿Ð¸Ð½Ð°Ð»,Ø¥Ø¨ÙÙØ§Ù,ã¨ããã«,Ãpinal", :latitude => "48.18333", :longitude => "6.45").save
City.new(:country_id => "76", :name => "Epernay", :aliases => "Epernay,Eperne,Ãpernay,ÐÐ¿ÐµÑÐ½Ðµ,Ãpernay", :latitude => "49.05", :longitude => "3.95").save
City.new(:country_id => "76", :name => "Elbeuf", :aliases => "Ehl'bef,Elbeuf,Ð­Ð»ÑÐ±ÐµÑ,Elbeuf", :latitude => "49.28669", :longitude => "1.00288").save
City.new(:country_id => "76", :name => "Elancourt", :aliases => "Elancourt,Elenkur,Ãlancourt,ÐÐ»ÐµÐ½ÐºÑÑ,Ãlancourt", :latitude => "48.78333", :longitude => "1.95").save
City.new(:country_id => "76", :name => "Ecully", :aliases => ",Ãcully", :latitude => "45.76667", :longitude => "4.76667").save
City.new(:country_id => "76", :name => "Echirolles", :aliases => "Echirolles,Eshirol,Ãchirolles,ÐÑÐ¸ÑÐ¾Ð»,Ãchirolles", :latitude => "45.1439", :longitude => "5.72883").save
City.new(:country_id => "76", :name => "Eaubonne", :aliases => "Eaubonne,Eaubonne", :latitude => "48.99712", :longitude => "2.28249").save
City.new(:country_id => "76", :name => "Dunkerque", :aliases => "Djunkerk,Duenkirchen,Duinkerke,Dukark,Dun-Libre,Dune-Libre,Dunes-Libres,Dunkerque,Dunkierka,Dunkirk,Dunquerque,Duunkerke,DÃ¼nkirchen,Lungsod ng Dunkerque,dainkarka,dankeruku,dun ke er ke,ÐÑÐ½ÐºÐµÑÐº,ÚÙÚ©Ø±Ú©,à¤¦à¥à¤à¤à¤°à¥à¤,ãã³ã±ã«ã¯,æ¦å»å°å,Dunkerque", :latitude => "51.05", :longitude => "2.36667").save
City.new(:country_id => "76", :name => "Dreux", :aliases => "Dre,Dreux,ÐÑÐµ,Dreux", :latitude => "48.73333", :longitude => "1.36667").save
City.new(:country_id => "76", :name => "Draveil", :aliases => "Draveil,Dravej,ÐÑÐ°Ð²ÐµÑ,Draveil", :latitude => "48.68333", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Drancy", :aliases => "Drancy,Dransi,ÐÑÐ°Ð½ÑÐ¸,××¨×× ×¡×,Drancy", :latitude => "48.92578", :longitude => "2.44533").save
City.new(:country_id => "76", :name => "Draguignan", :aliases => "Draginan,Draguignan,Draguinhan,ÐÑÐ°Ð³Ð¸ÑÐ°Ð½,Draguignan", :latitude => "43.53333", :longitude => "6.46667").save
City.new(:country_id => "76", :name => "Douarnenez", :aliases => "Douamenez,Douarnenez,Douarnenez", :latitude => "48.09542", :longitude => "-4.32904").save
City.new(:country_id => "76", :name => "Douai", :aliases => "Douai,Dowaai,Due,dwyh,ÐÑÐµ,Ø¯ÙÙÙ,Douai", :latitude => "50.36667", :longitude => "3.06667").save
City.new(:country_id => "76", :name => "Domont", :aliases => "Domont,Domont", :latitude => "49.02782", :longitude => "2.32638").save
City.new(:country_id => "76", :name => "Dole", :aliases => "Dole,Dolja,ÐÐ¾Ð»Ñ,Dole", :latitude => "47.1", :longitude => "5.5").save
City.new(:country_id => "76", :name => "Dijon", :aliases => "Digione,Dijon,DijÂ·on,Divio,Diviodunum,Dizhon,di rong,dijom,dijon,dyz'wn,ÐÐ¸Ð¶Ð¾Ð½,×××'××,à¤¦à¥à¤à¥à¤,ãã£ã¸ã§ã³,ç¬¬æ,Dijon", :latitude => "47.31667", :longitude => "5.01667").save
City.new(:country_id => "76", :name => "Digne-les-Bains", :aliases => "Digne,Digne-les-Bains", :latitude => "44.09252", :longitude => "6.23199").save
City.new(:country_id => "76", :name => "Dieppe", :aliases => "D'ep,Dieppe,Dijep,Djep,ÐÐ¸ÑÐµÐ¿,ÐÑÐµÐ¿,ÐÑÐµÐ¿,Dieppe", :latitude => "49.93333", :longitude => "1.08333").save
City.new(:country_id => "76", :name => "Deuil-la-Barre", :aliases => "Dej la Bar,Deuil,Deuil-la-Barre,ÐÐµÑ Ð»Ð° ÐÐ°Ñ,Deuil-la-Barre", :latitude => "48.97674", :longitude => "2.32722").save
City.new(:country_id => "76", :name => "Denain", :aliases => "Danen,Denain,ÐÐ°Ð½ÐµÐ½,Denain", :latitude => "50.33333", :longitude => "3.38333").save
City.new(:country_id => "76", :name => "Decines-Charpieu", :aliases => "Decines,Decines-Charpieu,DÃ©cines,DÃ©cines-Charpieu,DÃ©cines-Charpieu", :latitude => "45.75", :longitude => "4.96667").save
City.new(:country_id => "76", :name => "Dax", :aliases => "Akize,Daks,Dax,Lepelletier,ÐÐ°ÐºÑ,Dax", :latitude => "43.71032", :longitude => "-1.05366").save
City.new(:country_id => "76", :name => "Dammarie-les-Lys", :aliases => "Dammarie,Dammarie-les-Fontaines,Dammarie-les-Lys", :latitude => "48.51667", :longitude => "2.65").save
City.new(:country_id => "76", :name => "Cugnaux", :aliases => "Cugnaux-Vingtcasses,Cugnaux", :latitude => "43.53635", :longitude => "1.34428").save
City.new(:country_id => "76", :name => "Croix", :aliases => "Croix,Croix", :latitude => "50.66667", :longitude => "3.15").save
City.new(:country_id => "76", :name => "Creteil", :aliases => "Creteil,CrÃ©teil,Kretej,kureteiyu,ÐÑÐµÑÐµÐ¹,ÐÑÐµÑÐµÑ,ã¯ã¬ãã¤ã¦,CrÃ©teil", :latitude => "48.78333", :longitude => "2.46667").save
City.new(:country_id => "76", :name => "Crepy-en-Valois", :aliases => "Bouillant-Germinal,Crepy,Crepy-en-Valois,CrÃ©py,CrÃ©py-en-Valois,CrÃ©py-en-Valois", :latitude => "49.23359", :longitude => "2.88807").save
City.new(:country_id => "76", :name => "Creil", :aliases => "Creil,Krej,ÐÑÐµÐ¹,ÐÑÐµÑ,Creil", :latitude => "49.25672", :longitude => "2.48477").save
City.new(:country_id => "76", :name => "Cran-Gevrier", :aliases => "Gevrier,GÃ©vrier,Cran-Gevrier", :latitude => "45.9", :longitude => "6.1").save
City.new(:country_id => "76", :name => "Cournon-d'Auvergne", :aliases => "Cournon,Cournon-d'Auvergne,Cournon-d'Auvergne", :latitude => "45.75", :longitude => "3.21667").save
City.new(:country_id => "76", :name => "Courbevoie", :aliases => ",Courbevoie", :latitude => "48.89672", :longitude => "2.25666").save
City.new(:country_id => "76", :name => "Coulommiers", :aliases => "Coulommiers,Coulommiers", :latitude => "48.81451", :longitude => "3.08498").save
City.new(:country_id => "76", :name => "Coueron", :aliases => "Coueron,CouÃ«ron,Koeron,CouÃ«ron", :latitude => "47.21667", :longitude => "-1.73333").save
City.new(:country_id => "76", :name => "Coudekerque-Branche", :aliases => "Coudekerque,Coudekerque-Branche,Couderkerque-Branche,Coudekerque-Branche", :latitude => "51.02288", :longitude => "2.39359").save
City.new(:country_id => "76", :name => "Cormeilles-en-Parisis", :aliases => "Cormeilles,Cormeilles-en-Parisis,Cormeilles-en-Parisis", :latitude => "48.97111", :longitude => "2.20491").save
City.new(:country_id => "76", :name => "Corbeil-Essonnes", :aliases => "Corbeil,Corbeil-Essonnes,Corbeil-la-Montagne,Korbej Eson,Korbej-Ehsson,ÐÐ¾ÑÐ±ÐµÐ¹-Ð­ÑÑÐ¾Ð½,ÐÐ¾ÑÐ±ÐµÑ ÐÑÐ¾Ð½,Corbeil-Essonnes", :latitude => "48.6", :longitude => "2.48333").save
City.new(:country_id => "76", :name => "Conflans-Sainte-Honorine", :aliases => "Conflans,Conflans-Sainte-Honorine,Confluent-de-Seine-et-Oise,Konflan Sent Onoren,ÐÐ¾Ð½ÑÐ»Ð°Ð½ Ð¡ÐµÐ½Ñ ÐÐ½Ð¾ÑÐµÐ½,Conflans-Sainte-Honorine", :latitude => "49.00158", :longitude => "2.09694").save
City.new(:country_id => "76", :name => "Concarneau", :aliases => "Concarneau,Konk-Kerne,Konkarno,ÐÐ¾Ð½ÐºÐ°ÑÐ½Ð¾,Concarneau", :latitude => "47.87502", :longitude => "-3.92245").save
City.new(:country_id => "76", :name => "Compiegne", :aliases => "Compiegne,CompiÃ¨gne,Komp'en',Kompjen,Marat-sur-Oise,gong bi nie,ÐÐ¾Ð¼Ð¿ÑÐµÐ½Ñ,ÐÐ¾Ð¼Ð¿ÑÐµÑ,è´¡æ¯æ¶,CompiÃ¨gne", :latitude => "49.41794", :longitude => "2.82606").save
City.new(:country_id => "76", :name => "Combs-la-Ville", :aliases => "Combs,Combs-la-Ville,Komb la Vil,ÐÐ¾Ð¼Ð± Ð»Ð° ÐÐ¸Ð»,Combs-la-Ville", :latitude => "48.66667", :longitude => "2.56667").save
City.new(:country_id => "76", :name => "Pontault-Combault", :aliases => ",Pontault-Combault", :latitude => "48.79813", :longitude => "2.60676").save
City.new(:country_id => "76", :name => "Colomiers", :aliases => "Colomiers,Kolomje,ÐÐ¾Ð»Ð¾Ð¼ÑÐµ,Colomiers", :latitude => "43.61247", :longitude => "1.33278").save
City.new(:country_id => "76", :name => "Colombes", :aliases => "Colombes,Kolomb,ÐÐ¾Ð»Ð¾Ð¼Ð±,Colombes", :latitude => "48.91882", :longitude => "2.25404").save
City.new(:country_id => "76", :name => "Colmar", :aliases => "Colmar,Kol'mar,Kolmar,korumaru,ÐÐ¾Ð»Ð¼Ð°Ñ,ÐÐ¾Ð»ÑÐ¼Ð°Ñ,ã³ã«ãã¼ã«,Colmar", :latitude => "48.08333", :longitude => "7.36667").save
City.new(:country_id => "76", :name => "Cognac", :aliases => "Cognac,Conhac,Kon'jak,Konjak,ÐÐ¾Ð½ÑÑÐº,Cognac", :latitude => "45.7", :longitude => "-0.33333").save
City.new(:country_id => "76", :name => "Cluses", :aliases => "Cluses,Kljuz,ÐÐ»ÑÐ·,Cluses", :latitude => "46.06251", :longitude => "6.57497").save
City.new(:country_id => "76", :name => "Clichy-sous-Bois", :aliases => "Clichy,Clichy-sous-Bois,Klishi su Boa,ÐÐ»Ð¸ÑÐ¸ ÑÑ ÐÐ¾Ð°,Clichy-sous-Bois", :latitude => "48.9102", :longitude => "2.55324").save
City.new(:country_id => "76", :name => "Clichy", :aliases => "Clichy,Clichy-sur-Seine,Clicy,Klishi,ÐÐ»Ð¸ÑÐ¸,Clichy", :latitude => "48.90018", :longitude => "2.30952").save
City.new(:country_id => "76", :name => "Clermont-Ferrand", :aliases => "Clarmont,Clarmont-Ferrand,Clermont,Clermont-Ferrand,Cllarmont-Ferrand,CllÃ¢rmont-FÃ¨rrand,Klermon Feran,Klermon-Ferran,Klermona-Ferana,Klermona-FerÄna,kurerumon=feran,ÐÐ»ÐµÑÐ¼Ð¾Ð½ Ð¤ÐµÑÐ°Ð½,ÐÐ»ÐµÑÐ¼Ð¾Ð½-Ð¤ÐµÑÑÐ°Ð½,ã¯ã¬ã«ã¢ã³ï¼ãã§ã©ã³,Clermont-Ferrand", :latitude => "45.78333", :longitude => "3.08333").save
City.new(:country_id => "76", :name => "Clamart", :aliases => "Clamart,Klamar,Le Vignoble,ÐÐ»Ð°Ð¼Ð°Ñ,Clamart", :latitude => "48.8", :longitude => "2.26667").save
City.new(:country_id => "76", :name => "Cholet", :aliases => "Shole,Ð¨Ð¾Ð»Ðµ,Cholet", :latitude => "47.06667", :longitude => "-0.88333").save
City.new(:country_id => "76", :name => "Choisy-le-Roi", :aliases => "Choisy,Choisy-le-Roi,Choisy-sur-Seine,Shoazi le Roa,Ð¨Ð¾Ð°Ð·Ð¸ Ð»Ðµ Ð Ð¾Ð°,Choisy-le-Roi", :latitude => "48.76667", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Chilly-Mazarin", :aliases => "Chilly-Mazarin,Chilly-Mazarin", :latitude => "48.7", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Chevilly-Larue", :aliases => "Chevilly,Chevilly-Larue,Chevilly-Larue", :latitude => "48.76667", :longitude => "2.35").save
City.new(:country_id => "76", :name => "Cherbourg-Octeville", :aliases => "Cherbourg,Cherbourg-Octeville", :latitude => "49.63984", :longitude => "-1.61636").save
City.new(:country_id => "76", :name => "Chenove", :aliases => "Chenove,ChenÃ´ve,ChenÃ´ve", :latitude => "47.29323", :longitude => "5.00457").save
City.new(:country_id => "76", :name => "Chennevieres-sur-Marne", :aliases => "Chennevieres,Chennevieres-sur-Marne,ChenneviÃ¨res,ChenneviÃ¨res-sur-Marne,ChenneviÃ¨res-sur-Marne", :latitude => "48.8", :longitude => "2.51667").save
City.new(:country_id => "76", :name => "Chelles", :aliases => "Chelles,Chelles", :latitude => "48.88109", :longitude => "2.59295").save
City.new(:country_id => "76", :name => "Chaville", :aliases => "Chaville,Chaville", :latitude => "48.8", :longitude => "2.2").save
City.new(:country_id => "76", :name => "Chaumont", :aliases => "Chaumant,Chaumont,Chaumont Enbassigby,Chaumont-en-Bassigny,Shomon,shomon,Ð¨Ð¾Ð¼Ð¾Ð½,ã·ã§ã¼ã¢ã³,Chaumont", :latitude => "48.11667", :longitude => "5.13333").save
City.new(:country_id => "76", :name => "Chatou", :aliases => "Chatou,Shatu,Ð¨Ð°ÑÑ,Chatou", :latitude => "48.8898", :longitude => "2.15863").save
City.new(:country_id => "76", :name => "Chatillon", :aliases => "Chatillon,Chatillon-sous-Bagneux,ChÃ¢tillon,ChÃ¢tillon-sous-Bagneux,Fort Chatillon,Fort ChÃ¢tillon,Montagne-l'Union,ChÃ¢tillon", :latitude => "48.8", :longitude => "2.28333").save
City.new(:country_id => "76", :name => "Chatenay-Malabry", :aliases => "Chatenay,Chatenay-Malabry,Chatenay-la-Montagne,Chatenay-les-Bagneux,ChÃ¢tenay,ChÃ¢tenay-Malabry,ChÃ¢tenay-la-Montagne,ChÃ¢tenay-lÃ¨s-Bagneux,Shatne Malabri,Ð¨Ð°ÑÐ½Ðµ ÐÐ°Ð»Ð°Ð±ÑÐ¸,ChÃ¢tenay-Malabry", :latitude => "48.76667", :longitude => "2.26667").save
City.new(:country_id => "76", :name => "Chatellerault", :aliases => "Chatellerault,ChÃ¢tellerault,Shatlero,Ð¨Ð°ÑÐ»ÐµÑÐ¾,ChÃ¢tellerault", :latitude => "46.8", :longitude => "0.53333").save
City.new(:country_id => "76", :name => "Chateau-Thierry", :aliases => "Chateau-Egalite,Chateau-Thierry,ChÃ¢teau-EgalitÃ©,ChÃ¢teau-Thierry,Egalite-sur-Marne,EgalitÃ©-sur-Marne,Faubourg-du-Puits-d'Amour,Puits-d'Amour,ChÃ¢teau-Thierry", :latitude => "49.05", :longitude => "3.4").save
City.new(:country_id => "76", :name => "Chateauroux", :aliases => "Chateauroux,ChÃ¢teauroux,Indrelibre,Indreville,shatoru,ã·ã£ãã¼ã«ã¼,ChÃ¢teauroux", :latitude => "46.81667", :longitude => "1.7").save
City.new(:country_id => "76", :name => "Chateaudun", :aliases => "Chateaudun,ChÃ¢teaudun,Dun-sur-Loir,syatodeong,ì¤í ë©,ChÃ¢teaudun", :latitude => "48.08333", :longitude => "1.33333").save
City.new(:country_id => "76", :name => "Chartres", :aliases => "Autricum,Chartres,Chartrez,Shartr,sha te er,sharutoru,Ð¨Ð°ÑÑÑ,×©××¨××¨,ã·ã£ã«ãã«,æ²ç¹å°,Chartres", :latitude => "48.44685", :longitude => "1.48925").save
City.new(:country_id => "76", :name => "Charleville-Mezieres", :aliases => "Charleville,Charleville-Mezieres,Charleville-MÃ©ziÃ¨res,Libreville,Mezieres,MÃ©ziÃ¨res,Sharlevil'-Mez'er,Sharlvil Mezijer,sharuruvu~iru=mejieru,Ð¨Ð°ÑÐ»Ð²Ð¸Ð» ÐÐµÐ·Ð¸ÑÐµÑ,Ð¨Ð°ÑÐ»ÐµÐ²Ð¸Ð»Ñ-ÐÐµÐ·ÑÐµÑ,ã·ã£ã«ã«ã´ã£ã«ï¼ã¡ã¸ã¨ã¼ã«,Charleville-MÃ©ziÃ¨res", :latitude => "49.76667", :longitude => "4.71667").save
City.new(:country_id => "76", :name => "Charenton-le-Pont", :aliases => "Charenton,Charenton-Republicain,Charenton-RÃ©publicain,Charenton-le-Pont,Le Republicain,Le RÃ©publicain,Sharanton le Pon,Sharonton-l-Pon,Ð¨Ð°ÑÐ°Ð½ÑÐ¾Ð½ Ð»Ðµ ÐÐ¾Ð½,Ð¨Ð°ÑÐ¾Ð½ÑÐ¾Ð½-Ð»-ÐÐ¾Ð½,Charenton-le-Pont", :latitude => "48.81667", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Champs-sur-Marne", :aliases => "Champs,Shan sir Marn,Ð¨Ð°Ð½ ÑÐ¸Ñ ÐÐ°ÑÐ½,Champs-sur-Marne", :latitude => "48.85", :longitude => "2.6").save
City.new(:country_id => "76", :name => "Champigny-sur-Marne", :aliases => "Champigny,Champigny-sur-Marne,Sampini sir Marn,Ð¨Ð°Ð¼Ð¿Ð¸ÑÐ¸ ÑÐ¸Ñ ÐÐ°ÑÐ½,Champigny-sur-Marne", :latitude => "48.81667", :longitude => "2.51667").save
City.new(:country_id => "76", :name => "Chambery", :aliases => "Chamberi,Chambery,Chambery-le-Vieux,ChambÃ¨ri,ChambÃ©ry,ChambÃ©ry-le-Vieux,Shamberi,shanberi,Ð¨Ð°Ð¼Ð±ÐµÑÐ¸,ã·ã£ã³ããª,ChambÃ©ry", :latitude => "45.56667", :longitude => "5.93333").save
City.new(:country_id => "76", :name => "Chamalieres", :aliases => "Chamalieres,ChamaliÃ¨res,Shamal'er,Ð¨Ð°Ð¼Ð°Ð»ÑÐµÑ,ChamaliÃ¨res", :latitude => "45.78333", :longitude => "3.06667").save
City.new(:country_id => "76", :name => "Chalon-sur-Saone", :aliases => "Chalon,Chalon-sur-Saone,Chalon-sur-SaÃ´ne,Chalons,Chalons sur Saone,Chalons sur SaÃ´ne,Come-la-Montagne,CÃ´me-la-Montagne,La Montagne,Montagne-les-Chalon,Montagne-lÃ¨s-Chalon,Port-la-Montagne,Rochefort-des-Vignes,Rochefort-la-Vigne,Shalon sir Saon,Ð¨Ð°Ð»Ð¾Ð½ ÑÐ¸Ñ Ð¡Ð°Ð¾Ð½,Chalon-sur-SaÃ´ne", :latitude => "46.78333", :longitude => "4.85").save
City.new(:country_id => "76", :name => "Chalons-en-Champagne", :aliases => "Chalons,Chalons-en-Champagne,Chalons-sur-Marne,ChÃ¢lons,ChÃ¢lons-en-Champagne,ChÃ¢lons-sur-Marne,Shalon-an-Shampan',Ð¨Ð°Ð»Ð¾Ð½-Ð°Ð½-Ð¨Ð°Ð¼Ð¿Ð°Ð½Ñ,ChÃ¢lons-en-Champagne", :latitude => "48.95", :longitude => "4.36667").save
City.new(:country_id => "76", :name => "Challans", :aliases => "Challans,Challans", :latitude => "46.85", :longitude => "-1.88333").save
City.new(:country_id => "76", :name => "Cestas", :aliases => "Cestas,Sesta,Ð¡ÐµÑÑÐ°,Cestas", :latitude => "44.73333", :longitude => "-0.68333").save
City.new(:country_id => "76", :name => "Cesson-Sevigne", :aliases => "Cesson-Sevigne,Cesson-SÃ©vignÃ©,Saozon-Sevigneg,Cesson-SÃ©vignÃ©", :latitude => "48.1212", :longitude => "-1.603").save
City.new(:country_id => "76", :name => "Cergy-Pontoise", :aliases => ",Cergy-Pontoise", :latitude => "49.04117", :longitude => "2.08107").save
City.new(:country_id => "76", :name => "Cergy", :aliases => "Cergy,Serzhi,Ð¡ÐµÑÐ¶Ð¸,Cergy", :latitude => "49.03645", :longitude => "2.07613").save
City.new(:country_id => "76", :name => "Cenon", :aliases => "Cenon,Senon,Ð¡ÐµÐ½Ð¾Ð½,Cenon", :latitude => "44.85", :longitude => "-0.53333").save
City.new(:country_id => "76", :name => "Cayenne", :aliases => ",Cayenne", :latitude => "49.55858", :longitude => "1.62803").save
City.new(:country_id => "76", :name => "Cavaillon", :aliases => "Cavaillon,Clavaillan,Cavaillon", :latitude => "43.91667", :longitude => "5.28333").save
City.new(:country_id => "76", :name => "Cavaillon", :aliases => "Cavaillon,Kavajon,ÐÐ°Ð²Ð°ÑÐ¾Ð½,Cavaillon", :latitude => "43.83125", :longitude => "5.03586").save
City.new(:country_id => "76", :name => "Castres", :aliases => "Castras,Castres,Castres-sur-l'Agout,Kastras,kasutoru,ã«ã¹ãã«,Castres", :latitude => "43.6", :longitude => "2.25").save
City.new(:country_id => "76", :name => "Castelnau-le-Lez", :aliases => "Castelnau,Castelnau-le-Lez,Castelnau-le-Lez", :latitude => "43.63333", :longitude => "3.9").save
City.new(:country_id => "76", :name => "Carvin", :aliases => ",Carvin", :latitude => "50.49235", :longitude => "2.95815").save
City.new(:country_id => "76", :name => "Carrieres-sous-Poissy", :aliases => "Carrieres,Carrieres sur Poissy,Carrieres-sous-Poissy,CarriÃ¨res,CarriÃ¨res-sous-Poissy,CarriÃ¨res-sous-Poissy", :latitude => "48.94952", :longitude => "2.04068").save
City.new(:country_id => "76", :name => "Carquefou", :aliases => "Carquefou,Kerc'hfaou,Carquefou", :latitude => "47.3", :longitude => "-1.5").save
City.new(:country_id => "76", :name => "Carpentras", :aliases => "Carpentras,CarpentrÃ s,Karpantras,karupantora,ÐÐ°ÑÐ¿Ð°Ð½ÑÑÐ°Ñ,ã«ã«ãã³ãã©,Carpentras", :latitude => "44.05", :longitude => "5.05").save
City.new(:country_id => "76", :name => "Carcassonne", :aliases => "Carcasona,Carcasonne,Carcassona,Carcassonne,Karkason,Karkasson,karukason'nu,ÐÐ°ÑÐºÐ°ÑÐ¾Ð½,ÐÐ°ÑÐºÐ°ÑÑÐ¾Ð½,ã«ã«ã«ã½ã³ã,Carcassonne", :latitude => "43.21667", :longitude => "2.35").save
City.new(:country_id => "76", :name => "Canteleu", :aliases => "Canteleu,Canteleu", :latitude => "49.44065", :longitude => "1.02459").save
City.new(:country_id => "76", :name => "Cannes", :aliases => "Canas,Canes,Cannes,Chalier,ChÃ¢lier,Kan,Kannes,Kanny,jia na,kan,kan'nu,kn,mdynt kan,ÎÎ¬Î½Î½ÎµÏ,ÐÐ°Ð½,ÐÐ°Ð½Ð½Ñ,×§××,ÙØ¯ÙÙØ© ÙØ§Ù,Ú©Ø§Ù,Ú©Ù,ã«ã³ã,æçº³,Cannes", :latitude => "43.55135", :longitude => "7.01275").save
City.new(:country_id => "76", :name => "Cambrai", :aliases => "Cambrai,Cambria,Kambre,kanbure,ÐÐ°Ð¼Ð±ÑÐµ,ã«ã³ãã¬ã¼,Cambrai", :latitude => "50.16667", :longitude => "3.23333").save
City.new(:country_id => "76", :name => "Caluire-et-Cuire", :aliases => "Caluire,Caluire-et-Cuire,Kalir e Kir,Scevola,ScÃ©vola,karyuiru=e=kyuiru,ÐÐ°Ð»Ð¸Ñ Ðµ ÐÐ¸Ñ,ã«ãªã¥ã¤ã¼ã«ï¼ã¨ï¼ã­ã¥ã¤ã¼ã«,Caluire-et-Cuire", :latitude => "45.8", :longitude => "4.85").save
City.new(:country_id => "76", :name => "Calais", :aliases => "Calais,Caletum,Kale,Kales,jia lai,kare,ÐÐ°Ð»Ðµ,×§×××,ã«ã¬ã¼,å æ¥,Calais", :latitude => "50.9581", :longitude => "1.85205").save
City.new(:country_id => "76", :name => "Cahors", :aliases => "Cahors,Caors,Divona Cadurcorum,Kagor,Kaor,kaoru,ÐÐ°Ð³Ð¾Ñ,ÐÐ°Ð¾Ñ,ã«ãªã¼ã«,Cahors", :latitude => "44.4491", :longitude => "1.43663").save
City.new(:country_id => "76", :name => "Cagnes-sur-Mer", :aliases => "Cagnes,Cagnes-sur-Mer,Kan sir Mer,Kan sjur Mer,ÐÐ°Ð½ ÑÑÑ ÐÐµÑ,ÐÐ°Ñ ÑÐ¸Ñ ÐÐµÑ,Cagnes-sur-Mer", :latitude => "43.66667", :longitude => "7.15").save
City.new(:country_id => "76", :name => "Caen", :aliases => "Caen,Kan,ka ang,kan,ÐÐ°Ð½,ã«ã¼ã³,å¡æ,Caen", :latitude => "49.18585", :longitude => "-0.35912").save
City.new(:country_id => "76", :name => "Cachan", :aliases => "Cachan,Cachon,Kashan,ÐÐ°ÑÐ°Ð½,Cachan", :latitude => "48.78333", :longitude => "2.33333").save
City.new(:country_id => "76", :name => "Bry-sur-Marne", :aliases => "Bry,Bry-sur-Marne,Bry-sur-Marne", :latitude => "48.83333", :longitude => "2.51667").save
City.new(:country_id => "76", :name => "Brunoy", :aliases => "Brinoa,Brinoj,Brunoy,ÐÑÐ¸Ð½Ð¾Ð°,ÐÑÐ¸Ð½Ð¾Ñ,Brunoy", :latitude => "48.7", :longitude => "2.5").save
City.new(:country_id => "76", :name => "Bruay-la-Buissiere", :aliases => "Bruay-en-Artois,Bruay-la-BuissiÃ¨re", :latitude => "50.48333", :longitude => "2.55").save
City.new(:country_id => "76", :name => "Bron", :aliases => "Bron,ÐÑÐ¾Ð½,Bron", :latitude => "45.73333", :longitude => "4.91667").save
City.new(:country_id => "76", :name => "Brive-la-Gaillarde", :aliases => "Briv la Gajar,Briva,Brive,Brive-la-Gaillarde,ÐÑÐ¸Ð² Ð»Ð° ÐÐ°ÑÐ°Ñ,ÐÑÐ¸Ð²Ðµ-Ð»Ð°-ÐÐ°Ð¸Ð»Ð»Ð°ÑÐ´Ðµ,Brive-la-Gaillarde", :latitude => "45.15", :longitude => "1.53333").save
City.new(:country_id => "76", :name => "Brignoles", :aliases => "Brignoles,Brinhola,BrinhÃ²la,Brignoles", :latitude => "43.4", :longitude => "6.06667").save
City.new(:country_id => "76", :name => "Brie-Comte-Robert", :aliases => "Brie-Comte-Robert,Brie-Libre,Brie-la-Ville,Brie-sur-Hieres,Brie-sur-HiÃ¨res,Brie-Comte-Robert", :latitude => "48.68333", :longitude => "2.61667").save
City.new(:country_id => "76", :name => "Bretigny-sur-Orge", :aliases => "Bretigny,Bretigny-sur-Orge,Bretini sir Orz,BrÃ©tigny-sur-Orge,ÐÑÐµÑÐ¸ÑÐ¸ ÑÐ¸Ñ ÐÑÐ¶,BrÃ©tigny-sur-Orge", :latitude => "48.61667", :longitude => "2.31667").save
City.new(:country_id => "76", :name => "Brest", :aliases => "Brest,Brestia,braista,bu lei si te,buresuto,ÐÑÐµÑÑ,à¤¬à¥à¤°à¥à¤¸à¥à¤¤,ãã¬ã¹ã,å¸é·æ¯ç¹,Brest", :latitude => "48.4", :longitude => "-4.48333").save
City.new(:country_id => "76", :name => "Bressuire", :aliases => "Bressjuir,Bressuire,Givre-en-Mai,ÐÑÐµÑÑÑÐ¸Ñ,Bressuire", :latitude => "46.85", :longitude => "-0.48333").save
City.new(:country_id => "76", :name => "Bourgoin", :aliases => ",Bourgoin", :latitude => "45.58333", :longitude => "5.28333").save
City.new(:country_id => "76", :name => "Bourg-les-Valence", :aliases => "Bourg,Bourg-les-Valence,Bourg-lÃ¨s-Valence,Bourg-lÃ¨s-Valence", :latitude => "44.95", :longitude => "4.88333").save
City.new(:country_id => "76", :name => "Bourg-la-Reine", :aliases => "Bourg-Egalite,Bourg-EgalitÃ©,Bourg-la-Reine,Bourge la Reine,Bourg-la-Reine", :latitude => "48.78333", :longitude => "2.31667").save
City.new(:country_id => "76", :name => "Bourges", :aliases => "Borges,Bourges,Burzh,bu er ri,buruju,ÐÑÑÐ¶,ãã¼ã«ã¸ã¥,å¸å°æ¥,Bourges", :latitude => "47.08333", :longitude => "2.4").save
City.new(:country_id => "76", :name => "Bourg-en-Bresse", :aliases => "Borg,Bourg,Bourg-Regenere,Bourg-RegÃ©nÃ©rÃ©,Bourg-en-Bresse,Burg an Bres,BÃ´rg,Epi-d'Ain,Epi-d'Or,buru=kan=buresu,ÐÑÑÐ³ Ð°Ð½ ÐÑÐµÑ,ãã¼ã«ï¼ã«ã³ï¼ãã¬ã¹,Bourg-en-Bresse", :latitude => "46.20574", :longitude => "5.2258").save
City.new(:country_id => "76", :name => "Boulogne-sur-Mer", :aliases => "Bolonha-sobre-o-Mar,Bononia,Boulogne,Boulogne-sur-Mer,Bulon sir Mer,Bulon',Bulon'-sjur-Mer,Bulonjo,Bulonjo-ce-Maro,Bulonjo-sur-Maro,Bulonjo-Äe-Maro,Gesoriacum,Itius Portus,Port-de-l'Union,Portus Itius,buronyu=shuru=meru,ÐÑÐ»Ð¾Ð½Ñ,ÐÑÐ»Ð¾Ð½Ñ-ÑÑÑ-ÐÐµÑ,ÐÑÐ»Ð¾Ñ ÑÐ¸Ñ ÐÐµÑ,ãã­ã¼ãã¥ï¼ã·ã¥ã«ï¼ã¡ã¼ã«,Boulogne-sur-Mer", :latitude => "50.71667", :longitude => "1.61667").save
City.new(:country_id => "76", :name => "Boulogne-Billancourt", :aliases => "Billancourt,Boulogne,Boulogne-Billancourt,Boulogne-sur-Seine,Bulon Bijankur,buronyu=biyankuru,ÐÑÐ»Ð¾Ñ ÐÐ¸ÑÐ°Ð½ÐºÑÑ,ãã­ã¼ãã¥ï¼ãã¤ã³ã¯ã¼ã«,Boulogne-Billancourt", :latitude => "48.83333", :longitude => "2.25").save
City.new(:country_id => "76", :name => "Bouguenais", :aliases => "Bougenais,Bouguenais,Kervegon,Bouguenais", :latitude => "47.18333", :longitude => "-1.61667").save
City.new(:country_id => "76", :name => "Bordeaux", :aliases => "Bordeaux,Bordele,Bordeos,Bordeu,Bordeus,Bordo,Bordox,Bordozo,BordÃ¨u,BordÃ©us,BordÃ²,BordÃ´x,Bornto,Bourdel,Burdeos,Burdeus,Burdigala,Gorad Bardo,bo er duo,boleudo,bordo,bordu,borudo,bwrdw,bxr do,ÎÏÎ¿ÏÎ½ÏÏ,ÐÐ¾ÑÐ´Ð¾,ÐÐ¾ÑÐ°Ð´ ÐÐ°ÑÐ´Ð¾,Ô²Õ¸ÖÕ¤Õ¸,×××¨××,Ø¨ÙØ±Ø¯Ù,Ø¨ÙØ±ÚÛÚ©Ø³,à¤¬à¥à¤°à¥à¤¦à¥,à¤¬à¥à¤°à¥à¤¦à¥,à¸à¸­à¸£à¹à¹à¸,ááá áá,ãã«ãã¼,æ³¢å°å¤,ë³´ë¥´ë,Bordeaux", :latitude => "44.83333", :longitude => "-0.56667").save
City.new(:country_id => "76", :name => "Bonneuil-sur-Marne", :aliases => "Bonneuil,Bonneuil-sur-Marne,Bonneuil-sur-Marne", :latitude => "48.76667", :longitude => "2.48333").save
City.new(:country_id => "76", :name => "Bondy", :aliases => "Bondi,Bondy,ÐÐ¾Ð½Ð´Ð¸,Bondy", :latitude => "48.9018", :longitude => "2.48931").save
City.new(:country_id => "76", :name => "Boissy-Saint-Leger", :aliases => "Boissy,Boissy-Saint-Leger,Boissy-Saint-LÃ©ger,Boissy-la-Montagne,Boissy-Saint-LÃ©ger", :latitude => "48.75", :longitude => "2.51667").save
City.new(:country_id => "76", :name => "Bois-Colombes", :aliases => "Boa Kolomb,Boa Kolon,Bois-Colombes,ÐÐ¾Ð° ÐÐ¾Ð»Ð¾Ð¼Ð±,ÐÐ¾Ð° ÐÐ¾Ð»Ð¾Ð½,Bois-Colombes", :latitude => "48.91936", :longitude => "2.27484").save
City.new(:country_id => "76", :name => "Bobigny", :aliases => "Bobigny,Bobin'i,Bobini,bobini,ÐÐ¾Ð±Ð¸Ð½ÑÐ¸,ÐÐ¾Ð±Ð¸ÑÐ¸,ãããã¼,Bobigny", :latitude => "48.9", :longitude => "2.45").save
City.new(:country_id => "76", :name => "Blois", :aliases => "Bleaz,Bloa,Blois,Blua,burowa,ÐÐ»Ð¾Ð°,ÐÐ»ÑÐ°,ãã­ã¯,Blois", :latitude => "47.58333", :longitude => "1.33333").save
City.new(:country_id => "76", :name => "Blanquefort", :aliases => "Blanquefort,Blanquefort", :latitude => "44.91667", :longitude => "-0.63333").save
City.new(:country_id => "76", :name => "Blagnac", :aliases => "Blagnac,Blanak,ÐÐ»Ð°ÑÐ°Ðº,Blagnac", :latitude => "43.63333", :longitude => "1.4").save
City.new(:country_id => "76", :name => "Bischheim", :aliases => "Bischheim,Bischheim", :latitude => "48.61612", :longitude => "7.75343").save
City.new(:country_id => "76", :name => "Biarritz", :aliases => "Biarric,Biarritz,Biarriz,Bijaric,Miarritze,bi ya li ci,ÐÐ¸Ð°ÑÑÐ¸Ñ,ÐÐ¸ÑÐ°ÑÐ¸Ñ,æ¯äºéè¨,Biarritz", :latitude => "43.48333", :longitude => "-1.56667").save
City.new(:country_id => "76", :name => "Bezons", :aliases => "Bezon,Bezons,ÐÐµÐ·Ð¾Ð½,Bezons", :latitude => "48.92426", :longitude => "2.2128").save
City.new(:country_id => "76", :name => "Beziers", :aliases => "Baeterrae,Besiers,BesiÃ¨rs,Bez'e,Beziers,Bezije,Bezje,BÃ©ziers,ÐÐµÐ·Ð¸ÑÐµ,ÐÐµÐ·ÑÐµ,ÐÐµÐ·ÑÐµ,BÃ©ziers", :latitude => "43.34762", :longitude => "3.21899").save
City.new(:country_id => "76", :name => "Bethune", :aliases => "Beten,Bethune,Betin,Betjun,BÃ©thune,ÐÐµÑÐµÐ½,ÐÐµÑÐ¸Ð½,ÐÐµÑÑÐ½,BÃ©thune", :latitude => "50.53333", :longitude => "2.63333").save
City.new(:country_id => "76", :name => "Besancon", :aliases => "Becoinson,Besancon,Besanson,Besanzon,BesanzÃ³n,BesanÃ§on,Bezanson,Bezansona,Bezansonas,Vesuntio,bei sang song,bejhamsom,bexs xngsng,bezansoni,buzanson,bzanswn,ÎÏÎµÎ¶Î±Î½ÏÏÎ½,ÐÐµÐ·Ð°Ð½ÑÐ¾Ð½,ÐÐµÑÐ°Ð½ÑÐ¾Ð½,Ô²Õ¥Õ¦Õ¡Õ¶Õ½Õ¸Õ¶,×××× ×¡××,Ø¨Ø²Ø§ÙØ³ÙÙ,à¤¬à¥à¤à¤¾à¤à¤¸à¥à¤,à¹à¸à¸­à¸à¹à¸­à¸à¸à¸,áááááá¡ááá,ãã¶ã³ã½ã³,è´æ¡æ¾,BesanÃ§on", :latitude => "47.25", :longitude => "6.03333").save
City.new(:country_id => "76", :name => "Bergerac", :aliases => "Bergerac,Berzherak,Brageirac,ÐÐµÑÐ¶ÐµÑÐ°Ðº,Bergerac", :latitude => "44.85", :longitude => "0.48333").save
City.new(:country_id => "76", :name => "Berck", :aliases => "Berck-sur-Mer,Berck", :latitude => "50.4", :longitude => "1.6").save
City.new(:country_id => "76", :name => "Berck-Plage", :aliases => ",Berck-Plage", :latitude => "50.40704", :longitude => "1.56446").save
City.new(:country_id => "76", :name => "Belfort", :aliases => "Beffert,Bel'for,Belfor,Belfort,beruforu,ÐÐµÐ»ÑÐ¾Ñ,ÐÐµÐ»ÑÑÐ¾Ñ,ãã«ãã©ã¼ã«,Belfort", :latitude => "47.63333", :longitude => "6.86667").save
City.new(:country_id => "76", :name => "Begles", :aliases => "Begles,Beglese,BÃ¨gles,ÐÐµÐ³Ð»ÐµÑÐµ,BÃ¨gles", :latitude => "44.8", :longitude => "-0.53333").save
City.new(:country_id => "76", :name => "Beauvais", :aliases => "Beauvais,Bove,Bovoa,Duthil-la-Montagne,La Chaussee-de-la-Montagne,La ChaussÃ©e-de-la-Montagne,bo wei,bovu~e,ÐÐ¾Ð²Ðµ,ÐÐ¾Ð²Ð¾Ð°,ãã¼ã´ã§,åé¦,Beauvais", :latitude => "49.43333", :longitude => "2.08333").save
City.new(:country_id => "76", :name => "Beaune", :aliases => "Beaune,Bon,bonu,ÐÐ¾Ð½,ãã¼ã,Beaune", :latitude => "47.03333", :longitude => "4.83333").save
City.new(:country_id => "76", :name => "Bayonne", :aliases => "Baiona,Bajon,Bajono,Bayona,Bayonne,ÐÐ°Ð¹Ð¾Ð½,ÐÐ°ÑÐ¾Ð½,Bayonne", :latitude => "43.48333", :longitude => "-1.48333").save
City.new(:country_id => "76", :name => "Bayeux", :aliases => "Baje,Bajjo,Bajocae,Bayeux,baiyu,ÐÐ°Ð¹Ñ,ÐÐ°ÑÐµ,ãã¤ã¦ã¼,Bayeux", :latitude => "49.27732", :longitude => "-0.7039").save
City.new(:country_id => "76", :name => "Bastia", :aliases => "Bastia,Bastija,ba si di ya,basutia,ÐÐ°ÑÑÐ¸Ñ,ãã¹ãã£ã¢,å·´æ¯èäº,Bastia", :latitude => "42.70278", :longitude => "9.45").save
City.new(:country_id => "76", :name => "Bar-le-Duc", :aliases => "Bar,Bar le Dik,Bar-le-Duc,Bar-sur-Meurthe,Bar-sur-Ornain,baru=ru=de~yukku,ÐÐ°Ñ Ð»Ðµ ÐÐ¸Ðº,ãã«ï¼ã«ï¼ãã¥ãã¯,Bar-le-Duc", :latitude => "48.78333", :longitude => "5.16667").save
City.new(:country_id => "76", :name => "Balma", :aliases => "Balma,Balma", :latitude => "43.61111", :longitude => "1.49944").save
City.new(:country_id => "76", :name => "Bagnols-sur-Ceze", :aliases => "Bagnols,Bagnols-sur-Ceze,Bagnols-sur-CÃ¨ze,Bagnols-sur-CÃ¨ze", :latitude => "44.16667", :longitude => "4.61667").save
City.new(:country_id => "76", :name => "Bagnolet", :aliases => "Bagnolet,Ban'ole,Banole,ÐÐ°Ð½ÑÐ¾Ð»Ðµ,ÐÐ°ÑÐ¾Ð»Ðµ,Bagnolet", :latitude => "48.86667", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Bagneux", :aliases => "Bagneux,Bano,ÐÐ°ÑÐ¾,Bagneux", :latitude => "48.8", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Avon", :aliases => "Avon,Avon", :latitude => "48.4", :longitude => "2.71667").save
City.new(:country_id => "76", :name => "Avion", :aliases => "Avion,Avion", :latitude => "50.4", :longitude => "2.83333").save
City.new(:country_id => "76", :name => "Avignon", :aliases => "Abinion,Avennio,Avignon,Avignone,Avin'on,Avinhao,Avinhon,AvinhÃ£o,Avinjonas,Avinjono,Avinon,Avinon - Avignon,Avinyo,Avinyon,AvinyÃ³,AvinyÃ³n,AviÃ±Ã³n,AviÃ±Ã³n - Avignon,Awinion,abinyong,avinioni,avu~inyon,awynywn,ya wei nong,ÎÎ²Î¹Î½Î¹ÏÎ½,ÐÐ²Ð¸Ð½ÑÐ¾Ð½,ÐÐ²Ð¸ÑÐ¾Ð½,ÐÐ²ÑÐ½ÑÐ¹Ð¾Ð½,×××× ×××,Ø¢ÙÛÙÛÙÙ,áááááááá,ã¢ã´ã£ãã§ã³,äºç¶­è¾²,ìë¹ë½,Avignon", :latitude => "43.94834", :longitude => "4.80892").save
City.new(:country_id => "76", :name => "Auxerre", :aliases => "Auxerre,Okser,Oser,oseru,ou sai er,ÐÐºÑÐµÑ,ÐÑÐµÑ,ãªã»ã¼ã«,æ¬§å¡å°,Auxerre", :latitude => "47.8", :longitude => "3.56667").save
City.new(:country_id => "76", :name => "Autun", :aliases => "Autun,Bibracte,Utan,otan,Ð£ÑÐ°Ð½,ãªã¼ã¿ã³,Autun", :latitude => "46.95", :longitude => "4.3").save
City.new(:country_id => "76", :name => "Aurillac", :aliases => "Aurillac,Orijak,Orilak,Orlhac,oriyakku,ÐÑÐ¸ÑÐ°Ðº,ÐÑÐ¸ÑÐ°Ðº,ãªã¼ãªã¤ãã¯,Aurillac", :latitude => "44.91667", :longitude => "2.45").save
City.new(:country_id => "76", :name => "Aulnay-sous-Bois", :aliases => "Aulnay,Aulnay-sous-Bois,olne su boa,ÐÐ»Ð½Ðµ ÑÑ ÐÐ¾Ð°,Aulnay-sous-Bois", :latitude => "48.93814", :longitude => "2.49402").save
City.new(:country_id => "76", :name => "Audincourt", :aliases => "Audincourt,Audincourt", :latitude => "47.48333", :longitude => "6.83333").save
City.new(:country_id => "76", :name => "Auch", :aliases => "Auch,Aush,Auski,Osh,Ush,oshu,ÐÑ,Ð£Ñ,ãªã¼ã·ã¥,Auch", :latitude => "43.65", :longitude => "0.58333").save
City.new(:country_id => "76", :name => "Aubervilliers", :aliases => "Aubervilles,Aubervilliers,Aubervilliers", :latitude => "48.91667", :longitude => "2.38333").save
City.new(:country_id => "76", :name => "Aubagne", :aliases => "Aubagne,Aubagne en Provence,Oban,Oban',Obane,ObanÄ,Ubane,obanyu,ÐÐ±Ð°Ð½,ÐÐ±Ð°Ð½Ñ,ÐÐ±Ð°Ñ,Ð£Ð±Ð°ÑÐµ,ãªã¼ãã¼ãã¥,Aubagne", :latitude => "43.29276", :longitude => "5.57067").save
City.new(:country_id => "76", :name => "Athis-Mons", :aliases => "Athis,Athis-Mons,Ati Mon,ÐÑÐ¸ ÐÐ¾Ð½,Athis-Mons", :latitude => "48.71667", :longitude => "2.4").save
City.new(:country_id => "76", :name => "Asnieres-sur-Seine", :aliases => "An'er-sjur-Sen,Asnieres,AsniÃ¨res,ÐÐ½ÑÐµÑ-ÑÑÑ-Ð¡ÐµÐ½,AsniÃ¨res-sur-Seine", :latitude => "48.91667", :longitude => "2.28333").save
City.new(:country_id => "76", :name => "Arras", :aliases => "Aras,Arras,Atrecht,a la si,arasu,ÐÑÐ°Ñ,ÐÑÑÐ°Ñ,ã¢ã©ã¹,é¿ææ¯,Arras", :latitude => "50.29301", :longitude => "2.78186").save
City.new(:country_id => "76", :name => "Armentieres", :aliases => "Armant'er,Armantjer,Armentieres,Armentiers,ArmentiÃ¨res,Armontijer,ÐÑÐ¼Ð°Ð½ÑÑÐµÑ,ÐÑÐ¼Ð°Ð½ÑÑÐµÑ,ÐÑÐ¼Ð¾Ð½ÑÐ¸ÑÐµÑ,ArmentiÃ¨res", :latitude => "50.68333", :longitude => "2.88333").save
City.new(:country_id => "76", :name => "Arles", :aliases => "Arelate,Arl,Arl',Arle,Arles,Arles-Trinquetaille,Arles-sur-Rhone,Arles-sur-RhÃ´ne,aruru,ÐÑÐ»,ÐÑÐ»Ñ,××¨×,ã¢ã«ã«,Arles", :latitude => "43.67681", :longitude => "4.63031").save
City.new(:country_id => "76", :name => "Argenteuil", :aliases => "Argenteuil,Arzhantej,Arzhentoj,arujanto~uiyu,ÐÑÐ¶Ð°Ð½ÑÐµÐ¹,ÐÑÐ¶Ð°Ð½ÑÐµÑ,ÐÑÐ¶ÐµÐ½ÑÐ¾Ñ,ã¢ã«ã¸ã£ã³ãã¥ã¤ã¦,Argenteuil", :latitude => "48.95", :longitude => "2.25").save
City.new(:country_id => "76", :name => "Argentan", :aliases => "Argentan,Arzhantan,ÐÑÐ¶Ð°Ð½ÑÐ°Ð½,Argentan", :latitude => "48.75", :longitude => "-0.01667").save
City.new(:country_id => "76", :name => "Arcueil", :aliases => "Arcueil,Arkej,ÐÑÐºÐµÑ,Arcueil", :latitude => "48.8", :longitude => "2.33333").save
City.new(:country_id => "76", :name => "Antony", :aliases => "Antony,Ontoni,ÐÐ½ÑÐ¾Ð½Ð¸,Antony", :latitude => "48.75", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Antibes", :aliases => "Antib,Antibes,Antipolis,ÐÐ½ÑÐ¸Ð±,Antibes", :latitude => "43.58333", :longitude => "7.11667").save
City.new(:country_id => "76", :name => "Annonay", :aliases => "Annonay,Anone,ÐÐ½Ð¾Ð½Ðµ,Annonay", :latitude => "45.23333", :longitude => "4.66667").save
City.new(:country_id => "76", :name => "Annemasse", :aliases => "Annemasse,anmas,ÐÐ½Ð¼Ð°Ñ,Annemasse", :latitude => "46.19439", :longitude => "6.23775").save
City.new(:country_id => "76", :name => "Annecy-le-Vieux", :aliases => "Anesi le Vje,Annecy-le-Vieux,Annesi-le-V'e,ÐÐ½ÐµÑÐ¸ Ð»Ðµ ÐÑÐµ,ÐÐ½Ð½ÐµÑÐ¸-Ð»Ðµ-ÐÑÐµ,Annecy-le-Vieux", :latitude => "45.91667", :longitude => "6.15").save
City.new(:country_id => "76", :name => "Annecy", :aliases => "Annecy,Ansi,Eneci,ansi,anushi,Ãneci,ÐÐ½ÑÐ¸,ã¢ãã·ã¼,ìì,Annecy", :latitude => "45.9", :longitude => "6.11667").save
City.new(:country_id => "76", :name => "Angouleme", :aliases => "An'nkoulem,Angouleme,AngoulÃªme,Angulem,Angulema,Angulema - Angouleme,Angulema - AngoulÃªme,Angulemo,Engoleime,Montagne-Charente,Ongulem,anguremu,ÎÎ½Î³ÎºÎ¿ÏÎ»Î­Î¼,ÐÐ½Ð³ÑÐ»ÐµÐ¼,ÐÐ½Ð³ÑÐ»ÐµÐ¼,ã¢ã³ã°ã¬ã¼ã ,AngoulÃªme", :latitude => "45.65", :longitude => "0.15").save
City.new(:country_id => "76", :name => "Anglet", :aliases => "Angelu,Angl,Anglet,Ongle,ÐÐ½Ð³Ð»,ÐÐ½Ð³Ð»Ðµ,Anglet", :latitude => "43.48333", :longitude => "-1.53333").save
City.new(:country_id => "76", :name => "Angers", :aliases => "Andecavis,Angero,Angers,Angieus,Anje,Anze,Anzhe,Anzher,AnÄero,AnÅ¾Ä,AnÅ¾Ä,AÃ±je,Bonne-Terre,Fruits-Sucres,Fruits-SucrÃ©s,ang re,anje,anzhe,anzhw,ÐÐ½Ð¶Ðµ,ÐÐ½Ð¶ÐµÑ,×× ×'×,Ø¢ÙÚÙ,áááá,ã¢ã³ã¸ã§,æç­,Angers", :latitude => "47.46667", :longitude => "-0.55").save
City.new(:country_id => "76", :name => "Amiens", :aliases => "Am'en,Amien,Amiens,Amijen,Amjen,Samarobriva,amian,ya mian,ÐÐ¼'ÑÐ½,ÐÐ¼Ð¸ÐµÐ½,ÐÐ¼Ð¸ÑÐµÐ½,ÐÐ¼ÑÐµÐ½,ÐÐ¼ÑÐµÐ½,×××××,ã¢ãã¢ã³,äºç ,Amiens", :latitude => "49.9", :longitude => "2.3").save
City.new(:country_id => "76", :name => "Allauch", :aliases => "Allauch,Allauch", :latitude => "43.33573", :longitude => "5.48201").save
City.new(:country_id => "76", :name => "Alfortville", :aliases => "Alfortvij,Alfortville,Alforvil,ÐÐ»ÑÐ¾ÑÐ²Ð¸Ð»,ÐÐ»ÑÐ¾ÑÑÐ²Ð¸Ñ,Alfortville", :latitude => "48.8", :longitude => "2.41667").save
City.new(:country_id => "76", :name => "Ales", :aliases => "Alais,Ale,Ales,AlÃ¨s,Auxon,Pont-Auzon,ÐÐ»Ðµ,AlÃ¨s", :latitude => "44.13333", :longitude => "4.08333").save
City.new(:country_id => "76", :name => "Alencon", :aliases => "Alanson,Alencon,Alenson,AlenÃ§on,Alonson,aranson,ÐÐ»Ð°Ð½ÑÐ¾Ð½,ÐÐ»ÐµÐ½ÑÐ¾Ð½,ÐÐ»Ð¾Ð½ÑÐ¾Ð½,ã¢ã©ã³ã½ã³,AlenÃ§on", :latitude => "48.43333", :longitude => "0.08333").save
City.new(:country_id => "76", :name => "Albi", :aliases => "Al'bi,Albi,AlbÃ­,arubi,ÐÐ»Ð±Ð¸,ÐÐ»ÑÐ±Ð¸,××××,ã¢ã«ã,Albi", :latitude => "43.9298", :longitude => "2.148").save
City.new(:country_id => "76", :name => "Albertville", :aliases => "Al'bervil',Albertville,Albervij,Albervil,Arbertvile,ArbÃ¨rtvile,Roc-Libre,Valbeau,aruberuvu~iru,ÐÐ»Ð±ÐµÑÐ²Ð¸Ð»,ÐÐ»Ð±ÐµÑÐ²Ð¸Ñ,ÐÐ»ÑÐ±ÐµÑÐ²Ð¸Ð»Ñ,ÐÐ»ÑÐ±ÐµÑÐ²ÑÐ»Ñ,ã¢ã«ãã¼ã«ã´ã£ã«,Albertville", :latitude => "45.67452", :longitude => "6.39061").save
City.new(:country_id => "76", :name => "Ajaccio", :aliases => "Aiacciu,Ajaccio,Ajacciu,Ajachcho,Ajachio,Azhaksio,a ya ke xiao,a ya ke xiu,ajagsio,ajakushio,ÐÐ¶Ð°ÐºÑÐ¸Ð¾,ÐÑÑÑÐ¾,ÐÑÐ°ÑÐ¸Ð¾,ã¢ã¸ã£ã¯ã·ãª,é¿éåä¿®,é¿éåè,ìììì¤,Ajaccio", :latitude => "41.91667", :longitude => "8.73333").save
City.new(:country_id => "76", :name => "Aix-les-Bains", :aliases => "Aix-les-Bains,Eks le Ben,Eks-les-Bjan,ekusu=re=ban,ÐÐºÑ Ð»Ðµ ÐÐµÐ½,ÐÐºÑ-Ð»ÐµÑ-ÐÑÐ°Ð½,ã¨ã¯ã¹ï¼ã¬ï¼ãã³,Aix-les-Bains", :latitude => "45.7", :longitude => "5.91667").save
City.new(:country_id => "76", :name => "Aix-en-Provence", :aliases => "Aikso Provenca,Ais de Provenca,Ais de ProvenÃ§a,Aix,Aix-en-Provence,Aquae Sextiae,Ehks-an-Provans,Eks an Provans,egsangpeulobangseu,ekusu=an=purovu~ansu,ÐÐºÑ Ð°Ð½ ÐÑÐ¾Ð²Ð°Ð½Ñ,Ð­ÐºÑ-Ð°Ð½-ÐÑÐ¾Ð²Ð°Ð½Ñ,ã¨ã¯ã¹ï¼ã¢ã³ï¼ãã­ã´ã¡ã³ã¹,ììíë¡ë°©ì¤,Aix-en-Provence", :latitude => "43.5283", :longitude => "5.44973").save
City.new(:country_id => "76", :name => "Agen", :aliases => "Agen,Azhan,Azhon,ajan,ÐÐ¶Ð°Ð½,ÐÐ¶Ð¾Ð½,ã¢ã¸ã£ã³,Agen", :latitude => "44.2", :longitude => "0.63333").save
City.new(:country_id => "76", :name => "Agde", :aliases => "Agd,Agde,ÐÐ³Ð´,Agde", :latitude => "43.31083", :longitude => "3.47583").save
City.new(:country_id => "76", :name => "Acheres", :aliases => "Acheres,AchÃ¨res,AchÃ¨res", :latitude => "48.96116", :longitude => "2.06882").save
City.new(:country_id => "76", :name => "Abbeville", :aliases => "Abbatis villa,Abbeville,AbbÃ©ville,Abevil,Abeville,Abvij,Abvil,Abvil',ÐÐ±Ð²Ð¸Ð»,ÐÐ±Ð²Ð¸Ð»Ñ,ÐÐ±Ð²Ð¸Ñ,ÐÐ±ÐµÐ²Ð¸Ð»,Abbeville", :latitude => "50.1", :longitude => "1.83333").save
City.new(:country_id => "76", :name => "Villeneuve-d'Ascq", :aliases => ",Villeneuve-d'Ascq", :latitude => "50.61669", :longitude => "3.16664").save
City.new(:country_id => "76", :name => "Les Ulis", :aliases => ",Les Ulis", :latitude => "48.68167", :longitude => "2.16944").save
City.new(:country_id => "76", :name => "Bourgoin-Jallieu", :aliases => ",Bourgoin-Jallieu", :latitude => "45.58611", :longitude => "5.27361").save
