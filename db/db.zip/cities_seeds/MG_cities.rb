City.new(:country_id => "144", :name => "Toamasina", :aliases => "Tamatave,Toamasina,Tuamasina,tu a ma xi na,Ð¢ÑÐ°Ð¼Ð°ÑÐ¸Ð½Ð°,å¾é¿é©¬è¥¿çº³,Toamasina", :latitude => "-18.16667", :longitude => "49.38333").save
City.new(:country_id => "144", :name => "Vondrozo", :aliases => ",Vondrozo", :latitude => "-22.81667", :longitude => "47.28333").save
City.new(:country_id => "144", :name => "Vohibinany", :aliases => ",Vohibinany", :latitude => "-17.35", :longitude => "49.03333").save
City.new(:country_id => "144", :name => "Vavatenina", :aliases => ",Vavatenina", :latitude => "-17.46667", :longitude => "49.2").save
City.new(:country_id => "144", :name => "Vangaindrano", :aliases => "Vangaindrano,Vangaindrano", :latitude => "-23.35", :longitude => "47.6").save
City.new(:country_id => "144", :name => "Tsiroanomandidy", :aliases => ",Tsiroanomandidy", :latitude => "-18.76667", :longitude => "46.03333").save
City.new(:country_id => "144", :name => "Tsiombe", :aliases => "Tsihombe,Tsiombe,Tsiombe", :latitude => "-25.3", :longitude => "45.48333").save
City.new(:country_id => "144", :name => "Tsaratanana", :aliases => ",Tsaratanana", :latitude => "-16.78333", :longitude => "47.65").save
City.new(:country_id => "144", :name => "Toliara", :aliases => "Toliara,Toliary,Tulear,Tuliara,Tullear,Ð¢ÑÐ»Ð¸Ð°ÑÐ°,Toliara", :latitude => "-23.35", :longitude => "43.66667").save
City.new(:country_id => "144", :name => "Fort Dauphin", :aliases => "Faradofay,Taolanaro,Tolagnaro,TÃ´lagnaro,Fort Dauphin", :latitude => "-25.03183", :longitude => "46.99981").save
City.new(:country_id => "144", :name => "Soavinandriana", :aliases => "Seavinandriana,Soavinandriana,Soavinandriana", :latitude => "-19.16667", :longitude => "46.73333").save
City.new(:country_id => "144", :name => "Soanierana Ivongo", :aliases => "Saanierana,Soahierana,Soanierana,Soanierana Ivongo,Soanierana Ivongo", :latitude => "-16.91667", :longitude => "49.58333").save
City.new(:country_id => "144", :name => "Sambava", :aliases => "Sahambava,Sahambavany,Sambaha,Sambava,Ð¡Ð°Ð¼Ð±Ð°Ð²Ð°,Sambava", :latitude => "-14.26667", :longitude => "50.16667").save
City.new(:country_id => "144", :name => "Sakaraha", :aliases => "Sakaraha,Sakaray,Sakaraha", :latitude => "-22.9", :longitude => "44.53333").save
City.new(:country_id => "144", :name => "Nosy Varika", :aliases => ",Nosy Varika", :latitude => "-20.58333", :longitude => "48.53333").save
City.new(:country_id => "144", :name => "Morondava", :aliases => "Morondava,Morondava", :latitude => "-20.28333", :longitude => "44.28333").save
City.new(:country_id => "144", :name => "Moramanga", :aliases => ",Moramanga", :latitude => "-18.93333", :longitude => "48.2").save
City.new(:country_id => "144", :name => "Miandrivazo", :aliases => "Miandrivazo,Miandrivazo", :latitude => "-19.51667", :longitude => "45.46667").save
City.new(:country_id => "144", :name => "Marovoay", :aliases => "Marovoay,Marovoay", :latitude => "-16.1", :longitude => "46.63333").save
City.new(:country_id => "144", :name => "Marolambo", :aliases => ",Marolambo", :latitude => "-20.05", :longitude => "48.11667").save
City.new(:country_id => "144", :name => "Maroantsetra", :aliases => "Maroantsetra,Maruancentre,ÐÐ°ÑÑÐ°Ð½ÑÐµÐ½ÑÑÐµ,Maroantsetra", :latitude => "-15.43333", :longitude => "49.73333").save
City.new(:country_id => "144", :name => "Manjakandriana", :aliases => ",Manjakandriana", :latitude => "-18.91667", :longitude => "47.8").save
City.new(:country_id => "144", :name => "Mananjary", :aliases => ",Mananjary", :latitude => "-21.21667", :longitude => "48.33333").save
City.new(:country_id => "144", :name => "Mananara Avaratra", :aliases => "Mananara,Mananara Avaratra,Mananara Avaratra", :latitude => "-16.16667", :longitude => "49.76667").save
City.new(:country_id => "144", :name => "Manakara", :aliases => "Manakara,Manankara,ÐÐ°Ð½Ð°ÐºÐ°ÑÐ°,Manakara", :latitude => "-22.13333", :longitude => "48.01667").save
City.new(:country_id => "144", :name => "Mahanoro", :aliases => ",Mahanoro", :latitude => "-19.9", :longitude => "48.8").save
City.new(:country_id => "144", :name => "Mahajanga", :aliases => "Mahajanga,Majunga,Makhadzanga,mahajanga,ÐÐ°ÑÐ°Ð´Ð·Ð°Ð½Ð³Ð°,ããã¸ã£ã³ã¬,Mahajanga", :latitude => "-15.71667", :longitude => "46.31667").save
City.new(:country_id => "144", :name => "Ikongo", :aliases => "Fort Carhot,Fort-Carnot,Ikongo,Ikongo", :latitude => "-21.88333", :longitude => "47.43333").save
City.new(:country_id => "144", :name => "Ikalamavony", :aliases => "Ikalamavony,Ikalamavony", :latitude => "-21.15", :longitude => "46.58333").save
City.new(:country_id => "144", :name => "Ihosy", :aliases => "Ihosy,Ihosy", :latitude => "-22.4", :longitude => "46.11667").save
City.new(:country_id => "144", :name => "Ifanadiana", :aliases => ",Ifanadiana", :latitude => "-21.3", :longitude => "47.63333").save
City.new(:country_id => "144", :name => "Fianarantsoa", :aliases => "Fianarancua,Fianarantsoa,Ð¤Ð¸Ð°Ð½Ð°ÑÐ°Ð½ÑÑÐ°,Fianarantsoa", :latitude => "-21.43333", :longitude => "47.08333").save
City.new(:country_id => "144", :name => "Fenoarivo Be", :aliases => "Fenoarivo,Fenoarivo Afovoany,Fenoarivo Be,Fenoarivo Be", :latitude => "-18.43333", :longitude => "46.56667").save
City.new(:country_id => "144", :name => "Fenoarivo Atsinanana", :aliases => "Fenerive,Fenerive-Atsinanana,Fenerive-Est,Fenoarivo Atsinanana,FÃ©nÃ©rive-Atsinanana,FÃ©nÃ©rive-Est,Fenoarivo Atsinanana", :latitude => "-17.36667", :longitude => "49.41667").save
City.new(:country_id => "144", :name => "Faratsiho", :aliases => ",Faratsiho", :latitude => "-19.4", :longitude => "46.95").save
City.new(:country_id => "144", :name => "Farafangana", :aliases => ",Farafangana", :latitude => "-22.81667", :longitude => "47.83333").save
City.new(:country_id => "144", :name => "Fandriana", :aliases => "Fandriana,Ifandriana,Fandriana", :latitude => "-20.23333", :longitude => "47.38333").save
City.new(:country_id => "144", :name => "Betioky", :aliases => ",Betioky", :latitude => "-23.71667", :longitude => "44.38333").save
City.new(:country_id => "144", :name => "Betafo", :aliases => ",Betafo", :latitude => "-19.83333", :longitude => "46.85").save
City.new(:country_id => "144", :name => "Beroroha", :aliases => "Beroroha,Beroroho,Beroroka,Beroroha", :latitude => "-21.66667", :longitude => "45.16667").save
City.new(:country_id => "144", :name => "Belo Tsiribihina", :aliases => "Belo,Belo Tsiribihina,Belo sur Tsiribihina,Belo Tsiribihina", :latitude => "-19.7", :longitude => "44.55").save
City.new(:country_id => "144", :name => "Beloha", :aliases => ",Beloha", :latitude => "-25.16667", :longitude => "45.05").save
City.new(:country_id => "144", :name => "Bealanana", :aliases => ",Bealanana", :latitude => "-14.55", :longitude => "48.73333").save
City.new(:country_id => "144", :name => "Arivonimamo", :aliases => "Arivonimamo,Arivonimamy,Arivonimamo", :latitude => "-19.01667", :longitude => "47.18333").save
City.new(:country_id => "144", :name => "Antsohihy", :aliases => "Antsohihi,Antsohihy,Antsohihy", :latitude => "-14.87959", :longitude => "47.98751").save
City.new(:country_id => "144", :name => "Antsiranana", :aliases => "Anceranana,Antseranana,Antsirana,Antsiranana,Antsirane,AntsiranÌana,Diego Soarez,Diego-Suarez,DiÃ©go-Suarez,ÐÐ½ÑÐµÑÐ°Ð½Ð°Ð½Ð°,AntsiranÌana", :latitude => "-12.2787", :longitude => "49.29171").save
City.new(:country_id => "144", :name => "Antanifotsy", :aliases => ",Antanifotsy", :latitude => "-19.65", :longitude => "47.31667").save
City.new(:country_id => "144", :name => "Antananarivo", :aliases => "Antananarivo,Antananarivu,Antananaryvas,Antananarywa,AntananarÃ­vÃ³,Tananaribe,Tananarive,antananalibo,antananaribo,antananaryfw,ta na na li fu,xan ta nana ri wo,Î¤Î±Î½Î±Î½Î±ÏÎ¯Î²Î·,ÐÐ½ÑÐ°Ð½Ð°Ð½Ð°ÑÐ¸Ð²Ð¾,ÐÐ½ÑÐ°Ð½Ð°Ð½Ð°ÑÐ¸Ð²Ñ,ÐÐ½ÑÐ°Ð½Ð°Ð½Ð°ÑÑÐ²Ð¾,Ô±Õ¶Õ¿Õ¡Õ¶Õ¡Õ¶Õ¡ÖÕ«Õ¾Õ¸,×× ×× × ×¨×××,Ø£ÙØªØ§ÙØ§ÙØ§Ø±ÙÙÙ,à¸­à¸±à¸à¸à¸²à¸à¸²à¸à¸²à¸£à¸´à¹à¸§,ááá¢áááááá ááá,á áá³áááªá®,ã¢ã³ã¿ãããªã,å¡é£é£å©ä½,ìíëëë¦¬ë³´,Antananarivo", :latitude => "-18.91433", :longitude => "47.53098").save
City.new(:country_id => "144", :name => "Antalaha", :aliases => "Antalaha,Antalakhi,ÐÐ½ÑÐ°Ð»Ð°ÑÐ¸,Antalaha", :latitude => "-14.90033", :longitude => "50.27876").save
City.new(:country_id => "144", :name => "Ankazobe", :aliases => ",Ankazobe", :latitude => "-18.31667", :longitude => "47.11667").save
City.new(:country_id => "144", :name => "Ankazoabo", :aliases => "Ankazoabe,Ankazoabo,Ankazoabo Sud,Ankazoabo", :latitude => "-22.28333", :longitude => "44.51667").save
City.new(:country_id => "144", :name => "Anjozorobe", :aliases => ",Anjozorobe", :latitude => "-18.4", :longitude => "47.86667").save
City.new(:country_id => "144", :name => "Andoany", :aliases => "Andoany,Hell-Ville,Helville,Andoany", :latitude => "-13.4", :longitude => "48.26667").save
City.new(:country_id => "144", :name => "Andilamena", :aliases => ",Andilamena", :latitude => "-17.01667", :longitude => "48.58333").save
City.new(:country_id => "144", :name => "Andapa", :aliases => ",Andapa", :latitude => "-14.65", :longitude => "49.65").save
City.new(:country_id => "144", :name => "Amparafaravola", :aliases => "Amparafaravola,Amparafarovola,Amparofaravola,Amparafaravola", :latitude => "-17.58333", :longitude => "48.21667").save
City.new(:country_id => "144", :name => "Ampanihy", :aliases => ",Ampanihy", :latitude => "-24.7", :longitude => "44.75").save
City.new(:country_id => "144", :name => "Ambovombe", :aliases => ",Ambovombe", :latitude => "-25.16667", :longitude => "46.08333").save
City.new(:country_id => "144", :name => "Ambositra", :aliases => "Ambositra,Ambositra", :latitude => "-20.51667", :longitude => "47.25").save
City.new(:country_id => "144", :name => "Amboasary", :aliases => "Amboasary,Amboasary Sud,Amboasary", :latitude => "-25.03333", :longitude => "46.38333").save
City.new(:country_id => "144", :name => "Ambatondrazaka", :aliases => "Ambatondrazaka,Ambatonoradrazaka,Ambatondrazaka", :latitude => "-17.83333", :longitude => "48.41667").save
City.new(:country_id => "144", :name => "Ambatolampy", :aliases => ",Ambatolampy", :latitude => "-19.38333", :longitude => "47.41667").save
City.new(:country_id => "144", :name => "Ambatofinandrahana", :aliases => "Ambatofinandrahana,Ambatofinandrahana", :latitude => "-20.55", :longitude => "46.8").save
City.new(:country_id => "144", :name => "Ambato Boeny", :aliases => "Ambato,Ambato Boeni,Ambato Boeny,Ambato Boeny", :latitude => "-16.46667", :longitude => "46.71667").save
City.new(:country_id => "144", :name => "Ambanja", :aliases => "Ambanja,Ambanja", :latitude => "-13.68333", :longitude => "48.45").save
City.new(:country_id => "144", :name => "Ambalavao", :aliases => "Ambalava,Ambalavao,Ambalavao", :latitude => "-21.83333", :longitude => "46.93333").save
