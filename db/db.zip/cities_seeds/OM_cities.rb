City.new(:country_id => "174", :name => "Sur", :aliases => "As Sur,As SÅ«r,Sur,ÅÅ«r,Ð¡ÑÑ,ÅÅ«r", :latitude => "22.56667", :longitude => "59.52889").save
City.new(:country_id => "174", :name => "Al Sohar", :aliases => "Al Sohar,As Sohar,As SohÄr,As Suhar,AÅ Åuá¸©Är,Sohar,SohÄr,Suhar,Sukhar,Åuá¸©Är,Ð¡ÑÑÐ°Ñ,Al Sohar", :latitude => "24.36889", :longitude => "56.74389").save
City.new(:country_id => "174", :name => "Sufalat Sama'il", :aliases => "Sama'il,SamÄâil,Sifalat Samail,SifÄlat SamÄil,Sufalat Sama'il,SufÄlat SamÄâil,SufÄlat SamÄâil", :latitude => "23.31667", :longitude => "58.01667").save
City.new(:country_id => "174", :name => "Shinas", :aliases => "Al Shinas,Ash Shinas,Ash ShinÄs,Shinas,ShinÄÅ,ShinÄÅ", :latitude => "24.74333", :longitude => "56.46583").save
City.new(:country_id => "174", :name => "Salalah", :aliases => "Al Kathir,As Salala,As Salalah,AÅ ÅalÄlah,Salala,Salalah,slalh,slalt,Äl KathÄ«r,ÅalÄlah,Ð¡Ð°Ð»Ð°Ð»Ð°,ØµÙØ§ÙØ©,ØµÙØ§ÙÙ,ÅalÄlah", :latitude => "17.01505", :longitude => "54.09237").save
City.new(:country_id => "174", :name => "Saham", :aliases => "As Saham,As Åaham,Saham,Saham Town,Sahm,Salam,Åaá¸©am,Åaá¸©m,Ð¡Ð°Ð»Ð°Ð¼,Åaá¸©am", :latitude => "24.17222", :longitude => "56.88861").save
City.new(:country_id => "174", :name => "Nizwa", :aliases => "Nazwah,Nizva,Nizwa,NizwÃ¡,ÐÐ¸Ð·Ð²Ð°,NizwÃ¡", :latitude => "22.93333", :longitude => "57.53333").save
City.new(:country_id => "174", :name => "Muscat", :aliases => "Maeskat,Mascat,Mascate,Maskat,Maskatas,Masqat,MasqaÅ£,Masquat,Mouskat,Muscat,Muskat,MÃ¤skat,ma si ke te,masukatto,mhafzt msqt,msqt,museukateu,mwsqt,ÎÎ¿ÏÏÎºÎ¬Ï,ÐÐ°ÑÐºÐ°Ñ,ÕÕ¡Õ½Õ¯Õ¡Õ¿,×××¡×§×,ÙØ­Ø§ÙØ¸Ø© ÙØ³ÙØ·,ÙØ³ÙØ·,ááµá¨áµ,ãã¹ã«ãã,é©¬æ¯åç¹,ë¬´ì¤ì¹´í¸,Muscat", :latitude => "23.61333", :longitude => "58.59333").save
City.new(:country_id => "174", :name => "Khasab", :aliases => "Al Khasab,Al Khasal,Al KhaÅab,Khasab,KhaÅab,KhaÅab", :latitude => "26.19167", :longitude => "56.24361").save
City.new(:country_id => "174", :name => "Izki", :aliases => "Azki,AzkÄ«,Izki,IzkÄ«,Ziki,IzkÄ«", :latitude => "22.93333", :longitude => "57.76667").save
City.new(:country_id => "174", :name => "`Ibri", :aliases => "Ibri,`Ibri,âIbrÄ«,âIbrÄ«", :latitude => "23.22573", :longitude => "56.51572").save
City.new(:country_id => "174", :name => "Ibra", :aliases => "Bira,Ibra,IbrÄ,Sufalat Ibra',SufÄlat IbrÄâ,ÐÐ±ÑÐ°,IbrÄ", :latitude => "22.69028", :longitude => "58.54694").save
City.new(:country_id => "174", :name => "Bidbid", :aliases => "Bidbid,Bidbid", :latitude => "23.40639", :longitude => "58.12639").save
City.new(:country_id => "174", :name => "Bawshar", :aliases => "Baushar,Bawshar,bwshr,Ø¨ÙØ´Ø±,Bawshar", :latitude => "23.55827", :longitude => "58.41063").save
City.new(:country_id => "174", :name => "Barka'", :aliases => "Barka',Barkah,BarkÄâ,BarkÄâ", :latitude => "23.70917", :longitude => "57.88694").save
City.new(:country_id => "174", :name => "Bahla'", :aliases => "Bahla',Bahlah,BahlÄâ,BahlÄâ", :latitude => "22.96667", :longitude => "57.3").save
City.new(:country_id => "174", :name => "Badiyah", :aliases => "Badiya,Badiyah,BadÄ«yah,BadÄ«yah", :latitude => "22.45", :longitude => "58.8").save
City.new(:country_id => "174", :name => "As Suwayq", :aliases => "As Suwaiq,As Suwayq,Suwaik,Suwayq,As Suwayq", :latitude => "23.84944", :longitude => "57.43861").save
City.new(:country_id => "174", :name => "As Sib", :aliases => "Al-Sib,Al-SÄ«b,As Sib,As SÄ«b,Sib,As SÄ«b", :latitude => "23.68028", :longitude => "58.1825").save
City.new(:country_id => "174", :name => "Rustaq", :aliases => "Ar Rustaq,Ar RustÄq,Qal`at Kasra,Qalâat KasrÃ¡,Rostak,Rustaka,Rustaq,RustÄq,Ð ÑÑÑÐ°ÐºÐ°,RustÄq", :latitude => "23.39083", :longitude => "57.42444").save
City.new(:country_id => "174", :name => "Al Liwa'", :aliases => "Al Liwa',Al LiwÄâ,Hillat al Hisn,Liwa',LiwÄâ,á¸¨illat al á¸¨isn,Al LiwÄâ", :latitude => "24.53611", :longitude => "56.56556").save
City.new(:country_id => "174", :name => "Al Khaburah", :aliases => "Al Khabura,Al Khaburah,Al KhÄbÅ«ra,Al KhÄbÅ«rah,Al-Khabourah,Khabura,Khaburah,KhÄbÅ«rah,Al KhÄbÅ«rah", :latitude => "23.98111", :longitude => "57.10444").save
City.new(:country_id => "174", :name => "Al Buraymi", :aliases => "Al Buraymi,Al BuraymÄ«,Baraimi,Bireimi,Buraimi,Burami,Al BuraymÄ«", :latitude => "24.25", :longitude => "55.75").save
City.new(:country_id => "174", :name => "Adam", :aliases => "Adam,Ädam,Ädam", :latitude => "22.38333", :longitude => "57.53333").save
City.new(:country_id => "174", :name => "Yanqul", :aliases => "Yanqul,Yanqul", :latitude => "23.58556", :longitude => "56.54083").save
