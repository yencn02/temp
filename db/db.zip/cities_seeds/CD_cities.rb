City.new(:country_id => "41", :name => "Yangambi", :aliases => ",Yangambi", :latitude => "0.81021", :longitude => "24.43359").save
City.new(:country_id => "41", :name => "Watsa", :aliases => ",Watsa", :latitude => "3.05", :longitude => "29.53333").save
City.new(:country_id => "41", :name => "Wamba", :aliases => ",Wamba", :latitude => "2.15", :longitude => "28").save
City.new(:country_id => "41", :name => "Uvira", :aliases => "Uvinza,Uvira,Ð£Ð²Ð¸ÑÐ°,Uvira", :latitude => "-3.40667", :longitude => "29.14583").save
City.new(:country_id => "41", :name => "Tshikapa", :aliases => "Chikapa,Tshikapa,Ð§Ð¸ÐºÐ°Ð¿Ð°,Tshikapa", :latitude => "-6.41667", :longitude => "20.8").save
City.new(:country_id => "41", :name => "Sake", :aliases => "Sake,Sake", :latitude => "-1.57361", :longitude => "29.045").save
City.new(:country_id => "41", :name => "Mwene-Ditu", :aliases => "Mvene-Ditu,Mwene-Ditu,ÐÐ²ÐµÐ½Ðµ-ÐÐ¸ÑÑ,Mwene-Ditu", :latitude => "-7", :longitude => "23.45").save
City.new(:country_id => "41", :name => "Mweka", :aliases => "Mueka,Mveka,Mweka,ÐÐ²ÐµÐºÐ°,Mweka", :latitude => "-4.85", :longitude => "21.56667").save
City.new(:country_id => "41", :name => "Mbuji-Mayi", :aliases => "Bakwanga,Mbuji-Mayi,Mbuy Mayi,Mbuzhi-Maji,ÐÐ±ÑÐ¶Ð¸-ÐÐ°Ð¹Ð¸,Mbuji-Mayi", :latitude => "-6.15", :longitude => "23.6").save
City.new(:country_id => "41", :name => "Lusambo", :aliases => "Lusambo,Luzambo,ÐÑÑÐ°Ð¼Ð±Ð¾,Lusambo", :latitude => "-4.96667", :longitude => "23.45").save
City.new(:country_id => "41", :name => "Luebo", :aliases => ",Luebo", :latitude => "-5.35", :longitude => "21.41667").save
City.new(:country_id => "41", :name => "Lubao", :aliases => "Lubao,Senteri,Sentiry,Lubao", :latitude => "-5.36667", :longitude => "25.75").save
City.new(:country_id => "41", :name => "Lodja", :aliases => "Lodja,Lodzh,Loja,ÐÐ¾Ð´Ð¶,Lodja", :latitude => "-3.48333", :longitude => "23.43333").save
City.new(:country_id => "41", :name => "Lisala", :aliases => "Lisala,Lisale,Lizala,ÐÐ¸ÑÐ°Ð»Ðµ,Lisala", :latitude => "2.15", :longitude => "21.51667").save
City.new(:country_id => "41", :name => "Kongolo", :aliases => "Kangolo,Kongolo,ÐÐ¾Ð½Ð³Ð¾Ð»Ð¾,Kongolo", :latitude => "-5.38333", :longitude => "27").save
City.new(:country_id => "41", :name => "Kisangani", :aliases => "Kisangani,Singitini,Stanleystad,ji sang jia ni,kisangani,ÐÐ¸ÑÐ°Ð½Ð³Ð°Ð½Ð¸,ã­ãµã³ã¬ã,åºæ¡å å°¼,Kisangani", :latitude => "0.51667", :longitude => "25.2").save
City.new(:country_id => "41", :name => "Kindu", :aliases => "Kindu,Kindu-Port-Empain,Port de Kindu,Port-Empain,ÐÐ¸Ð½Ð´Ñ,Kindu", :latitude => "-2.95", :longitude => "25.95").save
City.new(:country_id => "41", :name => "Kasongo", :aliases => "Kasongo,Kazongo,Tongoni,Tongoni Kapaya,ÐÐ°ÑÐ¾Ð½Ð³Ð¾,Kasongo", :latitude => "-4.45", :longitude => "26.66667").save
City.new(:country_id => "41", :name => "Kaniama", :aliases => ",Kaniama", :latitude => "-7.56667", :longitude => "24.18333").save
City.new(:country_id => "41", :name => "Kananga", :aliases => "Kananga,Kanange,Lulua,Luluabourg,ÐÐ°Ð½Ð°Ð½Ð³Ð°,Kananga", :latitude => "-5.89583", :longitude => "22.41778").save
City.new(:country_id => "41", :name => "Kampene", :aliases => ",Kampene", :latitude => "-3.6", :longitude => "26.66667").save
City.new(:country_id => "41", :name => "Kamina", :aliases => "Kamina,Kaminy,ÐÐ°Ð¼Ð¸Ð½Ñ,Kamina", :latitude => "-8.73861", :longitude => "24.99056").save
City.new(:country_id => "41", :name => "Kalemie", :aliases => "Albertstad,Albertville,Kalemi,Kalemie,ÐÐ°Ð»ÐµÐ¼Ð¸,Kalemie", :latitude => "-5.94749", :longitude => "29.19471").save
City.new(:country_id => "41", :name => "Kabinda", :aliases => ",Kabinda", :latitude => "-6.13333", :longitude => "24.48333").save
City.new(:country_id => "41", :name => "Kabare", :aliases => ",Kabare", :latitude => "-2.46833", :longitude => "28.82417").save
City.new(:country_id => "41", :name => "Kabalo", :aliases => ",Kabalo", :latitude => "-6.05", :longitude => "26.91667").save
City.new(:country_id => "41", :name => "Isiro", :aliases => "Isirio,Isiro,Paulis,ÐÑÐ¸ÑÐ¾,Isiro", :latitude => "2.76667", :longitude => "27.61667").save
City.new(:country_id => "41", :name => "Ilebo", :aliases => "Franqui,Ilebo,Port-Francqui,ÐÐ»ÐµÐ±Ð¾,Ilebo", :latitude => "-4.31667", :longitude => "20.58333").save
City.new(:country_id => "41", :name => "Goma", :aliases => "Goma,Ngoma,ÐÐ¾Ð¼Ð°,Goma", :latitude => "-1.67917", :longitude => "29.22278").save
City.new(:country_id => "41", :name => "Gbadolite", :aliases => "Bado,Badolite,Gbadolite,ÐÐ±Ð°Ð´Ð¾Ð»Ð¸ÑÐµ,Gbadolite", :latitude => "4.28333", :longitude => "21.01667").save
City.new(:country_id => "41", :name => "Gandajika", :aliases => ",Gandajika", :latitude => "-6.75", :longitude => "23.95").save
City.new(:country_id => "41", :name => "Demba", :aliases => ",Demba", :latitude => "-5.51", :longitude => "22.26667").save
City.new(:country_id => "41", :name => "Butembo", :aliases => "Butembo,ÐÑÑÐµÐ¼Ð±Ð¾,Butembo", :latitude => "0.15", :longitude => "29.28333").save
City.new(:country_id => "41", :name => "Buta", :aliases => "But,Buta,ÐÑÑ,Buta", :latitude => "2.8", :longitude => "24.73333").save
City.new(:country_id => "41", :name => "Businga", :aliases => ",Businga", :latitude => "3.33333", :longitude => "20.88333").save
City.new(:country_id => "41", :name => "Bunia", :aliases => "Bunia,ÐÑÐ½Ð¸Ð°,Bunia", :latitude => "1.56667", :longitude => "30.25").save
City.new(:country_id => "41", :name => "Bumba", :aliases => "Bumba,ÐÑÐ¼Ð±Ð°,Bumba", :latitude => "2.18333", :longitude => "22.46667").save
City.new(:country_id => "41", :name => "Bukavu", :aliases => "Bukavu,Costermansstad,Costermansville,ÐÑÐºÐ°Ð²Ñ,Bukavu", :latitude => "-2.50833", :longitude => "28.86083").save
City.new(:country_id => "41", :name => "Bukama", :aliases => ",Bukama", :latitude => "-9.2", :longitude => "25.85").save
City.new(:country_id => "41", :name => "Bondo", :aliases => ",Bondo", :latitude => "3.81667", :longitude => "23.66667").save
City.new(:country_id => "41", :name => "Boende", :aliases => ",Boende", :latitude => "-0.21667", :longitude => "20.86667").save
City.new(:country_id => "41", :name => "Beni", :aliases => "Beni,ÐÐµÐ½Ð¸,Beni", :latitude => "0.5", :longitude => "29.46667").save
City.new(:country_id => "41", :name => "Basoko", :aliases => ",Basoko", :latitude => "1.23333", :longitude => "23.6").save
City.new(:country_id => "41", :name => "Aketi", :aliases => "Aketi,Port Chaltin,Aketi", :latitude => "2.73333", :longitude => "23.76667").save
City.new(:country_id => "41", :name => "Lubumbashi", :aliases => "E'ville,Elisabethville,Elizabethstad,Elizabethville,Eâville,Lubumbashi,Lubumbasi,Lubumbasis,LubumbaÅ¡i,LubumbaÅ¡is,Lumumbashi,lu ben ba xi,lubumbasi,lubumbasi si,lwbwmbashy,rubunbashi,Ãlisabethville,ÐÑÐ±ÑÐ¼Ð±Ð°ÑÐ¸,ÙÙØ¨ÙÙØ¨Ø§Ø´Ù,ã«ãã³ãã·,ç§æ¬å·´å¸,ë£¨ë¶ë°ì,ë£¨ë¶ë°ì ì,Lubumbashi", :latitude => "-11.66667", :longitude => "27.46667").save
City.new(:country_id => "41", :name => "Likasi", :aliases => "Jadotsville,Jadotville,Likasi,ÐÐ¸ÐºÐ°ÑÐ¸,Likasi", :latitude => "-10.98139", :longitude => "26.73333").save
City.new(:country_id => "41", :name => "Kolwezi", :aliases => "Kolvezi,Kolwezi,ÐÐ¾Ð»Ð²ÐµÐ·Ð¸,Kolwezi", :latitude => "-10.71667", :longitude => "25.4725").save
City.new(:country_id => "41", :name => "Kipushi", :aliases => "Kipushi,ÐÐ¸Ð¿ÑÑÐ¸,Kipushi", :latitude => "-11.76667", :longitude => "27.23333").save
City.new(:country_id => "41", :name => "Kambove", :aliases => ",Kambove", :latitude => "-10.87639", :longitude => "26.59694").save
City.new(:country_id => "41", :name => "Tshela", :aliases => ",Tshela", :latitude => "-4.98333", :longitude => "12.93333").save
City.new(:country_id => "41", :name => "Nioki", :aliases => ",Nioki", :latitude => "-2.71667", :longitude => "17.68333").save
City.new(:country_id => "41", :name => "Mushie", :aliases => ",Mushie", :latitude => "-3.01667", :longitude => "16.9").save
City.new(:country_id => "41", :name => "Mbanza-Ngungu", :aliases => "Mbanza-Ngungu,Thystad,Thysville,ÐÐ±Ð°Ð½Ð·Ð°-ÐÐ³ÑÐ½Ð³Ñ,Mbanza-Ngungu", :latitude => "-5.25", :longitude => "14.86667").save
City.new(:country_id => "41", :name => "Mbandaka", :aliases => "Bandaka,Cocquilhatville,Coquilhalville,Coquilhatstad,Coquilhatville,Mbandaka,MbÃ¡ndÃ¡kÃ¡,Wangata,ÐÐ±Ð°Ð½Ð´Ð°ÐºÐ°,Mbandaka", :latitude => "0.06667", :longitude => "18.26667").save
City.new(:country_id => "41", :name => "Matadi", :aliases => "Matadi,Matidi,matadi,ÐÐ°ÑÐ°Ð´Ð¸,×××××,ãã¿ãã£,Matadi", :latitude => "-5.81667", :longitude => "13.45").save
City.new(:country_id => "41", :name => "Mangai", :aliases => ",Mangai", :latitude => "-4.05", :longitude => "19.53333").save
City.new(:country_id => "41", :name => "Libenge", :aliases => ",Libenge", :latitude => "3.65", :longitude => "18.63333").save
City.new(:country_id => "41", :name => "Kinshasa", :aliases => "Kinsasa,Kinsaso,Kinshasa,Kinshasae,Kinszasa,KinsÃ¡sÃ¡,KinÅaso,KinÅ¡asa,Leopoldstad,Leopoldville,LÃ©opoldville,jin xia sha,kinshasa,kinsyasa,kynshasa,kynshaza,ÐÐ¸Ð½ÑÐ°ÑÃ¦,ÐÐ¸Ð½ÑÐ°ÑÐ°,×§×× ×©××¡×,ÙÙÙØ´Ø§Ø³Ø§,Ú©ÛÙØ´Ø§Ø²Ø§,áªáá»á³,ã­ã³ã·ã£ãµ,éå¤æ²,í¨ì¤ì¬,Kinshasa", :latitude => "-4.32459", :longitude => "15.32146").save
City.new(:country_id => "41", :name => "Kikwit", :aliases => "Kikvite,Kikwit,Kitwit,ÐÐ¸ÐºÐ²Ð¸ÑÐµ,Kikwit", :latitude => "-5.03861", :longitude => "18.81806").save
City.new(:country_id => "41", :name => "Kasongo-Lunda", :aliases => ",Kasongo-Lunda", :latitude => "-6.46667", :longitude => "16.81667").save
City.new(:country_id => "41", :name => "Kasangulu", :aliases => ",Kasangulu", :latitude => "-4.59111", :longitude => "15.17083").save
City.new(:country_id => "41", :name => "Inongo", :aliases => ",Inongo", :latitude => "-1.95", :longitude => "18.26667").save
City.new(:country_id => "41", :name => "Gemena", :aliases => "Gemena,Gemene,ÐÐµÐ¼ÐµÐ½Ðµ,Gemena", :latitude => "3.25", :longitude => "19.76667").save
City.new(:country_id => "41", :name => "Bulungu", :aliases => ",Bulungu", :latitude => "-4.55", :longitude => "18.6").save
City.new(:country_id => "41", :name => "Bolobo", :aliases => ",Bolobo", :latitude => "-2.16667", :longitude => "16.23333").save
City.new(:country_id => "41", :name => "Bandundu", :aliases => "Bandundu,Banningville,ÐÐ°Ð½Ð´ÑÐ½Ð´Ñ,Bandundu", :latitude => "-3.31667", :longitude => "17.36667").save
City.new(:country_id => "41", :name => "Masina", :aliases => ",Masina", :latitude => "-4.38361", :longitude => "15.39139").save
