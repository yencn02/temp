City.new(:country_id => "51", :name => "Turrialba", :aliases => "Turialba,Turrial'ba,Turrialba,Ð¢ÑÑÑÐ¸Ð°Ð»ÑÐ±Ð°,Turrialba", :latitude => "9.9", :longitude => "-83.68333").save
City.new(:country_id => "51", :name => "Tejar", :aliases => ",Tejar", :latitude => "9.75", :longitude => "-84.23333").save
City.new(:country_id => "51", :name => "Siquirres", :aliases => "Siquirres,Siquirres", :latitude => "10.1", :longitude => "-83.51667").save
City.new(:country_id => "51", :name => "San Vicente", :aliases => ",San Vicente", :latitude => "9.96667", :longitude => "-84.05").save
City.new(:country_id => "51", :name => "San Rafael Arriba", :aliases => "San Rafael,San Rafael Arriba,San Rafael Arriba", :latitude => "9.88333", :longitude => "-84.08333").save
City.new(:country_id => "51", :name => "San Rafael Abajo", :aliases => ",San Rafael Abajo", :latitude => "9.83333", :longitude => "-84.28333").save
City.new(:country_id => "51", :name => "San Rafael", :aliases => ",San Rafael", :latitude => "9.96667", :longitude => "-84.21667").save
City.new(:country_id => "51", :name => "San Rafael", :aliases => ",San Rafael", :latitude => "9.93333", :longitude => "-84.13333").save
City.new(:country_id => "51", :name => "San Pedro", :aliases => "Pedro,San Pedro,San Pedro de Montes de Oca,San Pedro", :latitude => "9.93333", :longitude => "-84.05").save
City.new(:country_id => "51", :name => "San Pablo", :aliases => ",San Pablo", :latitude => "10", :longitude => "-84.08333").save
City.new(:country_id => "51", :name => "San Miguel", :aliases => ",San Miguel", :latitude => "9.88333", :longitude => "-84.06667").save
City.new(:country_id => "51", :name => "San Juan de Dios", :aliases => "Juan de Dios,San Juan de Dios,San Juan de Dios", :latitude => "9.88333", :longitude => "-84.08333").save
City.new(:country_id => "51", :name => "San Juan", :aliases => ",San Juan", :latitude => "9.96667", :longitude => "-84.08333").save
City.new(:country_id => "51", :name => "San Jose", :aliases => ",San JosÃ©", :latitude => "10.95173", :longitude => "-85.1361").save
City.new(:country_id => "51", :name => "San Jose", :aliases => "San Chose,San ChosÄ,San Jose,San JosÃ©,San-Joseo,San-Khose,sanhose,sheng he xi,sn hwsh,Î£Î±Î½ Î§Î¿ÏÎ­,Ð¡Ð°Ð½-Ð¥Ð¾ÑÐµ,×¡×× ×××¡×,×¡× ×××¡×,à¸à¸±à¸à¹à¸®à¹à¸,á³á áá,ãµã³ãã»,èè·è¥¿,ì°í¸ì¸,San JosÃ©", :latitude => "9.93333", :longitude => "-84.08333").save
City.new(:country_id => "51", :name => "San Isidro", :aliases => "Barrio Urena,Barrio UreÃ±a,San Isidro,San Isidro Urena,San Isidro de El General,San Isidro del General,Urena,UreÃ±a,San Isidro", :latitude => "9.38333", :longitude => "-83.7").save
City.new(:country_id => "51", :name => "San Francisco", :aliases => ",San Francisco", :latitude => "9.98333", :longitude => "-84.13333").save
City.new(:country_id => "51", :name => "San Felipe", :aliases => ",San Felipe", :latitude => "9.9", :longitude => "-84.1").save
City.new(:country_id => "51", :name => "San Diego", :aliases => ",San Diego", :latitude => "9.9", :longitude => "-84").save
City.new(:country_id => "51", :name => "Quesada", :aliases => "Ciudad Quesada,Kesada,Quesada,Villa Quesada,ÐÐµÑÐ°Ð´Ð°,Quesada", :latitude => "10.33333", :longitude => "-84.43333").save
City.new(:country_id => "51", :name => "Purral", :aliases => ",Purral", :latitude => "9.95", :longitude => "-84.03333").save
City.new(:country_id => "51", :name => "Puntarenas", :aliases => "Puntarenas,ÐÑÐ½ÑÐ°ÑÐµÐ½Ð°Ñ,Puntarenas", :latitude => "9.97625", :longitude => "-84.83836").save
City.new(:country_id => "51", :name => "Puerto Limon", :aliases => "Ciudad de Limon,Ciudad de LimÃ³n,Limon,LimÃ³n,Provincia de Limon,Provinsi Limon,Provinsi LimÃ³n,ProvÃ­ncia de LimÃ³n,Puehrto-Limon,Puerto Limon,Puerto LimÃ³n,ÐÑÑÑÑÐ¾-ÐÐ¸Ð¼Ð¾Ð½,Puerto LimÃ³n", :latitude => "10", :longitude => "-83.03333").save
City.new(:country_id => "51", :name => "Patarra", :aliases => ",PatarrÃ¡", :latitude => "9.88333", :longitude => "-84.03333").save
City.new(:country_id => "51", :name => "Paraiso", :aliases => ",ParaÃ­so", :latitude => "9.83333", :longitude => "-83.86667").save
City.new(:country_id => "51", :name => "Nicoya", :aliases => "Nicoya,Nicoya", :latitude => "10.15", :longitude => "-85.45").save
City.new(:country_id => "51", :name => "Mercedes", :aliases => "Mercedes,Mercedes Norte,Mercedes", :latitude => "10.01667", :longitude => "-84.13333").save
City.new(:country_id => "51", :name => "Liberia", :aliases => "Liberia,Liberija,ÐÐ¸Ð±ÐµÑÐ¸Ñ,Liberia", :latitude => "10.63504", :longitude => "-85.43772").save
City.new(:country_id => "51", :name => "Ipis", :aliases => ",IpÃ­s", :latitude => "9.96667", :longitude => "-84.01667").save
City.new(:country_id => "51", :name => "Heredia", :aliases => "Ciudad de Heredia,Ehredia,Heredia,Heridia,Ð­ÑÐµÐ´Ð¸Ð°,Heredia", :latitude => "10", :longitude => "-84.11667").save
City.new(:country_id => "51", :name => "Guapiles", :aliases => ",GuÃ¡piles", :latitude => "10.21667", :longitude => "-83.78333").save
City.new(:country_id => "51", :name => "Guadalupe", :aliases => "Guadelupe,Gvadalupe,San Francisco Guadaloupe,ÐÐ²Ð°Ð´Ð°Ð»ÑÐ¿Ðµ,Guadalupe", :latitude => "9.94611", :longitude => "-84.05279").save
City.new(:country_id => "51", :name => "Esparza", :aliases => "Esparta,Esparza,Esparza", :latitude => "9.98333", :longitude => "-84.66667").save
City.new(:country_id => "51", :name => "Curridabat", :aliases => ",Curridabat", :latitude => "9.91667", :longitude => "-84.03333").save
City.new(:country_id => "51", :name => "Colima", :aliases => "Colima,La Estacion,La EstaciÃ³n,Colima", :latitude => "9.95", :longitude => "-84.08333").save
City.new(:country_id => "51", :name => "Chacarita", :aliases => ",Chacarita", :latitude => "9.98333", :longitude => "-84.78333").save
City.new(:country_id => "51", :name => "Cartago", :aliases => "Cartago,Kartagas,Kartago,ÐÐ°ÑÑÐ°Ð³Ð¾,Cartago", :latitude => "9.86667", :longitude => "-83.91667").save
City.new(:country_id => "51", :name => "Canas", :aliases => "Canas,CaÃ±as,Ciudad Canas,Ciudad CaÃ±as,Kanash,Las Canas,Las CaÃ±as,ÐÐ°Ð½Ð°Ñ,CaÃ±as", :latitude => "10.4294", :longitude => "-85.09311").save
City.new(:country_id => "51", :name => "Calle Blancos", :aliases => "Blancos,Calle Blancos,Calle Blancos", :latitude => "9.95", :longitude => "-84.06667").save
City.new(:country_id => "51", :name => "Aserri", :aliases => "Aseri,Aserri,AserrÃ­,AserrÃ­", :latitude => "9.86667", :longitude => "-84.1").save
City.new(:country_id => "51", :name => "Alajuela", :aliases => "Alajuela,Alakhuehla,ÐÐ»Ð°ÑÑÑÐ»Ð°,Alajuela", :latitude => "10.01667", :longitude => "-84.21667").save
City.new(:country_id => "51", :name => "San Vicente de Moravia", :aliases => ",San Vicente de Moravia", :latitude => "9.96164", :longitude => "-84.0488").save
