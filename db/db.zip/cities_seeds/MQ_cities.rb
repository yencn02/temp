City.new(:country_id => "152", :name => "Saint-Joseph", :aliases => "Saint-Joseph,Saint-Joseph", :latitude => "14.66792", :longitude => "-61.04558").save
City.new(:country_id => "152", :name => "Sainte-Marie", :aliases => "Sainte-Marie,Sent-Mari,Ð¡ÐµÐ½Ñ-ÐÐ°ÑÐ¸,Sainte-Marie", :latitude => "14.78392", :longitude => "-60.99274").save
City.new(:country_id => "152", :name => "Petite Riviere Salee", :aliases => "Petite Riviere Salee,Petite RiviÃ¨re SalÃ©e,Quartier Petite Riviere Salee,Quartier Petite RiviÃ¨re SalÃ©e,Petite RiviÃ¨re SalÃ©e", :latitude => "14.75", :longitude => "-60.96667").save
City.new(:country_id => "152", :name => "Le Robert", :aliases => "Robert,Le Robert", :latitude => "14.67751", :longitude => "-60.94228").save
City.new(:country_id => "152", :name => "Le Lamentin", :aliases => "Lamentin,Le Lamentin,Le Lamentin", :latitude => "14.608", :longitude => "-61.00933").save
City.new(:country_id => "152", :name => "Le Francois", :aliases => "Francois,FranÃ§ois,Le Francois,Le FranÃ§ois,Le FranÃ§ois", :latitude => "14.61557", :longitude => "-60.90308").save
City.new(:country_id => "152", :name => "La Trinite", :aliases => "La Trinite,La TrinitÃ©,Trinite,TrinitÃ©,La TrinitÃ©", :latitude => "14.73758", :longitude => "-60.96286").save
City.new(:country_id => "152", :name => "Fort-de-France", :aliases => "For de Fransas,Fort Royal,Fort-de-France,Fort-de-Frans,FÃ´rt-de-France,Le Fort-de-France,poleudeupeulangseu,Ð¤Ð¾ÑÑ-Ð´Ðµ-Ð¤ÑÐ°Ð½Ñ,ãã©ã¼ã«ã»ãã»ãã©ã³ã¹,í¬ë¥´ëíëì¤,Fort-de-France", :latitude => "14.60892", :longitude => "-61.07334").save
City.new(:country_id => "152", :name => "Ducos", :aliases => "Ducos,Ducos", :latitude => "14.57529", :longitude => "-60.97453").save
