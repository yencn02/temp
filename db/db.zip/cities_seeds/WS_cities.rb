City.new(:country_id => "244", :name => "Apia", :aliases => "Apia,ÎAÏÎ¹Î±,ÐÐ¿Ð¸Ð°,Apia", :latitude => "-13.83333", :longitude => "-171.76666").save
