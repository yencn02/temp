City.new(:country_id => "186", :name => "Vila Franca de Xira", :aliases => "Vila Franca de Xira,Vila Franca de Xira", :latitude => "38.95525", :longitude => "-8.98966").save
City.new(:country_id => "186", :name => "Vialonga", :aliases => ",Vialonga", :latitude => "38.87094", :longitude => "-9.06823").save
City.new(:country_id => "186", :name => "Torres Vedras", :aliases => "Torres Vedras,Torresh,Ð¢Ð¾ÑÑÐµÑ,Torres Vedras", :latitude => "39.09109", :longitude => "-9.2586").save
City.new(:country_id => "186", :name => "Tomar", :aliases => "Tomar,Ð¢Ð¾Ð¼Ð°Ñ,Tomar", :latitude => "39.6", :longitude => "-8.41667").save
City.new(:country_id => "186", :name => "Sintra", :aliases => "Cintra,Sintra,shintora,Î£Î¯Î½ÏÏÎ±,Ð¡Ð¸Ð½ÑÑÐ°,ã·ã³ãã©,Sintra", :latitude => "38.80097", :longitude => "-9.37826").save
City.new(:country_id => "186", :name => "Sesimbra", :aliases => "Sesimbra,Sezimbra,Sisimbra,Ð¡ÐµÑÐ¸Ð¼Ð±ÑÐ°,Sesimbra", :latitude => "38.44451", :longitude => "-9.10149").save
City.new(:country_id => "186", :name => "Setubal", :aliases => "Setoumpal,Setubal,SetÃºbal,sai tu ba er,stwbal,Î£ÎµÏÎ¿ÏÎ¼ÏÎ±Î»,Ð¡ÐµÑÑÐ±Ð°Ð»,Ø³ØªÙØ¨Ø§Ù,å¡å¾å·´å°,SetÃºbal", :latitude => "38.5244", :longitude => "-8.8882").save
City.new(:country_id => "186", :name => "Sao Joao da Talha", :aliases => ",SÃ£o JoÃ£o da Talha", :latitude => "38.82183", :longitude => "-9.09079").save
City.new(:country_id => "186", :name => "Sao Domingos de Rana", :aliases => "Domingos De Rana,Sao Domingos,Sao Domingos de Rana,SÃ£o Domingos,SÃ£o Domingos de Rana,SÃ£o Domingos de Rana", :latitude => "38.70123", :longitude => "-9.3276").save
City.new(:country_id => "186", :name => "Santarem", :aliases => "Santarem,Santaren,SantarÃ©m,Scalabis,Î£Î±Î½ÏÎ±ÏÎ­Î¼,Ð¡Ð°Ð½ÑÐ°ÑÐµÐ½,SantarÃ©m", :latitude => "39.23333", :longitude => "-8.68333").save
City.new(:country_id => "186", :name => "Santa Iria da Azoia", :aliases => "Santa Iria,Santa Iria da Azoia,Santa Iria da AzÃ³ia,Santa Iria de Azoia,Santa Iria da AzÃ³ia", :latitude => "38.84629", :longitude => "-9.08748").save
City.new(:country_id => "186", :name => "Sacavem", :aliases => ",SacavÃ©m", :latitude => "38.79202", :longitude => "-9.10801").save
City.new(:country_id => "186", :name => "Rio de Mouro", :aliases => ",Rio de Mouro", :latitude => "38.77457", :longitude => "-9.3276").save
City.new(:country_id => "186", :name => "Ramada", :aliases => ",Ramada", :latitude => "38.80235", :longitude => "-9.19216").save
City.new(:country_id => "186", :name => "Queluz", :aliases => "Kelush,Queluz,ÐÐµÐ»ÑÑ,Queluz", :latitude => "38.75657", :longitude => "-9.25451").save
City.new(:country_id => "186", :name => "Quarteira", :aliases => "Quarteira,Quarteira", :latitude => "37.06667", :longitude => "-8.1").save
City.new(:country_id => "186", :name => "Povoa de Santa Iria", :aliases => "Povoa,Povoa Santa Iria,Povoa de Martinho,Povoa de Santa Iria,Povoa do Tojal,Povua-de-Santa-Irija,PÃ³voa,PÃ³voa Santa Iria,PÃ³voa de Santa Iria,PÃ³voa do Tojal,ÐÐ¾Ð²ÑÐ°-Ð´Ðµ-Ð¡Ð°Ð½ÑÐ°-ÐÑÐ¸Ñ,PÃ³voa de Santa Iria", :latitude => "38.86101", :longitude => "-9.06453").save
City.new(:country_id => "186", :name => "Portimao", :aliases => "Portimao,Vila Nova de Portimao,Vila Nova de PortimÃ£o,ÐÐ¾ÑÑÐ¸Ð¼Ð°Ð¾,PortimÃ£o", :latitude => "37.13856", :longitude => "-8.53775").save
City.new(:country_id => "186", :name => "Portalegre", :aliases => "Portalegre,ÐÐ¾ÑÑÐ°Ð»ÐµÐ³ÑÐµ,Portalegre", :latitude => "39.29379", :longitude => "-7.43122").save
City.new(:country_id => "186", :name => "Pontinha", :aliases => ",Pontinha", :latitude => "38.76771", :longitude => "-9.19935").save
City.new(:country_id => "186", :name => "Pombal", :aliases => "Pombal,ÐÐ¾Ð¼Ð±Ð°Ð»,Pombal", :latitude => "39.91667", :longitude => "-8.63333").save
City.new(:country_id => "186", :name => "Pinhal Novo", :aliases => "Pinhal Novo,Pinhal Novo", :latitude => "38.63106", :longitude => "-8.91376").save
City.new(:country_id => "186", :name => "Piedade", :aliases => "Cova da Piedade,Piedade,Piedade", :latitude => "38.66667", :longitude => "-9.15").save
City.new(:country_id => "186", :name => "Peniche", :aliases => "Peniche,Peniche", :latitude => "39.3558", :longitude => "-9.38112").save
City.new(:country_id => "186", :name => "Parede", :aliases => ",Parede", :latitude => "38.69282", :longitude => "-9.35412").save
City.new(:country_id => "186", :name => "Palmela", :aliases => "Palmela,Palmela", :latitude => "38.56902", :longitude => "-8.90126").save
City.new(:country_id => "186", :name => "Paco de Arcos", :aliases => "Paco d'Arcos,PaÃ§o d'Arcos,PaÃ§o de Arcos", :latitude => "38.69569", :longitude => "-9.29143").save
City.new(:country_id => "186", :name => "Olhao", :aliases => ",OlhÃ£o", :latitude => "37.03333", :longitude => "-7.83333").save
City.new(:country_id => "186", :name => "Odivelas", :aliases => "Odivelas,awdywlas,Ø§ÙØ¯ÛÙÙØ§Ø³,Odivelas", :latitude => "38.79269", :longitude => "-9.1838").save
City.new(:country_id => "186", :name => "Montijo", :aliases => "Montijo,Montikho,ÐÐ¾Ð½ÑÐ¸ÑÐ¾,Montijo", :latitude => "38.70675", :longitude => "-8.97388").save
City.new(:country_id => "186", :name => "Monte Estoril", :aliases => ",Monte Estoril", :latitude => "38.70279", :longitude => "-9.41606").save
City.new(:country_id => "186", :name => "Monsanto", :aliases => "Monsanto,ÐÐ¾Ð½ÑÐ°Ð½ÑÐ¾,Monsanto", :latitude => "39.46667", :longitude => "-8.71667").save
City.new(:country_id => "186", :name => "Moita", :aliases => ",Moita", :latitude => "38.65078", :longitude => "-8.99038").save
City.new(:country_id => "186", :name => "Marinha Grande", :aliases => "Marinha Grande,Marinha Grande", :latitude => "39.75", :longitude => "-8.93333").save
City.new(:country_id => "186", :name => "Loures", :aliases => "Loures,Loyres,ÎÏÏÏÎµÏ,Loures", :latitude => "38.83091", :longitude => "-9.16845").save
City.new(:country_id => "186", :name => "Loule", :aliases => "Lola,Loule,LoulÃ©,ÐÐ¾Ð»Ð°,LoulÃ©", :latitude => "37.13333", :longitude => "-8.03333").save
City.new(:country_id => "186", :name => "Lisbon", :aliases => "Felicitas Julia,Felicitas Julia Olissipo,Liospoin,LiospÃ³in,Lisabon,Lisabona,Lisboa,Lisbon,Lisbona,Lisbonne,Lisbono,Lisbonum,Lissabon,Lisszabon,Lizboa,Lizbon,Lizbona,Olisipo,Olissipo,li si ben,lisaboni,lisbana,lisbxn,liseubon,lshbwnt,lysabwn,lysbwn,risubon,ÎÎ¹ÏÎ±Î²ÏÎ½Î±,ÐÐ¸ÑÐ°Ð±Ð¾Ð½,ÐÐ¸ÑÑÐ°Ð±Ð¾Ð½,ÐÑÑÐ°Ð±Ð¾Ð½,Ô¼Õ«Õ½Õ¢Õ¸Õ¶Õ¡,×××¡×××,ÙØ´Ø¨ÙÙØ©,ÙÙØ³Ø§Ø¨ÙÙ,ÙÛØ³Ø¨ÙÙ,Ü Ü«ÜÜÜ¢Ü,à¤²à¤¿à¤¸à¥à¤¬à¤¨,à¸¥à¸´à¸ªà¸à¸­à¸,ááá¡ááááá,ááá¦á,ãªã¹ãã³,éæ¯æ¬,ë¦¬ì¤ë³¸,Lisbon", :latitude => "38.71667", :longitude => "-9.13333").save
City.new(:country_id => "186", :name => "Linda-a-Velha", :aliases => "Linda a Velha,Linda-a-Velha,Linda-a-Velha", :latitude => "38.71446", :longitude => "-9.2422").save
City.new(:country_id => "186", :name => "Leiria", :aliases => "Leiria,Lejrija,Vieira de Leiria,lyyryh,ÎÎµÏÏÎ¯Î±,ÐÐµÐ¹ÑÐ¸Ñ,××××¨××,Leiria", :latitude => "39.74362", :longitude => "-8.80705").save
City.new(:country_id => "186", :name => "Laranjeiro", :aliases => ",Laranjeiro", :latitude => "37.06667", :longitude => "-7.8").save
City.new(:country_id => "186", :name => "Lagos", :aliases => ",Lagos", :latitude => "37.10202", :longitude => "-8.67422").save
City.new(:country_id => "186", :name => "Funchal", :aliases => "Funchal,Funshal,Phountsal,funsharu,Î¦Î¿ÏÎ½ÏÏÎ¬Î»,Ð¤ÑÐ½ÑÐ°Ð»,ãã³ã·ã£ã«,Funchal", :latitude => "32.63333", :longitude => "-16.9").save
City.new(:country_id => "186", :name => "Faro", :aliases => "Faro,Faru,Ð¤Ð°ÑÑ,Faro", :latitude => "37.01667", :longitude => "-7.93333").save
City.new(:country_id => "186", :name => "Evora", :aliases => "Ebora,Ehvora,Evora,Ãbora,Ãvora,Ð­Ð²Ð¾ÑÐ°,Ãvora", :latitude => "38.56667", :longitude => "-7.9").save
City.new(:country_id => "186", :name => "Estoril", :aliases => "Ehshtoril,Eshhoril,Estoril,Estoris,EstorÃ­s,Estroil,esutoriru,ÎÏÏÎ¿ÏÎ¯Î»,ÐÑÐ¾ÑÐ¸Ð»,Ð­ÑÑÐ¾ÑÐ¸Ð»,ã¨ã¹ããªã«,Estoril", :latitude => "38.70571", :longitude => "-9.39773").save
City.new(:country_id => "186", :name => "Entroncamento", :aliases => "Entrocamento,Entroncamento,Entroncamento", :latitude => "39.46667", :longitude => "-8.46667").save
City.new(:country_id => "186", :name => "Corroios", :aliases => ",Corroios", :latitude => "38.64502", :longitude => "-9.14843").save
City.new(:country_id => "186", :name => "Charneca", :aliases => "Charneca,Charneca de Caparica,Sharneka,Ð¨Ð°ÑÐ½ÐµÐºÐ°,Charneca", :latitude => "38.62059", :longitude => "-9.19149").save
City.new(:country_id => "186", :name => "Castelo Branco", :aliases => "Castelo Branco,Kashtelu-Branku,ÐÐ°ÑÑÐµÐ»Ñ-ÐÑÐ°Ð½ÐºÑ,Castelo Branco", :latitude => "39.81667", :longitude => "-7.5").save
City.new(:country_id => "186", :name => "Cascais", :aliases => "Cascaes,Cascais,Kashkajsh,Kaskais,kasukaisu,ÎÎ±ÏÎºÎ¬Î¹Ï,ÐÐ°ÑÐºÐ°Ð¹Ñ,ã«ã¹ã«ã¤ã¹,Cascais", :latitude => "38.6979", :longitude => "-9.42146").save
City.new(:country_id => "186", :name => "Carnaxide", :aliases => "Carnaxide,Karnashide,ÐÐ°ÑÐ½Ð°ÑÐ¸Ð´Ðµ,Carnaxide", :latitude => "38.72706", :longitude => "-9.24671").save
City.new(:country_id => "186", :name => "Carcavelos", :aliases => ",Carcavelos", :latitude => "38.69105", :longitude => "-9.32215").save
City.new(:country_id => "186", :name => "Caparica", :aliases => ",Caparica", :latitude => "38.66667", :longitude => "-9.2").save
City.new(:country_id => "186", :name => "Camarate", :aliases => "Camarate,Camrate,Kamarate,ÐÐ°Ð¼Ð°ÑÐ°ÑÐµ,Camarate", :latitude => "38.80358", :longitude => "-9.12808").save
City.new(:country_id => "186", :name => "Camara de Lobos", :aliases => "Camara de Lobos,CÃ¢mara de Lobos,Kamara nte Lompos,Kamara-de-Lobos,ÎÎ±Î¼Î¬ÏÎ± Î½ÏÎµ ÎÏÎ¼ÏÎ¿Ï,ÐÐ°Ð¼Ð°ÑÐ°-Ð´Ðµ-ÐÐ¾Ð±Ð¾Ñ,CÃ¢mara de Lobos", :latitude => "32.63333", :longitude => "-16.96667").save
City.new(:country_id => "186", :name => "Caldas da Rainha", :aliases => "Caldad da Rainha,Caldas da Rainha,Caldas da Rainha", :latitude => "39.4", :longitude => "-9.13333").save
City.new(:country_id => "186", :name => "Cacem", :aliases => ",CacÃ©m", :latitude => "38.76698", :longitude => "-9.29793").save
City.new(:country_id => "186", :name => "Belas", :aliases => ",Belas", :latitude => "38.77721", :longitude => "-9.26078").save
City.new(:country_id => "186", :name => "Barreiro", :aliases => "Barreiro,Barrejru,ba lei lu,ÐÐ°ÑÑÐµÐ¹ÑÑ,å·´é·é²,Barreiro", :latitude => "38.66314", :longitude => "-9.0724").save
City.new(:country_id => "186", :name => "Arrentela", :aliases => "Arrentela,Arrentella,ÐÑÑÐµÐ½ÑÐµÐ»Ð°,Arrentela", :latitude => "38.61667", :longitude => "-9.1").save
City.new(:country_id => "186", :name => "Amora", :aliases => ",Amora", :latitude => "38.62961", :longitude => "-9.11557").save
City.new(:country_id => "186", :name => "Amadora", :aliases => "Amadora,ÎÎ¼Î±Î´ÏÏÎ±,ÐÐ¼Ð°Ð´Ð¾ÑÐ°,Amadora", :latitude => "38.75382", :longitude => "-9.23083").save
City.new(:country_id => "186", :name => "Almada", :aliases => "Almada,Almanta,ÎÎ»Î¼Î¬Î½ÏÎ±,ÐÐ»Ð¼Ð°Ð´Ð°,Almada", :latitude => "38.67902", :longitude => "-9.1569").save
City.new(:country_id => "186", :name => "Alges", :aliases => "Alges,AlgÃ©s,AlgÃ©s", :latitude => "38.70245", :longitude => "-9.22936").save
City.new(:country_id => "186", :name => "Alcabideche", :aliases => "Alcabideche,Alkabideshe,Aloabideche,AloabidÃ¨che,ÐÐ»ÐºÐ°Ð±Ð¸Ð´ÐµÑÐµ,Alcabideche", :latitude => "38.73366", :longitude => "-9.40928").save
City.new(:country_id => "186", :name => "Albufeira", :aliases => "Albufeira,albwfyra,Ø¢ÙØ¨ÙÙÛØ±Ø§,Albufeira", :latitude => "37.08819", :longitude => "-8.2503").save
City.new(:country_id => "186", :name => "Viseu", :aliases => "Viseu,Vizeu,Vizeu Celorico,ÐÐ¸Ð·ÐµÑ,Viseu", :latitude => "40.65", :longitude => "-7.91667").save
City.new(:country_id => "186", :name => "Vila Real", :aliases => "Bila Real,Vila Real,Vila-Real,ÎÎ¯Î»Î± Î¡ÎµÎ¬Î»,ÐÐ¸Ð»Ð°-Ð ÐµÐ°Ð»,Vila Real", :latitude => "41.3", :longitude => "-7.75").save
City.new(:country_id => "186", :name => "Vilar de Andorinho", :aliases => "Andorinho,Vilar de Andorinha,Vilar de Andorinho,Villar d'Andorinha,Villar d'Andorinho,Villar dâAndorinha,Villar dâAndorinho,Vilar de Andorinho", :latitude => "41.1", :longitude => "-8.56667").save
City.new(:country_id => "186", :name => "Vila Nova de Gaia", :aliases => "Bila Noba nte Nkaia,Gaia,Portus Cale,Vila Nova de Gaia,Vila-Nova-de-Gajja,ÎÎ¯Î»Î± ÎÏÎ²Î± Î½ÏÎµ ÎÎºÎ¬Î¹Î±,ÐÐ¸Ð»Ð°-ÐÐ¾Ð²Ð°-Ð´Ðµ-ÐÐ°Ð¹Ñ,Vila Nova de Gaia", :latitude => "41.13333", :longitude => "-8.61667").save
City.new(:country_id => "186", :name => "Vila do Conde", :aliases => "Bila nto Konte,Vila do Conde,Vila-du-Konde,ÎÎ¯Î»Î± Î½ÏÎ¿ ÎÏÎ½ÏÎµ,ÐÐ¸Ð»Ð°-Ð´Ñ-ÐÐ¾Ð½Ð´Ðµ,Vila do Conde", :latitude => "41.35", :longitude => "-8.75").save
City.new(:country_id => "186", :name => "Viana do Castelo", :aliases => "Viana do Castelo,Vianna do Castello,Viana do Castelo", :latitude => "41.7", :longitude => "-8.83333").save
City.new(:country_id => "186", :name => "Valongo", :aliases => "Valonga,Valongo,Valongu,ÐÐ°Ð»Ð¾Ð½Ð³Ñ,Valongo", :latitude => "41.18333", :longitude => "-8.5").save
City.new(:country_id => "186", :name => "Sequeira", :aliases => ",Sequeira", :latitude => "40.55", :longitude => "-7.23333").save
City.new(:country_id => "186", :name => "Senhora da Hora", :aliases => ",Senhora da Hora", :latitude => "41.18333", :longitude => "-8.65").save
City.new(:country_id => "186", :name => "Sao Pedro da Cova", :aliases => ",SÃ£o Pedro da Cova", :latitude => "41.15", :longitude => "-8.51667").save
City.new(:country_id => "186", :name => "Sao Mamede de Infesta", :aliases => "San-Mamed-de-Infeshta,Santo Mamede de Infesta,Sao Mamede,Sao Mamede da Infesta,Sao Mamede de Infesta,SÃ£o Mamede,SÃ£o Mamede da Infesta,SÃ£o Mamede de Infesta,Ð¡Ð°Ð½-ÐÐ°Ð¼ÐµÐ´-Ð´Ðµ-ÐÐ½ÑÐµÑÑÐ°,SÃ£o Mamede de Infesta", :latitude => "41.2", :longitude => "-8.6").save
City.new(:country_id => "186", :name => "Sao Joao da Madeira", :aliases => "San-Zhuan-da-Madejra,Santo Joao da Madeira,Santo JoÃ£o da Madeira,Sao Joao da Madeiro,Sao Joao de Madeira,SÃ£o JoÃ£o da Madeiro,SÃ£o JoÃ£o de Madeira,Ð¡Ð°Ð½-ÐÑÐ°Ð½-Ð´Ð°-ÐÐ°Ð´ÐµÐ¹ÑÐ°,SÃ£o JoÃ£o da Madeira", :latitude => "40.90229", :longitude => "-8.48969").save
City.new(:country_id => "186", :name => "Rio Tinto", :aliases => "Rio Tinto,Rio Tinto", :latitude => "41.18333", :longitude => "-8.56667").save
City.new(:country_id => "186", :name => "Povoa de Varzim", :aliases => "Poboa nte Barzim,Povoa de Varzim,PÃ³voa de Varzim,Villa Euracini,pwwa dwarzym,Î ÏÎ²Î¿Î± Î½ÏÎµ ÎÎ±ÏÎ¶Î¯Î¼,Ù¾ÙÙØ§ Ø¯ÙØ§Ø±Ø²ÛÙ,PÃ³voa de Varzim", :latitude => "41.38333", :longitude => "-8.76667").save
City.new(:country_id => "186", :name => "Porto", :aliases => "Oporto,Porto,Portu,Portus Cale,bo tu,bwrtw,poruto,pwrtw,Î Î¿ÏÏÎ¿,Î ÏÏÏÎ¿,ÐÐ¾ÑÑÐ¾,ÐÐ¾ÑÑÑ,×¤××¨××,Ø¨ÙØ±ØªÙ,Ù¾ÙØ±ØªÙ,ááá á¢á£,ãã«ã,æ³¢å,Porto", :latitude => "41.15", :longitude => "-8.61667").save
City.new(:country_id => "186", :name => "Ponte do Lima", :aliases => "Ponte de Lima,Ponte do Lima,ÐÐ¾Ð½ÑÐµ Ð´Ðµ ÐÐ¸Ð¼Ð°,Ponte do Lima", :latitude => "41.76667", :longitude => "-8.58333").save
City.new(:country_id => "186", :name => "Pedroso", :aliases => ",Pedroso", :latitude => "41.41667", :longitude => "-8.75").save
City.new(:country_id => "186", :name => "Ovar", :aliases => "Ovar,ÐÐ²Ð°Ñ,Ovar", :latitude => "40.85862", :longitude => "-8.62513").save
City.new(:country_id => "186", :name => "Oliveira do Douro", :aliases => ",Oliveira do Douro", :latitude => "41.11667", :longitude => "-8.58333").save
City.new(:country_id => "186", :name => "Moncao", :aliases => "Moncao,Monsao,MonsÃ£o,MonÃ§Ã£o,MonÃ§Ã£o", :latitude => "42.07892", :longitude => "-8.48076").save
City.new(:country_id => "186", :name => "Matosinhos", :aliases => "Matosinhos,Matozinhos,Matosinhos", :latitude => "41.18333", :longitude => "-8.7").save
City.new(:country_id => "186", :name => "Maia", :aliases => "Maia,Majja,ÐÐ°Ð¹Ñ,Maia", :latitude => "41.23333", :longitude => "-8.61667").save
City.new(:country_id => "186", :name => "Leca do Bailio", :aliases => "Leca do Bailio,Leca do Balio,Leca do Belio,LeÃ§a do Bailio,LeÃ§a do Balio,LeÃ§a do Bailio", :latitude => "41.2", :longitude => "-8.61667").save
City.new(:country_id => "186", :name => "Leca da Palmeira", :aliases => "Leca,Leca da Palmeira,Leca de Palmeira,LeÃ§a,LeÃ§a da Palmeira,LeÃ§a de Palmeira,LeÃ§a da Palmeira", :latitude => "41.2", :longitude => "-8.7").save
City.new(:country_id => "186", :name => "Ilhavo", :aliases => "Ilhavo,Ãlhavo,Ãlhavo", :latitude => "40.6", :longitude => "-8.66667").save
City.new(:country_id => "186", :name => "Guimaraes", :aliases => "Gimarajnsh,Guimaraes,Guimarais,GuimarÃ£es,GuimarÃ£is,Nkimaraes,ÎÎºÎ¹Î¼Î±ÏÎ¬ÎµÏ,ÐÐ¸Ð¼Ð°ÑÐ°Ð¹Ð½Ñ,GuimarÃ£es", :latitude => "41.45", :longitude => "-8.3").save
City.new(:country_id => "186", :name => "Gondomar", :aliases => "Gondomar,ÐÐ¾Ð½Ð´Ð¾Ð¼Ð°Ñ,Gondomar", :latitude => "41.15", :longitude => "-8.53333").save
City.new(:country_id => "186", :name => "Feira", :aliases => ",Feira", :latitude => "40.91667", :longitude => "-8.55").save
City.new(:country_id => "186", :name => "Fanzeres", :aliases => ",FÃ¢nzeres", :latitude => "41.16667", :longitude => "-8.53333").save
City.new(:country_id => "186", :name => "Fafe", :aliases => "Fafe,Ð¤Ð°ÑÐµ,Fafe", :latitude => "41.45", :longitude => "-8.16667").save
City.new(:country_id => "186", :name => "Esposende", :aliases => ",Esposende", :latitude => "41.53333", :longitude => "-8.8").save
City.new(:country_id => "186", :name => "Esposende", :aliases => "Ehshpozende,Esposende,Espozende,Ð­ÑÐ¿Ð¾Ð·ÐµÐ½Ð´Ðµ,Esposende", :latitude => "41.53333", :longitude => "-8.78333").save
City.new(:country_id => "186", :name => "Ermezinde", :aliases => "Ehrmezinde,Ermezinde,Ð­ÑÐ¼ÐµÐ·Ð¸Ð½Ð´Ðµ,Ermezinde", :latitude => "41.21667", :longitude => "-8.55").save
City.new(:country_id => "186", :name => "Custoias", :aliases => ",Custoias", :latitude => "41.1", :longitude => "-7.31667").save
City.new(:country_id => "186", :name => "Covilha", :aliases => "Covilha,CovilhÃ£,Kovil'jan,ÐÐ¾Ð²Ð¸Ð»ÑÑÐ½,CovilhÃ£", :latitude => "40.28333", :longitude => "-7.5").save
City.new(:country_id => "186", :name => "Coimbra", :aliases => "Coimbra,CoÃ­mbra,CoÃ¯mbra,Koimbra,Koimbro,Koimpra,KoÃ­mbra,ke ying bu la,koinbura,ÎÏÎ¹Î¼ÏÏÎ±,ÐÐ¾Ð¸Ð¼Ð±ÑÐ°,ã³ã¤ã³ãã©,ç§è±å¸æ,Coimbra", :latitude => "40.2", :longitude => "-8.41667").save
City.new(:country_id => "186", :name => "Canidelo", :aliases => "Canidello,Canidelo,Canidelo", :latitude => "41.11667", :longitude => "-8.65").save
City.new(:country_id => "186", :name => "Braganca", :aliases => "Braganca,Bragance,BraganÃ§a,ÐÑÐ°Ð³Ð°Ð½ÑÐ°,BraganÃ§a", :latitude => "41.81667", :longitude => "-6.75").save
City.new(:country_id => "186", :name => "Braga", :aliases => "Bracara Augusta,Braga,Mpranka,braga,buraga,ÎÏÏÎ¬Î³ÎºÎ±,ÐÑÐ°Ð³Ð°,Ø¨Ø±Ø§Ú¯Ø§,ãã©ã¬,Braga", :latitude => "41.55", :longitude => "-8.43333").save
City.new(:country_id => "186", :name => "Bougado", :aliases => ",Bougado", :latitude => "41.33333", :longitude => "-8.55").save
City.new(:country_id => "186", :name => "Barcelos", :aliases => "Barcelos,Barcelos", :latitude => "41.53333", :longitude => "-8.61667").save
City.new(:country_id => "186", :name => "Baguim do Monte", :aliases => "Baguim,Baguim do Monte,Baguim do Monte", :latitude => "41.18333", :longitude => "-8.53333").save
City.new(:country_id => "186", :name => "Aveiro", :aliases => "Abeiro,Aveiro,Avejru,ÎÎ²Î­Î¹ÏÎ¿,ÐÐ²ÐµÐ¹ÑÑ,Aveiro", :latitude => "40.63333", :longitude => "-8.65").save
City.new(:country_id => "186", :name => "Aguas Santas", :aliases => ",Ãguas Santas", :latitude => "41.2", :longitude => "-8.58333").save
City.new(:country_id => "186", :name => "Ponta Delgada", :aliases => ",Ponta Delgada", :latitude => "37.73333", :longitude => "-25.66667").save
