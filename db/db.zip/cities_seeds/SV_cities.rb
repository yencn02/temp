City.new(:country_id => "211", :name => "Zacatecoluca", :aliases => "Zacateccoluca,Zacatecoluca,Zacatecoluca", :latitude => "13.5", :longitude => "-88.86667").save
City.new(:country_id => "211", :name => "Usulutan", :aliases => "Usulutan,Usulutane,UsulutÃ¡n,Ð£ÑÑÐ»ÑÑÐ°Ð½Ðµ,UsulutÃ¡n", :latitude => "13.35", :longitude => "-88.45").save
City.new(:country_id => "211", :name => "Soyapango", :aliases => "Sojapango,Soyapango,Soyopango,Ð¡Ð¾ÑÐ¿Ð°Ð½Ð³Ð¾,Soyapango", :latitude => "13.73472", :longitude => "-89.15139").save
City.new(:country_id => "211", :name => "Sonzacate", :aliases => ",Sonzacate", :latitude => "13.73417", :longitude => "-89.71472").save
City.new(:country_id => "211", :name => "Sonsonate", :aliases => "Ciudad de Sonsonate,Sonsonate,Ð¡Ð¾Ð½ÑÐ¾Ð½Ð°ÑÐµ,Sonsonate", :latitude => "13.71889", :longitude => "-89.72417").save
City.new(:country_id => "211", :name => "Sensuntepeque", :aliases => "Sensuntepeque,Sensuntepque,Sensutepeke,Ð¡ÐµÐ½ÑÑÑÐµÐ¿ÐµÐºÐµ,Sensuntepeque", :latitude => "13.86667", :longitude => "-88.63333").save
City.new(:country_id => "211", :name => "San Vicente", :aliases => "San Vicente,San Vincente,San Vicente", :latitude => "13.63333", :longitude => "-88.8").save
City.new(:country_id => "211", :name => "Santiago de Maria", :aliases => "Santiago,Santiago de Maria,Santiago de MarÃ­a,Santiago de MarÃ­a", :latitude => "13.48333", :longitude => "-88.46667").save
City.new(:country_id => "211", :name => "Santa Ana", :aliases => "Santa Ana,Santa-Ana,Ð¡Ð°Ð½ÑÐ°-ÐÐ½Ð°,Santa Ana", :latitude => "13.99417", :longitude => "-89.55972").save
City.new(:country_id => "211", :name => "San Salvador", :aliases => "Salvador,San Salbador,San Salvador,San Salvadoras,San Salwador,San-Sal'vador,San-Salvadoro,san salwadwr,sansalbadoleu,sansalwadxr,sansarubadoru,sheng sa er wa duo,sn slwwdwr,Î£Î±Î½ Î£Î±Î»Î²Î±Î´ÏÏ,Ð¡Ð°Ð½-Ð¡Ð°Ð»ÑÐ²Ð°Ð´Ð¾Ñ,×¡× ×¡××××××¨,Ø³Ø§Ù Ø³Ø§ÙÙØ§Ø¯ÙØ±,à¸à¸±à¸à¸à¸±à¸¥à¸§à¸²à¸à¸­à¸£à¹,á³á á³áá«á¶á­,ãµã³ãµã«ããã«,èè©ç¾ç¦å¤,ì°ì´ë°ëë¥´,San Salvador", :latitude => "13.68935", :longitude => "-89.18718").save
City.new(:country_id => "211", :name => "San Rafael Oriente", :aliases => "San Rafael Oriente,San Rafael de Oriente,San Rafael Oriente", :latitude => "13.38333", :longitude => "-88.35").save
City.new(:country_id => "211", :name => "San Miquel", :aliases => ",San Miquel", :latitude => "13.48333", :longitude => "-88.18333").save
City.new(:country_id => "211", :name => "San Martin", :aliases => ",San MartÃ­n", :latitude => "13.78333", :longitude => "-88.91667").save
City.new(:country_id => "211", :name => "San Marcos", :aliases => ",San Marcos", :latitude => "13.65889", :longitude => "-89.18306").save
City.new(:country_id => "211", :name => "San Francisco", :aliases => "Gotera,San Francisco,San Francisco Gotera,San Francisco", :latitude => "13.7", :longitude => "-88.1").save
City.new(:country_id => "211", :name => "Quezaltepeque", :aliases => "Kesal'tepeke,Quezaltepeque,Quezaltepque,ÐÐµÑÐ°Ð»ÑÑÐµÐ¿ÐµÐºÐµ,Quezaltepeque", :latitude => "13.835", :longitude => "-89.27444").save
City.new(:country_id => "211", :name => "Puerto El Triunfo", :aliases => "Puerto Del Triunfo,Puerto El Triunfo,Puerto El Triunfo", :latitude => "13.28333", :longitude => "-88.55").save
City.new(:country_id => "211", :name => "Nueva San Salvador", :aliases => "Ciudad de Nueva San Salvador,La Ciudad de Nueva San Salvador,Nuehva-San-Sal'vador,Nueva San Salvador,Santa Tecla,ÐÑÑÐ²Ð°-Ð¡Ð°Ð½-Ð¡Ð°Ð»ÑÐ²Ð°Ð´Ð¾Ñ,Nueva San Salvador", :latitude => "13.67694", :longitude => "-89.27972").save
City.new(:country_id => "211", :name => "Metapan", :aliases => "Metapan,MetapÃ¡n,MetapÃ¡n", :latitude => "14.33333", :longitude => "-89.45").save
City.new(:country_id => "211", :name => "Mejicanos", :aliases => "Mejicanos,Mekhikanos,Mexicanos,ÐÐµÑÐ¸ÐºÐ°Ð½Ð¾Ñ,Mejicanos", :latitude => "13.74028", :longitude => "-89.21306").save
City.new(:country_id => "211", :name => "La Union", :aliases => "La Union,La UniÃ³n,San Carlos de La Union,San Carlos de La UniÃ³n,La UniÃ³n", :latitude => "13.33694", :longitude => "-87.84389").save
City.new(:country_id => "211", :name => "La Libertad", :aliases => "La Libertad,Puerto La Libertad,La Libertad", :latitude => "13.48833", :longitude => "-89.32222").save
City.new(:country_id => "211", :name => "Izalco", :aliases => "Izalco,Yzalco,Izalco", :latitude => "13.74472", :longitude => "-89.67306").save
City.new(:country_id => "211", :name => "Ilopango", :aliases => "Ilopango,Ylopango,ÐÐ»Ð¾Ð¿Ð°Ð½Ð³Ð¾,Ilopango", :latitude => "13.70167", :longitude => "-89.10944").save
City.new(:country_id => "211", :name => "Delgado", :aliases => "Del'gado,Delgado,Villa Delcado,Villa Delgado,ÐÐµÐ»ÑÐ³Ð°Ð´Ð¾,Delgado", :latitude => "13.72417", :longitude => "-89.17028").save
City.new(:country_id => "211", :name => "Cuscatancingo", :aliases => "Cuscatancingo,Cuscatancingo", :latitude => "13.73611", :longitude => "-89.18139").save
City.new(:country_id => "211", :name => "Cojutepeque", :aliases => "Cojutepeque,Cojutepeque", :latitude => "13.71667", :longitude => "-88.93333").save
City.new(:country_id => "211", :name => "Chalchuapa", :aliases => "Chalchuapa,Chalchuapa", :latitude => "13.98667", :longitude => "-89.68111").save
City.new(:country_id => "211", :name => "Chalatenango", :aliases => "Chalatenanga,Chalatenango,Ð§Ð°Ð»Ð°ÑÐµÐ½Ð°Ð½Ð³Ð¾,Chalatenango", :latitude => "14.03333", :longitude => "-88.93333").save
City.new(:country_id => "211", :name => "Ayutuxtepeque", :aliases => "Ayutuxtepegue,Ayutuxtepeque,Ayutuxtepeque", :latitude => "13.74556", :longitude => "-89.20639").save
City.new(:country_id => "211", :name => "Apopa", :aliases => "Apopa,Apopa", :latitude => "13.80722", :longitude => "-89.17917").save
City.new(:country_id => "211", :name => "Antiguo Cuscatlan", :aliases => "Antiguo Cuscatlan,Antiguo CuscatlÃ¡n,Antiguo CuscatlÃ¡n", :latitude => "13.67306", :longitude => "-89.24083").save
City.new(:country_id => "211", :name => "Ahuachapan", :aliases => "Achuachapan,Ahuachapan,AhuachapÃ¡n,ÐÑÑÐ°ÑÐ°Ð¿Ð°Ð½,AhuachapÃ¡n", :latitude => "13.92139", :longitude => "-89.845").save
City.new(:country_id => "211", :name => "Aguilares", :aliases => ",Aguilares", :latitude => "13.95722", :longitude => "-89.18972").save
City.new(:country_id => "211", :name => "Acajutla", :aliases => "Acajutla,Akakhutla,Puerto Acajutla,ÐÐºÐ°ÑÑÑÐ»Ð°,Acajutla", :latitude => "13.59278", :longitude => "-89.8275").save
