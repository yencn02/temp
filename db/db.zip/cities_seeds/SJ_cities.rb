City.new(:country_id => "203", :name => "Longyearbyen", :aliases => "Longyearbyen,rongui~erubin,ã­ã³ã°ã¤ã§ã¼ã«ãã¼ã³,Longyearbyen", :latitude => "78.2186", :longitude => "15.64007").save
