City.new(:country_id => "84", :name => "Yendi", :aliases => "Jendi,Yendi,Yendi", :latitude => "9.43333", :longitude => "-0.01667").save
City.new(:country_id => "84", :name => "Winneba", :aliases => "Simpa,Vinnebe,Winneba,Winnebah,ÐÐ¸Ð½Ð½ÐµÐ±Ðµ,Winneba", :latitude => "5.35113", :longitude => "-0.62313").save
City.new(:country_id => "84", :name => "Wenchi", :aliases => ",Wenchi", :latitude => "7.73333", :longitude => "-2.1").save
City.new(:country_id => "84", :name => "Wa", :aliases => "Va,Wa,ÐÐ°,Wa", :latitude => "10.05", :longitude => "-2.48333").save
City.new(:country_id => "84", :name => "Teshi", :aliases => "Tassi,Teshhi,Teshi,Teshie,Ð¢ÐµÑÐ¸,Teshi", :latitude => "5.58333", :longitude => "-0.1").save
City.new(:country_id => "84", :name => "Tema", :aliases => "Tema,Temma,Toma,Ð¢ÐµÐ¼Ð°,Tema", :latitude => "5.61667", :longitude => "-0.01667").save
City.new(:country_id => "84", :name => "Techiman", :aliases => "Takyiman,Techiman,Tekyiman,Tekyiman-Brong,Techiman", :latitude => "7.58333", :longitude => "-1.93333").save
City.new(:country_id => "84", :name => "Tarkwa", :aliases => "Tarkwa,Tarquah,Tarkwa", :latitude => "5.3", :longitude => "-1.98333").save
City.new(:country_id => "84", :name => "Tamale", :aliases => "Tamale,Ð¢Ð°Ð¼Ð°Ð»Ðµ,Tamale", :latitude => "9.4", :longitude => "-0.83333").save
City.new(:country_id => "84", :name => "Takoradi", :aliases => ",Takoradi", :latitude => "4.88333", :longitude => "-1.75").save
City.new(:country_id => "84", :name => "Tafo", :aliases => "Old Tafo,Tafo,Tafo", :latitude => "6.73333", :longitude => "-1.61667").save
City.new(:country_id => "84", :name => "Swedru", :aliases => "Agona,Agona Swedru,Jwewuhu,Swedru,Swedru", :latitude => "5.53333", :longitude => "-0.7").save
City.new(:country_id => "84", :name => "Sunyani", :aliases => "Sunyani,Sunyani", :latitude => "7.33333", :longitude => "-2.33333").save
City.new(:country_id => "84", :name => "Suhum", :aliases => ",Suhum", :latitude => "6.03333", :longitude => "-0.45").save
City.new(:country_id => "84", :name => "Shama Junction", :aliases => "Shama,Shama Junction,Shama Junction", :latitude => "5", :longitude => "-1.65").save
City.new(:country_id => "84", :name => "Sekondi", :aliases => "Sekondi,Sekondi-Takoradi,SÃ©kondi,Ð¡ÐµÐºÐ¾Ð½Ð´Ð¸,Sekondi", :latitude => "4.93333", :longitude => "-1.7").save
City.new(:country_id => "84", :name => "Savelugu", :aliases => "Saveluga,Savelugu,Savelugu", :latitude => "9.62472", :longitude => "-0.82778").save
City.new(:country_id => "84", :name => "Saltpond", :aliases => "Achimfu,Saltpond,Saltpond", :latitude => "5.2", :longitude => "-1.06667").save
City.new(:country_id => "84", :name => "Salaga", :aliases => "Salaga,Salaga", :latitude => "8.55", :longitude => "-0.51667").save
City.new(:country_id => "84", :name => "Prestea", :aliases => "Esamang,Prestea,Prestea", :latitude => "5.43333", :longitude => "-2.15").save
City.new(:country_id => "84", :name => "Oduponkpehe", :aliases => ",Oduponkpehe", :latitude => "5.53333", :longitude => "-0.41667").save
City.new(:country_id => "84", :name => "Oda", :aliases => "Akim Oda,Insuaim,Nsuaem,Oda,ÐÐ´Ð°,Oda", :latitude => "5.91667", :longitude => "-0.98333").save
City.new(:country_id => "84", :name => "Obuasi", :aliases => "Oboase,Obuasi,Obuassi,Obuasi", :latitude => "6.2", :longitude => "-1.66667").save
City.new(:country_id => "84", :name => "Nungua", :aliases => "Nungoa,Nungua,Nungwa,Nungua", :latitude => "5.6", :longitude => "-0.06667").save
City.new(:country_id => "84", :name => "Nsawam", :aliases => ",Nsawam", :latitude => "5.8", :longitude => "-0.35").save
City.new(:country_id => "84", :name => "Nkawkaw", :aliases => "Nkawkaw,Nkokoo,Nkawkaw", :latitude => "6.55", :longitude => "-0.76667").save
City.new(:country_id => "84", :name => "Navrongo", :aliases => "Navrongo,Navrongo", :latitude => "10.895", :longitude => "-1.09389").save
City.new(:country_id => "84", :name => "Mampong", :aliases => "Mampon,Mampon Asante,Mampong,Mampong", :latitude => "7.06667", :longitude => "-1.4").save
City.new(:country_id => "84", :name => "Madina", :aliases => ",Madina", :latitude => "5.68333", :longitude => "-0.16667").save
City.new(:country_id => "84", :name => "Kumasi", :aliases => "Coomassie,Kumase,Kumasi,Kumasis,Kumassi,ku ma xi,kumasi,ÐÑÐ¼Ð°ÑÐ¸,åºé©¬è¥¿,ì¿ ë§ì,Kumasi", :latitude => "6.68333", :longitude => "-1.61667").save
City.new(:country_id => "84", :name => "Kpandu", :aliases => "Gabi,Kpando,Kpandu,Tsakpe,Kpandu", :latitude => "7", :longitude => "0.3").save
City.new(:country_id => "84", :name => "Konongo", :aliases => ",Konongo", :latitude => "6.61667", :longitude => "-1.21667").save
City.new(:country_id => "84", :name => "Koforidua", :aliases => "Koforidua,ÐÐ¾ÑÐ¾ÑÐ¸Ð´ÑÐ°,Koforidua", :latitude => "6.08333", :longitude => "-0.25").save
City.new(:country_id => "84", :name => "Kintampo", :aliases => "Kintampo,Kintampo", :latitude => "8.05", :longitude => "-1.71667").save
City.new(:country_id => "84", :name => "Keta", :aliases => "Keta,Kitta,Kwitta,Quittah,Keta", :latitude => "5.91667", :longitude => "0.98333").save
City.new(:country_id => "84", :name => "Hohoe", :aliases => "Chochoe,Chokhoe,Hohoe,Khokhoe,Hohoe", :latitude => "7.15", :longitude => "0.46667").save
City.new(:country_id => "84", :name => "Ho", :aliases => "Ho,Hohoe,Kho,Ð¥Ð¾,Ho", :latitude => "6.6", :longitude => "0.46667").save
City.new(:country_id => "84", :name => "Gbawe", :aliases => ",Gbawe", :latitude => "5.58333", :longitude => "-0.3").save
City.new(:country_id => "84", :name => "Foso", :aliases => ",Foso", :latitude => "5.7", :longitude => "-1.28333").save
City.new(:country_id => "84", :name => "Elmina", :aliases => "Dena,Edina,Ehlmina,Elmina,Saint George Del Mina,Sao Jorge da Mina,SÃ£o Jorge da Mina,Ð­Ð»Ð¼Ð¸Ð½Ð°,Elmina", :latitude => "5.08333", :longitude => "-1.35").save
City.new(:country_id => "84", :name => "Ejura", :aliases => "Ejura,Ejura", :latitude => "7.38333", :longitude => "-1.36667").save
City.new(:country_id => "84", :name => "Dunkwa", :aliases => ",Dunkwa", :latitude => "5.96667", :longitude => "-1.78333").save
City.new(:country_id => "84", :name => "Dom", :aliases => "Dam,Dom,Dome,ÐÐ¾Ð¼,Dom", :latitude => "5.65", :longitude => "-0.23333").save
City.new(:country_id => "84", :name => "Cape Coast", :aliases => "Cabo Corso,Cape Coast,Cape Coast Castle,Igua Ogwa,Ogwa,Cape Coast", :latitude => "5.10535", :longitude => "-1.2466").save
City.new(:country_id => "84", :name => "Bolgatanga", :aliases => "Bolagatanga,Bolgatanga,Bolgatange,ÐÐ¾Ð»Ð³Ð°ÑÐ°Ð½Ð³Ðµ,Bolgatanga", :latitude => "10.78556", :longitude => "-0.85139").save
City.new(:country_id => "84", :name => "Bibiani", :aliases => "Babianeha,Bebiani,Bebianiha,Bibiani,Bibiani", :latitude => "6.46667", :longitude => "-2.33333").save
City.new(:country_id => "84", :name => "Berekum", :aliases => "Berekum,Berekum", :latitude => "7.45", :longitude => "-2.58333").save
City.new(:country_id => "84", :name => "Begoro", :aliases => ",Begoro", :latitude => "6.38333", :longitude => "-0.38333").save
City.new(:country_id => "84", :name => "Bawku", :aliases => "Bawku,Bawku", :latitude => "11.05806", :longitude => "-0.24167").save
City.new(:country_id => "84", :name => "Axim", :aliases => "Axim,Axim", :latitude => "4.86833", :longitude => "-2.24139").save
City.new(:country_id => "84", :name => "Asamankese", :aliases => ",Asamankese", :latitude => "5.86667", :longitude => "-0.66667").save
City.new(:country_id => "84", :name => "Apam", :aliases => "Apam,Appam,ÐÐ¿Ð°Ð¼,Apam", :latitude => "5.28333", :longitude => "-0.73333").save
City.new(:country_id => "84", :name => "Anloga", :aliases => "Anloga,Awunaga,Anloga", :latitude => "5.8", :longitude => "0.9").save
City.new(:country_id => "84", :name => "Akwatia", :aliases => ",Akwatia", :latitude => "6.05", :longitude => "-0.8").save
City.new(:country_id => "84", :name => "Agogo", :aliases => ",Agogo", :latitude => "6.8", :longitude => "-1.08333").save
City.new(:country_id => "84", :name => "Achiaman", :aliases => ",Achiaman", :latitude => "5.7", :longitude => "-0.33333").save
City.new(:country_id => "84", :name => "Accra", :aliases => "Accra,Acra,Akkra,Akkrae,Akra,Akrao,Nkran,a ke la,akeula,akra,akura,ÎAÎºÎºÏÎ±,ÐÐºÐºÑÃ¦,ÐÐºÐºÑÐ°,ÐÐºÑÐ°,××§×¨×,à¤à¤à¥à¤°à¤¾,á á­á«,ã¢ã¯ã©,é¿åæ,ìí¬ë¼,Accra", :latitude => "5.55602", :longitude => "-0.1969").save
City.new(:country_id => "84", :name => "Aburi", :aliases => "Aburi,Aburi", :latitude => "5.85", :longitude => "-0.18333").save
