City.new(:country_id => "201", :name => "Jamestown", :aliases => "Jamestown,Jamestown", :latitude => "-15.93872", :longitude => "-5.71675").save
