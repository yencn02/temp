City.new(:country_id => "166", :name => "Zuru", :aliases => ",Zuru", :latitude => "11.42406", :longitude => "5.22879").save
City.new(:country_id => "166", :name => "Zungeru", :aliases => "Zungeru,Zungeru", :latitude => "9.81278", :longitude => "6.15583").save
City.new(:country_id => "166", :name => "Zaria", :aliases => "Zaria,Zarja,ÐÐ°ÑÑ,Zaria", :latitude => "11.11324", :longitude => "7.72518").save
City.new(:country_id => "166", :name => "Yola", :aliases => "Jola,Yola,ÐÐ¾Ð»Ð°,Yola", :latitude => "9.2", :longitude => "12.48333").save
City.new(:country_id => "166", :name => "Yenagoa", :aliases => "Yenagoa,Yenagoa", :latitude => "4.92472", :longitude => "6.26417").save
City.new(:country_id => "166", :name => "Wukari", :aliases => "Ukari,Wukari,Wukari", :latitude => "7.85", :longitude => "9.78333").save
City.new(:country_id => "166", :name => "Wudil", :aliases => ",Wudil", :latitude => "11.81067", :longitude => "8.84505").save
City.new(:country_id => "166", :name => "Warri", :aliases => "Varri,Warri,ÐÐ°ÑÑÐ¸,Warri", :latitude => "5.51667", :longitude => "5.75").save
City.new(:country_id => "166", :name => "Wamba", :aliases => ",Wamba", :latitude => "8.93333", :longitude => "8.6").save
City.new(:country_id => "166", :name => "Uromi", :aliases => ",Uromi", :latitude => "6.7", :longitude => "6.33333").save
City.new(:country_id => "166", :name => "Umuahia", :aliases => "Umuahia,Umuahia Ibeku,Umuahia", :latitude => "5.52627", :longitude => "7.48959").save
City.new(:country_id => "166", :name => "Ughelli", :aliases => "Ughelli,Ughelli", :latitude => "5.48986", :longitude => "6.00743").save
City.new(:country_id => "166", :name => "Ugep", :aliases => "Ugep,Ugep", :latitude => "5.8086", :longitude => "8.0812").save
City.new(:country_id => "166", :name => "Uga", :aliases => ",Uga", :latitude => "5.93576", :longitude => "7.0793").save
City.new(:country_id => "166", :name => "Ubiaja", :aliases => "Ubiaja,Ubiaja", :latitude => "6.65504", :longitude => "6.38687").save
City.new(:country_id => "166", :name => "Tegina", :aliases => ",Tegina", :latitude => "10.0706", :longitude => "6.1906").save
City.new(:country_id => "166", :name => "Tambawel", :aliases => "Tambawal,Tambawel,Tambuwal,Tambawel", :latitude => "12.40386", :longitude => "4.64692").save
City.new(:country_id => "166", :name => "Talata Mafara", :aliases => ",Talata Mafara", :latitude => "12.57317", :longitude => "6.05971").save
City.new(:country_id => "166", :name => "Takum", :aliases => ",Takum", :latitude => "7.26667", :longitude => "9.98333").save
City.new(:country_id => "166", :name => "Abuja", :aliases => "Abudzha,Abuja,Sulaija,Suleija,Suleja,ÐÐ±ÑÐ´Ð¶Ð°,Abuja", :latitude => "9.17583", :longitude => "7.18083").save
City.new(:country_id => "166", :name => "Sokoto", :aliases => "Socoto,Sokoto,Ð¡Ð¾ÐºÐ¾ÑÐ¾,Sokoto", :latitude => "13.06092", :longitude => "5.23902").save
City.new(:country_id => "166", :name => "Soba", :aliases => ",Soba", :latitude => "10.98134", :longitude => "8.05749").save
City.new(:country_id => "166", :name => "Saki", :aliases => "Saki,Shaki,Ð¡Ð°ÐºÐ¸,Saki", :latitude => "8.66667", :longitude => "3.38333").save
City.new(:country_id => "166", :name => "Shagamu", :aliases => "Sagamu,Shagamu,Shagamu", :latitude => "6.84323", :longitude => "3.64776").save
City.new(:country_id => "166", :name => "Sapele", :aliases => ",Sapele", :latitude => "5.89405", :longitude => "5.67666").save
City.new(:country_id => "166", :name => "Rijau", :aliases => ",Rijau", :latitude => "11.10298", :longitude => "5.25068").save
City.new(:country_id => "166", :name => "Rano", :aliases => ",Rano", :latitude => "11.54912", :longitude => "8.57464").save
City.new(:country_id => "166", :name => "Potiskum", :aliases => "Potiskum,Putuskum,Potiskum", :latitude => "11.7091", :longitude => "11.0694").save
City.new(:country_id => "166", :name => "Port Harcourt", :aliases => "Port Harcourt,Port Harkortas,Port Kharkurt,bwrt harkwrt,potohakoto,ÐÐ¾ÑÑ Ð¥Ð°ÑÐºÑÑÑ,Ø¨ÙØ±Øª ÙØ§Ø±ÙÙØ±Øª,ãã¼ããã¼ã³ã¼ã,Port Harcourt", :latitude => "4.77742", :longitude => "7.0134").save
City.new(:country_id => "166", :name => "Pindiga", :aliases => ",Pindiga", :latitude => "9.98333", :longitude => "10.93333").save
City.new(:country_id => "166", :name => "Pategi", :aliases => "Pategi,Pategi", :latitude => "8.73333", :longitude => "5.75").save
City.new(:country_id => "166", :name => "Pankshin", :aliases => ",Pankshin", :latitude => "9.33333", :longitude => "9.45").save
City.new(:country_id => "166", :name => "Ozubulu", :aliases => ",Ozubulu", :latitude => "5.95666", :longitude => "6.84904").save
City.new(:country_id => "166", :name => "Oyo", :aliases => "Oio,OiÃ³,Ojo,Oyo,ÐÐ¹Ð¾,Oyo", :latitude => "7.85", :longitude => "3.93333").save
City.new(:country_id => "166", :name => "Oyan", :aliases => ",Oyan", :latitude => "8.05", :longitude => "4.76667").save
City.new(:country_id => "166", :name => "Owo", :aliases => "Ovo,Owo,ÐÐ²Ð¾,Owo", :latitude => "7.1962", :longitude => "5.58681").save
City.new(:country_id => "166", :name => "Owerri", :aliases => "Overri,Owerri,ÐÐ²ÐµÑÑÐ¸,Owerri", :latitude => "5.48333", :longitude => "7.03041").save
City.new(:country_id => "166", :name => "Otukpa", :aliases => ",Otukpa", :latitude => "7.08921", :longitude => "7.64989").save
City.new(:country_id => "166", :name => "Orita Eruwa", :aliases => ",Orita Eruwa", :latitude => "7.55", :longitude => "3.43333").save
City.new(:country_id => "166", :name => "Onitsha", :aliases => "Onicha,Onitsha,Onitsha", :latitude => "6.14543", :longitude => "6.78845").save
City.new(:country_id => "166", :name => "Ondo", :aliases => "Ondo,ÐÐ½Ð´Ð¾,Ondo", :latitude => "7.1", :longitude => "4.83333").save
City.new(:country_id => "166", :name => "Olupona", :aliases => "Olupona,Olupono,Olupona", :latitude => "7.6", :longitude => "4.18333").save
City.new(:country_id => "166", :name => "Okuta", :aliases => ",Okuta", :latitude => "9.21667", :longitude => "3.18333").save
City.new(:country_id => "166", :name => "Okrika", :aliases => "Okrika,Okrika", :latitude => "4.74159", :longitude => "7.08488").save
City.new(:country_id => "166", :name => "Okigwi", :aliases => ",Okigwi", :latitude => "5.83523", :longitude => "7.35989").save
City.new(:country_id => "166", :name => "Oke Mesi", :aliases => "Oke Mesi,Oke Messi,Oke Mesi", :latitude => "7.81667", :longitude => "4.91667").save
City.new(:country_id => "166", :name => "Ohafia-Ifigh", :aliases => ",Ohafia-Ifigh", :latitude => "5.61455", :longitude => "7.81191").save
City.new(:country_id => "166", :name => "Ogwashi-Uku", :aliases => "Ogwashi-Uku,Ugwashi-Uku,Ogwashi-Uku", :latitude => "6.17818", :longitude => "6.52429").save
City.new(:country_id => "166", :name => "Oguta", :aliases => "Oguta,Oguta", :latitude => "5.7089", :longitude => "6.81026").save
City.new(:country_id => "166", :name => "Ogoja", :aliases => "Ogoja,Ogoja", :latitude => "6.65471", :longitude => "8.79764").save
City.new(:country_id => "166", :name => "Ogaminan", :aliases => ",Ogaminan", :latitude => "7.59464", :longitude => "6.22476").save
City.new(:country_id => "166", :name => "Offa", :aliases => "Offa,ÐÑÑÐ°,Offa", :latitude => "8.15", :longitude => "4.71667").save
City.new(:country_id => "166", :name => "Ode", :aliases => "Awde,Oda,Ode,ÐÐ´Ð°,Ode", :latitude => "7.7899", :longitude => "5.7117").save
City.new(:country_id => "166", :name => "Obudu", :aliases => ",Obudu", :latitude => "6.66737", :longitude => "9.17157").save
City.new(:country_id => "166", :name => "Obonoma", :aliases => "Abonnema,Obonoma,Obonoma", :latitude => "4.70844", :longitude => "6.79307").save
City.new(:country_id => "166", :name => "Numan", :aliases => "Numan,Numan", :latitude => "9.46667", :longitude => "12.03333").save
City.new(:country_id => "166", :name => "Nsukka", :aliases => "Nsukka,ÐÑÑÐºÐºÐ°,Nsukka", :latitude => "6.8561", :longitude => "7.3927").save
City.new(:country_id => "166", :name => "Nnewi", :aliases => "Newi,Nnewi,Nnjuvi,ÐÐ½ÑÐ²Ð¸,Nnewi", :latitude => "6.01986", :longitude => "6.91478").save
City.new(:country_id => "166", :name => "Nkwerre", :aliases => ",Nkwerre", :latitude => "5.75555", :longitude => "7.10627").save
City.new(:country_id => "166", :name => "Nkpor", :aliases => "Mkpor,Nkpor,Nkpor", :latitude => "6.15164", :longitude => "6.84458").save
City.new(:country_id => "166", :name => "Nguru", :aliases => "N'gourou,Nguru,Nâgourou,Nguru", :latitude => "12.8791", :longitude => "10.4526").save
City.new(:country_id => "166", :name => "Nassarawa", :aliases => "Nasarawa,Nassarava,Nassarawa,ÐÐ°ÑÑÐ°ÑÐ°Ð²Ð°,Nassarawa", :latitude => "8.52944", :longitude => "7.72417").save
City.new(:country_id => "166", :name => "Nafada", :aliases => ",Nafada", :latitude => "11.0956", :longitude => "11.3327").save
City.new(:country_id => "166", :name => "Mubi", :aliases => "Mubi,ÐÑÐ±Ð¸,Mubi", :latitude => "10.26761", :longitude => "13.26436").save
City.new(:country_id => "166", :name => "Moriki", :aliases => ",Moriki", :latitude => "12.87405", :longitude => "6.48754").save
City.new(:country_id => "166", :name => "Mongonu", :aliases => "Mongono,Mongonu,Monguno,Mongonu", :latitude => "12.67863", :longitude => "13.60792").save
City.new(:country_id => "166", :name => "Mokwa", :aliases => ",Mokwa", :latitude => "9.28333", :longitude => "5.05").save
City.new(:country_id => "166", :name => "Modakeke", :aliases => ",Modakeke", :latitude => "7.38333", :longitude => "4.26667").save
City.new(:country_id => "166", :name => "Minna", :aliases => "Minna,ÐÐ¸Ð½Ð½Ð°,Minna", :latitude => "9.61389", :longitude => "6.55694").save
City.new(:country_id => "166", :name => "Marte", :aliases => "Marte,Marte-Kuna,Marte", :latitude => "12.36113", :longitude => "13.8246").save
City.new(:country_id => "166", :name => "Malumfashi", :aliases => "Malumfashi,Malumfashi", :latitude => "11.78529", :longitude => "7.62175").save
City.new(:country_id => "166", :name => "Makurdi", :aliases => "Makurdi,Makurdu,ÐÐ°ÐºÑÑÐ´Ð¸,Makurdi", :latitude => "7.7411", :longitude => "8.5121").save
City.new(:country_id => "166", :name => "Maiduguri", :aliases => "Maidiguri,Maidugari,Maiduguri,Maiduguris,maydwghwry,ÐÐ°Ð¸Ð´ÑÐ³ÑÑÐ¸,ÙØ§ÙØ¯ÙØºÙØ±Ù,Maiduguri", :latitude => "11.84644", :longitude => "13.16027").save
City.new(:country_id => "166", :name => "Magumeri", :aliases => ",Magumeri", :latitude => "12.1131", :longitude => "12.8274").save
City.new(:country_id => "166", :name => "Lokoja", :aliases => "Lairdstown,Lokoja,Zokoja,Lokoja", :latitude => "7.80236", :longitude => "6.743").save
City.new(:country_id => "166", :name => "Lere", :aliases => "Lera,Lere,Leri,ÐÐµÑÐ°,Lere", :latitude => "10.38697", :longitude => "8.57262").save
City.new(:country_id => "166", :name => "Lapai", :aliases => "Badeggi,Badeji,Lapai,Lapai", :latitude => "9.05", :longitude => "6.56667").save
City.new(:country_id => "166", :name => "Lalupon", :aliases => ",Lalupon", :latitude => "7.46667", :longitude => "4.06667").save
City.new(:country_id => "166", :name => "Lagos", :aliases => "Eko,Lacupolis,Lagos,Lagosa,Lagosas,Lagoso,Logos,la ge si,laghws,lagosa,lagoseu,lagws,lakxs,ragosu,ÐÐ°Ð³Ð¾Ñ,×××××¡,ÙØ§ØºÙØ³,ÙØ§Ú¯ÙØ³,à¤²à¤¾à¤à¥à¤¸,à¸¥à¸²à¸à¸­à¸ª,ã©ã´ã¹,æå¥æ¯,ë¼ê³ ì¤,Lagos", :latitude => "6.45306", :longitude => "3.39583").save
City.new(:country_id => "166", :name => "Lafiagi", :aliases => ",Lafiagi", :latitude => "8.86667", :longitude => "5.41667").save
City.new(:country_id => "166", :name => "Lafia", :aliases => "Lafia,Lafia Beriberi,Lafia", :latitude => "8.48333", :longitude => "8.51667").save
City.new(:country_id => "166", :name => "Kwale", :aliases => "Kwale,Kwale Station,Obetim,Kwale", :latitude => "5.70632", :longitude => "6.43741").save
City.new(:country_id => "166", :name => "Kumo", :aliases => ",Kumo", :latitude => "10.04469", :longitude => "11.21217").save
City.new(:country_id => "166", :name => "Kumagunnam", :aliases => "Kumaganum,Kumagunam,Kumagunnam,Kumagunnam", :latitude => "13.15514", :longitude => "10.63423").save
City.new(:country_id => "166", :name => "Kukawa", :aliases => "Koukaoua,Koukawa,Kukawa,Kukawa", :latitude => "12.92342", :longitude => "13.56058").save
City.new(:country_id => "166", :name => "Kontagora", :aliases => "Kontagora,Kontagora", :latitude => "10.39989", :longitude => "5.46949").save
City.new(:country_id => "166", :name => "Kishi", :aliases => ",Kishi", :latitude => "9.08333", :longitude => "3.85").save
City.new(:country_id => "166", :name => "Keffi", :aliases => ",Keffi", :latitude => "8.84861", :longitude => "7.87361").save
City.new(:country_id => "166", :name => "Kaura Namoda", :aliases => ",Kaura Namoda", :latitude => "12.58979", :longitude => "6.57791").save
City.new(:country_id => "166", :name => "Katsina Ala", :aliases => "Katsena Ala,Katsina Ala,Katsina Ala", :latitude => "7.16667", :longitude => "9.28333").save
City.new(:country_id => "166", :name => "Katsina", :aliases => "Katsina,ÐÐ°ÑÑÐ¸Ð½Ð°,Katsina", :latitude => "12.98943", :longitude => "7.60063").save
City.new(:country_id => "166", :name => "Kari", :aliases => ",Kari", :latitude => "11.2471", :longitude => "10.561").save
City.new(:country_id => "166", :name => "Kano", :aliases => "Cano,Kanas,Kano,Kanoriket,kano,kanw,ÐÐ°Ð½Ð¾,ÙØ§ÙÙ,ã«ã,Kano", :latitude => "11.99435", :longitude => "8.51381").save
City.new(:country_id => "166", :name => "Kamba", :aliases => "Kamba,Kambo,ÐÐ°Ð¼Ð±Ð°,Kamba", :latitude => "11.84864", :longitude => "3.65761").save
City.new(:country_id => "166", :name => "Kaiama", :aliases => "Kaiama,Kaima,Kaiama", :latitude => "9.6225", :longitude => "3.94806").save
City.new(:country_id => "166", :name => "Kagoro", :aliases => ",Kagoro", :latitude => "9.6", :longitude => "8.38333").save
City.new(:country_id => "166", :name => "Kafachan", :aliases => "Kafachan,Kafanchan,Kafanchan Junction,Kajanchan,Kafachan", :latitude => "9.58333", :longitude => "8.3").save
City.new(:country_id => "166", :name => "Kaduna", :aliases => "Kaduna,kadwna,ÐÐ°Ð´ÑÐ½Ð°,ÙØ§Ø¯ÙÙØ§,Kaduna", :latitude => "10.52224", :longitude => "7.43828").save
City.new(:country_id => "166", :name => "Kachia", :aliases => ",Kachia", :latitude => "9.86667", :longitude => "7.95").save
City.new(:country_id => "166", :name => "Kabba", :aliases => "Kabba,Kabba", :latitude => "7.82873", :longitude => "6.0731").save
City.new(:country_id => "166", :name => "Jos", :aliases => "Jos,ÐÐ¾Ñ,Jos", :latitude => "9.91667", :longitude => "8.9").save
City.new(:country_id => "166", :name => "Jimeta", :aliases => "Jimeta,Jimeta", :latitude => "9.28333", :longitude => "12.46667").save
City.new(:country_id => "166", :name => "Jega", :aliases => ",Jega", :latitude => "12.2175", :longitude => "4.37917").save
City.new(:country_id => "166", :name => "Jebba", :aliases => "Djebba,Jebba,Jebba", :latitude => "9.13333", :longitude => "4.83333").save
City.new(:country_id => "166", :name => "Jalingo", :aliases => "Jalingo,Jalingo", :latitude => "8.88333", :longitude => "11.36667").save
City.new(:country_id => "166", :name => "Iwo", :aliases => "Ivo,Iwo,ÐÐ²Ð¾,Iwo", :latitude => "7.63333", :longitude => "4.18333").save
City.new(:country_id => "166", :name => "Itu", :aliases => ",Itu", :latitude => "5.2004", :longitude => "7.98475").save
City.new(:country_id => "166", :name => "Isieke", :aliases => ",Isieke", :latitude => "6.37831", :longitude => "8.03524").save
City.new(:country_id => "166", :name => "Ise-Ekiti", :aliases => "Ise,Ise-Ekiti,Ise-Ekiti", :latitude => "7.4632", :longitude => "5.4281").save
City.new(:country_id => "166", :name => "Isanlu Itedoijowa", :aliases => ",Isanlu Itedoijowa", :latitude => "8.26667", :longitude => "5.83333").save
City.new(:country_id => "166", :name => "Ipoti", :aliases => ",Ipoti", :latitude => "7.87377", :longitude => "5.07692").save
City.new(:country_id => "166", :name => "Iperu", :aliases => ",Iperu", :latitude => "6.91002", :longitude => "3.66557").save
City.new(:country_id => "166", :name => "Inisa", :aliases => ",Inisa", :latitude => "7.85", :longitude => "4.33333").save
City.new(:country_id => "166", :name => "Ilorin", :aliases => "Illorin,Ilorin,Ilorin", :latitude => "8.5", :longitude => "4.55").save
City.new(:country_id => "166", :name => "Ilobu", :aliases => "Ilobu,Ilobu", :latitude => "7.83333", :longitude => "4.48333").save
City.new(:country_id => "166", :name => "Illela", :aliases => ",Illela", :latitude => "13.72918", :longitude => "5.29752").save
City.new(:country_id => "166", :name => "Ilesa", :aliases => "Ilesa,Ilesha,Ilesa", :latitude => "7.61667", :longitude => "4.73333").save
City.new(:country_id => "166", :name => "Ilaro", :aliases => "Ilaro,Ilaro", :latitude => "6.88653", :longitude => "3.0205").save
City.new(:country_id => "166", :name => "Ila Orangun", :aliases => "Ila,Ila Orangun,Ila Orangun", :latitude => "8.01667", :longitude => "4.9").save
City.new(:country_id => "166", :name => "Ikot-Ekpene", :aliases => "Ikot Expene,Ikot-Ekpene,Ikot-Ekpene", :latitude => "5.17938", :longitude => "7.71082").save
City.new(:country_id => "166", :name => "Ikom", :aliases => ",Ikom", :latitude => "5.961", :longitude => "8.7107").save
City.new(:country_id => "166", :name => "Ikirun", :aliases => "Ikirun,Ikirun", :latitude => "7.91667", :longitude => "4.66667").save
City.new(:country_id => "166", :name => "Ikire", :aliases => "Ikire,Ikire", :latitude => "7.35", :longitude => "4.18333").save
City.new(:country_id => "166", :name => "Ikerre", :aliases => "Ikare,Ikere,Ikere-Ekiti,Ikerre,Ikerre", :latitude => "7.49133", :longitude => "5.23225").save
City.new(:country_id => "166", :name => "Ijero-Ekiti", :aliases => "Ijero,Ijero-Ekiti,Ijero-Ekiti", :latitude => "7.8139", :longitude => "5.0742").save
City.new(:country_id => "166", :name => "Ijebu-Ode", :aliases => "Ijebu Ode,Ijebu-Ode,Ijebu-Ode", :latitude => "6.81609", :longitude => "3.91588").save
City.new(:country_id => "166", :name => "Ijebu Ijesha", :aliases => ",Ijebu Ijesha", :latitude => "7.68333", :longitude => "4.81667").save
City.new(:country_id => "166", :name => "Ijebu-Igbo", :aliases => "Ijebu-Igbo,Ijebu-Igbo", :latitude => "6.9798", :longitude => "4.00329").save
City.new(:country_id => "166", :name => "Ihiala", :aliases => "Ihiala,Ihiala", :latitude => "5.85377", :longitude => "6.86026").save
City.new(:country_id => "166", :name => "Igede-Ekiti", :aliases => "Igbede,Igede,Igede-Ekiti,Igede-Ekiti", :latitude => "7.66676", :longitude => "5.13205").save
City.new(:country_id => "166", :name => "Igbo-Ukwu", :aliases => "Igbo,Igbo-Ukwu,Igbo-Ukwu", :latitude => "6.01669", :longitude => "7.02654").save
City.new(:country_id => "166", :name => "Igbor", :aliases => ",Igbor", :latitude => "7.4527", :longitude => "8.6098").save
City.new(:country_id => "166", :name => "Igbo Ora", :aliases => "Igbo Ora,Igbo-Awra,Igbo Ora", :latitude => "7.43333", :longitude => "3.28333").save
City.new(:country_id => "166", :name => "Igboho", :aliases => ",Igboho", :latitude => "8.83333", :longitude => "3.75").save
City.new(:country_id => "166", :name => "Igbeti", :aliases => "Igbeti,Igbetti,Igbeti", :latitude => "8.75", :longitude => "4.13333").save
City.new(:country_id => "166", :name => "Igbara-Odo", :aliases => "Igbara-Odo,Igbarra-Odo,Igbara-Odo", :latitude => "7.50251", :longitude => "5.06258").save
City.new(:country_id => "166", :name => "Ifo", :aliases => "Ifaw,Ifo,Ifo", :latitude => "6.81437", :longitude => "3.19575").save
City.new(:country_id => "166", :name => "Idanre", :aliases => ",Idanre", :latitude => "7.1127", :longitude => "5.1159").save
City.new(:country_id => "166", :name => "Idah", :aliases => "Idah,Idah", :latitude => "7.10651", :longitude => "6.73415").save
City.new(:country_id => "166", :name => "Ibi", :aliases => ",Ibi", :latitude => "8.18333", :longitude => "9.75").save
City.new(:country_id => "166", :name => "Ibeto", :aliases => ",Ibeto", :latitude => "10.48536", :longitude => "5.14502").save
City.new(:country_id => "166", :name => "Ibadan", :aliases => "Ibadan,Ibadana,Ibadanas,aybadan,ibadan,ÐÐ±Ð°Ð´Ð°Ð½,Ø¥ÙØ¨Ø§Ø¯Ø§Ù,Ø§ÙØ¨Ø§Ø¯Ø§Ù,ã¤ããã³,Ibadan", :latitude => "7.38778", :longitude => "3.89639").save
City.new(:country_id => "166", :name => "Hadejia", :aliases => "Hadejia,Hadejia", :latitude => "12.4498", :longitude => "10.0444").save
City.new(:country_id => "166", :name => "Gwoza", :aliases => ",Gwoza", :latitude => "11.10359", :longitude => "13.71298").save
City.new(:country_id => "166", :name => "Gwarzo", :aliases => "Gwarzo,Gwarzo", :latitude => "11.91521", :longitude => "7.9346").save
City.new(:country_id => "166", :name => "Gwaram", :aliases => "Gwaram,Old Gwaram,Gwaram", :latitude => "11.27639", :longitude => "9.88583").save
City.new(:country_id => "166", :name => "Gwadabawa", :aliases => ",Gwadabawa", :latitude => "13.35612", :longitude => "5.23664").save
City.new(:country_id => "166", :name => "Gusau", :aliases => "Gusau,ÐÑÑÐ°Ñ,Gusau", :latitude => "12.16278", :longitude => "6.66135").save
City.new(:country_id => "166", :name => "Gummi", :aliases => "Gummi,Gunmi,Kunmi,ÐÑÐ½Ð¼Ð¸,Gummi", :latitude => "12.14358", :longitude => "5.10809").save
City.new(:country_id => "166", :name => "Gumel", :aliases => "Gumel,Gumel", :latitude => "12.62791", :longitude => "9.39119").save
City.new(:country_id => "166", :name => "Little Gombi", :aliases => "Gombe,Gombi,Gombi Fulani,Little Gombi,Little Gombi", :latitude => "10.16138", :longitude => "12.7399").save
City.new(:country_id => "166", :name => "Gombe", :aliases => ",Gombe", :latitude => "10.28969", :longitude => "11.16729").save
City.new(:country_id => "166", :name => "Gembu", :aliases => ",Gembu", :latitude => "6.7", :longitude => "11.26667").save
City.new(:country_id => "166", :name => "Geidam", :aliases => ",Geidam", :latitude => "12.897", :longitude => "11.9304").save
City.new(:country_id => "166", :name => "Gbongan", :aliases => ",Gbongan", :latitude => "7.46667", :longitude => "4.35").save
City.new(:country_id => "166", :name => "Gaya", :aliases => ",Gaya", :latitude => "11.86136", :longitude => "8.99714").save
City.new(:country_id => "166", :name => "Gashua", :aliases => ",Gashua", :latitude => "12.871", :longitude => "11.0482").save
City.new(:country_id => "166", :name => "Garko", :aliases => ",Garko", :latitude => "10.17506", :longitude => "11.16458").save
City.new(:country_id => "166", :name => "Ganye", :aliases => ",Ganye", :latitude => "8.43333", :longitude => "12.06667").save
City.new(:country_id => "166", :name => "Gambaru", :aliases => ",Gambaru", :latitude => "12.37066", :longitude => "14.21731").save
City.new(:country_id => "166", :name => "Funtua", :aliases => "Funtua,Puntua,Funtua", :latitude => "11.52325", :longitude => "7.30813").save
City.new(:country_id => "166", :name => "Fiditi", :aliases => ",Fiditi", :latitude => "7.71361", :longitude => "3.91722").save
City.new(:country_id => "166", :name => "Ezza Ohu", :aliases => ",Ezza Ohu", :latitude => "6.4373", :longitude => "8.0862").save
City.new(:country_id => "166", :name => "Esuk Oron", :aliases => ",Esuk Oron", :latitude => "4.80293", :longitude => "8.25341").save
City.new(:country_id => "166", :name => "Epe", :aliases => "Ehpe,Epe,Epeh,Ð­Ð¿Ðµ,Epe", :latitude => "6.58333", :longitude => "3.98333").save
City.new(:country_id => "166", :name => "Enugu-Ukwu", :aliases => "Enugu,Enugu-Ukwu,Enugwu-Ukwu,Enugu-Ukwu", :latitude => "6.17851", :longitude => "7.01156").save
City.new(:country_id => "166", :name => "Enugu-Ezike", :aliases => ",Enugu-Ezike", :latitude => "6.9825", :longitude => "7.457").save
City.new(:country_id => "166", :name => "Enugu", :aliases => "Enuga,Enugu,ÐÐ½ÑÐ³Ñ,Enugu", :latitude => "6.4402", :longitude => "7.4943").save
City.new(:country_id => "166", :name => "Emure-Ekiti", :aliases => "Emure,Emure-Ekiti,Emure-Ekiti", :latitude => "7.43614", :longitude => "5.45932").save
City.new(:country_id => "166", :name => "Elele", :aliases => ",Elele", :latitude => "5.1009", :longitude => "6.81411").save
City.new(:country_id => "166", :name => "Ekpoma", :aliases => "Ekpoma,Ekpoma", :latitude => "6.74206", :longitude => "6.139").save
City.new(:country_id => "166", :name => "Eket", :aliases => ",Eket", :latitude => "4.64122", :longitude => "7.92092").save
City.new(:country_id => "166", :name => "Ejigbo", :aliases => ",Ejigbo", :latitude => "7.9", :longitude => "4.31667").save
City.new(:country_id => "166", :name => "Eha Amufu", :aliases => ",Eha Amufu", :latitude => "6.65223", :longitude => "7.76837").save
City.new(:country_id => "166", :name => "Egbe", :aliases => ",Egbe", :latitude => "8.21667", :longitude => "5.51667").save
City.new(:country_id => "166", :name => "Effon Alaiye", :aliases => "Effon Alaiye,Efon-Alaiye,Effon Alaiye", :latitude => "7.65", :longitude => "4.91667").save
City.new(:country_id => "166", :name => "Effium", :aliases => ",Effium", :latitude => "6.62917", :longitude => "8.05925").save
City.new(:country_id => "166", :name => "Ebute Ikorodu", :aliases => "Awja-Ikoradu,Ebute Ikorodu,Ebute-Egga,Ebute Ikorodu", :latitude => "6.60086", :longitude => "3.48818").save
City.new(:country_id => "166", :name => "Dutsen Wai", :aliases => "Dutsan Wai,Dutsen Wai,Dutsen Wai", :latitude => "10.85009", :longitude => "8.199").save
City.new(:country_id => "166", :name => "Dutse", :aliases => "Dutse,Dutsi,Dutse", :latitude => "11.7594", :longitude => "9.33921").save
City.new(:country_id => "166", :name => "Dukku", :aliases => "Dukku,Duku,Dukku", :latitude => "10.82306", :longitude => "10.77167").save
City.new(:country_id => "166", :name => "Doma", :aliases => ",Doma", :latitude => "8.38333", :longitude => "8.35").save
City.new(:country_id => "166", :name => "Dikwa", :aliases => "Dikoa,Dikwa,Dikwa", :latitude => "12.02396", :longitude => "13.91646").save
City.new(:country_id => "166", :name => "Deba Habe", :aliases => "Deba,Deba Habe,Deba Habe", :latitude => "10.20864", :longitude => "11.38586").save
City.new(:country_id => "166", :name => "Daura", :aliases => "Daura,ÐÐ°ÑÑÐ°,Daura", :latitude => "13.03594", :longitude => "8.31631").save
City.new(:country_id => "166", :name => "Daura", :aliases => ",Daura", :latitude => "11.5538", :longitude => "11.4085").save
City.new(:country_id => "166", :name => "Darazo", :aliases => "Darazo,Darazo", :latitude => "10.99375", :longitude => "10.41179").save
City.new(:country_id => "166", :name => "Damboa", :aliases => "Damboa,Dumboa,Damboa", :latitude => "11.15604", :longitude => "12.75758").save
City.new(:country_id => "166", :name => "Damaturu", :aliases => "Damaturu,Damaturu", :latitude => "11.747", :longitude => "11.9608").save
City.new(:country_id => "166", :name => "Calabar", :aliases => "Calabar,Kalabar,ÐÐ°Ð»Ð°Ð±Ð°Ñ,Calabar", :latitude => "4.9517", :longitude => "8.322").save
City.new(:country_id => "166", :name => "Burutu", :aliases => ",Burutu", :latitude => "5.35091", :longitude => "5.50758").save
City.new(:country_id => "166", :name => "Bukuru", :aliases => ",Bukuru", :latitude => "9.8", :longitude => "8.86667").save
City.new(:country_id => "166", :name => "Buguma", :aliases => "Bugama,Buguma,Buguma", :latitude => "4.73407", :longitude => "6.86345").save
City.new(:country_id => "166", :name => "Bonny", :aliases => "Bonny,Bonny Town,Bonny", :latitude => "4.4522", :longitude => "7.16808").save
City.new(:country_id => "166", :name => "Bode Sadu", :aliases => ",Bode Sadu", :latitude => "8.93333", :longitude => "4.78333").save
City.new(:country_id => "166", :name => "Biu", :aliases => ",Biu", :latitude => "10.61285", :longitude => "12.19458").save
City.new(:country_id => "166", :name => "Birnin Kudu", :aliases => "Birnin Kudu,Birnin Kudu", :latitude => "11.44588", :longitude => "9.4984").save
City.new(:country_id => "166", :name => "Birnin Kebbi", :aliases => "Birnin Kebbi,Birnin Kebbi", :latitude => "12.45389", :longitude => "4.1975").save
City.new(:country_id => "166", :name => "Sofo-Birnin-Gwari", :aliases => "Birni-Gwari,Birnin-Gwari,Sofo-Birnin-Gwari,Sofo-Birnin-Gwari", :latitude => "11.01537", :longitude => "6.78036").save
City.new(:country_id => "166", :name => "Biliri", :aliases => "Biliri,Billiri,Biliri", :latitude => "9.86472", :longitude => "11.22528").save
City.new(:country_id => "166", :name => "Bida", :aliases => "Bida,ÐÐ¸Ð´Ð°,Bida", :latitude => "9.08333", :longitude => "6.01667").save
City.new(:country_id => "166", :name => "Benin City", :aliases => "Benim,Benin,Benin City,Benin-Siti,Benin-Stadt,Beninas,BÃ©nin,mdynt bnyn,ÐÐµÐ½Ð¸Ð½-Ð¡Ð¸ÑÐ¸,ÙØ¯ÙÙØ© Ø¨ÙÙÙ,Benin City", :latitude => "6.33504", :longitude => "5.62749").save
City.new(:country_id => "166", :name => "Bende", :aliases => ",Bende", :latitude => "5.55718", :longitude => "7.63676").save
City.new(:country_id => "166", :name => "Beli", :aliases => "Bali,Beli", :latitude => "7.85868", :longitude => "10.97187").save
City.new(:country_id => "166", :name => "Bauchi", :aliases => "Bauchi,Yakoba,Yakubu,ÐÐ°ÑÑÐ¸,Bauchi", :latitude => "10.31344", :longitude => "9.84327").save
City.new(:country_id => "166", :name => "Baro", :aliases => "Barbo,Baro,ÐÐ°ÑÐ¾,Baro", :latitude => "8.6", :longitude => "6.41667").save
City.new(:country_id => "166", :name => "Bama", :aliases => ",Bama", :latitude => "11.5221", :longitude => "13.68558").save
City.new(:country_id => "166", :name => "Badagry", :aliases => "Badagri,Badagry,Badagry", :latitude => "6.41667", :longitude => "2.88333").save
City.new(:country_id => "166", :name => "Babana", :aliases => ",Babana", :latitude => "10.42949", :longitude => "3.81495").save
City.new(:country_id => "166", :name => "Azare", :aliases => "Azare,Azare", :latitude => "11.6765", :longitude => "10.1948").save
City.new(:country_id => "166", :name => "Awka", :aliases => "Akwa,Awka,Awka", :latitude => "6.21009", :longitude => "7.07411").save
City.new(:country_id => "166", :name => "Awgu", :aliases => ",Awgu", :latitude => "6.0742", :longitude => "7.4786").save
City.new(:country_id => "166", :name => "Auchi", :aliases => ",Auchi", :latitude => "7.06667", :longitude => "6.26667").save
City.new(:country_id => "166", :name => "Asaba", :aliases => "Asaba,ÐÑÐ°Ð±Ð°,Asaba", :latitude => "6.20064", :longitude => "6.73384").save
City.new(:country_id => "166", :name => "Argungu", :aliases => "Argungu,Argungu", :latitude => "12.74334", :longitude => "4.52687").save
City.new(:country_id => "166", :name => "Araomoko Ekiti", :aliases => "Ara,Aramoko-Ekiti,Araomoko Ekiti,Araomoko Ekiti", :latitude => "7.70927", :longitude => "5.04474").save
City.new(:country_id => "166", :name => "Apomu", :aliases => ",Apomu", :latitude => "7.33333", :longitude => "4.18333").save
City.new(:country_id => "166", :name => "Anchau", :aliases => ",Anchau", :latitude => "10.95967", :longitude => "8.39155").save
City.new(:country_id => "166", :name => "Amaigbo", :aliases => ",Amaigbo", :latitude => "5.78917", :longitude => "7.83829").save
City.new(:country_id => "166", :name => "Akwanga", :aliases => ",Akwanga", :latitude => "8.91667", :longitude => "8.38333").save
City.new(:country_id => "166", :name => "Akure", :aliases => "Akuce,Akure,Akure", :latitude => "7.25256", :longitude => "5.19312").save
City.new(:country_id => "166", :name => "Aku", :aliases => ",Aku", :latitude => "6.7081", :longitude => "7.3167").save
City.new(:country_id => "166", :name => "Ajaokuta", :aliases => "Ajaokuta,Ajaokuta", :latitude => "7.4605", :longitude => "6.6947").save
City.new(:country_id => "166", :name => "Agulu", :aliases => ",Agulu", :latitude => "6.11", :longitude => "7.0724").save
City.new(:country_id => "166", :name => "Agbor", :aliases => "Afbor,Agbor,Agbor-BoIIboji,Agbor", :latitude => "6.25183", :longitude => "6.19337").save
City.new(:country_id => "166", :name => "Afikpo", :aliases => "Afikpo,Afikpo", :latitude => "5.89312", :longitude => "7.93735").save
City.new(:country_id => "166", :name => "Ado Odo", :aliases => "Addo,Ado,Ado Odo,Ado Odo", :latitude => "6.6", :longitude => "2.93333").save
City.new(:country_id => "166", :name => "Abuja", :aliases => "Abudza,Abudzha,AbudÅ¼a,AbudÅ¾a,Abugo,Abuja,Abuya,AbuÄo,Ampouza,a bu jia,abuja,abwja,ÎÎ¼ÏÎ¿ÏÎ¶Î±,ÐÐ±ÑÐ´Ð¶Ð°,ÐÐ±ÑÑÐ°,Ô±Õ¢Õ¸ÖÕ»Õ¡,××××'×,Ø¢Ø¨ÙØ¬Ø§,Ø£Ø¨ÙØ¬Ø§,á á¡á,ã¢ãã¸ã£,é¿å¸è´¾,ìë¶ì,Abuja", :latitude => "9.05735", :longitude => "7.48976").save
City.new(:country_id => "166", :name => "Abeokuta", :aliases => "Abeokuta,a bei ao ku ta,ÐÐ±ÐµÐ¾ÐºÑÑÐ°,é¿è´å¥¥åºå¡,Abeokuta", :latitude => "7.15", :longitude => "3.35").save
City.new(:country_id => "166", :name => "Abakaliki", :aliases => "Abakaliki,a ba ka li ji,é¿å·´å¡å©åº,Abakaliki", :latitude => "6.31625", :longitude => "8.11691").save
City.new(:country_id => "166", :name => "Aba", :aliases => "Aba,a ba,ÐÐ±Ð°,é¿å·´,Aba", :latitude => "5.10658", :longitude => "7.36667").save
City.new(:country_id => "166", :name => "Degema Hulk", :aliases => ",Degema Hulk", :latitude => "4.76254", :longitude => "6.752").save
