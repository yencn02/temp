City.new(:country_id => "194", :name => "Rwamagana", :aliases => "Rwamagana,Rwanagana,Rwamagana", :latitude => "-1.9487", :longitude => "30.4347").save
City.new(:country_id => "194", :name => "Ruhengeri", :aliases => "Ruhengeri,Ruhengeris,Rukhengeri,Ð ÑÑÐµÐ½Ð³ÐµÑÐ¸,Ruhengeri", :latitude => "-1.49984", :longitude => "29.63497").save
City.new(:country_id => "194", :name => "Nzega", :aliases => "Mont Nzega,Nseka,Nzega,Nzega", :latitude => "-2.479", :longitude => "29.5564").save
City.new(:country_id => "194", :name => "Kigali", :aliases => "Kigale,Kigali,Kigalis,Kinkali,KÃ­galÃ­,ji jia li,kigalli,kigari,ÎÎ¹Î³ÎºÎ¬Î»Î¹,ÐÐ¸Ð³Ð°Ð»Ð¸,×§×××××,áªáá,ã­ã¬ãª,åä½³å©,í¤ê°ë¦¬,Kigali", :latitude => "-1.94995", :longitude => "30.05885").save
City.new(:country_id => "194", :name => "Kibuye", :aliases => "Kibue,Kibuje,KibujÄ,Kibuye,ÐÐ¸Ð±ÑÐµ,Kibuye", :latitude => "-2.0597", :longitude => "29.3482").save
City.new(:country_id => "194", :name => "Kibungo", :aliases => "Kibungo,Kibungu,ÐÐ¸Ð±ÑÐ½Ð³Ð¾,Kibungo", :latitude => "-2.1597", :longitude => "30.5427").save
City.new(:country_id => "194", :name => "Gitarama", :aliases => "Gitarama,Gitarame,ÐÐ¸ÑÐ°ÑÐ°Ð¼Ðµ,Gitarama", :latitude => "-2.07444", :longitude => "29.75667").save
City.new(:country_id => "194", :name => "Cyangugu", :aliases => "Cyangugu,Shangugu,Siangugu,Ð¡Ð¸Ð°Ð½Ð³ÑÐ³Ñ,Cyangugu", :latitude => "-2.4846", :longitude => "28.9075").save
City.new(:country_id => "194", :name => "Gisenyi", :aliases => "Colline Gosenyi,Gisen'i,Gisenjis,Gisenyi,Gosenyi,ji sai ni,ÐÐ¸ÑÐµÐ½ÑÐ¸,åå¡å°¼,Gisenyi", :latitude => "-1.70278", :longitude => "29.25639").save
City.new(:country_id => "194", :name => "Byumba", :aliases => "Biumba,Bjumba,Byumba,ÐÐ¸ÑÐ¼Ð±Ð°,Byumba", :latitude => "-1.5763", :longitude => "30.0675").save
City.new(:country_id => "194", :name => "Butare", :aliases => "Butare,ButarÃ©,ButarÄ,ÐÑÑÐ°ÑÐµ,Butare", :latitude => "-2.59667", :longitude => "29.73944").save
