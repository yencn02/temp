City.new(:country_id => "233", :name => "Bessemer", :aliases => ",Bessemer", :latitude => "33.40178", :longitude => "-86.95444").save
City.new(:country_id => "233", :name => "Paducah", :aliases => ",Paducah", :latitude => "37.08339", :longitude => "-88.60005").save
City.new(:country_id => "233", :name => "Birmingham", :aliases => "Birmingem,Birmingham,Birmingham i Alabama,baminguhamu,baminhamu,bo ming han,ÐÐ¸ÑÐ¼Ð¸Ð½Ð³ÐµÐ¼,ÐÑÑÐ¼ÑÐ½Ð³ÐµÐ¼,ãã¼ãã³ã°ãã ,ãã¼ãã³ãã ,ä¼¯æç¿°,Birmingham", :latitude => "33.52066", :longitude => "-86.80249").save
City.new(:country_id => "233", :name => "Center Point", :aliases => ",Center Point", :latitude => "33.64566", :longitude => "-86.6836").save
City.new(:country_id => "233", :name => "Daphne", :aliases => ",Daphne", :latitude => "30.60353", :longitude => "-87.9036").save
City.new(:country_id => "233", :name => "Decatur", :aliases => "Decatur,Dekejter,decatur,ÐÐµÐºÐµÐ¹ÑÐµÑ,Decatur", :latitude => "34.60593", :longitude => "-86.98334").save
City.new(:country_id => "233", :name => "Dothan", :aliases => "Dothan,Dothan", :latitude => "31.22323", :longitude => "-85.39049").save
City.new(:country_id => "233", :name => "East Florence", :aliases => ",East Florence", :latitude => "34.80953", :longitude => "-87.64947").save
City.new(:country_id => "233", :name => "Enterprise", :aliases => ",Enterprise", :latitude => "31.31517", :longitude => "-85.85522").save
City.new(:country_id => "233", :name => "Fairhope", :aliases => ",Fairhope", :latitude => "30.52297", :longitude => "-87.90333").save
City.new(:country_id => "233", :name => "Florence", :aliases => "Florencija,Ð¤Ð»Ð¾ÑÐµÐ½ÑÐ¸Ñ,Florence", :latitude => "34.79981", :longitude => "-87.67725").save
City.new(:country_id => "233", :name => "Gadsden", :aliases => ",Gadsden", :latitude => "34.01426", :longitude => "-86.00664").save
City.new(:country_id => "233", :name => "Homewood", :aliases => ",Homewood", :latitude => "33.47177", :longitude => "-86.80082").save
City.new(:country_id => "233", :name => "Hoover", :aliases => "Guver,Hoover,ÐÑÐ²ÐµÑ,Hoover", :latitude => "33.40539", :longitude => "-86.81138").save
City.new(:country_id => "233", :name => "Hueytown", :aliases => ",Hueytown", :latitude => "33.45122", :longitude => "-86.99666").save
City.new(:country_id => "233", :name => "Huntsville", :aliases => "Gantsvill,Huntsville,Khantsvill,hantsubiru,ÐÐ°Ð½ÑÑÐ²ÑÐ»Ð»,Ð¥Ð°Ð½ÑÑÐ²Ð¸Ð»Ð»,ãã³ããã«,Huntsville", :latitude => "34.73037", :longitude => "-86.5861").save
City.new(:country_id => "233", :name => "Madison", :aliases => "Madison,ÐÐ°Ð´Ð¸ÑÐ¾Ð½,Madison", :latitude => "34.69926", :longitude => "-86.74833").save
City.new(:country_id => "233", :name => "Mobile", :aliases => "Mobil,Mobil'nye,Mobile,mobiru,ÐÐ¾Ð±Ð¸Ð»ÑÐ½ÑÐµ,ÐÐ¾Ð±ÑÐ»,ã¢ã¼ãã«,Mobile", :latitude => "30.69436", :longitude => "-88.04305").save
City.new(:country_id => "233", :name => "Montgomery", :aliases => "Montgomeri,Montgomery,mantgmry,meng ge ma li,mongomeri,mwntgwmry,ÐÐ¾Ð½ÑÐ³Ð¾Ð¼ÐµÑÐ¸,ÐÐ¾Ð½ÑÐ³Ð¾Ð¼ÐµÑÑ,××× ×××××¨×,ÙØ§ÙØªÚ¯ÙØ±Û,ã¢ã³ã´ã¡ãªã¼,èå¥é©¬å©,Montgomery", :latitude => "32.36681", :longitude => "-86.29997").save
City.new(:country_id => "233", :name => "Mountain Brook", :aliases => ",Mountain Brook", :latitude => "33.50094", :longitude => "-86.75221").save
City.new(:country_id => "233", :name => "Northport", :aliases => ",Northport", :latitude => "33.22901", :longitude => "-87.57723").save
City.new(:country_id => "233", :name => "Opelika", :aliases => ",Opelika", :latitude => "32.64541", :longitude => "-85.37828").save
City.new(:country_id => "233", :name => "Oxford", :aliases => "Oksford,ÐÐºÑÑÐ¾ÑÐ´,Oxford", :latitude => "33.61427", :longitude => "-85.83496").save
City.new(:country_id => "233", :name => "Pelham", :aliases => ",Pelham", :latitude => "33.28567", :longitude => "-86.80999").save
City.new(:country_id => "233", :name => "Phenix City", :aliases => ",Phenix City", :latitude => "32.47098", :longitude => "-85.00077").save
City.new(:country_id => "233", :name => "Prattville", :aliases => ",Prattville", :latitude => "32.46402", :longitude => "-86.4597").save
City.new(:country_id => "233", :name => "Prichard", :aliases => "Prichard,ÐÑÐ¸ÑÐ°ÑÐ´,Prichard", :latitude => "30.7388", :longitude => "-88.07889").save
City.new(:country_id => "233", :name => "Selma", :aliases => "Sel'ma,Selma,Ð¡ÐµÐ»ÑÐ¼Ð°,Selma", :latitude => "32.40736", :longitude => "-87.0211").save
City.new(:country_id => "233", :name => "Smiths Station", :aliases => ",Smiths Station", :latitude => "32.54014", :longitude => "-85.09855").save
City.new(:country_id => "233", :name => "Talladega", :aliases => ",Talladega", :latitude => "33.43594", :longitude => "-86.1058").save
City.new(:country_id => "233", :name => "Trussville", :aliases => ",Trussville", :latitude => "33.61983", :longitude => "-86.60888").save
City.new(:country_id => "233", :name => "Tuscaloosa", :aliases => "Tuscaloosa,Tuskalusa,tasukarusa,Ð¢ÑÑÐºÐ°Ð»ÑÑÐ°,ã¿ã¹ã«ã«ã¼ãµ,Tuscaloosa", :latitude => "33.20984", :longitude => "-87.56917").save
City.new(:country_id => "233", :name => "Vestavia Hills", :aliases => ",Vestavia Hills", :latitude => "33.44872", :longitude => "-86.78777").save
City.new(:country_id => "233", :name => "Bella Vista", :aliases => ",Bella Vista", :latitude => "36.42952", :longitude => "-94.2316").save
City.new(:country_id => "233", :name => "Bella Vista", :aliases => ",Bella Vista", :latitude => "36.48146", :longitude => "-94.27326").save
City.new(:country_id => "233", :name => "Benton", :aliases => "Benton,ÐÐµÐ½ÑÐ¾Ð½,Benton", :latitude => "34.56454", :longitude => "-92.58683").save
City.new(:country_id => "233", :name => "Bentonville", :aliases => "Bentonville,ben dun wei,ÐÐµÐ½ÑÐ¾Ð½Ð²Ð¸Ð»Ð»Ðµ,æ¬é ç¶­,Bentonville", :latitude => "36.37285", :longitude => "-94.20882").save
City.new(:country_id => "233", :name => "Blytheville", :aliases => ",Blytheville", :latitude => "35.9273", :longitude => "-89.91898").save
City.new(:country_id => "233", :name => "Bryant", :aliases => ",Bryant", :latitude => "34.59593", :longitude => "-92.48905").save
City.new(:country_id => "233", :name => "Cabot", :aliases => "Kabot,ÐÐ°Ð±Ð¾Ñ,Cabot", :latitude => "34.97453", :longitude => "-92.01653").save
City.new(:country_id => "233", :name => "Conway", :aliases => "Konvej,ÐÐ¾Ð½Ð²ÐµÐ¹,Conway", :latitude => "35.0887", :longitude => "-92.4421").save
City.new(:country_id => "233", :name => "El Dorado", :aliases => ",El Dorado", :latitude => "33.20763", :longitude => "-92.66627").save
City.new(:country_id => "233", :name => "Fayetteville", :aliases => "Fayetteville,Fayetteville", :latitude => "36.06258", :longitude => "-94.15743").save
City.new(:country_id => "233", :name => "Fort Smith", :aliases => "Fort Smith,fotosumisu,ãã©ã¼ãã¹ãã¹,Fort Smith", :latitude => "35.38592", :longitude => "-94.39855").save
City.new(:country_id => "233", :name => "Hot Springs", :aliases => "Khot-Springs,Ð¥Ð¾Ñ-Ð¡Ð¿ÑÐ¸Ð½Ð³Ñ,Hot Springs", :latitude => "34.5037", :longitude => "-93.05518").save
City.new(:country_id => "233", :name => "Jacksonville", :aliases => "Dzheksonvill,ÐÐ¶ÐµÐºÑÐ¾Ð½Ð²Ð¸Ð»Ð»,Jacksonville", :latitude => "34.8662", :longitude => "-92.11015").save
City.new(:country_id => "233", :name => "Jonesboro", :aliases => "Dzhonsboro,ÐÐ¶Ð¾Ð½ÑÐ±Ð¾ÑÐ¾,Jonesboro", :latitude => "35.8423", :longitude => "-90.70428").save
City.new(:country_id => "233", :name => "Little Rock", :aliases => "Litl-Rok,Little Rock,ritorurokku,xiao yan cheng,ÐÐ¸ÑÐ»-Ð Ð¾Ðº,ÙÙ¹Ù Ø±Ø§Ú©Ø Ø¢Ø±Ú©ÙØ³Ø§Ø³,ãªãã«ã­ãã¯,å°å²©å,Little Rock", :latitude => "34.74648", :longitude => "-92.28959").save
City.new(:country_id => "233", :name => "North Little Rock", :aliases => ",North Little Rock", :latitude => "34.76954", :longitude => "-92.26709").save
City.new(:country_id => "233", :name => "Paragould", :aliases => ",Paragould", :latitude => "36.0584", :longitude => "-90.49733").save
City.new(:country_id => "233", :name => "Pine Bluff", :aliases => ",Pine Bluff", :latitude => "34.22843", :longitude => "-92.0032").save
City.new(:country_id => "233", :name => "Rogers", :aliases => "Rodzhers,Ð Ð¾Ð´Ð¶ÐµÑÑ,Rogers", :latitude => "36.33202", :longitude => "-94.11854").save
City.new(:country_id => "233", :name => "Russellville", :aliases => ",Russellville", :latitude => "35.27842", :longitude => "-93.13379").save
City.new(:country_id => "233", :name => "Searcy", :aliases => ",Searcy", :latitude => "35.25064", :longitude => "-91.73625").save
City.new(:country_id => "233", :name => "Springdale", :aliases => ",Springdale", :latitude => "36.18674", :longitude => "-94.12881").save
City.new(:country_id => "233", :name => "Texarkana", :aliases => ",Texarkana", :latitude => "33.44179", :longitude => "-94.03769").save
City.new(:country_id => "233", :name => "Van Buren", :aliases => ",Van Buren", :latitude => "35.43676", :longitude => "-94.34827").save
City.new(:country_id => "233", :name => "West Memphis", :aliases => ",West Memphis", :latitude => "35.14648", :longitude => "-90.18454").save
City.new(:country_id => "233", :name => "Washington, D. C.", :aliases => "Ouasinkton,Vashington,Vasingtonia,WAS,Washington,Washington D.C.,Washington DC,Waszyngton,ÎÏÎ¬ÏÎ¹Î³ÎºÏÎ¿Î½,ÐÐ°ÑÐ¸Ð½Ð³ÑÐ¾Ð½,Washington, D. C.", :latitude => "38.89511", :longitude => "-77.03637").save
City.new(:country_id => "233", :name => "Bear", :aliases => ",Bear", :latitude => "39.62928", :longitude => "-75.65826").save
City.new(:country_id => "233", :name => "Dover", :aliases => "Dover,doba,duo fu,dwbr,ÐÐ¾Ð²ÐµÑ,××××¨,ãã¼ãã¼,å¤ä½,Dover", :latitude => "39.15817", :longitude => "-75.52437").save
City.new(:country_id => "233", :name => "Newark", :aliases => "N'juark,ÐÑÑÐ°ÑÐº,Newark", :latitude => "39.68372", :longitude => "-75.74966").save
City.new(:country_id => "233", :name => "Pike Creek", :aliases => ",Pike Creek", :latitude => "39.73095", :longitude => "-75.7041").save
City.new(:country_id => "233", :name => "Wilmington", :aliases => "Uilmington,Wilmington,u~iruminton,wilmingteon,Ð£Ð¸Ð»Ð¼Ð¸Ð½Ð³ÑÐ¾Ð½,ã¦ã£ã«ãã³ãã³,ìë°í´,Wilmington", :latitude => "39.74595", :longitude => "-75.54659").save
City.new(:country_id => "233", :name => "Altamonte Springs", :aliases => ",Altamonte Springs", :latitude => "28.66111", :longitude => "-81.36562").save
City.new(:country_id => "233", :name => "Apopka", :aliases => ",Apopka", :latitude => "28.68055", :longitude => "-81.50952").save
City.new(:country_id => "233", :name => "Aventura", :aliases => ",Aventura", :latitude => "25.95648", :longitude => "-80.13921").save
City.new(:country_id => "233", :name => "Bartow", :aliases => ",Bartow", :latitude => "27.89641", :longitude => "-81.84314").save
City.new(:country_id => "233", :name => "Bayonet Point", :aliases => ",Bayonet Point", :latitude => "28.32667", :longitude => "-82.68343").save
City.new(:country_id => "233", :name => "Bayshore Gardens", :aliases => ",Bayshore Gardens", :latitude => "27.42532", :longitude => "-82.59038").save
City.new(:country_id => "233", :name => "Belle Glade", :aliases => ",Belle Glade", :latitude => "26.68451", :longitude => "-80.66756").save
City.new(:country_id => "233", :name => "Bellview", :aliases => ",Bellview", :latitude => "30.46159", :longitude => "-87.31497").save
City.new(:country_id => "233", :name => "Bloomingdale", :aliases => ",Bloomingdale", :latitude => "27.89364", :longitude => "-82.24037").save
City.new(:country_id => "233", :name => "Boca Del Mar", :aliases => ",Boca Del Mar", :latitude => "26.34508", :longitude => "-80.14671").save
City.new(:country_id => "233", :name => "Boca Raton", :aliases => "Boca Raton,Boca de Ratones,Boca Raton", :latitude => "26.35869", :longitude => "-80.0831").save
City.new(:country_id => "233", :name => "Bonita Springs", :aliases => ",Bonita Springs", :latitude => "26.33981", :longitude => "-81.7787").save
City.new(:country_id => "233", :name => "Boynton Beach", :aliases => "Boynton Beach,Boynton Beach", :latitude => "26.52535", :longitude => "-80.06643").save
City.new(:country_id => "233", :name => "Bradenton", :aliases => ",Bradenton", :latitude => "27.49893", :longitude => "-82.57482").save
City.new(:country_id => "233", :name => "Brandon", :aliases => "Brandon,Brehndon,ÐÑÑÐ½Ð´Ð¾Ð½,Brandon", :latitude => "27.9378", :longitude => "-82.28592").save
City.new(:country_id => "233", :name => "Brent", :aliases => ",Brent", :latitude => "30.46881", :longitude => "-87.23608").save
City.new(:country_id => "233", :name => "Cape Coral", :aliases => "Cabo Coral,Cape Coral,Cape Coral", :latitude => "26.56285", :longitude => "-81.94953").save
City.new(:country_id => "233", :name => "Carol City", :aliases => "Carol City,Carol City", :latitude => "25.94065", :longitude => "-80.2456").save
City.new(:country_id => "233", :name => "Carrollwood Village", :aliases => ",Carrollwood Village", :latitude => "28.06752", :longitude => "-82.52093").save
City.new(:country_id => "233", :name => "Casselberry", :aliases => ",Casselberry", :latitude => "28.67778", :longitude => "-81.32785").save
City.new(:country_id => "233", :name => "Citrus Park", :aliases => ",Citrus Park", :latitude => "28.07835", :longitude => "-82.56982").save
City.new(:country_id => "233", :name => "Clearwater", :aliases => "Clearwater,kuriau~ota,ã¯ãªã¢ã¦ã©ã¼ã¿ã¼,Clearwater", :latitude => "27.96585", :longitude => "-82.8001").save
City.new(:country_id => "233", :name => "Cocoa", :aliases => ",Cocoa", :latitude => "28.38612", :longitude => "-80.742").save
City.new(:country_id => "233", :name => "Coconut Creek", :aliases => ",Coconut Creek", :latitude => "26.25175", :longitude => "-80.17894").save
City.new(:country_id => "233", :name => "Conway", :aliases => "Konvej,ÐÐ¾Ð½Ð²ÐµÐ¹,Conway", :latitude => "28.50278", :longitude => "-81.33062").save
City.new(:country_id => "233", :name => "Cooper City", :aliases => ",Cooper City", :latitude => "26.05731", :longitude => "-80.27172").save
City.new(:country_id => "233", :name => "Coral Gables", :aliases => ",Coral Gables", :latitude => "25.72149", :longitude => "-80.26838").save
City.new(:country_id => "233", :name => "Coral Springs", :aliases => "Coral Springs,Koral-Springs,ÐÐ¾ÑÐ°Ð»-Ð¡Ð¿ÑÐ¸Ð½Ð³Ñ,Coral Springs", :latitude => "26.27119", :longitude => "-80.2706").save
City.new(:country_id => "233", :name => "Coral Terrace", :aliases => ",Coral Terrace", :latitude => "25.74593", :longitude => "-80.3045").save
City.new(:country_id => "233", :name => "Country Club", :aliases => ",Country Club", :latitude => "25.94815", :longitude => "-80.317").save
City.new(:country_id => "233", :name => "Crestview", :aliases => ",Crestview", :latitude => "30.76213", :longitude => "-86.57051").save
City.new(:country_id => "233", :name => "Cutler", :aliases => ",Cutler", :latitude => "25.6151", :longitude => "-80.31061").save
City.new(:country_id => "233", :name => "Cutler Ridge", :aliases => ",Cutler Ridge", :latitude => "25.58066", :longitude => "-80.34672").save
City.new(:country_id => "233", :name => "Dania Beach", :aliases => ",Dania Beach", :latitude => "26.05231", :longitude => "-80.14393").save
City.new(:country_id => "233", :name => "Davie", :aliases => "Davie,Dehvi,ÐÑÐ²Ð¸,Davie", :latitude => "26.06287", :longitude => "-80.2331").save
City.new(:country_id => "233", :name => "Daytona Beach", :aliases => "Daytona Beach,Dejtona-Bich,deitonabichi,ÐÐµÐ¹ÑÐ¾Ð½Ð°-ÐÐ¸Ñ,ãã¤ãããã¼ã,Daytona Beach", :latitude => "29.21081", :longitude => "-81.02283").save
City.new(:country_id => "233", :name => "DeLand", :aliases => ",DeLand", :latitude => "29.02832", :longitude => "-81.30312").save
City.new(:country_id => "233", :name => "DeBary", :aliases => ",DeBary", :latitude => "28.88305", :longitude => "-81.30868").save
City.new(:country_id => "233", :name => "Deerfield Beach", :aliases => "Deerfield Beach,Deerfield Beach", :latitude => "26.31841", :longitude => "-80.09977").save
City.new(:country_id => "233", :name => "Delray Beach", :aliases => "Delray Beach,dlryy byz',×××¨×× ×××¥',Delray Beach", :latitude => "26.46146", :longitude => "-80.07282").save
City.new(:country_id => "233", :name => "Deltona", :aliases => "Deltona,Deltona", :latitude => "28.90054", :longitude => "-81.26367").save
City.new(:country_id => "233", :name => "Doral", :aliases => ",Doral", :latitude => "25.81954", :longitude => "-80.35533").save
City.new(:country_id => "233", :name => "Dunedin", :aliases => "Danedin,ÐÐ°Ð½ÐµÐ´Ð¸Ð½,Dunedin", :latitude => "28.01974", :longitude => "-82.77177").save
City.new(:country_id => "233", :name => "East Lake", :aliases => ",East Lake", :latitude => "28.11085", :longitude => "-82.69482").save
City.new(:country_id => "233", :name => "East Pensacola Heights", :aliases => ",East Pensacola Heights", :latitude => "30.42881", :longitude => "-87.17997").save
City.new(:country_id => "233", :name => "Edgewater", :aliases => ",Edgewater", :latitude => "28.98888", :longitude => "-80.90228").save
City.new(:country_id => "233", :name => "Egypt Lake-Leto", :aliases => ",Egypt Lake-Leto", :latitude => "28.01769", :longitude => "-82.50619").save
City.new(:country_id => "233", :name => "Englewood", :aliases => ",Englewood", :latitude => "26.96201", :longitude => "-82.3526").save
City.new(:country_id => "233", :name => "Ensley", :aliases => ",Ensley", :latitude => "30.51881", :longitude => "-87.27275").save
City.new(:country_id => "233", :name => "Eustis", :aliases => ",Eustis", :latitude => "28.85277", :longitude => "-81.68535").save
City.new(:country_id => "233", :name => "Ferry Pass", :aliases => ",Ferry Pass", :latitude => "30.5102", :longitude => "-87.21247").save
City.new(:country_id => "233", :name => "Florida Ridge", :aliases => ",Florida Ridge", :latitude => "27.58031", :longitude => "-80.38672").save
City.new(:country_id => "233", :name => "Fort Lauderdale", :aliases => "Fort Lauderdale,Ft. Lauderdale,fotorodaderu,lao de dai er bao,ãã©ã¼ãã­ã¼ãã¼ãã¼ã«,å³å¾·ä»£å°å ¡,Fort Lauderdale", :latitude => "26.12231", :longitude => "-80.14338").save
City.new(:country_id => "233", :name => "Fort Myers", :aliases => ",Fort Myers", :latitude => "26.62168", :longitude => "-81.84059").save
City.new(:country_id => "233", :name => "Fort Pierce", :aliases => ",Fort Pierce", :latitude => "27.44671", :longitude => "-80.32561").save
City.new(:country_id => "233", :name => "Fort Walton Beach", :aliases => ",Fort Walton Beach", :latitude => "30.40576", :longitude => "-86.61884").save
City.new(:country_id => "233", :name => "Fountainebleau", :aliases => "Fountainbleau,Fountainebleau", :latitude => "25.77288", :longitude => "-80.34783").save
City.new(:country_id => "233", :name => "Fruit Cove", :aliases => ",Fruit Cove", :latitude => "30.11107", :longitude => "-81.64176").save
City.new(:country_id => "233", :name => "Gainesville", :aliases => "Gainesopolis,Gainesville,Gainesville", :latitude => "29.65163", :longitude => "-82.32483").save
City.new(:country_id => "233", :name => "Glenvar Heights", :aliases => ",Glenvar Heights", :latitude => "25.7076", :longitude => "-80.32561").save
City.new(:country_id => "233", :name => "Golden Gate", :aliases => ",Golden Gate", :latitude => "26.18787", :longitude => "-81.69509").save
City.new(:country_id => "233", :name => "Golden Glades", :aliases => ",Golden Glades", :latitude => "25.91176", :longitude => "-80.20033").save
City.new(:country_id => "233", :name => "Greater Sun Center", :aliases => ",Greater Sun Center", :latitude => "27.71809", :longitude => "-82.35176").save
City.new(:country_id => "233", :name => "Greenacres City", :aliases => ",Greenacres City", :latitude => "26.62368", :longitude => "-80.12532").save
City.new(:country_id => "233", :name => "Hallandale Beach", :aliases => "Hallandale,Hallandale Beach", :latitude => "25.9812", :longitude => "-80.14838").save
City.new(:country_id => "233", :name => "Hialeah", :aliases => "Hialeah,haiaria,ãã¤ã¢ãªã¢,Hialeah", :latitude => "25.8576", :longitude => "-80.27811").save
City.new(:country_id => "233", :name => "Hialeah Gardens", :aliases => ",Hialeah Gardens", :latitude => "25.8651", :longitude => "-80.3245").save
City.new(:country_id => "233", :name => "Holiday", :aliases => ",Holiday", :latitude => "28.18779", :longitude => "-82.73955").save
City.new(:country_id => "233", :name => "Hollywood", :aliases => "Gollivud,Hollywood,hariuddo,hwlywwd,ÐÐ¾Ð»Ð»Ð¸Ð²ÑÐ´,×××××××,ããªã¦ãã,Hollywood", :latitude => "26.0112", :longitude => "-80.14949").save
City.new(:country_id => "233", :name => "Homestead", :aliases => ",Homestead", :latitude => "25.46872", :longitude => "-80.47756").save
City.new(:country_id => "233", :name => "Homosassa Springs", :aliases => ",Homosassa Springs", :latitude => "28.80359", :longitude => "-82.57593").save
City.new(:country_id => "233", :name => "Hudson", :aliases => "Gudzon,ÐÑÐ´Ð·Ð¾Ð½,Hudson", :latitude => "28.36445", :longitude => "-82.69343").save
City.new(:country_id => "233", :name => "Immokalee", :aliases => ",Immokalee", :latitude => "26.41869", :longitude => "-81.4173").save
City.new(:country_id => "233", :name => "Ives Estates", :aliases => ",Ives Estates", :latitude => "25.96231", :longitude => "-80.17671").save
City.new(:country_id => "233", :name => "Jacksonville", :aliases => "Dzhaks'nvil,Dzheksonvil',Iacsoniapolis,Iacsonvilla,Jacksonville,g'qswnwwyl,jaegseunbil,jakusonbiru,jie ke xun wei er,ÐÐ¶Ð°ÐºÑÑÐ½Ð²Ð¸Ð»,ÐÐ¶ÐµÐºÑÐ¾Ð½Ð²Ð¸Ð»Ñ,×'×§×¡×× ××××,ã¸ã£ã¯ã½ã³ãã«,æ°åéç»´å°,ì­ì¨ë¹,Jacksonville", :latitude => "30.33218", :longitude => "-81.65565").save
City.new(:country_id => "233", :name => "Jacksonville Beach", :aliases => ",Jacksonville Beach", :latitude => "30.29469", :longitude => "-81.39314").save
City.new(:country_id => "233", :name => "Jasmine Estates", :aliases => ",Jasmine Estates", :latitude => "28.29306", :longitude => "-82.6901").save
City.new(:country_id => "233", :name => "Jupiter", :aliases => "Jupiter,Ð®Ð¿Ð¸ÑÐµÑ,Jupiter", :latitude => "26.93422", :longitude => "-80.09421").save
City.new(:country_id => "233", :name => "Kendale Lakes", :aliases => "Kendale Lakes,Kendale Lakes", :latitude => "25.70816", :longitude => "-80.407").save
City.new(:country_id => "233", :name => "Kendall", :aliases => "Kendall,ÐÐµÐ½Ð´Ð°Ð»Ð»,Kendall", :latitude => "25.67927", :longitude => "-80.31727").save
City.new(:country_id => "233", :name => "Key West", :aliases => ",Key West", :latitude => "24.5557", :longitude => "-81.78259").save
City.new(:country_id => "233", :name => "Keystone", :aliases => ",Keystone", :latitude => "28.15585", :longitude => "-82.62121").save
City.new(:country_id => "233", :name => "Kissimmee", :aliases => "Kissimmee,Kissimmi,qysymy,ÐÐ¸ÑÑÐ¸Ð¼Ð¼Ð¸,×§××¡×××,Kissimmee", :latitude => "28.30468", :longitude => "-81.41667").save
City.new(:country_id => "233", :name => "Lake Magdalene", :aliases => ",Lake Magdalene", :latitude => "28.07418", :longitude => "-82.47176").save
City.new(:country_id => "233", :name => "Lake Worth", :aliases => ",Lake Worth", :latitude => "26.6159", :longitude => "-80.05699").save
City.new(:country_id => "233", :name => "Lake Worth Corridor", :aliases => ",Lake Worth Corridor", :latitude => "26.61649", :longitude => "-80.10102").save
City.new(:country_id => "233", :name => "Lakeland", :aliases => "Lakeland,Lakeland", :latitude => "28.03947", :longitude => "-81.9498").save
City.new(:country_id => "233", :name => "Lakeside", :aliases => ",Lakeside", :latitude => "30.12996", :longitude => "-81.76815").save
City.new(:country_id => "233", :name => "Land O' Lakes", :aliases => ",Land O' Lakes", :latitude => "28.2189", :longitude => "-82.45759").save
City.new(:country_id => "233", :name => "Largo", :aliases => "Largo,Largo", :latitude => "27.90947", :longitude => "-82.78732").save
City.new(:country_id => "233", :name => "Lauderdale Lakes", :aliases => ",Lauderdale Lakes", :latitude => "26.16647", :longitude => "-80.20838").save
City.new(:country_id => "233", :name => "Lauderhill", :aliases => ",Lauderhill", :latitude => "26.14036", :longitude => "-80.21338").save
City.new(:country_id => "233", :name => "Leesburg", :aliases => ",Leesburg", :latitude => "28.81082", :longitude => "-81.87786").save
City.new(:country_id => "233", :name => "Lehigh Acres", :aliases => ",Lehigh Acres", :latitude => "26.62535", :longitude => "-81.6248").save
City.new(:country_id => "233", :name => "Leisure City", :aliases => ",Leisure City", :latitude => "25.49539", :longitude => "-80.42922").save
City.new(:country_id => "233", :name => "Lutz", :aliases => "Lutc,ÐÑÑÑ,Lutz", :latitude => "28.15112", :longitude => "-82.46148").save
City.new(:country_id => "233", :name => "Lynn Haven", :aliases => ",Lynn Haven", :latitude => "30.24548", :longitude => "-85.64826").save
City.new(:country_id => "233", :name => "Margate", :aliases => ",Margate", :latitude => "26.24453", :longitude => "-80.20644").save
City.new(:country_id => "233", :name => "Meadow Woods", :aliases => ",Meadow Woods", :latitude => "28.38556", :longitude => "-81.36646").save
City.new(:country_id => "233", :name => "Melbourne", :aliases => "Mel'burn,Melbourne,mlbwrn,ÐÐµÐ»ÑÐ±ÑÑÐ½,×××××¨×,Melbourne", :latitude => "28.08363", :longitude => "-80.60811").save
City.new(:country_id => "233", :name => "Merritt Island", :aliases => ",Merritt Island", :latitude => "28.53917", :longitude => "-80.672").save
City.new(:country_id => "233", :name => "Miami", :aliases => "Majami,Miami,mai a mi,maiaemi,maiami,myamy,ÐÐ°Ð¹Ð°Ð¼Ð¸,ÐÐ°ÑÐ¼Ð¸,×××××,ÙÙØ§ÙÙ,ÙÛØ§ÙÛ,áááááá,ãã¤ã¢ã,è¿é¿å¯,ë§ì´ì ë¯¸,Miami", :latitude => "25.77427", :longitude => "-80.19366").save
City.new(:country_id => "233", :name => "Miami Beach", :aliases => "Majami-Bich,Miami Beach,ÐÐ°Ð¹Ð°Ð¼Ð¸-ÐÐ¸Ñ,Miami Beach", :latitude => "25.79065", :longitude => "-80.13005").save
City.new(:country_id => "233", :name => "Miami Lakes", :aliases => ",Miami Lakes", :latitude => "25.90871", :longitude => "-80.30866").save
City.new(:country_id => "233", :name => "Miramar", :aliases => "Miramar,mirama,ÐÐ¸ÑÐ°Ð¼Ð°Ñ,ãã©ãã¼,Miramar", :latitude => "25.98731", :longitude => "-80.23227").save
City.new(:country_id => "233", :name => "Myrtle Grove", :aliases => ",Myrtle Grove", :latitude => "30.42103", :longitude => "-87.30747").save
City.new(:country_id => "233", :name => "Naples", :aliases => "Neapol',ÐÐµÐ°Ð¿Ð¾Ð»Ñ,Naples", :latitude => "26.14204", :longitude => "-81.79481").save
City.new(:country_id => "233", :name => "New Port Richey", :aliases => ",New Port Richey", :latitude => "28.24418", :longitude => "-82.71927").save
City.new(:country_id => "233", :name => "New Smyrna Beach", :aliases => ",New Smyrna Beach", :latitude => "29.02582", :longitude => "-80.927").save
City.new(:country_id => "233", :name => "Norland", :aliases => "Norland,ÐÐ¾ÑÐ»Ð°Ð½Ð´,Norland", :latitude => "25.94898", :longitude => "-80.21227").save
City.new(:country_id => "233", :name => "North Fort Myers", :aliases => ",North Fort Myers", :latitude => "26.66729", :longitude => "-81.88009").save
City.new(:country_id => "233", :name => "North Lauderdale", :aliases => ",North Lauderdale", :latitude => "26.2173", :longitude => "-80.22588").save
City.new(:country_id => "233", :name => "North Miami", :aliases => ",North Miami", :latitude => "25.89009", :longitude => "-80.18671").save
City.new(:country_id => "233", :name => "North Miami Beach", :aliases => ",North Miami Beach", :latitude => "25.93315", :longitude => "-80.16255").save
City.new(:country_id => "233", :name => "North Port", :aliases => ",North Port", :latitude => "27.04422", :longitude => "-82.23593").save
City.new(:country_id => "233", :name => "Oak Ridge", :aliases => ",Oak Ridge", :latitude => "28.47112", :longitude => "-81.42452").save
City.new(:country_id => "233", :name => "Oakland Park", :aliases => ",Oakland Park", :latitude => "26.17231", :longitude => "-80.13199").save
City.new(:country_id => "233", :name => "Ocala", :aliases => "Okala,ÐÐºÐ°Ð»Ð°,Ocala", :latitude => "29.1872", :longitude => "-82.14009").save
City.new(:country_id => "233", :name => "Ocoee", :aliases => ",Ocoee", :latitude => "28.56917", :longitude => "-81.54396").save
City.new(:country_id => "233", :name => "Ojus", :aliases => ",Ojus", :latitude => "25.94843", :longitude => "-80.1506").save
City.new(:country_id => "233", :name => "Oldsmar", :aliases => ",Oldsmar", :latitude => "28.03418", :longitude => "-82.6651").save
City.new(:country_id => "233", :name => "Orlando", :aliases => "Orlando,ao lan duo,orando,ÐÑÐ»Ð°Ð½Ð´Ð¾,×××¨×× ××,ãªã¼ã©ã³ã,å¥¥å°å¤,Orlando", :latitude => "28.53834", :longitude => "-81.37924").save
City.new(:country_id => "233", :name => "Ormond Beach", :aliases => ",Ormond Beach", :latitude => "29.28581", :longitude => "-81.05589").save
City.new(:country_id => "233", :name => "Oviedo", :aliases => "Ov'edo,ÐÐ²ÑÐµÐ´Ð¾,Oviedo", :latitude => "28.67", :longitude => "-81.20812").save
City.new(:country_id => "233", :name => "Palm Bay", :aliases => "Palm Bay,Palm Bay", :latitude => "28.03446", :longitude => "-80.58866").save
City.new(:country_id => "233", :name => "Palm Beach Gardens", :aliases => ",Palm Beach Gardens", :latitude => "26.82339", :longitude => "-80.13865").save
City.new(:country_id => "233", :name => "Palm City", :aliases => ",Palm City", :latitude => "27.16783", :longitude => "-80.26616").save
City.new(:country_id => "233", :name => "Palm Coast", :aliases => ",Palm Coast", :latitude => "29.58497", :longitude => "-81.20784").save
City.new(:country_id => "233", :name => "Palm Harbor", :aliases => "Palm Harbor,Palm Harbor", :latitude => "28.07807", :longitude => "-82.76371").save
City.new(:country_id => "233", :name => "Palm Valley", :aliases => ",Palm Valley", :latitude => "30.17746", :longitude => "-81.38758").save
City.new(:country_id => "233", :name => "Panama City", :aliases => "Panama,Panama City,ÐÐ°Ð½Ð°Ð¼Ð°,Panama City", :latitude => "30.15946", :longitude => "-85.65983").save
City.new(:country_id => "233", :name => "Parkland", :aliases => ",Parkland", :latitude => "26.31008", :longitude => "-80.23727").save
City.new(:country_id => "233", :name => "Pembroke Pines", :aliases => "Pembroke Pines,Pembroke Pines", :latitude => "26.00315", :longitude => "-80.22394").save
City.new(:country_id => "233", :name => "Pensacola", :aliases => "Pensacola,Pensacola i Florida,Pensakola,pensakora,ÐÐµÐ½ÑÐ°ÐºÐ¾Ð»Ð°,ãã³ãµã³ã¼ã©,Pensacola", :latitude => "30.42131", :longitude => "-87.21691").save
City.new(:country_id => "233", :name => "Pine Hills", :aliases => ",Pine Hills", :latitude => "28.55778", :longitude => "-81.4534").save
City.new(:country_id => "233", :name => "Pinecrest", :aliases => ",Pinecrest", :latitude => "25.66705", :longitude => "-80.30811").save
City.new(:country_id => "233", :name => "Pinellas Park", :aliases => ",Pinellas Park", :latitude => "27.8428", :longitude => "-82.69954").save
City.new(:country_id => "233", :name => "Pinewood", :aliases => ",Pinewood", :latitude => "25.86898", :longitude => "-80.21699").save
City.new(:country_id => "233", :name => "Plant City", :aliases => ",Plant City", :latitude => "28.01863", :longitude => "-82.11286").save
City.new(:country_id => "233", :name => "Plantation", :aliases => "Plantacija,ÐÐ»Ð°Ð½ÑÐ°ÑÐ¸Ñ,Plantation", :latitude => "26.13421", :longitude => "-80.23184").save
City.new(:country_id => "233", :name => "Poinciana", :aliases => ",Poinciana", :latitude => "28.14029", :longitude => "-81.45841").save
City.new(:country_id => "233", :name => "Pompano Beach", :aliases => "Pompano Beach,Pompano Beach", :latitude => "26.23786", :longitude => "-80.12477").save
City.new(:country_id => "233", :name => "Ponte Vedra Beach", :aliases => "Ponte-Vedra-Bich,ÐÐ¾Ð½ÑÐµ-ÐÐµÐ´ÑÐ°-ÐÐ¸Ñ,Ponte Vedra Beach", :latitude => "30.23969", :longitude => "-81.38564").save
City.new(:country_id => "233", :name => "Port Charlotte", :aliases => ",Port Charlotte", :latitude => "26.97617", :longitude => "-82.09064").save
City.new(:country_id => "233", :name => "Port Orange", :aliases => ",Port Orange", :latitude => "29.13832", :longitude => "-80.99561").save
City.new(:country_id => "233", :name => "Port Saint Lucie", :aliases => "Port St. Lucie,Port Saint Lucie", :latitude => "27.29393", :longitude => "-80.35033").save
City.new(:country_id => "233", :name => "Punta Gorda Isles", :aliases => ",Punta Gorda Isles", :latitude => "26.91756", :longitude => "-82.07842").save
City.new(:country_id => "233", :name => "Richmond West", :aliases => ",Richmond West", :latitude => "25.6105", :longitude => "-80.42971").save
City.new(:country_id => "233", :name => "Riverview", :aliases => ",Riverview", :latitude => "27.86614", :longitude => "-82.32648").save
City.new(:country_id => "233", :name => "Riviera Beach", :aliases => ",Riviera Beach", :latitude => "26.77534", :longitude => "-80.0581").save
City.new(:country_id => "233", :name => "Rockledge", :aliases => ",Rockledge", :latitude => "28.35084", :longitude => "-80.72533").save
City.new(:country_id => "233", :name => "Royal Palm Beach", :aliases => ",Royal Palm Beach", :latitude => "26.7084", :longitude => "-80.2306").save
City.new(:country_id => "233", :name => "Safety Harbor", :aliases => ",Safety Harbor", :latitude => "27.99085", :longitude => "-82.69316").save
City.new(:country_id => "233", :name => "Saint Cloud", :aliases => ",Saint Cloud", :latitude => "28.2489", :longitude => "-81.28118").save
City.new(:country_id => "233", :name => "Saint Petersburg", :aliases => "Saint Petersburg,St. Petersburg,Saint Petersburg", :latitude => "27.77086", :longitude => "-82.67927").save
City.new(:country_id => "233", :name => "San Carlos Park", :aliases => ",San Carlos Park", :latitude => "26.4673", :longitude => "-81.80147").save
City.new(:country_id => "233", :name => "Sandalfoot Cove", :aliases => ",Sandalfoot Cove", :latitude => "26.33924", :longitude => "-80.18755").save
City.new(:country_id => "233", :name => "Sanford", :aliases => ",Sanford", :latitude => "28.80055", :longitude => "-81.27312").save
City.new(:country_id => "233", :name => "Sarasota", :aliases => "Sarasota,Sarasota", :latitude => "27.33643", :longitude => "-82.53065").save
City.new(:country_id => "233", :name => "Sarasota Springs", :aliases => ",Sarasota Springs", :latitude => "27.30894", :longitude => "-82.47954").save
City.new(:country_id => "233", :name => "Sebastian", :aliases => ",Sebastian", :latitude => "27.81642", :longitude => "-80.47061").save
City.new(:country_id => "233", :name => "Seminole", :aliases => ",Seminole", :latitude => "27.83975", :longitude => "-82.79121").save
City.new(:country_id => "233", :name => "South Bradenton", :aliases => ",South Bradenton", :latitude => "27.4631", :longitude => "-82.58176").save
City.new(:country_id => "233", :name => "South Miami Heights", :aliases => ",South Miami Heights", :latitude => "25.59761", :longitude => "-80.38061").save
City.new(:country_id => "233", :name => "Spring Hill", :aliases => "Spring-Khill,Ð¡Ð¿ÑÐ¸Ð½Ð³-Ð¥Ð¸Ð»Ð»,Spring Hill", :latitude => "28.47688", :longitude => "-82.52546").save
City.new(:country_id => "233", :name => "Stuart", :aliases => ",Stuart", :latitude => "27.19755", :longitude => "-80.25283").save
City.new(:country_id => "233", :name => "Sun City Center", :aliases => ",Sun City Center", :latitude => "27.71809", :longitude => "-82.35176").save
City.new(:country_id => "233", :name => "Sunny Isles Beach", :aliases => ",Sunny Isles Beach", :latitude => "25.95065", :longitude => "-80.12282").save
City.new(:country_id => "233", :name => "Sunrise", :aliases => ",Sunrise", :latitude => "26.15767", :longitude => "-80.28611").save
City.new(:country_id => "233", :name => "Sunset", :aliases => ",Sunset", :latitude => "25.70594", :longitude => "-80.35228").save
City.new(:country_id => "233", :name => "Tallahassee", :aliases => "Tallahassee,Tallahassia,Tallakhassi,tarahashi,Ð¢Ð°Ð»Ð»Ð°ÑÐ°ÑÑÐ¸,×××××××¡×,ã¿ã©ãã·ã¼,Tallahassee", :latitude => "30.43826", :longitude => "-84.28073").save
City.new(:country_id => "233", :name => "Tamarac", :aliases => ",Tamarac", :latitude => "26.21286", :longitude => "-80.24977").save
City.new(:country_id => "233", :name => "Tamiami", :aliases => "Tamiami,Tamiami", :latitude => "25.75871", :longitude => "-80.39839").save
City.new(:country_id => "233", :name => "Tampa", :aliases => "Tampa,tan pa,tanpa,tmph,Ð¢Ð°Ð¼Ð¿Ð°,×××¤×,ã¿ã³ã,å¦å¸,Tampa", :latitude => "27.94752", :longitude => "-82.45843").save
City.new(:country_id => "233", :name => "Tarpon Springs", :aliases => ",Tarpon Springs", :latitude => "28.14612", :longitude => "-82.75677").save
City.new(:country_id => "233", :name => "Temple Terrace", :aliases => ",Temple Terrace", :latitude => "28.0353", :longitude => "-82.38926").save
City.new(:country_id => "233", :name => "The Crossings", :aliases => ",The Crossings", :latitude => "25.67066", :longitude => "-80.40117").save
City.new(:country_id => "233", :name => "The Hammocks", :aliases => "The Hammocks,The Hammocks", :latitude => "25.67149", :longitude => "-80.4445").save
City.new(:country_id => "233", :name => "Titusville", :aliases => "Titusvill',Ð¢Ð¸ÑÑÑÐ²Ð¸Ð»Ð»Ñ,Titusville", :latitude => "28.61222", :longitude => "-80.80755").save
City.new(:country_id => "233", :name => "Town 'n' Country", :aliases => "Town 'n' Country,Town 'n' Country", :latitude => "28.01057", :longitude => "-82.57732").save
City.new(:country_id => "233", :name => "University Park", :aliases => ",University Park", :latitude => "25.74649", :longitude => "-80.36755").save
City.new(:country_id => "233", :name => "Venice", :aliases => "Venecija,ÐÐµÐ½ÐµÑÐ¸Ñ,Venice", :latitude => "27.09978", :longitude => "-82.45426").save
City.new(:country_id => "233", :name => "Vero Beach", :aliases => ",Vero Beach", :latitude => "27.63864", :longitude => "-80.39727").save
City.new(:country_id => "233", :name => "Wekiwa Springs", :aliases => ",Wekiwa Springs", :latitude => "28.69861", :longitude => "-81.42563").save
City.new(:country_id => "233", :name => "Wekiva Springs", :aliases => ",Wekiva Springs", :latitude => "28.69861", :longitude => "-81.42563").save
City.new(:country_id => "233", :name => "Wellington", :aliases => "Vellington,ÐÐµÐ»Ð»Ð¸Ð½Ð³ÑÐ¾Ð½,Wellington", :latitude => "26.65868", :longitude => "-80.24144").save
City.new(:country_id => "233", :name => "West Little River", :aliases => ",West Little River", :latitude => "25.85704", :longitude => "-80.23699").save
City.new(:country_id => "233", :name => "West Palm Beach", :aliases => "West Palm Beach,u~esutopamubichi,ã¦ã§ã¹ããã¼ã ãã¼ã,West Palm Beach", :latitude => "26.71534", :longitude => "-80.05337").save
City.new(:country_id => "233", :name => "West Pensacola", :aliases => ",West Pensacola", :latitude => "30.42659", :longitude => "-87.27969").save
City.new(:country_id => "233", :name => "West and East Lealman", :aliases => ",West and East Lealman", :latitude => "27.81993", :longitude => "-82.68944").save
City.new(:country_id => "233", :name => "Westchester", :aliases => "Vestchester,ÐÐµÑÑÑÐµÑÑÐµÑ,Westchester", :latitude => "25.75482", :longitude => "-80.32727").save
City.new(:country_id => "233", :name => "Weston", :aliases => "Uehston,Weston,Ð£ÑÑÑÐ¾Ð½,Weston", :latitude => "26.10037", :longitude => "-80.39977").save
City.new(:country_id => "233", :name => "Winter Garden", :aliases => ",Winter Garden", :latitude => "28.56528", :longitude => "-81.58618").save
City.new(:country_id => "233", :name => "Winter Haven", :aliases => ",Winter Haven", :latitude => "28.02224", :longitude => "-81.73286").save
City.new(:country_id => "233", :name => "Winter Park", :aliases => ",Winter Park", :latitude => "28.6", :longitude => "-81.33924").save
City.new(:country_id => "233", :name => "Winter Springs", :aliases => ",Winter Springs", :latitude => "28.69889", :longitude => "-81.30812").save
City.new(:country_id => "233", :name => "Wright", :aliases => "Rajt,Ð Ð°Ð¹Ñ,Wright", :latitude => "30.45575", :longitude => "-86.63829").save
City.new(:country_id => "233", :name => "Yeehaw Junction", :aliases => ",Yeehaw Junction", :latitude => "27.70031", :longitude => "-80.90423").save
City.new(:country_id => "233", :name => "Acworth", :aliases => ",Acworth", :latitude => "34.06593", :longitude => "-84.67688").save
City.new(:country_id => "233", :name => "Albany", :aliases => "Olbani,ÐÐ»Ð±Ð°Ð½Ð¸,Albany", :latitude => "31.57851", :longitude => "-84.15574").save
City.new(:country_id => "233", :name => "Alpharetta", :aliases => "Al'faretta,ÐÐ»ÑÑÐ°ÑÐµÑÑÐ°,Alpharetta", :latitude => "34.07538", :longitude => "-84.29409").save
City.new(:country_id => "233", :name => "Americus", :aliases => ",Americus", :latitude => "32.07239", :longitude => "-84.23269").save
City.new(:country_id => "233", :name => "Athens", :aliases => "Atina,ÐÑÐ¸Ð½Ð°,Athens", :latitude => "33.96095", :longitude => "-83.37794").save
City.new(:country_id => "233", :name => "Atlanta", :aliases => "Atlanta,Atlantae,aeteullaenta,atalanta,atlanta,atlanta, jwrjya,atoranta,etalanta,etlanta,ya te lan da,ÎÏÎ»Î¬Î½ÏÎ±,ÐÑÐ»Ð°Ð½ÑÃ¦,ÐÑÐ»Ð°Ð½ÑÐ°,××××× ××,×××× ××,Ø¢ØªÙØ§ÙØªØ§,Ø£ØªÙØ§ÙØªØ§Ø Ø¬ÙØ±Ø¬ÙØ§,Ø§Ù¹ÙØ§ÙÙ¹Ø§,Ø§Ù¹ÙØ§ÙÙ¹Ø§Ø Ø¬Ø§Ø±Ø¬ÛØ§,à¤à¤à¤²à¤¾à¤à¤à¤¾,à¤à¤à¥à¤²à¤¾à¤¨à¥à¤à¤¾,àªàªàª²àª¾àª¨à«àªàª¾,à®à®à¯à®²à®¾à®©à¯à®à®¾,à°à°à±à°²à°¾à°à°à°¾,à²à²à³à²²à²¾à²à²à²¾,à¹à¸­à¸à¹à¸¥à¸à¸à¸²,à½¨à¼à½à½²à¼à½£à½±à½à¼à½à½±à¼,áá¢áááá¢á,ã¢ãã©ã³ã¿,äºç¹å°å¤§,ì íëí,Atlanta", :latitude => "33.749", :longitude => "-84.38798").save
City.new(:country_id => "233", :name => "Augusta", :aliases => "Augusta,Ogasta,awghsta, jwrjya,ÐÐ³Ð°ÑÑÐ°,Ø£ÙØºØ³ØªØ§Ø Ø¬ÙØ±Ø¬ÙØ§,Augusta", :latitude => "33.47097", :longitude => "-81.97484").save
City.new(:country_id => "233", :name => "Belvedere Park", :aliases => ",Belvedere Park", :latitude => "33.75483", :longitude => "-84.26742").save
City.new(:country_id => "233", :name => "Brunswick", :aliases => "Braunshvejg,ÐÑÐ°ÑÐ½ÑÐ²ÐµÐ¹Ð³,Brunswick", :latitude => "31.14995", :longitude => "-81.49149").save
City.new(:country_id => "233", :name => "Canton", :aliases => ",Canton", :latitude => "34.23676", :longitude => "-84.49076").save
City.new(:country_id => "233", :name => "Carrollton", :aliases => ",Carrollton", :latitude => "33.58011", :longitude => "-85.07661").save
City.new(:country_id => "233", :name => "Cartersville", :aliases => ",Cartersville", :latitude => "34.1651", :longitude => "-84.79994").save
City.new(:country_id => "233", :name => "College Park", :aliases => "Kolledzh Park,ÐÐ¾Ð»Ð»ÐµÐ´Ð¶ ÐÐ°ÑÐº,College Park", :latitude => "33.65344", :longitude => "-84.44937").save
City.new(:country_id => "233", :name => "Columbus", :aliases => "Columbus,kolumbus,koronbasu,ÐÐ¾Ð»ÑÐ¼Ð±ÑÑ,ã³ã­ã³ãã¹,Columbus", :latitude => "32.46098", :longitude => "-84.98771").save
City.new(:country_id => "233", :name => "Dalton", :aliases => "Dalton,ÐÐ°Ð»ÑÐ¾Ð½,Dalton", :latitude => "34.7698", :longitude => "-84.97022").save
City.new(:country_id => "233", :name => "Decatur", :aliases => "Dekejter,ÐÐµÐºÐµÐ¹ÑÐµÑ,Decatur", :latitude => "33.77483", :longitude => "-84.29631").save
City.new(:country_id => "233", :name => "Douglasville", :aliases => ",Douglasville", :latitude => "33.7515", :longitude => "-84.74771").save
City.new(:country_id => "233", :name => "Dublin", :aliases => "Dublin,ÐÑÐ±Ð»Ð¸Ð½,Dublin", :latitude => "32.54044", :longitude => "-82.90375").save
City.new(:country_id => "233", :name => "Duluth", :aliases => "Dulut,ÐÑÐ»ÑÑ,Duluth", :latitude => "34.00288", :longitude => "-84.14464").save
City.new(:country_id => "233", :name => "Dunwoody", :aliases => "Danvudi,ÐÐ°Ð½Ð²ÑÐ´Ð¸,Dunwoody", :latitude => "33.94621", :longitude => "-84.33465").save
City.new(:country_id => "233", :name => "East Point", :aliases => ",East Point", :latitude => "33.67955", :longitude => "-84.43937").save
City.new(:country_id => "233", :name => "Evans", :aliases => ",Evans", :latitude => "33.53375", :longitude => "-82.13067").save
City.new(:country_id => "233", :name => "Forest Park", :aliases => ",Forest Park", :latitude => "33.62205", :longitude => "-84.36909").save
City.new(:country_id => "233", :name => "Gainesville", :aliases => ",Gainesville", :latitude => "34.29788", :longitude => "-83.82407").save
City.new(:country_id => "233", :name => "Griffin", :aliases => "Griffin,ÐÑÐ¸ÑÑÐ¸Ð½,Griffin", :latitude => "33.24678", :longitude => "-84.26409").save
City.new(:country_id => "233", :name => "Hinesville", :aliases => ",Hinesville", :latitude => "31.84688", :longitude => "-81.59595").save
City.new(:country_id => "233", :name => "Kennesaw", :aliases => "Kenneso,ÐÐµÐ½Ð½ÐµÑÐ¾,Kennesaw", :latitude => "34.02343", :longitude => "-84.61549").save
City.new(:country_id => "233", :name => "La Grange", :aliases => "City of LaGrange,La Grange,LaGrange,La Grange", :latitude => "33.03929", :longitude => "-85.03133").save
City.new(:country_id => "233", :name => "Lawrenceville", :aliases => ",Lawrenceville", :latitude => "33.95621", :longitude => "-83.98796").save
City.new(:country_id => "233", :name => "Mableton", :aliases => ",Mableton", :latitude => "33.81574", :longitude => "-84.56194").save
City.new(:country_id => "233", :name => "Macon", :aliases => "Macon,Makon,mei ken,ÐÐ°ÐºÐ¾Ð½,æ¢è¯,Macon", :latitude => "32.84069", :longitude => "-83.6324").save
City.new(:country_id => "233", :name => "Marietta", :aliases => "Marietta,marietta,ÐÐ°ÑÐ¸ÐµÑÑÐ°,ããªã¨ãã¿,Marietta", :latitude => "33.9526", :longitude => "-84.54993").save
City.new(:country_id => "233", :name => "Martinez", :aliases => "Martines,ÐÐ°ÑÑÐ¸Ð½ÐµÑ,Martinez", :latitude => "33.51736", :longitude => "-82.07567").save
City.new(:country_id => "233", :name => "Milledgeville", :aliases => ",Milledgeville", :latitude => "33.08014", :longitude => "-83.2321").save
City.new(:country_id => "233", :name => "Newnan", :aliases => ",Newnan", :latitude => "33.38067", :longitude => "-84.79966").save
City.new(:country_id => "233", :name => "North Atlanta", :aliases => ",North Atlanta", :latitude => "33.8651", :longitude => "-84.33659").save
City.new(:country_id => "233", :name => "North Decatur", :aliases => ",North Decatur", :latitude => "33.79038", :longitude => "-84.30603").save
City.new(:country_id => "233", :name => "North Druid Hills", :aliases => ",North Druid Hills", :latitude => "33.81677", :longitude => "-84.31326").save
City.new(:country_id => "233", :name => "Peachtree City", :aliases => ",Peachtree City", :latitude => "33.39678", :longitude => "-84.59576").save
City.new(:country_id => "233", :name => "Redan", :aliases => "Redan,Ð ÐµÐ´Ð°Ð½,Redan", :latitude => "33.74538", :longitude => "-84.13158").save
City.new(:country_id => "233", :name => "Riverdale", :aliases => ",Riverdale", :latitude => "33.57261", :longitude => "-84.41326").save
City.new(:country_id => "233", :name => "Rome", :aliases => ",Rome", :latitude => "34.25704", :longitude => "-85.16467").save
City.new(:country_id => "233", :name => "Roswell", :aliases => "Roswell,Roswell", :latitude => "34.02316", :longitude => "-84.36159").save
City.new(:country_id => "233", :name => "Sandy Springs", :aliases => "Sandy Springs,Sandy Springs", :latitude => "33.92427", :longitude => "-84.37854").save
City.new(:country_id => "233", :name => "Savannah", :aliases => "Savanna,Savannah,Savannah i Georgia,saban'na,sha wa na,Ð¡Ð°Ð²Ð°Ð½Ð½Ð°,ãµãã³ã,æ²ç¦ç´,Savannah", :latitude => "32.08354", :longitude => "-81.09983").save
City.new(:country_id => "233", :name => "Smyrna", :aliases => "Smirna,Ð¡Ð¼Ð¸ÑÐ½Ð°,Smyrna", :latitude => "33.88399", :longitude => "-84.51438").save
City.new(:country_id => "233", :name => "Snellville", :aliases => ",Snellville", :latitude => "33.85733", :longitude => "-84.01991").save
City.new(:country_id => "233", :name => "Statesboro", :aliases => ",Statesboro", :latitude => "32.44879", :longitude => "-81.78317").save
City.new(:country_id => "233", :name => "Sugar Hill", :aliases => ",Sugar Hill", :latitude => "34.10649", :longitude => "-84.03352").save
City.new(:country_id => "233", :name => "Thomasville", :aliases => ",Thomasville", :latitude => "30.83658", :longitude => "-83.97878").save
City.new(:country_id => "233", :name => "Tifton", :aliases => ",Tifton", :latitude => "31.45046", :longitude => "-83.5085").save
City.new(:country_id => "233", :name => "Tucker", :aliases => "Taker,Ð¢Ð°ÐºÐµÑ,Tucker", :latitude => "33.85455", :longitude => "-84.21714").save
City.new(:country_id => "233", :name => "Valdosta", :aliases => ",Valdosta", :latitude => "30.8327", :longitude => "-83.27849").save
City.new(:country_id => "233", :name => "Warner Robins", :aliases => ",Warner Robins", :latitude => "32.62098", :longitude => "-83.5999").save
City.new(:country_id => "233", :name => "Waycross", :aliases => ",Waycross", :latitude => "31.21355", :longitude => "-82.35402").save
City.new(:country_id => "233", :name => "Wilmington Island", :aliases => ",Wilmington Island", :latitude => "32.00355", :longitude => "-80.97372").save
City.new(:country_id => "233", :name => "Woodstock", :aliases => "Vudstok,ÐÑÐ´ÑÑÐ¾Ðº,Woodstock", :latitude => "34.10149", :longitude => "-84.51938").save
City.new(:country_id => "233", :name => "Alton", :aliases => ",Alton", :latitude => "38.8906", :longitude => "-90.18428").save
City.new(:country_id => "233", :name => "Belleville", :aliases => ",Belleville", :latitude => "38.52005", :longitude => "-89.98399").save
City.new(:country_id => "233", :name => "Cahokia", :aliases => ",Cahokia", :latitude => "38.57088", :longitude => "-90.19011").save
City.new(:country_id => "233", :name => "Carbondale", :aliases => ",Carbondale", :latitude => "37.72727", :longitude => "-89.21675").save
City.new(:country_id => "233", :name => "Charleston", :aliases => "Charlston,Ð§Ð°ÑÐ»ÑÑÐ¾Ð½,Charleston", :latitude => "39.49615", :longitude => "-88.17615").save
City.new(:country_id => "233", :name => "Collinsville", :aliases => "Kollinsvil',ÐÐ¾Ð»Ð»Ð¸Ð½ÑÐ²Ð¸Ð»Ñ,Collinsville", :latitude => "38.67033", :longitude => "-89.98455").save
City.new(:country_id => "233", :name => "Decatur", :aliases => "Decatur,Dekejter,dikatura,ÐÐµÐºÐµÐ¹ÑÐµÑ,à¦¡à¦¿à¦à¦¾à¦à§à¦°,Decatur", :latitude => "39.84031", :longitude => "-88.9548").save
City.new(:country_id => "233", :name => "East Saint Louis", :aliases => ",East Saint Louis", :latitude => "38.6245", :longitude => "-90.15094").save
City.new(:country_id => "233", :name => "Edwardsville", :aliases => ",Edwardsville", :latitude => "38.81144", :longitude => "-89.95316").save
City.new(:country_id => "233", :name => "Fairview Heights", :aliases => ",Fairview Heights", :latitude => "38.58894", :longitude => "-89.99038").save
City.new(:country_id => "233", :name => "Godfrey", :aliases => ",Godfrey", :latitude => "38.9556", :longitude => "-90.18678").save
City.new(:country_id => "233", :name => "Granite City", :aliases => ",Granite City", :latitude => "38.70144", :longitude => "-90.14872").save
City.new(:country_id => "233", :name => "Jacksonville", :aliases => "Dzheksonvill,ÐÐ¶ÐµÐºÑÐ¾Ð½Ð²Ð¸Ð»Ð»,Jacksonville", :latitude => "39.73394", :longitude => "-90.22901").save
City.new(:country_id => "233", :name => "Marion", :aliases => "Mehrion,ÐÑÑÐ¸Ð¾Ð½,Marion", :latitude => "37.73061", :longitude => "-88.93313").save
City.new(:country_id => "233", :name => "Mattoon", :aliases => ",Mattoon", :latitude => "39.48309", :longitude => "-88.37283").save
City.new(:country_id => "233", :name => "Mount Vernon", :aliases => ",Mount Vernon", :latitude => "38.31727", :longitude => "-88.90312").save
City.new(:country_id => "233", :name => "O'Fallon", :aliases => ",O'Fallon", :latitude => "38.59227", :longitude => "-89.91121").save
City.new(:country_id => "233", :name => "Quincy", :aliases => "Kuinsi,ÐÑÐ¸Ð½ÑÐ¸,Quincy", :latitude => "39.9356", :longitude => "-91.40987").save
City.new(:country_id => "233", :name => "Springfield", :aliases => "Springfield,Springfild,si pu lin fei er de,springfild,spryngpyld,supuringufirudo,Ð¡Ð¿ÑÐ¸Ð½Ð³ÑÐ¸Ð»Ð´,Ð¡Ð¿ÑÑÐ½Ð³ÑÑÐ»Ð´,×¡×¤×¨×× ××¤×××,à¸ªà¸à¸£à¸´à¸à¸à¸´à¸¥à¸à¹,ã¹ããªã³ã°ãã£ã¼ã«ã,æ¯æ®æè²å°å¾·,Springfield", :latitude => "39.80172", :longitude => "-89.64371").save
City.new(:country_id => "233", :name => "Upper Alton", :aliases => ",Upper Alton", :latitude => "38.91144", :longitude => "-90.15066").save
City.new(:country_id => "233", :name => "Bloomington", :aliases => "Bloomington,Blumington,buruminton,ÐÐ»ÑÐ¼Ð¸Ð½Ð³ÑÐ¾Ð½,ãã«ã¼ãã³ãã³,Bloomington", :latitude => "39.16532", :longitude => "-86.52639").save
City.new(:country_id => "233", :name => "Brownsburg", :aliases => ",Brownsburg", :latitude => "39.84338", :longitude => "-86.39777").save
City.new(:country_id => "233", :name => "Carmel", :aliases => "Karmel',ÐÐ°ÑÐ¼ÐµÐ»Ñ,Carmel", :latitude => "39.97837", :longitude => "-86.11804").save
City.new(:country_id => "233", :name => "Clarksville", :aliases => ",Clarksville", :latitude => "38.29674", :longitude => "-85.75996").save
City.new(:country_id => "233", :name => "Columbus", :aliases => "Kolumbus,ÐÐ¾Ð»ÑÐ¼Ð±ÑÑ,Columbus", :latitude => "39.20144", :longitude => "-85.92138").save
City.new(:country_id => "233", :name => "Evansville", :aliases => "Ehvansvill,Evansville,ebanzubiru,evu~anzuvu~iru,Ð­Ð²Ð°Ð½ÑÐ²Ð¸Ð»Ð»,ã¨ãã³ãºãã«,ã¨ã´ã¡ã³ãºã´ã£ã«,Evansville", :latitude => "37.97476", :longitude => "-87.55585").save
City.new(:country_id => "233", :name => "Fishers", :aliases => ",Fishers", :latitude => "39.95559", :longitude => "-86.01387").save
City.new(:country_id => "233", :name => "Greenfield", :aliases => "Grinfild,ÐÑÐ¸Ð½ÑÐ¸Ð»Ð´,Greenfield", :latitude => "39.78504", :longitude => "-85.76942").save
City.new(:country_id => "233", :name => "Greenwood", :aliases => ",Greenwood", :latitude => "39.61366", :longitude => "-86.10665").save
City.new(:country_id => "233", :name => "Indianapolis", :aliases => "Indianapolis,ÐÐ½Ð´Ð¸Ð°Ð½Ð°Ð¿Ð¾Ð»Ð¸Ñ,Indianapolis", :latitude => "39.76838", :longitude => "-86.15804").save
City.new(:country_id => "233", :name => "Jeffersonville", :aliases => ",Jeffersonville", :latitude => "38.27757", :longitude => "-85.73718").save
City.new(:country_id => "233", :name => "Lawrence", :aliases => "Lourens,ÐÐ¾ÑÑÐµÐ½Ñ,Lawrence", :latitude => "39.83865", :longitude => "-86.02526").save
City.new(:country_id => "233", :name => "New Albany", :aliases => "N'ju-Albani,ÐÑÑ-ÐÐ»Ð±Ð°Ð½Ð¸,New Albany", :latitude => "38.28562", :longitude => "-85.82413").save
City.new(:country_id => "233", :name => "New Castle", :aliases => ",New Castle", :latitude => "39.92894", :longitude => "-85.37025").save
City.new(:country_id => "233", :name => "Plainfield", :aliases => ",Plainfield", :latitude => "39.70421", :longitude => "-86.39944").save
City.new(:country_id => "233", :name => "Richmond", :aliases => "Richmond,Ð Ð¸ÑÐ¼Ð¾Ð½Ð´,Richmond", :latitude => "39.82894", :longitude => "-84.89024").save
City.new(:country_id => "233", :name => "Seymour", :aliases => ",Seymour", :latitude => "38.95922", :longitude => "-85.89025").save
City.new(:country_id => "233", :name => "Shelbyville", :aliases => ",Shelbyville", :latitude => "39.52144", :longitude => "-85.77692").save
City.new(:country_id => "233", :name => "Terre Haute", :aliases => ",Terre Haute", :latitude => "39.4667", :longitude => "-87.41391").save
City.new(:country_id => "233", :name => "Vincennes", :aliases => ",Vincennes", :latitude => "38.67727", :longitude => "-87.52863").save
City.new(:country_id => "233", :name => "Derby", :aliases => ",Derby", :latitude => "37.54557", :longitude => "-97.26893").save
City.new(:country_id => "233", :name => "Emporia", :aliases => ",Emporia", :latitude => "38.4039", :longitude => "-96.18166").save
City.new(:country_id => "233", :name => "Hays", :aliases => ",Hays", :latitude => "38.87918", :longitude => "-99.32677").save
City.new(:country_id => "233", :name => "Hutchinson", :aliases => "Khatchinson,Ð¥Ð°ÑÑÐ¸Ð½ÑÐ¾Ð½,Hutchinson", :latitude => "38.06084", :longitude => "-97.92977").save
City.new(:country_id => "233", :name => "Junction City", :aliases => ",Junction City", :latitude => "39.02861", :longitude => "-96.8314").save
City.new(:country_id => "233", :name => "Kansas City", :aliases => "Kansas City,Kansas City i Kansas,Kanzas-Siti,kan sa si cheng,ÐÐ°Ð½Ð·Ð°Ñ-Ð¡Ð¸ÑÐ¸,å ªè©æ¯å,Kansas City", :latitude => "39.11417", :longitude => "-94.62746").save
City.new(:country_id => "233", :name => "Lawrence", :aliases => "Lawrence,Lorens,Lourens,ÐÐ¾ÑÑÐµÐ½Ñ,Lawrence", :latitude => "38.97167", :longitude => "-95.23525").save
City.new(:country_id => "233", :name => "Leavenworth", :aliases => "Livenvors,ÐÐ¸Ð²ÐµÐ½Ð²Ð¾ÑÑ,Leavenworth", :latitude => "39.31111", :longitude => "-94.92246").save
City.new(:country_id => "233", :name => "Leawood", :aliases => ",Leawood", :latitude => "38.96667", :longitude => "-94.6169").save
City.new(:country_id => "233", :name => "Lenexa", :aliases => ",Lenexa", :latitude => "38.95362", :longitude => "-94.73357").save
City.new(:country_id => "233", :name => "Manhattan", :aliases => "Mankhehtten,ÐÐ°Ð½ÑÑÑÑÐµÐ½,Manhattan", :latitude => "39.18361", :longitude => "-96.57167").save
City.new(:country_id => "233", :name => "Newton", :aliases => "N'juton,ÐÑÑÑÐ¾Ð½,Newton", :latitude => "38.04668", :longitude => "-97.34504").save
City.new(:country_id => "233", :name => "Olathe", :aliases => "Olathe,Olathe", :latitude => "38.8814", :longitude => "-94.81913").save
City.new(:country_id => "233", :name => "Overland Park", :aliases => "Overland Park,Overland Park", :latitude => "38.98223", :longitude => "-94.67079").save
City.new(:country_id => "233", :name => "Pittsburg", :aliases => "Pitsburg,ÐÐ¸ÑÑÐ±ÑÑÐ³,Pittsburg", :latitude => "37.41088", :longitude => "-94.70496").save
City.new(:country_id => "233", :name => "Prairie Village", :aliases => ",Prairie Village", :latitude => "38.99167", :longitude => "-94.63357").save
City.new(:country_id => "233", :name => "Salina", :aliases => "Salina,Ð¡Ð°Ð»Ð¸Ð½Ð°,Salina", :latitude => "38.84028", :longitude => "-97.61142").save
City.new(:country_id => "233", :name => "Shawnee", :aliases => ",Shawnee", :latitude => "39.04167", :longitude => "-94.72024").save
City.new(:country_id => "233", :name => "Topeka", :aliases => "Topeka,Topika,topika,twpyqh,Ð¢Ð¾Ð¿Ð¸ÐºÐ°,×××¤××§×,ããã«,Topeka", :latitude => "39.04833", :longitude => "-95.67804").save
City.new(:country_id => "233", :name => "Wichita", :aliases => "Uichito,Wichita,u~ichita,wei qi tuo,Ð£Ð¸ÑÐ¸ÑÐ¾,ã¦ã£ãã¿,å¨å¥æ,Wichita", :latitude => "37.69224", :longitude => "-97.33754").save
City.new(:country_id => "233", :name => "Ashland", :aliases => ",Ashland", :latitude => "38.47841", :longitude => "-82.63794").save
City.new(:country_id => "233", :name => "Bowling Green", :aliases => "Bouling-Grin,ÐÐ¾ÑÐ»Ð¸Ð½Ð³-ÐÑÐ¸Ð½,Bowling Green", :latitude => "36.99032", :longitude => "-86.4436").save
City.new(:country_id => "233", :name => "Covington", :aliases => ",Covington", :latitude => "39.08367", :longitude => "-84.50855").save
City.new(:country_id => "233", :name => "Danville", :aliases => ",Danville", :latitude => "37.64563", :longitude => "-84.77217").save
City.new(:country_id => "233", :name => "Elizabethtown", :aliases => "Ehlizabettaun,Ð­Ð»Ð¸Ð·Ð°Ð±ÐµÑÑÐ°ÑÐ½,Elizabethtown", :latitude => "37.69395", :longitude => "-85.85913").save
City.new(:country_id => "233", :name => "Erlanger", :aliases => ",Erlanger", :latitude => "39.01673", :longitude => "-84.60078").save
City.new(:country_id => "233", :name => "Fern Creek", :aliases => ",Fern Creek", :latitude => "38.15979", :longitude => "-85.58774").save
City.new(:country_id => "233", :name => "Florence", :aliases => "Florencija,Ð¤Ð»Ð¾ÑÐµÐ½ÑÐ¸Ñ,Florence", :latitude => "38.99895", :longitude => "-84.62661").save
City.new(:country_id => "233", :name => "Fort Thomas", :aliases => ",Fort Thomas", :latitude => "39.07506", :longitude => "-84.44716").save
City.new(:country_id => "233", :name => "Frankfort", :aliases => "Frankfort,Frankfurt,furankufoto,prnqpwrt,Ð¤ÑÐ°Ð½ÐºÑÑÑÑ,×¤×¨× ×§×¤××¨×,à¹à¸à¸£à¸à¸à¹à¹à¸à¸´à¸£à¹à¸,ãã©ã³ã¯ãã©ã¼ã,Frankfort", :latitude => "38.20091", :longitude => "-84.87328").save
City.new(:country_id => "233", :name => "Georgetown", :aliases => ",Georgetown", :latitude => "38.2098", :longitude => "-84.55883").save
City.new(:country_id => "233", :name => "Henderson", :aliases => "Khenderson,Ð¥ÐµÐ½Ð´ÐµÑÑÐ¾Ð½,Henderson", :latitude => "37.83615", :longitude => "-87.59001").save
City.new(:country_id => "233", :name => "Highview", :aliases => ",Highview", :latitude => "38.14285", :longitude => "-85.62413").save
City.new(:country_id => "233", :name => "Hopkinsville", :aliases => "Khopkinsville,Ð¥Ð¾Ð¿ÐºÐ¸Ð½ÑÐ²Ð¸Ð»Ð»Ðµ,Hopkinsville", :latitude => "36.8656", :longitude => "-87.48862").save
City.new(:country_id => "233", :name => "Independence", :aliases => ",Independence", :latitude => "38.94312", :longitude => "-84.54411").save
City.new(:country_id => "233", :name => "Jeffersontown", :aliases => ",Jeffersontown", :latitude => "38.19424", :longitude => "-85.5644").save
City.new(:country_id => "233", :name => "Lexington", :aliases => "Leksington,Lexington,Lexintonia,lqsyngtwn,rekishinton,ÐÐµÐºÑÐ¸Ð½Ð³ÑÐ¾Ð½,××§×¡×× ××××,ã¬ã­ã·ã³ãã³,Lexington", :latitude => "37.98869", :longitude => "-84.47772").save
City.new(:country_id => "233", :name => "Lexington-Fayette", :aliases => ",Lexington-Fayette", :latitude => "38.0498", :longitude => "-84.45855").save
City.new(:country_id => "233", :name => "Louisville", :aliases => "Louisville,Ludovicopolis,Luisvil,Luivil,lu yi si wei er,ruibiru,ÐÑÐ¸Ð²Ð¸Ð»,ÐÑÐ¸ÑÐ²Ð¸Ð»,ã«ã¤ãã«,è·¯ææ¯ç¶­ç¾,Louisville", :latitude => "38.25424", :longitude => "-85.75941").save
City.new(:country_id => "233", :name => "Madisonville", :aliases => ",Madisonville", :latitude => "37.3281", :longitude => "-87.49889").save
City.new(:country_id => "233", :name => "Murray", :aliases => "Mjurrej,ÐÑÑÑÐµÐ¹,Murray", :latitude => "36.61033", :longitude => "-88.31476").save
City.new(:country_id => "233", :name => "Newburg", :aliases => ",Newburg", :latitude => "38.16007", :longitude => "-85.65968").save
City.new(:country_id => "233", :name => "Newport", :aliases => "N'juport,ÐÑÑÐ¿Ð¾ÑÑ,Newport", :latitude => "39.09145", :longitude => "-84.49578").save
City.new(:country_id => "233", :name => "Nicholasville", :aliases => ",Nicholasville", :latitude => "37.88063", :longitude => "-84.573").save
City.new(:country_id => "233", :name => "Okolona", :aliases => ",Okolona", :latitude => "38.14118", :longitude => "-85.68774").save
City.new(:country_id => "233", :name => "Owensboro", :aliases => ",Owensboro", :latitude => "37.77422", :longitude => "-87.11333").save
City.new(:country_id => "233", :name => "Pleasure Ridge Park", :aliases => ",Pleasure Ridge Park", :latitude => "38.14535", :longitude => "-85.8583").save
City.new(:country_id => "233", :name => "Radcliff", :aliases => "Radklif,Ð Ð°Ð´ÐºÐ»Ð¸Ñ,Radcliff", :latitude => "37.84035", :longitude => "-85.94913").save
City.new(:country_id => "233", :name => "Richmond", :aliases => "Richmond,Ð Ð¸ÑÐ¼Ð¾Ð½Ð´,Richmond", :latitude => "37.74786", :longitude => "-84.29465").save
City.new(:country_id => "233", :name => "Saint Matthews", :aliases => ",Saint Matthews", :latitude => "38.25285", :longitude => "-85.65579").save
City.new(:country_id => "233", :name => "Shively", :aliases => ",Shively", :latitude => "38.20007", :longitude => "-85.82274").save
City.new(:country_id => "233", :name => "Valley Station", :aliases => ",Valley Station", :latitude => "38.11118", :longitude => "-85.87024").save
City.new(:country_id => "233", :name => "Winchester", :aliases => ",Winchester", :latitude => "37.99008", :longitude => "-84.17965").save
City.new(:country_id => "233", :name => "Alexandria", :aliases => "Aleksandrija,ÐÐ»ÐµÐºÑÐ°Ð½Ð´ÑÐ¸Ñ,Alexandria", :latitude => "31.31129", :longitude => "-92.44514").save
City.new(:country_id => "233", :name => "Baton Rouge", :aliases => "Baton Rouge,Baton-Ruzh,Rubrobastum,batonruju,batwn rwzh,ÐÐ°ÑÐ¾Ð½-Ð ÑÐ¶,Ø¨Ø§ØªÙÙ Ø±ÙÚ,Ø¨Ø§ØªÙÙâØ±ÙÚ,ããã³ã«ã¼ã¸ã¥,Baton Rouge", :latitude => "30.45075", :longitude => "-91.15455").save
City.new(:country_id => "233", :name => "Bayou Cane", :aliases => ",Bayou Cane", :latitude => "29.6241", :longitude => "-90.7512").save
City.new(:country_id => "233", :name => "Bossier City", :aliases => ",Bossier City", :latitude => "32.51599", :longitude => "-93.73212").save
City.new(:country_id => "233", :name => "Chalmette", :aliases => ",Chalmette", :latitude => "29.9427", :longitude => "-89.9634").save
City.new(:country_id => "233", :name => "Estelle", :aliases => ",Estelle", :latitude => "29.84576", :longitude => "-90.10674").save
City.new(:country_id => "233", :name => "Gretna", :aliases => ",Gretna", :latitude => "29.91465", :longitude => "-90.05396").save
City.new(:country_id => "233", :name => "Hammond", :aliases => "Khammond,Ð¥Ð°Ð¼Ð¼Ð¾Ð½Ð´,Hammond", :latitude => "30.50436", :longitude => "-90.4612").save
City.new(:country_id => "233", :name => "Harvey", :aliases => "Kharvi,Ð¥Ð°ÑÐ²Ð¸,Harvey", :latitude => "29.90354", :longitude => "-90.07729").save
City.new(:country_id => "233", :name => "Houma", :aliases => ",Houma", :latitude => "29.59577", :longitude => "-90.71953").save
City.new(:country_id => "233", :name => "Kenner", :aliases => "Kenner,ÐÐµÐ½Ð½ÐµÑ,Kenner", :latitude => "29.99409", :longitude => "-90.24174").save
City.new(:country_id => "233", :name => "Lafayette", :aliases => "Lafajet,Lafayette,rafaietto,ÐÐ°ÑÐ°Ð¹ÐµÑ,ã©ãã¡ã¤ã¨ãã,Lafayette", :latitude => "30.22409", :longitude => "-92.01984").save
City.new(:country_id => "233", :name => "Lake Charles", :aliases => "Lake Charles,Lejk-Charl'z,reikucharuzu,ÐÐµÐ¹Ðº-Ð§Ð°ÑÐ»ÑÐ·,ã¬ã¤ã¯ãã£ã¼ã«ãº,Lake Charles", :latitude => "30.21309", :longitude => "-93.2044").save
City.new(:country_id => "233", :name => "Laplace", :aliases => "Laplas,ÐÐ°Ð¿Ð»Ð°Ñ,Laplace", :latitude => "30.06659", :longitude => "-90.48008").save
City.new(:country_id => "233", :name => "Marrero", :aliases => "Marrero,ÐÐ°ÑÑÐµÑÐ¾,Marrero", :latitude => "29.89937", :longitude => "-90.10035").save
City.new(:country_id => "233", :name => "Metairie", :aliases => "Metairie,Metairie", :latitude => "29.98409", :longitude => "-90.15285").save
City.new(:country_id => "233", :name => "Metairie Terrace", :aliases => ",Metairie Terrace", :latitude => "29.97854", :longitude => "-90.16396").save
City.new(:country_id => "233", :name => "Monroe", :aliases => "Monro,ÐÐ¾Ð½ÑÐ¾,Monroe", :latitude => "32.50931", :longitude => "-92.1193").save
City.new(:country_id => "233", :name => "Natchitoches", :aliases => ",Natchitoches", :latitude => "31.76072", :longitude => "-93.08627").save
City.new(:country_id => "233", :name => "New Iberia", :aliases => ",New Iberia", :latitude => "30.00354", :longitude => "-91.81873").save
City.new(:country_id => "233", :name => "New Orleans", :aliases => "Big Easy,Cene Orlean,La Nouvelle-Orleans,La Nouvelle-OrlÃ©ans,New Orleans,Nju Orleans,Nju Orlijns,Nov-Orleano,Nov-Orleans,Nova Aurelia,Nova Orleans,Nova Orleans - New Orleans,Nova OrleÃ¡ns - New Orleans,Novyj Orlean,Nowy Orlean,Nueva Orleans,The Big Easy,akhali orleani,new orleans louisiana,niyu orlens,nyuollieonseu,nyuorinzu,nyw awrlynz,oralensa parisa,xin ao er liang,ÃÄÐ½Ä ÐÑÐ»ÐµÐ°Ð½,ÐÑ ÐÑÐ»ÐµÐ°Ð½Ñ,ÐÐ¾Ð²ÑÐ¹ ÐÑÐ»ÐµÐ°Ð½,ÐÑ ÐÑÐ»Ð¸Ð¹Ð½Ñ,× ×× ×××¨××× ×¡,ÙÙÙ Ø£ÙØ±ÙÙÙØ²,à¦à¦°à¦²à§à¦¨à§à¦¸ à¦ªà¦¾à¦°à¦¿à¦¶,à®¨à®¿à®¯à¯ à®à®°à¯à®²à¯à®©à¯à®¸à¯,áá®ááá áá ááááá,ãã¥ã¼ãªã¼ãªã³ãº,æ°å¥¥å°è¯,ë´ì¬ë¦¬ì¸ì¤,New Orleans", :latitude => "29.95465", :longitude => "-90.07507").save
City.new(:country_id => "233", :name => "Opelousas", :aliases => ",Opelousas", :latitude => "30.53353", :longitude => "-92.08151").save
City.new(:country_id => "233", :name => "Ruston", :aliases => ",Ruston", :latitude => "32.52321", :longitude => "-92.63793").save
City.new(:country_id => "233", :name => "Shenandoah", :aliases => ",Shenandoah", :latitude => "30.4013", :longitude => "-91.00094").save
City.new(:country_id => "233", :name => "Shreveport", :aliases => "Shreveport,shuribupoto,Ð¨ÑÐµÐ²ÐµÐ¿Ð¾ÑÑ,ã·ã¥ãªã¼ããã¼ã,Shreveport", :latitude => "32.52515", :longitude => "-93.75018").save
City.new(:country_id => "233", :name => "Slidell", :aliases => ",Slidell", :latitude => "30.27519", :longitude => "-89.78117").save
City.new(:country_id => "233", :name => "Sulphur", :aliases => ",Sulphur", :latitude => "30.23659", :longitude => "-93.37738").save
City.new(:country_id => "233", :name => "Terrytown", :aliases => ",Terrytown", :latitude => "29.9102", :longitude => "-90.03257").save
City.new(:country_id => "233", :name => "Adelphi", :aliases => ",Adelphi", :latitude => "39.00317", :longitude => "-76.97192").save
City.new(:country_id => "233", :name => "Annapolis", :aliases => "Annapolis,an na bo li si,anaporisu,ÐÐ½Ð½Ð°Ð¿Ð¾Ð»Ð¸Ñ,ã¢ãããªã¹,å®é£æ³¢å©æ¯,Annapolis", :latitude => "38.97845", :longitude => "-76.49218").save
City.new(:country_id => "233", :name => "Arbutus", :aliases => ",Arbutus", :latitude => "39.25455", :longitude => "-76.69997").save
City.new(:country_id => "233", :name => "Arnold", :aliases => "Arnol'd,ÐÑÐ½Ð¾Ð»ÑÐ´,Arnold", :latitude => "39.03206", :longitude => "-76.50274").save
City.new(:country_id => "233", :name => "Aspen Hill", :aliases => ",Aspen Hill", :latitude => "39.07955", :longitude => "-77.07303").save
City.new(:country_id => "233", :name => "Baltimore", :aliases => "Baltimor,Baltimora,Baltimore,BaltimorÄ,ba er de mo,boltimo-eo,boruchimoa,bwltymwr,ÐÐ°Ð»ÑÐ¸Ð¼Ð¾Ñ,××××××××¨,áááá¢áááá á,ãã«ãã¢ã¢,å·´ç¾çæ©,ë³¼í°ëª¨ì´,Baltimore", :latitude => "39.29038", :longitude => "-76.61219").save
City.new(:country_id => "233", :name => "Ballenger Creek", :aliases => ",Ballenger Creek", :latitude => "39.3726", :longitude => "-77.43526").save
City.new(:country_id => "233", :name => "Beltsville", :aliases => ",Beltsville", :latitude => "39.03483", :longitude => "-76.90747").save
City.new(:country_id => "233", :name => "Bethesda", :aliases => ",Bethesda", :latitude => "38.98067", :longitude => "-77.10026").save
City.new(:country_id => "233", :name => "Bowie", :aliases => "Boui,ÐÐ¾ÑÐ¸,Bowie", :latitude => "39.00678", :longitude => "-76.77914").save
City.new(:country_id => "233", :name => "Camp Springs", :aliases => ",Camp Springs", :latitude => "38.804", :longitude => "-76.90664").save
City.new(:country_id => "233", :name => "Carney", :aliases => "Karni,ÐÐ°ÑÐ½Ð¸,Carney", :latitude => "39.39427", :longitude => "-76.52358").save
City.new(:country_id => "233", :name => "Catonsville", :aliases => ",Catonsville", :latitude => "39.27205", :longitude => "-76.73192").save
City.new(:country_id => "233", :name => "Chillum", :aliases => ",Chillum", :latitude => "38.96372", :longitude => "-76.99081").save
City.new(:country_id => "233", :name => "Clinton", :aliases => "Klinton,ÐÐ»Ð¸Ð½ÑÐ¾Ð½,Clinton", :latitude => "38.76511", :longitude => "-76.89831").save
City.new(:country_id => "233", :name => "Cockeysville", :aliases => ",Cockeysville", :latitude => "39.48122", :longitude => "-76.64386").save
City.new(:country_id => "233", :name => "Colesville", :aliases => ",Colesville", :latitude => "39.07566", :longitude => "-77.00192").save
City.new(:country_id => "233", :name => "College Park", :aliases => ",College Park", :latitude => "38.98067", :longitude => "-76.93692").save
City.new(:country_id => "233", :name => "Columbia", :aliases => "Columbia,Kolumbija,ÐÐ¾Ð»ÑÐ¼Ð±Ð¸Ñ,Columbia", :latitude => "39.24038", :longitude => "-76.83942").save
City.new(:country_id => "233", :name => "Crofton", :aliases => "Kroftona,ÐÑÐ¾ÑÑÐ¾Ð½Ð°,Crofton", :latitude => "39.00178", :longitude => "-76.68747").save
City.new(:country_id => "233", :name => "Cumberland", :aliases => "Kamberlend,ÐÐ°Ð¼Ð±ÐµÑÐ»ÐµÐ½Ð´,Cumberland", :latitude => "39.65287", :longitude => "-78.76252").save
City.new(:country_id => "233", :name => "Dundalk", :aliases => "Dandolk,Dundalk,ÐÐ°Ð½Ð´Ð¾Ð»Ðº,Dundalk", :latitude => "39.25066", :longitude => "-76.52052").save
City.new(:country_id => "233", :name => "East Riverdale", :aliases => ",East Riverdale", :latitude => "38.96206", :longitude => "-76.92192").save
City.new(:country_id => "233", :name => "Edgewood", :aliases => ",Edgewood", :latitude => "39.41872", :longitude => "-76.2944").save
City.new(:country_id => "233", :name => "Eldersburg", :aliases => ",Eldersburg", :latitude => "39.40371", :longitude => "-76.95026").save
City.new(:country_id => "233", :name => "Elkridge", :aliases => ",Elkridge", :latitude => "39.21261", :longitude => "-76.71358").save
City.new(:country_id => "233", :name => "Ellicott City", :aliases => "Ellicott City,Ellicott City", :latitude => "39.26733", :longitude => "-76.79831").save
City.new(:country_id => "233", :name => "Essex", :aliases => "Ehsseks,Ð­ÑÑÐµÐºÑ,Essex", :latitude => "39.30927", :longitude => "-76.47496").save
City.new(:country_id => "233", :name => "Fairland", :aliases => ",Fairland", :latitude => "39.07622", :longitude => "-76.95775").save
City.new(:country_id => "233", :name => "Ferndale", :aliases => ",Ferndale", :latitude => "39.18316", :longitude => "-76.64024").save
City.new(:country_id => "233", :name => "Fort Washington", :aliases => ",Fort Washington", :latitude => "38.70734", :longitude => "-77.02303").save
City.new(:country_id => "233", :name => "Frederick", :aliases => "Frederik,Ð¤ÑÐµÐ´ÐµÑÐ¸Ðº,Frederick", :latitude => "39.41427", :longitude => "-77.41054").save
City.new(:country_id => "233", :name => "Gaithersburg", :aliases => ",Gaithersburg", :latitude => "39.14344", :longitude => "-77.20137").save
City.new(:country_id => "233", :name => "Germantown", :aliases => ",Germantown", :latitude => "39.17316", :longitude => "-77.27165").save
City.new(:country_id => "233", :name => "Glen Burnie", :aliases => ",Glen Burnie", :latitude => "39.16261", :longitude => "-76.62469").save
City.new(:country_id => "233", :name => "Green Haven", :aliases => ",Green Haven", :latitude => "39.13955", :longitude => "-76.54774").save
City.new(:country_id => "233", :name => "Greenbelt", :aliases => "Grinbelte,ÐÑÐ¸Ð½Ð±ÐµÐ»ÑÐµ,Greenbelt", :latitude => "39.00455", :longitude => "-76.87553").save
City.new(:country_id => "233", :name => "Hagerstown", :aliases => ",Hagerstown", :latitude => "39.64176", :longitude => "-77.71999").save
City.new(:country_id => "233", :name => "Hillcrest Heights", :aliases => ",Hillcrest Heights", :latitude => "38.83289", :longitude => "-76.95942").save
City.new(:country_id => "233", :name => "Hyattsville", :aliases => ",Hyattsville", :latitude => "38.95594", :longitude => "-76.94553").save
City.new(:country_id => "233", :name => "Langley Park", :aliases => ",Langley Park", :latitude => "38.98872", :longitude => "-76.98136").save
City.new(:country_id => "233", :name => "Laurel", :aliases => ",Laurel", :latitude => "39.09928", :longitude => "-76.84831").save
City.new(:country_id => "233", :name => "Lochearn", :aliases => ",Lochearn", :latitude => "39.34066", :longitude => "-76.72219").save
City.new(:country_id => "233", :name => "Middle River", :aliases => ",Middle River", :latitude => "39.33427", :longitude => "-76.43941").save
City.new(:country_id => "233", :name => "Milford Mill", :aliases => ",Milford Mill", :latitude => "39.34788", :longitude => "-76.76997").save
City.new(:country_id => "233", :name => "Montgomery Village", :aliases => ",Montgomery Village", :latitude => "39.17677", :longitude => "-77.19526").save
City.new(:country_id => "233", :name => "North Bel Air", :aliases => ",North Bel Air", :latitude => "39.53983", :longitude => "-76.35496").save
City.new(:country_id => "233", :name => "North Bethesda", :aliases => ",North Bethesda", :latitude => "39.04455", :longitude => "-77.11887").save
City.new(:country_id => "233", :name => "North Laurel", :aliases => ",North Laurel", :latitude => "39.139", :longitude => "-76.87053").save
City.new(:country_id => "233", :name => "North Potomac", :aliases => ",North Potomac", :latitude => "39.08289", :longitude => "-77.26498").save
City.new(:country_id => "233", :name => "Odenton", :aliases => ",Odenton", :latitude => "39.084", :longitude => "-76.70025").save
City.new(:country_id => "233", :name => "Olney", :aliases => "Olni,ÐÐ»Ð½Ð¸,Olney", :latitude => "39.15316", :longitude => "-77.06692").save
City.new(:country_id => "233", :name => "Owings Mills", :aliases => ",Owings Mills", :latitude => "39.41955", :longitude => "-76.78025").save
City.new(:country_id => "233", :name => "Parkville", :aliases => ",Parkville", :latitude => "39.37733", :longitude => "-76.53969").save
City.new(:country_id => "233", :name => "Parole", :aliases => ",Parole", :latitude => "38.97956", :longitude => "-76.53052").save
City.new(:country_id => "233", :name => "Perry Hall", :aliases => ",Perry Hall", :latitude => "39.41261", :longitude => "-76.46357").save
City.new(:country_id => "233", :name => "Pikesville", :aliases => ",Pikesville", :latitude => "39.37427", :longitude => "-76.72247").save
City.new(:country_id => "233", :name => "Potomac", :aliases => "Potomak,ÐÐ¾ÑÐ¾Ð¼Ð°Ðº,Potomac", :latitude => "39.01817", :longitude => "-77.20859").save
City.new(:country_id => "233", :name => "Randallstown", :aliases => ",Randallstown", :latitude => "39.36733", :longitude => "-76.79525").save
City.new(:country_id => "233", :name => "Redland", :aliases => ",Redland", :latitude => "39.14539", :longitude => "-77.14415").save
City.new(:country_id => "233", :name => "Reisterstown", :aliases => ",Reisterstown", :latitude => "39.46955", :longitude => "-76.82942").save
City.new(:country_id => "233", :name => "Rockville", :aliases => "Rokvill,Ð Ð¾ÐºÐ²Ð¸Ð»Ð»,Rockville", :latitude => "39.084", :longitude => "-77.15276").save
City.new(:country_id => "233", :name => "Rosedale", :aliases => ",Rosedale", :latitude => "39.32011", :longitude => "-76.51552").save
City.new(:country_id => "233", :name => "Saint Charles", :aliases => ",Saint Charles", :latitude => "38.60317", :longitude => "-76.93858").save
City.new(:country_id => "233", :name => "Salisbury", :aliases => ",Salisbury", :latitude => "38.36067", :longitude => "-75.59937").save
City.new(:country_id => "233", :name => "Severn", :aliases => "Severn,Ð¡ÐµÐ²ÐµÑÐ½,Severn", :latitude => "39.13705", :longitude => "-76.6983").save
City.new(:country_id => "233", :name => "Severna Park", :aliases => ",Severna Park", :latitude => "39.07039", :longitude => "-76.54524").save
City.new(:country_id => "233", :name => "Silver Spring", :aliases => "Silver Spring,yin quan,é¶æ³,Silver Spring", :latitude => "38.99067", :longitude => "-77.02609").save
City.new(:country_id => "233", :name => "South Bel Air", :aliases => ",South Bel Air", :latitude => "39.53316", :longitude => "-76.33746").save
City.new(:country_id => "233", :name => "South Gate", :aliases => ",South Gate", :latitude => "39.129", :longitude => "-76.6258").save
City.new(:country_id => "233", :name => "South Laurel", :aliases => ",South Laurel", :latitude => "39.06983", :longitude => "-76.85025").save
City.new(:country_id => "233", :name => "Takoma Park", :aliases => ",Takoma Park", :latitude => "38.97789", :longitude => "-77.00748").save
City.new(:country_id => "233", :name => "Towson", :aliases => ",Towson", :latitude => "39.4015", :longitude => "-76.60191").save
City.new(:country_id => "233", :name => "Waldorf", :aliases => ",Waldorf", :latitude => "38.62456", :longitude => "-76.93914").save
City.new(:country_id => "233", :name => "West Elkridge", :aliases => ",West Elkridge", :latitude => "39.20705", :longitude => "-76.72692").save
City.new(:country_id => "233", :name => "Westminster", :aliases => ",Westminster", :latitude => "39.57538", :longitude => "-76.99581").save
City.new(:country_id => "233", :name => "White Oak", :aliases => ",White Oak", :latitude => "39.03983", :longitude => "-76.99303").save
City.new(:country_id => "233", :name => "Woodlawn", :aliases => ",Woodlawn", :latitude => "39.32288", :longitude => "-76.72803").save
City.new(:country_id => "233", :name => "Woodlawn", :aliases => ",Woodlawn", :latitude => "38.94956", :longitude => "-76.89136").save
City.new(:country_id => "233", :name => "Affton", :aliases => ",Affton", :latitude => "38.55061", :longitude => "-90.33317").save
City.new(:country_id => "233", :name => "Arnold", :aliases => "Arnol'd,ÐÑÐ½Ð¾Ð»ÑÐ´,Arnold", :latitude => "38.43283", :longitude => "-90.37762").save
City.new(:country_id => "233", :name => "Ballwin", :aliases => ",Ballwin", :latitude => "38.59505", :longitude => "-90.54623").save
City.new(:country_id => "233", :name => "Belton", :aliases => "Belton,ÐÐµÐ»ÑÐ¾Ð½,Belton", :latitude => "38.81195", :longitude => "-94.5319").save
City.new(:country_id => "233", :name => "Blue Springs", :aliases => ",Blue Springs", :latitude => "39.01695", :longitude => "-94.28161").save
City.new(:country_id => "233", :name => "Bridgeton", :aliases => ",Bridgeton", :latitude => "38.767", :longitude => "-90.41151").save
City.new(:country_id => "233", :name => "Cape Girardeau", :aliases => ",Cape Girardeau", :latitude => "37.30588", :longitude => "-89.51815").save
City.new(:country_id => "233", :name => "Chesterfield", :aliases => ",Chesterfield", :latitude => "38.66311", :longitude => "-90.57707").save
City.new(:country_id => "233", :name => "Clayton", :aliases => ",Clayton", :latitude => "38.64255", :longitude => "-90.32373").save
City.new(:country_id => "233", :name => "Columbia", :aliases => "Columbia,Kolumbija,koronbia,ÐÐ¾Ð»ÑÐ¼Ð±Ð¸Ñ,ã³ã­ã³ãã¢,Columbia", :latitude => "38.95171", :longitude => "-92.33407").save
City.new(:country_id => "233", :name => "Concord", :aliases => ",Concord", :latitude => "38.5245", :longitude => "-90.35734").save
City.new(:country_id => "233", :name => "Creve Coeur", :aliases => ",Creve Coeur", :latitude => "38.66089", :longitude => "-90.42262").save
City.new(:country_id => "233", :name => "East Independence", :aliases => ",East Independence", :latitude => "39.09556", :longitude => "-94.35523").save
City.new(:country_id => "233", :name => "Ferguson", :aliases => "Fergjuson,Ð¤ÐµÑÐ³ÑÑÐ¾Ð½,Ferguson", :latitude => "38.74422", :longitude => "-90.30539").save
City.new(:country_id => "233", :name => "Florissant", :aliases => ",Florissant", :latitude => "38.78922", :longitude => "-90.32261").save
City.new(:country_id => "233", :name => "Gladstone", :aliases => "Gladston,ÐÐ»Ð°Ð´ÑÑÐ¾Ð½,Gladstone", :latitude => "39.20389", :longitude => "-94.55468").save
City.new(:country_id => "233", :name => "Grandview", :aliases => ",Grandview", :latitude => "38.88584", :longitude => "-94.53301").save
City.new(:country_id => "233", :name => "Hannibal", :aliases => ",Hannibal", :latitude => "39.70838", :longitude => "-91.35848").save
City.new(:country_id => "233", :name => "Hazelwood", :aliases => ",Hazelwood", :latitude => "38.77144", :longitude => "-90.37095").save
City.new(:country_id => "233", :name => "Independence", :aliases => "Independence,du li cheng,indipendensu,ã¤ã³ãã£ãã³ãã³ã¹,ç¬ç«å,Independence", :latitude => "39.09112", :longitude => "-94.41551").save
City.new(:country_id => "233", :name => "Jefferson City", :aliases => "Dzeferson Siti,Dzhefferson-Siti,Jefferson City,jefasonshiti,jepeoseun si,ÐÐµÑÐµÑÑÐ¾Ð½ Ð¡Ð¸ÑÐ¸,ÐÐ¶ÐµÑÑÐµÑÑÐ¾Ð½-Ð¡Ð¸ÑÐ¸,ã¸ã§ãã¡ã¼ã½ã³ã·ãã£,ì í¼ì¨ ì,Jefferson City", :latitude => "38.5767", :longitude => "-92.17352").save
City.new(:country_id => "233", :name => "Joplin", :aliases => "Dzhoplin,ÐÐ¶Ð¾Ð¿Ð»Ð¸Ð½,Joplin", :latitude => "37.08423", :longitude => "-94.51328").save
City.new(:country_id => "233", :name => "Kansas City", :aliases => "Kansas City,Kansas City i Missouri,Kansasurbo,Kanzas Siti,Kanzas-Siti,kan sa si cheng,kanzasushiti,qnzs syty,ÐÐ°Ð½Ð·Ð°Ñ Ð¡Ð¸ÑÐ¸,ÐÐ°Ð½Ð·Ð°Ñ-Ð¡Ð¸ÑÐ¸,×§× ××¡ ×¡×××,ã«ã³ã¶ã¹ã·ãã£,å ªè©æ¯å,Kansas City", :latitude => "39.09973", :longitude => "-94.57857").save
City.new(:country_id => "233", :name => "Kirkwood", :aliases => "Kirkvuda,ÐÐ¸ÑÐºÐ²ÑÐ´Ð°,Kirkwood", :latitude => "38.58339", :longitude => "-90.40678").save
City.new(:country_id => "233", :name => "Lees Summit", :aliases => ",Lees Summit", :latitude => "38.91084", :longitude => "-94.38217").save
City.new(:country_id => "233", :name => "Lemay", :aliases => ",Lemay", :latitude => "38.53339", :longitude => "-90.27928").save
City.new(:country_id => "233", :name => "Liberty", :aliases => ",Liberty", :latitude => "39.24611", :longitude => "-94.41912").save
City.new(:country_id => "233", :name => "Manchester", :aliases => "Manchester,ÐÐ°Ð½ÑÐµÑÑÐµÑ,Manchester", :latitude => "38.597", :longitude => "-90.50929").save
City.new(:country_id => "233", :name => "Maryland Heights", :aliases => ",Maryland Heights", :latitude => "38.71311", :longitude => "-90.42984").save
City.new(:country_id => "233", :name => "Mehlville", :aliases => ",Mehlville", :latitude => "38.50839", :longitude => "-90.32289").save
City.new(:country_id => "233", :name => "O'Fallon", :aliases => ",O'Fallon", :latitude => "38.81061", :longitude => "-90.69985").save
City.new(:country_id => "233", :name => "Oakville", :aliases => ",Oakville", :latitude => "38.47005", :longitude => "-90.30456").save
City.new(:country_id => "233", :name => "Overland", :aliases => ",Overland", :latitude => "38.70116", :longitude => "-90.36234").save
City.new(:country_id => "233", :name => "Ozark", :aliases => ",Ozark", :latitude => "37.02089", :longitude => "-93.20602").save
City.new(:country_id => "233", :name => "Poplar Bluff", :aliases => ",Poplar Bluff", :latitude => "36.757", :longitude => "-90.39289").save
City.new(:country_id => "233", :name => "Raytown", :aliases => ",Raytown", :latitude => "39.00862", :longitude => "-94.46356").save
City.new(:country_id => "233", :name => "Rolla", :aliases => ",Rolla", :latitude => "37.95143", :longitude => "-91.77127").save
City.new(:country_id => "233", :name => "Saint Charles", :aliases => "Sent-Charl'z,Ð¡ÐµÐ½Ñ-Ð§Ð°ÑÐ»ÑÐ·,Saint Charles", :latitude => "38.78394", :longitude => "-90.48123").save
City.new(:country_id => "233", :name => "Saint Joseph", :aliases => "Saint Joseph,Sent-Dzhozef,St. Joseph,Ð¡ÐµÐ½Ñ-ÐÐ¶Ð¾Ð·ÐµÑ,Saint Joseph", :latitude => "39.76861", :longitude => "-94.84663").save
City.new(:country_id => "233", :name => "Saint Louis", :aliases => "Saint Louis,San Luis,Sankta-Luizo,Sejnt Luis,Sent-Luis,St Louis,St. Louis,seinteulu-iseu,sentoruisu,sheng lu yi si,Ð¡ÐµÐ¹Ð½Ñ ÐÑÐ¸Ñ,Ð¡ÐµÐ½Ñ-ÐÑÐ¸Ñ,Ð¡ÐµÐ½Ñ-ÐÑÑÑ,×¡× × ×××××¡,ã»ã³ãã«ã¤ã¹,å£è·¯ææ¯,ì¸ì¸í¸ë£¨ì´ì¤,Saint Louis", :latitude => "38.62727", :longitude => "-90.19789").save
City.new(:country_id => "233", :name => "Saint Peters", :aliases => "Sankt-Peterbu,Ð¡Ð°Ð½ÐºÑ-ÐÐµÑÐµÑÐ±Ñ,Saint Peters", :latitude => "38.80033", :longitude => "-90.62651").save
City.new(:country_id => "233", :name => "Sedalia", :aliases => ",Sedalia", :latitude => "38.70446", :longitude => "-93.22826").save
City.new(:country_id => "233", :name => "Sikeston", :aliases => ",Sikeston", :latitude => "36.87672", :longitude => "-89.58786").save
City.new(:country_id => "233", :name => "Spanish Lake", :aliases => ",Spanish Lake", :latitude => "38.78783", :longitude => "-90.21594").save
City.new(:country_id => "233", :name => "Springfield", :aliases => "Springfield,Springfild,supuringufirudo,Ð¡Ð¿ÑÐ¸Ð½Ð³ÑÐ¸Ð»Ð´,ã¹ããªã³ã°ãã£ã¼ã«ã,Springfield", :latitude => "37.21533", :longitude => "-93.29824").save
City.new(:country_id => "233", :name => "University City", :aliases => ",University City", :latitude => "38.65588", :longitude => "-90.30928").save
City.new(:country_id => "233", :name => "Warrensburg", :aliases => ",Warrensburg", :latitude => "38.76279", :longitude => "-93.73605").save
City.new(:country_id => "233", :name => "Webster Groves", :aliases => ",Webster Groves", :latitude => "38.59255", :longitude => "-90.35734").save
City.new(:country_id => "233", :name => "Wentzville", :aliases => ",Wentzville", :latitude => "38.81144", :longitude => "-90.85291").save
City.new(:country_id => "233", :name => "Wildwood", :aliases => ",Wildwood", :latitude => "38.58283", :longitude => "-90.6629").save
City.new(:country_id => "233", :name => "Biloxi", :aliases => "Biloksi,Biloxi,ÐÐ¸Ð»Ð¾ÐºÑÐ¸,Biloxi", :latitude => "30.39603", :longitude => "-88.88531").save
City.new(:country_id => "233", :name => "Brandon", :aliases => "Brehndon,ÐÑÑÐ½Ð´Ð¾Ð½,Brandon", :latitude => "32.2732", :longitude => "-89.98592").save
City.new(:country_id => "233", :name => "Clarksdale", :aliases => ",Clarksdale", :latitude => "34.20011", :longitude => "-90.57093").save
City.new(:country_id => "233", :name => "Clinton", :aliases => "Klinton,ÐÐ»Ð¸Ð½ÑÐ¾Ð½,Clinton", :latitude => "32.34153", :longitude => "-90.32176").save
City.new(:country_id => "233", :name => "Columbus", :aliases => "Kolumbus,ÐÐ¾Ð»ÑÐ¼Ð±ÑÑ,Columbus", :latitude => "33.49567", :longitude => "-88.42726").save
City.new(:country_id => "233", :name => "Gautier", :aliases => "Got'e,ÐÐ¾ÑÑÐµ,Gautier", :latitude => "30.38576", :longitude => "-88.61169").save
City.new(:country_id => "233", :name => "Greenville", :aliases => "Grinvill,ÐÑÐ¸Ð½Ð²Ð¸Ð»Ð»,Greenville", :latitude => "33.41012", :longitude => "-91.06177").save
City.new(:country_id => "233", :name => "Greenwood", :aliases => ",Greenwood", :latitude => "33.51623", :longitude => "-90.17953").save
City.new(:country_id => "233", :name => "Gulfport", :aliases => "Galfporta,Gulfport,ÐÐ°Ð»ÑÐ¿Ð¾ÑÑÐ°,Gulfport", :latitude => "30.36742", :longitude => "-89.09282").save
City.new(:country_id => "233", :name => "Hattiesburg", :aliases => ",Hattiesburg", :latitude => "31.32712", :longitude => "-89.29034").save
City.new(:country_id => "233", :name => "Horn Lake", :aliases => ",Horn Lake", :latitude => "34.95537", :longitude => "-90.03481").save
City.new(:country_id => "233", :name => "Jackson", :aliases => "Dzhaksun,Jackson,jakswn,jakuson,ÐÐ¶Ð°ÐºÑÑÐ½,Ø¬Ø§ÙØ³ÙÙ,ã¸ã£ã¯ã½ã³,Jackson", :latitude => "32.29876", :longitude => "-90.18481").save
City.new(:country_id => "233", :name => "Laurel", :aliases => ",Laurel", :latitude => "31.69405", :longitude => "-89.13061").save
City.new(:country_id => "233", :name => "Long Beach", :aliases => "Long-Bich,ÐÐ¾Ð½Ð³-ÐÐ¸Ñ,Long Beach", :latitude => "30.35048", :longitude => "-89.15282").save
City.new(:country_id => "233", :name => "Madison", :aliases => "Madison,ÐÐ°Ð´Ð¸ÑÐ¾Ð½,Madison", :latitude => "32.46181", :longitude => "-90.11536").save
City.new(:country_id => "233", :name => "Meridian", :aliases => "Meridian,ÐÐµÑÐ¸Ð´Ð¸Ð°Ð½,Meridian", :latitude => "32.36431", :longitude => "-88.70366").save
City.new(:country_id => "233", :name => "Natchez", :aliases => ",Natchez", :latitude => "31.56044", :longitude => "-91.40317").save
City.new(:country_id => "233", :name => "Ocean Springs", :aliases => ",Ocean Springs", :latitude => "30.41131", :longitude => "-88.82781").save
City.new(:country_id => "233", :name => "Olive Branch", :aliases => ",Olive Branch", :latitude => "34.96176", :longitude => "-89.82953").save
City.new(:country_id => "233", :name => "Pascagoula", :aliases => "Paskagula,ÐÐ°ÑÐºÐ°Ð³ÑÐ»Ð°,Pascagoula", :latitude => "30.36576", :longitude => "-88.55613").save
City.new(:country_id => "233", :name => "Pearl", :aliases => ",Pearl", :latitude => "32.27459", :longitude => "-90.13203").save
City.new(:country_id => "233", :name => "Ridgeland", :aliases => ",Ridgeland", :latitude => "32.42848", :longitude => "-90.13231").save
City.new(:country_id => "233", :name => "Southaven", :aliases => ",Southaven", :latitude => "34.98898", :longitude => "-90.01259").save
City.new(:country_id => "233", :name => "Starkville", :aliases => ",Starkville", :latitude => "33.4504", :longitude => "-88.81839").save
City.new(:country_id => "233", :name => "Tupelo", :aliases => "Tjupelo,Tupelo,Ð¢ÑÐ¿ÐµÐ»Ð¾,Tupelo", :latitude => "34.25761", :longitude => "-88.70339").save
City.new(:country_id => "233", :name => "Vicksburg", :aliases => ",Vicksburg", :latitude => "32.35265", :longitude => "-90.87788").save
City.new(:country_id => "233", :name => "West Gulfport", :aliases => ",West Gulfport", :latitude => "30.40409", :longitude => "-89.0942").save
City.new(:country_id => "233", :name => "Albemarle", :aliases => ",Albemarle", :latitude => "35.35014", :longitude => "-80.20006").save
City.new(:country_id => "233", :name => "Apex", :aliases => "Apeks,ÐÐ¿ÐµÐºÑ,Apex", :latitude => "35.73265", :longitude => "-78.85029").save
City.new(:country_id => "233", :name => "Asheboro", :aliases => ",Asheboro", :latitude => "35.70791", :longitude => "-79.81364").save
City.new(:country_id => "233", :name => "Asheville", :aliases => "Asheville,Ehshvil',Ð­ÑÐ²Ð¸Ð»Ñ,Asheville", :latitude => "35.60095", :longitude => "-82.55402").save
City.new(:country_id => "233", :name => "Burlington", :aliases => "Berlington,ÐÐµÑÐ»Ð¸Ð½Ð³ÑÐ¾Ð½,Burlington", :latitude => "36.09569", :longitude => "-79.4378").save
City.new(:country_id => "233", :name => "Carrboro", :aliases => ",Carrboro", :latitude => "35.91014", :longitude => "-79.07529").save
City.new(:country_id => "233", :name => "Cary", :aliases => "Kehri,ÐÑÑÐ¸,Cary", :latitude => "35.79154", :longitude => "-78.78112").save
City.new(:country_id => "233", :name => "Chapel Hill", :aliases => ",Chapel Hill", :latitude => "35.9132", :longitude => "-79.05584").save
City.new(:country_id => "233", :name => "Charlotte", :aliases => "Charlotte,Sharl't,Sharlot,sharotto,syallos,tsharlwt,Ð¨Ð°ÑÐ»Ð¾Ñ,Ð¨Ð°ÑÐ»ÑÑ,×©××¨×××,ØªØ´Ø§Ø±ÙÙØª,ã·ã£ã¼ã­ãã,ì¬ë¡¯,Charlotte", :latitude => "35.22709", :longitude => "-80.84313").save
City.new(:country_id => "233", :name => "Clemmons", :aliases => ",Clemmons", :latitude => "36.02153", :longitude => "-80.382").save
City.new(:country_id => "233", :name => "Concord", :aliases => "Konkord,ÐÐ¾Ð½ÐºÐ¾ÑÐ´,Concord", :latitude => "35.40875", :longitude => "-80.57951").save
City.new(:country_id => "233", :name => "Cornelius", :aliases => "Kornelius,ÐÐ¾ÑÐ½ÐµÐ»Ð¸ÑÑ,Cornelius", :latitude => "35.4868", :longitude => "-80.86007").save
City.new(:country_id => "233", :name => "Durham", :aliases => "Darem,Durham,daramu,ÐÐ°ÑÐµÐ¼,ãã¼ã©ã ,Durham", :latitude => "35.99403", :longitude => "-78.89862").save
City.new(:country_id => "233", :name => "Eden", :aliases => ",Eden", :latitude => "36.48847", :longitude => "-79.7667").save
City.new(:country_id => "233", :name => "Elizabeth City", :aliases => ",Elizabeth City", :latitude => "36.2946", :longitude => "-76.25105").save
City.new(:country_id => "233", :name => "Fayetteville", :aliases => "Fayetteville,Fayetteville", :latitude => "35.05266", :longitude => "-78.87836").save
City.new(:country_id => "233", :name => "Garner", :aliases => "Garner,ÐÐ°ÑÐ½ÐµÑ,Garner", :latitude => "35.71126", :longitude => "-78.61417").save
City.new(:country_id => "233", :name => "Gastonia", :aliases => ",Gastonia", :latitude => "35.26208", :longitude => "-81.1873").save
City.new(:country_id => "233", :name => "Goldsboro", :aliases => ",Goldsboro", :latitude => "35.38488", :longitude => "-77.99277").save
City.new(:country_id => "233", :name => "Greensboro", :aliases => "Greensboro,Grinsboro,ÐÑÐ¸Ð½ÑÐ±Ð¾ÑÐ¾,Greensboro", :latitude => "36.07264", :longitude => "-79.79198").save
City.new(:country_id => "233", :name => "Greenville", :aliases => "Grinvill,ÐÑÐ¸Ð½Ð²Ð¸Ð»Ð»,Greenville", :latitude => "35.61266", :longitude => "-77.36635").save
City.new(:country_id => "233", :name => "Havelock", :aliases => ",Havelock", :latitude => "34.87905", :longitude => "-76.90133").save
City.new(:country_id => "233", :name => "Henderson", :aliases => "Khenderson,Ð¥ÐµÐ½Ð´ÐµÑÑÐ¾Ð½,Henderson", :latitude => "36.32959", :longitude => "-78.39916").save
City.new(:country_id => "233", :name => "Hickory", :aliases => ",Hickory", :latitude => "35.73319", :longitude => "-81.3412").save
City.new(:country_id => "233", :name => "High Point", :aliases => ",High Point", :latitude => "35.95569", :longitude => "-80.00532").save
City.new(:country_id => "233", :name => "Huntersville", :aliases => ",Huntersville", :latitude => "35.41069", :longitude => "-80.84285").save
City.new(:country_id => "233", :name => "Indian Trail", :aliases => ",Indian Trail", :latitude => "35.07681", :longitude => "-80.66924").save
City.new(:country_id => "233", :name => "Jacksonville", :aliases => "Dzheksonvill,ÐÐ¶ÐµÐºÑÐ¾Ð½Ð²Ð¸Ð»Ð»,Jacksonville", :latitude => "34.75405", :longitude => "-77.43024").save
City.new(:country_id => "233", :name => "Kannapolis", :aliases => ",Kannapolis", :latitude => "35.48736", :longitude => "-80.62173").save
City.new(:country_id => "233", :name => "Kernersville", :aliases => ",Kernersville", :latitude => "36.11986", :longitude => "-80.07365").save
City.new(:country_id => "233", :name => "Kinston", :aliases => ",Kinston", :latitude => "35.26266", :longitude => "-77.58164").save
City.new(:country_id => "233", :name => "Laurinburg", :aliases => ",Laurinburg", :latitude => "34.77405", :longitude => "-79.46282").save
City.new(:country_id => "233", :name => "Lenoir", :aliases => ",Lenoir", :latitude => "35.91402", :longitude => "-81.53898").save
City.new(:country_id => "233", :name => "Lexington", :aliases => "Leksington,ÐÐµÐºÑÐ¸Ð½Ð³ÑÐ¾Ð½,Lexington", :latitude => "35.82403", :longitude => "-80.25338").save
City.new(:country_id => "233", :name => "Lumberton", :aliases => ",Lumberton", :latitude => "34.61822", :longitude => "-79.00864").save
City.new(:country_id => "233", :name => "Matthews", :aliases => ",Matthews", :latitude => "35.11681", :longitude => "-80.72368").save
City.new(:country_id => "233", :name => "Mint Hill", :aliases => ",Mint Hill", :latitude => "35.17959", :longitude => "-80.64729").save
City.new(:country_id => "233", :name => "Monroe", :aliases => "Monro,ÐÐ¾Ð½ÑÐ¾,Monroe", :latitude => "34.98543", :longitude => "-80.54951").save
City.new(:country_id => "233", :name => "Mooresville", :aliases => ",Mooresville", :latitude => "35.58486", :longitude => "-80.81007").save
City.new(:country_id => "233", :name => "Morganton", :aliases => ",Morganton", :latitude => "35.74541", :longitude => "-81.68482").save
City.new(:country_id => "233", :name => "New Bern", :aliases => "N'ju-Bern,ÐÑÑ-ÐÐµÑÐ½,New Bern", :latitude => "35.10849", :longitude => "-77.04411").save
City.new(:country_id => "233", :name => "Raleigh", :aliases => "Raleigh,Roli,ra li,rori,Ð Ð¾Ð»Ð¸,×¨×××,à¸£à¸²à¸¥à¸µ,ã­ã¼ãªã¼,Raleigh", :latitude => "35.7721", :longitude => "-78.63861").save
City.new(:country_id => "233", :name => "Roanoke Rapids", :aliases => ",Roanoke Rapids", :latitude => "36.46154", :longitude => "-77.65415").save
City.new(:country_id => "233", :name => "Rocky Mount", :aliases => ",Rocky Mount", :latitude => "35.93821", :longitude => "-77.79053").save
City.new(:country_id => "233", :name => "Salisbury", :aliases => ",Salisbury", :latitude => "35.67097", :longitude => "-80.47423").save
City.new(:country_id => "233", :name => "Sanford", :aliases => ",Sanford", :latitude => "35.47988", :longitude => "-79.1803").save
City.new(:country_id => "233", :name => "Shelby", :aliases => ",Shelby", :latitude => "35.29235", :longitude => "-81.53565").save
City.new(:country_id => "233", :name => "Statesville", :aliases => ",Statesville", :latitude => "35.78264", :longitude => "-80.8873").save
City.new(:country_id => "233", :name => "Thomasville", :aliases => ",Thomasville", :latitude => "35.88264", :longitude => "-80.08199").save
City.new(:country_id => "233", :name => "Wake Forest", :aliases => ",Wake Forest", :latitude => "35.97987", :longitude => "-78.50972").save
City.new(:country_id => "233", :name => "West Raleigh", :aliases => ",West Raleigh", :latitude => "35.78682", :longitude => "-78.66389").save
City.new(:country_id => "233", :name => "Wilmington", :aliases => "Uilmington,Wilmington,u~iruminton,Ð£Ð¸Ð»Ð¼Ð¸Ð½Ð³ÑÐ¾Ð½,ã¦ã£ã«ãã³ãã³,Wilmington", :latitude => "34.22573", :longitude => "-77.94471").save
City.new(:country_id => "233", :name => "Wilson", :aliases => "Uilson,Ð£Ð¸Ð»ÑÐ¾Ð½,Wilson", :latitude => "35.72127", :longitude => "-77.91554").save
City.new(:country_id => "233", :name => "Winston-Salem", :aliases => "Vinston-Salem,Winston Salem,Winston-Salem,ÐÐ¸Ð½ÑÑÐ¾Ð½-Ð¡Ð°Ð»ÐµÐ¼,ã¦ã£ã³ã¹ãã³ã»ã»ã¼ã©ã ,Winston-Salem", :latitude => "36.09986", :longitude => "-80.24422").save
City.new(:country_id => "233", :name => "Atlantic City", :aliases => "Atlantic City,Atlantik Siti,Atlantik-Siti,atorantikkushiti,ÐÑÐ»Ð°Ð½ÑÐ¸Ðº Ð¡Ð¸ÑÐ¸,ÐÑÐ»Ð°Ð½ÑÐ¸Ðº-Ð¡Ð¸ÑÐ¸,××××× ×××§ ×¡×××,ã¢ãã©ã³ãã£ãã¯ã·ãã£,Atlantic City", :latitude => "39.36428", :longitude => "-74.42293").save
City.new(:country_id => "233", :name => "Bridgeton", :aliases => ",Bridgeton", :latitude => "39.42734", :longitude => "-75.23408").save
City.new(:country_id => "233", :name => "Camden", :aliases => "Camden,kamuden,ã«ã ãã³,Camden", :latitude => "39.92595", :longitude => "-75.11962").save
City.new(:country_id => "233", :name => "Cherry Hill", :aliases => ",Cherry Hill", :latitude => "39.93484", :longitude => "-75.03073").save
City.new(:country_id => "233", :name => "Glassboro", :aliases => ",Glassboro", :latitude => "39.70289", :longitude => "-75.11184").save
City.new(:country_id => "233", :name => "Lindenwold", :aliases => ",Lindenwold", :latitude => "39.82428", :longitude => "-74.99767").save
City.new(:country_id => "233", :name => "Maple Shade", :aliases => ",Maple Shade", :latitude => "39.95261", :longitude => "-74.99239").save
City.new(:country_id => "233", :name => "Millville", :aliases => ",Millville", :latitude => "39.40206", :longitude => "-75.03934").save
City.new(:country_id => "233", :name => "Ocean Acres", :aliases => ",Ocean Acres", :latitude => "39.74345", :longitude => "-74.28098").save
City.new(:country_id => "233", :name => "Ocean City", :aliases => ",Ocean City", :latitude => "39.27762", :longitude => "-74.5746").save
City.new(:country_id => "233", :name => "Pennsauken", :aliases => ",Pennsauken", :latitude => "39.95622", :longitude => "-75.05795").save
City.new(:country_id => "233", :name => "Pleasantville", :aliases => ",Pleasantville", :latitude => "39.38984", :longitude => "-74.52404").save
City.new(:country_id => "233", :name => "South Vineland", :aliases => ",South Vineland", :latitude => "39.44595", :longitude => "-75.02879").save
City.new(:country_id => "233", :name => "Toms River", :aliases => "Toms River,Toms River", :latitude => "39.95373", :longitude => "-74.19792").save
City.new(:country_id => "233", :name => "Vineland", :aliases => ",Vineland", :latitude => "39.48623", :longitude => "-75.02573").save
City.new(:country_id => "233", :name => "Athens", :aliases => "Afiny,ÐÑÐ¸Ð½Ñ,Athens", :latitude => "39.32924", :longitude => "-82.10126").save
City.new(:country_id => "233", :name => "Beavercreek", :aliases => "Beaver Creek,Beavercreek", :latitude => "39.70923", :longitude => "-84.06327").save
City.new(:country_id => "233", :name => "Centerville", :aliases => ",Centerville", :latitude => "39.62839", :longitude => "-84.15938").save
City.new(:country_id => "233", :name => "Cincinnati", :aliases => "Cincinnati,Sinsinati,shinshinati,synsynty,xin xin na di,Ð¡Ð¸Ð½ÑÐ¸Ð½Ð°ÑÐ¸,Ð¦Ð¸Ð½ÑÐ¸Ð½Ð½Ð°ÑÐ¸,×¡×× ×¡×× ××,ã·ã³ã·ããã£,è¾è¾é£å ¤,Cincinnati", :latitude => "39.162", :longitude => "-84.45689").save
City.new(:country_id => "233", :name => "Columbus", :aliases => "Columbus,Columbus i Ohio,Kolumbus,ge lun bu,kolleombeoseu,koronbasu,qwlwmbws,ÐÐ¾Ð»ÑÐ¼Ð±ÑÑ,×§×××××××¡,Ú©ÙÙÙØ¨Ø³Ø Ø§ÙÛØ§Ø¦ÛÙ,ã³ã­ã³ãã¹,å¥ä¼¦å¸,ì½ë¼ë²ì¤,Columbus", :latitude => "39.96118", :longitude => "-82.99879").save
City.new(:country_id => "233", :name => "Dayton", :aliases => "Dayton,Dejton,dai dun,ÐÐµÐ¹ÑÐ¾Ð½,ÐÐµÑÑÐ¾Ð½,ä»£é¡¿,Dayton", :latitude => "39.75895", :longitude => "-84.19161").save
City.new(:country_id => "233", :name => "Fairborn", :aliases => ",Fairborn", :latitude => "39.82089", :longitude => "-84.01938").save
City.new(:country_id => "233", :name => "Fairfield", :aliases => "Feurfild,Ð¤ÐµÑÑÑÐ¸Ð»Ð´,Fairfield", :latitude => "39.34589", :longitude => "-84.5605").save
City.new(:country_id => "233", :name => "Forest Park", :aliases => ",Forest Park", :latitude => "39.29034", :longitude => "-84.50411").save
City.new(:country_id => "233", :name => "Grove City", :aliases => ",Grove City", :latitude => "39.88145", :longitude => "-83.09296").save
City.new(:country_id => "233", :name => "Hamilton", :aliases => "Gamil'ton,Hamilton,ÐÐ°Ð¼Ð¸Ð»ÑÑÐ¾Ð½,Hamilton", :latitude => "39.3995", :longitude => "-84.56134").save
City.new(:country_id => "233", :name => "Huber Heights", :aliases => ",Huber Heights", :latitude => "39.84395", :longitude => "-84.12466").save
City.new(:country_id => "233", :name => "Kettering", :aliases => "Kettering,ÐÐµÑÑÐµÑÐ¸Ð½Ð³,Kettering", :latitude => "39.6895", :longitude => "-84.16883").save
City.new(:country_id => "233", :name => "Lancaster", :aliases => "Lankaster,ÐÐ°Ð½ÐºÐ°ÑÑÐµÑ,Lancaster", :latitude => "39.71368", :longitude => "-82.59933").save
City.new(:country_id => "233", :name => "Lebanon", :aliases => ",Lebanon", :latitude => "39.43534", :longitude => "-84.20299").save
City.new(:country_id => "233", :name => "Mason", :aliases => "Mejson,ÐÐµÐ¹ÑÐ¾Ð½,Mason", :latitude => "39.36006", :longitude => "-84.30994").save
City.new(:country_id => "233", :name => "Miamisburg", :aliases => ",Miamisburg", :latitude => "39.64284", :longitude => "-84.28661").save
City.new(:country_id => "233", :name => "Middletown", :aliases => ",Middletown", :latitude => "39.51506", :longitude => "-84.39828").save
City.new(:country_id => "233", :name => "Norwood", :aliases => ",Norwood", :latitude => "39.15561", :longitude => "-84.45966").save
City.new(:country_id => "233", :name => "Oxford", :aliases => "Oksford,ÐÐºÑÑÐ¾ÑÐ´,Oxford", :latitude => "39.507", :longitude => "-84.74523").save
City.new(:country_id => "233", :name => "Pickerington", :aliases => ",Pickerington", :latitude => "39.88423", :longitude => "-82.7535").save
City.new(:country_id => "233", :name => "Portsmouth", :aliases => "Portsmut,ÐÐ¾ÑÑÑÐ¼ÑÑ,Portsmouth", :latitude => "38.73174", :longitude => "-82.99767").save
City.new(:country_id => "233", :name => "Reynoldsburg", :aliases => ",Reynoldsburg", :latitude => "39.95479", :longitude => "-82.81212").save
City.new(:country_id => "233", :name => "Riverside", :aliases => "Riversajd,Ð Ð¸Ð²ÐµÑÑÐ°Ð¹Ð´,Riverside", :latitude => "39.77978", :longitude => "-84.1241").save
City.new(:country_id => "233", :name => "Springboro", :aliases => ",Springboro", :latitude => "39.55228", :longitude => "-84.23327").save
City.new(:country_id => "233", :name => "Springfield", :aliases => "Springfield,Springfild,Ð¡Ð¿ÑÐ¸Ð½Ð³ÑÐ¸Ð»Ð´,Springfield", :latitude => "39.92423", :longitude => "-83.80882").save
City.new(:country_id => "233", :name => "Trotwood", :aliases => "Trotvud,Ð¢ÑÐ¾ÑÐ²ÑÐ´,Trotwood", :latitude => "39.79728", :longitude => "-84.31133").save
City.new(:country_id => "233", :name => "Upper Arlington", :aliases => ",Upper Arlington", :latitude => "39.99451", :longitude => "-83.06241").save
City.new(:country_id => "233", :name => "Whitehall", :aliases => ",Whitehall", :latitude => "39.96673", :longitude => "-82.88546").save
City.new(:country_id => "233", :name => "Xenia", :aliases => "Ksenija,ÐÑÐµÐ½Ð¸Ñ,Xenia", :latitude => "39.68478", :longitude => "-83.92965").save
City.new(:country_id => "233", :name => "Zanesville", :aliases => ",Zanesville", :latitude => "39.94035", :longitude => "-82.01319").save
City.new(:country_id => "233", :name => "Ada", :aliases => ",Ada", :latitude => "34.77453", :longitude => "-96.67834").save
City.new(:country_id => "233", :name => "Altus", :aliases => ",Altus", :latitude => "34.63813", :longitude => "-99.33398").save
City.new(:country_id => "233", :name => "Ardmore", :aliases => ",Ardmore", :latitude => "34.17426", :longitude => "-97.14363").save
City.new(:country_id => "233", :name => "Bartlesville", :aliases => ",Bartlesville", :latitude => "36.74731", :longitude => "-95.98082").save
City.new(:country_id => "233", :name => "Bethany", :aliases => ",Bethany", :latitude => "35.51867", :longitude => "-97.63226").save
City.new(:country_id => "233", :name => "Bixby", :aliases => ",Bixby", :latitude => "35.94204", :longitude => "-95.88332").save
City.new(:country_id => "233", :name => "Broken Arrow", :aliases => "Broken Arrow,Broken Arrow", :latitude => "36.0526", :longitude => "-95.79082").save
City.new(:country_id => "233", :name => "Chickasha", :aliases => ",Chickasha", :latitude => "35.05256", :longitude => "-97.93643").save
City.new(:country_id => "233", :name => "Claremore", :aliases => ",Claremore", :latitude => "36.3126", :longitude => "-95.61609").save
City.new(:country_id => "233", :name => "Del City", :aliases => ",Del City", :latitude => "35.44201", :longitude => "-97.44087").save
City.new(:country_id => "233", :name => "Duncan", :aliases => "Dunkan,ÐÑÐ½ÐºÐ°Ð½,Duncan", :latitude => "34.5023", :longitude => "-97.95781").save
City.new(:country_id => "233", :name => "Durant", :aliases => ",Durant", :latitude => "33.99399", :longitude => "-96.37082").save
City.new(:country_id => "233", :name => "Edmond", :aliases => "Ehdmon,Ð­Ð´Ð¼Ð¾Ð½,Edmond", :latitude => "35.65283", :longitude => "-97.4781").save
City.new(:country_id => "233", :name => "El Reno", :aliases => ",El Reno", :latitude => "35.53227", :longitude => "-97.95505").save
City.new(:country_id => "233", :name => "Enid", :aliases => "Ehnid,Ð­Ð½Ð¸Ð´,Enid", :latitude => "36.39559", :longitude => "-97.87839").save
City.new(:country_id => "233", :name => "Lawton", :aliases => "Lawton,Louton,lao dun,ÐÐ¾ÑÑÐ¾Ð½,å³é¡¿,Lawton", :latitude => "34.60869", :longitude => "-98.39033").save
City.new(:country_id => "233", :name => "McAlester", :aliases => ",McAlester", :latitude => "34.93343", :longitude => "-95.76971").save
City.new(:country_id => "233", :name => "Midwest City", :aliases => ",Midwest City", :latitude => "35.44951", :longitude => "-97.3967").save
City.new(:country_id => "233", :name => "Moore", :aliases => "Mur,ÐÑÑ,Moore", :latitude => "35.33951", :longitude => "-97.4867").save
City.new(:country_id => "233", :name => "Muskogee", :aliases => "Maskogi,ÐÐ°ÑÐºÐ¾Ð³Ð¸,Muskogee", :latitude => "35.74788", :longitude => "-95.36969").save
City.new(:country_id => "233", :name => "Mustang", :aliases => ",Mustang", :latitude => "35.38423", :longitude => "-97.72449").save
City.new(:country_id => "233", :name => "Norman", :aliases => "Norman,ÐÐ¾ÑÐ¼Ð°Ð½,Norman", :latitude => "35.22257", :longitude => "-97.43948").save
City.new(:country_id => "233", :name => "Oklahoma City", :aliases => "Oklahoma City,Oklakhoma Siti,ao ke la he ma shi,awklahwma syty,okurahomashiti,ÐÐºÐ»Ð°ÑÐ¾Ð¼Ð° Ð¡Ð¸ÑÐ¸,×××§××××× ×¡×××,Ø£ÙÙÙØ§ÙÙÙØ§ Ø³ÙØªÙ,ãªã¯ã©ããã·ãã£,å¥§åæè·é¦¬å¸,Oklahoma City", :latitude => "35.46756", :longitude => "-97.51643").save
City.new(:country_id => "233", :name => "Owasso", :aliases => ",Owasso", :latitude => "36.26954", :longitude => "-95.85471").save
City.new(:country_id => "233", :name => "Ponca City", :aliases => ",Ponca City", :latitude => "36.70698", :longitude => "-97.08559").save
City.new(:country_id => "233", :name => "Sand Springs", :aliases => ",Sand Springs", :latitude => "36.13981", :longitude => "-96.10889").save
City.new(:country_id => "233", :name => "Sapulpa", :aliases => ",Sapulpa", :latitude => "35.9987", :longitude => "-96.11417").save
City.new(:country_id => "233", :name => "Shawnee", :aliases => ",Shawnee", :latitude => "35.32729", :longitude => "-96.9253").save
City.new(:country_id => "233", :name => "Stillwater", :aliases => ",Stillwater", :latitude => "36.11561", :longitude => "-97.05837").save
City.new(:country_id => "233", :name => "Tahlequah", :aliases => ",Tahlequah", :latitude => "35.91537", :longitude => "-94.96996").save
City.new(:country_id => "233", :name => "Tulsa", :aliases => "T'lsa,Tulsa,tarusa,tu er sa,Ð¢ÑÐ»ÑÐ°,ã¿ã«ãµ,åç¾è©,Tulsa", :latitude => "36.15398", :longitude => "-95.99278").save
City.new(:country_id => "233", :name => "Yukon", :aliases => "Jukon,Ð®ÐºÐ¾Ð½,Yukon", :latitude => "35.50672", :longitude => "-97.76254").save
City.new(:country_id => "233", :name => "Chambersburg", :aliases => ",Chambersburg", :latitude => "39.93759", :longitude => "-77.6611").save
City.new(:country_id => "233", :name => "Chester", :aliases => "Chester,Ð§ÐµÑÑÐµÑ,Chester", :latitude => "39.84956", :longitude => "-75.35575").save
City.new(:country_id => "233", :name => "Drexel Hill", :aliases => ",Drexel Hill", :latitude => "39.94706", :longitude => "-75.29213").save
City.new(:country_id => "233", :name => "Hanover", :aliases => ",Hanover", :latitude => "39.80066", :longitude => "-76.98304").save
City.new(:country_id => "233", :name => "Philadelphia", :aliases => "Filadel'fi,Filadel'fija,Filadelfia,Filadelfie,Filadelfija,Filadelfio,FiladÃ¨lfia,FiladÃ©lfia,Filidelfi,Philadelpheia,Philadelphia,Philadelphie,fei cheng,firaderufia,fyladlfya,piladelpia,pilladelpia,pyldlpyh,Î¦Î¹Î»Î±Î´Î­Î»ÏÎµÎ¹Î±,Ð¤Ð¸Ð»Ð°Ð´ÐµÐ»ÑÐ¸Ñ,Ð¤Ð¸Ð»Ð°Ð´ÐµÐ»ÑÐ¸ÑÐ°,Ð¤Ð¸Ð»Ð°Ð´ÐµÐ»ÑÑÐ¸,Ð¤Ð¸Ð»Ð°Ð´ÐµÐ»ÑÑÐ¸Ñ,Ð¤ÑÐ»Ð°Ð´ÐµÐ»ÑÑÑÑ,×¤×××××¤××,ÙÙÙØ§Ø¯ÙÙÙØ§,á¤ááááááá¤áá,ãã£ã©ãã«ãã£ã¢,è²»å,íë¼ë¸í¼ì,Philadelphia", :latitude => "39.95234", :longitude => "-75.16379").save
City.new(:country_id => "233", :name => "Springfield", :aliases => "Springfild,Ð¡Ð¿ÑÐ¸Ð½Ð³ÑÐ¸Ð»Ð´,Springfield", :latitude => "39.93067", :longitude => "-75.32019").save
City.new(:country_id => "233", :name => "West Chester", :aliases => ",West Chester", :latitude => "39.96066", :longitude => "-75.60549").save
City.new(:country_id => "233", :name => "York", :aliases => "Jork,ÐÐ¾ÑÐº,York", :latitude => "39.9626", :longitude => "-76.72774").save
City.new(:country_id => "233", :name => "Aiken", :aliases => "Ajken,ÐÐ¹ÐºÐµÐ½,Aiken", :latitude => "33.56042", :longitude => "-81.71955").save
City.new(:country_id => "233", :name => "Anderson", :aliases => "Anderson,ÐÐ½Ð´ÐµÑÑÐ¾Ð½,Anderson", :latitude => "34.50344", :longitude => "-82.65013").save
City.new(:country_id => "233", :name => "Charleston", :aliases => "Carolopolis,Charleston,Charlston,cha er si dun,chalseuteon,Ð§Ð°ÑÐ»ÑÑÐ¾Ð½,æ¥å°æ¯é¡¿,ì°°ì¤í´,Charleston", :latitude => "32.77657", :longitude => "-79.93092").save
City.new(:country_id => "233", :name => "Columbia", :aliases => "Columbia,Kolumbija,koronbia,kwlmbya, jnwby kyrwlyna,ÐÐ¾Ð»ÑÐ¼Ð±Ð¸Ñ,Ú©ÙÙÙØ¨ÛØ§Ø Ø¬ÙÙØ¨Û Ú©ÛØ±ÙÙÛÙØ§,ã³ã­ã³ãã¢,Columbia", :latitude => "34.00071", :longitude => "-81.03481").save
City.new(:country_id => "233", :name => "Florence", :aliases => "Florencija,Ð¤Ð»Ð¾ÑÐµÐ½ÑÐ¸Ñ,Florence", :latitude => "34.19543", :longitude => "-79.76256").save
City.new(:country_id => "233", :name => "Goose Creek", :aliases => ",Goose Creek", :latitude => "32.98101", :longitude => "-80.03259").save
City.new(:country_id => "233", :name => "Greenville", :aliases => "Grinvill,ÐÑÐ¸Ð½Ð²Ð¸Ð»Ð»,Greenville", :latitude => "34.85262", :longitude => "-82.39401").save
City.new(:country_id => "233", :name => "Greenwood", :aliases => ",Greenwood", :latitude => "34.1954", :longitude => "-82.16179").save
City.new(:country_id => "233", :name => "Greer", :aliases => "Grir,ÐÑÐ¸Ñ,Greer", :latitude => "34.93873", :longitude => "-82.22706").save
City.new(:country_id => "233", :name => "Hilton Head Island", :aliases => "Hilton Head,Hilton Head Island,Hilton Head Island", :latitude => "32.21632", :longitude => "-80.75261").save
City.new(:country_id => "233", :name => "Mauldin", :aliases => ",Mauldin", :latitude => "34.77873", :longitude => "-82.31012").save
City.new(:country_id => "233", :name => "Mount Pleasant", :aliases => ",Mount Pleasant", :latitude => "32.79407", :longitude => "-79.86259").save
City.new(:country_id => "233", :name => "Myrtle Beach", :aliases => ",Myrtle Beach", :latitude => "33.68906", :longitude => "-78.88669").save
City.new(:country_id => "233", :name => "North Augusta", :aliases => ",North Augusta", :latitude => "33.5018", :longitude => "-81.96512").save
City.new(:country_id => "233", :name => "North Charleston", :aliases => "North Charleston,North Charleston", :latitude => "32.88856", :longitude => "-80.00751").save
City.new(:country_id => "233", :name => "Rock Hill", :aliases => ",Rock Hill", :latitude => "34.92487", :longitude => "-81.02508").save
City.new(:country_id => "233", :name => "Saint Andrews", :aliases => ",Saint Andrews", :latitude => "34.04543", :longitude => "-81.12926").save
City.new(:country_id => "233", :name => "Seven Oaks", :aliases => ",Seven Oaks", :latitude => "34.04876", :longitude => "-81.14648").save
City.new(:country_id => "233", :name => "Socastee", :aliases => ",Socastee", :latitude => "33.6835", :longitude => "-78.99837").save
City.new(:country_id => "233", :name => "Spartanburg", :aliases => ",Spartanburg", :latitude => "34.94957", :longitude => "-81.93205").save
City.new(:country_id => "233", :name => "Saint Andrews", :aliases => ",Saint Andrews", :latitude => "34.04876", :longitude => "-81.10315").save
City.new(:country_id => "233", :name => "Summerville", :aliases => ",Summerville", :latitude => "33.0185", :longitude => "-80.17565").save
City.new(:country_id => "233", :name => "Taylors", :aliases => ",Taylors", :latitude => "34.92039", :longitude => "-82.29623").save
City.new(:country_id => "233", :name => "Wade Hampton", :aliases => ",Wade Hampton", :latitude => "34.90373", :longitude => "-82.33317").save
City.new(:country_id => "233", :name => "Bartlett", :aliases => "Bartlett,ÐÐ°ÑÑÐ»ÐµÑÑ,Bartlett", :latitude => "35.20453", :longitude => "-89.87398").save
City.new(:country_id => "233", :name => "Brentwood", :aliases => ",Brentwood", :latitude => "36.03312", :longitude => "-86.78278").save
City.new(:country_id => "233", :name => "Brentwood Estates", :aliases => ",Brentwood Estates", :latitude => "36.02506", :longitude => "-86.77917").save
City.new(:country_id => "233", :name => "Bristol", :aliases => ",Bristol", :latitude => "36.59511", :longitude => "-82.18874").save
City.new(:country_id => "233", :name => "Chattanooga", :aliases => "Chattanooga,Chattanuga,chatanuga,Ð§Ð°ÑÑÐ°Ð½ÑÐ³Ð°,ãã£ã¿ãã¼ã¬,Chattanooga", :latitude => "35.04563", :longitude => "-85.30968").save
City.new(:country_id => "233", :name => "Clarksville", :aliases => "Clarksville,Clarksville", :latitude => "36.52977", :longitude => "-87.35945").save
City.new(:country_id => "233", :name => "Cleveland", :aliases => "Klivlend,ÐÐ»Ð¸Ð²Ð»ÐµÐ½Ð´,Cleveland", :latitude => "35.15952", :longitude => "-84.87661").save
City.new(:country_id => "233", :name => "Collierville", :aliases => ",Collierville", :latitude => "35.04204", :longitude => "-89.66453").save
City.new(:country_id => "233", :name => "Columbia", :aliases => "Kolumbija,ÐÐ¾Ð»ÑÐ¼Ð±Ð¸Ñ,Columbia", :latitude => "35.61507", :longitude => "-87.03528").save
City.new(:country_id => "233", :name => "Cookeville", :aliases => ",Cookeville", :latitude => "36.16284", :longitude => "-85.50164").save
City.new(:country_id => "233", :name => "Dyersburg", :aliases => ",Dyersburg", :latitude => "36.03452", :longitude => "-89.38563").save
City.new(:country_id => "233", :name => "East Brainerd", :aliases => ",East Brainerd", :latitude => "34.99591", :longitude => "-85.15023").save
City.new(:country_id => "233", :name => "East Chattanooga", :aliases => ",East Chattanooga", :latitude => "35.06535", :longitude => "-85.24912").save
City.new(:country_id => "233", :name => "East Ridge", :aliases => ",East Ridge", :latitude => "35.01424", :longitude => "-85.2519").save
City.new(:country_id => "233", :name => "Farragut", :aliases => ",Farragut", :latitude => "35.88452", :longitude => "-84.15353").save
City.new(:country_id => "233", :name => "Franklin", :aliases => "Franklin,Ð¤ÑÐ°Ð½ÐºÐ»Ð¸Ð½,Franklin", :latitude => "35.92506", :longitude => "-86.86889").save
City.new(:country_id => "233", :name => "Gallatin", :aliases => ",Gallatin", :latitude => "36.38838", :longitude => "-86.44666").save
City.new(:country_id => "233", :name => "Germantown", :aliases => ",Germantown", :latitude => "35.08676", :longitude => "-89.81009").save
City.new(:country_id => "233", :name => "Greeneville", :aliases => ",Greeneville", :latitude => "36.16316", :longitude => "-82.83099").save
City.new(:country_id => "233", :name => "Hendersonville", :aliases => ",Hendersonville", :latitude => "36.30477", :longitude => "-86.62").save
City.new(:country_id => "233", :name => "Jackson", :aliases => "Dzhekson,Jackson,jakuson,ÐÐ¶ÐµÐºÑÐ¾Ð½,ã¸ã£ã¯ã½ã³,Jackson", :latitude => "35.61452", :longitude => "-88.81395").save
City.new(:country_id => "233", :name => "Johnson City", :aliases => ",Johnson City", :latitude => "36.31344", :longitude => "-82.35347").save
City.new(:country_id => "233", :name => "Kingsport", :aliases => ",Kingsport", :latitude => "36.54843", :longitude => "-82.56182").save
City.new(:country_id => "233", :name => "Knoxville", :aliases => "Knoxville,Noksvill,nokkusubiru,nwqswwyl,ÐÐ¾ÐºÑÐ²Ð¸Ð»Ð»,× ××§×¡××××,ããã¯ã¹ãã«,Knoxville", :latitude => "35.96064", :longitude => "-83.92074").save
City.new(:country_id => "233", :name => "La Vergne", :aliases => ",La Vergne", :latitude => "36.01562", :longitude => "-86.58194").save
City.new(:country_id => "233", :name => "Lebanon", :aliases => ",Lebanon", :latitude => "36.20811", :longitude => "-86.2911").save
City.new(:country_id => "233", :name => "Maryville", :aliases => ",Maryville", :latitude => "35.75647", :longitude => "-83.97046").save
City.new(:country_id => "233", :name => "Memphis", :aliases => "Memfis,Memphis,Memphis Tennesiae,Menfis,mempisi,menfisu,mmpys,mymfys,ÐÐµÐ¼ÑÐ¸Ñ,×××¤××¡,ÙÙÙÙÙØ³,áááá¤áá¡á,ã¡ã³ãã£ã¹,Memphis", :latitude => "35.14953", :longitude => "-90.04898").save
City.new(:country_id => "233", :name => "Morristown", :aliases => ",Morristown", :latitude => "36.21398", :longitude => "-83.29489").save
City.new(:country_id => "233", :name => "Mount Juliet", :aliases => ",Mount Juliet", :latitude => "36.20006", :longitude => "-86.51861").save
City.new(:country_id => "233", :name => "Murfreesboro", :aliases => "Merfrisboro,Murfreesboro,ÐÐµÑÑÑÐ¸ÑÐ±Ð¾ÑÐ¾,Murfreesboro", :latitude => "35.84562", :longitude => "-86.39027").save
City.new(:country_id => "233", :name => "Nashville", :aliases => "Nasburgum,Nashvil,Nashvill,Nashville,Nehshvill,na shen wei er,naesyubil,nashfyl,nasshubiru,neshvili,nshwyl,ÐÐ°ÑÐ²Ð¸Ð»,ÐÐ°ÑÐ²Ð¸Ð»Ð»,ÐÑÑÐ²Ð¸Ð»Ð»,× ××©××××,ÙØ§Ø´ÙÙÙ,ÙØ´ÙÛÙ,ááá¨áááá,ããã·ã¥ãã«,çº³ä»ç»´å°,ë´ìë¹,Nashville", :latitude => "36.16589", :longitude => "-86.78444").save
City.new(:country_id => "233", :name => "New South Memphis", :aliases => ",New South Memphis", :latitude => "35.08676", :longitude => "-90.05676").save
City.new(:country_id => "233", :name => "Oak Ridge", :aliases => ",Oak Ridge", :latitude => "36.01036", :longitude => "-84.26964").save
City.new(:country_id => "233", :name => "Sevierville", :aliases => ",Sevierville", :latitude => "35.86815", :longitude => "-83.56184").save
City.new(:country_id => "233", :name => "Shelbyville", :aliases => ",Shelbyville", :latitude => "35.48341", :longitude => "-86.46027").save
City.new(:country_id => "233", :name => "Smyrna", :aliases => "Smirna,Ð¡Ð¼Ð¸ÑÐ½Ð°,Smyrna", :latitude => "35.98284", :longitude => "-86.5186").save
City.new(:country_id => "233", :name => "Spring Hill", :aliases => "Spring-Khill,Ð¡Ð¿ÑÐ¸Ð½Ð³-Ð¥Ð¸Ð»Ð»,Spring Hill", :latitude => "35.75118", :longitude => "-86.93").save
City.new(:country_id => "233", :name => "Springfield", :aliases => "Springfild,Ð¡Ð¿ÑÐ¸Ð½Ð³ÑÐ¸Ð»Ð´,Springfield", :latitude => "36.50921", :longitude => "-86.885").save
City.new(:country_id => "233", :name => "Tullahoma", :aliases => ",Tullahoma", :latitude => "35.36202", :longitude => "-86.20943").save
City.new(:country_id => "233", :name => "Abilene", :aliases => "Abilene,Abilin,a bi lin,ÐÐ±Ð¸Ð»Ð¸Ð½,é¿æ¯æ,Abilene", :latitude => "32.44874", :longitude => "-99.73314").save
City.new(:country_id => "233", :name => "Alamo", :aliases => ",Alamo", :latitude => "26.18369", :longitude => "-98.12306").save
City.new(:country_id => "233", :name => "Aldine", :aliases => ",Aldine", :latitude => "29.93244", :longitude => "-95.38021").save
City.new(:country_id => "233", :name => "Alice", :aliases => ",Alice", :latitude => "27.75225", :longitude => "-98.06972").save
City.new(:country_id => "233", :name => "Allen", :aliases => "Allen,ÐÐ»Ð»ÐµÐ½,Allen", :latitude => "33.10317", :longitude => "-96.67055").save
City.new(:country_id => "233", :name => "Alvin", :aliases => "Ehlvin,Ð­Ð»Ð²Ð¸Ð½,Alvin", :latitude => "29.42385", :longitude => "-95.2441").save
City.new(:country_id => "233", :name => "Angleton", :aliases => ",Angleton", :latitude => "29.16941", :longitude => "-95.43188").save
City.new(:country_id => "233", :name => "Arlington", :aliases => "Arlingt'n,Arlington,arinton,ÐÑÐ»Ð¸Ð½Ð³ÑÑÐ½,ã¢ã¼ãªã³ãã³,Arlington", :latitude => "32.73569", :longitude => "-97.10807").save
City.new(:country_id => "233", :name => "Atascocita", :aliases => ",Atascocita", :latitude => "29.99883", :longitude => "-95.1766").save
City.new(:country_id => "233", :name => "Austin", :aliases => "Austin,Austino,AÅ­stino,Ostin,ao si ting,austina,osutin,ÎÏÏÎ¹Î½,ÐÑÑÐ¸Ð½,×××¡×××,à¤à¤¸à¥à¤à¤¿à¤¨,ãªã¼ã¹ãã£ã³,å¥§æ¯æ±,Austin", :latitude => "30.26715", :longitude => "-97.74306").save
City.new(:country_id => "233", :name => "Balch Springs", :aliases => ",Balch Springs", :latitude => "32.72874", :longitude => "-96.62277").save
City.new(:country_id => "233", :name => "Baytown", :aliases => "Baytown,Baytown", :latitude => "29.7355", :longitude => "-94.97743").save
City.new(:country_id => "233", :name => "Beaumont", :aliases => "Beaumont,Beaumont", :latitude => "30.08605", :longitude => "-94.10185").save
City.new(:country_id => "233", :name => "Bedford", :aliases => "Bedford,ÐÐµÐ´ÑÐ¾ÑÐ´,Bedford", :latitude => "32.84402", :longitude => "-97.14307").save
City.new(:country_id => "233", :name => "Bellaire", :aliases => ",Bellaire", :latitude => "29.70579", :longitude => "-95.45883").save
City.new(:country_id => "233", :name => "Belton", :aliases => "Belton,ÐÐµÐ»ÑÐ¾Ð½,Belton", :latitude => "31.05601", :longitude => "-97.46445").save
City.new(:country_id => "233", :name => "Benbrook", :aliases => ",Benbrook", :latitude => "32.67319", :longitude => "-97.46058").save
City.new(:country_id => "233", :name => "Brownsville", :aliases => "Brownsville,Brownsville", :latitude => "25.90175", :longitude => "-97.49748").save
City.new(:country_id => "233", :name => "Brownwood", :aliases => ",Brownwood", :latitude => "31.70932", :longitude => "-98.99116").save
City.new(:country_id => "233", :name => "Brushy Creek", :aliases => ",Brushy Creek", :latitude => "30.51353", :longitude => "-97.73973").save
City.new(:country_id => "233", :name => "Bryan", :aliases => "Bryan,Bryan", :latitude => "30.67436", :longitude => "-96.36996").save
City.new(:country_id => "233", :name => "Burleson", :aliases => "Burlesone,ÐÑÑÐ»ÐµÑÐ¾Ð½Ðµ,Burleson", :latitude => "32.54208", :longitude => "-97.32085").save
City.new(:country_id => "233", :name => "Canyon Lake", :aliases => ",Canyon Lake", :latitude => "29.87522", :longitude => "-98.26251").save
City.new(:country_id => "233", :name => "Carrollton", :aliases => "Carrollton,Carrollton", :latitude => "32.95373", :longitude => "-96.89028").save
City.new(:country_id => "233", :name => "Cedar Hill", :aliases => ",Cedar Hill", :latitude => "32.58847", :longitude => "-96.95612").save
City.new(:country_id => "233", :name => "Cedar Park", :aliases => ",Cedar Park", :latitude => "30.5052", :longitude => "-97.82029").save
City.new(:country_id => "233", :name => "Channelview", :aliases => ",Channelview", :latitude => "29.77606", :longitude => "-95.11465").save
City.new(:country_id => "233", :name => "Cleburne", :aliases => ",Cleburne", :latitude => "32.34764", :longitude => "-97.38668").save
City.new(:country_id => "233", :name => "Cloverleaf", :aliases => ",Cloverleaf", :latitude => "29.77828", :longitude => "-95.17188").save
City.new(:country_id => "233", :name => "College Station", :aliases => "College Station,College Station", :latitude => "30.62798", :longitude => "-96.33441").save
City.new(:country_id => "233", :name => "Colleyville", :aliases => ",Colleyville", :latitude => "32.88096", :longitude => "-97.15501").save
City.new(:country_id => "233", :name => "Conroe", :aliases => ",Conroe", :latitude => "30.31188", :longitude => "-95.45605").save
City.new(:country_id => "233", :name => "Coppell", :aliases => "Koppell,ÐÐ¾Ð¿Ð¿ÐµÐ»Ð»,Coppell", :latitude => "32.95457", :longitude => "-97.01501").save
City.new(:country_id => "233", :name => "Copperas Cove", :aliases => ",Copperas Cove", :latitude => "31.12406", :longitude => "-97.90308").save
City.new(:country_id => "233", :name => "Corinth", :aliases => ",Corinth", :latitude => "33.15401", :longitude => "-97.06473").save
City.new(:country_id => "233", :name => "Corpus Christi", :aliases => "Corpus Christi,Korpus-Kristi,kopasukurisuti,ÐÐ¾ÑÐ¿ÑÑ-ÐÑÐ¸ÑÑÐ¸,ã³ã¼ãã¹ã¯ãªã¹ãã£,Corpus Christi", :latitude => "27.80058", :longitude => "-97.39638").save
City.new(:country_id => "233", :name => "Corsicana", :aliases => ",Corsicana", :latitude => "32.09543", :longitude => "-96.46887").save
City.new(:country_id => "233", :name => "Dallas", :aliases => "Dalas,Dallas,Ntalas,da la si,dalas,dalasa,dallas,darasu,ÎÏÎ¬Î»Î±Ï,ÐÐ°Ð»Ð°Ñ,ÐÐ°Ð»Ð»Ð°Ñ,×××××¡,Ø¯Ø§ÙØ§Ø³,Ø¯Ø§ÙÙØ§Ø³,à¤¡à¤¾à¤²à¤¾à¤¸,ãã©ã¹,éææ¯,Dallas", :latitude => "32.78306", :longitude => "-96.80667").save
City.new(:country_id => "233", :name => "DeSoto", :aliases => "Soto,Ð¡Ð¾ÑÐ¾,DeSoto", :latitude => "32.58986", :longitude => "-96.85695").save
City.new(:country_id => "233", :name => "Deer Park", :aliases => ",Deer Park", :latitude => "29.70523", :longitude => "-95.12382").save
City.new(:country_id => "233", :name => "Denison", :aliases => "Denison,ÐÐµÐ½Ð¸ÑÐ¾Ð½,Denison", :latitude => "33.75566", :longitude => "-96.53666").save
City.new(:country_id => "233", :name => "Denton", :aliases => "Denton,Dentono,dentana,à¦¡à§à¦¨à§à¦à¦¨,Denton", :latitude => "33.21484", :longitude => "-97.13307").save
City.new(:country_id => "233", :name => "Dickinson", :aliases => ",Dickinson", :latitude => "29.46079", :longitude => "-95.05132").save
City.new(:country_id => "233", :name => "Donna", :aliases => ",Donna", :latitude => "26.17035", :longitude => "-98.05195").save
City.new(:country_id => "233", :name => "Duncanville", :aliases => ",Duncanville", :latitude => "32.6518", :longitude => "-96.90834").save
City.new(:country_id => "233", :name => "Edinburg", :aliases => "Ehdinburg,Ð­Ð´Ð¸Ð½Ð±ÑÑÐ³,Edinburg", :latitude => "26.30174", :longitude => "-98.16334").save
City.new(:country_id => "233", :name => "Ennis", :aliases => ",Ennis", :latitude => "32.32931", :longitude => "-96.62527").save
City.new(:country_id => "233", :name => "Euless", :aliases => ",Euless", :latitude => "32.83707", :longitude => "-97.08195").save
City.new(:country_id => "233", :name => "Farmers Branch", :aliases => ",Farmers Branch", :latitude => "32.92651", :longitude => "-96.89612").save
City.new(:country_id => "233", :name => "Flower Mound", :aliases => "Flower Mound,Flower Mound", :latitude => "33.01457", :longitude => "-97.09696").save
City.new(:country_id => "233", :name => "Fort Worth", :aliases => "Fort Uurt,Fort Worth,Fort-Uehrt,fotowasu,pwrt wwrt',wo si bao,Ð¤Ð¾ÑÑ Ð£ÑÑÑ,Ð¤Ð¾ÑÑ-Ð£ÑÑÑ,×¤××¨× ×××¨×ª',ãã©ã¼ãã¯ã¼ã¹,æ²æ¯å ¡,Fort Worth", :latitude => "32.72541", :longitude => "-97.32085").save
City.new(:country_id => "233", :name => "Friendswood", :aliases => ",Friendswood", :latitude => "29.5294", :longitude => "-95.20104").save
City.new(:country_id => "233", :name => "Frisco", :aliases => "Frisco,Frisco", :latitude => "33.15067", :longitude => "-96.82361").save
City.new(:country_id => "233", :name => "Gainesville", :aliases => ",Gainesville", :latitude => "33.62594", :longitude => "-97.13335").save
City.new(:country_id => "233", :name => "Galveston", :aliases => "Galveston,garubesuton,ÐÐ°Ð»Ð²ÐµÑÑÐ¾Ð½,ã¬ã«ãã¹ãã³,Galveston", :latitude => "29.30135", :longitude => "-94.7977").save
City.new(:country_id => "233", :name => "Garland", :aliases => "Garland,Girljanda,ÐÐ¸ÑÐ»ÑÐ½Ð´Ð°,Garland", :latitude => "32.91262", :longitude => "-96.63888").save
City.new(:country_id => "233", :name => "Gatesville", :aliases => ",Gatesville", :latitude => "31.43516", :longitude => "-97.74391").save
City.new(:country_id => "233", :name => "Georgetown", :aliases => ",Georgetown", :latitude => "30.63269", :longitude => "-97.67723").save
City.new(:country_id => "233", :name => "Grand Prairie", :aliases => "Grand Prairie,Grand Prairie", :latitude => "32.74596", :longitude => "-96.99778").save
City.new(:country_id => "233", :name => "Grapevine", :aliases => ",Grapevine", :latitude => "32.93429", :longitude => "-97.07807").save
City.new(:country_id => "233", :name => "Greenville", :aliases => "Grinvill,ÐÑÐ¸Ð½Ð²Ð¸Ð»Ð»,Greenville", :latitude => "33.13845", :longitude => "-96.11081").save
City.new(:country_id => "233", :name => "Groves", :aliases => ",Groves", :latitude => "29.94827", :longitude => "-93.91712").save
City.new(:country_id => "233", :name => "Haltom City", :aliases => ",Haltom City", :latitude => "32.79957", :longitude => "-97.26918").save
City.new(:country_id => "233", :name => "Harker Heights", :aliases => ",Harker Heights", :latitude => "31.08351", :longitude => "-97.65974").save
City.new(:country_id => "233", :name => "Harlingen", :aliases => "Harlingen,Kharlingen,Ð¥Ð°ÑÐ»Ð¸Ð½Ð³ÐµÐ½,Harlingen", :latitude => "26.19063", :longitude => "-97.6961").save
City.new(:country_id => "233", :name => "Highland Village", :aliases => ",Highland Village", :latitude => "33.09179", :longitude => "-97.04668").save
City.new(:country_id => "233", :name => "Houston", :aliases => "Chiouston,Houston,Hustonia,Kh'juston,Khjust'n,hiws tan,hyustana,hyusuton,xiu si dun,ywstwn,Î§Î¹Î¿ÏÏÏÎ¿Î½,Ð¥ÑÑÑÑÐ¾Ð½,Ð¥ÑÑÑÑÐ½,×××¡×××,Ú¾ÙÛØ³ØªÙÙ,à¤¹à¥à¤¯à¥à¤¸à¥à¤à¤¨,à¸®à¸´à¸§à¸ªà¸à¸±à¸,ãã¥ã¼ã¹ãã³,ä¼æ¯æ¦,Houston", :latitude => "29.76328", :longitude => "-95.36327").save
City.new(:country_id => "233", :name => "Huntsville", :aliases => "Khantsvill,Ð¥Ð°Ð½ÑÑÐ²Ð¸Ð»Ð»,Huntsville", :latitude => "30.72353", :longitude => "-95.55078").save
City.new(:country_id => "233", :name => "Hurst", :aliases => "Kherst,Ð¥ÐµÑÑÑ,Hurst", :latitude => "32.82346", :longitude => "-97.17057").save
City.new(:country_id => "233", :name => "Irving", :aliases => "Irving,ÐÑÐ²Ð¸Ð½Ð³,Irving", :latitude => "32.81402", :longitude => "-96.94889").save
City.new(:country_id => "233", :name => "Jollyville", :aliases => ",Jollyville", :latitude => "30.4427", :longitude => "-97.77501").save
City.new(:country_id => "233", :name => "Keller", :aliases => "Keller,ÐÐµÐ»Ð»ÐµÑ,Keller", :latitude => "32.93457", :longitude => "-97.25168").save
City.new(:country_id => "233", :name => "Kerrville", :aliases => ",Kerrville", :latitude => "30.04743", :longitude => "-99.14032").save
City.new(:country_id => "233", :name => "Killeen", :aliases => "Killeen,Killeen", :latitude => "31.11712", :longitude => "-97.7278").save
City.new(:country_id => "233", :name => "Kingsville", :aliases => ",Kingsville", :latitude => "27.51587", :longitude => "-97.85611").save
City.new(:country_id => "233", :name => "Kyle", :aliases => ",Kyle", :latitude => "29.99835", :longitude => "-97.87153").save
City.new(:country_id => "233", :name => "La Porte", :aliases => ",La Porte", :latitude => "29.66578", :longitude => "-95.01937").save
City.new(:country_id => "233", :name => "Lake Jackson", :aliases => ",Lake Jackson", :latitude => "29.03386", :longitude => "-95.43439").save
City.new(:country_id => "233", :name => "Lancaster", :aliases => "Lankaster,ÐÐ°Ð½ÐºÐ°ÑÑÐµÑ,Lancaster", :latitude => "32.59208", :longitude => "-96.75611").save
City.new(:country_id => "233", :name => "Laredo", :aliases => "Laredo,ÐÐ°ÑÐµÐ´Ð¾,Laredo", :latitude => "27.50641", :longitude => "-99.50754").save
City.new(:country_id => "233", :name => "League City", :aliases => "League City,League City", :latitude => "29.50745", :longitude => "-95.09493").save
City.new(:country_id => "233", :name => "Leander", :aliases => ",Leander", :latitude => "30.57881", :longitude => "-97.85307").save
City.new(:country_id => "233", :name => "Lewisville", :aliases => "Lewisville,Lewisville", :latitude => "33.04623", :longitude => "-96.99417").save
City.new(:country_id => "233", :name => "Little Elm", :aliases => ",Little Elm", :latitude => "33.16262", :longitude => "-96.93751").save
City.new(:country_id => "233", :name => "Longview", :aliases => "Longview,Longview", :latitude => "32.5007", :longitude => "-94.74049").save
City.new(:country_id => "233", :name => "Lufkin", :aliases => ",Lufkin", :latitude => "31.33824", :longitude => "-94.7291").save
City.new(:country_id => "233", :name => "Mansfield", :aliases => "Mehnsfild,ÐÑÐ½ÑÑÐ¸Ð»Ð´,Mansfield", :latitude => "32.56319", :longitude => "-97.14168").save
City.new(:country_id => "233", :name => "Marshall", :aliases => "Marshall,ma xie er,marshal,masharu,ÐÐ°ÑÑÐ°Ð»Ð»,ÙØ§Ø±Ø´Ø§Ù,ãã¼ã·ã£ã«,é©¬æ­å°,Marshall", :latitude => "32.54487", :longitude => "-94.36742").save
City.new(:country_id => "233", :name => "McAllen", :aliases => "McAllen,McAllen", :latitude => "26.20341", :longitude => "-98.23001").save
City.new(:country_id => "233", :name => "McKinney", :aliases => "McKinney,McKinney", :latitude => "33.19762", :longitude => "-96.61527").save
City.new(:country_id => "233", :name => "Mesquite", :aliases => "Mesquite,Mesquite", :latitude => "32.7668", :longitude => "-96.59916").save
City.new(:country_id => "233", :name => "Mineral Wells", :aliases => ",Mineral Wells", :latitude => "32.80846", :longitude => "-98.11282").save
City.new(:country_id => "233", :name => "Mission", :aliases => "Missija,Mission,ÐÐ¸ÑÑÐ¸Ñ,Mission", :latitude => "26.21591", :longitude => "-98.32529").save
City.new(:country_id => "233", :name => "Mission Bend", :aliases => ",Mission Bend", :latitude => "29.69384", :longitude => "-95.66495").save
City.new(:country_id => "233", :name => "Missouri City", :aliases => "Missouri City,Missouri City", :latitude => "29.61857", :longitude => "-95.53772").save
City.new(:country_id => "233", :name => "Nacogdoches", :aliases => ",Nacogdoches", :latitude => "31.60351", :longitude => "-94.65549").save
City.new(:country_id => "233", :name => "Nederland", :aliases => ",Nederland", :latitude => "29.97438", :longitude => "-93.9924").save
City.new(:country_id => "233", :name => "New Braunfels", :aliases => ",New Braunfels", :latitude => "29.703", :longitude => "-98.12445").save
City.new(:country_id => "233", :name => "New Territory", :aliases => ",New Territory", :latitude => "29.59412", :longitude => "-95.68078").save
City.new(:country_id => "233", :name => "Orange", :aliases => ",Orange", :latitude => "30.09299", :longitude => "-93.73655").save
City.new(:country_id => "233", :name => "Palestine", :aliases => ",Palestine", :latitude => "31.76212", :longitude => "-95.63079").save
City.new(:country_id => "233", :name => "Paris", :aliases => "Parizh,ÐÐ°ÑÐ¸Ð¶,Paris", :latitude => "33.66094", :longitude => "-95.55551").save
City.new(:country_id => "233", :name => "Pasadena", :aliases => "Pasadena,ÐÐ°ÑÐ°Ð´ÐµÐ½Ð°,Pasadena", :latitude => "29.69106", :longitude => "-95.2091").save
City.new(:country_id => "233", :name => "Pearland", :aliases => ",Pearland", :latitude => "29.56357", :longitude => "-95.28605").save
City.new(:country_id => "233", :name => "Pecan Grove", :aliases => ",Pecan Grove", :latitude => "29.62607", :longitude => "-95.73162").save
City.new(:country_id => "233", :name => "Pflugerville", :aliases => ",Pflugerville", :latitude => "30.43937", :longitude => "-97.62").save
City.new(:country_id => "233", :name => "Pharr", :aliases => "Farra,Ð¤Ð°ÑÑÐ°,Pharr", :latitude => "26.1948", :longitude => "-98.18362").save
City.new(:country_id => "233", :name => "Plano", :aliases => "Planom,ÐÐ»Ð°Ð½Ð¾Ð¼,Plano", :latitude => "33.01984", :longitude => "-96.69889").save
City.new(:country_id => "233", :name => "Port Arthur", :aliases => "Port-Artur,ÐÐ¾ÑÑ-ÐÑÑÑÑ,Port Arthur", :latitude => "29.89883", :longitude => "-93.92878").save
City.new(:country_id => "233", :name => "Portland", :aliases => "Portlend,ÐÐ¾ÑÑÐ»ÐµÐ½Ð´,Portland", :latitude => "27.87725", :longitude => "-97.32388").save
City.new(:country_id => "233", :name => "Richardson", :aliases => "Richardson,Ð Ð¸ÑÐ°ÑÐ´ÑÐ¾Ð½,Richardson", :latitude => "32.94818", :longitude => "-96.72972").save
City.new(:country_id => "233", :name => "Rockwall", :aliases => ",Rockwall", :latitude => "32.93123", :longitude => "-96.45971").save
City.new(:country_id => "233", :name => "Rosenberg", :aliases => "Rozenberg,Ð Ð¾Ð·ÐµÐ½Ð±ÐµÑÐ³,Rosenberg", :latitude => "29.55718", :longitude => "-95.80856").save
City.new(:country_id => "233", :name => "Round Rock", :aliases => "Round Rock,Round Rock", :latitude => "30.50826", :longitude => "-97.6789").save
City.new(:country_id => "233", :name => "Rowlett", :aliases => ",Rowlett", :latitude => "32.9029", :longitude => "-96.56388").save
City.new(:country_id => "233", :name => "Sachse", :aliases => ",Sachse", :latitude => "32.97623", :longitude => "-96.59527").save
City.new(:country_id => "233", :name => "Saginaw", :aliases => ",Saginaw", :latitude => "32.86013", :longitude => "-97.36391").save
City.new(:country_id => "233", :name => "San Antonio", :aliases => "San Antonio,Sanctus Antonius,san antwnyw,san'antonio,sheng an dong ni ao,Ð¡Ð°Ð½ ÐÐ½ÑÐ¾Ð½Ð¸Ð¾,×¡×× ×× ××× ××,Ø³Ø§Ù Ø£ÙØ·ÙÙÙÙ,ãµã³ã¢ã³ãããª,å£å®ä¸å°¼å¥¥,San Antonio", :latitude => "29.42412", :longitude => "-98.49363").save
City.new(:country_id => "233", :name => "San Benito", :aliases => ",San Benito", :latitude => "26.13258", :longitude => "-97.6311").save
City.new(:country_id => "233", :name => "San Juan", :aliases => ",San Juan", :latitude => "26.18924", :longitude => "-98.15529").save
City.new(:country_id => "233", :name => "San Marcos", :aliases => ",San Marcos", :latitude => "29.88327", :longitude => "-97.94139").save
City.new(:country_id => "233", :name => "Schertz", :aliases => ",Schertz", :latitude => "29.55217", :longitude => "-98.26973").save
City.new(:country_id => "233", :name => "Seguin", :aliases => ",Seguin", :latitude => "29.56884", :longitude => "-97.96473").save
City.new(:country_id => "233", :name => "Sherman", :aliases => "Sherman,Ð¨ÐµÑÐ¼Ð°Ð½,Sherman", :latitude => "33.63566", :longitude => "-96.60888").save
City.new(:country_id => "233", :name => "South Houston", :aliases => ",South Houston", :latitude => "29.66301", :longitude => "-95.23549").save
City.new(:country_id => "233", :name => "Southlake", :aliases => ",Southlake", :latitude => "32.94124", :longitude => "-97.13418").save
City.new(:country_id => "233", :name => "Spring", :aliases => ",Spring", :latitude => "30.07994", :longitude => "-95.41716").save
City.new(:country_id => "233", :name => "Stafford", :aliases => ",Stafford", :latitude => "29.61607", :longitude => "-95.55772").save
City.new(:country_id => "233", :name => "Stephenville", :aliases => ",Stephenville", :latitude => "32.2207", :longitude => "-98.20226").save
City.new(:country_id => "233", :name => "Sugar Land", :aliases => "Sugar Land,Sugar Land", :latitude => "29.61968", :longitude => "-95.63495").save
City.new(:country_id => "233", :name => "Sulphur Springs", :aliases => ",Sulphur Springs", :latitude => "33.13845", :longitude => "-95.60107").save
City.new(:country_id => "233", :name => "Temple", :aliases => ",Temple", :latitude => "31.09823", :longitude => "-97.34278").save
City.new(:country_id => "233", :name => "Terrell", :aliases => ",Terrell", :latitude => "32.73596", :longitude => "-96.27526").save
City.new(:country_id => "233", :name => "Texarkana", :aliases => ",Texarkana", :latitude => "33.42512", :longitude => "-94.04769").save
City.new(:country_id => "233", :name => "Texas City", :aliases => ",Texas City", :latitude => "29.38384", :longitude => "-94.9027").save
City.new(:country_id => "233", :name => "The Colony", :aliases => "Kolonija,ÐÐ¾Ð»Ð¾Ð½Ð¸Ñ,The Colony", :latitude => "33.08901", :longitude => "-96.88639").save
City.new(:country_id => "233", :name => "The Woodlands", :aliases => "The Woodlands,Woodlands,The Woodlands", :latitude => "30.15799", :longitude => "-95.48938").save
City.new(:country_id => "233", :name => "Tyler", :aliases => "Tajler,Tyler,Ð¢Ð°Ð¹Ð»ÐµÑ,Tyler", :latitude => "32.35126", :longitude => "-95.30106").save
City.new(:country_id => "233", :name => "Universal City", :aliases => ",Universal City", :latitude => "29.54801", :longitude => "-98.29112").save
City.new(:country_id => "233", :name => "University Park", :aliases => ",University Park", :latitude => "32.85013", :longitude => "-96.80028").save
City.new(:country_id => "233", :name => "Uvalde", :aliases => ",Uvalde", :latitude => "29.20968", :longitude => "-99.78617").save
City.new(:country_id => "233", :name => "Victoria", :aliases => "Victoria,Viktorija,ÐÐ¸ÐºÑÐ¾ÑÐ¸Ñ,Victoria", :latitude => "28.80527", :longitude => "-97.0036").save
City.new(:country_id => "233", :name => "Waco", :aliases => "Vako,Waco,wei ke,ÐÐ°ÐºÐ¾,é¦ç§,Waco", :latitude => "31.54933", :longitude => "-97.14667").save
City.new(:country_id => "233", :name => "Watauga", :aliases => ",Watauga", :latitude => "32.85791", :longitude => "-97.25474").save
City.new(:country_id => "233", :name => "Waxahachie", :aliases => ",Waxahachie", :latitude => "32.38653", :longitude => "-96.84833").save
City.new(:country_id => "233", :name => "Weatherford", :aliases => ",Weatherford", :latitude => "32.7593", :longitude => "-97.79725").save
City.new(:country_id => "233", :name => "Weslaco", :aliases => ",Weslaco", :latitude => "26.15952", :longitude => "-97.99084").save
City.new(:country_id => "233", :name => "West University Place", :aliases => ",West University Place", :latitude => "29.71801", :longitude => "-95.43383").save
City.new(:country_id => "233", :name => "White Settlement", :aliases => ",White Settlement", :latitude => "32.75957", :longitude => "-97.45835").save
City.new(:country_id => "233", :name => "Wichita Falls", :aliases => "Wichita Falls,Wichita Falls", :latitude => "33.91371", :longitude => "-98.49339").save
City.new(:country_id => "233", :name => "Wylie", :aliases => ",Wylie", :latitude => "33.01512", :longitude => "-96.53888").save
City.new(:country_id => "233", :name => "Alexandria", :aliases => "Aleksandrija,Alexandria,arekusandoria,ya li shan de li ya,ÐÐ»ÐµÐºÑÐ°Ð½Ð´ÑÐ¸Ñ,ã¢ã¬ã¯ãµã³ããªã¢,äºåå±±å¾·éäº,Alexandria", :latitude => "38.80484", :longitude => "-77.04692").save
City.new(:country_id => "233", :name => "Annandale", :aliases => ",Annandale", :latitude => "38.83039", :longitude => "-77.19637").save
City.new(:country_id => "233", :name => "Arlington", :aliases => "Arlington,a ling dun xian,arinton,ÐÑÐ»Ð¸Ð½Ð³ÑÐ¾Ð½,ã¢ã¼ãªã³ãã³,é¿éé ç¸£,Arlington", :latitude => "38.88101", :longitude => "-77.10428").save
City.new(:country_id => "233", :name => "Baileys Crossroads", :aliases => ",Baileys Crossroads", :latitude => "38.85039", :longitude => "-77.1297").save
City.new(:country_id => "233", :name => "Blacksburg", :aliases => "Blehksburg,ÐÐ»ÑÐºÑÐ±ÑÑÐ³,Blacksburg", :latitude => "37.22957", :longitude => "-80.41394").save
City.new(:country_id => "233", :name => "Bon Air", :aliases => ",Bon Air", :latitude => "37.52487", :longitude => "-77.55777").save
City.new(:country_id => "233", :name => "Bristol", :aliases => ",Bristol", :latitude => "36.59649", :longitude => "-82.18847").save
City.new(:country_id => "233", :name => "Bull Run", :aliases => ",Bull Run", :latitude => "38.78373", :longitude => "-77.52055").save
City.new(:country_id => "233", :name => "Burke", :aliases => "Berk,ÐÐµÑÐº,Burke", :latitude => "38.79345", :longitude => "-77.27165").save
City.new(:country_id => "233", :name => "Cave Spring", :aliases => ",Cave Spring", :latitude => "37.22764", :longitude => "-80.01282").save
City.new(:country_id => "233", :name => "Centreville", :aliases => "Centreville,Centreville", :latitude => "38.84039", :longitude => "-77.42888").save
City.new(:country_id => "233", :name => "Chantilly", :aliases => ",Chantilly", :latitude => "38.89428", :longitude => "-77.4311").save
City.new(:country_id => "233", :name => "Charlottesville", :aliases => "Charlottesville,Sharlottsvill',sharottsubiru,syalleocheubil,Ð¨Ð°ÑÐ»Ð¾ÑÑÑÐ²Ð¸Ð»Ð»Ñ,ã·ã£ã¼ã­ãããã«,ì¬ë¬ì¸ ë¹,Charlottesville", :latitude => "38.02931", :longitude => "-78.47668").save
City.new(:country_id => "233", :name => "Chesapeake", :aliases => "Chesapeake,Chesapik,Ð§ÐµÑÐ°Ð¿Ð¸Ðº,Chesapeake", :latitude => "36.81904", :longitude => "-76.27494").save
City.new(:country_id => "233", :name => "Chester", :aliases => "Chester,Ð§ÐµÑÑÐµÑ,Chester", :latitude => "37.35682", :longitude => "-77.44165").save
City.new(:country_id => "233", :name => "Christiansburg", :aliases => ",Christiansburg", :latitude => "37.12985", :longitude => "-80.40894").save
City.new(:country_id => "233", :name => "Colonial Heights", :aliases => ",Colonial Heights", :latitude => "37.26804", :longitude => "-77.40726").save
City.new(:country_id => "233", :name => "Dale City", :aliases => "Dale City,Dale City", :latitude => "38.63706", :longitude => "-77.31109").save
City.new(:country_id => "233", :name => "Danville", :aliases => ",Danville", :latitude => "36.58597", :longitude => "-79.39502").save
City.new(:country_id => "233", :name => "East Hampton", :aliases => ",East Hampton", :latitude => "37.03737", :longitude => "-76.33161").save
City.new(:country_id => "233", :name => "Fairfax", :aliases => ",Fairfax", :latitude => "38.84622", :longitude => "-77.30637").save
City.new(:country_id => "233", :name => "Franconia", :aliases => "Frankonija,Ð¤ÑÐ°Ð½ÐºÐ¾Ð½Ð¸Ñ,Franconia", :latitude => "38.78206", :longitude => "-77.14637").save
City.new(:country_id => "233", :name => "Fredericksburg", :aliases => "Fredericksburg,Frederiksburg,fu lei de li ke si bao,peuledeoligseubeogeu,Ð¤ÑÐµÐ´ÐµÑÐ¸ÐºÑÐ±ÑÑÐ³,á¤á áááá ááá¡áá£á áá,å¼é·å¾·éåæ¯å ¡,íë ëë¦­ì¤ë²ê·¸,Fredericksburg", :latitude => "38.30318", :longitude => "-77.46054").save
City.new(:country_id => "233", :name => "Groveton", :aliases => ",Groveton", :latitude => "38.76734", :longitude => "-77.0847").save
City.new(:country_id => "233", :name => "Hampton", :aliases => "Hampton,Khehmpton,Ð¥ÑÐ¼Ð¿ÑÐ¾Ð½,Hampton", :latitude => "37.02987", :longitude => "-76.34522").save
City.new(:country_id => "233", :name => "Harrisonburg", :aliases => ",Harrisonburg", :latitude => "38.44957", :longitude => "-78.86892").save
City.new(:country_id => "233", :name => "Herndon", :aliases => "Kherndon,Ð¥ÐµÑÐ½Ð´Ð¾Ð½,Herndon", :latitude => "38.96955", :longitude => "-77.3861").save
City.new(:country_id => "233", :name => "Highland Springs", :aliases => ",Highland Springs", :latitude => "37.54598", :longitude => "-77.32776").save
City.new(:country_id => "233", :name => "Hopewell", :aliases => "Khopuehlla,Ð¥Ð¾Ð¿ÑÑÐ»Ð»Ð°,Hopewell", :latitude => "37.30432", :longitude => "-77.2872").save
City.new(:country_id => "233", :name => "Hybla Valley", :aliases => ",Hybla Valley", :latitude => "38.74761", :longitude => "-77.08303").save
City.new(:country_id => "233", :name => "Idylwood", :aliases => ",Idylwood", :latitude => "38.89511", :longitude => "-77.21165").save
City.new(:country_id => "233", :name => "Jefferson", :aliases => "Dzhefferson,ÐÐ¶ÐµÑÑÐµÑÑÐ¾Ð½,Jefferson", :latitude => "38.86456", :longitude => "-77.18776").save
City.new(:country_id => "233", :name => "Lake Ridge", :aliases => ",Lake Ridge", :latitude => "38.68789", :longitude => "-77.29776").save
City.new(:country_id => "233", :name => "Laurel", :aliases => ",Laurel", :latitude => "37.64292", :longitude => "-77.50887").save
City.new(:country_id => "233", :name => "Leesburg", :aliases => ",Leesburg", :latitude => "39.11566", :longitude => "-77.5636").save
City.new(:country_id => "233", :name => "Lincolnia", :aliases => ",Lincolnia", :latitude => "38.81845", :longitude => "-77.14331").save
City.new(:country_id => "233", :name => "Lorton", :aliases => ",Lorton", :latitude => "38.70428", :longitude => "-77.22776").save
City.new(:country_id => "233", :name => "Lynchburg", :aliases => "Lynchburg,Lynchburg", :latitude => "37.41375", :longitude => "-79.14225").save
City.new(:country_id => "233", :name => "Manassas", :aliases => "Manassas,ÐÐ°Ð½Ð°ÑÑÐ°Ñ,Manassas", :latitude => "38.75095", :longitude => "-77.47527").save
City.new(:country_id => "233", :name => "McLean", :aliases => "Maklin,ÐÐ°ÐºÐ»Ð¸Ð½,McLean", :latitude => "38.93428", :longitude => "-77.17748").save
City.new(:country_id => "233", :name => "Mechanicsville", :aliases => ",Mechanicsville", :latitude => "37.60876", :longitude => "-77.37331").save
City.new(:country_id => "233", :name => "Montclair", :aliases => ",Montclair", :latitude => "38.61095", :longitude => "-77.33971").save
City.new(:country_id => "233", :name => "Newington", :aliases => ",Newington", :latitude => "38.73845", :longitude => "-77.18498").save
City.new(:country_id => "233", :name => "Newport News", :aliases => "N'juport-N'jus,ÐÑÑÐ¿Ð¾ÑÑ-ÐÑÑÑ,Newport News", :latitude => "36.97876", :longitude => "-76.428").save
City.new(:country_id => "233", :name => "Norfolk", :aliases => "Norfolk,Norfolko,nofoku,nwrpwq,ÐÐ¾ÑÑÐ¾Ð»Ðº,× ××¨×¤××§,ãã¼ãã©ã¼ã¯,Norfolk", :latitude => "36.84681", :longitude => "-76.28522").save
City.new(:country_id => "233", :name => "Oakton", :aliases => ",Oakton", :latitude => "38.88095", :longitude => "-77.30082").save
City.new(:country_id => "233", :name => "Petersburg", :aliases => "Peterburg,ÐÐµÑÐµÑÐ±ÑÑÐ³,Petersburg", :latitude => "37.22793", :longitude => "-77.40193").save
City.new(:country_id => "233", :name => "Portsmouth", :aliases => "Portsmouth,Portsmut,ÐÐ¾ÑÑÑÐ¼ÑÑ,Portsmouth", :latitude => "36.83543", :longitude => "-76.29827").save
City.new(:country_id => "233", :name => "Portsmouth Heights", :aliases => ",Portsmouth Heights", :latitude => "36.82098", :longitude => "-76.36883").save
City.new(:country_id => "233", :name => "Reston", :aliases => "Reston,Ð ÐµÑÑÐ¾Ð½,Reston", :latitude => "38.96872", :longitude => "-77.3411").save
City.new(:country_id => "233", :name => "Richmond", :aliases => "Richmond,Ð Ð¸ÑÐ¼Ð¾Ð½Ð´,Richmond", :latitude => "37.55376", :longitude => "-77.46026").save
City.new(:country_id => "233", :name => "Roanoke", :aliases => ",Roanoke", :latitude => "37.27097", :longitude => "-79.94143").save
City.new(:country_id => "233", :name => "Rose Hill", :aliases => ",Rose Hill", :latitude => "38.78872", :longitude => "-77.11276").save
City.new(:country_id => "233", :name => "Salem", :aliases => "Salem,Ð¡Ð°Ð»ÐµÐ¼,Salem", :latitude => "37.29347", :longitude => "-80.05476").save
City.new(:country_id => "233", :name => "South Suffolk", :aliases => ",South Suffolk", :latitude => "36.71709", :longitude => "-76.59023").save
City.new(:country_id => "233", :name => "Springfield", :aliases => "Springfild,Ð¡Ð¿ÑÐ¸Ð½Ð³ÑÐ¸Ð»Ð´,Springfield", :latitude => "38.78928", :longitude => "-77.1872").save
City.new(:country_id => "233", :name => "Staunton", :aliases => "Stonton,Ð¡ÑÐ¾Ð½ÑÐ¾Ð½,Staunton", :latitude => "38.14958", :longitude => "-79.0717").save
City.new(:country_id => "233", :name => "Sterling", :aliases => "Sterling,Ð¡ÑÐµÑÐ»Ð¸Ð½Ð³,Sterling", :latitude => "39.00622", :longitude => "-77.4286").save
City.new(:country_id => "233", :name => "Suffolk", :aliases => "Saffolk,Suffolk,Ð¡Ð°ÑÑÐ¾Ð»Ðº,Suffolk", :latitude => "36.72821", :longitude => "-76.58356").save
City.new(:country_id => "233", :name => "Tuckahoe", :aliases => ",Tuckahoe", :latitude => "37.59015", :longitude => "-77.55638").save
City.new(:country_id => "233", :name => "Tysons Corner", :aliases => ",Tysons Corner", :latitude => "38.91872", :longitude => "-77.23109").save
City.new(:country_id => "233", :name => "Virginia Beach", :aliases => "Virdzhinija Bijch,Virginia Beach,bajiniabichi,beojiniabichi,ÐÐ¸ÑÐ´Ð¶Ð¸Ð½Ð¸Ñ ÐÐ¸Ð¹Ñ,ãã¼ã¸ãã¢ãã¼ã,ë²ì§ëìë¹ì¹,Virginia Beach", :latitude => "36.85293", :longitude => "-75.97798").save
City.new(:country_id => "233", :name => "Waynesboro", :aliases => ",Waynesboro", :latitude => "38.06847", :longitude => "-78.88947").save
City.new(:country_id => "233", :name => "West Lynchburg", :aliases => ",West Lynchburg", :latitude => "37.4032", :longitude => "-79.17808").save
City.new(:country_id => "233", :name => "West Springfield", :aliases => ",West Springfield", :latitude => "38.77261", :longitude => "-77.22109").save
City.new(:country_id => "233", :name => "Winchester", :aliases => ",Winchester", :latitude => "39.18566", :longitude => "-78.16333").save
City.new(:country_id => "233", :name => "Woodbridge", :aliases => ",Woodbridge", :latitude => "38.65817", :longitude => "-77.2497").save
City.new(:country_id => "233", :name => "Beckley", :aliases => ",Beckley", :latitude => "37.77817", :longitude => "-81.18816").save
City.new(:country_id => "233", :name => "Charleston", :aliases => "Charleston,Charlston,cha er si dun,charusuton,Ð§Ð°ÑÐ»ÑÑÐ¾Ð½,ãã£ã¼ã«ã¹ãã³,æ¥å°æ¯é¡¿,Charleston", :latitude => "38.34982", :longitude => "-81.63262").save
City.new(:country_id => "233", :name => "Clarksburg", :aliases => ",Clarksburg", :latitude => "39.28065", :longitude => "-80.34453").save
City.new(:country_id => "233", :name => "Fairmont", :aliases => ",Fairmont", :latitude => "39.48508", :longitude => "-80.14258").save
City.new(:country_id => "233", :name => "Huntington", :aliases => "Khantington,Ð¥Ð°Ð½ÑÐ¸Ð½Ð³ÑÐ¾Ð½,Huntington", :latitude => "38.41925", :longitude => "-82.44515").save
City.new(:country_id => "233", :name => "Martinsburg", :aliases => ",Martinsburg", :latitude => "39.45621", :longitude => "-77.96389").save
City.new(:country_id => "233", :name => "Morgantown", :aliases => ",Morgantown", :latitude => "39.62953", :longitude => "-79.9559").save
City.new(:country_id => "233", :name => "Parkersburg", :aliases => "Parkersberg,ÐÐ°ÑÐºÐµÑÑÐ±ÐµÑÐ³,Parkersburg", :latitude => "39.26674", :longitude => "-81.56151").save
City.new(:country_id => "233", :name => "Teays Valley", :aliases => ",Teays Valley", :latitude => "38.45009", :longitude => "-81.9293").save
City.new(:country_id => "233", :name => "Sherwood", :aliases => ",Sherwood", :latitude => "34.81509", :longitude => "-92.22432").save
City.new(:country_id => "233", :name => "Franklin", :aliases => "Franklin,Ð¤ÑÐ°Ð½ÐºÐ»Ð¸Ð½,Franklin", :latitude => "39.48061", :longitude => "-86.05499").save
City.new(:country_id => "233", :name => "Chillicothe", :aliases => ",Chillicothe", :latitude => "39.33312", :longitude => "-82.9824").save
City.new(:country_id => "233", :name => "Bay City", :aliases => "Bej-Siti,ÐÐµÐ¹-Ð¡Ð¸ÑÐ¸,Bay City", :latitude => "28.98276", :longitude => "-95.9694").save
City.new(:country_id => "233", :name => "Alabaster", :aliases => "Alebastr,ÐÐ»ÐµÐ±Ð°ÑÑÑ,Alabaster", :latitude => "33.24428", :longitude => "-86.81638").save
City.new(:country_id => "233", :name => "Albertville", :aliases => ",Albertville", :latitude => "34.26759", :longitude => "-86.20887").save
City.new(:country_id => "233", :name => "Anniston", :aliases => "Anniston,ÐÐ½Ð½Ð¸ÑÑÐ¾Ð½,Anniston", :latitude => "33.65983", :longitude => "-85.83163").save
City.new(:country_id => "233", :name => "Athens", :aliases => ",Athens", :latitude => "34.80287", :longitude => "-86.97167").save
City.new(:country_id => "233", :name => "Auburn", :aliases => ",Auburn", :latitude => "32.60986", :longitude => "-85.48078").save
City.new(:country_id => "233", :name => "Glendale Heights", :aliases => ",Glendale Heights", :latitude => "41.91031", :longitude => "-88.07174").save
City.new(:country_id => "233", :name => "North Andover", :aliases => ",North Andover", :latitude => "42.6987", :longitude => "-71.13506").save
City.new(:country_id => "233", :name => "Revere", :aliases => ",Revere", :latitude => "42.40843", :longitude => "-71.01199").save
City.new(:country_id => "233", :name => "Danbury", :aliases => ",Danbury", :latitude => "41.39482", :longitude => "-73.45401").save
City.new(:country_id => "233", :name => "Darien", :aliases => ",Darien", :latitude => "41.07871", :longitude => "-73.46929").save
City.new(:country_id => "233", :name => "Inkster", :aliases => ",Inkster", :latitude => "42.2942", :longitude => "-83.30993").save
City.new(:country_id => "233", :name => "Cleveland Heights", :aliases => ",Cleveland Heights", :latitude => "41.52005", :longitude => "-81.55624").save
City.new(:country_id => "233", :name => "East Hartford", :aliases => ",East Hartford", :latitude => "41.78232", :longitude => "-72.61203").save
City.new(:country_id => "233", :name => "East Haven", :aliases => ",East Haven", :latitude => "41.27621", :longitude => "-72.86843").save
City.new(:country_id => "233", :name => "East Norwalk", :aliases => ",East Norwalk", :latitude => "41.10565", :longitude => "-73.39845").save
City.new(:country_id => "233", :name => "Fairfield", :aliases => "Feurfild,Ð¤ÐµÑÑÑÐ¸Ð»Ð´,Fairfield", :latitude => "41.14121", :longitude => "-73.26373").save
City.new(:country_id => "233", :name => "Farmington", :aliases => "Farmington,Ð¤Ð°ÑÐ¼Ð¸Ð½Ð³ÑÐ¾Ð½,Farmington", :latitude => "41.71982", :longitude => "-72.83204").save
City.new(:country_id => "233", :name => "Glastonbury", :aliases => "Glastonberi,ÐÐ»Ð°ÑÑÐ¾Ð½Ð±ÐµÑÐ¸,Glastonbury", :latitude => "41.71232", :longitude => "-72.60815").save
City.new(:country_id => "233", :name => "Greenwich", :aliases => "Grinvich,ÐÑÐ¸Ð½Ð²Ð¸Ñ,Greenwich", :latitude => "41.02649", :longitude => "-73.62846").save
City.new(:country_id => "233", :name => "Guilford", :aliases => "Gilford,ÐÐ¸Ð»ÑÐ¾ÑÐ´,Guilford", :latitude => "41.28899", :longitude => "-72.68176").save
City.new(:country_id => "233", :name => "Hamden", :aliases => ",Hamden", :latitude => "41.39593", :longitude => "-72.89677").save
City.new(:country_id => "233", :name => "Hartford", :aliases => "Hartford,Khartford,ha te fu,hatofodo,Ð¥Ð°ÑÑÑÐ¾ÑÐ´,ãã¼ããã©ã¼ã,åç¹ç¦,Hartford", :latitude => "41.76371", :longitude => "-72.68509").save
City.new(:country_id => "233", :name => "Killingly Center", :aliases => ",Killingly Center", :latitude => "41.83871", :longitude => "-71.86924").save
City.new(:country_id => "233", :name => "Ledyard Center", :aliases => ",Ledyard Center", :latitude => "41.43982", :longitude => "-72.01424").save
City.new(:country_id => "233", :name => "Madison", :aliases => "Madison,ÐÐ°Ð´Ð¸ÑÐ¾Ð½,Madison", :latitude => "41.27954", :longitude => "-72.59843").save
City.new(:country_id => "233", :name => "Manchester", :aliases => "Manchester,ÐÐ°Ð½ÑÐµÑÑÐµÑ,Manchester", :latitude => "41.77593", :longitude => "-72.52148").save
City.new(:country_id => "233", :name => "Mansfield City", :aliases => ",Mansfield City", :latitude => "41.76593", :longitude => "-72.23369").save
City.new(:country_id => "233", :name => "Meriden", :aliases => ",Meriden", :latitude => "41.53815", :longitude => "-72.80704").save
City.new(:country_id => "233", :name => "Middletown", :aliases => ",Middletown", :latitude => "41.56232", :longitude => "-72.65065").save
City.new(:country_id => "233", :name => "Milford", :aliases => "Milford,ÐÐ¸Ð»ÑÐ¾ÑÐ´,Milford", :latitude => "41.22232", :longitude => "-73.0565").save
City.new(:country_id => "233", :name => "Montville Center", :aliases => ",Montville Center", :latitude => "41.47899", :longitude => "-72.15119").save
City.new(:country_id => "233", :name => "Naugatuck", :aliases => ",Naugatuck", :latitude => "41.48593", :longitude => "-73.05066").save
City.new(:country_id => "233", :name => "New Britain", :aliases => "New Britain,New Britain", :latitude => "41.66121", :longitude => "-72.77954").save
City.new(:country_id => "233", :name => "New Haven", :aliases => "N'ju-Khejven,New Haven,niu hei wen,nyuheibun,nyw hyybn,ÐÑÑ-Ð¥ÐµÐ¹Ð²ÐµÐ½,× ×× ×××××,ãã¥ã¼ãã¤ãã³,çº½é»æ,New Haven", :latitude => "41.30815", :longitude => "-72.92816").save
City.new(:country_id => "233", :name => "New London", :aliases => "N'ju-London,Nova Londres,ÐÑÑ-ÐÐ¾Ð½Ð´Ð¾Ð½,New London", :latitude => "41.35565", :longitude => "-72.09952").save
City.new(:country_id => "233", :name => "New Milford", :aliases => ",New Milford", :latitude => "41.57704", :longitude => "-73.40845").save
City.new(:country_id => "233", :name => "Newington", :aliases => ",Newington", :latitude => "41.69788", :longitude => "-72.72371").save
City.new(:country_id => "233", :name => "North Haven", :aliases => ",North Haven", :latitude => "41.39093", :longitude => "-72.85954").save
City.new(:country_id => "233", :name => "North Stamford", :aliases => ",North Stamford", :latitude => "41.13815", :longitude => "-73.54346").save
City.new(:country_id => "233", :name => "Norwalk", :aliases => "Norwalk,Norwalk", :latitude => "41.1176", :longitude => "-73.4079").save
City.new(:country_id => "233", :name => "Norwich", :aliases => "Noridzh,ÐÐ¾ÑÐ¸Ð´Ð¶,Norwich", :latitude => "41.52426", :longitude => "-72.07591").save
City.new(:country_id => "233", :name => "Old Greenwich", :aliases => ",Old Greenwich", :latitude => "41.02288", :longitude => "-73.56485").save
City.new(:country_id => "233", :name => "Plainfield", :aliases => ",Plainfield", :latitude => "41.67649", :longitude => "-71.91507").save
City.new(:country_id => "233", :name => "Plainville", :aliases => "Plainville,Plejnvill',ÐÐ»ÐµÐ¹Ð½Ð²Ð¸Ð»Ð»Ñ,Plainville", :latitude => "41.67454", :longitude => "-72.85816").save
City.new(:country_id => "233", :name => "Seymour", :aliases => ",Seymour", :latitude => "41.39676", :longitude => "-73.07594").save
City.new(:country_id => "233", :name => "Shelton", :aliases => "Shelton,Ð¨ÐµÐ»ÑÐ¾Ð½,Shelton", :latitude => "41.31649", :longitude => "-73.09316").save
City.new(:country_id => "233", :name => "South Windsor", :aliases => ",South Windsor", :latitude => "41.82371", :longitude => "-72.6212").save
City.new(:country_id => "233", :name => "Southbury", :aliases => ",Southbury", :latitude => "41.48148", :longitude => "-73.21317").save
City.new(:country_id => "233", :name => "Stamford", :aliases => "Stamford,sutanfodo,Ð¡ÑÐ°Ð¼ÑÐ¾ÑÐ´,ã¹ã¿ã³ãã©ã¼ã,Stamford", :latitude => "41.05343", :longitude => "-73.53873").save
City.new(:country_id => "233", :name => "Stratford", :aliases => "Stratford,Ð¡ÑÑÐ°ÑÑÐ¾ÑÐ´,Stratford", :latitude => "41.18454", :longitude => "-73.13317").save
City.new(:country_id => "233", :name => "Torrington", :aliases => ",Torrington", :latitude => "41.80065", :longitude => "-73.12122").save
City.new(:country_id => "233", :name => "Trumbull", :aliases => "Trambal,Ð¢ÑÐ°Ð¼Ð±Ð°Ð»,Trumbull", :latitude => "41.24287", :longitude => "-73.20067").save
City.new(:country_id => "233", :name => "Wallingford", :aliases => ",Wallingford", :latitude => "41.45704", :longitude => "-72.82316").save
City.new(:country_id => "233", :name => "Waterbury", :aliases => "Uot'rb'ri,Waterbury,u~otabari,u~otaberi,Ð£Ð¾ÑÑÑÐ±ÑÑÐ¸,ã¦ã©ã¼ã¿ã¼ããªã¼,ã¦ã©ã¼ã¿ã¼ããªã¼,Waterbury", :latitude => "41.55815", :longitude => "-73.0515").save
City.new(:country_id => "233", :name => "Watertown", :aliases => ",Watertown", :latitude => "41.60621", :longitude => "-73.11817").save
City.new(:country_id => "233", :name => "West Hartford", :aliases => "West Hartford,West Hartford", :latitude => "41.76204", :longitude => "-72.74204").save
City.new(:country_id => "233", :name => "West Haven", :aliases => ",West Haven", :latitude => "41.27065", :longitude => "-72.94705").save
City.new(:country_id => "233", :name => "West Torrington", :aliases => ",West Torrington", :latitude => "41.81843", :longitude => "-73.14372").save
City.new(:country_id => "233", :name => "Westport", :aliases => ",Westport", :latitude => "41.14149", :longitude => "-73.3579").save
City.new(:country_id => "233", :name => "Wethersfield", :aliases => ",Wethersfield", :latitude => "41.71427", :longitude => "-72.65259").save
City.new(:country_id => "233", :name => "Willimantic", :aliases => ",Willimantic", :latitude => "41.71065", :longitude => "-72.20813").save
City.new(:country_id => "233", :name => "Windham", :aliases => ",Windham", :latitude => "41.69982", :longitude => "-72.15702").save
City.new(:country_id => "233", :name => "Wolcott", :aliases => ",Wolcott", :latitude => "41.60232", :longitude => "-72.98677").save
City.new(:country_id => "233", :name => "Ames", :aliases => "Ames,Ehjmsa,ai mu si,xem s,Ð­Ð¹Ð¼ÑÐ°,à¹à¸­à¸¡à¸ªà¹,è¾å§æ¯,Ames", :latitude => "42.03471", :longitude => "-93.61994").save
City.new(:country_id => "233", :name => "Ankeny", :aliases => ",Ankeny", :latitude => "41.72971", :longitude => "-93.60577").save
City.new(:country_id => "233", :name => "Bettendorf", :aliases => ",Bettendorf", :latitude => "41.52448", :longitude => "-90.51569").save
City.new(:country_id => "233", :name => "Burlington", :aliases => "Berlington,ÐÐµÑÐ»Ð¸Ð½Ð³ÑÐ¾Ð½,Burlington", :latitude => "40.80754", :longitude => "-91.11292").save
City.new(:country_id => "233", :name => "Cedar Falls", :aliases => ",Cedar Falls", :latitude => "42.52776", :longitude => "-92.44547").save
City.new(:country_id => "233", :name => "Cedar Rapids", :aliases => ",Cedar Rapids", :latitude => "42.00833", :longitude => "-91.64407").save
City.new(:country_id => "233", :name => "Clinton", :aliases => "Klinton,ÐÐ»Ð¸Ð½ÑÐ¾Ð½,Clinton", :latitude => "41.84447", :longitude => "-90.18874").save
City.new(:country_id => "233", :name => "Clinton Stock Yards", :aliases => ",Clinton Stock Yards", :latitude => "41.8167", :longitude => "-90.22263").save
City.new(:country_id => "233", :name => "Coralville", :aliases => ",Coralville", :latitude => "41.6764", :longitude => "-91.58045").save
City.new(:country_id => "233", :name => "Council Bluffs", :aliases => ",Council Bluffs", :latitude => "41.26194", :longitude => "-95.86083").save
City.new(:country_id => "233", :name => "Davenport", :aliases => "Davenport,Dehvenport,ÐÑÐ²ÐµÐ½Ð¿Ð¾ÑÑ,Davenport", :latitude => "41.52364", :longitude => "-90.57764").save
City.new(:country_id => "233", :name => "Des Moines", :aliases => "De-Mojn,Des Moines,de mei yin,demoin,dh mwyn,di mxyn,dy mwyn,ÐÐµ-ÐÐ¾Ð¹Ð½,×× ××××,Ø¯Ù ÙÙÙÙ,à¸à¸´à¸¡à¸­à¸¢à¸à¹,ãã¢ã¤ã³,å¾·æ¢å ,Des Moines", :latitude => "41.60054", :longitude => "-93.60911").save
City.new(:country_id => "233", :name => "Dubuque", :aliases => ",Dubuque", :latitude => "42.50056", :longitude => "-90.66457").save
City.new(:country_id => "233", :name => "Fort Dodge", :aliases => ",Fort Dodge", :latitude => "42.49747", :longitude => "-94.16802").save
City.new(:country_id => "233", :name => "Iowa City", :aliases => "Iowa City,Iowa City", :latitude => "41.66113", :longitude => "-91.53017").save
City.new(:country_id => "233", :name => "Marion", :aliases => "Mehrion,ÐÑÑÐ¸Ð¾Ð½,Marion", :latitude => "42.03417", :longitude => "-91.59768").save
City.new(:country_id => "233", :name => "Marshalltown", :aliases => ",Marshalltown", :latitude => "42.04943", :longitude => "-92.90798").save
City.new(:country_id => "233", :name => "Mason City", :aliases => "Mejson-Siti,ÐÐµÐ¹ÑÐ¾Ð½-Ð¡Ð¸ÑÐ¸,Mason City", :latitude => "43.15357", :longitude => "-93.20104").save
City.new(:country_id => "233", :name => "Muscatine", :aliases => ",Muscatine", :latitude => "41.42447", :longitude => "-91.04321").save
City.new(:country_id => "233", :name => "Newton", :aliases => "N'juton,ÐÑÑÑÐ¾Ð½,Newton", :latitude => "41.69971", :longitude => "-93.04798").save
City.new(:country_id => "233", :name => "Ottumwa", :aliases => "Ottamua,ÐÑÑÐ°Ð¼ÑÐ°,Ottumwa", :latitude => "41.02001", :longitude => "-92.4113").save
City.new(:country_id => "233", :name => "Sioux City", :aliases => ",Sioux City", :latitude => "42.49999", :longitude => "-96.40031").save
City.new(:country_id => "233", :name => "Urbandale", :aliases => ",Urbandale", :latitude => "41.62666", :longitude => "-93.71217").save
City.new(:country_id => "233", :name => "Waterloo", :aliases => "Vaterlo,Waterloo,ÐÐ°ÑÐµÑÐ»Ð¾,Waterloo", :latitude => "42.49276", :longitude => "-92.34296").save
City.new(:country_id => "233", :name => "West Des Moines", :aliases => ",West Des Moines", :latitude => "41.57199", :longitude => "-93.74531").save
City.new(:country_id => "233", :name => "Addison", :aliases => ",Addison", :latitude => "41.9317", :longitude => "-87.98896").save
City.new(:country_id => "233", :name => "Algonquin", :aliases => ",Algonquin", :latitude => "42.16558", :longitude => "-88.29425").save
City.new(:country_id => "233", :name => "Alsip", :aliases => ",Alsip", :latitude => "41.66892", :longitude => "-87.73866").save
City.new(:country_id => "233", :name => "Arlington Heights", :aliases => "Arlington Heights,Arlington Heights", :latitude => "42.08836", :longitude => "-87.98063").save
City.new(:country_id => "233", :name => "Aurora", :aliases => "Aurora,Avrora,ÐÐ²ÑÐ¾ÑÐ°,Aurora", :latitude => "41.76058", :longitude => "-88.32007").save
City.new(:country_id => "233", :name => "Bartlett", :aliases => "Bartlett,ÐÐ°ÑÑÐ»ÐµÑÑ,Bartlett", :latitude => "41.99503", :longitude => "-88.18563").save
City.new(:country_id => "233", :name => "Batavia", :aliases => "Batavija,ÐÐ°ÑÐ°Ð²Ð¸Ñ,Batavia", :latitude => "41.85003", :longitude => "-88.31257").save
City.new(:country_id => "233", :name => "Bellwood", :aliases => ",Bellwood", :latitude => "41.88142", :longitude => "-87.88312").save
City.new(:country_id => "233", :name => "Belvidere", :aliases => "Bel'vedere,ÐÐµÐ»ÑÐ²ÐµÐ´ÐµÑÐµ,Belvidere", :latitude => "42.26391", :longitude => "-88.84427").save
City.new(:country_id => "233", :name => "Bensenville", :aliases => ",Bensenville", :latitude => "41.95503", :longitude => "-87.94007").save
City.new(:country_id => "233", :name => "Berwyn", :aliases => ",Berwyn", :latitude => "41.85059", :longitude => "-87.79367").save
City.new(:country_id => "233", :name => "Bloomingdale", :aliases => ",Bloomingdale", :latitude => "41.95753", :longitude => "-88.0809").save
City.new(:country_id => "233", :name => "Bloomington", :aliases => "Bloomington,Blumington,blumintana,ÐÐ»ÑÐ¼Ð¸Ð½Ð³ÑÐ¾Ð½,à¦¬à§à¦²à§à¦®à¦¿à¦à¦à¦¨,Bloomington", :latitude => "40.4842", :longitude => "-88.99369").save
City.new(:country_id => "233", :name => "Blue Island", :aliases => ",Blue Island", :latitude => "41.65726", :longitude => "-87.68005").save
City.new(:country_id => "233", :name => "Bolingbrook", :aliases => "Bolingbrook,Bolingbrook", :latitude => "41.69864", :longitude => "-88.0684").save
City.new(:country_id => "233", :name => "Bourbonnais", :aliases => ",Bourbonnais", :latitude => "41.1417", :longitude => "-87.87504").save
City.new(:country_id => "233", :name => "Bridgeview", :aliases => ",Bridgeview", :latitude => "41.75003", :longitude => "-87.80422").save
City.new(:country_id => "233", :name => "Brookfield", :aliases => ",Brookfield", :latitude => "41.82392", :longitude => "-87.85173").save
City.new(:country_id => "233", :name => "Buffalo Grove", :aliases => ",Buffalo Grove", :latitude => "42.15141", :longitude => "-87.95979").save
City.new(:country_id => "233", :name => "Burbank", :aliases => "Berbank,ÐÐµÑÐ±Ð°Ð½Ðº,Burbank", :latitude => "41.73392", :longitude => "-87.7795").save
City.new(:country_id => "233", :name => "Calumet City", :aliases => ",Calumet City", :latitude => "41.61559", :longitude => "-87.52949").save
City.new(:country_id => "233", :name => "Carol Stream", :aliases => ",Carol Stream", :latitude => "41.91253", :longitude => "-88.13479").save
City.new(:country_id => "233", :name => "Carpentersville", :aliases => ",Carpentersville", :latitude => "42.12114", :longitude => "-88.25786").save
City.new(:country_id => "233", :name => "Cary", :aliases => "Kehri,ÐÑÑÐ¸,Cary", :latitude => "42.21197", :longitude => "-88.23814").save
City.new(:country_id => "233", :name => "Champaign", :aliases => "Champaign,Shampejn,syampe'ina,Ð¨Ð°Ð¼Ð¿ÐµÐ¹Ð½,à¦¶à§à¦¯à¦¾à¦®à§à¦ªà§à¦à¦¨,Champaign", :latitude => "40.11642", :longitude => "-88.24338").save
City.new(:country_id => "233", :name => "Chicago", :aliases => "CHI,Chicago,Chicagu,Chikago,Cikaga,Cikago,Cikaqo,Gorad Chykaga,Kikako,Sicagum,Sikago,Tsikago,chikhako,cikago,cikako,shikago,shkagw,shykaghw,shykagw,shykajw,shyqgw,sikago,sikkagea,syqgw,zhi jia ge,Ãikaqo,Äikago,Äikaga,ÄikÄga,Åikago,Î£Î¹ÎºÎ¬Î³Î¿,ÐÐ¾ÑÐ°Ð´ Ð§ÑÐºÐ°Ð³Ð°,Ð§Ð¸ÐºÐ°Ð³Ð¾,Ð§Ð¸ÐºÐ°ÒÐ¾,ÕÕ«Õ¯Õ¡Õ£Õ¸,×©××§×××,×©××§××,Ø´ÙÙØ§Ø¬Ù,Ø´ÙÙØ§ØºÙ,Ø´Ú©Ø§Ú¯Ù,Ø´ÛÚ©Ø§Ú¯Ù,Ü«ÜÜ©ÜÜ,à¤¶à¤¿à¤à¤¾à¤à¥,à¦¶à¦¿à¦à¦¾à¦à§,à®à®¿à®à®¾à®à¯,à°à°¿à°à°¾à°à±,à´·à´¿à´àµà´à´¾à´àµ,à¸à¸´à¸à¸²à¹à¸,á©ááááá,á°áá¯/siiqaaku,á¹¢Ã¬kÃ¡gÃ²,ã·ã«ã´,èå å¥,ìì¹´ê³ ,Chicago", :latitude => "41.85003", :longitude => "-87.65005").save
City.new(:country_id => "233", :name => "Chicago Heights", :aliases => ",Chicago Heights", :latitude => "41.50615", :longitude => "-87.6356").save
City.new(:country_id => "233", :name => "Cicero", :aliases => "Cicero,Ciceron,Ð¦Ð¸ÑÐµÑÐ¾Ð½,Cicero", :latitude => "41.84559", :longitude => "-87.75394").save
City.new(:country_id => "233", :name => "Country Club Hills", :aliases => ",Country Club Hills", :latitude => "41.56809", :longitude => "-87.72033").save
City.new(:country_id => "233", :name => "Crest Hill", :aliases => ",Crest Hill", :latitude => "41.55475", :longitude => "-88.09867").save
City.new(:country_id => "233", :name => "Crystal Lake", :aliases => ",Crystal Lake", :latitude => "42.24113", :longitude => "-88.3162").save
City.new(:country_id => "233", :name => "Danville", :aliases => ",Danville", :latitude => "40.12448", :longitude => "-87.63002").save
City.new(:country_id => "233", :name => "Darien", :aliases => ",Darien", :latitude => "41.75198", :longitude => "-87.97395").save
City.new(:country_id => "233", :name => "DeKalb", :aliases => ",DeKalb", :latitude => "41.92947", :longitude => "-88.75036").save
City.new(:country_id => "233", :name => "Deerfield", :aliases => ",Deerfield", :latitude => "42.17114", :longitude => "-87.84451").save
City.new(:country_id => "233", :name => "Des Plaines", :aliases => ",Des Plaines", :latitude => "42.03336", :longitude => "-87.8834").save
City.new(:country_id => "233", :name => "Dolton", :aliases => ",Dolton", :latitude => "41.63892", :longitude => "-87.60727").save
City.new(:country_id => "233", :name => "Downers Grove", :aliases => ",Downers Grove", :latitude => "41.80892", :longitude => "-88.01117").save
City.new(:country_id => "233", :name => "East Moline", :aliases => ",East Moline", :latitude => "41.50087", :longitude => "-90.4443").save
City.new(:country_id => "233", :name => "East Peoria", :aliases => ",East Peoria", :latitude => "40.66615", :longitude => "-89.5801").save
City.new(:country_id => "233", :name => "Elgin", :aliases => "Elgin,Elgin", :latitude => "42.03725", :longitude => "-88.28119").save
City.new(:country_id => "233", :name => "Elk Grove Village", :aliases => ",Elk Grove Village", :latitude => "42.00392", :longitude => "-87.97035").save
City.new(:country_id => "233", :name => "Elmhurst", :aliases => ",Elmhurst", :latitude => "41.89947", :longitude => "-87.94034").save
City.new(:country_id => "233", :name => "Elmwood Park", :aliases => ",Elmwood Park", :latitude => "41.92114", :longitude => "-87.80923").save
City.new(:country_id => "233", :name => "Evanston", :aliases => "Evanston,Evanston", :latitude => "42.04114", :longitude => "-87.69006").save
City.new(:country_id => "233", :name => "Evergreen Park", :aliases => ",Evergreen Park", :latitude => "41.72059", :longitude => "-87.70172").save
City.new(:country_id => "233", :name => "Forest Park", :aliases => ",Forest Park", :latitude => "41.87948", :longitude => "-87.81367").save
City.new(:country_id => "233", :name => "Frankfort", :aliases => "Frankfurt,Ð¤ÑÐ°Ð½ÐºÑÑÑÑ,Frankfort", :latitude => "41.49587", :longitude => "-87.84866").save
City.new(:country_id => "233", :name => "Franklin Park", :aliases => ",Franklin Park", :latitude => "41.93531", :longitude => "-87.86562").save
City.new(:country_id => "233", :name => "Freeport", :aliases => ",Freeport", :latitude => "42.29669", :longitude => "-89.62123").save
City.new(:country_id => "233", :name => "Galesburg", :aliases => ",Galesburg", :latitude => "40.94782", :longitude => "-90.37124").save
City.new(:country_id => "233", :name => "Geneva", :aliases => "Zheneva,ÐÐµÐ½ÐµÐ²Ð°,Geneva", :latitude => "41.88753", :longitude => "-88.30535").save
City.new(:country_id => "233", :name => "Glen Ellyn", :aliases => ",Glen Ellyn", :latitude => "41.87753", :longitude => "-88.06701").save
City.new(:country_id => "233", :name => "Glenview", :aliases => ",Glenview", :latitude => "42.06975", :longitude => "-87.78784").save
City.new(:country_id => "233", :name => "Goodings Grove", :aliases => ",Goodings Grove", :latitude => "41.6292", :longitude => "-87.93089").save
City.new(:country_id => "233", :name => "Grayslake", :aliases => ",Grayslake", :latitude => "42.34447", :longitude => "-88.04175").save
City.new(:country_id => "233", :name => "Gurnee", :aliases => ",Gurnee", :latitude => "42.3703", :longitude => "-87.90202").save
City.new(:country_id => "233", :name => "Hanover Park", :aliases => ",Hanover Park", :latitude => "41.99947", :longitude => "-88.14507").save
City.new(:country_id => "233", :name => "Harvey", :aliases => "Kharvi,Ð¥Ð°ÑÐ²Ð¸,Harvey", :latitude => "41.61003", :longitude => "-87.64671").save
City.new(:country_id => "233", :name => "Highland Park", :aliases => ",Highland Park", :latitude => "42.18169", :longitude => "-87.80034").save
City.new(:country_id => "233", :name => "Hinsdale", :aliases => ",Hinsdale", :latitude => "41.80086", :longitude => "-87.93701").save
City.new(:country_id => "233", :name => "Hoffman Estates", :aliases => ",Hoffman Estates", :latitude => "42.04281", :longitude => "-88.0798").save
City.new(:country_id => "233", :name => "Homewood", :aliases => ",Homewood", :latitude => "41.55726", :longitude => "-87.6656").save
City.new(:country_id => "233", :name => "Huntley", :aliases => ",Huntley", :latitude => "42.16808", :longitude => "-88.42814").save
City.new(:country_id => "233", :name => "Joliet", :aliases => "Joliet,Joliet", :latitude => "41.52503", :longitude => "-88.08173").save
City.new(:country_id => "233", :name => "Kankakee", :aliases => ",Kankakee", :latitude => "41.12003", :longitude => "-87.86115").save
City.new(:country_id => "233", :name => "La Grange", :aliases => ",La Grange", :latitude => "41.80503", :longitude => "-87.86923").save
City.new(:country_id => "233", :name => "La Grange Park", :aliases => ",La Grange Park", :latitude => "41.83475", :longitude => "-87.86173").save
City.new(:country_id => "233", :name => "Lake Forest", :aliases => ",Lake Forest", :latitude => "42.25863", :longitude => "-87.84062").save
City.new(:country_id => "233", :name => "Lake Zurich", :aliases => ",Lake Zurich", :latitude => "42.19697", :longitude => "-88.09341").save
City.new(:country_id => "233", :name => "Lake in the Hills", :aliases => ",Lake in the Hills", :latitude => "42.18169", :longitude => "-88.33036").save
City.new(:country_id => "233", :name => "Lansing", :aliases => "Lansing,ÐÐ°Ð½ÑÐ¸Ð½Ð³,Lansing", :latitude => "41.56476", :longitude => "-87.53893").save
City.new(:country_id => "233", :name => "Lemont", :aliases => ",Lemont", :latitude => "41.67364", :longitude => "-88.00173").save
City.new(:country_id => "233", :name => "Libertyville", :aliases => ",Libertyville", :latitude => "42.28308", :longitude => "-87.95313").save
City.new(:country_id => "233", :name => "Lindenhurst", :aliases => ",Lindenhurst", :latitude => "42.41058", :longitude => "-88.02619").save
City.new(:country_id => "233", :name => "Lisle", :aliases => "Lilu,ÐÐ¸Ð»Ñ,Lisle", :latitude => "41.80114", :longitude => "-88.07479").save
City.new(:country_id => "233", :name => "Lockport", :aliases => ",Lockport", :latitude => "41.58948", :longitude => "-88.05784").save
City.new(:country_id => "233", :name => "Lombard", :aliases => "Lombard,ÐÐ¾Ð¼Ð±Ð°ÑÐ´,Lombard", :latitude => "41.88003", :longitude => "-88.00784").save
City.new(:country_id => "233", :name => "Loves Park", :aliases => ",Loves Park", :latitude => "42.32002", :longitude => "-89.05816").save
City.new(:country_id => "233", :name => "Machesney Park", :aliases => ",Machesney Park", :latitude => "42.34724", :longitude => "-89.039").save
City.new(:country_id => "233", :name => "Macomb", :aliases => ",Macomb", :latitude => "40.45921", :longitude => "-90.6718").save
City.new(:country_id => "233", :name => "Matteson", :aliases => ",Matteson", :latitude => "41.50392", :longitude => "-87.7131").save
City.new(:country_id => "233", :name => "Maywood", :aliases => ",Maywood", :latitude => "41.8792", :longitude => "-87.84312").save
City.new(:country_id => "233", :name => "McHenry", :aliases => ",McHenry", :latitude => "42.33336", :longitude => "-88.26675").save
City.new(:country_id => "233", :name => "Melrose Park", :aliases => ",Melrose Park", :latitude => "41.90059", :longitude => "-87.85673").save
City.new(:country_id => "233", :name => "Mokena", :aliases => ",Mokena", :latitude => "41.52614", :longitude => "-87.88922").save
City.new(:country_id => "233", :name => "Moline", :aliases => "Molin,ÐÐ¾Ð»Ð¸Ð½,Moline", :latitude => "41.5067", :longitude => "-90.51513").save
City.new(:country_id => "233", :name => "Morton", :aliases => ",Morton", :latitude => "40.61282", :longitude => "-89.45926").save
City.new(:country_id => "233", :name => "Morton Grove", :aliases => ",Morton Grove", :latitude => "42.04059", :longitude => "-87.78256").save
City.new(:country_id => "233", :name => "Mount Prospect", :aliases => ",Mount Prospect", :latitude => "42.06642", :longitude => "-87.93729").save
City.new(:country_id => "233", :name => "Mundelein", :aliases => ",Mundelein", :latitude => "42.26308", :longitude => "-88.00397").save
City.new(:country_id => "233", :name => "Naperville", :aliases => "Naperville,Naperville", :latitude => "41.78586", :longitude => "-88.14729").save
City.new(:country_id => "233", :name => "New Lenox", :aliases => ",New Lenox", :latitude => "41.51198", :longitude => "-87.96561").save
City.new(:country_id => "233", :name => "Niles", :aliases => ",Niles", :latitude => "42.01892", :longitude => "-87.80284").save
City.new(:country_id => "233", :name => "Normal", :aliases => "Normal'naja,ÐÐ¾ÑÐ¼Ð°Ð»ÑÐ½Ð°Ñ,Normal", :latitude => "40.5142", :longitude => "-88.99063").save
City.new(:country_id => "233", :name => "North Chicago", :aliases => ",North Chicago", :latitude => "42.32558", :longitude => "-87.84118").save
City.new(:country_id => "233", :name => "North Peoria", :aliases => ",North Peoria", :latitude => "40.71754", :longitude => "-89.58426").save
City.new(:country_id => "233", :name => "Northbrook", :aliases => ",Northbrook", :latitude => "42.12753", :longitude => "-87.82895").save
City.new(:country_id => "233", :name => "Oak Forest", :aliases => ",Oak Forest", :latitude => "41.60281", :longitude => "-87.74394").save
City.new(:country_id => "233", :name => "Oak Lawn", :aliases => ",Oak Lawn", :latitude => "41.71087", :longitude => "-87.75811").save
City.new(:country_id => "233", :name => "Oak Park", :aliases => "Ouk-Park,ÐÑÐº-ÐÐ°ÑÐº,Oak Park", :latitude => "41.88503", :longitude => "-87.7845").save
City.new(:country_id => "233", :name => "Orland Park", :aliases => ",Orland Park", :latitude => "41.63031", :longitude => "-87.85394").save
City.new(:country_id => "233", :name => "Oswego", :aliases => ",Oswego", :latitude => "41.68281", :longitude => "-88.35146").save
City.new(:country_id => "233", :name => "Ottawa", :aliases => ",Ottawa", :latitude => "41.34559", :longitude => "-88.84258").save
City.new(:country_id => "233", :name => "Palatine", :aliases => "Palatin,Palatine,ÐÐ°Ð»Ð°ÑÐ¸Ð½,Palatine", :latitude => "42.1103", :longitude => "-88.03424").save
City.new(:country_id => "233", :name => "Palos Hills", :aliases => ",Palos Hills", :latitude => "41.6967", :longitude => "-87.817").save
City.new(:country_id => "233", :name => "Park Forest", :aliases => ",Park Forest", :latitude => "41.49142", :longitude => "-87.67449").save
City.new(:country_id => "233", :name => "Park Ridge", :aliases => ",Park Ridge", :latitude => "42.01114", :longitude => "-87.84062").save
City.new(:country_id => "233", :name => "Pekin", :aliases => "Pekin,ÐÐµÐºÐ¸Ð½,Pekin", :latitude => "40.56754", :longitude => "-89.64066").save
City.new(:country_id => "233", :name => "Peoria", :aliases => "Peoria,Peorija,pi ao li ya,ÐÐµÐ¾ÑÐ¸Ñ,ç®å¥¥éäº,Peoria", :latitude => "40.69365", :longitude => "-89.58899").save
City.new(:country_id => "233", :name => "Plainfield", :aliases => ",Plainfield", :latitude => "41.62697", :longitude => "-88.20395").save
City.new(:country_id => "233", :name => "Prospect Heights", :aliases => ",Prospect Heights", :latitude => "42.0953", :longitude => "-87.93757").save
City.new(:country_id => "233", :name => "Rock Island", :aliases => "Rok-Ajlend,Ð Ð¾Ðº-ÐÐ¹Ð»ÐµÐ½Ð´,Rock Island", :latitude => "41.50948", :longitude => "-90.57875").save
City.new(:country_id => "233", :name => "Rockford", :aliases => "Rockford,rakaphorda,à¦°à¦à¦«à§à¦°à§à¦¡,Rockford", :latitude => "42.27113", :longitude => "-89.094").save
City.new(:country_id => "233", :name => "Rolling Meadows", :aliases => ",Rolling Meadows", :latitude => "42.08419", :longitude => "-88.01313").save
City.new(:country_id => "233", :name => "Romeoville", :aliases => ",Romeoville", :latitude => "41.64753", :longitude => "-88.08951").save
City.new(:country_id => "233", :name => "Roselle", :aliases => ",Roselle", :latitude => "41.98475", :longitude => "-88.07979").save
City.new(:country_id => "233", :name => "Saint Charles", :aliases => "Sent-Charl'z,Ð¡ÐµÐ½Ñ-Ð§Ð°ÑÐ»ÑÐ·,Saint Charles", :latitude => "41.91419", :longitude => "-88.30869").save
City.new(:country_id => "233", :name => "Schaumburg", :aliases => "Schaumburg,Shaumburg,shainbagu,shao mu bao,Ð¨Ð°ÑÐ¼Ð±ÑÑÐ³,ã·ã£ã¤ã³ãã¼ã°,ç»å§å ¡,Schaumburg", :latitude => "42.03336", :longitude => "-88.08341").save
City.new(:country_id => "233", :name => "Skokie", :aliases => "Skokie,Skokie", :latitude => "42.03336", :longitude => "-87.73339").save
City.new(:country_id => "233", :name => "South Elgin", :aliases => ",South Elgin", :latitude => "41.99419", :longitude => "-88.2923").save
City.new(:country_id => "233", :name => "South Holland", :aliases => ",South Holland", :latitude => "41.60087", :longitude => "-87.60699").save
City.new(:country_id => "233", :name => "Sterling", :aliases => "Sterling,Ð¡ÑÐµÑÐ»Ð¸Ð½Ð³,Sterling", :latitude => "41.78864", :longitude => "-89.69622").save
City.new(:country_id => "233", :name => "Streamwood", :aliases => ",Streamwood", :latitude => "42.02558", :longitude => "-88.17841").save
City.new(:country_id => "233", :name => "Tinley Park", :aliases => ",Tinley Park", :latitude => "41.57337", :longitude => "-87.78449").save
City.new(:country_id => "233", :name => "Urbana", :aliases => "Urbana,arbana,Ð£ÑÐ±Ð°Ð½Ð°,à¦à¦°à§à¦¬à¦¾à¦¨à¦¾,Urbana", :latitude => "40.11059", :longitude => "-88.20727").save
City.new(:country_id => "233", :name => "Vernon Hills", :aliases => ",Vernon Hills", :latitude => "42.21809", :longitude => "-87.96513").save
City.new(:country_id => "233", :name => "Villa Park", :aliases => ",Villa Park", :latitude => "41.88975", :longitude => "-87.98895").save
City.new(:country_id => "233", :name => "Waukegan", :aliases => "Waukegan,Waukegan", :latitude => "42.36363", :longitude => "-87.84479").save
City.new(:country_id => "233", :name => "West Chicago", :aliases => ",West Chicago", :latitude => "41.88475", :longitude => "-88.20396").save
City.new(:country_id => "233", :name => "Westchester", :aliases => "Vestchester,ÐÐµÑÑÑÐµÑÑÐµÑ,Westchester", :latitude => "41.85059", :longitude => "-87.882").save
City.new(:country_id => "233", :name => "Westmont", :aliases => ",Westmont", :latitude => "41.79586", :longitude => "-87.97562").save
City.new(:country_id => "233", :name => "Wheaton", :aliases => "Uiton,Ð£Ð¸ÑÐ¾Ð½,Wheaton", :latitude => "41.86614", :longitude => "-88.10701").save
City.new(:country_id => "233", :name => "Wheeling", :aliases => ",Wheeling", :latitude => "42.13919", :longitude => "-87.92896").save
City.new(:country_id => "233", :name => "Wilmette", :aliases => ",Wilmette", :latitude => "42.07225", :longitude => "-87.72284").save
City.new(:country_id => "233", :name => "Woodridge", :aliases => ",Woodridge", :latitude => "41.74697", :longitude => "-88.05034").save
City.new(:country_id => "233", :name => "Woodstock", :aliases => "Vudstok,ÐÑÐ´ÑÑÐ¾Ðº,Woodstock", :latitude => "42.31474", :longitude => "-88.4487").save
City.new(:country_id => "233", :name => "Zion", :aliases => "Sion,Ð¡Ð¸Ð¾Ð½,Zion", :latitude => "42.44613", :longitude => "-87.83285").save
City.new(:country_id => "233", :name => "Anderson", :aliases => "Anderson,ÐÐ½Ð´ÐµÑÑÐ¾Ð½,Anderson", :latitude => "40.10532", :longitude => "-85.68025").save
City.new(:country_id => "233", :name => "Crawfordsville", :aliases => ",Crawfordsville", :latitude => "40.04115", :longitude => "-86.87445").save
City.new(:country_id => "233", :name => "Crown Point", :aliases => ",Crown Point", :latitude => "41.41698", :longitude => "-87.36531").save
City.new(:country_id => "233", :name => "Dyer", :aliases => ",Dyer", :latitude => "41.4942", :longitude => "-87.52171").save
City.new(:country_id => "233", :name => "East Chicago", :aliases => ",East Chicago", :latitude => "41.6392", :longitude => "-87.45476").save
City.new(:country_id => "233", :name => "Elkhart", :aliases => "Ehlkkhart,Ð­Ð»ÐºÑÐ°ÑÑ,Elkhart", :latitude => "41.68199", :longitude => "-85.97667").save
City.new(:country_id => "233", :name => "Fort Wayne", :aliases => "Castrum Vainense,Fort Wayne,Fort Wayne", :latitude => "41.1306", :longitude => "-85.12886").save
City.new(:country_id => "233", :name => "Frankfort", :aliases => "Frankfurt,Ð¤ÑÐ°Ð½ÐºÑÑÑÑ,Frankfort", :latitude => "40.27948", :longitude => "-86.51084").save
City.new(:country_id => "233", :name => "Gary", :aliases => "Gary,geri,jia li,ã²ã¼ãªã¼,å é,Gary", :latitude => "41.59337", :longitude => "-87.34643").save
City.new(:country_id => "233", :name => "Goshen", :aliases => "Goshen,ÐÐ¾ÑÐµÐ½,Goshen", :latitude => "41.58227", :longitude => "-85.83444").save
City.new(:country_id => "233", :name => "Granger", :aliases => ",Granger", :latitude => "41.74813", :longitude => "-86.12569").save
City.new(:country_id => "233", :name => "Griffith", :aliases => ",Griffith", :latitude => "41.52837", :longitude => "-87.42365").save
City.new(:country_id => "233", :name => "Hammond", :aliases => "Hammond,Khammond,Ð¥Ð°Ð¼Ð¼Ð¾Ð½Ð´,Hammond", :latitude => "41.58337", :longitude => "-87.50004").save
City.new(:country_id => "233", :name => "Highland", :aliases => ",Highland", :latitude => "41.55365", :longitude => "-87.45198").save
City.new(:country_id => "233", :name => "Hobart", :aliases => "Khobart,Ð¥Ð¾Ð±Ð°ÑÑ,Hobart", :latitude => "41.53226", :longitude => "-87.25504").save
City.new(:country_id => "233", :name => "Huntington", :aliases => "Khantington,Ð¥Ð°Ð½ÑÐ¸Ð½Ð³ÑÐ¾Ð½,Huntington", :latitude => "40.8831", :longitude => "-85.49748").save
City.new(:country_id => "233", :name => "Kokomo", :aliases => ",Kokomo", :latitude => "40.48643", :longitude => "-86.1336").save
City.new(:country_id => "233", :name => "LaPorte", :aliases => ",LaPorte", :latitude => "41.6106", :longitude => "-86.72252").save
City.new(:country_id => "233", :name => "Lafayette", :aliases => "Lafajet,Lafayette,rafaietto,ÐÐ°ÑÐ°Ð¹ÐµÑ,ã©ãã¡ã¤ã¨ãã,Lafayette", :latitude => "40.4167", :longitude => "-86.87529").save
City.new(:country_id => "233", :name => "Logansport", :aliases => ",Logansport", :latitude => "40.75448", :longitude => "-86.35667").save
City.new(:country_id => "233", :name => "Marion", :aliases => "Mehrion,ÐÑÑÐ¸Ð¾Ð½,Marion", :latitude => "40.55837", :longitude => "-85.65914").save
City.new(:country_id => "233", :name => "Merrillville", :aliases => ",Merrillville", :latitude => "41.48281", :longitude => "-87.33281").save
City.new(:country_id => "233", :name => "Michigan City", :aliases => "Michigan-Siti,ÐÐ¸ÑÐ¸Ð³Ð°Ð½-Ð¡Ð¸ÑÐ¸,Michigan City", :latitude => "41.70754", :longitude => "-86.89503").save
City.new(:country_id => "233", :name => "Mishawaka", :aliases => ",Mishawaka", :latitude => "41.66199", :longitude => "-86.15862").save
City.new(:country_id => "233", :name => "Muncie", :aliases => "Mansi,Muncie,ÐÐ°Ð½ÑÐ¸,Muncie", :latitude => "40.19338", :longitude => "-85.38636").save
City.new(:country_id => "233", :name => "Munster", :aliases => "Mjunster,ÐÑÐ½ÑÑÐµÑ,Munster", :latitude => "41.56448", :longitude => "-87.51254").save
City.new(:country_id => "233", :name => "Noblesville", :aliases => ",Noblesville", :latitude => "40.04559", :longitude => "-86.0086").save
City.new(:country_id => "233", :name => "Portage", :aliases => ",Portage", :latitude => "41.57587", :longitude => "-87.17615").save
City.new(:country_id => "233", :name => "Schererville", :aliases => ",Schererville", :latitude => "41.47892", :longitude => "-87.45476").save
City.new(:country_id => "233", :name => "South Bend", :aliases => "Flexuvium Australe,South Bend,sausubendo,ãµã¦ã¹ãã³ã,South Bend", :latitude => "41.68338", :longitude => "-86.25001").save
City.new(:country_id => "233", :name => "Valparaiso", :aliases => "Val'paraiso,ÐÐ°Ð»ÑÐ¿Ð°ÑÐ°Ð¸ÑÐ¾,Valparaiso", :latitude => "41.47309", :longitude => "-87.06114").save
City.new(:country_id => "233", :name => "West Lafayette", :aliases => ",West Lafayette", :latitude => "40.42587", :longitude => "-86.90807").save
City.new(:country_id => "233", :name => "Abington", :aliases => ",Abington", :latitude => "42.10482", :longitude => "-70.94532").save
City.new(:country_id => "233", :name => "Acton", :aliases => "Ehkton,Ð­ÐºÑÐ¾Ð½,Acton", :latitude => "42.48509", :longitude => "-71.43284").save
City.new(:country_id => "233", :name => "Agawam", :aliases => ",Agawam", :latitude => "42.06954", :longitude => "-72.61481").save
City.new(:country_id => "233", :name => "Amesbury", :aliases => ",Amesbury", :latitude => "42.85842", :longitude => "-70.93005").save
City.new(:country_id => "233", :name => "Amherst Center", :aliases => ",Amherst Center", :latitude => "42.37537", :longitude => "-72.51925").save
City.new(:country_id => "233", :name => "Andover", :aliases => ",Andover", :latitude => "42.65843", :longitude => "-71.137").save
City.new(:country_id => "233", :name => "Arlington", :aliases => "Arlington,ÐÑÐ»Ð¸Ð½Ð³ÑÐ¾Ð½,Arlington", :latitude => "42.41537", :longitude => "-71.15644").save
City.new(:country_id => "233", :name => "Ashland", :aliases => ",Ashland", :latitude => "42.26121", :longitude => "-71.4634").save
City.new(:country_id => "233", :name => "Attleboro", :aliases => ",Attleboro", :latitude => "41.94454", :longitude => "-71.28561").save
City.new(:country_id => "233", :name => "Auburn", :aliases => ",Auburn", :latitude => "42.19454", :longitude => "-71.83563").save
City.new(:country_id => "233", :name => "Barnstable", :aliases => ",Barnstable", :latitude => "41.70011", :longitude => "-70.29947").save
City.new(:country_id => "233", :name => "Belchertown", :aliases => ",Belchertown", :latitude => "42.27704", :longitude => "-72.40092").save
City.new(:country_id => "233", :name => "Bellingham", :aliases => ",Bellingham", :latitude => "42.08676", :longitude => "-71.47451").save
City.new(:country_id => "233", :name => "Belmont", :aliases => "Belmont,ÐÐµÐ»Ð¼Ð¾Ð½Ñ,Belmont", :latitude => "42.39593", :longitude => "-71.17867").save
City.new(:country_id => "233", :name => "Beverly", :aliases => ",Beverly", :latitude => "42.55843", :longitude => "-70.88005").save
City.new(:country_id => "233", :name => "Beverly Cove", :aliases => ",Beverly Cove", :latitude => "42.55343", :longitude => "-70.85366").save
City.new(:country_id => "233", :name => "Billerica", :aliases => ",Billerica", :latitude => "42.55843", :longitude => "-71.26895").save
City.new(:country_id => "233", :name => "Boston", :aliases => "Boston,Bostona,Bostonas,Bostone,Bostonia,Bostono,Bostun,BostÃºn,Gorad Bostan,Pokekona,Vostoni,bastana,bo shi dun,boseuteon,bostan,bostana,bosuton,bwstn,bwstwn,bxstan,pastan,ÎÎ¿ÏÏÏÎ½Î·,ÎÎ¿ÏÏÏÎ½Î·,ÐÐ¾ÑÑÐ¾Ð½,ÐÐ¾ÑÑÑÐ½,ÐÐ¾ÑÐ°Ð´ ÐÐ¾ÑÑÐ°Ð½,×××¡×××,×××¡×××,Ø¨ÙØ³ØªÙÙ,Ø¨ÙØ³Ø·Ù,Ø¨ÙØ³Ù¹Ù,ÜÜÜ£ÜÜÜ¢,à¤¬à¥à¤¸à¥à¤à¤¨,à¤¬à¥à¤¸à¥à¤à¤¨,à¦¬à¦¸à§à¦à¦¨,à®ªà®¾à®¸à¯à®à®©à¯,à°¬à±à°¸à±à°à°¨à±,à´¬àµà´¸àµà´±àµà´±à´£àµâ,à¸à¸­à¸ªà¸à¸±à¸,à½à½¼à¼à½¦à½ºà¼à½à½¼à½à¼,ááá¡á¢ááá,ãã¹ãã³,æ³¢å£«é¡¿,ë³´ì¤í´,Boston", :latitude => "42.35843", :longitude => "-71.05977").save
City.new(:country_id => "233", :name => "Bourne", :aliases => ",Bourne", :latitude => "41.74122", :longitude => "-70.59892").save
City.new(:country_id => "233", :name => "Braintree", :aliases => ",Braintree", :latitude => "42.22232", :longitude => "-70.99949").save
City.new(:country_id => "233", :name => "Brewster", :aliases => "Brjuster,ÐÑÑÑÑÐµÑ,Brewster", :latitude => "41.76011", :longitude => "-70.0828").save
City.new(:country_id => "233", :name => "Bridgewater", :aliases => "Bridzhuoter,ÐÑÐ¸Ð´Ð¶ÑÐ¾ÑÐµÑ,Bridgewater", :latitude => "41.99038", :longitude => "-70.97504").save
City.new(:country_id => "233", :name => "Brockton", :aliases => "Brockton,Brockton", :latitude => "42.08343", :longitude => "-71.01838").save
City.new(:country_id => "233", :name => "Brookline", :aliases => "Brookline,Bruklin,bu lu ke lai en,ÐÑÑÐºÐ»Ð¸Ð½,å¸é²åè±æ©,Brookline", :latitude => "42.33176", :longitude => "-71.12116").save
City.new(:country_id => "233", :name => "Burlington", :aliases => "Berlington,ÐÐµÑÐ»Ð¸Ð½Ð³ÑÐ¾Ð½,Burlington", :latitude => "42.50482", :longitude => "-71.19561").save
City.new(:country_id => "233", :name => "Cambridge", :aliases => "Cambridge,Cantabrigia iuxta Flumen Carolanum,Kejmbridzh,Kembridzh,Kembrigo,KembriÄo,jian qiao,kambrydj,kan bu li qi,keimbeuliji,kenburijji,khem bridc,ÐÐµÐ¹Ð¼Ð±ÑÐ¸Ð´Ð¶,ÐÐµÐ¼Ð±ÑÐ¸Ð´Ð¶,ÙØ§ÙØ¨Ø±ÙØ¯Ø¬,à¹à¸à¸¡à¸à¸£à¸´à¸à¸à¹,ã±ã³ããªãã¸,åæ¡¥,åå¸éå¥,ì¼ìë¸ë¦¬ì§,Cambridge", :latitude => "42.3751", :longitude => "-71.10561").save
City.new(:country_id => "233", :name => "Canton", :aliases => ",Canton", :latitude => "42.15843", :longitude => "-71.14477").save
City.new(:country_id => "233", :name => "Chelmsford", :aliases => "Chelmsford,Ð§ÐµÐ»Ð¼ÑÑÐ¾ÑÐ´,Chelmsford", :latitude => "42.59981", :longitude => "-71.36728").save
City.new(:country_id => "233", :name => "Chelsea", :aliases => ",Chelsea", :latitude => "42.39176", :longitude => "-71.03283").save
City.new(:country_id => "233", :name => "Chicopee", :aliases => ",Chicopee", :latitude => "42.17256", :longitude => "-72.59491").save
City.new(:country_id => "233", :name => "Clinton", :aliases => "Klinton,ÐÐ»Ð¸Ð½ÑÐ¾Ð½,Clinton", :latitude => "42.41676", :longitude => "-71.68285").save
City.new(:country_id => "233", :name => "Concord", :aliases => "Konkord,ÐÐ¾Ð½ÐºÐ¾ÑÐ´,Concord", :latitude => "42.46037", :longitude => "-71.34895").save
City.new(:country_id => "233", :name => "Danvers", :aliases => "Denvers,ÐÐµÐ½Ð²ÐµÑÑ,Danvers", :latitude => "42.57509", :longitude => "-70.93005").save
City.new(:country_id => "233", :name => "Dedham", :aliases => ",Dedham", :latitude => "42.24177", :longitude => "-71.16616").save
City.new(:country_id => "233", :name => "Dennis", :aliases => "Dennis,ÐÐµÐ½Ð½Ð¸Ñ,Dennis", :latitude => "41.73539", :longitude => "-70.19391").save
City.new(:country_id => "233", :name => "Dracut", :aliases => ",Dracut", :latitude => "42.67037", :longitude => "-71.30201").save
City.new(:country_id => "233", :name => "Duxbury", :aliases => ",Duxbury", :latitude => "42.04177", :longitude => "-70.67226").save
City.new(:country_id => "233", :name => "East Longmeadow", :aliases => ",East Longmeadow", :latitude => "42.06454", :longitude => "-72.51259").save
City.new(:country_id => "233", :name => "Easthampton", :aliases => ",Easthampton", :latitude => "42.26676", :longitude => "-72.66898").save
City.new(:country_id => "233", :name => "Easton", :aliases => "Iston,ÐÑÑÐ¾Ð½,Easton", :latitude => "42.02454", :longitude => "-71.12866").save
City.new(:country_id => "233", :name => "Everett", :aliases => "Ehverett,Ð­Ð²ÐµÑÐµÑÑ,Everett", :latitude => "42.40843", :longitude => "-71.05366").save
City.new(:country_id => "233", :name => "Fairhaven", :aliases => ",Fairhaven", :latitude => "41.6376", :longitude => "-70.90365").save
City.new(:country_id => "233", :name => "Fall River", :aliases => "Fall River,Fall River", :latitude => "41.70149", :longitude => "-71.15505").save
City.new(:country_id => "233", :name => "Falmouth", :aliases => ",Falmouth", :latitude => "41.5515", :longitude => "-70.61475").save
City.new(:country_id => "233", :name => "Fitchburg", :aliases => ",Fitchburg", :latitude => "42.58342", :longitude => "-71.8023").save
City.new(:country_id => "233", :name => "Foxborough", :aliases => "Foxboro,Foxborough,Foxborough", :latitude => "42.06538", :longitude => "-71.24783").save
City.new(:country_id => "233", :name => "Framingham", :aliases => ",Framingham", :latitude => "42.27926", :longitude => "-71.41617").save
City.new(:country_id => "233", :name => "Framingham Center", :aliases => ",Framingham Center", :latitude => "42.29732", :longitude => "-71.43701").save
City.new(:country_id => "233", :name => "Franklin", :aliases => "Franklin,Ð¤ÑÐ°Ð½ÐºÐ»Ð¸Ð½,Franklin", :latitude => "42.08343", :longitude => "-71.39672").save
City.new(:country_id => "233", :name => "Gardner", :aliases => "Gardner,ÐÐ°ÑÐ´Ð½ÐµÑ,Gardner", :latitude => "42.57509", :longitude => "-71.99813").save
City.new(:country_id => "233", :name => "Gloucester", :aliases => "Gloster,ÐÐ»Ð¾ÑÑÐµÑ,Gloucester", :latitude => "42.61593", :longitude => "-70.66199").save
City.new(:country_id => "233", :name => "Grafton", :aliases => ",Grafton", :latitude => "42.20704", :longitude => "-71.68562").save
City.new(:country_id => "233", :name => "Greenfield", :aliases => "Grinfild,ÐÑÐ¸Ð½ÑÐ¸Ð»Ð´,Greenfield", :latitude => "42.58759", :longitude => "-72.59953").save
City.new(:country_id => "233", :name => "Hanson", :aliases => ",Hanson", :latitude => "42.0751", :longitude => "-70.88004").save
City.new(:country_id => "233", :name => "Hanover", :aliases => ",Hanover", :latitude => "42.11316", :longitude => "-70.81199").save
City.new(:country_id => "233", :name => "Haverhill", :aliases => "Haverhill,Khaverkhill,Ð¥Ð°Ð²ÐµÑÑÐ¸Ð»Ð»,Haverhill", :latitude => "42.7762", :longitude => "-71.07728").save
City.new(:country_id => "233", :name => "Hingham", :aliases => ",Hingham", :latitude => "42.24177", :longitude => "-70.88977").save
City.new(:country_id => "233", :name => "Holden", :aliases => ",Holden", :latitude => "42.35176", :longitude => "-71.86341").save
City.new(:country_id => "233", :name => "Holyoke", :aliases => ",Holyoke", :latitude => "42.20426", :longitude => "-72.6162").save
City.new(:country_id => "233", :name => "Hopkinton", :aliases => "Khopkinton,Ð¥Ð¾Ð¿ÐºÐ¸Ð½ÑÐ¾Ð½,Hopkinton", :latitude => "42.22871", :longitude => "-71.52256").save
City.new(:country_id => "233", :name => "Hudson", :aliases => "Gudzon,ÐÑÐ´Ð·Ð¾Ð½,Hudson", :latitude => "42.39176", :longitude => "-71.56618").save
City.new(:country_id => "233", :name => "Ipswich", :aliases => ",Ipswich", :latitude => "42.67926", :longitude => "-70.84116").save
City.new(:country_id => "233", :name => "Kingston", :aliases => "Kingston,ÐÐ¸Ð½Ð³ÑÑÐ¾Ð½,Kingston", :latitude => "41.99455", :longitude => "-70.72448").save
City.new(:country_id => "233", :name => "Lawrence", :aliases => "Lawrence,Lourens,ÐÐ¾ÑÑÐµÐ½Ñ,Lawrence", :latitude => "42.70704", :longitude => "-71.16311").save
City.new(:country_id => "233", :name => "Leominster", :aliases => "Leominstere,ÐÐµÐ¾Ð¼Ð¸Ð½ÑÑÐµÑÐµ,Leominster", :latitude => "42.52509", :longitude => "-71.75979").save
City.new(:country_id => "233", :name => "Lexington", :aliases => "Leksington,Lexington,rekishinton,ÐÐµÐºÑÐ¸Ð½Ð³ÑÐ¾Ð½,ã¬ã­ã·ã³ãã³,Lexington", :latitude => "42.44732", :longitude => "-71.2245").save
City.new(:country_id => "233", :name => "Longmeadow", :aliases => ",Longmeadow", :latitude => "42.0501", :longitude => "-72.58287").save
City.new(:country_id => "233", :name => "Lowell", :aliases => "Loouell,Louel,Lowell,ÎÏÎ¿ÏÎµÎ»Î»,ÐÐ¾ÑÐµÐ»,Lowell", :latitude => "42.63342", :longitude => "-71.31617").save
City.new(:country_id => "233", :name => "Ludlow", :aliases => ",Ludlow", :latitude => "42.16009", :longitude => "-72.47592").save
City.new(:country_id => "233", :name => "Lunenburg", :aliases => ",Lunenburg", :latitude => "42.59453", :longitude => "-71.72452").save
City.new(:country_id => "233", :name => "Lynn", :aliases => "Lynn,Lynn", :latitude => "42.46676", :longitude => "-70.94949").save
City.new(:country_id => "233", :name => "Malden", :aliases => ",Malden", :latitude => "42.4251", :longitude => "-71.06616").save
City.new(:country_id => "233", :name => "Mansfield", :aliases => "Mehnsfild,ÐÑÐ½ÑÑÐ¸Ð»Ð´,Mansfield", :latitude => "42.03343", :longitude => "-71.21894").save
City.new(:country_id => "233", :name => "Marblehead", :aliases => ",Marblehead", :latitude => "42.5001", :longitude => "-70.85783").save
City.new(:country_id => "233", :name => "Marlborough", :aliases => "Marlboro,ÐÐ°ÑÐ»Ð±Ð¾ÑÐ¾,Marlborough", :latitude => "42.34909", :longitude => "-71.54546").save
City.new(:country_id => "233", :name => "Marshfield", :aliases => ",Marshfield", :latitude => "42.09177", :longitude => "-70.70559").save
City.new(:country_id => "233", :name => "Medford", :aliases => "Medford,ÐÐµÐ´ÑÐ¾ÑÐ´,Medford", :latitude => "42.41843", :longitude => "-71.10616").save
City.new(:country_id => "233", :name => "Melrose", :aliases => "Melrouz,ÐÐµÐ»ÑÐ¾ÑÐ·,Melrose", :latitude => "42.45843", :longitude => "-71.06616").save
City.new(:country_id => "233", :name => "Methuen", :aliases => ",Methuen", :latitude => "42.7262", :longitude => "-71.19089").save
City.new(:country_id => "233", :name => "Milford", :aliases => "Milford,ÐÐ¸Ð»ÑÐ¾ÑÐ´,Milford", :latitude => "42.13982", :longitude => "-71.51617").save
City.new(:country_id => "233", :name => "Milton", :aliases => "Mil'ton,ÐÐ¸Ð»ÑÑÐ¾Ð½,Milton", :latitude => "42.24954", :longitude => "-71.06616").save
City.new(:country_id => "233", :name => "Natick", :aliases => ",Natick", :latitude => "42.28343", :longitude => "-71.3495").save
City.new(:country_id => "233", :name => "Needham", :aliases => ",Needham", :latitude => "42.28343", :longitude => "-71.23283").save
City.new(:country_id => "233", :name => "New Bedford", :aliases => "N'ju-Bedford,New Bedford,xin bei de fu de,ÐÑÑ-ÐÐµÐ´ÑÐ¾ÑÐ´,æ°è´å¾·ç¦å¾·,New Bedford", :latitude => "41.63622", :longitude => "-70.9342").save
City.new(:country_id => "233", :name => "Newburyport", :aliases => ",Newburyport", :latitude => "42.81259", :longitude => "-70.87728").save
City.new(:country_id => "233", :name => "Newton", :aliases => "N'juton,Newton,nyuton,ÐÑÑÑÐ¾Ð½,ãã¥ã¼ãã³,Newton", :latitude => "42.33704", :longitude => "-71.20922").save
City.new(:country_id => "233", :name => "North Chicopee", :aliases => ",North Chicopee", :latitude => "42.18343", :longitude => "-72.59953").save
City.new(:country_id => "233", :name => "North Pembroke", :aliases => ",North Pembroke", :latitude => "42.09316", :longitude => "-70.79254").save
City.new(:country_id => "233", :name => "Northampton", :aliases => "Nortkhempton,ÐÐ¾ÑÑÑÐµÐ¼Ð¿ÑÐ¾Ð½,Northampton", :latitude => "42.32509", :longitude => "-72.6412").save
City.new(:country_id => "233", :name => "Northborough", :aliases => ",Northborough", :latitude => "42.31954", :longitude => "-71.64118").save
City.new(:country_id => "233", :name => "Norton", :aliases => ",Norton", :latitude => "41.96677", :longitude => "-71.18699").save
City.new(:country_id => "233", :name => "Norwood", :aliases => ",Norwood", :latitude => "42.19454", :longitude => "-71.1995").save
City.new(:country_id => "233", :name => "Oxford", :aliases => "Oksford,ÐÐºÑÑÐ¾ÑÐ´,Oxford", :latitude => "42.11676", :longitude => "-71.86479").save
City.new(:country_id => "233", :name => "Palmer", :aliases => ",Palmer", :latitude => "42.15843", :longitude => "-72.32869").save
City.new(:country_id => "233", :name => "Peabody", :aliases => "Pibodi,ÐÐ¸Ð±Ð¾Ð´Ð¸,Peabody", :latitude => "42.52787", :longitude => "-70.92866").save
City.new(:country_id => "233", :name => "Pepperell", :aliases => ",Pepperell", :latitude => "42.66592", :longitude => "-71.5884").save
City.new(:country_id => "233", :name => "Pittsfield", :aliases => ",Pittsfield", :latitude => "42.45008", :longitude => "-73.24538").save
City.new(:country_id => "233", :name => "Plymouth", :aliases => "Plimut,ÐÐ»Ð¸Ð¼ÑÑ,Plymouth", :latitude => "41.95844", :longitude => "-70.66726").save
City.new(:country_id => "233", :name => "Quincy", :aliases => "Kuinsi,ÐÑÐ¸Ð½ÑÐ¸,Quincy", :latitude => "42.25288", :longitude => "-71.00227").save
City.new(:country_id => "233", :name => "Randolph", :aliases => "Randol'f,Ð Ð°Ð½Ð´Ð¾Ð»ÑÑ,Randolph", :latitude => "42.1626", :longitude => "-71.04116").save
City.new(:country_id => "233", :name => "Reading", :aliases => "Reding,Ð ÐµÐ´Ð¸Ð½Ð³,Reading", :latitude => "42.52565", :longitude => "-71.09533").save
City.new(:country_id => "233", :name => "Rockland", :aliases => ",Rockland", :latitude => "42.13066", :longitude => "-70.91616").save
City.new(:country_id => "233", :name => "Salem", :aliases => "Salem,seiramu,Ð¡Ð°Ð»ÐµÐ¼,ã»ã¤ã©ã ,Salem", :latitude => "42.51954", :longitude => "-70.89672").save
City.new(:country_id => "233", :name => "Sandwich", :aliases => "Sehndvich,Ð¡ÑÐ½Ð´Ð²Ð¸Ñ,Sandwich", :latitude => "41.759", :longitude => "-70.49392").save
City.new(:country_id => "233", :name => "Saugus", :aliases => ",Saugus", :latitude => "42.46482", :longitude => "-71.01005").save
City.new(:country_id => "233", :name => "Scituate", :aliases => ",Scituate", :latitude => "42.19593", :longitude => "-70.72587").save
City.new(:country_id => "233", :name => "Sharon", :aliases => "Sharon,Ð¨Ð°ÑÐ¾Ð½,Sharon", :latitude => "42.12371", :longitude => "-71.17866").save
City.new(:country_id => "233", :name => "Shrewsbury", :aliases => "Shrusberi,Ð¨ÑÑÑÐ±ÐµÑÐ¸,Shrewsbury", :latitude => "42.29593", :longitude => "-71.71285").save
City.new(:country_id => "233", :name => "Somerset", :aliases => "Somerset,Ð¡Ð¾Ð¼ÐµÑÑÐµÑ,Somerset", :latitude => "41.76955", :longitude => "-71.12866").save
City.new(:country_id => "233", :name => "Somerville", :aliases => "Somerville,Somerville", :latitude => "42.3876", :longitude => "-71.0995").save
City.new(:country_id => "233", :name => "South Boston", :aliases => ",South Boston", :latitude => "42.33343", :longitude => "-71.04949").save
City.new(:country_id => "233", :name => "South Hadley", :aliases => ",South Hadley", :latitude => "42.25842", :longitude => "-72.57453").save
City.new(:country_id => "233", :name => "South Peabody", :aliases => ",South Peabody", :latitude => "42.50982", :longitude => "-70.94949").save
City.new(:country_id => "233", :name => "Southbridge", :aliases => ",Southbridge", :latitude => "42.0751", :longitude => "-72.03341").save
City.new(:country_id => "233", :name => "Springfield", :aliases => "Springfield,Springfild,si pu lin fei er de,supuringufirudo,Ð¡Ð¿ÑÐ¸Ð½Ð³ÑÐ¸Ð»Ð´,ã¹ããªã³ã°ãã£ã¼ã«ã,æ¯æ®æè²å°å¾·,Springfield", :latitude => "42.10148", :longitude => "-72.58981").save
City.new(:country_id => "233", :name => "Stoneham", :aliases => ",Stoneham", :latitude => "42.4801", :longitude => "-71.0995").save
City.new(:country_id => "233", :name => "Stoughton", :aliases => ",Stoughton", :latitude => "42.1251", :longitude => "-71.10227").save
City.new(:country_id => "233", :name => "Sudbury", :aliases => ",Sudbury", :latitude => "42.38343", :longitude => "-71.41617").save
City.new(:country_id => "233", :name => "Swansea", :aliases => ",Swansea", :latitude => "41.74816", :longitude => "-71.18977").save
City.new(:country_id => "233", :name => "Taunton", :aliases => ",Taunton", :latitude => "41.9001", :longitude => "-71.08977").save
City.new(:country_id => "233", :name => "Tewksbury", :aliases => ",Tewksbury", :latitude => "42.61065", :longitude => "-71.23422").save
City.new(:country_id => "233", :name => "Townsend", :aliases => ",Townsend", :latitude => "42.66676", :longitude => "-71.70507").save
City.new(:country_id => "233", :name => "Wakefield", :aliases => ",Wakefield", :latitude => "42.50648", :longitude => "-71.07283").save
City.new(:country_id => "233", :name => "Walpole", :aliases => "Uolpol,Ð£Ð¾Ð»Ð¿Ð¾Ð»,Walpole", :latitude => "42.14177", :longitude => "-71.2495").save
City.new(:country_id => "233", :name => "Waltham", :aliases => ",Waltham", :latitude => "42.37649", :longitude => "-71.23561").save
City.new(:country_id => "233", :name => "Wareham Center", :aliases => ",Wareham Center", :latitude => "41.76677", :longitude => "-70.72615").save
City.new(:country_id => "233", :name => "Watertown", :aliases => ",Watertown", :latitude => "42.37093", :longitude => "-71.18283").save
City.new(:country_id => "233", :name => "Webster", :aliases => ",Webster", :latitude => "42.0501", :longitude => "-71.88007").save
City.new(:country_id => "233", :name => "Wellesley", :aliases => "Uehlsli,Ð£ÑÐ»ÑÐ»Ð¸,Wellesley", :latitude => "42.29649", :longitude => "-71.29256").save
City.new(:country_id => "233", :name => "West Springfield", :aliases => ",West Springfield", :latitude => "42.10704", :longitude => "-72.62037").save
City.new(:country_id => "233", :name => "Westborough", :aliases => ",Westborough", :latitude => "42.26954", :longitude => "-71.61618").save
City.new(:country_id => "233", :name => "Westfield", :aliases => ",Westfield", :latitude => "42.12509", :longitude => "-72.74954").save
City.new(:country_id => "233", :name => "Westford", :aliases => ",Westford", :latitude => "42.57926", :longitude => "-71.43784").save
City.new(:country_id => "233", :name => "Weymouth", :aliases => ",Weymouth", :latitude => "42.22093", :longitude => "-70.93977").save
City.new(:country_id => "233", :name => "Wilbraham", :aliases => ",Wilbraham", :latitude => "42.12371", :longitude => "-72.43147").save
City.new(:country_id => "233", :name => "Wilmington", :aliases => "Uilmington,Ð£Ð¸Ð»Ð¼Ð¸Ð½Ð³ÑÐ¾Ð½,Wilmington", :latitude => "42.54648", :longitude => "-71.17367").save
City.new(:country_id => "233", :name => "Winchester", :aliases => ",Winchester", :latitude => "42.45232", :longitude => "-71.137").save
City.new(:country_id => "233", :name => "Winthrop", :aliases => ",Winthrop", :latitude => "42.3751", :longitude => "-70.98283").save
City.new(:country_id => "233", :name => "Woburn", :aliases => ",Woburn", :latitude => "42.47926", :longitude => "-71.15228").save
City.new(:country_id => "233", :name => "Worcester", :aliases => "Vuster,Worcester,usuta,ÐÑÑÑÐµÑ,ã¦ã¼ã¹ã¿ã¼,Worcester", :latitude => "42.26259", :longitude => "-71.80229").save
City.new(:country_id => "233", :name => "Yarmouth", :aliases => ",Yarmouth", :latitude => "41.70567", :longitude => "-70.22863").save
City.new(:country_id => "233", :name => "Auburn", :aliases => ",Auburn", :latitude => "44.09785", :longitude => "-70.23117").save
City.new(:country_id => "233", :name => "Augusta", :aliases => "Augusta,Ogasta,ao gu si ta,ogasuta,ÐÐ³Ð°ÑÑÐ°,ãªã¼ã¬ã¹ã¿,å¥¥å¤æ¯å¡,Augusta", :latitude => "44.31062", :longitude => "-69.77949").save
City.new(:country_id => "233", :name => "Bangor", :aliases => "Bangor,ÐÐ°Ð½Ð³Ð¾Ñ,Bangor", :latitude => "44.80118", :longitude => "-68.77781").save
City.new(:country_id => "233", :name => "Biddeford", :aliases => ",Biddeford", :latitude => "43.49258", :longitude => "-70.45338").save
City.new(:country_id => "233", :name => "Brunswick", :aliases => "Braunshvejg,ÐÑÐ°ÑÐ½ÑÐ²ÐµÐ¹Ð³,Brunswick", :latitude => "43.91452", :longitude => "-69.96533").save
City.new(:country_id => "233", :name => "Gorham", :aliases => "Gorkhehm,ÐÐ¾ÑÑÑÐ¼,Gorham", :latitude => "43.67952", :longitude => "-70.44422").save
City.new(:country_id => "233", :name => "Lewiston", :aliases => "L'juiston,ÐÑÑÐ¸ÑÑÐ¾Ð½,Lewiston", :latitude => "44.10035", :longitude => "-70.21478").save
City.new(:country_id => "233", :name => "North Windham", :aliases => ",North Windham", :latitude => "43.83424", :longitude => "-70.43839").save
City.new(:country_id => "233", :name => "Portland", :aliases => "Portland,Portlandia,Portlend,pwrtlnd,ÐÐ¾ÑÑÐ»ÐµÐ½Ð´,×¤××¨××× ×,Portland", :latitude => "43.66147", :longitude => "-70.25533").save
City.new(:country_id => "233", :name => "Saco", :aliases => ",Saco", :latitude => "43.50092", :longitude => "-70.44283").save
City.new(:country_id => "233", :name => "Sanford", :aliases => ",Sanford", :latitude => "43.43925", :longitude => "-70.77422").save
City.new(:country_id => "233", :name => "South Portland", :aliases => ",South Portland", :latitude => "43.64147", :longitude => "-70.24088").save
City.new(:country_id => "233", :name => "South Portland Gardens", :aliases => ",South Portland Gardens", :latitude => "43.63897", :longitude => "-70.31533").save
City.new(:country_id => "233", :name => "Waterville", :aliases => ",Waterville", :latitude => "44.55201", :longitude => "-69.63171").save
City.new(:country_id => "233", :name => "West Scarborough", :aliases => ",West Scarborough", :latitude => "43.57036", :longitude => "-70.38783").save
City.new(:country_id => "233", :name => "Westbrook", :aliases => ",Westbrook", :latitude => "43.67703", :longitude => "-70.37116").save
City.new(:country_id => "233", :name => "Adrian", :aliases => "Adrian,ÐÐ´ÑÐ¸Ð°Ð½,Adrian", :latitude => "41.89755", :longitude => "-84.03717").save
City.new(:country_id => "233", :name => "Allen Park", :aliases => ",Allen Park", :latitude => "42.25754", :longitude => "-83.21104").save
City.new(:country_id => "233", :name => "Ann Arbor", :aliases => "A2,Ann Arbor,Ann-Arbor,Arbaro de Ana,aina arbara,an nuo bao,anaba,ena arbar,ÐÐ½Ð½-ÐÑÐ±Ð¾Ñ,à¤à¤¨ à¤à¤°à¥à¤¬à¤°à¥,à¤à¤¨ à¤à¤°à¥à¤¬à¤°,ã¢ãã¼ãã¼,å®å¨å ¡,Ann Arbor", :latitude => "42.27756", :longitude => "-83.74088").save
City.new(:country_id => "233", :name => "Auburn Hills", :aliases => "Obern-Khills,ÐÐ±ÐµÑÐ½-Ð¥Ð¸Ð»Ð»Ñ,Auburn Hills", :latitude => "42.68753", :longitude => "-83.2341").save
City.new(:country_id => "233", :name => "Battle Creek", :aliases => ",Battle Creek", :latitude => "42.32115", :longitude => "-85.17971").save
City.new(:country_id => "233", :name => "Bay City", :aliases => "Bej-Siti,ÐÐµÐ¹-Ð¡Ð¸ÑÐ¸,Bay City", :latitude => "43.59447", :longitude => "-83.88886").save
City.new(:country_id => "233", :name => "Birmingham", :aliases => "Birmingem,ÐÐ¸ÑÐ¼Ð¸Ð½Ð³ÐµÐ¼,Birmingham", :latitude => "42.5467", :longitude => "-83.21132").save
City.new(:country_id => "233", :name => "Burton", :aliases => "Berton,ÐÐµÑÑÐ¾Ð½,Burton", :latitude => "42.99947", :longitude => "-83.61634").save
City.new(:country_id => "233", :name => "Canton", :aliases => ",Canton", :latitude => "42.30865", :longitude => "-83.48216").save
City.new(:country_id => "233", :name => "Clinton", :aliases => ",Clinton", :latitude => "42.58698", :longitude => "-82.91992").save
City.new(:country_id => "233", :name => "Cutlerville", :aliases => ",Cutlerville", :latitude => "42.84086", :longitude => "-85.66364").save
City.new(:country_id => "233", :name => "Dearborn", :aliases => "Dearborn,di er bo en,dyrbwrn,Ø¯ÙØ±Ø¨ÙØ±Ù,è¿ªå°ä¼¯æ©,Dearborn", :latitude => "42.32226", :longitude => "-83.17631").save
City.new(:country_id => "233", :name => "Dearborn Heights", :aliases => ",Dearborn Heights", :latitude => "42.33698", :longitude => "-83.27326").save
City.new(:country_id => "233", :name => "Detroit", :aliases => "DTT,Detroit,Detroitas,Detrojt,Detrojto,Ntetroit,detoroito,detro'ita,di te lu,dtrwyt,dytrwyt,ÎÏÎ·ÏÏÏÎ¹Ï,ÐÐµÑÑÐ¾Ð¸Ñ,ÐÐµÑÑÐ¾Ð¹Ñ,×××¨×××,××¢××¨×××,Ø¯ÙØªØ±ÙÙØª,à¤¡à¥à¤à¥à¤°à¥à¤à¤,ããã­ã¤ã,åºç¹å¾,Detroit", :latitude => "42.33143", :longitude => "-83.04575").save
City.new(:country_id => "233", :name => "East Lansing", :aliases => "Ist-Lansing,ÐÑÑ-ÐÐ°Ð½ÑÐ¸Ð½Ð³,East Lansing", :latitude => "42.73698", :longitude => "-84.48387").save
City.new(:country_id => "233", :name => "Eastpointe", :aliases => ",Eastpointe", :latitude => "42.46837", :longitude => "-82.95547").save
City.new(:country_id => "233", :name => "Farmington Hills", :aliases => ",Farmington Hills", :latitude => "42.48531", :longitude => "-83.37716").save
City.new(:country_id => "233", :name => "Ferndale", :aliases => ",Ferndale", :latitude => "42.46059", :longitude => "-83.13465").save
City.new(:country_id => "233", :name => "Flint", :aliases => "Flint,furinto,Ð¤Ð»Ð¸Ð½Ñ,ããªã³ã,Flint", :latitude => "43.01253", :longitude => "-83.68746").save
City.new(:country_id => "233", :name => "Forest Hills", :aliases => ",Forest Hills", :latitude => "42.95947", :longitude => "-85.48975").save
City.new(:country_id => "233", :name => "Garden City", :aliases => ",Garden City", :latitude => "42.32559", :longitude => "-83.33104").save
City.new(:country_id => "233", :name => "Grand Rapids", :aliases => "Grand Rapids,Grand-Rapids,ÐÑÐ°Ð½Ð´-Ð Ð°Ð¿Ð¸Ð´Ñ,Grand Rapids", :latitude => "42.96336", :longitude => "-85.66809").save
City.new(:country_id => "233", :name => "Grandville", :aliases => ",Grandville", :latitude => "42.90975", :longitude => "-85.76309").save
City.new(:country_id => "233", :name => "Grosse Pointe Woods", :aliases => ",Grosse Pointe Woods", :latitude => "42.44365", :longitude => "-82.90686").save
City.new(:country_id => "233", :name => "Hamtramck", :aliases => ",Hamtramck", :latitude => "42.39282", :longitude => "-83.04964").save
City.new(:country_id => "233", :name => "Hazel Park", :aliases => ",Hazel Park", :latitude => "42.46254", :longitude => "-83.10409").save
City.new(:country_id => "233", :name => "Highland Park", :aliases => "Khajlend Park,Ð¥Ð°Ð¹Ð»ÐµÐ½Ð´ ÐÐ°ÑÐº,Highland Park", :latitude => "42.40559", :longitude => "-83.09687").save
City.new(:country_id => "233", :name => "Holland", :aliases => "Gollandija,Holland,Misi-pawastik,Misi-pÃ¡wastik,ÐÐ¾Ð»Ð»Ð°Ð½Ð´Ð¸Ñ,Holland", :latitude => "42.78752", :longitude => "-86.10893").save
City.new(:country_id => "233", :name => "Jackson", :aliases => "Dzhekson,ÐÐ¶ÐµÐºÑÐ¾Ð½,Jackson", :latitude => "42.24587", :longitude => "-84.40135").save
City.new(:country_id => "233", :name => "Jenison", :aliases => ",Jenison", :latitude => "42.90725", :longitude => "-85.79198").save
City.new(:country_id => "233", :name => "Kalamazoo", :aliases => "Kalamazoo,Kalamazu,ka la ma zu,ÐÐ°Ð»Ð°Ð¼Ð°Ð·Ñ,å¡æé©¬ç¥,Kalamazoo", :latitude => "42.29171", :longitude => "-85.58723").save
City.new(:country_id => "233", :name => "Kentwood", :aliases => ",Kentwood", :latitude => "42.86947", :longitude => "-85.64475").save
City.new(:country_id => "233", :name => "Lansing", :aliases => "Lansing,Lensing,lan xin,ranshingu,ÐÐµÐ½ÑÐ¸Ð½Ð³,ã©ã³ã·ã³ã°,å°è¾,Lansing", :latitude => "42.73254", :longitude => "-84.55553").save
City.new(:country_id => "233", :name => "Lincoln Park", :aliases => ",Lincoln Park", :latitude => "42.25059", :longitude => "-83.17854").save
City.new(:country_id => "233", :name => "Livonia", :aliases => "Livonija,ÐÐ¸Ð²Ð¾Ð½Ð¸Ñ,Livonia", :latitude => "42.36837", :longitude => "-83.35271").save
City.new(:country_id => "233", :name => "Madison Heights", :aliases => ",Madison Heights", :latitude => "42.48587", :longitude => "-83.1052").save
City.new(:country_id => "233", :name => "Marquette", :aliases => "Markett,ÐÐ°ÑÐºÐµÑÑ,Marquette", :latitude => "46.54354", :longitude => "-87.39542").save
City.new(:country_id => "233", :name => "Midland", :aliases => ",Midland", :latitude => "43.61558", :longitude => "-84.24721").save
City.new(:country_id => "233", :name => "Monroe", :aliases => "Monro,ÐÐ¾Ð½ÑÐ¾,Monroe", :latitude => "41.91643", :longitude => "-83.39771").save
City.new(:country_id => "233", :name => "Mount Clemens", :aliases => "Mt. Clemens,Mount Clemens", :latitude => "42.59726", :longitude => "-82.87798").save
City.new(:country_id => "233", :name => "Mount Pleasant", :aliases => ",Mount Pleasant", :latitude => "43.59781", :longitude => "-84.76751").save
City.new(:country_id => "233", :name => "Muskegon", :aliases => ",Muskegon", :latitude => "43.23418", :longitude => "-86.24839").save
City.new(:country_id => "233", :name => "Northview", :aliases => ",Northview", :latitude => "43.04558", :longitude => "-85.60059").save
City.new(:country_id => "233", :name => "Norton Shores", :aliases => ",Norton Shores", :latitude => "43.1689", :longitude => "-86.26395").save
City.new(:country_id => "233", :name => "Novi", :aliases => "Novyj,ÐÐ¾Ð²ÑÐ¹,Novi", :latitude => "42.48059", :longitude => "-83.47549").save
City.new(:country_id => "233", :name => "Oak Park", :aliases => "Ouk-Park,ÐÑÐº-ÐÐ°ÑÐº,Oak Park", :latitude => "42.45948", :longitude => "-83.18271").save
City.new(:country_id => "233", :name => "Okemos", :aliases => ",Okemos", :latitude => "42.72226", :longitude => "-84.42747").save
City.new(:country_id => "233", :name => "Owosso", :aliases => ",Owosso", :latitude => "42.9978", :longitude => "-84.17664").save
City.new(:country_id => "233", :name => "Pontiac", :aliases => "Pontiac,Pontiac", :latitude => "42.63892", :longitude => "-83.29105").save
City.new(:country_id => "233", :name => "Port Huron", :aliases => ",Port Huron", :latitude => "42.97086", :longitude => "-82.42491").save
City.new(:country_id => "233", :name => "Portage", :aliases => ",Portage", :latitude => "42.20115", :longitude => "-85.58").save
City.new(:country_id => "233", :name => "Redford", :aliases => "Redford,Ð ÐµÐ´ÑÐ¾ÑÐ´,Redford", :latitude => "42.38337", :longitude => "-83.2966").save
City.new(:country_id => "233", :name => "Rochester Hills", :aliases => ",Rochester Hills", :latitude => "42.65837", :longitude => "-83.14993").save
City.new(:country_id => "233", :name => "Romulus", :aliases => "Romul,Ð Ð¾Ð¼ÑÐ»,Romulus", :latitude => "42.22226", :longitude => "-83.3966").save
City.new(:country_id => "233", :name => "Roseville", :aliases => "Rozvell,Ð Ð¾Ð·Ð²ÐµÐ»Ð»,Roseville", :latitude => "42.49726", :longitude => "-82.93714").save
City.new(:country_id => "233", :name => "Royal Oak", :aliases => ",Royal Oak", :latitude => "42.48948", :longitude => "-83.14465").save
City.new(:country_id => "233", :name => "Saginaw", :aliases => ",Saginaw", :latitude => "43.41947", :longitude => "-83.95081").save
City.new(:country_id => "233", :name => "Sault Sainte Marie", :aliases => ",Sault Sainte Marie", :latitude => "46.4953", :longitude => "-84.34532").save
City.new(:country_id => "233", :name => "Shelby", :aliases => ",Shelby", :latitude => "42.67087", :longitude => "-83.03298").save
City.new(:country_id => "233", :name => "Southfield", :aliases => "Southfield,Southfield", :latitude => "42.47337", :longitude => "-83.22187").save
City.new(:country_id => "233", :name => "Southgate", :aliases => ",Southgate", :latitude => "42.21393", :longitude => "-83.19381").save
City.new(:country_id => "233", :name => "Saint Clair Shores", :aliases => ",Saint Clair Shores", :latitude => "42.49698", :longitude => "-82.88881").save
City.new(:country_id => "233", :name => "Sterling Heights", :aliases => ",Sterling Heights", :latitude => "42.58031", :longitude => "-83.0302").save
City.new(:country_id => "233", :name => "Taylor", :aliases => "Tejlor,Ð¢ÐµÐ¹Ð»Ð¾Ñ,Taylor", :latitude => "42.24087", :longitude => "-83.26965").save
City.new(:country_id => "233", :name => "Trenton", :aliases => "Trenton,Ð¢ÑÐµÐ½ÑÐ¾Ð½,Trenton", :latitude => "42.13949", :longitude => "-83.17826").save
City.new(:country_id => "233", :name => "Troy", :aliases => "Troja,Troy,Ð¢ÑÐ¾Ñ,Troy", :latitude => "42.60559", :longitude => "-83.14993").save
City.new(:country_id => "233", :name => "Walker", :aliases => ",Walker", :latitude => "43.00141", :longitude => "-85.76809").save
City.new(:country_id => "233", :name => "Warren", :aliases => "Uorren,Warren,Ð£Ð¾ÑÑÐµÐ½,Warren", :latitude => "42.47754", :longitude => "-83.0277").save
City.new(:country_id => "233", :name => "Waterford", :aliases => "Uoterford,Ð£Ð¾ÑÐµÑÑÐ¾ÑÐ´,Waterford", :latitude => "42.70225", :longitude => "-83.40272").save
City.new(:country_id => "233", :name => "Waverly", :aliases => ",Waverly", :latitude => "42.7392", :longitude => "-84.62082").save
City.new(:country_id => "233", :name => "Wayne", :aliases => ",Wayne", :latitude => "42.28143", :longitude => "-83.38632").save
City.new(:country_id => "233", :name => "Westland", :aliases => ",Westland", :latitude => "42.3242", :longitude => "-83.40021").save
City.new(:country_id => "233", :name => "Wyandotte", :aliases => ",Wyandotte", :latitude => "42.21421", :longitude => "-83.14992").save
City.new(:country_id => "233", :name => "Wyoming", :aliases => ",Wyoming", :latitude => "42.91336", :longitude => "-85.70531").save
City.new(:country_id => "233", :name => "Ypsilanti", :aliases => "Ipsilanti,ÐÐ¿ÑÐ¸Ð»Ð°Ð½ÑÐ¸,Ypsilanti", :latitude => "42.24115", :longitude => "-83.61299").save
City.new(:country_id => "233", :name => "Albert Lea", :aliases => ",Albert Lea", :latitude => "43.64801", :longitude => "-93.36827").save
City.new(:country_id => "233", :name => "Andover", :aliases => ",Andover", :latitude => "45.2333", :longitude => "-93.29134").save
City.new(:country_id => "233", :name => "Anoka", :aliases => ",Anoka", :latitude => "45.19774", :longitude => "-93.38718").save
City.new(:country_id => "233", :name => "Apple Valley", :aliases => ",Apple Valley", :latitude => "44.73191", :longitude => "-93.21772").save
City.new(:country_id => "233", :name => "Austin", :aliases => "Ostin,ÐÑÑÐ¸Ð½,Austin", :latitude => "43.66663", :longitude => "-92.97464").save
City.new(:country_id => "233", :name => "Blaine", :aliases => ",Blaine", :latitude => "45.1608", :longitude => "-93.23495").save
City.new(:country_id => "233", :name => "Bloomington", :aliases => ",Bloomington", :latitude => "44.8408", :longitude => "-93.29828").save
City.new(:country_id => "233", :name => "Brooklyn Center", :aliases => ",Brooklyn Center", :latitude => "45.07608", :longitude => "-93.33273").save
City.new(:country_id => "233", :name => "Brooklyn Park", :aliases => ",Brooklyn Park", :latitude => "45.09413", :longitude => "-93.35634").save
City.new(:country_id => "233", :name => "Burnsville", :aliases => ",Burnsville", :latitude => "44.76774", :longitude => "-93.27772").save
City.new(:country_id => "233", :name => "Champlin", :aliases => ",Champlin", :latitude => "45.18885", :longitude => "-93.39745").save
City.new(:country_id => "233", :name => "Chanhassen", :aliases => ",Chanhassen", :latitude => "44.86219", :longitude => "-93.53079").save
City.new(:country_id => "233", :name => "Chaska", :aliases => ",Chaska", :latitude => "44.78941", :longitude => "-93.60218").save
City.new(:country_id => "233", :name => "Columbia Heights", :aliases => ",Columbia Heights", :latitude => "45.0408", :longitude => "-93.263").save
City.new(:country_id => "233", :name => "Coon Rapids", :aliases => ",Coon Rapids", :latitude => "45.11997", :longitude => "-93.28773").save
City.new(:country_id => "233", :name => "Cottage Grove", :aliases => ",Cottage Grove", :latitude => "44.82774", :longitude => "-92.94382").save
City.new(:country_id => "233", :name => "Crystal", :aliases => ",Crystal", :latitude => "45.03274", :longitude => "-93.36023").save
City.new(:country_id => "233", :name => "Duluth", :aliases => "Dulut,Duluth,ÐÑÐ»ÑÑ,Duluth", :latitude => "46.78327", :longitude => "-92.10658").save
City.new(:country_id => "233", :name => "Eagan", :aliases => ",Eagan", :latitude => "44.80413", :longitude => "-93.16689").save
City.new(:country_id => "233", :name => "Eden Prairie", :aliases => "Eden Prairie,Eden Prairie", :latitude => "44.85469", :longitude => "-93.47079").save
City.new(:country_id => "233", :name => "Edina", :aliases => ",Edina", :latitude => "44.88969", :longitude => "-93.34995").save
City.new(:country_id => "233", :name => "Elk River", :aliases => ",Elk River", :latitude => "45.30385", :longitude => "-93.56718").save
City.new(:country_id => "233", :name => "Faribault", :aliases => ",Faribault", :latitude => "44.29496", :longitude => "-93.26883").save
City.new(:country_id => "233", :name => "Farmington", :aliases => "Farmington,Ð¤Ð°ÑÐ¼Ð¸Ð½Ð³ÑÐ¾Ð½,Farmington", :latitude => "44.64024", :longitude => "-93.14355").save
City.new(:country_id => "233", :name => "Forest Lake", :aliases => ",Forest Lake", :latitude => "45.27886", :longitude => "-92.98522").save
City.new(:country_id => "233", :name => "Fridley", :aliases => ",Fridley", :latitude => "45.08608", :longitude => "-93.26328").save
City.new(:country_id => "233", :name => "Golden Valley", :aliases => ",Golden Valley", :latitude => "45.00969", :longitude => "-93.34912").save
City.new(:country_id => "233", :name => "Hastings", :aliases => "Khejstings,Ð¥ÐµÐ¹ÑÑÐ¸Ð½Ð³Ñ,Hastings", :latitude => "44.7433", :longitude => "-92.85243").save
City.new(:country_id => "233", :name => "Hibbing", :aliases => ",Hibbing", :latitude => "47.42715", :longitude => "-92.93769").save
City.new(:country_id => "233", :name => "Hopkins", :aliases => ",Hopkins", :latitude => "44.92496", :longitude => "-93.46273").save
City.new(:country_id => "233", :name => "Inver Grove Heights", :aliases => ",Inver Grove Heights", :latitude => "44.84802", :longitude => "-93.04272").save
City.new(:country_id => "233", :name => "Lakeville", :aliases => ",Lakeville", :latitude => "44.64969", :longitude => "-93.24272").save
City.new(:country_id => "233", :name => "Lino Lakes", :aliases => ",Lino Lakes", :latitude => "45.16024", :longitude => "-93.08883").save
City.new(:country_id => "233", :name => "Mankato", :aliases => ",Mankato", :latitude => "44.16358", :longitude => "-93.9994").save
City.new(:country_id => "233", :name => "Maple Grove", :aliases => ",Maple Grove", :latitude => "45.07246", :longitude => "-93.45579").save
City.new(:country_id => "233", :name => "Maplewood", :aliases => ",Maplewood", :latitude => "44.95302", :longitude => "-92.99522").save
City.new(:country_id => "233", :name => "Minneapolis", :aliases => "Mineapolis,Minneapolis,mineaporisu,ming ni a bo li si,mini'apolisa,ÐÐ¸Ð½ÐµÐ°Ð¿Ð¾Ð»Ð¸Ñ,ÐÐ¸Ð½Ð½ÐµÐ°Ð¿Ð¾Ð»Ð¸Ñ,××× ×××¤××××¡,à¤®à¤¿à¤¨à¥à¤à¤ªà¥à¤²à¤¿à¤¸,ããã¢ããªã¹,æå°¼é¿æ³¢å©æ¯,Minneapolis", :latitude => "44.97997", :longitude => "-93.26384").save
City.new(:country_id => "233", :name => "Minnetonka", :aliases => ",Minnetonka", :latitude => "44.9133", :longitude => "-93.50329").save
City.new(:country_id => "233", :name => "Minnetonka Mills", :aliases => ",Minnetonka Mills", :latitude => "44.94107", :longitude => "-93.4419").save
City.new(:country_id => "233", :name => "Moorhead", :aliases => ",Moorhead", :latitude => "46.87385", :longitude => "-96.76758").save
City.new(:country_id => "233", :name => "New Brighton", :aliases => ",New Brighton", :latitude => "45.06552", :longitude => "-93.20189").save
City.new(:country_id => "233", :name => "New Hope", :aliases => ",New Hope", :latitude => "45.03802", :longitude => "-93.38662").save
City.new(:country_id => "233", :name => "Northfield", :aliases => ",Northfield", :latitude => "44.4583", :longitude => "-93.1616").save
City.new(:country_id => "233", :name => "Oakdale", :aliases => ",Oakdale", :latitude => "44.96302", :longitude => "-92.96494").save
City.new(:country_id => "233", :name => "Owatonna", :aliases => ",Owatonna", :latitude => "44.08385", :longitude => "-93.22604").save
City.new(:country_id => "233", :name => "Plymouth", :aliases => ",Plymouth", :latitude => "45.01052", :longitude => "-93.45551").save
City.new(:country_id => "233", :name => "Prior Lake", :aliases => ",Prior Lake", :latitude => "44.7133", :longitude => "-93.42273").save
City.new(:country_id => "233", :name => "Ramsey", :aliases => ",Ramsey", :latitude => "45.2611", :longitude => "-93.45").save
City.new(:country_id => "233", :name => "Red Wing", :aliases => ",Red Wing", :latitude => "44.56247", :longitude => "-92.5338").save
City.new(:country_id => "233", :name => "Richfield", :aliases => ",Richfield", :latitude => "44.8833", :longitude => "-93.283").save
City.new(:country_id => "233", :name => "Rochester", :aliases => "Rochester,Ð Ð¾ÑÐµÑÑÐµÑ,Rochester", :latitude => "44.02163", :longitude => "-92.4699").save
City.new(:country_id => "233", :name => "Rosemount", :aliases => ",Rosemount", :latitude => "44.73941", :longitude => "-93.12577").save
City.new(:country_id => "233", :name => "Roseville", :aliases => "Rozvell,Ð Ð¾Ð·Ð²ÐµÐ»Ð»,Roseville", :latitude => "45.00608", :longitude => "-93.15661").save
City.new(:country_id => "233", :name => "Saint Cloud", :aliases => ",Saint Cloud", :latitude => "45.5608", :longitude => "-94.16249").save
City.new(:country_id => "233", :name => "Saint Louis Park", :aliases => ",Saint Louis Park", :latitude => "44.9483", :longitude => "-93.34801").save
City.new(:country_id => "233", :name => "Saint Michael", :aliases => ",Saint Michael", :latitude => "45.20996", :longitude => "-93.66496").save
City.new(:country_id => "233", :name => "Saint Paul", :aliases => "Saint Paul,Sanctus Paulus,St. Paul,seinteupol,sentoporu,ã»ã³ããã¼ã«,ì¸ì¸í¸í´,Saint Paul", :latitude => "44.94441", :longitude => "-93.09327").save
City.new(:country_id => "233", :name => "Savage", :aliases => ",Savage", :latitude => "44.77913", :longitude => "-93.33634").save
City.new(:country_id => "233", :name => "Shakopee", :aliases => "Shejkope,Ð¨ÐµÐ¹ÐºÐ¾Ð¿Ðµ,Shakopee", :latitude => "44.79802", :longitude => "-93.5269").save
City.new(:country_id => "233", :name => "Shoreview", :aliases => ",Shoreview", :latitude => "45.07913", :longitude => "-93.14717").save
City.new(:country_id => "233", :name => "South Saint Paul", :aliases => "South Saint Paul,South Saint Paul", :latitude => "44.89274", :longitude => "-93.03494").save
City.new(:country_id => "233", :name => "Stillwater", :aliases => ",Stillwater", :latitude => "45.05636", :longitude => "-92.80604").save
City.new(:country_id => "233", :name => "West Coon Rapids", :aliases => ",West Coon Rapids", :latitude => "45.15969", :longitude => "-93.34967").save
City.new(:country_id => "233", :name => "West Saint Paul", :aliases => ",West Saint Paul", :latitude => "44.91608", :longitude => "-93.10161").save
City.new(:country_id => "233", :name => "White Bear Lake", :aliases => ",White Bear Lake", :latitude => "45.08469", :longitude => "-93.00994").save
City.new(:country_id => "233", :name => "Willmar", :aliases => ",Willmar", :latitude => "45.12191", :longitude => "-95.04334").save
City.new(:country_id => "233", :name => "Winona", :aliases => "Vajnona,ÐÐ°Ð¹Ð½Ð¾Ð½Ð°,Winona", :latitude => "44.04996", :longitude => "-91.63932").save
City.new(:country_id => "233", :name => "Woodbury", :aliases => ",Woodbury", :latitude => "44.92386", :longitude => "-92.95938").save
City.new(:country_id => "233", :name => "Kirksville", :aliases => ",Kirksville", :latitude => "40.19475", :longitude => "-92.58325").save
City.new(:country_id => "233", :name => "Fargo", :aliases => "Fargo,fago,Ð¤Ð°ÑÐ³Ð¾,ãã¡ã¼ã´,Fargo", :latitude => "46.87719", :longitude => "-96.7898").save
City.new(:country_id => "233", :name => "Grand Forks", :aliases => "Grand Forks,Grand-Forks,ÐÑÐ°Ð½Ð´-Ð¤Ð¾ÑÐºÑ,Grand Forks", :latitude => "47.92526", :longitude => "-97.03285").save
City.new(:country_id => "233", :name => "Jamestown", :aliases => ",Jamestown", :latitude => "46.91054", :longitude => "-98.70844").save
City.new(:country_id => "233", :name => "West Fargo", :aliases => ",West Fargo", :latitude => "46.87497", :longitude => "-96.90036").save
City.new(:country_id => "233", :name => "Bellevue", :aliases => ",Bellevue", :latitude => "41.13667", :longitude => "-95.89084").save
City.new(:country_id => "233", :name => "Columbus", :aliases => "Kolumbus,ÐÐ¾Ð»ÑÐ¼Ð±ÑÑ,Columbus", :latitude => "41.42973", :longitude => "-97.36838").save
City.new(:country_id => "233", :name => "Fremont", :aliases => "Frimont,Ð¤ÑÐ¸Ð¼Ð¾Ð½Ñ,Fremont", :latitude => "41.43333", :longitude => "-96.49808").save
City.new(:country_id => "233", :name => "Grand Island", :aliases => ",Grand Island", :latitude => "40.92501", :longitude => "-98.34201").save
City.new(:country_id => "233", :name => "Hastings", :aliases => "Khejstings,Ð¥ÐµÐ¹ÑÑÐ¸Ð½Ð³Ñ,Hastings", :latitude => "40.58612", :longitude => "-98.38839").save
City.new(:country_id => "233", :name => "Kearney", :aliases => "Kerni,ÐÐµÑÐ½Ð¸,Kearney", :latitude => "40.69946", :longitude => "-99.08148").save
City.new(:country_id => "233", :name => "La Vista", :aliases => ",La Vista", :latitude => "41.18389", :longitude => "-96.03113").save
City.new(:country_id => "233", :name => "Lincoln", :aliases => "Lincoln,Linkol'n,Linkolnas,rinkan,ÐÐ¸Ð½ÐºÐ¾Ð»ÑÐ½,ãªã³ã«ã¼ã³,Lincoln", :latitude => "40.8", :longitude => "-96.66696").save
City.new(:country_id => "233", :name => "Norfolk", :aliases => "Norfolk,ÐÐ¾ÑÑÐ¾Ð»Ðº,Norfolk", :latitude => "42.02834", :longitude => "-97.417").save
City.new(:country_id => "233", :name => "Omaha", :aliases => "Omaha,Omakha,ao ma ha,omaha,ÐÐ¼Ð°ÑÐ°,ãªãã,å¥¥é©¬å,Omaha", :latitude => "41.25861", :longitude => "-95.93779").save
City.new(:country_id => "233", :name => "Papillion", :aliases => ",Papillion", :latitude => "41.15444", :longitude => "-96.04224").save
City.new(:country_id => "233", :name => "Bedford", :aliases => "Bedford,ÐÐµÐ´ÑÐ¾ÑÐ´,Bedford", :latitude => "42.94647", :longitude => "-71.5159").save
City.new(:country_id => "233", :name => "Concord", :aliases => "Concord,Kon'kornt Niou Chamsair,Konkord,konkodo,ÎÏÎ½ÎºÎ¿ÏÎ½Ï ÎÎ¹Î¿Ï Î§Î¬Î¼ÏÎ±ÏÏ,ÐÐ¾Ð½ÐºÐ¾ÑÐ´,ã³ã³ã³ã¼ã,Concord", :latitude => "43.20814", :longitude => "-71.53757").save
City.new(:country_id => "233", :name => "Derry", :aliases => "Derri,ÐÐµÑÑÐ¸,Derry", :latitude => "42.88064", :longitude => "-71.32729").save
City.new(:country_id => "233", :name => "Derry Village", :aliases => ",Derry Village", :latitude => "42.89175", :longitude => "-71.31201").save
City.new(:country_id => "233", :name => "Dover", :aliases => "Dover,ÐÐ¾Ð²ÐµÑ,Dover", :latitude => "43.19786", :longitude => "-70.87367").save
City.new(:country_id => "233", :name => "East Concord", :aliases => ",East Concord", :latitude => "43.24202", :longitude => "-71.53813").save
City.new(:country_id => "233", :name => "Goffstown", :aliases => ",Goffstown", :latitude => "43.02036", :longitude => "-71.60035").save
City.new(:country_id => "233", :name => "Hampton", :aliases => "Khehmpton,Ð¥ÑÐ¼Ð¿ÑÐ¾Ð½,Hampton", :latitude => "42.93759", :longitude => "-70.83894").save
City.new(:country_id => "233", :name => "Hudson", :aliases => "Gudzon,ÐÑÐ´Ð·Ð¾Ð½,Hudson", :latitude => "42.76481", :longitude => "-71.43979").save
City.new(:country_id => "233", :name => "Keene", :aliases => ",Keene", :latitude => "42.93369", :longitude => "-72.27814").save
City.new(:country_id => "233", :name => "Laconia", :aliases => ",Laconia", :latitude => "43.52785", :longitude => "-71.47035").save
City.new(:country_id => "233", :name => "Londonderry", :aliases => "Londonderri,ÐÐ¾Ð½Ð´Ð¾Ð½Ð´ÐµÑÑÐ¸,Londonderry", :latitude => "42.86509", :longitude => "-71.37395").save
City.new(:country_id => "233", :name => "Manchester", :aliases => "Manchester,manchesuta,ÐÐ°Ð½ÑÐµÑÑÐµÑ,ãã³ãã§ã¹ã¿ã¼,Manchester", :latitude => "42.99564", :longitude => "-71.45479").save
City.new(:country_id => "233", :name => "Merrimack", :aliases => ",Merrimack", :latitude => "42.86509", :longitude => "-71.4934").save
City.new(:country_id => "233", :name => "Nashua", :aliases => "Nashua,Nashua", :latitude => "42.76537", :longitude => "-71.46757").save
City.new(:country_id => "233", :name => "Portsmouth", :aliases => "Portsmouth,Portsmut,potsumasu,ÐÐ¾ÑÑÑÐ¼ÑÑ,ãã¼ããã¹,Portsmouth", :latitude => "43.07176", :longitude => "-70.76255").save
City.new(:country_id => "233", :name => "Rochester", :aliases => "Rochester,Ð Ð¾ÑÐµÑÑÐµÑ,Rochester", :latitude => "43.30453", :longitude => "-70.97562").save
City.new(:country_id => "233", :name => "Salem", :aliases => "Salem,Ð¡Ð°Ð»ÐµÐ¼,Salem", :latitude => "42.78842", :longitude => "-71.20089").save
City.new(:country_id => "233", :name => "Asbury Park", :aliases => ",Asbury Park", :latitude => "40.22039", :longitude => "-74.01208").save
City.new(:country_id => "233", :name => "Avenel", :aliases => ",Avenel", :latitude => "40.58038", :longitude => "-74.28515").save
City.new(:country_id => "233", :name => "Bayonne", :aliases => ",Bayonne", :latitude => "40.66871", :longitude => "-74.11431").save
City.new(:country_id => "233", :name => "Belleville", :aliases => ",Belleville", :latitude => "40.79371", :longitude => "-74.15014").save
City.new(:country_id => "233", :name => "Bergenfield", :aliases => ",Bergenfield", :latitude => "40.9276", :longitude => "-73.99736").save
City.new(:country_id => "233", :name => "Bloomfield", :aliases => ",Bloomfield", :latitude => "40.80677", :longitude => "-74.18542").save
City.new(:country_id => "233", :name => "Carteret", :aliases => ",Carteret", :latitude => "40.57733", :longitude => "-74.2282").save
City.new(:country_id => "233", :name => "Cliffside Park", :aliases => ",Cliffside Park", :latitude => "40.82149", :longitude => "-73.98764").save
City.new(:country_id => "233", :name => "Clifton", :aliases => "Clifton,Klifton,ÐÐ»Ð¸ÑÑÐ¾Ð½,Clifton", :latitude => "40.85843", :longitude => "-74.16376").save
City.new(:country_id => "233", :name => "Colonia", :aliases => ",Colonia", :latitude => "40.57455", :longitude => "-74.30209").save
City.new(:country_id => "233", :name => "Cranford", :aliases => "Krehnford,ÐÑÑÐ½ÑÐ¾ÑÐ´,Cranford", :latitude => "40.65844", :longitude => "-74.29959").save
City.new(:country_id => "233", :name => "Dover", :aliases => "Dover,ÐÐ¾Ð²ÐµÑ,Dover", :latitude => "40.88399", :longitude => "-74.5621").save
City.new(:country_id => "233", :name => "Dumont", :aliases => ",Dumont", :latitude => "40.94065", :longitude => "-73.99681").save
City.new(:country_id => "233", :name => "East Brunswick", :aliases => ",East Brunswick", :latitude => "40.42788", :longitude => "-74.41598").save
City.new(:country_id => "233", :name => "East Orange", :aliases => "East Orange,East Orange", :latitude => "40.76732", :longitude => "-74.20487").save
City.new(:country_id => "233", :name => "Edison", :aliases => "Edison,Ehdison,Gmina Edison,ai di sheng,Ð­Ð´Ð¸ÑÐ¾Ð½,ç±è¿ªç,Edison", :latitude => "40.51872", :longitude => "-74.4121").save
City.new(:country_id => "233", :name => "Elizabeth", :aliases => "Ehlizabet,Elizabeth,Ð­Ð»Ð¸Ð·Ð°Ð±ÐµÑ,××××××ª,Elizabeth", :latitude => "40.66399", :longitude => "-74.2107").save
City.new(:country_id => "233", :name => "Elmwood Park", :aliases => ",Elmwood Park", :latitude => "40.90399", :longitude => "-74.11848").save
City.new(:country_id => "233", :name => "Englewood", :aliases => ",Englewood", :latitude => "40.89288", :longitude => "-73.97264").save
City.new(:country_id => "233", :name => "Ewing", :aliases => ",Ewing", :latitude => "40.26983", :longitude => "-74.79988").save
City.new(:country_id => "233", :name => "Fair Lawn", :aliases => ",Fair Lawn", :latitude => "40.94038", :longitude => "-74.13181").save
City.new(:country_id => "233", :name => "Fords", :aliases => ",Fords", :latitude => "40.52927", :longitude => "-74.31598").save
City.new(:country_id => "233", :name => "Fort Lee", :aliases => ",Fort Lee", :latitude => "40.85093", :longitude => "-73.97014").save
City.new(:country_id => "233", :name => "Garfield", :aliases => ",Garfield", :latitude => "40.88149", :longitude => "-74.1132").save
City.new(:country_id => "233", :name => "Hackensack", :aliases => "Khakensak,Ð¥Ð°ÐºÐµÐ½ÑÐ°Ðº,Hackensack", :latitude => "40.88593", :longitude => "-74.04347").save
City.new(:country_id => "233", :name => "Hawthorne", :aliases => ",Hawthorne", :latitude => "40.94926", :longitude => "-74.15375").save
City.new(:country_id => "233", :name => "Hillside", :aliases => ",Hillside", :latitude => "40.70121", :longitude => "-74.23015").save
City.new(:country_id => "233", :name => "Hoboken", :aliases => "Hoboken,Hoboken", :latitude => "40.74399", :longitude => "-74.03236").save
City.new(:country_id => "233", :name => "Hopatcong", :aliases => ",Hopatcong", :latitude => "40.93288", :longitude => "-74.65933").save
City.new(:country_id => "233", :name => "Hopatcong Hills", :aliases => ",Hopatcong Hills", :latitude => "40.94399", :longitude => "-74.67072").save
City.new(:country_id => "233", :name => "Irvington", :aliases => ",Irvington", :latitude => "40.73232", :longitude => "-74.23487").save
City.new(:country_id => "233", :name => "Iselin", :aliases => ",Iselin", :latitude => "40.57538", :longitude => "-74.32237").save
City.new(:country_id => "233", :name => "Jersey City", :aliases => "Dzhersi-Siti,ÐÐ¶ÐµÑÑÐ¸-Ð¡Ð¸ÑÐ¸,Jersey City", :latitude => "40.72816", :longitude => "-74.07764").save
City.new(:country_id => "233", :name => "Kearny", :aliases => "Kerni,ÐÐµÑÐ½Ð¸,Kearny", :latitude => "40.76843", :longitude => "-74.14542").save
City.new(:country_id => "233", :name => "Lakewood", :aliases => "Lejkvud,ÐÐµÐ¹ÐºÐ²ÑÐ´,Lakewood", :latitude => "40.09789", :longitude => "-74.21764").save
City.new(:country_id => "233", :name => "Linden", :aliases => "Linden,ÐÐ¸Ð½Ð´ÐµÐ½,Linden", :latitude => "40.62205", :longitude => "-74.24459").save
City.new(:country_id => "233", :name => "Livingston", :aliases => "Livingston,ÐÐ¸Ð²Ð¸Ð½Ð³ÑÑÐ¾Ð½,Livingston", :latitude => "40.79593", :longitude => "-74.31487").save
City.new(:country_id => "233", :name => "Lodi", :aliases => "Lodi,ÐÐ¾Ð´Ð¸,Lodi", :latitude => "40.88232", :longitude => "-74.0832").save
City.new(:country_id => "233", :name => "Long Branch", :aliases => ",Long Branch", :latitude => "40.30428", :longitude => "-73.99236").save
City.new(:country_id => "233", :name => "Lyndhurst", :aliases => ",Lyndhurst", :latitude => "40.81204", :longitude => "-74.12431").save
City.new(:country_id => "233", :name => "Madison", :aliases => "Madison,ÐÐ°Ð´Ð¸ÑÐ¾Ð½,Madison", :latitude => "40.75982", :longitude => "-74.4171").save
City.new(:country_id => "233", :name => "Maplewood", :aliases => ",Maplewood", :latitude => "40.73121", :longitude => "-74.27348").save
City.new(:country_id => "233", :name => "Montclair", :aliases => ",Montclair", :latitude => "40.82593", :longitude => "-74.20903").save
City.new(:country_id => "233", :name => "Morristown", :aliases => ",Morristown", :latitude => "40.79677", :longitude => "-74.48154").save
City.new(:country_id => "233", :name => "New Brunswick", :aliases => "N'ju-Bransuik,ÐÑÑ-ÐÑÐ°Ð½ÑÑÐ¸Ðº,New Brunswick", :latitude => "40.48622", :longitude => "-74.45182").save
City.new(:country_id => "233", :name => "New Milford", :aliases => "Novye Milford,ÐÐ¾Ð²ÑÐµ ÐÐ¸Ð»ÑÐ¾ÑÐ´,New Milford", :latitude => "40.93268", :longitude => "-74.01785").save
City.new(:country_id => "233", :name => "Newark", :aliases => "N'juark,Newark,Njuark,niu hua ke,nyuaku,ÐÑÑÐ°ÑÐº,ÐÑÐ°ÑÐº,ááá£áá áá,ãã¥ã¼ã¢ã¼ã¯,ç´è¯å,Newark", :latitude => "40.73566", :longitude => "-74.17237").save
City.new(:country_id => "233", :name => "North Arlington", :aliases => ",North Arlington", :latitude => "40.78843", :longitude => "-74.1332").save
City.new(:country_id => "233", :name => "North Bergen", :aliases => ",North Bergen", :latitude => "40.80427", :longitude => "-74.01208").save
City.new(:country_id => "233", :name => "North Plainfield", :aliases => ",North Plainfield", :latitude => "40.6301", :longitude => "-74.42737").save
City.new(:country_id => "233", :name => "Nutley", :aliases => ",Nutley", :latitude => "40.82232", :longitude => "-74.15987").save
City.new(:country_id => "233", :name => "Old Bridge", :aliases => ",Old Bridge", :latitude => "40.41483", :longitude => "-74.36543").save
City.new(:country_id => "233", :name => "Orange", :aliases => ",Orange", :latitude => "40.77066", :longitude => "-74.23265").save
City.new(:country_id => "233", :name => "Palisades Park", :aliases => ",Palisades Park", :latitude => "40.84816", :longitude => "-73.99764").save
City.new(:country_id => "233", :name => "Paramus", :aliases => "Paramus,ÐÐ°ÑÐ°Ð¼ÑÑ,Paramus", :latitude => "40.94454", :longitude => "-74.07542").save
City.new(:country_id => "233", :name => "Parsippany", :aliases => "Parsippani,ÐÐ°ÑÑÐ¸Ð¿Ð¿Ð°Ð½Ð¸,Parsippany", :latitude => "40.85788", :longitude => "-74.42599").save
City.new(:country_id => "233", :name => "Passaic", :aliases => ",Passaic", :latitude => "40.85677", :longitude => "-74.12848").save
City.new(:country_id => "233", :name => "Paterson", :aliases => "Paterson,ÐÐ°ÑÐµÑÑÐ¾Ð½,Paterson", :latitude => "40.91677", :longitude => "-74.17181").save
City.new(:country_id => "233", :name => "Perth Amboy", :aliases => ",Perth Amboy", :latitude => "40.50677", :longitude => "-74.26542").save
City.new(:country_id => "233", :name => "Phillipsburg", :aliases => ",Phillipsburg", :latitude => "40.69371", :longitude => "-75.19018").save
City.new(:country_id => "233", :name => "Plainfield", :aliases => ",Plainfield", :latitude => "40.61682", :longitude => "-74.41727").save
City.new(:country_id => "233", :name => "Point Pleasant", :aliases => ",Point Pleasant", :latitude => "40.08317", :longitude => "-74.06819").save
City.new(:country_id => "233", :name => "Rahway", :aliases => ",Rahway", :latitude => "40.60816", :longitude => "-74.27765").save
City.new(:country_id => "233", :name => "Ridgewood", :aliases => ",Ridgewood", :latitude => "40.97926", :longitude => "-74.11653").save
City.new(:country_id => "233", :name => "Roselle", :aliases => ",Roselle", :latitude => "40.66427", :longitude => "-74.2632").save
City.new(:country_id => "233", :name => "Rutherford", :aliases => ",Rutherford", :latitude => "40.82649", :longitude => "-74.10681").save
City.new(:country_id => "233", :name => "Sayreville", :aliases => ",Sayreville", :latitude => "40.45927", :longitude => "-74.36098").save
City.new(:country_id => "233", :name => "Sayreville Junction", :aliases => ",Sayreville Junction", :latitude => "40.46538", :longitude => "-74.33043").save
City.new(:country_id => "233", :name => "Scotch Plains", :aliases => ",Scotch Plains", :latitude => "40.65538", :longitude => "-74.38987").save
City.new(:country_id => "233", :name => "Secaucus", :aliases => "Secaucus,Secaucus", :latitude => "40.79672", :longitude => "-74.05532").save
City.new(:country_id => "233", :name => "Somerset", :aliases => "Somerset,Ð¡Ð¾Ð¼ÐµÑÑÐµÑ,Somerset", :latitude => "40.4976", :longitude => "-74.48849").save
City.new(:country_id => "233", :name => "South Old Bridge", :aliases => ",South Old Bridge", :latitude => "40.40816", :longitude => "-74.35432").save
City.new(:country_id => "233", :name => "South Orange", :aliases => ",South Orange", :latitude => "40.74899", :longitude => "-74.26126").save
City.new(:country_id => "233", :name => "South Plainfield", :aliases => ",South Plainfield", :latitude => "40.57927", :longitude => "-74.41154").save
City.new(:country_id => "233", :name => "South River", :aliases => ",South River", :latitude => "40.4465", :longitude => "-74.38598").save
City.new(:country_id => "233", :name => "Summit", :aliases => ",Summit", :latitude => "40.74149", :longitude => "-74.35959").save
City.new(:country_id => "233", :name => "Teaneck", :aliases => ",Teaneck", :latitude => "40.8976", :longitude => "-74.01597").save
City.new(:country_id => "233", :name => "Tinton Falls", :aliases => ",Tinton Falls", :latitude => "40.30428", :longitude => "-74.10042").save
City.new(:country_id => "233", :name => "Trenton", :aliases => "Trenton,torenton,trntwn,Ð¢ÑÐµÐ½ÑÐ¾Ð½,××¨× ×××,ãã¬ã³ãã³,Trenton", :latitude => "40.21705", :longitude => "-74.74294").save
City.new(:country_id => "233", :name => "Union", :aliases => ",Union", :latitude => "40.6976", :longitude => "-74.2632").save
City.new(:country_id => "233", :name => "Union City", :aliases => "Junion-Siti,Ð®Ð½Ð¸Ð¾Ð½-Ð¡Ð¸ÑÐ¸,Union City", :latitude => "40.77955", :longitude => "-74.02375").save
City.new(:country_id => "233", :name => "Wayne", :aliases => ",Wayne", :latitude => "40.92538", :longitude => "-74.27654").save
City.new(:country_id => "233", :name => "West Milford", :aliases => ",West Milford", :latitude => "41.13121", :longitude => "-74.36737").save
City.new(:country_id => "233", :name => "West New York", :aliases => ",West New York", :latitude => "40.78788", :longitude => "-74.01431").save
City.new(:country_id => "233", :name => "West Orange", :aliases => ",West Orange", :latitude => "40.79871", :longitude => "-74.23904").save
City.new(:country_id => "233", :name => "Westfield", :aliases => ",Westfield", :latitude => "40.65899", :longitude => "-74.34737").save
City.new(:country_id => "233", :name => "Willingboro", :aliases => ",Willingboro", :latitude => "40.02789", :longitude => "-74.86905").save
City.new(:country_id => "233", :name => "Woodbridge", :aliases => ",Woodbridge", :latitude => "40.5576", :longitude => "-74.28459").save
City.new(:country_id => "233", :name => "Wyckoff", :aliases => ",Wyckoff", :latitude => "41.00954", :longitude => "-74.17292").save
City.new(:country_id => "233", :name => "Albany", :aliases => "Albany,Olbani,Olbanis,Olbeni,albani,albany, nywywrk,alpeni,ao er ba ni,ao er ba ni shi,olbeoni,orubani,xxlbani,ÐÐ»Ð±Ð°Ð½Ð¸,ÐÐ»Ð±Ð°Ð½Ñ,ÐÐ»Ð±ÐµÐ½Ð¸,××××× ×,××××× ×,Ø¢ÙØ¨Ø§ÙÛØ ÙÛÙÛÙØ±Ú©,Ø£ÙØ¨Ø§ÙÙØ ÙÙÙÙÙØ±Ù,à¤à¤²à¥à¤¬à¤¨à¥,à®à®²à¯à®ªà¯à®©à®¿,à¸­à¸­à¸¥à¸à¸²à¸à¸µ,áááááá,ãªã¼ã«ãã,å¥¥å°å·´å°¼,å¥¥å°å·´å°¼å¸,ì¬ë²ë,Albany", :latitude => "42.65258", :longitude => "-73.75623").save
City.new(:country_id => "233", :name => "Amsterdam", :aliases => ",Amsterdam", :latitude => "42.93869", :longitude => "-74.18819").save
City.new(:country_id => "233", :name => "Auburn", :aliases => ",Auburn", :latitude => "42.93173", :longitude => "-76.56605").save
City.new(:country_id => "233", :name => "Baldwin", :aliases => "Bolduin,ÐÐ¾Ð»Ð´ÑÐ¸Ð½,Baldwin", :latitude => "40.65649", :longitude => "-73.6093").save
City.new(:country_id => "233", :name => "Batavia", :aliases => "Batavija,ÐÐ°ÑÐ°Ð²Ð¸Ñ,Batavia", :latitude => "42.99812", :longitude => "-78.18752").save
City.new(:country_id => "233", :name => "Bay Shore", :aliases => ",Bay Shore", :latitude => "40.7251", :longitude => "-73.24539").save
City.new(:country_id => "233", :name => "Beacon", :aliases => ",Beacon", :latitude => "41.50482", :longitude => "-73.96958").save
City.new(:country_id => "233", :name => "Bellmore", :aliases => ",Bellmore", :latitude => "40.66871", :longitude => "-73.52707").save
City.new(:country_id => "233", :name => "Bensonhurst", :aliases => "Bensonkherst,ÐÐµÐ½ÑÐ¾Ð½ÑÐµÑÑÑ,Bensonhurst", :latitude => "40.60177", :longitude => "-73.99403").save
City.new(:country_id => "233", :name => "Bethpage", :aliases => ",Bethpage", :latitude => "40.74427", :longitude => "-73.48207").save
City.new(:country_id => "233", :name => "Binghamton", :aliases => "Binghamton,bin han dun,è³ç½é ,Binghamton", :latitude => "42.09869", :longitude => "-75.91797").save
City.new(:country_id => "233", :name => "Brentwood", :aliases => ",Brentwood", :latitude => "40.78121", :longitude => "-73.24623").save
City.new(:country_id => "233", :name => "Brighton", :aliases => "Brajton,ÐÑÐ°Ð¹ÑÐ¾Ð½,Brighton", :latitude => "43.14756", :longitude => "-77.55055").save
City.new(:country_id => "233", :name => "Brooklyn", :aliases => "Broklino,Brooklyn,Brooklyn County,Brucclinu,Bruklin,Bruklina,Bruklinas,Comitatus Bruclinum,Kings County,beulukeullin,bru klin,brukalina,brwklyn,brwqlyn,bu lu ke lin qu,burukkurin qu,kinsa ka'unti,ÐÑÑÐºÐ»Ð¸Ð½,ÐÑÑÐºÐ»ÑÐ½,××¨××§×××,Ø¨Ø±ÙÙÙÙÙ,Ø¨Ø±ÙÚ©ÙÛÙ,à¤¬à¥à¤°à¥à¤à¤²à¥à¤¨,à¤¬à¥à¤°à¥à¤à¤²à¤¿à¤¨,à¦à¦¿à¦à¦¸ à¦à¦¾à¦à¦¨à§à¦à¦¿,à¦¬à§à¦°à§à¦à¦²à¦¿à¦¨,à¸à¸£à¸¸à¸à¸¥à¸´à¸,áá á£ááááá,ãã«ãã¯ãªã³åº,å¸é²åæåº,ë¸ë£¨í´ë¦°,Brooklyn", :latitude => "40.6501", :longitude => "-73.94958").save
City.new(:country_id => "233", :name => "Buffalo", :aliases => "Bafalo,Bufalo,Buffalo,baffaro,shui niu cheng,ÐÐ°ÑÐ°Ð»Ð¾,ÐÑÑÑÐ°Ð»Ð¾,ãããã¡ã­ã¼,æ°´çå,Buffalo", :latitude => "42.88645", :longitude => "-78.87837").save
City.new(:country_id => "233", :name => "Centereach", :aliases => ",Centereach", :latitude => "40.85843", :longitude => "-73.09955").save
City.new(:country_id => "233", :name => "Central Islip", :aliases => ",Central Islip", :latitude => "40.79065", :longitude => "-73.20178").save
City.new(:country_id => "233", :name => "Cheektowaga", :aliases => "Cheektowaga,Cheektowaga", :latitude => "42.90339", :longitude => "-78.75475").save
City.new(:country_id => "233", :name => "Cohoes", :aliases => ",Cohoes", :latitude => "42.77424", :longitude => "-73.70012").save
City.new(:country_id => "233", :name => "Commack", :aliases => ",Commack", :latitude => "40.84288", :longitude => "-73.29289").save
City.new(:country_id => "233", :name => "Coney Island", :aliases => ",Coney Island", :latitude => "40.57788", :longitude => "-73.99403").save
City.new(:country_id => "233", :name => "Copiague", :aliases => ",Copiague", :latitude => "40.68149", :longitude => "-73.39984").save
City.new(:country_id => "233", :name => "Coram", :aliases => ",Coram", :latitude => "40.86871", :longitude => "-73.00149").save
City.new(:country_id => "233", :name => "Cortland", :aliases => ",Cortland", :latitude => "42.60118", :longitude => "-76.18048").save
City.new(:country_id => "233", :name => "Deer Park", :aliases => ",Deer Park", :latitude => "40.76177", :longitude => "-73.32929").save
City.new(:country_id => "233", :name => "Depew", :aliases => ",Depew", :latitude => "42.90395", :longitude => "-78.69225").save
City.new(:country_id => "233", :name => "Dix Hills", :aliases => ",Dix Hills", :latitude => "40.80482", :longitude => "-73.33623").save
City.new(:country_id => "233", :name => "East Meadow", :aliases => ",East Meadow", :latitude => "40.71399", :longitude => "-73.55902").save
City.new(:country_id => "233", :name => "East Massapequa", :aliases => ",East Massapequa", :latitude => "40.67343", :longitude => "-73.43651").save
City.new(:country_id => "233", :name => "East New York", :aliases => "East New York,Starrett City,East New York", :latitude => "40.66677", :longitude => "-73.88236").save
City.new(:country_id => "233", :name => "East Northport", :aliases => ",East Northport", :latitude => "40.87676", :longitude => "-73.32456").save
City.new(:country_id => "233", :name => "East Patchogue", :aliases => ",East Patchogue", :latitude => "40.76704", :longitude => "-72.99622").save
City.new(:country_id => "233", :name => "East Setauket", :aliases => ",East Setauket", :latitude => "40.94149", :longitude => "-73.10594").save
City.new(:country_id => "233", :name => "Eastchester", :aliases => ",Eastchester", :latitude => "40.8876", :longitude => "-73.83291").save
City.new(:country_id => "233", :name => "Elmira", :aliases => "Ehl'mira,Ð­Ð»ÑÐ¼Ð¸ÑÐ°,Elmira", :latitude => "42.0898", :longitude => "-76.80773").save
City.new(:country_id => "233", :name => "Elmont", :aliases => ",Elmont", :latitude => "40.70094", :longitude => "-73.71291").save
City.new(:country_id => "233", :name => "Farmingville", :aliases => ",Farmingville", :latitude => "40.83121", :longitude => "-73.02955").save
City.new(:country_id => "233", :name => "Floral Park", :aliases => ",Floral Park", :latitude => "40.72371", :longitude => "-73.70485").save
City.new(:country_id => "233", :name => "Franklin Square", :aliases => ",Franklin Square", :latitude => "40.70732", :longitude => "-73.67596").save
City.new(:country_id => "233", :name => "Freeport", :aliases => ",Freeport", :latitude => "40.6576", :longitude => "-73.58318").save
City.new(:country_id => "233", :name => "Garden City", :aliases => ",Garden City", :latitude => "40.72677", :longitude => "-73.6343").save
City.new(:country_id => "233", :name => "Glen Cove", :aliases => "Glen-Kouv,ÐÐ»ÐµÐ½-ÐÐ¾ÑÐ²,Glen Cove", :latitude => "40.86232", :longitude => "-73.63374").save
City.new(:country_id => "233", :name => "Gloversville", :aliases => ",Gloversville", :latitude => "43.05285", :longitude => "-74.34375").save
City.new(:country_id => "233", :name => "Greenburgh", :aliases => ",Greenburgh", :latitude => "41.03288", :longitude => "-73.84291").save
City.new(:country_id => "233", :name => "Harrison", :aliases => "Kharrison,Ð¥Ð°ÑÑÐ¸ÑÐ¾Ð½,Harrison", :latitude => "40.96899", :longitude => "-73.71263").save
City.new(:country_id => "233", :name => "Hauppauge", :aliases => ",Hauppauge", :latitude => "40.82565", :longitude => "-73.20261").save
City.new(:country_id => "233", :name => "Hempstead", :aliases => "Khempsted,Ð¥ÐµÐ¼Ð¿ÑÑÐµÐ´,Hempstead", :latitude => "40.70621", :longitude => "-73.61874").save
City.new(:country_id => "233", :name => "Hicksville", :aliases => "Khiksvilla,Ð¥Ð¸ÐºÑÐ²Ð¸Ð»Ð»Ð°,Hicksville", :latitude => "40.76843", :longitude => "-73.52513").save
City.new(:country_id => "233", :name => "Holbrook", :aliases => "Kholbruk,Ð¥Ð¾Ð»Ð±ÑÑÐº,Holbrook", :latitude => "40.81232", :longitude => "-73.07844").save
City.new(:country_id => "233", :name => "Holtsville", :aliases => ",Holtsville", :latitude => "40.81538", :longitude => "-73.04511").save
City.new(:country_id => "233", :name => "Huntington", :aliases => "Khantington,Ð¥Ð°Ð½ÑÐ¸Ð½Ð³ÑÐ¾Ð½,Huntington", :latitude => "40.86815", :longitude => "-73.42568").save
City.new(:country_id => "233", :name => "Huntington Station", :aliases => ",Huntington Station", :latitude => "40.85343", :longitude => "-73.41151").save
City.new(:country_id => "233", :name => "Irondequoit", :aliases => ",Irondequoit", :latitude => "43.2134", :longitude => "-77.57972").save
City.new(:country_id => "233", :name => "Islip", :aliases => ",Islip", :latitude => "40.72982", :longitude => "-73.21039").save
City.new(:country_id => "233", :name => "Ithaca", :aliases => "Itak,ÐÑÐ°Ðº,Ithaca", :latitude => "42.44063", :longitude => "-76.49661").save
City.new(:country_id => "233", :name => "Jamestown", :aliases => ",Jamestown", :latitude => "42.097", :longitude => "-79.23533").save
City.new(:country_id => "233", :name => "Johnson City", :aliases => "Dzhonson Siti,ÐÐ¶Ð¾Ð½ÑÐ¾Ð½ Ð¡Ð¸ÑÐ¸,Johnson City", :latitude => "42.11563", :longitude => "-75.95881").save
City.new(:country_id => "233", :name => "Kenmore", :aliases => ",Kenmore", :latitude => "42.96589", :longitude => "-78.87004").save
City.new(:country_id => "233", :name => "Kings Park", :aliases => ",Kings Park", :latitude => "40.88621", :longitude => "-73.25734").save
City.new(:country_id => "233", :name => "Kingston", :aliases => "Kingston,ÐÐ¸Ð½Ð³ÑÑÐ¾Ð½,Kingston", :latitude => "41.92704", :longitude => "-73.99736").save
City.new(:country_id => "233", :name => "Kiryas Joel", :aliases => ",Kiryas Joel", :latitude => "41.34204", :longitude => "-74.16792").save
City.new(:country_id => "233", :name => "Lackawanna", :aliases => ",Lackawanna", :latitude => "42.82561", :longitude => "-78.82337").save
City.new(:country_id => "233", :name => "Lake Ronkonkoma", :aliases => ",Lake Ronkonkoma", :latitude => "40.8351", :longitude => "-73.13122").save
City.new(:country_id => "233", :name => "Levittown", :aliases => ",Levittown", :latitude => "40.72593", :longitude => "-73.51429").save
City.new(:country_id => "233", :name => "Lindenhurst", :aliases => ",Lindenhurst", :latitude => "40.68677", :longitude => "-73.37345").save
City.new(:country_id => "233", :name => "Lockport", :aliases => ",Lockport", :latitude => "43.17061", :longitude => "-78.69031").save
City.new(:country_id => "233", :name => "Long Beach", :aliases => "Long-Bich,ÐÐ¾Ð½Ð³-ÐÐ¸Ñ,Long Beach", :latitude => "40.58844", :longitude => "-73.65791").save
City.new(:country_id => "233", :name => "Lynbrook", :aliases => ",Lynbrook", :latitude => "40.65483", :longitude => "-73.6718").save
City.new(:country_id => "233", :name => "Mamaroneck", :aliases => ",Mamaroneck", :latitude => "40.94871", :longitude => "-73.73263").save
City.new(:country_id => "233", :name => "Manhattan", :aliases => ",Manhattan", :latitude => "40.78343", :longitude => "-73.96625").save
City.new(:country_id => "233", :name => "Massapequa", :aliases => ",Massapequa", :latitude => "40.68066", :longitude => "-73.47429").save
City.new(:country_id => "233", :name => "Massapequa Park", :aliases => ",Massapequa Park", :latitude => "40.68038", :longitude => "-73.45512").save
City.new(:country_id => "233", :name => "Mastic", :aliases => ",Mastic", :latitude => "40.80204", :longitude => "-72.84094").save
City.new(:country_id => "233", :name => "Medford", :aliases => "Medford,ÐÐµÐ´ÑÐ¾ÑÐ´,Medford", :latitude => "40.8176", :longitude => "-73.00011").save
City.new(:country_id => "233", :name => "Melville", :aliases => ",Melville", :latitude => "40.79343", :longitude => "-73.41512").save
City.new(:country_id => "233", :name => "Merrick", :aliases => "Merrik,ÐÐµÑÑÐ¸Ðº,Merrick", :latitude => "40.66288", :longitude => "-73.55152").save
City.new(:country_id => "233", :name => "Middletown", :aliases => ",Middletown", :latitude => "41.44593", :longitude => "-74.42293").save
City.new(:country_id => "233", :name => "Mineola", :aliases => ",Mineola", :latitude => "40.74927", :longitude => "-73.64068").save
City.new(:country_id => "233", :name => "Mount Vernon", :aliases => "Mount Vernon,Mount Vernon", :latitude => "40.9126", :longitude => "-73.83708").save
City.new(:country_id => "233", :name => "Nanuet", :aliases => ",Nanuet", :latitude => "41.08871", :longitude => "-74.01347").save
City.new(:country_id => "233", :name => "New City", :aliases => ",New City", :latitude => "41.1476", :longitude => "-73.98931").save
City.new(:country_id => "233", :name => "New Rochelle", :aliases => "N'ju-Roshel',New Rochelle,Nueva Rochelle,ÐÑÑ-Ð Ð¾ÑÐµÐ»Ñ,New Rochelle", :latitude => "40.91149", :longitude => "-73.78235").save
City.new(:country_id => "233", :name => "New York City", :aliases => "Bandaraya New York,Big Apple,Cathair Nua Eabhraic,Dinas Efrog Newydd,Eabhraig Nuadh,Evrek Nowydh,Lungsod ng New York,N'ju-Jork,NYC,Nea Yorke,Nei Yarrick Schtadt,New York,New York City,New York Stad,New York borg,New York kenti,New York-borg,Niujorkas,Nju Jork,Njujork,Nouvieau York,Nov-Jorko,Nova Iorque,Nova York,Nova-York,Novjorko,Nowy Jork,Nua-Eabhrac,Nueba York,Nueva York,Nujorka,Nyja Jorvik,NÃ²va York,NÃ½ja JÃ³rvÃ­k,Thanh pho New York,The City of New York,ThÃ nh phá» New York,Urbs Novum Eboracum,York Berri,ni'u iyarka,niu yue shi,niyuyark,nkhr niwyxrk,nyuyog,nyuyog si,nyuyoku,nyw ywrq,nywywrk,Åujorka,ÎÎ­Î± Î¥ÏÏÎºÎ·,ÐÑ ÐÐ¾ÑÐº,ÐÑÑÐ¾ÑÐº,ÐÑÑ-ÐÑÐº,ÐÑÑ-ÐÐ¾ÑÐº,ÐÑ ÐÐ¾ÑÐº,× ×× ×××¨×§,× ×× ×××¨×§,× ××Ö¾××Ö¸×¨×§,ÙÙÙÙÙØ±Ù,ÙÙÛÙÙØ±Ù Ø´ÛÚ¾ÛØ±,ÙÛÙÛØ§Ø±Ú© Ø´ÛØ±,ÙÛÙÛÙØ±Ú©,à¦¨à¦¿à¦ à¦à¦¯à¦¼à¦°à§à¦,à®¨à®¿à®¯à¯à®¯à®¾à®°à¯à®à¯,à¸à¸à¸£à¸à¸´à¸§à¸¢à¸­à¸£à¹à¸,ááá£-ááá áá,ãã¥ã¼ã¨ã¼ã¯,ç´ç´å¸,çº½çº¦å¸,ë´ì,ë´ì ì,New York City", :latitude => "40.71427", :longitude => "-74.00597").save
City.new(:country_id => "233", :name => "Newburgh", :aliases => "N'juberg,ÐÑÑÐ±ÐµÑÐ³,Newburgh", :latitude => "41.50343", :longitude => "-74.01042").save
City.new(:country_id => "233", :name => "Niagara Falls", :aliases => "Niagara Falls,Niagara Falls", :latitude => "43.0945", :longitude => "-79.05671").save
City.new(:country_id => "233", :name => "North Babylon", :aliases => ",North Babylon", :latitude => "40.71649", :longitude => "-73.32179").save
City.new(:country_id => "233", :name => "North Bay Shore", :aliases => ",North Bay Shore", :latitude => "40.73621", :longitude => "-73.26262").save
City.new(:country_id => "233", :name => "North Bellmore", :aliases => ",North Bellmore", :latitude => "40.69149", :longitude => "-73.53346").save
City.new(:country_id => "233", :name => "North Gates", :aliases => ",North Gates", :latitude => "43.17645", :longitude => "-77.70139").save
City.new(:country_id => "233", :name => "North Massapequa", :aliases => ",North Massapequa", :latitude => "40.70093", :longitude => "-73.46207").save
City.new(:country_id => "233", :name => "North Tonawanda", :aliases => ",North Tonawanda", :latitude => "43.03867", :longitude => "-78.8642").save
City.new(:country_id => "233", :name => "North Valley Stream", :aliases => ",North Valley Stream", :latitude => "40.6851", :longitude => "-73.7018").save
City.new(:country_id => "233", :name => "Oceanside", :aliases => ",Oceanside", :latitude => "40.63871", :longitude => "-73.64013").save
City.new(:country_id => "233", :name => "Ossining", :aliases => ",Ossining", :latitude => "41.16287", :longitude => "-73.86152").save
City.new(:country_id => "233", :name => "Oswego", :aliases => ",Oswego", :latitude => "43.45535", :longitude => "-76.5105").save
City.new(:country_id => "233", :name => "Pearl River", :aliases => ",Pearl River", :latitude => "41.05899", :longitude => "-74.02181").save
City.new(:country_id => "233", :name => "Peekskill", :aliases => ",Peekskill", :latitude => "41.29009", :longitude => "-73.92042").save
City.new(:country_id => "233", :name => "Plainview", :aliases => ",Plainview", :latitude => "40.77649", :longitude => "-73.46735").save
City.new(:country_id => "233", :name => "Plattsburgh", :aliases => ",Plattsburgh", :latitude => "44.69949", :longitude => "-73.45291").save
City.new(:country_id => "233", :name => "Port Chester", :aliases => ",Port Chester", :latitude => "41.00176", :longitude => "-73.66568").save
City.new(:country_id => "233", :name => "Port Washington", :aliases => ",Port Washington", :latitude => "40.82566", :longitude => "-73.69819").save
City.new(:country_id => "233", :name => "Poughkeepsie", :aliases => ",Poughkeepsie", :latitude => "41.70037", :longitude => "-73.92097").save
City.new(:country_id => "233", :name => "Rochester", :aliases => "Rocestera,Rocestro,Rochester,Rochestur,RoÄestro,RoÄestera,luo che si te,racestara,rochesuta,Ð Ð¾ÑÐµÑÑÐµÑ,Ð Ð¾ÑÐµÑÑÑÑ,à¦°à¦à§à¦¸à§à¦à¦¾à¦°,ã­ãã§ã¹ã¿ã¼,ç¾å¾¹æ¯ç¹,Rochester", :latitude => "43.15478", :longitude => "-77.61556").save
City.new(:country_id => "233", :name => "Rockville Centre", :aliases => "Rockville Center,Rockville Centre,Rockville Centre", :latitude => "40.65871", :longitude => "-73.64124").save
City.new(:country_id => "233", :name => "Rome", :aliases => "Rim,Ð Ð¸Ð¼,Rome", :latitude => "43.21285", :longitude => "-75.45573").save
City.new(:country_id => "233", :name => "Ronkonkoma", :aliases => ",Ronkonkoma", :latitude => "40.81538", :longitude => "-73.11233").save
City.new(:country_id => "233", :name => "Roosevelt", :aliases => ",Roosevelt", :latitude => "40.67871", :longitude => "-73.58902").save
City.new(:country_id => "233", :name => "Rotterdam", :aliases => ",Rotterdam", :latitude => "42.78702", :longitude => "-73.97096").save
City.new(:country_id => "233", :name => "Rye", :aliases => ",Rye", :latitude => "40.98065", :longitude => "-73.68374").save
City.new(:country_id => "233", :name => "Saratoga Springs", :aliases => "Saratoga-Springs,Ð¡Ð°ÑÐ°ÑÐ¾Ð³Ð°-Ð¡Ð¿ÑÐ¸Ð½Ð³Ñ,Saratoga Springs", :latitude => "43.08313", :longitude => "-73.78457").save
City.new(:country_id => "233", :name => "Sayville", :aliases => ",Sayville", :latitude => "40.73593", :longitude => "-73.08206").save
City.new(:country_id => "233", :name => "Scarsdale", :aliases => ",Scarsdale", :latitude => "41.0051", :longitude => "-73.78458").save
City.new(:country_id => "233", :name => "Schenectady", :aliases => "Schenectady,Skenektadi,sknyktady,Ð¡ÐºÐµÐ½ÐµÐºÑÐ°Ð´Ð¸,Ø³ÙÙÙÙØªØ§Ø¯Ù,Schenectady", :latitude => "42.81424", :longitude => "-73.93957").save
City.new(:country_id => "233", :name => "Seaford", :aliases => ",Seaford", :latitude => "40.66593", :longitude => "-73.48818").save
City.new(:country_id => "233", :name => "Selden", :aliases => "Selden,Ð¡ÐµÐ»Ð´ÐµÐ½,Selden", :latitude => "40.86649", :longitude => "-73.03566").save
City.new(:country_id => "233", :name => "Shirley", :aliases => "Shirli,Ð¨Ð¸ÑÐ»Ð¸,Shirley", :latitude => "40.80149", :longitude => "-72.8676").save
City.new(:country_id => "233", :name => "Smithtown", :aliases => ",Smithtown", :latitude => "40.85593", :longitude => "-73.20067").save
City.new(:country_id => "233", :name => "Spring Valley", :aliases => "Spring-Vehlli,Ð¡Ð¿ÑÐ¸Ð½Ð³-ÐÑÐ»Ð»Ð¸,Spring Valley", :latitude => "41.11315", :longitude => "-74.04375").save
City.new(:country_id => "233", :name => "Syosset", :aliases => ",Syosset", :latitude => "40.82621", :longitude => "-73.50207").save
City.new(:country_id => "233", :name => "Syracuse", :aliases => "Sirakuso,Syracuse,shirakyusu,shirakyuzu,xue cheng,ã·ã©ã­ã¥ã¼ã¹,ã·ã©ã­ã¥ã¼ãº,éªå,Syracuse", :latitude => "43.04812", :longitude => "-76.14742").save
City.new(:country_id => "233", :name => "Tonawanda", :aliases => ",Tonawanda", :latitude => "43.02033", :longitude => "-78.88032").save
City.new(:country_id => "233", :name => "Troy", :aliases => "Troja,Ð¢ÑÐ¾Ñ,Troy", :latitude => "42.72841", :longitude => "-73.69179").save
City.new(:country_id => "233", :name => "Uniondale", :aliases => ",Uniondale", :latitude => "40.70038", :longitude => "-73.59291").save
City.new(:country_id => "233", :name => "Utica", :aliases => "Utica,you ti ka,ç±æå¡,Utica", :latitude => "43.1009", :longitude => "-75.23266").save
City.new(:country_id => "233", :name => "Valley Stream", :aliases => ",Valley Stream", :latitude => "40.66427", :longitude => "-73.70846").save
City.new(:country_id => "233", :name => "Wantagh", :aliases => ",Wantagh", :latitude => "40.68371", :longitude => "-73.51013").save
City.new(:country_id => "233", :name => "Watertown", :aliases => ",Watertown", :latitude => "43.97478", :longitude => "-75.91076").save
City.new(:country_id => "233", :name => "West Albany", :aliases => ",West Albany", :latitude => "42.68313", :longitude => "-73.77845").save
City.new(:country_id => "233", :name => "West Babylon", :aliases => ",West Babylon", :latitude => "40.71816", :longitude => "-73.35429").save
City.new(:country_id => "233", :name => "West Hempstead", :aliases => ",West Hempstead", :latitude => "40.70482", :longitude => "-73.65013").save
City.new(:country_id => "233", :name => "West Islip", :aliases => ",West Islip", :latitude => "40.70621", :longitude => "-73.30623").save
City.new(:country_id => "233", :name => "West Seneca", :aliases => ",West Seneca", :latitude => "42.85006", :longitude => "-78.79975").save
City.new(:country_id => "233", :name => "White Plains", :aliases => "White Plains,ãã¯ã¤ãã»ãã¬ã¤ã³ãº,ãã¯ã¤ãã»ãã¬ã¤ã³ãº_,White Plains", :latitude => "41.03399", :longitude => "-73.76291").save
City.new(:country_id => "233", :name => "Woodmere", :aliases => ",Woodmere", :latitude => "40.63205", :longitude => "-73.71263").save
City.new(:country_id => "233", :name => "Yonkers", :aliases => "Jonkers,Yonkers,ÐÐ¾Ð½ÐºÐµÑÑ,Yonkers", :latitude => "40.93121", :longitude => "-73.89875").save
City.new(:country_id => "233", :name => "Akron", :aliases => "Akron,a ke lun,aekeuleon,akran, awhayw,akuron,ekran,ÐÐºÑÐ¾Ð½,Ø§Ú©Ø±Ø§ÙØ Ø§ÙÙØ§ÛÙ,à®à®à¯à®°à®©à¯,à´à´àµà´°àµàµº,ã¢ã¯ã­ã³,é¿åä¼¦,ì í¬ë°,Akron", :latitude => "41.08144", :longitude => "-81.51901").save
City.new(:country_id => "233", :name => "Alliance", :aliases => "Al'jans,ÐÐ»ÑÑÐ½Ñ,Alliance", :latitude => "40.91534", :longitude => "-81.10593").save
City.new(:country_id => "233", :name => "Ashland", :aliases => ",Ashland", :latitude => "40.86867", :longitude => "-82.31822").save
City.new(:country_id => "233", :name => "Ashtabula", :aliases => ",Ashtabula", :latitude => "41.86505", :longitude => "-80.78981").save
City.new(:country_id => "233", :name => "Austintown", :aliases => ",Austintown", :latitude => "41.10172", :longitude => "-80.76452").save
City.new(:country_id => "233", :name => "Avon Center", :aliases => ",Avon Center", :latitude => "41.45976", :longitude => "-82.01959").save
City.new(:country_id => "233", :name => "Avon Lake", :aliases => ",Avon Lake", :latitude => "41.50532", :longitude => "-82.0282").save
City.new(:country_id => "233", :name => "Barberton", :aliases => ",Barberton", :latitude => "41.01283", :longitude => "-81.60512").save
City.new(:country_id => "233", :name => "Bay Village", :aliases => ",Bay Village", :latitude => "41.48477", :longitude => "-81.92208").save
City.new(:country_id => "233", :name => "Berea", :aliases => "Berea,ÐÐµÑÐµÐ°,Berea", :latitude => "41.36616", :longitude => "-81.8543").save
City.new(:country_id => "233", :name => "Boardman", :aliases => "Bordman,ÐÐ¾ÑÐ´Ð¼Ð°Ð½,Boardman", :latitude => "41.02423", :longitude => "-80.66285").save
City.new(:country_id => "233", :name => "Bowling Green", :aliases => "Bouling-Grin,ÐÐ¾ÑÐ»Ð¸Ð½Ð³-ÐÑÐ¸Ð½,Bowling Green", :latitude => "41.37477", :longitude => "-83.65132").save
City.new(:country_id => "233", :name => "Broadview Heights", :aliases => ",Broadview Heights", :latitude => "41.31394", :longitude => "-81.68513").save
City.new(:country_id => "233", :name => "Brook Park", :aliases => ",Brook Park", :latitude => "41.39838", :longitude => "-81.80458").save
City.new(:country_id => "233", :name => "Brunswick", :aliases => "Braunshvejg,ÐÑÐ°ÑÐ½ÑÐ²ÐµÐ¹Ð³,Brunswick", :latitude => "41.23811", :longitude => "-81.8418").save
City.new(:country_id => "233", :name => "Canton", :aliases => "Canton,Canton", :latitude => "40.79895", :longitude => "-81.37845").save
City.new(:country_id => "233", :name => "Cleveland", :aliases => "Cleveland,Klevlando,Klivland,Klivlend,Klyvlendas,ke li fu lan,klyfland,kuriburando,qlyblnd,ÐÐ»Ð¸Ð²Ð»Ð°Ð½Ð´,ÐÐ»Ð¸Ð²Ð»ÐµÐ½Ð´,×§××××× ×,ÙÙÙÙÙØ§ÙØ¯,ã¯ãªã¼ãã©ã³ã,åéå¤«è­,Cleveland", :latitude => "41.4995", :longitude => "-81.69541").save
City.new(:country_id => "233", :name => "Cuyahoga Falls", :aliases => ",Cuyahoga Falls", :latitude => "41.13394", :longitude => "-81.48456").save
City.new(:country_id => "233", :name => "Defiance", :aliases => ",Defiance", :latitude => "41.28449", :longitude => "-84.35578").save
City.new(:country_id => "233", :name => "Delaware", :aliases => "Delavarskij,ÐÐµÐ»Ð°Ð²Ð°ÑÑÐºÐ¸Ð¹,Delaware", :latitude => "40.29867", :longitude => "-83.06796").save
City.new(:country_id => "233", :name => "Dublin", :aliases => "Dublin,ÐÑÐ±Ð»Ð¸Ð½,Dublin", :latitude => "40.09923", :longitude => "-83.11408").save
City.new(:country_id => "233", :name => "East Cleveland", :aliases => ",East Cleveland", :latitude => "41.53311", :longitude => "-81.57901").save
City.new(:country_id => "233", :name => "Eastlake", :aliases => ",Eastlake", :latitude => "41.65394", :longitude => "-81.45039").save
City.new(:country_id => "233", :name => "Elyria", :aliases => ",Elyria", :latitude => "41.36838", :longitude => "-82.10765").save
City.new(:country_id => "233", :name => "Euclid", :aliases => "Evklid,ÐÐ²ÐºÐ»Ð¸Ð´,Euclid", :latitude => "41.5931", :longitude => "-81.52679").save
City.new(:country_id => "233", :name => "Fairview Park", :aliases => ",Fairview Park", :latitude => "41.44144", :longitude => "-81.8643").save
City.new(:country_id => "233", :name => "Findlay", :aliases => "Findli,Ð¤Ð¸Ð½Ð´Ð»Ð¸,Findlay", :latitude => "41.04422", :longitude => "-83.64993").save
City.new(:country_id => "233", :name => "Fremont", :aliases => "Frimont,Ð¤ÑÐ¸Ð¼Ð¾Ð½Ñ,Fremont", :latitude => "41.35033", :longitude => "-83.12186").save
City.new(:country_id => "233", :name => "Gahanna", :aliases => ",Gahanna", :latitude => "40.01923", :longitude => "-82.87934").save
City.new(:country_id => "233", :name => "Garfield Heights", :aliases => ",Garfield Heights", :latitude => "41.417", :longitude => "-81.60596").save
City.new(:country_id => "233", :name => "Green", :aliases => ",Green", :latitude => "40.94589", :longitude => "-81.48317").save
City.new(:country_id => "233", :name => "Hilliard", :aliases => ",Hilliard", :latitude => "40.0334", :longitude => "-83.15825").save
City.new(:country_id => "233", :name => "Hudson", :aliases => "Gudzon,ÐÑÐ´Ð·Ð¾Ð½,Hudson", :latitude => "41.24006", :longitude => "-81.44067").save
City.new(:country_id => "233", :name => "Kent", :aliases => "Kent,ÐÐµÐ½Ñ,Kent", :latitude => "41.15367", :longitude => "-81.35789").save
City.new(:country_id => "233", :name => "Lakewood", :aliases => "Lejkvud,ÐÐµÐ¹ÐºÐ²ÑÐ´,Lakewood", :latitude => "41.48199", :longitude => "-81.79819").save
City.new(:country_id => "233", :name => "Lima", :aliases => "Lima,ÐÐ¸Ð¼Ð°,Lima", :latitude => "40.74255", :longitude => "-84.10523").save
City.new(:country_id => "233", :name => "Lorain", :aliases => "Lorain,Lorejn,ÐÐ¾ÑÐµÐ¹Ð½,Lorain", :latitude => "41.45282", :longitude => "-82.18237").save
City.new(:country_id => "233", :name => "Mansfield", :aliases => "Mehnsfild,ÐÑÐ½ÑÑÐ¸Ð»Ð´,Mansfield", :latitude => "40.75839", :longitude => "-82.51545").save
City.new(:country_id => "233", :name => "Maple Heights", :aliases => ",Maple Heights", :latitude => "41.41533", :longitude => "-81.56596").save
City.new(:country_id => "233", :name => "Marion", :aliases => "Mehrion,ÐÑÑÐ¸Ð¾Ð½,Marion", :latitude => "40.58867", :longitude => "-83.12852").save
City.new(:country_id => "233", :name => "Marysville", :aliases => ",Marysville", :latitude => "40.23645", :longitude => "-83.36714").save
City.new(:country_id => "233", :name => "Massillon", :aliases => ",Massillon", :latitude => "40.79672", :longitude => "-81.52151").save
City.new(:country_id => "233", :name => "Mayfield Heights", :aliases => ",Mayfield Heights", :latitude => "41.51922", :longitude => "-81.4579").save
City.new(:country_id => "233", :name => "Medina", :aliases => "Medina,ÐÐµÐ´Ð¸Ð½Ð°,Medina", :latitude => "41.13839", :longitude => "-81.86375").save
City.new(:country_id => "233", :name => "Mentor", :aliases => ",Mentor", :latitude => "41.66616", :longitude => "-81.33955").save
City.new(:country_id => "233", :name => "Middleburg Heights", :aliases => ",Middleburg Heights", :latitude => "41.36144", :longitude => "-81.81291").save
City.new(:country_id => "233", :name => "Mount Vernon", :aliases => ",Mount Vernon", :latitude => "40.3934", :longitude => "-82.48572").save
City.new(:country_id => "233", :name => "New Philadelphia", :aliases => ",New Philadelphia", :latitude => "40.48979", :longitude => "-81.44567").save
City.new(:country_id => "233", :name => "Newark", :aliases => "N'juark,ÐÑÑÐ°ÑÐº,Newark", :latitude => "40.05812", :longitude => "-82.40126").save
City.new(:country_id => "233", :name => "Niles", :aliases => ",Niles", :latitude => "41.18284", :longitude => "-80.76536").save
City.new(:country_id => "233", :name => "North Canton", :aliases => ",North Canton", :latitude => "40.87589", :longitude => "-81.40234").save
City.new(:country_id => "233", :name => "North Olmsted", :aliases => ",North Olmsted", :latitude => "41.4156", :longitude => "-81.92347").save
City.new(:country_id => "233", :name => "North Ridgeville", :aliases => ",North Ridgeville", :latitude => "41.38949", :longitude => "-82.01903").save
City.new(:country_id => "233", :name => "North Royalton", :aliases => ",North Royalton", :latitude => "41.31366", :longitude => "-81.72457").save
City.new(:country_id => "233", :name => "Norwalk", :aliases => ",Norwalk", :latitude => "41.24255", :longitude => "-82.61573").save
City.new(:country_id => "233", :name => "Oregon", :aliases => "Oregon,ÐÑÐµÐ³Ð¾Ð½,Oregon", :latitude => "41.64366", :longitude => "-83.48688").save
City.new(:country_id => "233", :name => "Painesville", :aliases => ",Painesville", :latitude => "41.72449", :longitude => "-81.24566").save
City.new(:country_id => "233", :name => "Parma", :aliases => "Parma,brma,ÐÐ°ÑÐ¼Ð°,Ø¨Ø±ÙØ§,Parma", :latitude => "41.40477", :longitude => "-81.72291").save
City.new(:country_id => "233", :name => "Parma Heights", :aliases => ",Parma Heights", :latitude => "41.39005", :longitude => "-81.75958").save
City.new(:country_id => "233", :name => "Perrysburg", :aliases => ",Perrysburg", :latitude => "41.557", :longitude => "-83.62716").save
City.new(:country_id => "233", :name => "Piqua", :aliases => ",Piqua", :latitude => "40.14477", :longitude => "-84.24244").save
City.new(:country_id => "233", :name => "Rocky River", :aliases => ",Rocky River", :latitude => "41.4756", :longitude => "-81.8393").save
City.new(:country_id => "233", :name => "Sandusky", :aliases => ",Sandusky", :latitude => "41.44894", :longitude => "-82.70796").save
City.new(:country_id => "233", :name => "Shaker Heights", :aliases => ",Shaker Heights", :latitude => "41.47394", :longitude => "-81.53707").save
City.new(:country_id => "233", :name => "Sidney", :aliases => "Sidnej,Ð¡Ð¸Ð´Ð½ÐµÐ¹,Sidney", :latitude => "40.28422", :longitude => "-84.1555").save
City.new(:country_id => "233", :name => "Solon", :aliases => "Solon,Ð¡Ð¾Ð»Ð¾Ð½,Solon", :latitude => "41.38978", :longitude => "-81.44123").save
City.new(:country_id => "233", :name => "South Euclid", :aliases => ",South Euclid", :latitude => "41.52311", :longitude => "-81.51846").save
City.new(:country_id => "233", :name => "Steubenville", :aliases => ",Steubenville", :latitude => "40.36979", :longitude => "-80.63396").save
City.new(:country_id => "233", :name => "Stow", :aliases => "Stou,Ð¡ÑÐ¾Ñ,Stow", :latitude => "41.1595", :longitude => "-81.44039").save
City.new(:country_id => "233", :name => "Streetsboro", :aliases => ",Streetsboro", :latitude => "41.23922", :longitude => "-81.34594").save
City.new(:country_id => "233", :name => "Strongsville", :aliases => ",Strongsville", :latitude => "41.3145", :longitude => "-81.83569").save
City.new(:country_id => "233", :name => "Sylvania", :aliases => ",Sylvania", :latitude => "41.71894", :longitude => "-83.71299").save
City.new(:country_id => "233", :name => "Tallmadge", :aliases => ",Tallmadge", :latitude => "41.10145", :longitude => "-81.44178").save
City.new(:country_id => "233", :name => "Tiffin", :aliases => ",Tiffin", :latitude => "41.1145", :longitude => "-83.17797").save
City.new(:country_id => "233", :name => "Toledo", :aliases => "Toledo,toredo,tuo lai duo,Ð¢Ð¾Ð»ÐµÐ´Ð¾,ãã¬ã,æè±å¤,Toledo", :latitude => "41.66394", :longitude => "-83.55521").save
City.new(:country_id => "233", :name => "Troy", :aliases => "Troja,Ð¢ÑÐ¾Ñ,Troy", :latitude => "40.0395", :longitude => "-84.20328").save
City.new(:country_id => "233", :name => "Twinsburg", :aliases => ",Twinsburg", :latitude => "41.31256", :longitude => "-81.44011").save
City.new(:country_id => "233", :name => "Wadsworth", :aliases => ",Wadsworth", :latitude => "41.02561", :longitude => "-81.72985").save
City.new(:country_id => "233", :name => "Warren", :aliases => "Uorren,Ð£Ð¾ÑÑÐµÐ½,Warren", :latitude => "41.23756", :longitude => "-80.81842").save
City.new(:country_id => "233", :name => "Westerville", :aliases => ",Westerville", :latitude => "40.12617", :longitude => "-82.92907").save
City.new(:country_id => "233", :name => "Westlake", :aliases => ",Westlake", :latitude => "41.45532", :longitude => "-81.91792").save
City.new(:country_id => "233", :name => "Willoughby", :aliases => "Uilloubi,Ð£Ð¸Ð»Ð»Ð¾ÑÐ±Ð¸,Willoughby", :latitude => "41.63977", :longitude => "-81.4065").save
City.new(:country_id => "233", :name => "Wooster", :aliases => "Vuster,ÐÑÑÑÐµÑ,Wooster", :latitude => "40.80506", :longitude => "-81.93514").save
City.new(:country_id => "233", :name => "Youngstown", :aliases => "Youngstown,Youngstown", :latitude => "41.09978", :longitude => "-80.64952").save
City.new(:country_id => "233", :name => "Allentown", :aliases => "Allenschteddel,Allentaun,Allentown,ÐÐ»Ð»ÐµÐ½ÑÐ°ÑÐ½,Allentown", :latitude => "40.60843", :longitude => "-75.49018").save
City.new(:country_id => "233", :name => "Altoona", :aliases => "Altuna,ÐÐ»ÑÑÐ½Ð°,Altoona", :latitude => "40.51868", :longitude => "-78.39474").save
City.new(:country_id => "233", :name => "Back Mountain", :aliases => ",Back Mountain", :latitude => "41.33591", :longitude => "-75.99631").save
City.new(:country_id => "233", :name => "Baldwin", :aliases => ",Baldwin", :latitude => "40.33813", :longitude => "-79.97894").save
City.new(:country_id => "233", :name => "Bethel Park", :aliases => ",Bethel Park", :latitude => "40.32757", :longitude => "-80.0395").save
City.new(:country_id => "233", :name => "Bethlehem", :aliases => "Bethlehem,Vifleem,ÐÐ¸ÑÐ»ÐµÐµÐ¼,Bethlehem", :latitude => "40.62593", :longitude => "-75.37046").save
City.new(:country_id => "233", :name => "Carlisle", :aliases => ",Carlisle", :latitude => "40.20148", :longitude => "-77.18887").save
City.new(:country_id => "233", :name => "Easton", :aliases => "Iston,ÐÑÑÐ¾Ð½,Easton", :latitude => "40.68843", :longitude => "-75.22073").save
City.new(:country_id => "233", :name => "Erie", :aliases => "Ehri,Erie,yi li,ÃriÃ©,Ð­ÑÐ¸,ä¼å©,Erie", :latitude => "42.12922", :longitude => "-80.08506").save
City.new(:country_id => "233", :name => "Greensburg", :aliases => ",Greensburg", :latitude => "40.30146", :longitude => "-79.53893").save
City.new(:country_id => "233", :name => "Harrisburg", :aliases => "Harrisbarrig,Harrisburg,Kharisburg,ha li si bao,harisubagu,Ð¥Ð°ÑÐ¸ÑÐ±ÑÑÐ³,ããªã¹ãã¼ã°,åéæ¯å ¡,Harrisburg", :latitude => "40.2737", :longitude => "-76.88442").save
City.new(:country_id => "233", :name => "Hazleton", :aliases => ",Hazleton", :latitude => "40.95842", :longitude => "-75.97465").save
City.new(:country_id => "233", :name => "Hermitage", :aliases => ",Hermitage", :latitude => "41.23339", :longitude => "-80.44868").save
City.new(:country_id => "233", :name => "Johnstown", :aliases => "Dzhonstaun,ÐÐ¶Ð¾Ð½ÑÑÐ°ÑÐ½,Johnstown", :latitude => "40.32674", :longitude => "-78.92197").save
City.new(:country_id => "233", :name => "King of Prussia", :aliases => ",King of Prussia", :latitude => "40.08927", :longitude => "-75.39602").save
City.new(:country_id => "233", :name => "Lancaster", :aliases => "Lancaster,Lankast'r,Lankaster,Lengeschder,ÐÐ°Ð½ÐºÐ°ÑÑÐµÑ,ÐÐ°Ð½ÐºÐ°ÑÑÑÑ,Lancaster", :latitude => "40.03788", :longitude => "-76.30551").save
City.new(:country_id => "233", :name => "Lansdale", :aliases => ",Lansdale", :latitude => "40.2415", :longitude => "-75.28379").save
City.new(:country_id => "233", :name => "Lebanon", :aliases => ",Lebanon", :latitude => "40.34093", :longitude => "-76.41135").save
City.new(:country_id => "233", :name => "Levittown", :aliases => ",Levittown", :latitude => "40.15511", :longitude => "-74.82877").save
City.new(:country_id => "233", :name => "McKeesport", :aliases => ",McKeesport", :latitude => "40.34785", :longitude => "-79.86422").save
City.new(:country_id => "233", :name => "Monroeville", :aliases => ",Monroeville", :latitude => "40.42118", :longitude => "-79.7881").save
City.new(:country_id => "233", :name => "Mount Lebanon", :aliases => ",Mount Lebanon", :latitude => "40.35535", :longitude => "-80.0495").save
City.new(:country_id => "233", :name => "Mountain Top", :aliases => ",Mountain Top", :latitude => "40.10677", :longitude => "-75.95272").save
City.new(:country_id => "233", :name => "Mountain Top", :aliases => ",Mountain Top", :latitude => "41.16953", :longitude => "-75.87742").save
City.new(:country_id => "233", :name => "Murrysville", :aliases => ",Murrysville", :latitude => "40.4284", :longitude => "-79.69754").save
City.new(:country_id => "233", :name => "New Castle", :aliases => ",New Castle", :latitude => "41.00367", :longitude => "-80.34701").save
City.new(:country_id => "233", :name => "Norristown", :aliases => ",Norristown", :latitude => "40.1215", :longitude => "-75.3399").save
City.new(:country_id => "233", :name => "Penn Hills", :aliases => ",Penn Hills", :latitude => "40.50118", :longitude => "-79.83922").save
City.new(:country_id => "233", :name => "Pittsburgh", :aliases => "Pitsb'rg,Pitsburg,Pitsburgas,Pittsbarig,Pittsburgh,Pittsburgum,pi zi bao,pittsubagu,pytsbwrg,ÐÐ¸ÑÑÐ±ÑÑÐ³,ÐÐ¸ÑÑÐ±ÑÑÐ³,×¤×××¡×××¨×,ããããã¼ã°,å¹å¹å ¡,Pittsburgh", :latitude => "40.44062", :longitude => "-79.99589").save
City.new(:country_id => "233", :name => "Plum", :aliases => ",Plum", :latitude => "40.50035", :longitude => "-79.74949").save
City.new(:country_id => "233", :name => "Pottstown", :aliases => ",Pottstown", :latitude => "40.24537", :longitude => "-75.64963").save
City.new(:country_id => "233", :name => "Radnor", :aliases => ",Radnor", :latitude => "40.04622", :longitude => "-75.35991").save
City.new(:country_id => "233", :name => "Reading", :aliases => "Reading,Reddin,Reding,Ð ÐµÐ´Ð¸Ð½Ð³,Reading", :latitude => "40.33565", :longitude => "-75.92687").save
City.new(:country_id => "233", :name => "Scranton", :aliases => "Scranton,Skrenton,Ð¡ÐºÑÐµÐ½ÑÐ¾Ð½,Scranton", :latitude => "41.40897", :longitude => "-75.66241").save
City.new(:country_id => "233", :name => "Sharon", :aliases => "Sharon,Ð¨Ð°ÑÐ¾Ð½,Sharon", :latitude => "41.23311", :longitude => "-80.4934").save
City.new(:country_id => "233", :name => "State College", :aliases => ",State College", :latitude => "40.7934", :longitude => "-77.86").save
City.new(:country_id => "233", :name => "Upper Saint Clair", :aliases => ",Upper Saint Clair", :latitude => "40.3359", :longitude => "-80.08339").save
City.new(:country_id => "233", :name => "West Mifflin", :aliases => ",West Mifflin", :latitude => "40.3634", :longitude => "-79.86644").save
City.new(:country_id => "233", :name => "Whitehall Township", :aliases => "Township of Whitehall,Whitehall,Whitehall Township", :latitude => "40.66676", :longitude => "-75.49991").save
City.new(:country_id => "233", :name => "Wilkes-Barre", :aliases => "Uilks-Barre,Wilkes Barre,Ð£Ð¸Ð»ÐºÑ-ÐÐ°ÑÑÐµ,Wilkes-Barre", :latitude => "41.24591", :longitude => "-75.88131").save
City.new(:country_id => "233", :name => "Wilkinsburg", :aliases => ",Wilkinsburg", :latitude => "40.44174", :longitude => "-79.88199").save
City.new(:country_id => "233", :name => "Williamsport", :aliases => ",Williamsport", :latitude => "41.24119", :longitude => "-77.00108").save
City.new(:country_id => "233", :name => "Willow Grove", :aliases => ",Willow Grove", :latitude => "40.144", :longitude => "-75.11573").save
City.new(:country_id => "233", :name => "Barrington", :aliases => ",Barrington", :latitude => "41.74066", :longitude => "-71.30866").save
City.new(:country_id => "233", :name => "Bristol", :aliases => ",Bristol", :latitude => "41.67705", :longitude => "-71.26616").save
City.new(:country_id => "233", :name => "Central Falls", :aliases => ",Central Falls", :latitude => "41.89066", :longitude => "-71.39228").save
City.new(:country_id => "233", :name => "Coventry", :aliases => "Koventri,ÐÐ¾Ð²ÐµÐ½ÑÑÐ¸,Coventry", :latitude => "41.7001", :longitude => "-71.68284").save
City.new(:country_id => "233", :name => "Cranston", :aliases => "Cranston,Krehnston,ÐÑÑÐ½ÑÑÐ¾Ð½,Cranston", :latitude => "41.77982", :longitude => "-71.43728").save
City.new(:country_id => "233", :name => "Cumberland", :aliases => "Kamberlend,ÐÐ°Ð¼Ð±ÐµÑÐ»ÐµÐ½Ð´,Cumberland", :latitude => "41.96677", :longitude => "-71.43284").save
City.new(:country_id => "233", :name => "East Providence", :aliases => ",East Providence", :latitude => "41.81371", :longitude => "-71.37005").save
City.new(:country_id => "233", :name => "Middletown", :aliases => ",Middletown", :latitude => "41.54566", :longitude => "-71.29144").save
City.new(:country_id => "233", :name => "Narragansett Pier", :aliases => ",Narragansett Pier", :latitude => "41.43232", :longitude => "-71.45644").save
City.new(:country_id => "233", :name => "Newport", :aliases => "N'juport,Newport,nyupoto,nywpwrt,ÐÑÑÐ¿Ð¾ÑÑ,× ×××¤××¨×,ãã¥ã¼ãã¼ã,Newport", :latitude => "41.4901", :longitude => "-71.31283").save
City.new(:country_id => "233", :name => "North Kingstown", :aliases => ",North Kingstown", :latitude => "41.5501", :longitude => "-71.46617").save
City.new(:country_id => "233", :name => "North Providence", :aliases => ",North Providence", :latitude => "41.8501", :longitude => "-71.46617").save
City.new(:country_id => "233", :name => "Pawtucket", :aliases => "Pawtucket,Pawtucket", :latitude => "41.87871", :longitude => "-71.38256").save
City.new(:country_id => "233", :name => "Portsmouth", :aliases => "Portsmut,ÐÐ¾ÑÑÑÐ¼ÑÑ,Portsmouth", :latitude => "41.60232", :longitude => "-71.25033").save
City.new(:country_id => "233", :name => "Providence", :aliases => "Provid'ns,Providence,Providensa,Providentia,prwbydns,pu luo wei dun si,purobidensu,purovu~idensu,ÐÑÐ¾Ð²Ð¸Ð´ÑÐ½Ñ,×¤×¨××××× ×¡,Ù¾Ø±ÙÙÛÚÙØ³Ø Ø±ÛÙÚ Ø¢Ø¦Û ÙÛÙÚ,ãã­ããã³ã¹,ãã­ã´ã£ãã³ã¹,æ®æ´å¨é æ¯,Providence", :latitude => "41.82399", :longitude => "-71.41283").save
City.new(:country_id => "233", :name => "Smithfield", :aliases => ",Smithfield", :latitude => "41.92204", :longitude => "-71.54951").save
City.new(:country_id => "233", :name => "Tiverton", :aliases => ",Tiverton", :latitude => "41.62594", :longitude => "-71.21338").save
City.new(:country_id => "233", :name => "Warwick", :aliases => "Warwick,Warwick", :latitude => "41.7001", :longitude => "-71.41617").save
City.new(:country_id => "233", :name => "West Warwick", :aliases => ",West Warwick", :latitude => "41.69689", :longitude => "-71.52194").save
City.new(:country_id => "233", :name => "Westerly", :aliases => ",Westerly", :latitude => "41.3776", :longitude => "-71.82729").save
City.new(:country_id => "233", :name => "Woonsocket", :aliases => ",Woonsocket", :latitude => "42.00288", :longitude => "-71.51478").save
City.new(:country_id => "233", :name => "Aberdeen", :aliases => "Aberdin,ÐÐ±ÐµÑÐ´Ð¸Ð½,Aberdeen", :latitude => "45.4647", :longitude => "-98.48648").save
City.new(:country_id => "233", :name => "Brookings", :aliases => ",Brookings", :latitude => "44.31136", :longitude => "-96.79839").save
City.new(:country_id => "233", :name => "Sioux Falls", :aliases => "Sioux Falls,Su-Fols,suforuzu,Ð¡Ñ-Ð¤Ð¾Ð»Ñ,ã¹ã¼ãã©ã¼ã«ãº,Sioux Falls", :latitude => "43.54997", :longitude => "-96.70033").save
City.new(:country_id => "233", :name => "Watertown", :aliases => ",Watertown", :latitude => "44.89941", :longitude => "-97.11507").save
City.new(:country_id => "233", :name => "Bennington", :aliases => ",Bennington", :latitude => "42.87813", :longitude => "-73.19677").save
City.new(:country_id => "233", :name => "Burlington", :aliases => "Berlington,Burlington,barinton,bo ling dun,ÐÐµÑÐ»Ð¸Ð½Ð³ÑÐ¾Ð½,ãã¼ãªã³ãã³,ä¼¯éé ,Burlington", :latitude => "44.47588", :longitude => "-73.21207").save
City.new(:country_id => "233", :name => "Colchester", :aliases => ",Colchester", :latitude => "44.54394", :longitude => "-73.14791").save
City.new(:country_id => "233", :name => "Essex Junction", :aliases => ",Essex Junction", :latitude => "44.49061", :longitude => "-73.11096").save
City.new(:country_id => "233", :name => "Rutland", :aliases => "Ratlend,Ð Ð°ÑÐ»ÐµÐ½Ð´,Rutland", :latitude => "43.61062", :longitude => "-72.97261").save
City.new(:country_id => "233", :name => "South Burlington", :aliases => ",South Burlington", :latitude => "44.46699", :longitude => "-73.17096").save
City.new(:country_id => "233", :name => "Appleton", :aliases => "Appleton,appuruton,ã¢ããã«ãã³,Appleton", :latitude => "44.26193", :longitude => "-88.41538").save
City.new(:country_id => "233", :name => "Ashwaubenon", :aliases => ",Ashwaubenon", :latitude => "44.48221", :longitude => "-88.0701").save
City.new(:country_id => "233", :name => "Beloit", :aliases => ",Beloit", :latitude => "42.50835", :longitude => "-89.03178").save
City.new(:country_id => "233", :name => "Brookfield", :aliases => ",Brookfield", :latitude => "43.06057", :longitude => "-88.10648").save
City.new(:country_id => "233", :name => "Caledonia", :aliases => "Kaledonija,ÐÐ°Ð»ÐµÐ´Ð¾Ð½Ð¸Ñ,Caledonia", :latitude => "42.8078", :longitude => "-87.92425").save
City.new(:country_id => "233", :name => "Cudahy", :aliases => ",Cudahy", :latitude => "42.95974", :longitude => "-87.86147").save
City.new(:country_id => "233", :name => "De Pere", :aliases => "Depere,De Pere", :latitude => "44.44888", :longitude => "-88.06038").save
City.new(:country_id => "233", :name => "Eau Claire", :aliases => "Eau Claire,Eau Claire", :latitude => "44.81135", :longitude => "-91.49849").save
City.new(:country_id => "233", :name => "Fitchburg", :aliases => ",Fitchburg", :latitude => "42.96083", :longitude => "-89.46984").save
City.new(:country_id => "233", :name => "Fond du Lac", :aliases => "Fon-dju-Lak,Ð¤Ð¾Ð½-Ð´Ñ-ÐÐ°Ðº,Fond du Lac", :latitude => "43.775", :longitude => "-88.43883").save
City.new(:country_id => "233", :name => "Franklin", :aliases => "Franklin,Ð¤ÑÐ°Ð½ÐºÐ»Ð¸Ð½,Franklin", :latitude => "42.88863", :longitude => "-88.03842").save
City.new(:country_id => "233", :name => "Germantown", :aliases => ",Germantown", :latitude => "43.22862", :longitude => "-88.11037").save
City.new(:country_id => "233", :name => "Green Bay", :aliases => "Green Bay,ge lin bei,gurinbei,kri nbey,à¸à¸£à¸µà¸à¹à¸à¸¢à¹,ã°ãªã¼ã³ãã¤,æ ¼æè´,Green Bay", :latitude => "44.51916", :longitude => "-88.01983").save
City.new(:country_id => "233", :name => "Greenfield", :aliases => "Grinfild,ÐÑÐ¸Ð½ÑÐ¸Ð»Ð´,Greenfield", :latitude => "42.9614", :longitude => "-88.01259").save
City.new(:country_id => "233", :name => "Janesville", :aliases => "Janesville,Janesville", :latitude => "42.68279", :longitude => "-89.01872").save
City.new(:country_id => "233", :name => "Kenosha", :aliases => "Chiave per bussole,Kenosha,Kenosha", :latitude => "42.58474", :longitude => "-87.82119").save
City.new(:country_id => "233", :name => "La Crosse", :aliases => "La-Kross,ÐÐ°-ÐÑÐ¾ÑÑ,La Crosse", :latitude => "43.80136", :longitude => "-91.23958").save
City.new(:country_id => "233", :name => "Madison", :aliases => "Madison,Madisonas,Madisonia,Medisun,madison,mai di xun,maidisana,mdyswn,ÐÐµÐ´Ð¸ÑÑÐ½,××××¡××,ÙØ¯ÛØ³ÙÙ,à¤®à¥à¤¡à¤¿à¤¸à¤¨,ããã£ã½ã³,éº¦è¿ªé,Madison", :latitude => "43.07305", :longitude => "-89.40123").save
City.new(:country_id => "233", :name => "Manitowoc", :aliases => ",Manitowoc", :latitude => "44.08861", :longitude => "-87.65758").save
City.new(:country_id => "233", :name => "Marshfield", :aliases => ",Marshfield", :latitude => "44.66885", :longitude => "-90.1718").save
City.new(:country_id => "233", :name => "Menasha", :aliases => ",Menasha", :latitude => "44.20221", :longitude => "-88.4465").save
City.new(:country_id => "233", :name => "Menomonee Falls", :aliases => ",Menomonee Falls", :latitude => "43.1789", :longitude => "-88.11731").save
City.new(:country_id => "233", :name => "Menominee", :aliases => ",Menominee", :latitude => "44.87552", :longitude => "-91.91934").save
City.new(:country_id => "233", :name => "Mequon", :aliases => ",Mequon", :latitude => "43.2364", :longitude => "-87.98453").save
City.new(:country_id => "233", :name => "Middleton", :aliases => ",Middleton", :latitude => "43.09722", :longitude => "-89.50429").save
City.new(:country_id => "233", :name => "Milwaukee", :aliases => "Miluoki,Milvauchia,Milvokis,Milwaukee,mi er wo ji,miruu~oki,mylwwqy,ÐÐ¸Ð»ÑÐ¾ÐºÐ¸,××××××§×,ãã«ã¦ã©ã¼ã­ã¼,å¯å°æ²åº,Milwaukee", :latitude => "43.0389", :longitude => "-87.90647").save
City.new(:country_id => "233", :name => "Muskego", :aliases => ",Muskego", :latitude => "42.90585", :longitude => "-88.13898").save
City.new(:country_id => "233", :name => "Neenah", :aliases => ",Neenah", :latitude => "44.18582", :longitude => "-88.46261").save
City.new(:country_id => "233", :name => "New Berlin", :aliases => ",New Berlin", :latitude => "42.9764", :longitude => "-88.10842").save
City.new(:country_id => "233", :name => "North La Crosse", :aliases => ",North La Crosse", :latitude => "43.84635", :longitude => "-91.24819").save
City.new(:country_id => "233", :name => "Oak Creek", :aliases => ",Oak Creek", :latitude => "42.88585", :longitude => "-87.86314").save
City.new(:country_id => "233", :name => "Onalaska", :aliases => ",Onalaska", :latitude => "43.88441", :longitude => "-91.23514").save
City.new(:country_id => "233", :name => "Oshkosh", :aliases => "Oshkosh,Oshkosh", :latitude => "44.02471", :longitude => "-88.54261").save
City.new(:country_id => "233", :name => "Pleasant Prairie", :aliases => ",Pleasant Prairie", :latitude => "42.55308", :longitude => "-87.93341").save
City.new(:country_id => "233", :name => "Racine", :aliases => "Racine,Rasijn,Rasin,Ð Ð°ÑÐ¸Ð¹Ð½,Ð Ð°ÑÐ¸Ð½,Racine", :latitude => "42.72613", :longitude => "-87.78285").save
City.new(:country_id => "233", :name => "Sheboygan", :aliases => "Shebojgan,Ð¨ÐµÐ±Ð¾Ð¹Ð³Ð°Ð½,Sheboygan", :latitude => "43.75083", :longitude => "-87.71453").save
City.new(:country_id => "233", :name => "South Milwaukee", :aliases => ",South Milwaukee", :latitude => "42.91057", :longitude => "-87.86064").save
City.new(:country_id => "233", :name => "Stevens Point", :aliases => ",Stevens Point", :latitude => "44.52358", :longitude => "-89.57456").save
City.new(:country_id => "233", :name => "Sun Prairie", :aliases => ",Sun Prairie", :latitude => "43.1836", :longitude => "-89.21373").save
City.new(:country_id => "233", :name => "Superior", :aliases => ",Superior", :latitude => "46.72077", :longitude => "-92.10408").save
City.new(:country_id => "233", :name => "Watertown", :aliases => ",Watertown", :latitude => "43.19472", :longitude => "-88.72899").save
City.new(:country_id => "233", :name => "Waukesha", :aliases => "Waukesha,Waukesha", :latitude => "43.01168", :longitude => "-88.23148").save
City.new(:country_id => "233", :name => "Wausau", :aliases => ",Wausau", :latitude => "44.95914", :longitude => "-89.63012").save
City.new(:country_id => "233", :name => "Wauwatosa", :aliases => ",Wauwatosa", :latitude => "43.04946", :longitude => "-88.00759").save
City.new(:country_id => "233", :name => "West Allis", :aliases => ",West Allis", :latitude => "43.01668", :longitude => "-88.00703").save
City.new(:country_id => "233", :name => "West Bend", :aliases => ",West Bend", :latitude => "43.42528", :longitude => "-88.18343").save
City.new(:country_id => "233", :name => "Wisconsin Rapids", :aliases => ",Wisconsin Rapids", :latitude => "44.38358", :longitude => "-89.81735").save
City.new(:country_id => "233", :name => "Weirton", :aliases => ",Weirton", :latitude => "40.41896", :longitude => "-80.58952").save
City.new(:country_id => "233", :name => "Weirton Heights", :aliases => ",Weirton Heights", :latitude => "40.4084", :longitude => "-80.53924").save
City.new(:country_id => "233", :name => "Wheeling", :aliases => ",Wheeling", :latitude => "40.06396", :longitude => "-80.72091").save
City.new(:country_id => "233", :name => "Groton", :aliases => ",Groton", :latitude => "42.6112", :longitude => "-71.57451").save
City.new(:country_id => "233", :name => "Ansonia", :aliases => ",Ansonia", :latitude => "41.34621", :longitude => "-73.079").save
City.new(:country_id => "233", :name => "Bridgeport", :aliases => "Bridgeport,burijjipoto,ããªãã¸ãã¼ã,Bridgeport", :latitude => "41.16704", :longitude => "-73.20483").save
City.new(:country_id => "233", :name => "Bristol", :aliases => "Bristol,Bristol", :latitude => "41.67176", :longitude => "-72.94927").save
City.new(:country_id => "233", :name => "Branford", :aliases => ",Branford", :latitude => "41.27954", :longitude => "-72.8151").save
City.new(:country_id => "233", :name => "Cheshire", :aliases => "Cheshir,Ð§ÐµÑÐ¸Ñ,Cheshire", :latitude => "41.49899", :longitude => "-72.90066").save
City.new(:country_id => "233", :name => "Colchester", :aliases => ",Colchester", :latitude => "41.57565", :longitude => "-72.33203").save
City.new(:country_id => "233", :name => "Fillmore", :aliases => ",Fillmore", :latitude => "34.39916", :longitude => "-118.91815").save
City.new(:country_id => "233", :name => "Bullhead City", :aliases => ",Bullhead City", :latitude => "35.14778", :longitude => "-114.5683").save
City.new(:country_id => "233", :name => "Casa Grande", :aliases => ",Casa Grande", :latitude => "32.8795", :longitude => "-111.75735").save
City.new(:country_id => "233", :name => "Casas Adobes", :aliases => "Casas Adobes,Casas Adobes", :latitude => "32.32341", :longitude => "-110.9951").save
City.new(:country_id => "233", :name => "Catalina Foothills", :aliases => "Catalina Foothills,Catalina Foothills", :latitude => "32.29785", :longitude => "-110.9187").save
City.new(:country_id => "233", :name => "Chandler", :aliases => "Chandler,chandora,Ð§Ð°Ð½Ð´Ð»ÐµÑ,ãã£ã³ãã©ã¼,Chandler", :latitude => "33.30616", :longitude => "-111.84125").save
City.new(:country_id => "233", :name => "Douglas", :aliases => ",Douglas", :latitude => "31.34455", :longitude => "-109.54534").save
City.new(:country_id => "233", :name => "Drexel Heights", :aliases => ",Drexel Heights", :latitude => "32.14119", :longitude => "-111.02843").save
City.new(:country_id => "233", :name => "El Mirage", :aliases => ",El Mirage", :latitude => "33.61309", :longitude => "-112.3246").save
City.new(:country_id => "233", :name => "Flagstaff", :aliases => "Flagshtok,Flagstaff,flgstf,furaggusutaffu,Ð¤Ð»Ð°Ð³ÑÑÐ¾Ðº,ÙÙÚ¯Ø³ØªÙ,ááááµá³áá¥ á áªáá,ãã©ãã°ã¹ã¿ãã,Flagstaff", :latitude => "35.19807", :longitude => "-111.65127").save
City.new(:country_id => "233", :name => "Florence", :aliases => "Florencija,Ð¤Ð»Ð¾ÑÐµÐ½ÑÐ¸Ñ,Florence", :latitude => "33.03145", :longitude => "-111.38734").save
City.new(:country_id => "233", :name => "Flowing Wells", :aliases => ",Flowing Wells", :latitude => "32.29396", :longitude => "-111.00982").save
City.new(:country_id => "233", :name => "Fortuna Foothills", :aliases => ",Fortuna Foothills", :latitude => "32.65783", :longitude => "-114.41189").save
City.new(:country_id => "233", :name => "Fountain Hills", :aliases => ",Fountain Hills", :latitude => "33.61171", :longitude => "-111.71736").save
City.new(:country_id => "233", :name => "Gilbert", :aliases => "Gilbert,ÐÐ¸Ð»Ð±ÐµÑÑ,Gilbert", :latitude => "33.35283", :longitude => "-111.78903").save
City.new(:country_id => "233", :name => "Glendale", :aliases => "Glendale,Glendejl,ÐÐ»ÐµÐ½Ð´ÐµÐ¹Ð»,Glendale", :latitude => "33.53865", :longitude => "-112.18599").save
City.new(:country_id => "233", :name => "Goodyear", :aliases => ",Goodyear", :latitude => "33.43532", :longitude => "-112.35821").save
City.new(:country_id => "233", :name => "Green Valley", :aliases => ",Green Valley", :latitude => "31.85425", :longitude => "-110.9937").save
City.new(:country_id => "233", :name => "Kingman", :aliases => "Kingmen,ÐÐ¸Ð½Ð³Ð¼ÐµÐ½,Kingman", :latitude => "35.18944", :longitude => "-114.05301").save
City.new(:country_id => "233", :name => "Lake Havasu City", :aliases => ",Lake Havasu City", :latitude => "34.4839", :longitude => "-114.32245").save
City.new(:country_id => "233", :name => "Mesa", :aliases => "Mesa,mesa,ÐÐµÑÐ°,ã¡ãµ,Mesa", :latitude => "33.42227", :longitude => "-111.82264").save
City.new(:country_id => "233", :name => "Mohave Valley", :aliases => ",Mohave Valley", :latitude => "34.93306", :longitude => "-114.58885").save
City.new(:country_id => "233", :name => "Nogales", :aliases => "Nogales,ÐÐ¾Ð³Ð°Ð»ÐµÑ,Nogales", :latitude => "31.34038", :longitude => "-110.93425").save
City.new(:country_id => "233", :name => "Oro Valley", :aliases => ",Oro Valley", :latitude => "32.39091", :longitude => "-110.96649").save
City.new(:country_id => "233", :name => "Peoria", :aliases => "Peoria,Peorija,ÐÐµÐ¾ÑÐ¸Ñ,Peoria", :latitude => "33.5806", :longitude => "-112.23738").save
City.new(:country_id => "233", :name => "Phoenix", :aliases => "Fenikso,Finiks,Peniki,Phoenix,PÄniki,feng huang cheng,fenikkusu,fwnyks,fynyks,pnyqs,pynyqs,Ð¤Ð¸Ð½Ð¸ÐºÑ,×¤×× ××§×¡,×¤× ××§×¡,ÙÙÙÛÚ©Ø³,ÙÙÙÙÙØ³,ãã§ããã¯ã¹,å¤å°å,é³³å°å,Phoenix", :latitude => "33.44838", :longitude => "-112.07404").save
City.new(:country_id => "233", :name => "Prescott", :aliases => ",Prescott", :latitude => "34.54002", :longitude => "-112.4685").save
City.new(:country_id => "233", :name => "Prescott Valley", :aliases => ",Prescott Valley", :latitude => "34.58941", :longitude => "-112.32525").save
City.new(:country_id => "233", :name => "San Luis", :aliases => ",San Luis", :latitude => "32.487", :longitude => "-114.78218").save
City.new(:country_id => "233", :name => "Scottsdale", :aliases => "Scottsdale,si ke ci dai er,sukottsuderu,ã¹ã³ãããã¼ã«,æ¯ç§è¨ä»£ç¾,Scottsdale", :latitude => "33.50921", :longitude => "-111.89903").save
City.new(:country_id => "233", :name => "Sierra Vista", :aliases => ",Sierra Vista", :latitude => "31.55454", :longitude => "-110.30369").save
City.new(:country_id => "233", :name => "Sun City", :aliases => ",Sun City", :latitude => "33.59754", :longitude => "-112.27182").save
City.new(:country_id => "233", :name => "Sun City West", :aliases => ",Sun City West", :latitude => "33.66198", :longitude => "-112.34127").save
City.new(:country_id => "233", :name => "Sun Lakes", :aliases => ",Sun Lakes", :latitude => "33.21116", :longitude => "-111.87542").save
City.new(:country_id => "233", :name => "Surprise", :aliases => "Sjurpriz,Ð¡ÑÑÐ¿ÑÐ¸Ð·,Surprise", :latitude => "33.63059", :longitude => "-112.33322").save
City.new(:country_id => "233", :name => "Tanque Verde", :aliases => ",Tanque Verde", :latitude => "32.25174", :longitude => "-110.73731").save
City.new(:country_id => "233", :name => "Tempe", :aliases => "Tempe,Ð¢ÐµÐ¼Ð¿Ðµ,Tempe", :latitude => "33.41477", :longitude => "-111.90931").save
City.new(:country_id => "233", :name => "Tempe Junction", :aliases => ",Tempe Junction", :latitude => "33.41421", :longitude => "-111.94348").save
City.new(:country_id => "233", :name => "Tucson", :aliases => "Tjuson,Tucson,tsuson,tu sen,twswn,Ð¢ÑÑÐ¾Ð½,×××¡××,ãã¼ã½ã³,å¾æ£®,Tucson", :latitude => "32.22174", :longitude => "-110.92648").save
City.new(:country_id => "233", :name => "Tucson Estates", :aliases => ",Tucson Estates", :latitude => "32.18758", :longitude => "-111.09093").save
City.new(:country_id => "233", :name => "Yuma", :aliases => "Juma,Yuma,Ð®Ð¼Ð°,Yuma", :latitude => "32.72532", :longitude => "-114.6244").save
City.new(:country_id => "233", :name => "Adelanto", :aliases => ",Adelanto", :latitude => "34.58277", :longitude => "-117.40922").save
City.new(:country_id => "233", :name => "Agoura", :aliases => ",Agoura", :latitude => "34.14306", :longitude => "-118.73787").save
City.new(:country_id => "233", :name => "Agoura Hills", :aliases => ",Agoura Hills", :latitude => "34.13639", :longitude => "-118.77453").save
City.new(:country_id => "233", :name => "Alameda", :aliases => "Alameda,ÐÐ»Ð°Ð¼ÐµÐ´Ð°,Alameda", :latitude => "37.76521", :longitude => "-122.24164").save
City.new(:country_id => "233", :name => "Alamo", :aliases => ",Alamo", :latitude => "37.8502", :longitude => "-122.03218").save
City.new(:country_id => "233", :name => "Albany", :aliases => "Olbani,ÐÐ»Ð±Ð°Ð½Ð¸,Albany", :latitude => "37.88687", :longitude => "-122.29775").save
City.new(:country_id => "233", :name => "Alhambra", :aliases => "Al'gambra,Alhambra,ÐÐ»ÑÐ³Ð°Ð¼Ð±ÑÐ°,Alhambra", :latitude => "34.09529", :longitude => "-118.12701").save
City.new(:country_id => "233", :name => "Aliso Viejo", :aliases => ",Aliso Viejo", :latitude => "33.56504", :longitude => "-117.72712").save
City.new(:country_id => "233", :name => "Alpine", :aliases => ",Alpine", :latitude => "32.83505", :longitude => "-116.76641").save
City.new(:country_id => "233", :name => "Altadena", :aliases => ",Altadena", :latitude => "34.18973", :longitude => "-118.13118").save
City.new(:country_id => "233", :name => "American Canyon", :aliases => ",American Canyon", :latitude => "38.17492", :longitude => "-122.2608").save
City.new(:country_id => "233", :name => "Anaheim", :aliases => "Anaheim,Anakhajm,an na han,anahaimu,ÐÐ½Ð°ÑÐ°Ð¹Ð¼,×× ××××,ã¢ããã¤ã ,å®é£ç½,å®é£ç¿°,Anaheim", :latitude => "33.83529", :longitude => "-117.9145").save
City.new(:country_id => "233", :name => "Antioch", :aliases => "Antioch,Antiok,ÐÐ½ÑÐ¸Ð¾Ðº,ÐÐ½ÑÐ¸Ð¾Ñ,Antioch", :latitude => "38.00492", :longitude => "-121.80579").save
City.new(:country_id => "233", :name => "Apple Valley", :aliases => "Apple Valley,Apple Valley", :latitude => "34.50083", :longitude => "-117.18588").save
City.new(:country_id => "233", :name => "Arcadia", :aliases => "Arkadija,ÐÑÐºÐ°Ð´Ð¸Ñ,Arcadia", :latitude => "34.13973", :longitude => "-118.03534").save
City.new(:country_id => "233", :name => "Arroyo Grande", :aliases => ",Arroyo Grande", :latitude => "35.11859", :longitude => "-120.59073").save
City.new(:country_id => "233", :name => "Artesia", :aliases => ",Artesia", :latitude => "33.86585", :longitude => "-118.08312").save
City.new(:country_id => "233", :name => "Ashland", :aliases => ",Ashland", :latitude => "37.69465", :longitude => "-122.11385").save
City.new(:country_id => "233", :name => "Atascadero", :aliases => ",Atascadero", :latitude => "35.48942", :longitude => "-120.67073").save
City.new(:country_id => "233", :name => "Atwater", :aliases => ",Atwater", :latitude => "37.34772", :longitude => "-120.60908").save
City.new(:country_id => "233", :name => "Avenal", :aliases => ",Avenal", :latitude => "36.00412", :longitude => "-120.12903").save
City.new(:country_id => "233", :name => "Avocado Heights", :aliases => ",Avocado Heights", :latitude => "34.03612", :longitude => "-117.99118").save
City.new(:country_id => "233", :name => "Azusa", :aliases => ",Azusa", :latitude => "34.13362", :longitude => "-117.90756").save
City.new(:country_id => "233", :name => "Bakersfield", :aliases => "Bakersfield,Bejkursfild,bekazufirudo,ÐÐµÐ¹ÐºÑÑÑÑÐ¸Ð»Ð´,ãã¼ã«ã¼ãºãã£ã¼ã«ã,Bakersfield", :latitude => "35.37329", :longitude => "-119.01871").save
City.new(:country_id => "233", :name => "Baldwin Park", :aliases => "Baldwin Park,Baldwin Park", :latitude => "34.08529", :longitude => "-117.9609").save
City.new(:country_id => "233", :name => "Banning", :aliases => ",Banning", :latitude => "33.92557", :longitude => "-116.87641").save
City.new(:country_id => "233", :name => "Barstow", :aliases => "Barstou,ÐÐ°ÑÑÑÐ¾Ñ,Barstow", :latitude => "34.89859", :longitude => "-117.02282").save
City.new(:country_id => "233", :name => "Barstow Heights", :aliases => ",Barstow Heights", :latitude => "34.86971", :longitude => "-117.05615").save
City.new(:country_id => "233", :name => "Bay Point", :aliases => ",Bay Point", :latitude => "38.02909", :longitude => "-121.96163").save
City.new(:country_id => "233", :name => "Beaumont", :aliases => ",Beaumont", :latitude => "33.92946", :longitude => "-116.97725").save
City.new(:country_id => "233", :name => "Bell", :aliases => "Bella,ÐÐµÐ»Ð»Ð°,Bell", :latitude => "33.97751", :longitude => "-118.18702").save
City.new(:country_id => "233", :name => "Bell Gardens", :aliases => ",Bell Gardens", :latitude => "33.96529", :longitude => "-118.15146").save
City.new(:country_id => "233", :name => "Bellflower", :aliases => "Bellflower,Bellflower", :latitude => "33.88168", :longitude => "-118.11701").save
City.new(:country_id => "233", :name => "Belmont", :aliases => "Belmont,ÐÐµÐ»Ð¼Ð¾Ð½Ñ,Belmont", :latitude => "37.52021", :longitude => "-122.2758").save
City.new(:country_id => "233", :name => "Benicia", :aliases => ",Benicia", :latitude => "38.04936", :longitude => "-122.15858").save
City.new(:country_id => "233", :name => "Berkeley", :aliases => "Berkeley,Berkli,Burkli,bakure,bakuri,beokeulli,bo ke li,ÐÐµÑÐºÐ»Ð¸,ÐÑÑÐºÐ»Ð¸,ãã¼ã¯ãªã¼,ãã¼ã¯ã¬ã¼,ä¼¯åå©,ë²í´ë¦¬,Berkeley", :latitude => "37.87159", :longitude => "-122.27275").save
City.new(:country_id => "233", :name => "Beverly Hills", :aliases => "Bev'rli Khils,Beverly Hills,beverli hilsi,bibarihiruzu,bwrly hylz,bwwrly hyls,ÐÐµÐ²ÑÑÐ»Ð¸ Ð¥Ð¸Ð»Ñ,××××¨×× ××××¡,Ø¨ÙØ±ÙÛ ÙÛÙØ²,ááááá áá á°ááá¡á,ãããªã¼ãã«ãº,Beverly Hills", :latitude => "34.07362", :longitude => "-118.40036").save
City.new(:country_id => "233", :name => "Bloomington", :aliases => "Blumington,ÐÐ»ÑÐ¼Ð¸Ð½Ð³ÑÐ¾Ð½,Bloomington", :latitude => "34.07029", :longitude => "-117.39588").save
City.new(:country_id => "233", :name => "Blythe", :aliases => "Blajt,ÐÐ»Ð°Ð¹Ñ,Blythe", :latitude => "33.6103", :longitude => "-114.59635").save
City.new(:country_id => "233", :name => "Bostonia", :aliases => ",Bostonia", :latitude => "32.80755", :longitude => "-116.93642").save
City.new(:country_id => "233", :name => "Brawley", :aliases => ",Brawley", :latitude => "32.97866", :longitude => "-115.53027").save
City.new(:country_id => "233", :name => "Brea", :aliases => ",Brea", :latitude => "33.91668", :longitude => "-117.90006").save
City.new(:country_id => "233", :name => "Brentwood", :aliases => ",Brentwood", :latitude => "37.92687", :longitude => "-121.72577").save
City.new(:country_id => "233", :name => "Buena Park", :aliases => "Buena Park,Buena Park", :latitude => "33.86751", :longitude => "-117.99812").save
City.new(:country_id => "233", :name => "Burbank", :aliases => "B'rbank,Berbank,Burbank,Burbank, Los Angeles County,bo ban ke,ÐÐµÑÐ±Ð°Ð½Ðº,ÐÑÑÐ±Ð°Ð½Ðº,ä¼¯ç­å,Burbank", :latitude => "34.18084", :longitude => "-118.30897").save
City.new(:country_id => "233", :name => "Burlingame", :aliases => "Berlingem,ÐÐµÑÐ»Ð¸Ð½Ð³ÐµÐ¼,Burlingame", :latitude => "37.5841", :longitude => "-122.36608").save
City.new(:country_id => "233", :name => "Calabasas", :aliases => ",Calabasas", :latitude => "34.15778", :longitude => "-118.63842").save
City.new(:country_id => "233", :name => "Calexico", :aliases => ",Calexico", :latitude => "32.67895", :longitude => "-115.49888").save
City.new(:country_id => "233", :name => "Camarillo", :aliases => "Camarillo,Camarillo", :latitude => "34.21639", :longitude => "-119.0376").save
City.new(:country_id => "233", :name => "Cameron Park", :aliases => ",Cameron Park", :latitude => "38.66879", :longitude => "-120.98716").save
City.new(:country_id => "233", :name => "Campbell", :aliases => "Kehmpbell,ÐÑÐ¼Ð¿Ð±ÐµÐ»Ð»,Campbell", :latitude => "37.28717", :longitude => "-121.94996").save
City.new(:country_id => "233", :name => "Carlsbad", :aliases => "Carlsbad,Carlsbad", :latitude => "33.15809", :longitude => "-117.35059").save
City.new(:country_id => "233", :name => "Carmichael", :aliases => "Karmajkl,ÐÐ°ÑÐ¼Ð°Ð¹ÐºÐ»,Carmichael", :latitude => "38.61713", :longitude => "-121.32828").save
City.new(:country_id => "233", :name => "Carson", :aliases => "Carson,Karson,ÐÐ°ÑÑÐ¾Ð½,Carson", :latitude => "33.83141", :longitude => "-118.28202").save
City.new(:country_id => "233", :name => "Castro Valley", :aliases => "Castro Valley,Kastro Vali,ÐÐ°ÑÑÑÐ¾ ÐÐ°Ð»Ð¸,Castro Valley", :latitude => "37.6941", :longitude => "-122.08635").save
City.new(:country_id => "233", :name => "Cathedral City", :aliases => ",Cathedral City", :latitude => "33.77974", :longitude => "-116.46529").save
City.new(:country_id => "233", :name => "Ceres", :aliases => "Cerera,Ð¦ÐµÑÐµÑÐ°,Ceres", :latitude => "37.59493", :longitude => "-120.95771").save
City.new(:country_id => "233", :name => "Cerritos", :aliases => "Serritos,Ð¡ÐµÑÑÐ¸ÑÐ¾Ñ,Cerritos", :latitude => "33.85835", :longitude => "-118.06479").save
City.new(:country_id => "233", :name => "Cherryland", :aliases => ",Cherryland", :latitude => "37.67938", :longitude => "-122.1033").save
City.new(:country_id => "233", :name => "Chico", :aliases => "Chico,Chiko,Ð§Ð¸ÐºÐ¾,Chico", :latitude => "39.72849", :longitude => "-121.83748").save
City.new(:country_id => "233", :name => "Chino", :aliases => "Chino,Chino", :latitude => "34.01223", :longitude => "-117.68894").save
City.new(:country_id => "233", :name => "Chino Hills", :aliases => ",Chino Hills", :latitude => "33.9938", :longitude => "-117.75888").save
City.new(:country_id => "233", :name => "Chula Vista", :aliases => "Chula Vista,Chula Vista", :latitude => "32.64005", :longitude => "-117.0842").save
City.new(:country_id => "233", :name => "Citrus Heights", :aliases => "Citrus Heights,Citrus Heights", :latitude => "38.70712", :longitude => "-121.28106").save
City.new(:country_id => "233", :name => "Claremont", :aliases => "Klermont,ÐÐ»ÐµÑÐ¼Ð¾Ð½Ñ,Claremont", :latitude => "34.09668", :longitude => "-117.71978").save
City.new(:country_id => "233", :name => "Clovis", :aliases => "Clovis,Klovis,ÐÐ»Ð¾Ð²Ð¸Ñ,Clovis", :latitude => "36.82523", :longitude => "-119.70292").save
City.new(:country_id => "233", :name => "Coachella", :aliases => ",Coachella", :latitude => "33.6803", :longitude => "-116.17389").save
City.new(:country_id => "233", :name => "Coalinga", :aliases => ",Coalinga", :latitude => "36.13968", :longitude => "-120.36015").save
City.new(:country_id => "233", :name => "Colton", :aliases => "Kolton,ÐÐ¾Ð»ÑÐ¾Ð½,Colton", :latitude => "34.0739", :longitude => "-117.31365").save
City.new(:country_id => "233", :name => "Compton", :aliases => "Compton,Kompton,ÐÐ¾Ð¼Ð¿ÑÐ¾Ð½,Compton", :latitude => "33.89585", :longitude => "-118.22007").save
City.new(:country_id => "233", :name => "Concord", :aliases => "Concord,Konkord,ÐÐ¾Ð½ÐºÐ¾ÑÐ´,Concord", :latitude => "37.97798", :longitude => "-122.03107").save
City.new(:country_id => "233", :name => "Corcoran", :aliases => "Korkoran,ÐÐ¾ÑÐºÐ¾ÑÐ°Ð½,Corcoran", :latitude => "36.09801", :longitude => "-119.5604").save
City.new(:country_id => "233", :name => "Corona", :aliases => ",Corona", :latitude => "33.87529", :longitude => "-117.56644").save
City.new(:country_id => "233", :name => "Coronado", :aliases => "Koronado,ÐÐ¾ÑÐ¾Ð½Ð°Ð´Ð¾,Coronado", :latitude => "32.68589", :longitude => "-117.18309").save
City.new(:country_id => "233", :name => "Costa Mesa", :aliases => "Costa Mesa,Kosta-Mesa,ÐÐ¾ÑÑÐ°-ÐÐµÑÐ°,Costa Mesa", :latitude => "33.64113", :longitude => "-117.91867").save
City.new(:country_id => "233", :name => "Coto De Caza", :aliases => ",Coto De Caza", :latitude => "33.60419", :longitude => "-117.58699").save
City.new(:country_id => "233", :name => "Covina", :aliases => ",Covina", :latitude => "34.09001", :longitude => "-117.89034").save
City.new(:country_id => "233", :name => "Cudahy", :aliases => ",Cudahy", :latitude => "33.96057", :longitude => "-118.18535").save
City.new(:country_id => "233", :name => "Culver City", :aliases => "Kalver-Siti,ÐÐ°Ð»Ð²ÐµÑ-Ð¡Ð¸ÑÐ¸,Culver City", :latitude => "34.02112", :longitude => "-118.39647").save
City.new(:country_id => "233", :name => "Cupertino", :aliases => "Cupertino,Kupertino,kupachino,kupeotino,qwprtynw,ÐÑÐ¿ÐµÑÑÐ¸Ð½Ð¾,×§××¤×¨××× ×,ã¯ããã¼ã,ì¿ í¼í°ë¸,Cupertino", :latitude => "37.323", :longitude => "-122.03218").save
City.new(:country_id => "233", :name => "Cypress", :aliases => ",Cypress", :latitude => "33.81696", :longitude => "-118.03729").save
City.new(:country_id => "233", :name => "Daly City", :aliases => "Daly City,Dejli Siti,ÐÐµÐ¹Ð»Ð¸ Ð¡Ð¸ÑÐ¸,Daly City", :latitude => "37.70577", :longitude => "-122.46192").save
City.new(:country_id => "233", :name => "Dana Point", :aliases => ",Dana Point", :latitude => "33.46697", :longitude => "-117.69811").save
City.new(:country_id => "233", :name => "Danville", :aliases => ",Danville", :latitude => "37.82159", :longitude => "-121.99996").save
City.new(:country_id => "233", :name => "Davis", :aliases => "Davis,Dejvis,ÐÐµÐ¹Ð²Ð¸Ñ,Davis", :latitude => "38.54491", :longitude => "-121.74052").save
City.new(:country_id => "233", :name => "Delano", :aliases => "Delano,ÐÐµÐ»Ð°Ð½Ð¾,Delano", :latitude => "35.76884", :longitude => "-119.24705").save
City.new(:country_id => "233", :name => "Desert Hot Springs", :aliases => ",Desert Hot Springs", :latitude => "33.96112", :longitude => "-116.50168").save
City.new(:country_id => "233", :name => "Diamond Bar", :aliases => ",Diamond Bar", :latitude => "34.02862", :longitude => "-117.81034").save
City.new(:country_id => "233", :name => "Dinuba", :aliases => ",Dinuba", :latitude => "36.54328", :longitude => "-119.38707").save
City.new(:country_id => "233", :name => "Dixon", :aliases => ",Dixon", :latitude => "38.44546", :longitude => "-121.8233").save
City.new(:country_id => "233", :name => "Downey", :aliases => "Dauni,Downey,ÐÐ°ÑÐ½Ð¸,Downey", :latitude => "33.94001", :longitude => "-118.13257").save
City.new(:country_id => "233", :name => "Duarte", :aliases => "Duarte,ÐÑÐ°ÑÑÐµ,Duarte", :latitude => "34.13945", :longitude => "-117.97729").save
City.new(:country_id => "233", :name => "Dublin", :aliases => "Dublin,ÐÑÐ±Ð»Ð¸Ð½,Dublin", :latitude => "37.70215", :longitude => "-121.93579").save
City.new(:country_id => "233", :name => "East Los Angeles", :aliases => "East Los Angeles,East Los Angeles", :latitude => "34.0239", :longitude => "-118.17202").save
City.new(:country_id => "233", :name => "East Palo Alto", :aliases => ",East Palo Alto", :latitude => "37.46883", :longitude => "-122.14108").save
City.new(:country_id => "233", :name => "East San Gabriel", :aliases => ",East San Gabriel", :latitude => "34.09168", :longitude => "-118.09118").save
City.new(:country_id => "233", :name => "El Cajon", :aliases => "El Cajon,El Cajon", :latitude => "32.79477", :longitude => "-116.96253").save
City.new(:country_id => "233", :name => "El Centro", :aliases => ",El Centro", :latitude => "32.792", :longitude => "-115.56305").save
City.new(:country_id => "233", :name => "El Cerrito", :aliases => ",El Cerrito", :latitude => "37.91576", :longitude => "-122.31164").save
City.new(:country_id => "233", :name => "El Dorado Hills", :aliases => ",El Dorado Hills", :latitude => "38.68574", :longitude => "-121.08217").save
City.new(:country_id => "233", :name => "El Monte", :aliases => "Ehl'-Monte,El Monte,Ð­Ð»Ñ-ÐÐ¾Ð½ÑÐµ,El Monte", :latitude => "34.06862", :longitude => "-118.02757").save
City.new(:country_id => "233", :name => "El Segundo", :aliases => ",El Segundo", :latitude => "33.91918", :longitude => "-118.41647").save
City.new(:country_id => "233", :name => "Elk Grove", :aliases => "Elk Grove,Elk Grove", :latitude => "38.4088", :longitude => "-121.37162").save
City.new(:country_id => "233", :name => "Encinitas", :aliases => ",Encinitas", :latitude => "33.03699", :longitude => "-117.29198").save
City.new(:country_id => "233", :name => "Escondido", :aliases => "Escondido,Escondido", :latitude => "33.11921", :longitude => "-117.08642").save
City.new(:country_id => "233", :name => "Fair Oaks", :aliases => ",Fair Oaks", :latitude => "38.64463", :longitude => "-121.27217").save
City.new(:country_id => "233", :name => "Fairfield", :aliases => "Fairfield,Feurfild,Ð¤ÐµÑÑÑÐ¸Ð»Ð´,Fairfield", :latitude => "38.24936", :longitude => "-122.03997").save
City.new(:country_id => "233", :name => "Fallbrook", :aliases => ",Fallbrook", :latitude => "33.37642", :longitude => "-117.25115").save
City.new(:country_id => "233", :name => "Florin", :aliases => "Florin,Ð¤Ð»Ð¾ÑÐ¸Ð½,Florin", :latitude => "38.49602", :longitude => "-121.40884").save
City.new(:country_id => "233", :name => "Folsom", :aliases => "Folsom,Folsom", :latitude => "38.67796", :longitude => "-121.17606").save
City.new(:country_id => "233", :name => "Fontana", :aliases => "Fontana,Ð¤Ð¾Ð½ÑÐ°Ð½Ð°,Fontana", :latitude => "34.09223", :longitude => "-117.43505").save
City.new(:country_id => "233", :name => "Foothill Farms", :aliases => ",Foothill Farms", :latitude => "38.67877", :longitude => "-121.35114").save
City.new(:country_id => "233", :name => "Foster City", :aliases => ",Foster City", :latitude => "37.55855", :longitude => "-122.27108").save
City.new(:country_id => "233", :name => "Fountain Valley", :aliases => ",Fountain Valley", :latitude => "33.70918", :longitude => "-117.95367").save
City.new(:country_id => "233", :name => "Fremont", :aliases => "Fremont,Frimont,fei li meng,Ð¤ÑÐ¸Ð¼Ð¾Ð½Ñ,è²»å©è,Fremont", :latitude => "37.54827", :longitude => "-121.98857").save
City.new(:country_id => "233", :name => "Fresno", :aliases => "Fraxinus,Fresno,furezuno,Ð¤ÑÐµÑÐ½Ð¾,ãã¬ãºã,Fresno", :latitude => "36.74773", :longitude => "-119.77237").save
City.new(:country_id => "233", :name => "Fullerton", :aliases => "Fullerton,Ð¤ÑÐ»Ð»ÐµÑÑÐ¾Ð½,Fullerton", :latitude => "33.87029", :longitude => "-117.92534").save
City.new(:country_id => "233", :name => "Galt", :aliases => "Galt,ÐÐ°Ð»Ñ,Galt", :latitude => "38.25464", :longitude => "-121.29995").save
City.new(:country_id => "233", :name => "Garden Grove", :aliases => "Garden Grove,Garden Grove", :latitude => "33.77391", :longitude => "-117.94145").save
City.new(:country_id => "233", :name => "Gardena", :aliases => ",Gardena", :latitude => "33.88835", :longitude => "-118.30896").save
City.new(:country_id => "233", :name => "Gilroy", :aliases => ",Gilroy", :latitude => "37.00578", :longitude => "-121.56828").save
City.new(:country_id => "233", :name => "Glen Avon", :aliases => ",Glen Avon", :latitude => "34.01168", :longitude => "-117.48477").save
City.new(:country_id => "233", :name => "Glendale", :aliases => "Glendale,Glendejl,geullendeil,ÐÐ»ÐµÐ½Ð´ÐµÐ¹Ð»,ê¸ë ë°ì¼,Glendale", :latitude => "34.14251", :longitude => "-118.25508").save
City.new(:country_id => "233", :name => "Glendora", :aliases => ",Glendora", :latitude => "34.13612", :longitude => "-117.86534").save
City.new(:country_id => "233", :name => "Goleta", :aliases => "Goelette,Goleta,Golita,GoÃ©lette,Kuunari,Schoener,Schoner,Schooner,Shkhuna,Skonert,Skonnert,Skonnorta,Skuna,Skuner,Szkuner,sukuna,Å kuna,Å kuner,ÐÐ¾Ð»Ð¸ÑÐ°,Ð¨ÑÑÐ½Ð°,ã¹ã¯ã¼ã,Goleta", :latitude => "34.43583", :longitude => "-119.82764").save
City.new(:country_id => "233", :name => "Granite Bay", :aliases => ",Granite Bay", :latitude => "38.76323", :longitude => "-121.16384").save
City.new(:country_id => "233", :name => "Hacienda Heights", :aliases => ",Hacienda Heights", :latitude => "33.99307", :longitude => "-117.96868").save
City.new(:country_id => "233", :name => "Hanford", :aliases => "Khehnford,Ð¥ÑÐ½ÑÐ¾ÑÐ´,Hanford", :latitude => "36.32745", :longitude => "-119.64568").save
City.new(:country_id => "233", :name => "Hawaiian Gardens", :aliases => ",Hawaiian Gardens", :latitude => "33.8314", :longitude => "-118.07284").save
City.new(:country_id => "233", :name => "Hawthorne", :aliases => "Hawthorne,Hawthorne", :latitude => "33.9164", :longitude => "-118.35257").save
City.new(:country_id => "233", :name => "Hayward", :aliases => "Hayward,Kheju'rd,hai wo de,heiwado,Ð¥ÐµÐ¹ÑÑÑÐ´,ãã¤ã¯ã¼ã,æµ·æ²å¾·,Hayward", :latitude => "37.66882", :longitude => "-122.0808").save
City.new(:country_id => "233", :name => "Hemet", :aliases => "Hemet,Hemet", :latitude => "33.74752", :longitude => "-116.97197").save
City.new(:country_id => "233", :name => "Hercules", :aliases => "Gerkules,ÐÐµÑÐºÑÐ»ÐµÑ,Hercules", :latitude => "38.01714", :longitude => "-122.28858").save
City.new(:country_id => "233", :name => "Hermosa Beach", :aliases => ",Hermosa Beach", :latitude => "33.86224", :longitude => "-118.39952").save
City.new(:country_id => "233", :name => "Hesperia", :aliases => "Hesperia,Hesperia", :latitude => "34.42639", :longitude => "-117.30088").save
City.new(:country_id => "233", :name => "Highland", :aliases => ",Highland", :latitude => "34.12834", :longitude => "-117.20865").save
City.new(:country_id => "233", :name => "Hollister", :aliases => ",Hollister", :latitude => "36.85245", :longitude => "-121.4016").save
City.new(:country_id => "233", :name => "Hollywood", :aliases => "Gollivud,Holivudas,Holivudo,Hollywood,Kholivud,hali'uda,hao lai wu,hariuddo,holivuda,hwlywwd,ÐÐ¾Ð»Ð»Ð¸Ð²ÑÐ´,Ð¥Ð¾Ð»Ð¸Ð²ÑÐ´,×××××××,à¤¹à¥à¤²à¤¿à¤µà¥à¤¡,à¦¹à¦²à¦¿à¦à¦¡,ããªã¦ãã,å¥½è±å,Hollywood", :latitude => "34.09834", :longitude => "-118.32674").save
City.new(:country_id => "233", :name => "Huntington Beach", :aliases => "Huntington Beach,Kh'ntingt'n Bijch,Ð¥ÑÐ½ÑÐ¸Ð½Ð³ÑÑÐ½ ÐÐ¸Ð¹Ñ,Huntington Beach", :latitude => "33.6603", :longitude => "-117.99923").save
City.new(:country_id => "233", :name => "Huntington Park", :aliases => "Huntington Park,Huntington Park", :latitude => "33.98168", :longitude => "-118.22507").save
City.new(:country_id => "233", :name => "Imperial Beach", :aliases => ",Imperial Beach", :latitude => "32.58394", :longitude => "-117.11308").save
City.new(:country_id => "233", :name => "Indio", :aliases => "Indio,indio,ã¤ã³ãã£ãª,Indio", :latitude => "33.72058", :longitude => "-116.21556").save
City.new(:country_id => "233", :name => "Inglewood", :aliases => "Inglewood,Inglewood", :latitude => "33.96168", :longitude => "-118.35313").save
City.new(:country_id => "233", :name => "Irvine", :aliases => "'rvajn,Irvajn,Irvin,Irvine,abain,ÐÑÐ²Ð°Ð¹Ð½,ÐÑÐ²Ð¸Ð½,ÐªÑÐ²Ð°Ð¹Ð½,ã¢ã¼ãã¤ã³,Irvine", :latitude => "33.66946", :longitude => "-117.82311").save
City.new(:country_id => "233", :name => "Isla Vista", :aliases => ",Isla Vista", :latitude => "34.41333", :longitude => "-119.86097").save
City.new(:country_id => "233", :name => "La Canada Flintridge", :aliases => ",La CaÃ±ada Flintridge", :latitude => "34.19917", :longitude => "-118.18785").save
City.new(:country_id => "233", :name => "La Habra", :aliases => ",La Habra", :latitude => "33.93196", :longitude => "-117.94617").save
City.new(:country_id => "233", :name => "La Mesa", :aliases => ",La Mesa", :latitude => "32.76783", :longitude => "-117.02308").save
City.new(:country_id => "233", :name => "La Mirada", :aliases => ",La Mirada", :latitude => "33.91724", :longitude => "-118.01201").save
City.new(:country_id => "233", :name => "La Palma", :aliases => ",La Palma", :latitude => "33.8464", :longitude => "-118.04673").save
City.new(:country_id => "233", :name => "La Presa", :aliases => ",La Presa", :latitude => "32.70811", :longitude => "-116.99725").save
City.new(:country_id => "233", :name => "La Puente", :aliases => ",La Puente", :latitude => "34.02001", :longitude => "-117.94951").save
City.new(:country_id => "233", :name => "La Quinta", :aliases => ",La Quinta", :latitude => "33.66336", :longitude => "-116.31001").save
City.new(:country_id => "233", :name => "La Verne", :aliases => ",La Verne", :latitude => "34.10084", :longitude => "-117.76784").save
City.new(:country_id => "233", :name => "Lafayette", :aliases => "Lafajet,ÐÐ°ÑÐ°Ð¹ÐµÑ,Lafayette", :latitude => "37.88576", :longitude => "-122.11802").save
City.new(:country_id => "233", :name => "Laguna", :aliases => ",Laguna", :latitude => "38.42102", :longitude => "-121.42384").save
City.new(:country_id => "233", :name => "Laguna Beach", :aliases => ",Laguna Beach", :latitude => "33.54225", :longitude => "-117.78311").save
City.new(:country_id => "233", :name => "Laguna Hills", :aliases => ",Laguna Hills", :latitude => "33.5956", :longitude => "-117.70031").save
City.new(:country_id => "233", :name => "Laguna Niguel", :aliases => "Laguna Niguel,Laguna Niguel", :latitude => "33.52253", :longitude => "-117.70755").save
City.new(:country_id => "233", :name => "Laguna Woods", :aliases => ",Laguna Woods", :latitude => "33.6103", :longitude => "-117.72533").save
City.new(:country_id => "233", :name => "Lake Elsinore", :aliases => ",Lake Elsinore", :latitude => "33.66808", :longitude => "-117.32726").save
City.new(:country_id => "233", :name => "Lake Forest", :aliases => "Lake Forest,Lake Forest", :latitude => "33.64697", :longitude => "-117.68922").save
City.new(:country_id => "233", :name => "Lakeside", :aliases => ",Lakeside", :latitude => "32.85727", :longitude => "-116.92225").save
City.new(:country_id => "233", :name => "Lakewood", :aliases => "Lakewood,Lejkvud,ÐÐµÐ¹ÐºÐ²ÑÐ´,Lakewood", :latitude => "33.85363", :longitude => "-118.13396").save
City.new(:country_id => "233", :name => "Lancaster", :aliases => "Lancaster,Lankaster,ÐÐ°Ð½ÐºÐ°ÑÑÐµÑ,Lancaster", :latitude => "34.69804", :longitude => "-118.13674").save
City.new(:country_id => "233", :name => "Lawndale", :aliases => ",Lawndale", :latitude => "33.88724", :longitude => "-118.35257").save
City.new(:country_id => "233", :name => "Lemon Grove", :aliases => ",Lemon Grove", :latitude => "32.74255", :longitude => "-117.03142").save
City.new(:country_id => "233", :name => "Lemoore", :aliases => ",Lemoore", :latitude => "36.30078", :longitude => "-119.78291").save
City.new(:country_id => "233", :name => "Lennox", :aliases => "Lennoks,ÐÐµÐ½Ð½Ð¾ÐºÑ,Lennox", :latitude => "33.93807", :longitude => "-118.35258").save
City.new(:country_id => "233", :name => "Lincoln", :aliases => "Linkoln,ÐÐ¸Ð½ÐºÐ¾Ð»Ð½,Lincoln", :latitude => "38.89156", :longitude => "-121.29301").save
City.new(:country_id => "233", :name => "Live Oak", :aliases => ",Live Oak", :latitude => "36.98356", :longitude => "-121.98052").save
City.new(:country_id => "233", :name => "Livermore", :aliases => "Liv'rmor,Livermore,ribamoa,ÐÐ¸Ð²ÑÑÐ¼Ð¾Ñ,ãªãã¢ã¢,Livermore", :latitude => "37.68187", :longitude => "-121.76801").save
City.new(:country_id => "233", :name => "Lodi", :aliases => "Lodi,ÐÐ¾Ð´Ð¸,Lodi", :latitude => "38.1302", :longitude => "-121.27245").save
City.new(:country_id => "233", :name => "Loma Linda", :aliases => ",Loma Linda", :latitude => "34.04835", :longitude => "-117.26115").save
City.new(:country_id => "233", :name => "Lomita", :aliases => ",Lomita", :latitude => "33.79224", :longitude => "-118.31507").save
City.new(:country_id => "233", :name => "Lompoc", :aliases => ",Lompoc", :latitude => "34.63915", :longitude => "-120.45794").save
City.new(:country_id => "233", :name => "Long Beach", :aliases => "Litus Longum,Long Beach,Long Bich,Long Bijch,Long Bycas,Long ByÄas,Long-Bich,lwng byz',rongubichi,ÐÐ¾Ð½Ð³ ÐÐ¸Ð¹Ñ,ÐÐ¾Ð½Ð³ ÐÐ¸Ñ,ÐÐ¾Ð½Ð³-ÐÐ¸Ñ,××× × ×××¥',ã­ã³ã°ãã¼ã,Long Beach", :latitude => "33.76696", :longitude => "-118.18923").save
City.new(:country_id => "233", :name => "Los Altos", :aliases => "Los Altos,luo si la tu si,lws altws,rosuarutosu,ÐÐ¾Ñ ÐÐ»ÑÐ¾Ñ,×××¡ ×××××¡,ÙÙØ³ Ø£ÙØªÙØ³,ã­ã¹ã¢ã«ãã¹,æ´æ¯æå¾æ¯,æ´æ¯æåæ¯,Los Altos", :latitude => "37.38522", :longitude => "-122.11413").save
City.new(:country_id => "233", :name => "Los Angeles", :aliases => "Angelopolis,El Pueblo de Nuestra Senora de los Angeles de Porciuncula,El Pueblo de Nuestra SeÃ±ora de los Ãngeles de PorciÃºncula,L.A.,LA,Los Andzelas,Los Andzeles,Los Andzhelis,Los AndÅ¾elas,Los Angeles,Los Antzeles,Los Anxhelos,Los Anxhelosi,Los Anzeles,Los Ãngeles,Los-Andzhehles,Los-Andzheles,Los-Angeleso,Los-AnÄeleso,Losandzelosa,LosandÅ¾elosa,Lungsod ng Los Angeles,Os Anxeles - Los Angeles,Os Ãnxeles - Los Angeles,las encalas,los-anjelesi,loseuaenjelleseu,ls anjls,luo shan ji,lws anjls,rosanzerusu,ÎÎ¿Ï ÎÎ½ÏÎ¶ÎµÎ»ÎµÏ,ÐÐ¾Ñ ÐÐ½Ð´Ð¶ÐµÐ»Ð¸Ñ,ÐÐ¾Ñ ÐÐ½ÑÐµÐ»ÐµÑ,ÐÐ¾Ñ ÐÐ½ÑÐµÐ»ÐµÑ,ÐÐ¾Ñ ÐÐ½Ò·ÐµÐ»ÐµÑ,ÐÐ¾Ñ ÐÐ½ÓÐµÐ»ÐµÑ,ÐÐ¾Ñ-ÐÐ½Ð´Ð¶ÐµÐ»ÐµÑ,ÐÐ¾Ñ-ÐÐ½Ð´Ð¶ÑÐ»ÐµÑ,×××¡ ×× ×'××¡,ÙØ³ Ø¢ÙØ¬ÙØ³,ÙØ³âØ¢ÙØ¬ÙØ³,ÙÙØ³ Ø¢ÙØ¬ÙØ³,ÙÙØ³ Ø£ÙØ¬ÙØ³,ÙÙØ³ Ø¦Ø§ÙØ¬ÛÙÛØ³,ÙÙØ³ Ø¦Ø§ÙØ¬ÛÙÛØ³,à®²à®¾à®¸à¯ à®à®à¯à®à®²à®¸à¯,à¸¥à¸­à¸ªà¹à¸­à¸à¹à¸à¸¥à¸µà¸ª,ááá¡-ááá¯áááá¡á,ã­ãµã³ã¼ã«ã¹,æ´æç¶,ë¡ì¤ì¤ì ¤ë ì¤,Los Angeles", :latitude => "34.05223", :longitude => "-118.24368").save
City.new(:country_id => "233", :name => "Los Banos", :aliases => "Los-Ban'os,ÐÐ¾Ñ-ÐÐ°Ð½ÑÐ¾Ñ,Los Banos", :latitude => "37.05828", :longitude => "-120.84992").save
City.new(:country_id => "233", :name => "Los Gatos", :aliases => ",Los Gatos", :latitude => "37.22661", :longitude => "-121.97468").save
City.new(:country_id => "233", :name => "Lynwood", :aliases => "Linvud,Lynwood,ÐÐ¸Ð½Ð²ÑÐ´,Lynwood", :latitude => "33.93029", :longitude => "-118.21146").save
City.new(:country_id => "233", :name => "Madera", :aliases => "Madera,ÐÐ°Ð´ÐµÑÐ°,Madera", :latitude => "36.96134", :longitude => "-120.06072").save
City.new(:country_id => "233", :name => "Manhattan Beach", :aliases => ",Manhattan Beach", :latitude => "33.88474", :longitude => "-118.41091").save
City.new(:country_id => "233", :name => "Manteca", :aliases => "Manteca,Manteca", :latitude => "37.79743", :longitude => "-121.21605").save
City.new(:country_id => "233", :name => "Marina", :aliases => ",Marina", :latitude => "36.6844", :longitude => "-121.80217").save
City.new(:country_id => "233", :name => "Martinez", :aliases => "Martines,ÐÐ°ÑÑÐ¸Ð½ÐµÑ,Martinez", :latitude => "38.01937", :longitude => "-122.13413").save
City.new(:country_id => "233", :name => "Maywood", :aliases => ",Maywood", :latitude => "33.98668", :longitude => "-118.18535").save
City.new(:country_id => "233", :name => "Menlo Park", :aliases => "Menlo Park,men luo pa ke,ÐÐµÐ½Ð»Ð¾ ÐÐ°ÑÐº,é¨æ´å¸å,Menlo Park", :latitude => "37.45383", :longitude => "-122.18219").save
City.new(:country_id => "233", :name => "Merced", :aliases => "Merced,Mersed,ÐÐµÑÑÐµÐ´,Merced", :latitude => "37.30216", :longitude => "-120.48297").save
City.new(:country_id => "233", :name => "Millbrae", :aliases => ",Millbrae", :latitude => "37.59855", :longitude => "-122.38719").save
City.new(:country_id => "233", :name => "Milpitas", :aliases => "Milpitas,ÐÐ¸Ð»Ð¿Ð¸ÑÐ°Ñ,Milpitas", :latitude => "37.42827", :longitude => "-121.90662").save
City.new(:country_id => "233", :name => "Mira Loma", :aliases => ",Mira Loma", :latitude => "33.99251", :longitude => "-117.51644").save
City.new(:country_id => "233", :name => "Mission Viejo", :aliases => "Mission Viejo,Mission Viejo", :latitude => "33.60002", :longitude => "-117.672").save
City.new(:country_id => "233", :name => "Modesto", :aliases => "Modesto,mwdstw,ÐÐ¾Ð´ÐµÑÑÐ¾,××××¡××,Modesto", :latitude => "37.6391", :longitude => "-120.99688").save
City.new(:country_id => "233", :name => "Monrovia", :aliases => "Monrovija,ÐÐ¾Ð½ÑÐ¾Ð²Ð¸Ñ,Monrovia", :latitude => "34.14806", :longitude => "-117.99895").save
City.new(:country_id => "233", :name => "Montclair", :aliases => ",Montclair", :latitude => "34.07751", :longitude => "-117.68978").save
City.new(:country_id => "233", :name => "Montebello", :aliases => "Montebello,ÐÐ¾Ð½ÑÐµÐ±ÐµÐ»Ð»Ð¾,Montebello", :latitude => "34.00946", :longitude => "-118.10535").save
City.new(:country_id => "233", :name => "Monterey", :aliases => "Monterej,Monterey,montore,ÐÐ¾Ð½ÑÐµÑÐµÐ¹,ã¢ã³ãã¬ã¼,Monterey", :latitude => "36.60024", :longitude => "-121.89468").save
City.new(:country_id => "233", :name => "Monterey Park", :aliases => "Monterey Park,Monterey Park", :latitude => "34.06251", :longitude => "-118.12285").save
City.new(:country_id => "233", :name => "Moorpark", :aliases => ",Moorpark", :latitude => "34.28556", :longitude => "-118.88204").save
City.new(:country_id => "233", :name => "Moraga", :aliases => ",Moraga", :latitude => "37.83493", :longitude => "-122.12969").save
City.new(:country_id => "233", :name => "Moreno Valley", :aliases => "Moreno Valley,Moreno Valley", :latitude => "33.93752", :longitude => "-117.23059").save
City.new(:country_id => "233", :name => "Morgan Hill", :aliases => ",Morgan Hill", :latitude => "37.1305", :longitude => "-121.65439").save
City.new(:country_id => "233", :name => "Mountain View", :aliases => "Mauntin Vju,Mauntin-V'ju,Mountain View,mang ting wei you,ÐÐ°ÑÐ½ÑÐ¸Ð½ ÐÑ,ÐÐ°ÑÐ½ÑÐ¸Ð½-ÐÑÑ,èå»·ç»´å°¤,Mountain View", :latitude => "37.38605", :longitude => "-122.08385").save
City.new(:country_id => "233", :name => "Murrieta", :aliases => "Murrieta,Murrieta", :latitude => "33.55391", :longitude => "-117.21392").save
City.new(:country_id => "233", :name => "Napa", :aliases => "Napa,napa,ÐÐ°Ð¿Ð°,ãã,Napa", :latitude => "38.29714", :longitude => "-122.28553").save
City.new(:country_id => "233", :name => "National City", :aliases => "National City,National City", :latitude => "32.67811", :longitude => "-117.0992").save
City.new(:country_id => "233", :name => "Newark", :aliases => "N'juark,ÐÑÑÐ°ÑÐº,Newark", :latitude => "37.52966", :longitude => "-122.04024").save
City.new(:country_id => "233", :name => "Newport Beach", :aliases => ",Newport Beach", :latitude => "33.61891", :longitude => "-117.92895").save
City.new(:country_id => "233", :name => "Nipomo", :aliases => ",Nipomo", :latitude => "35.04275", :longitude => "-120.476").save
City.new(:country_id => "233", :name => "Norco", :aliases => ",Norco", :latitude => "33.93113", :longitude => "-117.54866").save
City.new(:country_id => "233", :name => "North Fair Oaks", :aliases => ",North Fair Oaks", :latitude => "37.47438", :longitude => "-122.19663").save
City.new(:country_id => "233", :name => "North Glendale", :aliases => ",North Glendale", :latitude => "34.16056", :longitude => "-118.26452").save
City.new(:country_id => "233", :name => "North Highlands", :aliases => ",North Highlands", :latitude => "38.68574", :longitude => "-121.37217").save
City.new(:country_id => "233", :name => "Norwalk", :aliases => ",Norwalk", :latitude => "33.90224", :longitude => "-118.08173").save
City.new(:country_id => "233", :name => "Novato", :aliases => ",Novato", :latitude => "38.10742", :longitude => "-122.5697").save
City.new(:country_id => "233", :name => "Oakdale", :aliases => ",Oakdale", :latitude => "37.76659", :longitude => "-120.84715").save
City.new(:country_id => "233", :name => "Oakland", :aliases => "Oakland,Okland,Oklend,Oukland,ao ke lan,okurando,ÐÐºÐ»Ð°Ð½Ð´,ÐÐºÐ»ÐµÐ½Ð´,ÐÑÐºÐ»Ð°Ð½Ð´,×××§×× ×,ãªã¼ã¯ã©ã³ã,å¥¥åå°,Oakland", :latitude => "37.80437", :longitude => "-122.2708").save
City.new(:country_id => "233", :name => "Oakley", :aliases => ",Oakley", :latitude => "37.99742", :longitude => "-121.71245").save
City.new(:country_id => "233", :name => "Oceanside", :aliases => "Oceanside,Oceanside", :latitude => "33.19587", :longitude => "-117.37948").save
City.new(:country_id => "233", :name => "Oildale", :aliases => ",Oildale", :latitude => "35.41968", :longitude => "-119.01955").save
City.new(:country_id => "233", :name => "Ontario", :aliases => "Ontario,ÐÐ½ÑÐ°ÑÐ¸Ð¾,Ontario", :latitude => "34.06334", :longitude => "-117.65089").save
City.new(:country_id => "233", :name => "Orange", :aliases => "Orange,Orange", :latitude => "33.78779", :longitude => "-117.85311").save
City.new(:country_id => "233", :name => "Orangevale", :aliases => ",Orangevale", :latitude => "38.67851", :longitude => "-121.22578").save
City.new(:country_id => "233", :name => "Orcutt", :aliases => ",Orcutt", :latitude => "34.86526", :longitude => "-120.436").save
City.new(:country_id => "233", :name => "Orinda", :aliases => ",Orinda", :latitude => "37.87715", :longitude => "-122.17969").save
City.new(:country_id => "233", :name => "Oxnard", :aliases => "Oksnard,Oxnard,ÐÐºÑÐ½Ð°ÑÐ´,Oxnard", :latitude => "34.1975", :longitude => "-119.17705").save
City.new(:country_id => "233", :name => "Oxnard Shores", :aliases => ",Oxnard Shores", :latitude => "34.19084", :longitude => "-119.2415").save
City.new(:country_id => "233", :name => "Pacifica", :aliases => ",Pacifica", :latitude => "37.61383", :longitude => "-122.48692").save
City.new(:country_id => "233", :name => "Pacific Grove", :aliases => ",Pacific Grove", :latitude => "36.61774", :longitude => "-121.91662").save
City.new(:country_id => "233", :name => "Palm Desert", :aliases => ",Palm Desert", :latitude => "33.72224", :longitude => "-116.37446").save
City.new(:country_id => "233", :name => "Palm Springs", :aliases => "Palm Springs,pamusupuringusu,ÐÐ°Ð»Ð¼ Ð¡Ð¿ÑÐ¸Ð½Ð³Ñ,ãã¼ã ã¹ããªã³ã°ã¹,Palm Springs", :latitude => "33.8303", :longitude => "-116.54529").save
City.new(:country_id => "233", :name => "Palmdale", :aliases => "Palmdale,Palmdejl,ÐÐ°Ð»Ð¼Ð´ÐµÐ¹Ð»,Palmdale", :latitude => "34.57943", :longitude => "-118.11646").save
City.new(:country_id => "233", :name => "Palo Alto", :aliases => "Palo Al'to,Palo Alto,pa luo ao duo,paroaruto,ÐÐ°Ð»Ð¾ ÐÐ»ÑÐ¾,ÐÐ°Ð»Ð¾ ÐÐ»ÑÑÐ¾,×¤××× ××××,ãã­ã¢ã«ã,å¸ç¾å¥§å¤,Palo Alto", :latitude => "37.44188", :longitude => "-122.14302").save
City.new(:country_id => "233", :name => "Paradise", :aliases => ",Paradise", :latitude => "39.75961", :longitude => "-121.62192").save
City.new(:country_id => "233", :name => "Paramount", :aliases => ",Paramount", :latitude => "33.88946", :longitude => "-118.15979").save
City.new(:country_id => "233", :name => "Pasadena", :aliases => "Pasadena,Pasadina,paeseodineo,pasadena,ÐÐ°ÑÐ°Ð´Ð¸Ð½Ð°,ããµãã,í¨ìëë,Pasadena", :latitude => "34.14778", :longitude => "-118.14452").save
City.new(:country_id => "233", :name => "Paso Robles", :aliases => ",Paso Robles", :latitude => "35.62664", :longitude => "-120.691").save
City.new(:country_id => "233", :name => "Patterson", :aliases => ",Patterson", :latitude => "37.4716", :longitude => "-121.12966").save
City.new(:country_id => "233", :name => "Perris", :aliases => ",Perris", :latitude => "33.78252", :longitude => "-117.22865").save
City.new(:country_id => "233", :name => "Petaluma", :aliases => "Petaluma,ÐÐµÑÐ°Ð»ÑÐ¼Ð°,Petaluma", :latitude => "38.23242", :longitude => "-122.63665").save
City.new(:country_id => "233", :name => "Pico Rivera", :aliases => "Pico Rivera,Pico Rivera", :latitude => "33.98307", :longitude => "-118.09674").save
City.new(:country_id => "233", :name => "Pinole", :aliases => ",Pinole", :latitude => "38.00437", :longitude => "-122.29886").save
City.new(:country_id => "233", :name => "Pittsburg", :aliases => "Pitsb'rg,Pittsburg,ÐÐ¸ÑÑÐ±ÑÑÐ³,Pittsburg", :latitude => "38.02798", :longitude => "-121.88468").save
City.new(:country_id => "233", :name => "Placentia", :aliases => ",Placentia", :latitude => "33.87224", :longitude => "-117.87034").save
City.new(:country_id => "233", :name => "Pleasant Hill", :aliases => ",Pleasant Hill", :latitude => "37.94798", :longitude => "-122.0608").save
City.new(:country_id => "233", :name => "Pleasanton", :aliases => "Pleasanton,Plezant'n,ÐÐ»ÐµÐ·Ð°Ð½ÑÑÐ½,Pleasanton", :latitude => "37.66243", :longitude => "-121.87468").save
City.new(:country_id => "233", :name => "Pomona", :aliases => "Pomona,ÐÐ¾Ð¼Ð¾Ð½Ð°,Pomona", :latitude => "34.05529", :longitude => "-117.75228").save
City.new(:country_id => "233", :name => "Port Hueneme", :aliases => ",Port Hueneme", :latitude => "34.14778", :longitude => "-119.19511").save
City.new(:country_id => "233", :name => "Porterville", :aliases => ",Porterville", :latitude => "36.06523", :longitude => "-119.01677").save
City.new(:country_id => "233", :name => "Poway", :aliases => ",Poway", :latitude => "32.96282", :longitude => "-117.03586").save
City.new(:country_id => "233", :name => "Prunedale", :aliases => ",Prunedale", :latitude => "36.77579", :longitude => "-121.66967").save
City.new(:country_id => "233", :name => "Ramona", :aliases => ",Ramona", :latitude => "33.04171", :longitude => "-116.86808").save
City.new(:country_id => "233", :name => "Rancho Cordova", :aliases => ",Rancho Cordova", :latitude => "38.58907", :longitude => "-121.30273").save
City.new(:country_id => "233", :name => "Rancho Cucamonga", :aliases => "Rancho Cucamonga,Rancho Cucamonga", :latitude => "34.1064", :longitude => "-117.59311").save
City.new(:country_id => "233", :name => "Rancho Mirage", :aliases => ",Rancho Mirage", :latitude => "33.73974", :longitude => "-116.41279").save
City.new(:country_id => "233", :name => "Rancho Palos Verdes", :aliases => ",Rancho Palos Verdes", :latitude => "33.74446", :longitude => "-118.38702").save
City.new(:country_id => "233", :name => "Rancho San Diego", :aliases => ",Rancho San Diego", :latitude => "32.74727", :longitude => "-116.9353").save
City.new(:country_id => "233", :name => "Rancho Santa Margarita", :aliases => ",Rancho Santa Margarita", :latitude => "33.64086", :longitude => "-117.6031").save
City.new(:country_id => "233", :name => "Redlands", :aliases => "Redlands,ledeullaenjeu,reddoranzu,ã¬ããã©ã³ãº,ë ë¤ëì¦,Redlands", :latitude => "34.05557", :longitude => "-117.18254").save
City.new(:country_id => "233", :name => "Redondo Beach", :aliases => "Redondo Beach,Redondo Beach", :latitude => "33.84918", :longitude => "-118.38841").save
City.new(:country_id => "233", :name => "Redwood City", :aliases => ",Redwood City", :latitude => "37.48522", :longitude => "-122.23635").save
City.new(:country_id => "233", :name => "Reedley", :aliases => ",Reedley", :latitude => "36.59634", :longitude => "-119.4504").save
City.new(:country_id => "233", :name => "Rialto", :aliases => "Rial'to,Rialto,Ð Ð¸Ð°Ð»ÑÑÐ¾,Rialto", :latitude => "34.1064", :longitude => "-117.37032").save
City.new(:country_id => "233", :name => "Richmond", :aliases => "Richmond,Richmund,Ð Ð¸ÑÐ¼ÑÐ½Ð´,Richmond", :latitude => "37.93576", :longitude => "-122.34775").save
City.new(:country_id => "233", :name => "Ridgecrest", :aliases => ",Ridgecrest", :latitude => "35.62246", :longitude => "-117.6709").save
City.new(:country_id => "233", :name => "Riverbank", :aliases => ",Riverbank", :latitude => "37.73604", :longitude => "-120.93549").save
City.new(:country_id => "233", :name => "Riverside", :aliases => "Riverside,Rivursajd,Ð Ð¸Ð²ÑÑÑÐ°Ð¹Ð´,Riverside", :latitude => "33.95335", :longitude => "-117.39616").save
City.new(:country_id => "233", :name => "Rocklin", :aliases => ",Rocklin", :latitude => "38.79073", :longitude => "-121.23578").save
City.new(:country_id => "233", :name => "Rohnert Park", :aliases => ",Rohnert Park", :latitude => "38.33964", :longitude => "-122.7011").save
City.new(:country_id => "233", :name => "Rosamond", :aliases => ",Rosamond", :latitude => "34.86414", :longitude => "-118.16341").save
City.new(:country_id => "233", :name => "Rosemead", :aliases => ",Rosemead", :latitude => "34.08057", :longitude => "-118.07285").save
City.new(:country_id => "233", :name => "Rosemont", :aliases => "Rozemont,Ð Ð¾Ð·ÐµÐ¼Ð¾Ð½Ñ,Rosemont", :latitude => "38.55185", :longitude => "-121.36467").save
City.new(:country_id => "233", :name => "Roseville", :aliases => "Roseville,Rozvell,Ð Ð¾Ð·Ð²ÐµÐ»Ð»,Roseville", :latitude => "38.75212", :longitude => "-121.28801").save
City.new(:country_id => "233", :name => "Rowland Heights", :aliases => ",Rowland Heights", :latitude => "33.97612", :longitude => "-117.90534").save
City.new(:country_id => "233", :name => "Rubidoux", :aliases => ",Rubidoux", :latitude => "33.99613", :longitude => "-117.4056").save
City.new(:country_id => "233", :name => "Sacramento", :aliases => "Sacramento,Sakramentas,Sakramento,sakuramento,sha jia mian du,sqrmntw,Ð¡Ð°ÐºÑÐ°Ð¼ÐµÐ½ÑÐ¾,×¡×§×¨×× ××,ãµã¯ã©ã¡ã³ã,æ²å ç·¬åº¦,Sacramento", :latitude => "38.58157", :longitude => "-121.4944").save
City.new(:country_id => "233", :name => "Salida", :aliases => ",Salida", :latitude => "37.70576", :longitude => "-121.08494").save
City.new(:country_id => "233", :name => "Salinas", :aliases => "Salinas,Ð¡Ð°Ð»Ð¸Ð½Ð°Ñ,Salinas", :latitude => "36.67774", :longitude => "-121.6555").save
City.new(:country_id => "233", :name => "San Bernardino", :aliases => "San Bernardino,saenbeoneodino,sanbanadino,sanbanadino_,Ð¡Ð°Ð½ ÐÐµÑÐ½Ð°ÑÐ´Ð¸Ð½Ð¾,ãµã³ãã¼ãã¼ãã£ã¼ã,ãµã³ãã¼ãã¼ãã£ã¼ã_,ìë²ëëë¸,San Bernardino", :latitude => "34.10834", :longitude => "-117.28977").save
City.new(:country_id => "233", :name => "San Bruno", :aliases => ",San Bruno", :latitude => "37.63049", :longitude => "-122.41108").save
City.new(:country_id => "233", :name => "San Carlos", :aliases => ",San Carlos", :latitude => "37.50716", :longitude => "-122.26052").save
City.new(:country_id => "233", :name => "San Clemente", :aliases => ",San Clemente", :latitude => "33.42697", :longitude => "-117.61199").save
City.new(:country_id => "233", :name => "San Diego", :aliases => "Didacopolis,Lungsod ng San Diego,San Diegas,San Diego,San-Diego,saendieigo,san dyyghw,sandiego,sheng de ya ge,sn dyygw,Ð¡Ð°Ð½ ÐÐ¸ÐµÐ³Ð¾,Ð¡Ð°Ð½-ÐÐ¸ÐµÐ³Ð¾,Ð¡Ð°Ð½-ÐÑÑÐ³Ð¾,×¡× ×××××,Ø³Ø§Ù Ø¯ÙÙØºÙ,ãµã³ãã£ã¨ã´,èå°çå¥,ìëìì´ê³ ,San Diego", :latitude => "32.71533", :longitude => "-117.15726").save
City.new(:country_id => "233", :name => "San Dimas", :aliases => ",San Dimas", :latitude => "34.10668", :longitude => "-117.80673").save
City.new(:country_id => "233", :name => "San Fernando", :aliases => ",San Fernando", :latitude => "34.28195", :longitude => "-118.43897").save
City.new(:country_id => "233", :name => "San Francisco", :aliases => "Frisco,Kapalakiko,Lungsod ng San Francisco,San Francisco,San Franciscu,San Franciskas,San Francisko,San Fransisco,San Frantzisko,San Phransisko,San-Francisko,Sanctus Franciscus,Sanfrancisko,jiu jin shan,saenpeulansiseuko,san f ran si s ko,san fransyskw,sanfuranshisuko,sn prnsysqw,Î£Î±Î½ Î¦ÏÎ±Î½ÏÎ¯ÏÎºÎ¿,Ð¡Ð°Ð½ Ð¤ÑÐ°Ð½ÑÐ¸ÑÐºÐ¾,Ð¡Ð°Ð½-Ð¤ÑÐ°Ð½ÑÐ¸ÑÐºÐ¾,Ð¡Ð°Ð½-Ð¤ÑÐ°Ð½ÑÑÑÐºÐ¾,×¡× ×¤×¨× ×¡××¡×§×,Ø³Ø§Ù ÙØ±Ø§ÙØ³ÙØ³ÙÙ,Ø³Ø§Ù ÙØ±Ø§ÙØ³ÙØ³ÙÙ,Ø³Ø§ÙâÙØ±Ø§ÙØ³ÛØ³Ú©Ù,à¸à¸²à¸à¸à¸£à¸²à¸à¸à¸´à¸ªà¹à¸,á¡áá-á¤á áááªáá¡áá,ãµã³ãã©ã³ã·ã¹ã³,æ§éå±±,ìíëìì¤ì½,San Francisco", :latitude => "37.77493", :longitude => "-122.41942").save
City.new(:country_id => "233", :name => "San Gabriel", :aliases => ",San Gabriel", :latitude => "34.09611", :longitude => "-118.10583").save
City.new(:country_id => "233", :name => "San Jacinto", :aliases => ",San Jacinto", :latitude => "33.78391", :longitude => "-116.95864").save
City.new(:country_id => "233", :name => "San Jose", :aliases => "San Chose,San ChosÄ,San Jose,San JosÃ©,San Khose,San-Joseo,San-Khose,Sanctus Iosephus,san'noze,sheng he xi,sn hwzh,Ð¡Ð°Ð½ Ð¥Ð¾ÑÐµ,Ð¡Ð°Ð½-Ð¥Ð¾ÑÐµ,×¡× ××××,ãµã³ãã¼,èè·è¥¿,San Jose", :latitude => "37.33939", :longitude => "-121.89496").save
City.new(:country_id => "233", :name => "San Juan Capistrano", :aliases => ",San Juan Capistrano", :latitude => "33.50169", :longitude => "-117.66255").save
City.new(:country_id => "233", :name => "San Leandro", :aliases => ",San Leandro", :latitude => "37.72493", :longitude => "-122.15608").save
City.new(:country_id => "233", :name => "San Lorenzo", :aliases => ",San Lorenzo", :latitude => "37.68104", :longitude => "-122.12441").save
City.new(:country_id => "233", :name => "San Luis Obispo", :aliases => ",San Luis Obispo", :latitude => "35.28275", :longitude => "-120.65962").save
City.new(:country_id => "233", :name => "San Marcos", :aliases => "San Marcos,San Marcos", :latitude => "33.14337", :longitude => "-117.16614").save
City.new(:country_id => "233", :name => "San Mateo", :aliases => "San Mateo,Ð¡Ð°Ð½ ÐÐ°ÑÐµÐ¾,San Mateo", :latitude => "37.56299", :longitude => "-122.32553").save
City.new(:country_id => "233", :name => "San Pablo", :aliases => ",San Pablo", :latitude => "37.96215", :longitude => "-122.34553").save
City.new(:country_id => "233", :name => "San Rafael", :aliases => ",San Rafael", :latitude => "37.97353", :longitude => "-122.53109").save
City.new(:country_id => "233", :name => "San Ramon", :aliases => ",San Ramon", :latitude => "37.77993", :longitude => "-121.97802").save
City.new(:country_id => "233", :name => "Sanger", :aliases => ",Sanger", :latitude => "36.70801", :longitude => "-119.55597").save
City.new(:country_id => "233", :name => "Santa Ana", :aliases => "Santa Ana,santaana,Ð¡Ð°Ð½ÑÐ° ÐÐ½Ð°,ãµã³ã¿ã¢ã,Santa Ana", :latitude => "33.74557", :longitude => "-117.86783").save
City.new(:country_id => "233", :name => "Santa Barbara", :aliases => "Sancta Barbara,Santa Barbara,santababara,sheng ba ba la,Ð¡Ð°Ð½ÑÐ° ÐÐ°ÑÐ±Ð°ÑÐ°,ãµã³ã¿ãã¼ãã©,å£å·´å·´æ,Santa Barbara", :latitude => "34.42083", :longitude => "-119.69819").save
City.new(:country_id => "233", :name => "Santa Clara", :aliases => "Santa Clara,Santa Klara,santakurara,sheng ke la la,Ð¡Ð°Ð½ÑÐ° ÐÐ»Ð°ÑÐ°,ãµã³ã¿ã¯ã©ã©,å£åææ,Santa Clara", :latitude => "37.35411", :longitude => "-121.95524").save
City.new(:country_id => "233", :name => "Santa Clarita", :aliases => "Santa Clarita,Santa Klarita,Ð¡Ð°Ð½ÑÐ° ÐÐ»Ð°ÑÐ¸ÑÐ°,Santa Clarita", :latitude => "34.39166", :longitude => "-118.54259").save
City.new(:country_id => "233", :name => "Santa Cruz", :aliases => "Santa Cruz,Santa Kruz,Santa-Krus,Ð¡Ð°Ð½ÑÐ° ÐÑÑÐ·,Ð¡Ð°Ð½ÑÐ°-ÐÑÑÑ,Santa Cruz", :latitude => "36.97412", :longitude => "-122.0308").save
City.new(:country_id => "233", :name => "Santa Fe Springs", :aliases => ",Santa Fe Springs", :latitude => "33.94724", :longitude => "-118.08535").save
City.new(:country_id => "233", :name => "Santa Maria", :aliases => "Santa Maria,Santa Marija,Ð¡Ð°Ð½ÑÐ° ÐÐ°ÑÐ¸Ñ,Santa Maria", :latitude => "34.95303", :longitude => "-120.43572").save
City.new(:country_id => "233", :name => "Santa Monica", :aliases => "Sancta Monica,Santa Monica,Santa Monika,Santa MÃ´nica,santa mwnyka,santamonika,Ð¡Ð°Ð½ÑÐ° ÐÐ¾Ð½Ð¸ÐºÐ°,Ø³Ø§ÙØªØ§ ÙÙÙÙÙØ§,ãµã³ã¿ã¢ãã«,Santa Monica", :latitude => "34.01945", :longitude => "-118.49119").save
City.new(:country_id => "233", :name => "Santa Paula", :aliases => "Santa-Paula,Ð¡Ð°Ð½ÑÐ°-ÐÐ°ÑÐ»Ð°,Santa Paula", :latitude => "34.35417", :longitude => "-119.05927").save
City.new(:country_id => "233", :name => "Santa Rosa", :aliases => "Santa Rosa,Santa Roza,Ð¡Ð°Ð½ÑÐ° Ð Ð¾Ð·Ð°,Santa Rosa", :latitude => "38.44047", :longitude => "-122.71443").save
City.new(:country_id => "233", :name => "Santee", :aliases => "Santi,Ð¡Ð°Ð½ÑÐ¸,Santee", :latitude => "32.83838", :longitude => "-116.97392").save
City.new(:country_id => "233", :name => "Saratoga", :aliases => ",Saratoga", :latitude => "37.26383", :longitude => "-122.02301").save
City.new(:country_id => "233", :name => "Seal Beach", :aliases => ",Seal Beach", :latitude => "33.74141", :longitude => "-118.10479").save
City.new(:country_id => "233", :name => "Seaside", :aliases => "Sisajd,Ð¡Ð¸ÑÐ°Ð¹Ð´,Seaside", :latitude => "36.61107", :longitude => "-121.85162").save
City.new(:country_id => "233", :name => "Selma", :aliases => "Sel'ma,Ð¡ÐµÐ»ÑÐ¼Ð°,Selma", :latitude => "36.57078", :longitude => "-119.61208").save
City.new(:country_id => "233", :name => "Simi Valley", :aliases => "Simi Valley,Simi Valley", :latitude => "34.26945", :longitude => "-118.78148").save
City.new(:country_id => "233", :name => "Soledad", :aliases => "Soledad,Ð¡Ð¾Ð»ÐµÐ´Ð°Ð´,Soledad", :latitude => "36.42469", :longitude => "-121.32632").save
City.new(:country_id => "233", :name => "South El Monte", :aliases => ",South El Monte", :latitude => "34.05195", :longitude => "-118.04673").save
City.new(:country_id => "233", :name => "South Gate", :aliases => "South Gate,South Gate", :latitude => "33.95474", :longitude => "-118.21202").save
City.new(:country_id => "233", :name => "South Lake Tahoe", :aliases => ",South Lake Tahoe", :latitude => "38.93324", :longitude => "-119.98435").save
City.new(:country_id => "233", :name => "South Pasadena", :aliases => ",South Pasadena", :latitude => "34.11612", :longitude => "-118.15035").save
City.new(:country_id => "233", :name => "South San Francisco", :aliases => ",South San Francisco", :latitude => "37.65466", :longitude => "-122.40775").save
City.new(:country_id => "233", :name => "South San Jose Hills", :aliases => ",South San Jose Hills", :latitude => "34.01279", :longitude => "-117.90478").save
City.new(:country_id => "233", :name => "South Whittier", :aliases => ",South Whittier", :latitude => "33.96085", :longitude => "-118.04173").save
City.new(:country_id => "233", :name => "South Yuba City", :aliases => ",South Yuba City", :latitude => "39.11656", :longitude => "-121.63913").save
City.new(:country_id => "233", :name => "Spring Valley", :aliases => "Spring-Vehlli,Ð¡Ð¿ÑÐ¸Ð½Ð³-ÐÑÐ»Ð»Ð¸,Spring Valley", :latitude => "32.74477", :longitude => "-116.99892").save
City.new(:country_id => "233", :name => "Stanton", :aliases => "Stehnton,Ð¡ÑÑÐ½ÑÐ¾Ð½,Stanton", :latitude => "33.80252", :longitude => "-117.99312").save
City.new(:country_id => "233", :name => "Stockton", :aliases => "Stockton,Stokt'n,sutokkuton,Ð¡ÑÐ¾ÐºÑÑÐ½,ã¹ããã¯ãã³,Stockton", :latitude => "37.9577", :longitude => "-121.29078").save
City.new(:country_id => "233", :name => "Suisun", :aliases => ",Suisun", :latitude => "38.23825", :longitude => "-122.04024").save
City.new(:country_id => "233", :name => "Sun City", :aliases => ",Sun City", :latitude => "33.70919", :longitude => "-117.19726").save
City.new(:country_id => "233", :name => "Sunnyvale", :aliases => "S'nivejl,Sunnyvale,sen ni wei er,Ð¡ÑÐ½Ð¸Ð²ÐµÐ¹Ð»,æ£®å°¼é¦å°,Sunnyvale", :latitude => "37.36883", :longitude => "-122.03635").save
City.new(:country_id => "233", :name => "Temecula", :aliases => "Temekula,Ð¢ÐµÐ¼ÐµÐºÑÐ»Ð°,Temecula", :latitude => "33.49364", :longitude => "-117.14836").save
City.new(:country_id => "233", :name => "Temple City", :aliases => ",Temple City", :latitude => "34.10723", :longitude => "-118.05785").save
City.new(:country_id => "233", :name => "Thousand Oaks", :aliases => ",Thousand Oaks", :latitude => "34.17056", :longitude => "-118.83759").save
City.new(:country_id => "233", :name => "Torrance", :aliases => "Torrance,Torrans,Ð¢Ð¾ÑÑÐ°Ð½Ñ,Torrance", :latitude => "33.83585", :longitude => "-118.34063").save
City.new(:country_id => "233", :name => "Tracy", :aliases => "Tracy,Trejsi,Ð¢ÑÐµÐ¹ÑÐ¸,Tracy", :latitude => "37.73965", :longitude => "-121.42522").save
City.new(:country_id => "233", :name => "Truckee", :aliases => ",Truckee", :latitude => "39.32796", :longitude => "-120.18325").save
City.new(:country_id => "233", :name => "Tulare", :aliases => "Tular,Ð¢ÑÐ»Ð°Ñ,Tulare", :latitude => "36.20773", :longitude => "-119.34734").save
City.new(:country_id => "233", :name => "Turlock", :aliases => "Turlock,Turlock", :latitude => "37.49466", :longitude => "-120.84659").save
City.new(:country_id => "233", :name => "Tustin", :aliases => "Tustin,Tustin", :latitude => "33.74585", :longitude => "-117.82617").save
City.new(:country_id => "233", :name => "North Tustin", :aliases => ",North Tustin", :latitude => "33.76446", :longitude => "-117.79394").save
City.new(:country_id => "233", :name => "Twentynine Palms", :aliases => ",Twentynine Palms", :latitude => "34.13556", :longitude => "-116.05417").save
City.new(:country_id => "233", :name => "Ukiah", :aliases => ",Ukiah", :latitude => "39.15017", :longitude => "-123.20778").save
City.new(:country_id => "233", :name => "Union City", :aliases => "Junion-Siti,Ð®Ð½Ð¸Ð¾Ð½-Ð¡Ð¸ÑÐ¸,Union City", :latitude => "37.59583", :longitude => "-122.01917").save
City.new(:country_id => "233", :name => "Union City", :aliases => "Juni'n Siti,Union City,Ð®Ð½Ð¸ÑÐ½ Ð¡Ð¸ÑÐ¸,Union City", :latitude => "37.59577", :longitude => "-122.01913").save
City.new(:country_id => "233", :name => "Universal City", :aliases => "Juniversal-Siti,Ð®Ð½Ð¸Ð²ÐµÑÑÐ°Ð»-Ð¡Ð¸ÑÐ¸,Universal City", :latitude => "34.1389", :longitude => "-118.35341").save
City.new(:country_id => "233", :name => "Upland", :aliases => "Upland,Upland", :latitude => "34.09751", :longitude => "-117.64839").save
City.new(:country_id => "233", :name => "Vacaville", :aliases => "Vacaville,Vakavil,ÐÐ°ÐºÐ°Ð²Ð¸Ð»,Vacaville", :latitude => "38.35658", :longitude => "-121.98774").save
City.new(:country_id => "233", :name => "Valinda", :aliases => ",Valinda", :latitude => "34.04529", :longitude => "-117.94367").save
City.new(:country_id => "233", :name => "Vallejo", :aliases => "Valekho,Vallejo,ÐÐ°Ð»ÐµÑÐ¾,Vallejo", :latitude => "38.10409", :longitude => "-122.25664").save
City.new(:country_id => "233", :name => "Ventura", :aliases => ",Ventura", :latitude => "34.27834", :longitude => "-119.29317").save
City.new(:country_id => "233", :name => "Victorville", :aliases => "Victorville,Victorville", :latitude => "34.53611", :longitude => "-117.29116").save
City.new(:country_id => "233", :name => "Vincent", :aliases => ",Vincent", :latitude => "34.50055", :longitude => "-118.11646").save
City.new(:country_id => "233", :name => "Visalia", :aliases => "Visalia,Visalia", :latitude => "36.33023", :longitude => "-119.29206").save
City.new(:country_id => "233", :name => "Vista", :aliases => "Vista,Vista", :latitude => "33.20004", :longitude => "-117.24254").save
City.new(:country_id => "233", :name => "Walnut", :aliases => ",Walnut", :latitude => "34.02029", :longitude => "-117.86534").save
City.new(:country_id => "233", :name => "Walnut Creek", :aliases => "Uoln't Krijk,Walnut Creek,Ð£Ð¾Ð»Ð½ÑÑ ÐÑÐ¸Ð¹Ðº,Walnut Creek", :latitude => "37.90631", :longitude => "-122.06496").save
City.new(:country_id => "233", :name => "Walnut Park", :aliases => ",Walnut Park", :latitude => "33.96807", :longitude => "-118.22507").save
City.new(:country_id => "233", :name => "Watsonville", :aliases => ",Watsonville", :latitude => "36.91023", :longitude => "-121.75689").save
City.new(:country_id => "233", :name => "West Carson", :aliases => ",West Carson", :latitude => "33.82168", :longitude => "-118.29257").save
City.new(:country_id => "233", :name => "West Covina", :aliases => "West Covina,Zapadna Kovina,Zapadnaja Kovina,ÐÐ°Ð¿Ð°Ð´Ð½Ð° ÐÐ¾Ð²Ð¸Ð½Ð°,ÐÐ°Ð¿Ð°Ð´Ð½Ð°Ñ ÐÐ¾Ð²Ð¸Ð½Ð°,West Covina", :latitude => "34.06862", :longitude => "-117.93895").save
City.new(:country_id => "233", :name => "West Hollywood", :aliases => ",West Hollywood", :latitude => "34.09001", :longitude => "-118.36174").save
City.new(:country_id => "233", :name => "West Puente Valley", :aliases => ",West Puente Valley", :latitude => "34.05168", :longitude => "-117.9684").save
City.new(:country_id => "233", :name => "West Sacramento", :aliases => ",West Sacramento", :latitude => "38.58046", :longitude => "-121.53023").save
City.new(:country_id => "233", :name => "Westminster", :aliases => "Westminster,Westminster", :latitude => "33.75918", :longitude => "-118.00673").save
City.new(:country_id => "233", :name => "Westmont", :aliases => ",Westmont", :latitude => "33.9414", :longitude => "-118.3023").save
City.new(:country_id => "233", :name => "Whittier", :aliases => "Whittier,Whittier", :latitude => "33.97918", :longitude => "-118.03284").save
City.new(:country_id => "233", :name => "Wildomar", :aliases => ",Wildomar", :latitude => "33.59891", :longitude => "-117.28004").save
City.new(:country_id => "233", :name => "Willowbrook", :aliases => ",Willowbrook", :latitude => "33.91696", :longitude => "-118.25507").save
City.new(:country_id => "233", :name => "Windsor", :aliases => "Vindzor,ÐÐ¸Ð½Ð´Ð·Ð¾Ñ,Windsor", :latitude => "38.54713", :longitude => "-122.81638").save
City.new(:country_id => "233", :name => "Winter Gardens", :aliases => ",Winter Gardens", :latitude => "32.83116", :longitude => "-116.93336").save
City.new(:country_id => "233", :name => "Woodland", :aliases => ",Woodland", :latitude => "38.67852", :longitude => "-121.7733").save
City.new(:country_id => "233", :name => "Yorba Linda", :aliases => "Yorba Linda,Yorba Linda", :latitude => "33.88863", :longitude => "-117.81311").save
City.new(:country_id => "233", :name => "Yuba City", :aliases => ",Yuba City", :latitude => "39.14045", :longitude => "-121.61691").save
City.new(:country_id => "233", :name => "Yucaipa", :aliases => ",Yucaipa", :latitude => "34.03362", :longitude => "-117.04309").save
City.new(:country_id => "233", :name => "Yucca Valley", :aliases => ",Yucca Valley", :latitude => "34.11417", :longitude => "-116.43224").save
City.new(:country_id => "233", :name => "Arvada", :aliases => "Arvada,Arvada", :latitude => "39.80276", :longitude => "-105.08748").save
City.new(:country_id => "233", :name => "Aurora", :aliases => "Aurora,Avrora,ÐÐ²ÑÐ¾ÑÐ°,Aurora", :latitude => "39.72943", :longitude => "-104.83192").save
City.new(:country_id => "233", :name => "Black Forest", :aliases => ",Black Forest", :latitude => "39.01305", :longitude => "-104.70081").save
City.new(:country_id => "233", :name => "Brighton", :aliases => "Brajton,ÐÑÐ°Ð¹ÑÐ¾Ð½,Brighton", :latitude => "39.98526", :longitude => "-104.82053").save
City.new(:country_id => "233", :name => "Broomfield", :aliases => ",Broomfield", :latitude => "39.92054", :longitude => "-105.08665").save
City.new(:country_id => "233", :name => "Canon City", :aliases => ",CaÃ±on City", :latitude => "38.44098", :longitude => "-105.24245").save
City.new(:country_id => "233", :name => "Castle Rock", :aliases => ",Castle Rock", :latitude => "39.37221", :longitude => "-104.85609").save
City.new(:country_id => "233", :name => "Castlewood", :aliases => ",Castlewood", :latitude => "39.58471", :longitude => "-104.90109").save
City.new(:country_id => "233", :name => "Centennial", :aliases => ",Centennial", :latitude => "39.57916", :longitude => "-104.87692").save
City.new(:country_id => "233", :name => "Cimarron Hills", :aliases => ",Cimarron Hills", :latitude => "38.85861", :longitude => "-104.69886").save
City.new(:country_id => "233", :name => "Clifton", :aliases => "Klifton,ÐÐ»Ð¸ÑÑÐ¾Ð½,Clifton", :latitude => "39.09193", :longitude => "-108.44898").save
City.new(:country_id => "233", :name => "Colorado Springs", :aliases => "Colorado Springs,Kolorado Springs,ke luo la duo si pu lin si,ÐÐ¾Ð»Ð¾ÑÐ°Ð´Ð¾ Ð¡Ð¿ÑÐ¸Ð½Ð³Ñ,ã³ã­ã©ãã»ã¹ããªã³ã°ã¹,ç§ç½æå¤æ¯æ®ææ¯,Colorado Springs", :latitude => "38.83388", :longitude => "-104.82136").save
City.new(:country_id => "233", :name => "Columbine", :aliases => "Kolombina,ÐÐ¾Ð»Ð¾Ð¼Ð±Ð¸Ð½Ð°,Columbine", :latitude => "39.58777", :longitude => "-105.06943").save
City.new(:country_id => "233", :name => "Commerce City", :aliases => ",Commerce City", :latitude => "39.80832", :longitude => "-104.93387").save
City.new(:country_id => "233", :name => "Denver", :aliases => "Denv'r,Denver,Denvero,dan fu,denba,denbeo,denwexr,dnwwr,ÐÐµÐ½Ð²ÐµÑ,ÐÐµÐ½Ð²ÑÑ,×× ×××¨,à¹à¸à¸à¹à¸§à¸­à¸£à¹,ãã³ãã¼,ä¸¹ä½,ë´ë²,Denver", :latitude => "39.73915", :longitude => "-104.9847").save
City.new(:country_id => "233", :name => "Durango", :aliases => ",Durango", :latitude => "37.27528", :longitude => "-107.88007").save
City.new(:country_id => "233", :name => "Englewood", :aliases => ",Englewood", :latitude => "39.64777", :longitude => "-104.98776").save
City.new(:country_id => "233", :name => "Fountain", :aliases => ",Fountain", :latitude => "38.68222", :longitude => "-104.70081").save
City.new(:country_id => "233", :name => "Golden", :aliases => ",Golden", :latitude => "39.75554", :longitude => "-105.2211").save
City.new(:country_id => "233", :name => "Grand Junction", :aliases => ",Grand Junction", :latitude => "39.06387", :longitude => "-108.55065").save
City.new(:country_id => "233", :name => "Highlands Ranch", :aliases => "Highlands Ranch,Highlands Ranch", :latitude => "39.55388", :longitude => "-104.96943").save
City.new(:country_id => "233", :name => "Ken Caryl", :aliases => ",Ken Caryl", :latitude => "39.57726", :longitude => "-105.11687").save
City.new(:country_id => "233", :name => "Lafayette", :aliases => "Lafajet,ÐÐ°ÑÐ°Ð¹ÐµÑ,Lafayette", :latitude => "39.9936", :longitude => "-105.08971").save
City.new(:country_id => "233", :name => "Lakewood", :aliases => "Lakewood,Lejkvud,ÐÐµÐ¹ÐºÐ²ÑÐ´,Lakewood", :latitude => "39.70471", :longitude => "-105.08137").save
City.new(:country_id => "233", :name => "Littleton", :aliases => "Littlton,ÐÐ¸ÑÑÐ»ÑÐ¾Ð½,Littleton", :latitude => "39.61332", :longitude => "-105.01665").save
City.new(:country_id => "233", :name => "Louisville", :aliases => "Luisvil,ÐÑÐ¸ÑÐ²Ð¸Ð»,Louisville", :latitude => "39.97776", :longitude => "-105.13193").save
City.new(:country_id => "233", :name => "Montrose", :aliases => ",Montrose", :latitude => "38.47832", :longitude => "-107.87617").save
City.new(:country_id => "233", :name => "Northglenn", :aliases => ",Northglenn", :latitude => "39.88554", :longitude => "-104.9872").save
City.new(:country_id => "233", :name => "Parker", :aliases => "Parker,ÐÐ°ÑÐºÐµÑ,Parker", :latitude => "39.5186", :longitude => "-104.76136").save
City.new(:country_id => "233", :name => "Pueblo", :aliases => "Pueblo,Puehblo,ÐÑÑÐ±Ð»Ð¾,Pueblo", :latitude => "38.25445", :longitude => "-104.60914").save
City.new(:country_id => "233", :name => "Pueblo West", :aliases => ",Pueblo West", :latitude => "38.35", :longitude => "-104.72275").save
City.new(:country_id => "233", :name => "Sherrelwood", :aliases => ",Sherrelwood", :latitude => "39.83776", :longitude => "-105.00137").save
City.new(:country_id => "233", :name => "Southglenn", :aliases => ",Southglenn", :latitude => "39.58721", :longitude => "-104.95276").save
City.new(:country_id => "233", :name => "Thornton", :aliases => "Thornton,Tornton,Ð¢Ð¾ÑÐ½ÑÐ¾Ð½,Thornton", :latitude => "39.86804", :longitude => "-104.97192").save
City.new(:country_id => "233", :name => "Westminster", :aliases => "Westminster,Westminster", :latitude => "39.83665", :longitude => "-105.0372").save
City.new(:country_id => "233", :name => "Wheat Ridge", :aliases => ",Wheat Ridge", :latitude => "39.7661", :longitude => "-105.07721").save
City.new(:country_id => "233", :name => "Dodge City", :aliases => "Dodzh-siti,ÐÐ¾Ð´Ð¶-ÑÐ¸ÑÐ¸,Dodge City", :latitude => "37.7528", :longitude => "-100.01708").save
City.new(:country_id => "233", :name => "Garden City", :aliases => ",Garden City", :latitude => "37.97169", :longitude => "-100.87266").save
City.new(:country_id => "233", :name => "Liberal", :aliases => "Liberal'naja,ÐÐ¸Ð±ÐµÑÐ°Ð»ÑÐ½Ð°Ñ,Liberal", :latitude => "37.04308", :longitude => "-100.921").save
City.new(:country_id => "233", :name => "Alamogordo", :aliases => "Alamogordo,ÐÐ»Ð°Ð¼Ð¾Ð³Ð¾ÑÐ´Ð¾,Alamogordo", :latitude => "32.89953", :longitude => "-105.96026").save
City.new(:country_id => "233", :name => "Albuquerque", :aliases => "Al'bukerke,Albak'rki,Albuquerque,Alburquerque,Duke City,The Duke City,arubakaki,ÐÐ»Ð±Ð°ÐºÑÑÐºÐ¸,ÐÐ»ÑÐ±ÑÐºÐµÑÐºÐµ,××××§×¨×§×,ã¢ã«ãã«ã¼ã­,Albuquerque", :latitude => "35.08449", :longitude => "-106.65114").save
City.new(:country_id => "233", :name => "Carlsbad", :aliases => ",Carlsbad", :latitude => "32.42067", :longitude => "-104.22884").save
City.new(:country_id => "233", :name => "Clovis", :aliases => "Klovis,ÐÐ»Ð¾Ð²Ð¸Ñ,Clovis", :latitude => "34.4048", :longitude => "-103.20523").save
City.new(:country_id => "233", :name => "Farmington", :aliases => "Farmington,Ð¤Ð°ÑÐ¼Ð¸Ð½Ð³ÑÐ¾Ð½,Farmington", :latitude => "36.72806", :longitude => "-108.21869").save
City.new(:country_id => "233", :name => "Gallup", :aliases => ",Gallup", :latitude => "35.52808", :longitude => "-108.74258").save
City.new(:country_id => "233", :name => "Hobbs", :aliases => "Khobbs,Ð¥Ð¾Ð±Ð±Ñ,Hobbs", :latitude => "32.70261", :longitude => "-103.13604").save
City.new(:country_id => "233", :name => "Las Cruces", :aliases => "Las Cruces,Las-Kruses,ÐÐ°Ñ-ÐÑÑÑÐµÑ,Las Cruces", :latitude => "32.31232", :longitude => "-106.77834").save
City.new(:country_id => "233", :name => "Rio Rancho", :aliases => "Rio Rancho,Rio-Rancho,Ð Ð¸Ð¾-Ð Ð°Ð½ÑÐ¾,Rio Rancho", :latitude => "35.23338", :longitude => "-106.66447").save
City.new(:country_id => "233", :name => "Roswell", :aliases => "Roswell,Roswell", :latitude => "33.39427", :longitude => "-104.52302").save
City.new(:country_id => "233", :name => "Santa Fe", :aliases => "Santa Fe,Santa FÃ©,Santa FÄ,Santa-Fe,Yooto,YootÃ³,santafe,sheng da fei,snth ph,Ð¡Ð°Ð½ÑÐ° Ð¤Ðµ,Ð¡Ð°Ð½ÑÐ°-Ð¤Ðµ,×¡× ×× ×¤×,ãµã³ã¿ãã§,èå¤§é,Santa Fe", :latitude => "35.68698", :longitude => "-105.9378").save
City.new(:country_id => "233", :name => "South Valley", :aliases => ",South Valley", :latitude => "35.01005", :longitude => "-106.67808").save
City.new(:country_id => "233", :name => "Boulder City", :aliases => "Boulder,ÐÐ¾ÑÐ»Ð´ÐµÑ,Boulder City", :latitude => "35.97859", :longitude => "-114.83249").save
City.new(:country_id => "233", :name => "Carson City", :aliases => "Carson City,Carson city,Karson-Siti,Karsun Siti,ka sen cheng,karsana siti,karsn syty,kasonshiti,qrswn syty,ÐÐ°ÑÑÐ¾Ð½-Ð¡Ð¸ÑÐ¸,ÐÐ°ÑÑÑÐ½ Ð¡Ð¸ÑÐ¸,×§×¨×¡×× ×¡×××,ÙØ§Ø±Ø³Ù Ø³ÙØªÙ,à¦à¦¾à¦°à§à¦¸à¦¨ à¦¸à¦¿à¦à¦¿,ã«ã¼ã½ã³ã·ãã£,å¡æ£®å,Carson City", :latitude => "39.1638", :longitude => "-119.7674").save
City.new(:country_id => "233", :name => "Enterprise", :aliases => ",Enterprise", :latitude => "36.02525", :longitude => "-115.24194").save
City.new(:country_id => "233", :name => "Henderson", :aliases => "Henderson,Khenderson,Ð¥ÐµÐ½Ð´ÐµÑÑÐ¾Ð½,Henderson", :latitude => "36.0397", :longitude => "-114.98194").save
City.new(:country_id => "233", :name => "Las Vegas", :aliases => "Las Vegas,Las-Vegas,Lungsod ng Las Vegas,la si wei jia si,las fyghas,las weka s,lasa bhegasa,laseubeigeoseu,rasubegasu,ÐÐ°Ñ ÐÐµÐ³Ð°Ñ,ÐÐ°Ñ-ÐÐµÐ³Ð°Ñ,×××¡ ××××¡,ÙØ§Ø³ ÙÙØºØ§Ø³,à¦²à¦¾à¦¸ à¦­à§à¦à¦¾à¦¸,à¸¥à¸²à¸ªà¹à¸§à¸à¸±à¸ª,ã©ã¹ãã¬ã¹,ææ¯ç»´å æ¯,ë¼ì¤ë² ì´ê±°ì¤,Las Vegas", :latitude => "36.17497", :longitude => "-115.13722").save
City.new(:country_id => "233", :name => "North Las Vegas", :aliases => "North Las Vegas,North Las Vegas", :latitude => "36.19886", :longitude => "-115.1175").save
City.new(:country_id => "233", :name => "Pahrump", :aliases => ",Pahrump", :latitude => "36.20829", :longitude => "-115.98391").save
City.new(:country_id => "233", :name => "Paradise", :aliases => "Paradise,Paradise", :latitude => "36.09719", :longitude => "-115.14666").save
City.new(:country_id => "233", :name => "Reno", :aliases => "Reno,Rino,lei nuo,rino,rynw,Ð Ð¸Ð½Ð¾,×¨×× ×,Ø±ÙÙÙ,ãªã,é·è«¾,Reno", :latitude => "39.52963", :longitude => "-119.8138").save
City.new(:country_id => "233", :name => "Sparks", :aliases => "Sparks,Ð¡Ð¿Ð°ÑÐºÑ,Sparks", :latitude => "39.53491", :longitude => "-119.75269").save
City.new(:country_id => "233", :name => "Spring Valley", :aliases => "Spring Valley,Spring-Vehlli,Ð¡Ð¿ÑÐ¸Ð½Ð³-ÐÑÐ»Ð»Ð¸,Spring Valley", :latitude => "36.10803", :longitude => "-115.245").save
City.new(:country_id => "233", :name => "Sun Valley", :aliases => ",Sun Valley", :latitude => "39.5963", :longitude => "-119.77602").save
City.new(:country_id => "233", :name => "Sunrise Manor", :aliases => "Sunrise Manor,Sunrise Manor", :latitude => "36.21108", :longitude => "-115.07306").save
City.new(:country_id => "233", :name => "Whitney", :aliases => "Uitni,Ð£Ð¸ÑÐ½Ð¸,Whitney", :latitude => "36.07081", :longitude => "-115.08416").save
City.new(:country_id => "233", :name => "Winchester", :aliases => ",Winchester", :latitude => "36.12997", :longitude => "-115.11889").save
City.new(:country_id => "233", :name => "Amarillo", :aliases => "Amarillo,amariro,ÐÐ¼Ð°ÑÐ¸Ð»Ð»Ð¾,ã¢ããªã­,Amarillo", :latitude => "35.222", :longitude => "-101.8313").save
City.new(:country_id => "233", :name => "Big Spring", :aliases => ",Big Spring", :latitude => "32.2504", :longitude => "-101.47874").save
City.new(:country_id => "233", :name => "Del Rio", :aliases => ",Del Rio", :latitude => "29.36273", :longitude => "-100.89676").save
City.new(:country_id => "233", :name => "Eagle Pass", :aliases => ",Eagle Pass", :latitude => "28.70914", :longitude => "-100.49952").save
City.new(:country_id => "233", :name => "El Paso", :aliases => "El Pasas,El Paso,ÐÐ» ÐÐ°ÑÐ¾,ã¨ã«ã»ãã½,El Paso", :latitude => "31.75872", :longitude => "-106.48693").save
City.new(:country_id => "233", :name => "Lubbock", :aliases => "Lubbock,rabokku,ã©ããã¯,Lubbock", :latitude => "33.57786", :longitude => "-101.85517").save
City.new(:country_id => "233", :name => "Midland", :aliases => "Midland,Midland", :latitude => "31.99735", :longitude => "-102.07791").save
City.new(:country_id => "233", :name => "Odessa", :aliases => "Odesa,Odessa,ÐÐ´ÐµÑÐ°,ÐÐ´ÐµÑÑÐ°,Odessa", :latitude => "31.84568", :longitude => "-102.36764").save
City.new(:country_id => "233", :name => "Pampa", :aliases => ",Pampa", :latitude => "35.53616", :longitude => "-100.95987").save
City.new(:country_id => "233", :name => "Plainview", :aliases => ",Plainview", :latitude => "34.18479", :longitude => "-101.70684").save
City.new(:country_id => "233", :name => "San Angelo", :aliases => "San Angelo,San Angelo", :latitude => "31.46377", :longitude => "-100.43704").save
City.new(:country_id => "233", :name => "San Elizario", :aliases => ",San Elizario", :latitude => "31.58511", :longitude => "-106.27276").save
City.new(:country_id => "233", :name => "Socorro", :aliases => "Sokorro,Ð¡Ð¾ÐºÐ¾ÑÑÐ¾,Socorro", :latitude => "31.65456", :longitude => "-106.30331").save
City.new(:country_id => "233", :name => "Socorro Mission Number 1 Colonia", :aliases => ",Socorro Mission Number 1 Colonia", :latitude => "31.63622", :longitude => "-106.29054").save
City.new(:country_id => "233", :name => "West Odessa", :aliases => ",West Odessa", :latitude => "31.84235", :longitude => "-102.49876").save
City.new(:country_id => "233", :name => "Cedar City", :aliases => ",Cedar City", :latitude => "37.67748", :longitude => "-113.06189").save
City.new(:country_id => "233", :name => "Saint George", :aliases => ",Saint George", :latitude => "37.10415", :longitude => "-113.58412").save
City.new(:country_id => "233", :name => "Wasco", :aliases => ",Wasco", :latitude => "35.59412", :longitude => "-119.34095").save
City.new(:country_id => "233", :name => "Apache Junction", :aliases => ",Apache Junction", :latitude => "33.41505", :longitude => "-111.54958").save
City.new(:country_id => "233", :name => "Avondale", :aliases => "Avondale,Ejvondejl,ÐÐ¹Ð²Ð¾Ð½Ð´ÐµÐ¹Ð»,Avondale", :latitude => "33.4356", :longitude => "-112.3496").save
City.new(:country_id => "233", :name => "Juneau", :aliases => "Dzhuno,Dzuno,DÅ¾Å«no,Iunellum,Juneau,Juneau City and Borough,juno,jwnyaw, alaska,zhu nuo,ÐÑÐ½Ð¾,ÐÐ¶ÑÐ½Ð¾,Ø¬ÙÙÛØ§Ø¤Ø Ø§ÙØ§Ø³Ú©Ø§,Ø¬ÙÙÛØ§âØ¤,ã¸ã¥ãã¼,æ±è«¾,Juneau", :latitude => "58.30194", :longitude => "-134.41972").save
City.new(:country_id => "233", :name => "Arcata", :aliases => ",Arcata", :latitude => "40.86652", :longitude => "-124.08284").save
City.new(:country_id => "233", :name => "Bayside", :aliases => ",Bayside", :latitude => "40.84235", :longitude => "-124.06367").save
City.new(:country_id => "233", :name => "Eureka", :aliases => "Ehvrika,Ð­Ð²ÑÐ¸ÐºÐ°,Eureka", :latitude => "40.80207", :longitude => "-124.16367").save
City.new(:country_id => "233", :name => "McKinleyville", :aliases => ",McKinleyville", :latitude => "40.94652", :longitude => "-124.10062").save
City.new(:country_id => "233", :name => "Redding", :aliases => "Redding,Redding", :latitude => "40.58654", :longitude => "-122.39168").save
City.new(:country_id => "233", :name => "Susanville", :aliases => ",Susanville", :latitude => "40.41628", :longitude => "-120.65301").save
City.new(:country_id => "233", :name => "Boulder", :aliases => "Boulder,bolde xr,boruda,ÐÐ¾ÑÐ»Ð´ÐµÑ,à¹à¸à¸¥à¹à¸à¸­à¸£à¹,ãã«ãã¼,Boulder", :latitude => "40.01499", :longitude => "-105.27055").save
City.new(:country_id => "233", :name => "Evans", :aliases => ",Evans", :latitude => "40.37637", :longitude => "-104.69219").save
City.new(:country_id => "233", :name => "Fort Collins", :aliases => "Fort Collins,ãã©ã¼ãã»ã³ãªã³ãº,Fort Collins", :latitude => "40.58526", :longitude => "-105.08442").save
City.new(:country_id => "233", :name => "Greeley", :aliases => "Greeley,Greeley", :latitude => "40.42331", :longitude => "-104.70913").save
City.new(:country_id => "233", :name => "Longmont", :aliases => "Longmont,Longmont", :latitude => "40.16721", :longitude => "-105.10193").save
City.new(:country_id => "233", :name => "Loveland", :aliases => ",Loveland", :latitude => "40.39776", :longitude => "-105.07498").save
City.new(:country_id => "233", :name => "Boise", :aliases => "Boise,BoisÄ,Boizis,Bojse,bo yi xi,boishi,bwyysy,ÐÐ¾Ð¹ÑÐµ,×××××¡×,ãã¤ã·,åä¼è¥¿,Boise", :latitude => "43.6135", :longitude => "-116.20345").save
City.new(:country_id => "233", :name => "Caldwell", :aliases => "Kolduehll,ÐÐ¾Ð»Ð´ÑÑÐ»Ð»,Caldwell", :latitude => "43.66294", :longitude => "-116.68736").save
City.new(:country_id => "233", :name => "Coeur d'Alene", :aliases => ",Coeur d'Alene", :latitude => "47.67768", :longitude => "-116.78047").save
City.new(:country_id => "233", :name => "Eagle", :aliases => ",Eagle", :latitude => "43.69544", :longitude => "-116.35401").save
City.new(:country_id => "233", :name => "Idaho Falls", :aliases => "Ajdakho-Fols,ÐÐ¹Ð´Ð°ÑÐ¾-Ð¤Ð¾Ð»Ñ,Idaho Falls", :latitude => "43.46658", :longitude => "-112.03414").save
City.new(:country_id => "233", :name => "Lewiston", :aliases => "L'juiston,ÐÑÑÐ¸ÑÑÐ¾Ð½,Lewiston", :latitude => "46.41655", :longitude => "-117.01766").save
City.new(:country_id => "233", :name => "Lewiston Orchards", :aliases => ",Lewiston Orchards", :latitude => "46.38044", :longitude => "-116.97543").save
City.new(:country_id => "233", :name => "Meridian", :aliases => "Meridian,ÐÐµÑÐ¸Ð´Ð¸Ð°Ð½,Meridian", :latitude => "43.61211", :longitude => "-116.39151").save
City.new(:country_id => "233", :name => "Moscow", :aliases => "Moskva,ÐÐ¾ÑÐºÐ²Ð°,Moscow", :latitude => "46.73239", :longitude => "-117.00017").save
City.new(:country_id => "233", :name => "Nampa", :aliases => "Nampa,Nampa", :latitude => "43.54072", :longitude => "-116.56346").save
City.new(:country_id => "233", :name => "Pocatello", :aliases => ",Pocatello", :latitude => "42.8713", :longitude => "-112.44553").save
City.new(:country_id => "233", :name => "Post Falls", :aliases => ",Post Falls", :latitude => "47.71796", :longitude => "-116.95159").save
City.new(:country_id => "233", :name => "Rexburg", :aliases => ",Rexburg", :latitude => "43.82602", :longitude => "-111.78969").save
City.new(:country_id => "233", :name => "Twin Falls", :aliases => ",Twin Falls", :latitude => "42.56297", :longitude => "-114.46087").save
City.new(:country_id => "233", :name => "Billings", :aliases => "Belinum,Billings,biringusu,ÐÐ¸Ð»Ð»Ð¸Ð½Ð³Ñ,ããªã³ã°ã¹,Billings", :latitude => "45.78329", :longitude => "-108.50069").save
City.new(:country_id => "233", :name => "Bozeman", :aliases => "Bozmana,ÐÐ¾Ð·Ð¼Ð°Ð½Ð°,Bozeman", :latitude => "45.67965", :longitude => "-111.03856").save
City.new(:country_id => "233", :name => "Butte", :aliases => ",Butte", :latitude => "46.00382", :longitude => "-112.53474").save
City.new(:country_id => "233", :name => "Great Falls", :aliases => ",Great Falls", :latitude => "47.50024", :longitude => "-111.30081").save
City.new(:country_id => "233", :name => "Helena", :aliases => "Helena,Helenopolis,Khelena,herena,hlnh,Ð¥ÐµÐ»ÐµÐ½Ð°,××× ×,ãã¬ã,Helena", :latitude => "46.59271", :longitude => "-112.03611").save
City.new(:country_id => "233", :name => "Kalispell", :aliases => ",Kalispell", :latitude => "48.19579", :longitude => "-114.31291").save
City.new(:country_id => "233", :name => "Missoula", :aliases => ",Missoula", :latitude => "46.87215", :longitude => "-113.994").save
City.new(:country_id => "233", :name => "Bismarck", :aliases => "Bismarck,Bismarck i Nord-Dakota,Bismark,Bizmark,bisumaku,bysmrq,ÐÐ¸Ð·Ð¼Ð°ÑÐº,ÐÐ¸ÑÐ¼Ð°ÑÐº,×××¡××¨×§,ãã¹ãã¼ã¯,Bismarck", :latitude => "46.80833", :longitude => "-100.78374").save
City.new(:country_id => "233", :name => "Dickinson", :aliases => ",Dickinson", :latitude => "46.87918", :longitude => "-102.78962").save
City.new(:country_id => "233", :name => "Mandan", :aliases => ",Mandan", :latitude => "46.82666", :longitude => "-100.88958").save
City.new(:country_id => "233", :name => "Minot", :aliases => "Mina,ÐÐ¸Ð½Ð°,Minot", :latitude => "48.23251", :longitude => "-101.29627").save
City.new(:country_id => "233", :name => "North Platte", :aliases => ",North Platte", :latitude => "41.12389", :longitude => "-100.76542").save
City.new(:country_id => "233", :name => "Elko", :aliases => ",Elko", :latitude => "40.83242", :longitude => "-115.76312").save
City.new(:country_id => "233", :name => "Albany", :aliases => "Olbani,ÐÐ»Ð±Ð°Ð½Ð¸,Albany", :latitude => "44.63651", :longitude => "-123.10593").save
City.new(:country_id => "233", :name => "Aloha", :aliases => ",Aloha", :latitude => "45.49428", :longitude => "-122.86705").save
City.new(:country_id => "233", :name => "Altamont", :aliases => ",Altamont", :latitude => "42.20681", :longitude => "-121.73722").save
City.new(:country_id => "233", :name => "Ashland", :aliases => ",Ashland", :latitude => "42.19458", :longitude => "-122.70948").save
City.new(:country_id => "233", :name => "Beaverton", :aliases => "Beaverton,Beaverton", :latitude => "45.48706", :longitude => "-122.80371").save
City.new(:country_id => "233", :name => "Bend", :aliases => "Bend,ÐÐµÐ½Ð´,Bend", :latitude => "44.05817", :longitude => "-121.31531").save
City.new(:country_id => "233", :name => "Canby", :aliases => ",Canby", :latitude => "45.2629", :longitude => "-122.69259").save
City.new(:country_id => "233", :name => "Central Point", :aliases => ",Central Point", :latitude => "42.37596", :longitude => "-122.91643").save
City.new(:country_id => "233", :name => "Coos Bay", :aliases => ",Coos Bay", :latitude => "43.3665", :longitude => "-124.21789").save
City.new(:country_id => "233", :name => "Corvallis", :aliases => "Corvallis,Korvalis,ke wa li si,kobarisu,ÐÐ¾ÑÐ²Ð°Ð»Ð¸Ñ,ã³ã¼ããªã¹,ç§ç¦å©æ¯,Corvallis", :latitude => "44.56457", :longitude => "-123.26204").save
City.new(:country_id => "233", :name => "Eugene", :aliases => "Eugene,Judzhin,yujin,Ð®Ð´Ð¶Ð¸Ð½,ã¦ã¼ã¸ã³,ã¦ã¼ã¸ã¼ã³,Eugene", :latitude => "44.05207", :longitude => "-123.08675").save
City.new(:country_id => "233", :name => "Forest Grove", :aliases => ",Forest Grove", :latitude => "45.51984", :longitude => "-123.11066").save
City.new(:country_id => "233", :name => "Grants Pass", :aliases => ",Grants Pass", :latitude => "42.43901", :longitude => "-123.32839").save
City.new(:country_id => "233", :name => "Gresham", :aliases => "Gresham,Gresham", :latitude => "45.49818", :longitude => "-122.43148").save
City.new(:country_id => "233", :name => "Hayesville", :aliases => ",Hayesville", :latitude => "44.98595", :longitude => "-122.98287").save
City.new(:country_id => "233", :name => "Hillsboro", :aliases => "Hillsboro,Khillsboro,Ð¥Ð¸Ð»Ð»ÑÐ±Ð¾ÑÐ¾,Hillsboro", :latitude => "45.52289", :longitude => "-122.98983").save
City.new(:country_id => "233", :name => "Keizer", :aliases => "Kejzer,ÐÐµÐ¹Ð·ÐµÑ,Keizer", :latitude => "44.99012", :longitude => "-123.02621").save
City.new(:country_id => "233", :name => "Klamath Falls", :aliases => ",Klamath Falls", :latitude => "42.22487", :longitude => "-121.78167").save
City.new(:country_id => "233", :name => "Lake Oswego", :aliases => ",Lake Oswego", :latitude => "45.42067", :longitude => "-122.67065").save
City.new(:country_id => "233", :name => "McMinnville", :aliases => ",McMinnville", :latitude => "45.21012", :longitude => "-123.19872").save
City.new(:country_id => "233", :name => "Medford", :aliases => "Medford,ÐÐµÐ´ÑÐ¾ÑÐ´,Medford", :latitude => "42.32652", :longitude => "-122.87559").save
City.new(:country_id => "233", :name => "Milwaukie", :aliases => "Miluoki,ÐÐ¸Ð»ÑÐ¾ÐºÐ¸,Milwaukie", :latitude => "45.44623", :longitude => "-122.63926").save
City.new(:country_id => "233", :name => "Newberg", :aliases => "N'juberg,ÐÑÑÐ±ÐµÑÐ³,Newberg", :latitude => "45.30012", :longitude => "-122.97316").save
City.new(:country_id => "233", :name => "Oregon City", :aliases => ",Oregon City", :latitude => "45.35734", :longitude => "-122.60676").save
City.new(:country_id => "233", :name => "Pendleton", :aliases => ",Pendleton", :latitude => "45.67208", :longitude => "-118.7886").save
City.new(:country_id => "233", :name => "Portland", :aliases => "Portland,Portland i Oregon,Portlandia,Portlend,bo te lan,poteullaendeu,potorando,pwrtlnd,ÐÐ¾ÑÑÐ»Ð°Ð½Ð´,ÐÐ¾ÑÑÐ»ÐµÐ½Ð´,×¤××¨××× ×,ãã¼ãã©ã³ã,æ³¢ç¹è­,í¬íëë,Portland", :latitude => "45.52345", :longitude => "-122.67621").save
City.new(:country_id => "233", :name => "Redmond", :aliases => "Redmond,Ð ÐµÐ´Ð¼Ð¾Ð½Ð´,Redmond", :latitude => "44.27262", :longitude => "-121.17392").save
City.new(:country_id => "233", :name => "Roseburg", :aliases => ",Roseburg", :latitude => "43.2165", :longitude => "-123.34174").save
City.new(:country_id => "233", :name => "Salem", :aliases => "Salem,seiramu,Ð¡Ð°Ð»ÐµÐ¼,×¡×××,ã»ã¤ã©ã ,Salem", :latitude => "44.9429", :longitude => "-123.0351").save
City.new(:country_id => "233", :name => "Sherwood", :aliases => ",Sherwood", :latitude => "45.35651", :longitude => "-122.8401").save
City.new(:country_id => "233", :name => "Springfield", :aliases => "Springfild,Ð¡Ð¿ÑÐ¸Ð½Ð³ÑÐ¸Ð»Ð´,Springfield", :latitude => "44.04624", :longitude => "-123.02203").save
City.new(:country_id => "233", :name => "Tigard", :aliases => ",Tigard", :latitude => "45.43123", :longitude => "-122.77149").save
City.new(:country_id => "233", :name => "Troutdale", :aliases => ",Troutdale", :latitude => "45.53929", :longitude => "-122.38731").save
City.new(:country_id => "233", :name => "Tualatin", :aliases => ",Tualatin", :latitude => "45.38401", :longitude => "-122.76399").save
City.new(:country_id => "233", :name => "West Linn", :aliases => ",West Linn", :latitude => "45.36568", :longitude => "-122.61231").save
City.new(:country_id => "233", :name => "Wilsonville", :aliases => ",Wilsonville", :latitude => "45.29984", :longitude => "-122.77371").save
City.new(:country_id => "233", :name => "Woodburn", :aliases => ",Woodburn", :latitude => "45.14373", :longitude => "-122.85537").save
City.new(:country_id => "233", :name => "Rapid City", :aliases => "Rapid-Siti,Ð Ð°Ð¿Ð¸Ð´-Ð¡Ð¸ÑÐ¸,Rapid City", :latitude => "44.08054", :longitude => "-103.23101").save
City.new(:country_id => "233", :name => "Bountiful", :aliases => ",Bountiful", :latitude => "40.88939", :longitude => "-111.88077").save
City.new(:country_id => "233", :name => "Brigham City", :aliases => ",Brigham City", :latitude => "41.51021", :longitude => "-112.0155").save
City.new(:country_id => "233", :name => "Clearfield", :aliases => ",Clearfield", :latitude => "41.11078", :longitude => "-112.02605").save
City.new(:country_id => "233", :name => "Clinton", :aliases => "Klinton,ÐÐ»Ð¸Ð½ÑÐ¾Ð½,Clinton", :latitude => "41.13967", :longitude => "-112.0505").save
City.new(:country_id => "233", :name => "Cottonwood Heights", :aliases => ",Cottonwood Heights", :latitude => "40.61967", :longitude => "-111.81021").save
City.new(:country_id => "233", :name => "Draper", :aliases => ",Draper", :latitude => "40.52467", :longitude => "-111.86382").save
City.new(:country_id => "233", :name => "East Millcreek", :aliases => ",East Millcreek", :latitude => "40.69995", :longitude => "-111.81049").save
City.new(:country_id => "233", :name => "Holladay", :aliases => ",Holladay", :latitude => "40.66884", :longitude => "-111.82466").save
City.new(:country_id => "233", :name => "Kaysville", :aliases => ",Kaysville", :latitude => "41.03522", :longitude => "-111.93855").save
City.new(:country_id => "233", :name => "Kearns", :aliases => "Kerns,ÐÐµÑÐ½Ñ,Kearns", :latitude => "40.65995", :longitude => "-111.99633").save
City.new(:country_id => "233", :name => "Layton", :aliases => "Layton,Lejton,ÐÐµÐ¹ÑÐ¾Ð½,Layton", :latitude => "41.06022", :longitude => "-111.97105").save
City.new(:country_id => "233", :name => "Lehi", :aliases => "Lekhe,ÐÐµÑÐµ,Lehi", :latitude => "40.39162", :longitude => "-111.85077").save
City.new(:country_id => "233", :name => "Logan", :aliases => ",Logan", :latitude => "41.73549", :longitude => "-111.83439").save
City.new(:country_id => "233", :name => "Magna", :aliases => ",Magna", :latitude => "40.70911", :longitude => "-112.10161").save
City.new(:country_id => "233", :name => "Midvale", :aliases => ",Midvale", :latitude => "40.61106", :longitude => "-111.89994").save
City.new(:country_id => "233", :name => "Millcreek", :aliases => ",Millcreek", :latitude => "40.68689", :longitude => "-111.87549").save
City.new(:country_id => "233", :name => "Murray", :aliases => "Mjurrej,ÐÑÑÑÐµÐ¹,Murray", :latitude => "40.66689", :longitude => "-111.88799").save
City.new(:country_id => "233", :name => "North Ogden", :aliases => ",North Ogden", :latitude => "41.30716", :longitude => "-111.96022").save
City.new(:country_id => "233", :name => "Ogden", :aliases => "Ogden,ÐÐ³Ð´ÐµÐ½,Ogden", :latitude => "41.223", :longitude => "-111.97383").save
City.new(:country_id => "233", :name => "Orem", :aliases => "Orem,Orem", :latitude => "40.2969", :longitude => "-111.69465").save
City.new(:country_id => "233", :name => "Payson", :aliases => ",Payson", :latitude => "40.0444", :longitude => "-111.73215").save
City.new(:country_id => "233", :name => "Pleasant Grove", :aliases => ",Pleasant Grove", :latitude => "40.36412", :longitude => "-111.73854").save
City.new(:country_id => "233", :name => "Provo", :aliases => "Provo,pu ruo fu,purobo,ÐÑÐ¾Ð²Ð¾,ãã­ã,æ®è¥ä½,Provo", :latitude => "40.23384", :longitude => "-111.65853").save
City.new(:country_id => "233", :name => "Riverton", :aliases => "Riverton,Ð Ð¸Ð²ÐµÑÑÐ¾Ð½,Riverton", :latitude => "40.52189", :longitude => "-111.9391").save
City.new(:country_id => "233", :name => "Roy", :aliases => "Roj,Ð Ð¾Ð¹,Roy", :latitude => "41.16161", :longitude => "-112.02633").save
City.new(:country_id => "233", :name => "Salt Lake City", :aliases => "Sallagurbo,Salt Lake City,Solt Leik Sitis,Solt Lejk Siti,Solt-Lejk-Siti,solteuleikeu si,sorutoreikushiti,swlt lyyq syty,yan hu cheng,Ð¡Ð¾Ð»Ñ ÐÐµÐ¹Ðº Ð¡Ð¸ÑÐ¸,Ð¡Ð¾Ð»Ñ ÐÐµÑÐº Ð¡Ð¸ÑÐ¸,Ð¡Ð¾Ð»Ñ-ÐÐµÐ¹Ðº-Ð¡Ð¸ÑÐ¸,×¡××× ××××§ ×¡×××,Ø³Ø§ÙÙ¹ ÙÛÚ© Ø³Ù¹ÛØ ÛÙÙ¹Ø§Û,ã½ã«ãã¬ã¤ã¯ã·ãã£,çæ¹å,ìí¸ë ì´í¬ ì,Salt Lake City", :latitude => "40.76078", :longitude => "-111.89105").save
City.new(:country_id => "233", :name => "Sandy City", :aliases => ",Sandy City", :latitude => "40.57204", :longitude => "-111.86056").save
City.new(:country_id => "233", :name => "Sandy Hills", :aliases => ",Sandy Hills", :latitude => "40.58106", :longitude => "-111.85077").save
City.new(:country_id => "233", :name => "South Jordan Heights", :aliases => ",South Jordan Heights", :latitude => "40.56384", :longitude => "-111.94938").save
City.new(:country_id => "233", :name => "South Jordan", :aliases => ",South Jordan", :latitude => "40.56217", :longitude => "-111.92966").save
City.new(:country_id => "233", :name => "South Ogden", :aliases => ",South Ogden", :latitude => "41.19189", :longitude => "-111.97133").save
City.new(:country_id => "233", :name => "South Salt Lake", :aliases => ",South Salt Lake", :latitude => "40.71884", :longitude => "-111.88827").save
City.new(:country_id => "233", :name => "Spanish Fork", :aliases => ",Spanish Fork", :latitude => "40.11496", :longitude => "-111.65492").save
City.new(:country_id => "233", :name => "Springville", :aliases => ",Springville", :latitude => "40.16523", :longitude => "-111.61075").save
City.new(:country_id => "233", :name => "Syracuse", :aliases => ",Syracuse", :latitude => "41.08939", :longitude => "-112.06467").save
City.new(:country_id => "233", :name => "Taylorsville", :aliases => ",Taylorsville", :latitude => "40.66772", :longitude => "-111.93883").save
City.new(:country_id => "233", :name => "Tooele", :aliases => ",Tooele", :latitude => "40.53078", :longitude => "-112.29828").save
City.new(:country_id => "233", :name => "West Jordan", :aliases => "West Jordan,West Jordan", :latitude => "40.60967", :longitude => "-111.9391").save
City.new(:country_id => "233", :name => "West Valley City", :aliases => "West Valley,West Valley City,West Valley City", :latitude => "40.69161", :longitude => "-112.00105").save
City.new(:country_id => "233", :name => "Aberdeen", :aliases => "Aberdeen,Aburdijn,ÐÐ±ÑÑÐ´Ð¸Ð¹Ð½,×××¨×××,Aberdeen", :latitude => "46.97537", :longitude => "-123.81572").save
City.new(:country_id => "233", :name => "Alderwood Manor", :aliases => ",Alderwood Manor", :latitude => "47.82204", :longitude => "-122.28207").save
City.new(:country_id => "233", :name => "Anacortes", :aliases => ",Anacortes", :latitude => "48.5126", :longitude => "-122.61267").save
City.new(:country_id => "233", :name => "Arlington", :aliases => "Arlington,ÐÑÐ»Ð¸Ð½Ð³ÑÐ¾Ð½,Arlington", :latitude => "48.19871", :longitude => "-122.12514").save
City.new(:country_id => "233", :name => "Auburn", :aliases => ",Auburn", :latitude => "47.30732", :longitude => "-122.22845").save
City.new(:country_id => "233", :name => "Battle Ground", :aliases => ",Battle Ground", :latitude => "45.78095", :longitude => "-122.53343").save
City.new(:country_id => "233", :name => "Bellevue", :aliases => "Bellevue,Bellevue", :latitude => "47.61038", :longitude => "-122.20068").save
City.new(:country_id => "233", :name => "Bellingham", :aliases => "Bellingham,Bellingham", :latitude => "48.75955", :longitude => "-122.48822").save
City.new(:country_id => "233", :name => "Bothell", :aliases => ",Bothell", :latitude => "47.76232", :longitude => "-122.2054").save
City.new(:country_id => "233", :name => "Bremerton", :aliases => "Bremerton,ÐÑÐµÐ¼ÐµÑÑÐ¾Ð½,Bremerton", :latitude => "47.56732", :longitude => "-122.63264").save
City.new(:country_id => "233", :name => "Burien", :aliases => ",Burien", :latitude => "47.47038", :longitude => "-122.34679").save
City.new(:country_id => "233", :name => "Camas", :aliases => ",Camas", :latitude => "45.58706", :longitude => "-122.39954").save
City.new(:country_id => "233", :name => "Centralia", :aliases => ",Centralia", :latitude => "46.71621", :longitude => "-122.9543").save
City.new(:country_id => "233", :name => "Cottage Lake", :aliases => ",Cottage Lake", :latitude => "47.74427", :longitude => "-122.07735").save
City.new(:country_id => "233", :name => "Covington", :aliases => ",Covington", :latitude => "47.35818", :longitude => "-122.12216").save
City.new(:country_id => "233", :name => "Des Moines", :aliases => "De-Mojn,DesMoines,ÐÐµ-ÐÐ¾Ð¹Ð½,Des Moines", :latitude => "47.40177", :longitude => "-122.32429").save
City.new(:country_id => "233", :name => "Edmonds", :aliases => "Ehdmonds,Ð­Ð´Ð¼Ð¾Ð½Ð´Ñ,Edmonds", :latitude => "47.81065", :longitude => "-122.37736").save
City.new(:country_id => "233", :name => "Elk Plain", :aliases => ",Elk Plain", :latitude => "47.05316", :longitude => "-122.39762").save
City.new(:country_id => "233", :name => "Ellensburg", :aliases => ",Ellensburg", :latitude => "46.99651", :longitude => "-120.54785").save
City.new(:country_id => "233", :name => "Everett", :aliases => "Ehverett,Everett,Ð­Ð²ÐµÑÐµÑÑ,Everett", :latitude => "47.97898", :longitude => "-122.20208").save
City.new(:country_id => "233", :name => "Federal Way", :aliases => "Federal Way,Federal Way", :latitude => "47.32232", :longitude => "-122.31262").save
City.new(:country_id => "233", :name => "Issaquah", :aliases => ",Issaquah", :latitude => "47.5301", :longitude => "-122.03262").save
City.new(:country_id => "233", :name => "Kenmore", :aliases => ",Kenmore", :latitude => "47.75732", :longitude => "-122.24401").save
City.new(:country_id => "233", :name => "Kennewick", :aliases => "Kennewick,Kennewick", :latitude => "46.21125", :longitude => "-119.13723").save
City.new(:country_id => "233", :name => "Kent", :aliases => "98032,Kent,ÐÐµÐ½Ñ,Kent", :latitude => "47.38093", :longitude => "-122.23484").save
City.new(:country_id => "233", :name => "Kirkland", :aliases => ",Kirkland", :latitude => "47.68149", :longitude => "-122.20874").save
City.new(:country_id => "233", :name => "Lacey", :aliases => "Lejsi,ÐÐµÐ¹ÑÐ¸,Lacey", :latitude => "47.03426", :longitude => "-122.82319").save
City.new(:country_id => "233", :name => "Lakewood", :aliases => "Lejkvud,ÐÐµÐ¹ÐºÐ²ÑÐ´,Lakewood", :latitude => "47.17176", :longitude => "-122.51846").save
City.new(:country_id => "233", :name => "Longview", :aliases => ",Longview", :latitude => "46.13817", :longitude => "-122.93817").save
City.new(:country_id => "233", :name => "Lynnwood", :aliases => "Linvud,ÐÐ¸Ð½Ð²ÑÐ´,Lynnwood", :latitude => "47.82093", :longitude => "-122.31513").save
City.new(:country_id => "233", :name => "Marysville", :aliases => ",Marysville", :latitude => "48.05176", :longitude => "-122.17708").save
City.new(:country_id => "233", :name => "Mercer Island", :aliases => ",Mercer Island", :latitude => "47.57065", :longitude => "-122.22207").save
City.new(:country_id => "233", :name => "Monroe", :aliases => "Monro,ÐÐ¾Ð½ÑÐ¾,Monroe", :latitude => "47.85538", :longitude => "-121.97096").save
City.new(:country_id => "233", :name => "Moses Lake", :aliases => ",Moses Lake", :latitude => "47.13014", :longitude => "-119.27808").save
City.new(:country_id => "233", :name => "Mount Vernon", :aliases => ",Mount Vernon", :latitude => "48.42122", :longitude => "-122.33405").save
City.new(:country_id => "233", :name => "Mountlake Terrace", :aliases => ",Mountlake Terrace", :latitude => "47.78815", :longitude => "-122.30874").save
City.new(:country_id => "233", :name => "Mukilteo", :aliases => ",Mukilteo", :latitude => "47.94454", :longitude => "-122.30458").save
City.new(:country_id => "233", :name => "North Creek", :aliases => ",North Creek", :latitude => "47.81954", :longitude => "-122.17624").save
City.new(:country_id => "233", :name => "North Marysville", :aliases => ",North Marysville", :latitude => "48.09926", :longitude => "-122.14875").save
City.new(:country_id => "233", :name => "Oak Harbor", :aliases => ",Oak Harbor", :latitude => "48.29316", :longitude => "-122.64322").save
City.new(:country_id => "233", :name => "Olympia", :aliases => "Olimpija,Olympia,ao lin pi ya,orinpia,ÐÐ»Ð¸Ð¼Ð¿Ð¸Ñ,Ø§ÙÙÙÙ¾ÛØ§Ø ÙØ§Ø´ÙÚ¯Ù¹Ù,ãªãªã³ãã¢,å¥§æå¹äº,Olympia", :latitude => "47.03787", :longitude => "-122.9007").save
City.new(:country_id => "233", :name => "Opportunity", :aliases => ",Opportunity", :latitude => "47.65739", :longitude => "-117.23993").save
City.new(:country_id => "233", :name => "Orchards", :aliases => ",Orchards", :latitude => "45.66651", :longitude => "-122.56093").save
City.new(:country_id => "233", :name => "Parkland", :aliases => ",Parkland", :latitude => "47.15538", :longitude => "-122.43401").save
City.new(:country_id => "233", :name => "Pasco", :aliases => "Pasko,ÐÐ°ÑÐºÐ¾,Pasco", :latitude => "46.23958", :longitude => "-119.10057").save
City.new(:country_id => "233", :name => "Port Angeles", :aliases => ",Port Angeles", :latitude => "48.11815", :longitude => "-123.43074").save
City.new(:country_id => "233", :name => "Pullman", :aliases => ",Pullman", :latitude => "46.73127", :longitude => "-117.17962").save
City.new(:country_id => "233", :name => "Puyallup", :aliases => ",Puyallup", :latitude => "47.18538", :longitude => "-122.2929").save
City.new(:country_id => "233", :name => "Redmond", :aliases => "Redmond,lei de meng de,redomondo,Ð ÐµÐ´Ð¼Ð¾Ð½Ð´,ã¬ãã¢ã³ã,é·å¾·èå¾·,Redmond", :latitude => "47.67399", :longitude => "-122.12151").save
City.new(:country_id => "233", :name => "Renton", :aliases => ",Renton", :latitude => "47.48288", :longitude => "-122.21707").save
City.new(:country_id => "233", :name => "Richland", :aliases => "Richlend,Ð Ð¸ÑÐ»ÐµÐ½Ð´,Richland", :latitude => "46.28569", :longitude => "-119.28446").save
City.new(:country_id => "233", :name => "Salmon Creek", :aliases => ",Salmon Creek", :latitude => "45.71067", :longitude => "-122.64899").save
City.new(:country_id => "233", :name => "Sammamish", :aliases => ",Sammamish", :latitude => "47.64177", :longitude => "-122.0804").save
City.new(:country_id => "233", :name => "SeaTac", :aliases => ",SeaTac", :latitude => "47.44846", :longitude => "-122.29217").save
City.new(:country_id => "233", :name => "Seattle", :aliases => "Seattle,Seattlum,Siatul,Siehtl,Sietlas,Sijetl,shiatoru,si'aitala,siaeteul,syatl,xi ya tu,Ð¡Ð¸Ð°ÑÑÐ»,Ð¡Ð¸ÑÑÐ»,Ð¡Ð¸ÑÐµÑÐ»,×¡××××,×¡××¢××,Ø³ÙØ§ØªÙ,Ø³ÛØ§ØªÙ,à¤¸à¥à¤à¤à¤²,ã·ã¢ãã«,è¥¿éå,ìì í,Seattle", :latitude => "47.60621", :longitude => "-122.33207").save
City.new(:country_id => "233", :name => "Shoreline", :aliases => ",Shoreline", :latitude => "47.75565", :longitude => "-122.34152").save
City.new(:country_id => "233", :name => "Silverdale", :aliases => ",Silverdale", :latitude => "47.64454", :longitude => "-122.69487").save
City.new(:country_id => "233", :name => "South Hill", :aliases => ",South Hill", :latitude => "47.14121", :longitude => "-122.27012").save
City.new(:country_id => "233", :name => "Spanaway", :aliases => ",Spanaway", :latitude => "47.10399", :longitude => "-122.43457").save
City.new(:country_id => "233", :name => "Spokane", :aliases => "Spokane,supoken,ã¹ãã±ã¼ã³,ã¹ãã¼ã±ã³,Spokane", :latitude => "47.65878", :longitude => "-117.42605").save
City.new(:country_id => "233", :name => "Tacoma", :aliases => "Tacoma,takoma,ã¿ã³ã,Tacoma", :latitude => "47.25288", :longitude => "-122.44429").save
City.new(:country_id => "233", :name => "Tukwila", :aliases => ",Tukwila", :latitude => "47.47399", :longitude => "-122.26096").save
City.new(:country_id => "233", :name => "University Place", :aliases => ",University Place", :latitude => "47.23565", :longitude => "-122.5504").save
City.new(:country_id => "233", :name => "Vancouver", :aliases => "Predloga:Zascitenovand,Predloga:ZaÅ¡Äitenovand,Template:Vandalism,Vancouver,Vankuver,ÐÐ°Ð½ÐºÑÐ²ÐµÑ,Vancouver", :latitude => "45.63873", :longitude => "-122.66149").save
City.new(:country_id => "233", :name => "Walla Walla", :aliases => ",Walla Walla", :latitude => "46.06458", :longitude => "-118.34302").save
City.new(:country_id => "233", :name => "Wenatchee", :aliases => ",Wenatchee", :latitude => "47.42346", :longitude => "-120.31035").save
City.new(:country_id => "233", :name => "West Lake Sammamish", :aliases => ",West Lake Sammamish", :latitude => "47.5776", :longitude => "-122.10123").save
City.new(:country_id => "233", :name => "West Lake Stevens", :aliases => ",West Lake Stevens", :latitude => "47.99343", :longitude => "-122.1018").save
City.new(:country_id => "233", :name => "White Center", :aliases => ",White Center", :latitude => "47.51732", :longitude => "-122.35485").save
City.new(:country_id => "233", :name => "Yakima", :aliases => "Jakima,Yakima,Ð¯ÐºÐ¸Ð¼Ð°,Yakima", :latitude => "46.60207", :longitude => "-120.5059").save
City.new(:country_id => "233", :name => "Casper", :aliases => "Kasper,ÐÐ°ÑÐ¿ÐµÑ,Casper", :latitude => "42.86663", :longitude => "-106.31308").save
City.new(:country_id => "233", :name => "Cheyenne", :aliases => "Cheyenna,Cheyenne,Shajenn,shaian,shayan,xia yan,Ð¨Ð°Ð¹ÐµÐ½Ð½,Ø´Ø§ÙØ§Ù,ã·ã£ã¤ã¢ã³,å¤å»¶,Cheyenne", :latitude => "41.13998", :longitude => "-104.82025").save
City.new(:country_id => "233", :name => "Gillette", :aliases => ",Gillette", :latitude => "44.29109", :longitude => "-105.50222").save
City.new(:country_id => "233", :name => "Laramie", :aliases => "Larami,ÐÐ°ÑÐ°Ð¼Ð¸,Laramie", :latitude => "41.31137", :longitude => "-105.5911").save
City.new(:country_id => "233", :name => "Rock Springs", :aliases => ",Rock Springs", :latitude => "41.58746", :longitude => "-109.2029").save
City.new(:country_id => "233", :name => "Sheridan", :aliases => ",Sheridan", :latitude => "44.79719", :longitude => "-106.95618").save
City.new(:country_id => "233", :name => "American Fork", :aliases => ",American Fork", :latitude => "40.3769", :longitude => "-111.79576").save
City.new(:country_id => "233", :name => "Kahului", :aliases => ",Kahului", :latitude => "20.89472", :longitude => "-156.47").save
City.new(:country_id => "233", :name => "Kailua", :aliases => ",Kailua", :latitude => "21.40222", :longitude => "-157.73944").save
City.new(:country_id => "233", :name => "Kane'ohe", :aliases => "Kane'ohe,Kaneohe,KÄneâohe,KÄneâohe", :latitude => "21.41806", :longitude => "-157.80361").save
City.new(:country_id => "233", :name => "Kihei", :aliases => ",KÄ«hei", :latitude => "20.785", :longitude => "-156.46556").save
City.new(:country_id => "233", :name => "Makakilo City", :aliases => ",Makakilo City", :latitude => "21.34694", :longitude => "-158.08583").save
City.new(:country_id => "233", :name => "Mililani Town", :aliases => "Mililani,Mililani Town", :latitude => "21.45", :longitude => "-158.00111").save
City.new(:country_id => "233", :name => "Pearl City", :aliases => ",Pearl City", :latitude => "21.39722", :longitude => "-157.97333").save
City.new(:country_id => "233", :name => "Wahiawa", :aliases => ",WahiawÄ", :latitude => "21.50278", :longitude => "-158.02361").save
City.new(:country_id => "233", :name => "Waimalu", :aliases => ",Waimalu", :latitude => "21.40472", :longitude => "-157.94333").save
City.new(:country_id => "233", :name => "Waipahu", :aliases => ",Waipahu", :latitude => "21.38667", :longitude => "-158.00917").save
City.new(:country_id => "233", :name => "'Ewa Beach", :aliases => "'Ewa Beach,Ewa Beach,âEwa Beach,âEwa Beach", :latitude => "21.31556", :longitude => "-158.00722").save
City.new(:country_id => "233", :name => "Hilo", :aliases => "Baie de Hilo,Hilo,Khilo,hiro,Ð¥Ð¸Ð»Ð¾,ãã­,Hilo", :latitude => "19.72972", :longitude => "-155.09").save
City.new(:country_id => "233", :name => "Honolulu", :aliases => "Gonolulu,Honolulu,HonolulÃº,Khonolulu,honollullu,honoruru,hwnwlwlw,tan xiang shan,ÐÐ¾Ð½Ð¾Ð»ÑÐ»Ñ,Ð¥Ð¾Ð½Ð¾Ð»ÑÐ»Ñ,××× ×××××,ÙÙÙÙÙÙÙÙ,ããã«ã«,æªé¦å±±,í¸ëë£°ë£¨,Honolulu", :latitude => "21.30694", :longitude => "-157.85833").save
City.new(:country_id => "233", :name => "Fairbanks", :aliases => "Fairbanks,Fehrbenks,feabankusu,peeobaengkeuseu,Ð¤ÑÑÐ±ÐµÐ½ÐºÑ,ãã§ã¢ãã³ã¯ã¹,íì´ë±í¬ì¤,Fairbanks", :latitude => "64.83778", :longitude => "-147.71639").save
City.new(:country_id => "233", :name => "Anchorage", :aliases => "Anchorage,Ankoridz,Ankoridzas,Ankoridzh,AnkoridÅ¾as,aengkeoliji,an ke la zhi,ancorage byuro,ankarejji,ÐÐ½ÐºÐ¾ÑÐ¸Ð´Ð¶,ÐÐ½ÐºÐ¾ÑÑÐ´Ð¶,à¦à¦¨à§à¦à§à¦°à¦à§ à¦¬à§à¦¯à§à¦°à§,ã¢ã³ã«ã¬ãã¸,å®åææ²»,ìµì»¤ë¦¬ì§,Anchorage", :latitude => "61.21806", :longitude => "-149.90028").save
City.new(:country_id => "233", :name => "Fort Bragg", :aliases => ",Fort Bragg", :latitude => "35.139", :longitude => "-79.00603").save
City.new(:country_id => "233", :name => "BloomingtonMn", :aliases => ",BloomingtonMn", :latitude => "44.84096", :longitude => "-93.29843").save
