City.new(:country_id => "107", :name => "Punch", :aliases => "Poonch,Punch,PÅ«nch,PÅ«nch", :latitude => "33.76788", :longitude => "74.08974").save
City.new(:country_id => "107", :name => "Kilakarai", :aliases => "Kilakarai,Kilakari,KÄ«lakarai,KÄ«lakarai", :latitude => "9.23333", :longitude => "78.78333").save
City.new(:country_id => "107", :name => "Zunheboto", :aliases => "Zunheboto,Zunheboto", :latitude => "25.96667", :longitude => "94.51667").save
City.new(:country_id => "107", :name => "Zamania", :aliases => "Zamania,Zaminia,ZamÄnia,ZamÄnia", :latitude => "25.43333", :longitude => "83.56667").save
City.new(:country_id => "107", :name => "Zaidpur", :aliases => ",Zaidpur", :latitude => "26.83333", :longitude => "81.33333").save
City.new(:country_id => "107", :name => "Zahirabad", :aliases => "Zahirabad,ZahirÄbÄd,ZahirÄbÄd", :latitude => "17.68333", :longitude => "77.61667").save
City.new(:country_id => "107", :name => "Yeola", :aliases => "Yeola,Yevale,Yewle,Yeola", :latitude => "20.03333", :longitude => "74.48333").save
City.new(:country_id => "107", :name => "Yellapur", :aliases => ",YellÄpur", :latitude => "14.96667", :longitude => "74.71667").save
City.new(:country_id => "107", :name => "Yellandu", :aliases => "Yellandlapad,YellandlapÄd,Yellandrapad,Yellandu,Yellandu", :latitude => "17.6", :longitude => "80.33333").save
City.new(:country_id => "107", :name => "Yelahanka", :aliases => "Yelahanka,Yelahanka", :latitude => "13.1075", :longitude => "77.60028").save
City.new(:country_id => "107", :name => "Yavatmal", :aliases => "Yavatmal,YavatmÄl,Yeotmal,YeotmÄl,YavatmÄl", :latitude => "20.4", :longitude => "78.13333").save
City.new(:country_id => "107", :name => "Yaval", :aliases => ",YÄval", :latitude => "21.16667", :longitude => "75.7").save
City.new(:country_id => "107", :name => "Yanam", :aliases => "Janam,Yanam,Yanaon,Ð¯Ð½Ð°Ð¼,Yanam", :latitude => "16.73333", :longitude => "82.21667").save
City.new(:country_id => "107", :name => "Yamunanagar", :aliases => "Abdullahpur,Abdullapur,AbdullÄhpur,Jamna Nagar,Yamunanagar,YamunÄnagar,YamunÄnagar", :latitude => "30.1", :longitude => "77.28333").save
City.new(:country_id => "107", :name => "Yadgir", :aliases => "Yadgir,YÄdgÄ«r,YÄdgÄ«r", :latitude => "16.76667", :longitude => "77.13333").save
City.new(:country_id => "107", :name => "Wokha", :aliases => "Wokha,Wokha", :latitude => "26.1", :longitude => "94.26667").save
City.new(:country_id => "107", :name => "Wer", :aliases => ",Wer", :latitude => "27", :longitude => "77.16667").save
City.new(:country_id => "107", :name => "Wellington", :aliases => "Vellington,Wellington,Wellington Town,ÐÐµÐ»Ð»Ð¸Ð½Ð³ÑÐ¾Ð½,Wellington", :latitude => "11.36667", :longitude => "76.8").save
City.new(:country_id => "107", :name => "Wazirganj", :aliases => "Wazirganj,WazÄ«rganj,WazÄ«rganj", :latitude => "28.21667", :longitude => "79.05").save
City.new(:country_id => "107", :name => "Washim", :aliases => "Basim,BÄsim,Washim,WÄshÄ«m,WÄshÄ«m", :latitude => "20.1", :longitude => "77.15").save
City.new(:country_id => "107", :name => "Warud", :aliases => "Warud,Warud", :latitude => "21.46667", :longitude => "78.26667").save
City.new(:country_id => "107", :name => "Warora", :aliases => "Warora,Warora", :latitude => "20.23333", :longitude => "79").save
City.new(:country_id => "107", :name => "Waris Aliganj", :aliases => "Waris Aliganj,Waris Ariganj,WÄris AlÄ«ganj,WÄris ArÄ«ganj,WÄris AlÄ«ganj", :latitude => "25.01667", :longitude => "85.63333").save
City.new(:country_id => "107", :name => "Wardha", :aliases => "Vardkha,Wardha,ÐÐ°ÑÐ´ÑÐ°,Wardha", :latitude => "20.75", :longitude => "78.61667").save
City.new(:country_id => "107", :name => "Waraseoni", :aliases => ",WÄrÄseoni", :latitude => "21.75", :longitude => "80.03333").save
City.new(:country_id => "107", :name => "Warangal", :aliases => "Varangal,Warangal,varangal,varankal,warangaru,ÐÐ°ÑÐ°Ð½Ð³Ð°Ð»,à®µà®¾à®°à®à¯à®à®²à¯,à°µà°°à°à°à°²à±,ã¯ã©ã³ã¬ã«,Warangal", :latitude => "18", :longitude => "79.58333").save
City.new(:country_id => "107", :name => "Wanparti", :aliases => "Wanaparthy,Wanparti,Wanparti", :latitude => "16.36667", :longitude => "78.06667").save
City.new(:country_id => "107", :name => "Wankaner", :aliases => "Vankaner Kathiawar,Wankaner,WÄnkÄner,WÄnkÄner", :latitude => "22.61667", :longitude => "70.93333").save
City.new(:country_id => "107", :name => "Wani", :aliases => "Vanja,Wani,Wun,WÅ«n,ÐÐ°Ð½Ñ,Wani", :latitude => "20.06667", :longitude => "78.95").save
City.new(:country_id => "107", :name => "Walajapet", :aliases => "Walaja,Walajapet,WÄlÄjÄpet,WÄlÄjÄpet", :latitude => "12.93333", :longitude => "79.38333").save
City.new(:country_id => "107", :name => "Wai", :aliases => "Vaj,Wai,ÐÐ°Ð¹,Wai", :latitude => "17.93333", :longitude => "73.9").save
City.new(:country_id => "107", :name => "Wadi", :aliases => "Vadi,Wadi,WÄdi,ÐÐ°Ð´Ð¸,WÄdi", :latitude => "17.06667", :longitude => "76.98333").save
City.new(:country_id => "107", :name => "Vyara", :aliases => "Vvara,Vyara,VyÄra,VyÄra", :latitude => "21.11667", :longitude => "73.4").save
City.new(:country_id => "107", :name => "Vuyyuru", :aliases => "Vuyyuru,VuyyÅ«ru,VuyyÅ«ru", :latitude => "16.36667", :longitude => "80.85").save
City.new(:country_id => "107", :name => "Vrindavan", :aliases => "Brindaban,BrindÄban,Vrindaban,Vrindavan,VrindÄban,VrindÄvan,ÐÑÐ¸Ð½Ð´Ð°Ð²Ð°Ð½,VrindÄvan", :latitude => "27.58333", :longitude => "77.7").save
City.new(:country_id => "107", :name => "Vriddhachalam", :aliases => ",VriddhÄchalam", :latitude => "11.5", :longitude => "79.33333").save
City.new(:country_id => "107", :name => "Vizianagaram", :aliases => "Viguyanagram,Vizianagaram,Vizianagram,Vizianagram City,vijayanakaram,à®µà®¿à®à®¯à®¨à®à®°à®®à¯,Vizianagaram", :latitude => "18.11667", :longitude => "83.41667").save
City.new(:country_id => "107", :name => "Vite", :aliases => "Vita,Vite,ÐÐ¸ÑÐ°,Vite", :latitude => "17.28333", :longitude => "74.55").save
City.new(:country_id => "107", :name => "Visnagar", :aliases => "Visnagar,Visnagar", :latitude => "23.7", :longitude => "72.55").save
City.new(:country_id => "107", :name => "Vishakhapatnam", :aliases => "Vaisakhapattanam,VaisÄkhapattanam,Visak,Visakha,Visakhapatnam,Visakhapatnamas,Vishakhapatnam,Vishakkhapatnam,VishÄkhapatnam,Vizag,Vizag City,Vizagapatam,bisakhapattama,vicakappattinam,visakhapatnam,vu~ishakapatonamu,ÐÐ¸ÑÐ°ÐºÑÐ°Ð¿Ð°ÑÐ½Ð°Ð¼,à¦¬à¦¿à¦¶à¦¾à¦à¦¾à¦ªà¦¤à§à¦¤à¦®,à®µà®¿à®à®¾à®à®ªà¯à®ªà®à¯à®à®¿à®£à®®à¯,à°µà°¿à°¶à°¾à°à°ªà°à±à°¨à°,ã´ã£ã·ã£ã¼ã«ãããã ,VishÄkhapatnam", :latitude => "17.7", :longitude => "83.3").save
City.new(:country_id => "107", :name => "Visavadar", :aliases => "Visavadar,Visavedar,VÄ«sÄvadar,VÄ«sÄvadar", :latitude => "21.38333", :longitude => "70.68333").save
City.new(:country_id => "107", :name => "Virudunagar", :aliases => "Virudunagar,Virudupatti,Virudunagar", :latitude => "9.6", :longitude => "77.96667").save
City.new(:country_id => "107", :name => "Viravanallur", :aliases => "Vadakku Viravanallur,Vadakku ViravanallÅ«r,Viravanallur,ViravanallÅ«r,ViravanallÅ«r", :latitude => "8.7", :longitude => "77.53333").save
City.new(:country_id => "107", :name => "Virarajendrapet", :aliases => ",VÄ«rarÄjendrapet", :latitude => "12.2", :longitude => "75.8").save
City.new(:country_id => "107", :name => "Virar", :aliases => "Virar,VirÄr,VirÄr", :latitude => "19.46667", :longitude => "72.8").save
City.new(:country_id => "107", :name => "Vinukonda", :aliases => "Vinukonda,Vinukonda", :latitude => "16.05", :longitude => "79.75").save
City.new(:country_id => "107", :name => "Villupuram", :aliases => "Villapurum,Villupuram,Villupuram", :latitude => "11.93333", :longitude => "79.48333").save
City.new(:country_id => "107", :name => "Vikarabad", :aliases => "Vicarabad,Vikarabad,VikÄrÄbÄd,VikÄrÄbÄd", :latitude => "17.33333", :longitude => "77.9").save
City.new(:country_id => "107", :name => "Vijayawada", :aliases => "Bezawada,Bezwada,BezwÄda,Vidzhajavada,Vijayavada,VijayavÄdÄ,Vijayawada,VijayawÄda,Widzajawada,WidÅºajawada,vijayavada,vijayavata,vu~ijayawada,ÐÐ¸Ð´Ð¶Ð°ÑÐ²Ð°Ð´Ð°,à®µà®¿à®à®¯à®µà®¾à®à®¾,à°µà°¿à°à°¯à°µà°¾à°¡,ã´ã£ã¸ã£ã¤ã¯ã¼ã,VijayawÄda", :latitude => "16.51667", :longitude => "80.61667").save
City.new(:country_id => "107", :name => "Vijapur", :aliases => "Vijapur,VijÄpur,VijÄpur", :latitude => "23.56667", :longitude => "72.75").save
City.new(:country_id => "107", :name => "Vidisha", :aliases => "Bhilsa,BhÄ«lsa,Vidisha,Vidisha", :latitude => "23.53333", :longitude => "77.81667").save
City.new(:country_id => "107", :name => "Vettaikkaranpudur", :aliases => "Vettagaranpudur,Vettaikkaranpudur,VettaikkÄranpudÅ«r,Vettakkaranpudur,VettakkÄranpudÅ«r,VettaikkÄranpudÅ«r", :latitude => "10.56667", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Vetapalem", :aliases => "Vetapalem,VetÄpÄlem,VetÄpÄlem", :latitude => "15.78333", :longitude => "80.31667").save
City.new(:country_id => "107", :name => "Veraval", :aliases => "Veraval,VerÄval,VerÄval", :latitude => "20.9", :longitude => "70.36667").save
City.new(:country_id => "107", :name => "Vepagunta", :aliases => ",Vepagunta", :latitude => "17.77844", :longitude => "83.21577").save
City.new(:country_id => "107", :name => "Venkatagiri", :aliases => "Venkatagiri,Venkatagiri Town,Venkatagiri", :latitude => "13.96667", :longitude => "79.58333").save
City.new(:country_id => "107", :name => "Vemalwada", :aliases => "Lembulavataka,Lemulavada,Vemalwada,VemalwÄda,Vemulavada,VemalwÄda", :latitude => "18.46667", :longitude => "78.88333").save
City.new(:country_id => "107", :name => "Velur", :aliases => "Velur,VelÅ«r,VelÅ«r", :latitude => "11.1", :longitude => "78.01667").save
City.new(:country_id => "107", :name => "Vellore", :aliases => "Vellor,Vellore,Velluru,Velur,velur,vu~eruru,ÐÐµÐ»Ð»Ð¾Ñ,à®µà¯à®²à¯à®°à¯,ã´ã§ã¼ã«ã¼ã«,Vellore", :latitude => "12.93333", :longitude => "79.13333").save
City.new(:country_id => "107", :name => "Vejalpur", :aliases => "Vejalpur,Vejalpur", :latitude => "22.68333", :longitude => "73.56667").save
City.new(:country_id => "107", :name => "Vedaranniyam", :aliases => "Vedaranayam,Vedaraniam,Vedaranniyam,VedÄranniyam,VedÄranniyam", :latitude => "10.36667", :longitude => "79.85").save
City.new(:country_id => "107", :name => "Vayalar", :aliases => "Vayalar,VayalÄr,VayalÄr", :latitude => "9.7", :longitude => "76.33333").save
City.new(:country_id => "107", :name => "Vattalkundu", :aliases => ",Vattalkundu", :latitude => "10.16667", :longitude => "77.76667").save
City.new(:country_id => "107", :name => "Vasudevanallur", :aliases => "Vasudevanallur,VÄsudevanallÅ«r,VÄsudevanallÅ«r", :latitude => "9.23333", :longitude => "77.41667").save
City.new(:country_id => "107", :name => "Vasind", :aliases => ",Vasind", :latitude => "19.41667", :longitude => "73.26667").save
City.new(:country_id => "107", :name => "Vasco Da Gama", :aliases => "Vasco,Vasco Da Gama,Vasco da Gama,Vasko-da-Gama,VÄsco Da GÄma,ÐÐ°ÑÐºÐ¾-Ð´Ð°-ÐÐ°Ð¼Ð°,VÄsco Da GÄma", :latitude => "15.39585", :longitude => "73.81568").save
City.new(:country_id => "107", :name => "Vasa", :aliases => ",Vasa", :latitude => "22.66667", :longitude => "72.73333").save
City.new(:country_id => "107", :name => "Varkkallai", :aliases => "Varkala,ÐÐ°ÑÐºÐ°Ð»Ð°,Varkkallai", :latitude => "8.7341", :longitude => "76.70671").save
City.new(:country_id => "107", :name => "Varangaon", :aliases => "Varangaon,Varangaon", :latitude => "21.01667", :longitude => "75.9").save
City.new(:country_id => "107", :name => "Benares", :aliases => "Banaras,Banares,BanÄras,Benares,BenarÃ©s,Kasi,KÄsi,Varanasi,Varanasio,Varanasis,Varanassi,VÃ¢rÃ¢nasÃ®,VÄrÄnasi,Waranasi,balanasi,baranasi,pha ran si,varanaci,varanasi,wa la na xi,waranashi,ÐÐ°ÑÐ°Ð½Ð°ÑÐ¸,à¤µà¤¾à¤°à¤¾à¤£à¤¸à¥,à¦¬à¦¾à¦°à¦¾à¦¨à¦¸à¦¿,à®µà®¾à®°à®£à®¾à®à®¿,à¸à¸²à¸£à¸²à¸à¸ªà¸µ,ã¯ã¼ã©ã¼ãã·ã¼,ç¦èç´è¥¿,ë°ë¼ëì,Benares", :latitude => "25.33333", :longitude => "83").save
City.new(:country_id => "107", :name => "Vaniyambadi", :aliases => "Vanivambadi,Vaniyambadi,VÄnivambÄdi,VÄniyambÄdi,VÄniyambÄdi", :latitude => "12.68333", :longitude => "78.61667").save
City.new(:country_id => "107", :name => "Vandavasi", :aliases => "Vandavasi,VandavÄsi,Wandiwash,WandiwÄsh,VandavÄsi", :latitude => "12.5", :longitude => "79.61667").save
City.new(:country_id => "107", :name => "Valsad", :aliases => "Bulsar,BulsÄr,Valsad,ValsÄd,Walsad,WalsÄd,ValsÄd", :latitude => "20.63333", :longitude => "72.93333").save
City.new(:country_id => "107", :name => "Valparai", :aliases => "Valparai,VÄlpÄrai,VÄlpÄrai", :latitude => "10.36667", :longitude => "76.96667").save
City.new(:country_id => "107", :name => "Vallabh Vidyanagar", :aliases => "Vallabh,Vallabh Vidhyanagar,Vallabh Vidyanagar,Vallabh Vidyanagar", :latitude => "22.53333", :longitude => "72.9").save
City.new(:country_id => "107", :name => "Valabhipur", :aliases => "Vala,Valabhipur,ValabhÄ«pur,Vallabhipur,ValabhÄ«pur", :latitude => "21.88333", :longitude => "71.86667").save
City.new(:country_id => "107", :name => "Vaikam", :aliases => "Vaikam,Vaikom,Vaikam", :latitude => "9.76667", :longitude => "76.4").save
City.new(:country_id => "107", :name => "Vaijapur", :aliases => "Vaijapur,VaijÄpur,VaijÄpur", :latitude => "19.91667", :longitude => "74.73333").save
City.new(:country_id => "107", :name => "Vadodara", :aliases => "Baroda,Vadodara,Vapadedara,vadodara,vadodara sahara,vu~adodara,ÐÐ°Ð´Ð¾Ð´Ð°ÑÐ°,à¤µà¤¡à¥à¤¦à¤°à¤¾ à¤¶à¤¹à¤°,àªµàª¡à«àª¦àª°àª¾,ã´ã¡ããã©,ã´ã¡ãã¼ãã©ã¼,Vadodara", :latitude => "22.3", :longitude => "73.2").save
City.new(:country_id => "107", :name => "Vadnagar", :aliases => "Vadnagar,Vadnagar", :latitude => "23.78333", :longitude => "72.63333").save
City.new(:country_id => "107", :name => "Vadlapudi", :aliases => ",VadlapÅ«di", :latitude => "14.31667", :longitude => "79.8").save
City.new(:country_id => "107", :name => "Vadippatti", :aliases => ",VÄdippatti", :latitude => "10.08333", :longitude => "77.95").save
City.new(:country_id => "107", :name => "Vadamadurai", :aliases => "Vada-Madura,Vadamadurai,Vadamadurai", :latitude => "10.46667", :longitude => "78.08333").save
City.new(:country_id => "107", :name => "Vadakku Valliyur", :aliases => ",Vadakku ValliyÅ«r", :latitude => "8.38333", :longitude => "77.65").save
City.new(:country_id => "107", :name => "Vada", :aliases => ",VÄda", :latitude => "19.65", :longitude => "73.13333").save
City.new(:country_id => "107", :name => "Uttiramerur", :aliases => "Uttaramerur,UttaramerÅ«r,Uttiramerur,UttiramerÅ«r,UttiramerÅ«r", :latitude => "12.6", :longitude => "79.76667").save
City.new(:country_id => "107", :name => "Uttarkashi", :aliases => "Barahat,BÄrÄhÄt,Uttarkashi,UttarkÄshi,UttarkÄshi", :latitude => "30.73333", :longitude => "78.45").save
City.new(:country_id => "107", :name => "Uttamapalaiyam", :aliases => ",UttamapÄlaiyam", :latitude => "9.8", :longitude => "77.33333").save
City.new(:country_id => "107", :name => "Utraula", :aliases => "Utraula,UtraulÄ,UtraulÄ", :latitude => "27.31667", :longitude => "82.41667").save
City.new(:country_id => "107", :name => "Usilampatti", :aliases => "Usilampatti,Usilampatti", :latitude => "9.96667", :longitude => "77.8").save
City.new(:country_id => "107", :name => "Usehat", :aliases => "Usehat,Usehat", :latitude => "27.7986", :longitude => "79.2393").save
City.new(:country_id => "107", :name => "Uravakonda", :aliases => "Uravakonda,Uravakonda", :latitude => "14.95", :longitude => "77.26667").save
City.new(:country_id => "107", :name => "Uran", :aliases => "Uran,Ð£ÑÐ°Ð½,Uran", :latitude => "18.87694", :longitude => "72.93972").save
City.new(:country_id => "107", :name => "Upleta", :aliases => "Upleta,Upleta", :latitude => "21.73333", :longitude => "70.28333").save
City.new(:country_id => "107", :name => "Uppal Kalan", :aliases => "Oopal,Pedda Uppal,Upal,Uppal,Uppal Kalan,Uppal Kalan", :latitude => "17.40577", :longitude => "78.55911").save
City.new(:country_id => "107", :name => "Unnao", :aliases => "Unao,Unnao,UnnÄo,UnnÄo", :latitude => "26.53333", :longitude => "80.5").save
City.new(:country_id => "107", :name => "Unjha", :aliases => "Unjha,Unjha", :latitude => "23.8", :longitude => "72.4").save
City.new(:country_id => "107", :name => "Unhel", :aliases => "Unhel,Unhel", :latitude => "23.33333", :longitude => "75.56667").save
City.new(:country_id => "107", :name => "Una", :aliases => ",Una", :latitude => "31.48333", :longitude => "76.28333").save
City.new(:country_id => "107", :name => "Una", :aliases => "Una,Una", :latitude => "20.81667", :longitude => "71.03333").save
City.new(:country_id => "107", :name => "Un", :aliases => ",Åªn", :latitude => "29.58472", :longitude => "77.25417").save
City.new(:country_id => "107", :name => "Un", :aliases => "Un,Un", :latitude => "23.88333", :longitude => "71.76667").save
City.new(:country_id => "107", :name => "Umreth", :aliases => "Umreth,Umreth", :latitude => "22.7", :longitude => "73.11667").save
City.new(:country_id => "107", :name => "Umred", :aliases => "Umred,Umrer,Umred", :latitude => "20.85", :longitude => "79.33333").save
City.new(:country_id => "107", :name => "Umarkot", :aliases => ",Umarkot", :latitude => "19.66667", :longitude => "82.21667").save
City.new(:country_id => "107", :name => "Umarkhed", :aliases => "Umarkhed,Umarkhed", :latitude => "19.6", :longitude => "77.7").save
City.new(:country_id => "107", :name => "Umaria", :aliases => ",UmariÄ", :latitude => "23.53333", :longitude => "80.83333").save
City.new(:country_id => "107", :name => "Umarga", :aliases => "Umarga,Umarga", :latitude => "17.83333", :longitude => "76.61667").save
City.new(:country_id => "107", :name => "Ullal", :aliases => "Ulaul,Ullai,Ullal,UllÄl,UllÄl", :latitude => "12.8", :longitude => "74.85").save
City.new(:country_id => "107", :name => "Ulhasnagar", :aliases => "Ulhasnagar,UlhÄsnagar,UlhÄsnagar", :latitude => "19.21667", :longitude => "73.15").save
City.new(:country_id => "107", :name => "Ujjain", :aliases => "Uddzhajn,Ujjain,ujjaina,Ð£Ð´Ð´Ð¶Ð°Ð¹Ð½,à¤à¤à¥à¤à¥à¤¨,à¦à¦à§à¦à§à¦¨,Ujjain", :latitude => "23.18333", :longitude => "75.76667").save
City.new(:country_id => "107", :name => "Ujhani", :aliases => "Ujhani,UjhÄni,UjhÄni", :latitude => "28.01667", :longitude => "79.01667").save
City.new(:country_id => "107", :name => "Udumalaippettai", :aliases => "Udamalpet,Udumalaippettai,Udumalaippettai", :latitude => "10.58333", :longitude => "77.25").save
City.new(:country_id => "107", :name => "Udipi", :aliases => "Udipi,Udupi,udupi,wu du pi,à²à²¡à³à²ªà²¿,ä¹æç®,Udipi", :latitude => "13.35", :longitude => "74.75").save
City.new(:country_id => "107", :name => "Udhampur", :aliases => "Udhampur,Udhampur", :latitude => "32.93333", :longitude => "75.13333").save
City.new(:country_id => "107", :name => "Udgir", :aliases => "Udgir,UdgÄ«r,UdgÄ«r", :latitude => "18.38333", :longitude => "77.11667").save
City.new(:country_id => "107", :name => "Udankudi", :aliases => ",Udankudi", :latitude => "8.43333", :longitude => "78.01667").save
City.new(:country_id => "107", :name => "Udalguri", :aliases => "Udalguri,Udalguri", :latitude => "26.76667", :longitude => "92.13333").save
City.new(:country_id => "107", :name => "Udaipura", :aliases => "Udaipura,Udaipura", :latitude => "23.08333", :longitude => "78.5").save
City.new(:country_id => "107", :name => "Udaipur", :aliases => ",Udaipur", :latitude => "27.71667", :longitude => "75.48333").save
City.new(:country_id => "107", :name => "Udaipur", :aliases => "Oodeypore,Udaipur City,Udajpur,Ð£Ð´Ð°Ð¹Ð¿ÑÑ,Udaipur", :latitude => "24.57117", :longitude => "73.69183").save
City.new(:country_id => "107", :name => "Udaipur", :aliases => "Udaipur,Udajpur,Ð£Ð´Ð°Ð¹Ð¿ÑÑ,Udaipur", :latitude => "23.53333", :longitude => "91.48333").save
City.new(:country_id => "107", :name => "Udagamandalam", :aliases => "Ootacamund,Ooty,Otacamund,Udagamandalam,Udakamandalam,Udhagamandalam,Utakamand,udakamandaramu,udhagamandalama,utakamantalam,uti,à¤à¤à¥,à¦à¦§à¦à¦®à¦¨à§à¦¡à¦²à¦®,à®à®¤à®à®®à®£à¯à®à®²à®®à¯,ã¦ãã«ãã³ãã©ã ,UdagamandalÄm", :latitude => "11.4", :longitude => "76.7").save
City.new(:country_id => "107", :name => "Uchana", :aliases => "Bara Uchana,Bara UchÄna,Uchana,UchÄna,UchÄna", :latitude => "29.46667", :longitude => "76.16667").save
City.new(:country_id => "107", :name => "Turaiyur", :aliases => "Turaiyur,TuraiyÅ«r,Turalyur,TuraiyÅ«r", :latitude => "11.16667", :longitude => "78.61667").save
City.new(:country_id => "107", :name => "Tura", :aliases => ",Tura", :latitude => "25.51667", :longitude => "90.21667").save
City.new(:country_id => "107", :name => "Tuni", :aliases => "Tuni,Tuni", :latitude => "17.35", :longitude => "82.55").save
City.new(:country_id => "107", :name => "Tundla", :aliases => ",TÅ«ndla", :latitude => "27.2", :longitude => "78.28333").save
City.new(:country_id => "107", :name => "Tumsar", :aliases => "Tumsar,Tumsar", :latitude => "21.38333", :longitude => "79.73333").save
City.new(:country_id => "107", :name => "Tumkur", :aliases => ",TumkÅ«r", :latitude => "13.34222", :longitude => "77.10167").save
City.new(:country_id => "107", :name => "Tulsipur", :aliases => "Tulsipur,TulsÄ«pur,TulsÄ«pur", :latitude => "27.55", :longitude => "82.41667").save
City.new(:country_id => "107", :name => "Tuljapur", :aliases => "Tuljapur,TuljÄpur,TuljÄpur", :latitude => "18", :longitude => "76.08333").save
City.new(:country_id => "107", :name => "Tufanganj", :aliases => "Tufanganj,TufÄnganj,TufÄnganj", :latitude => "26.31667", :longitude => "89.66667").save
City.new(:country_id => "107", :name => "Tuensang", :aliases => "Mozungjami,MozÅ«ngjÄmi,Tuensang,Tuensang", :latitude => "26.28333", :longitude => "94.83333").save
City.new(:country_id => "107", :name => "Thiruvananthapuram", :aliases => "Thiruvananthapuram,Tiruvananantapuram,Tiruvanantapuram,Trivandrum,te li fan de lang,tiru'anantapuram,tirubanantapurama,tiruvanantapuram,tiruvanantapurama,tiruvu~anantapuramu,tribanadrama,trivendrama,Ð¢Ð¸ÑÑÐ²Ð°Ð½Ð°Ð½ÑÐ°Ð¿ÑÑÐ°Ð¼,à¤¤à¤¿à¤°à¥à¤à¤¨à¤¨à¥à¤¤à¤ªà¥à¤°à¤®à¥,à¤¤à¤¿à¤°à¥à¤µà¤¨à¤à¤¤à¤ªà¥à¤°à¤®,à¤¤à¥à¤°à¤¿à¤µà¥à¤¨à¥à¤¦à¥à¤°à¤®,à¦¤à¦¿à¦°à§à¦¬à¦¨à¦¨à§à¦¤à¦ªà§à¦°à¦®,à¦¤à§à¦°à¦¿à¦¬à¦¾à¦¨à¦¦à§à¦°à¦¾à¦®,à®¤à®¿à®°à¯à®µà®©à®¨à¯à®¤à®ªà¯à®°à®®à¯,à´¤à´¿à´°àµà´µà´¨à´¨àµà´¤à´ªàµà´°à´,ãã£ã«ã´ã¡ãã³ã¿ãã©ã ,ç¹éå¡å¾ç,Thiruvananthapuram", :latitude => "8.48333", :longitude => "76.91667").save
City.new(:country_id => "107", :name => "Trichur", :aliases => "Thrissur,Trichura,tiruccur,Ð¢ÑÐ¸ÑÑÑÐ°,à®¤à®¿à®°à¯à®à¯à®à¯à®°à¯,à´¤àµà´¶àµà´¶àµà´°àµâ,TrichÅ«r", :latitude => "10.51667", :longitude => "76.21667").save
City.new(:country_id => "107", :name => "Tonk", :aliases => "Tonk,Tonk City,Tonk", :latitude => "26.16667", :longitude => "75.78333").save
City.new(:country_id => "107", :name => "Tondi", :aliases => ",Tondi", :latitude => "9.73333", :longitude => "79.01667").save
City.new(:country_id => "107", :name => "Tohana", :aliases => "Tohana,TohÄna,TohÄna", :latitude => "29.7", :longitude => "75.9").save
City.new(:country_id => "107", :name => "Toda Raisingh", :aliases => "Toda Raisingh,Toda RÄisingh,Todarasingh,Toda RÄisingh", :latitude => "26.01667", :longitude => "75.48333").save
City.new(:country_id => "107", :name => "Toda Bhim", :aliases => ",Toda BhÄ«m", :latitude => "26.91667", :longitude => "76.81667").save
City.new(:country_id => "107", :name => "Titlagarh", :aliases => "Titilagarh,Titlagar,Titlagarh,TitlÄgarh,TitlÄgarh", :latitude => "20.3", :longitude => "83.15").save
City.new(:country_id => "107", :name => "Titagarh", :aliases => "Titagarh,TitÄgarh,TitÄgarh", :latitude => "22.73639", :longitude => "88.37361").save
City.new(:country_id => "107", :name => "Tisaiyanvilai", :aliases => ",Tisaiyanvilai", :latitude => "8.33333", :longitude => "77.88333").save
City.new(:country_id => "107", :name => "Tiruvettipuram", :aliases => "Cheyyar,Tiruvattiyur,TiruvattiyÅ«r,Tiruvetipuram,Tiruvettipuram,Tiruvettipuram", :latitude => "12.66667", :longitude => "79.55").save
City.new(:country_id => "107", :name => "Tiruvannamalai", :aliases => "Tirruvannamalai,Tiruvannamalai,Tiruvannamalaj,TiruvannÄmalai,tiruvannamalai,tiruvu~an'namarai,Ð¢Ð¸ÑÑÐ²Ð°Ð½Ð½Ð°Ð¼Ð°Ð»Ð°Ð¹,à®¤à®¿à®°à¯à®µà®£à¯à®£à®¾à®®à®²à¯,ãã£ã«ã´ã¡ã³ãã¼ãã©ã¤,TiruvannÄmalai", :latitude => "12.21667", :longitude => "79.06667").save
City.new(:country_id => "107", :name => "Tiruvallur", :aliases => "Tiruvallur,TiruvallÅ«r,Tiruvellore,TiruvallÅ«r", :latitude => "13.15", :longitude => "79.91667").save
City.new(:country_id => "107", :name => "Tiruvalla", :aliases => "Thiruvalla,Tiruvalla,Tiruvalla", :latitude => "9.38333", :longitude => "76.56667").save
City.new(:country_id => "107", :name => "Tiruttani", :aliases => "Tirutani,Tiruttani,Tiruttani", :latitude => "13.18333", :longitude => "79.63333").save
City.new(:country_id => "107", :name => "Tiruttangal", :aliases => ",Tiruttangal", :latitude => "9.48333", :longitude => "77.83333").save
City.new(:country_id => "107", :name => "Tirur", :aliases => "Tirur,Tirur Station,TirÅ«r,TirÅ«r", :latitude => "10.9", :longitude => "75.91667").save
City.new(:country_id => "107", :name => "Tiruppuvanam", :aliases => ",Tiruppuvanam", :latitude => "9.83333", :longitude => "78.26667").save
City.new(:country_id => "107", :name => "Tiruppur", :aliases => "Tiruppur,TiruppÅ«r,Tirupur,TiruppÅ«r", :latitude => "11.1", :longitude => "77.35").save
City.new(:country_id => "107", :name => "Tirupparangunram", :aliases => "Thiruparangundram,Thirupparankundram,Tiruparankundram,Tirupparangunram,Tirupparankunram,Tirupparangunram", :latitude => "9.86667", :longitude => "78.06667").save
City.new(:country_id => "107", :name => "Tirupati", :aliases => "Tirumalai,Tirupati,Ð¢Ð¸ÑÑÐ¿Ð°ÑÐ¸,Tirupati", :latitude => "13.65", :longitude => "79.41667").save
City.new(:country_id => "107", :name => "Tirunelveli", :aliases => "Tinnevelli,Tinnevelly,Tinnevelly Junction,Tirunelveli,Tirunelweli,tirunelveli,tiruneruvu~eri,à®¤à®¿à®°à¯à®¨à¯à®²à¯à®µà¯à®²à®¿,ãã£ã«ãã«ã´ã§ã¼ãª,Tirunelveli", :latitude => "8.73333", :longitude => "77.7").save
City.new(:country_id => "107", :name => "Tirumala", :aliases => "Tirumala,Upper Tirupati,Tirumala", :latitude => "13.68333", :longitude => "79.35").save
City.new(:country_id => "107", :name => "Tirukkoyilur", :aliases => "Tirukkovilur,Tirukkoyilur,TirukkoyilÅ«r,TirukkoyilÅ«r", :latitude => "11.95", :longitude => "79.2").save
City.new(:country_id => "107", :name => "Tiruchengodu", :aliases => ",Tiruchengodu", :latitude => "11.38333", :longitude => "77.93333").save
City.new(:country_id => "107", :name => "Tiruchchirappalli", :aliases => "Tiruchchinappalli,TiruchchinÄppalli,Tiruchirappalli,Trichinapalli,Trichinopoli,Trichinopoly,Trinchinopoly,TiruchchirÄppalli", :latitude => "10.81667", :longitude => "78.68333").save
City.new(:country_id => "107", :name => "Tiruchchendur", :aliases => "Tiruchchendur,TiruchchendÅ«r,Tiruchendur,TiruchendÅ«r,TiruchchendÅ«r", :latitude => "8.48333", :longitude => "78.11667").save
City.new(:country_id => "107", :name => "Tirthahalli", :aliases => ",TÄ«rthahalli", :latitude => "13.7", :longitude => "75.23333").save
City.new(:country_id => "107", :name => "Tiptur", :aliases => "Tiptur,TiptÅ«r,TiptÅ«r", :latitude => "13.25861", :longitude => "76.47833").save
City.new(:country_id => "107", :name => "Tinsukia", :aliases => "Tinsukia,Tinsukia", :latitude => "27.5", :longitude => "95.36667").save
City.new(:country_id => "107", :name => "Tinnanur", :aliases => "Thiruninravur,Tinnanur,TinnanÅ«r,TinnanÅ«r", :latitude => "13.11139", :longitude => "80.02611").save
City.new(:country_id => "107", :name => "Tindivanam", :aliases => "Tindivanam,Tindivangam,Tindivanam", :latitude => "12.25", :longitude => "79.65").save
City.new(:country_id => "107", :name => "Tilhar", :aliases => "Tilhar,Tilhar", :latitude => "27.98333", :longitude => "79.73333").save
City.new(:country_id => "107", :name => "Tikamgarh", :aliases => "Tikamgarh,TÄ«kamgarh,TÄ«kamgarh", :latitude => "24.745", :longitude => "78.8333").save
City.new(:country_id => "107", :name => "Tijara", :aliases => "Tijara,TijÄra,TijÄra", :latitude => "27.93333", :longitude => "76.85").save
City.new(:country_id => "107", :name => "Thoubal", :aliases => "Thoubal,ThoubÄl,ThoubÄl", :latitude => "24.63333", :longitude => "94.01667").save
City.new(:country_id => "107", :name => "Thiruvarur", :aliases => "Thiruvarur,ThiruvÄrÅ«r,Tirnvalur,Tiruvalur,Tiruvarur,TiruvÄlÅ«r,ThiruvÄrÅ«r", :latitude => "10.76667", :longitude => "79.65").save
City.new(:country_id => "107", :name => "Thasra", :aliases => ",ThÄsra", :latitude => "22.8", :longitude => "73.21667").save
City.new(:country_id => "107", :name => "Tharad", :aliases => ",TharÄd", :latitude => "24.39611", :longitude => "71.62667").save
City.new(:country_id => "107", :name => "Thanjavur", :aliases => "Tanjavur,TanjavÃ»r,Tanjor,Tanjore,TanjÄvÅ«r,Thanjavur,ThanjÄvÅ«r,Tkhandzhavur,tanjaura,tanjavuru,Ð¢ÑÐ°Ð½Ð´Ð¶Ð°Ð²ÑÑ,à¤¤à¤à¤à¥à¤°,à®¤à®à¯à®à®¾à®µà¯à®°à¯,à´¤à´àµà´à´¾à´µàµà´°àµâ,ã¿ã³ã¸ã£ã¼ã´ã¼ã«,ThanjÄvÅ«r", :latitude => "10.8", :longitude => "79.15").save
City.new(:country_id => "107", :name => "Thanesar", :aliases => "Thanesar,ThÄnesar,ThÄnesar", :latitude => "29.98333", :longitude => "76.81667").save
City.new(:country_id => "107", :name => "Thane", :aliases => "Tanja,Tanna,Thana,Thane,ThÄna,ThÄne,Ð¢Ð°Ð½Ñ,ThÄne", :latitude => "19.2", :longitude => "72.96667").save
City.new(:country_id => "107", :name => "Thana Bhawan", :aliases => ",ThÄna Bhawan", :latitude => "29.58639", :longitude => "77.41667").save
City.new(:country_id => "107", :name => "Than", :aliases => "Than,Thangadh,ThÄn,ThÄn", :latitude => "22.56667", :longitude => "71.18333").save
City.new(:country_id => "107", :name => "Thakurganj", :aliases => "Thakurganj,ThÄkurganj,ThÄkurganj", :latitude => "26.45", :longitude => "88.13333").save
City.new(:country_id => "107", :name => "Thakurdwara", :aliases => "Thakurdwara,ThÄkurdwÄra,ThÄkurdwÄra", :latitude => "29.2", :longitude => "78.85").save
City.new(:country_id => "107", :name => "Tezpur", :aliases => "Darrang,Tezpur,Tezpur", :latitude => "26.63333", :longitude => "92.8").save
City.new(:country_id => "107", :name => "Terdal", :aliases => "Terdal,TerdÄl,TerdÄl", :latitude => "16.5", :longitude => "75.05").save
City.new(:country_id => "107", :name => "Teonthar", :aliases => "Teonthar,Teonthar", :latitude => "24.98333", :longitude => "81.65").save
City.new(:country_id => "107", :name => "Tenkasi", :aliases => "Tenkasi,TenkÄsi,TenkÄsi", :latitude => "8.96667", :longitude => "77.3").save
City.new(:country_id => "107", :name => "Teni", :aliases => "Teni,Theni,Tkheni,Ð¢ÑÐµÐ½Ð¸,Teni", :latitude => "10", :longitude => "77.48333").save
City.new(:country_id => "107", :name => "Tellicherry", :aliases => "Talasseri,Tellicherri,Tellichery,Tellicherry", :latitude => "11.75", :longitude => "75.53333").save
City.new(:country_id => "107", :name => "Telhara", :aliases => "Telhara,TelhÄra,TelhÄra", :latitude => "21.02694", :longitude => "76.83889").save
City.new(:country_id => "107", :name => "Tekkali", :aliases => ",Tekkali", :latitude => "18.61667", :longitude => "84.23333").save
City.new(:country_id => "107", :name => "Tekkalakote", :aliases => "Takkalakote,Tekkalakota,Tekkalakote,Tekkalakote", :latitude => "15.53333", :longitude => "76.88333").save
City.new(:country_id => "107", :name => "Tekari", :aliases => "Tekari,TekÄri,TekÄri", :latitude => "24.93333", :longitude => "84.83333").save
City.new(:country_id => "107", :name => "Tehri", :aliases => "Tehri,Tehri-Garhwal,Tehri-GarhwÄl,Tekhri,Ð¢ÐµÑÑÐ¸,Tehri", :latitude => "30.38333", :longitude => "78.48333").save
City.new(:country_id => "107", :name => "Teghra", :aliases => ",Teghra", :latitude => "25.48333", :longitude => "85.95").save
City.new(:country_id => "107", :name => "Tasgaon", :aliases => "Tasgaon,TÄsgaon,TÄsgaon", :latitude => "17.03333", :longitude => "74.6").save
City.new(:country_id => "107", :name => "Tarn Taran", :aliases => "Tarn Taran,Tarn TÄran,Tarn TÄran", :latitude => "31.45", :longitude => "74.92528").save
City.new(:country_id => "107", :name => "Tarikere", :aliases => "Tarikere,Tarikere", :latitude => "13.71667", :longitude => "75.81667").save
City.new(:country_id => "107", :name => "Tarangambadi", :aliases => "Fort Dansborg,Tarangambadi,TarangambÄdi,Trankebar,Tranquebar,TarangambÄdi", :latitude => "11.03194", :longitude => "79.85278").save
City.new(:country_id => "107", :name => "Taranagar", :aliases => "Reni,Taranagar,TÄrÄnagar,TÄrÄnagar", :latitude => "28.6709", :longitude => "75.0351").save
City.new(:country_id => "107", :name => "Tarana", :aliases => "Tarana,TarÄna,Ð¢Ð°ÑÐ°Ð½Ð°,TarÄna", :latitude => "23.33333", :longitude => "76.03333").save
City.new(:country_id => "107", :name => "Taramangalam", :aliases => ",TÄramangalam", :latitude => "11.7", :longitude => "77.98333").save
City.new(:country_id => "107", :name => "Tarakeswar", :aliases => "Tarakeswar,Tarakeswar", :latitude => "22.885", :longitude => "88.01722").save
City.new(:country_id => "107", :name => "Taoru", :aliases => "Taoru,TÄoru,TÄoru", :latitude => "28.21667", :longitude => "76.95").save
City.new(:country_id => "107", :name => "Tanuku", :aliases => "Tanuku,Tanuku", :latitude => "16.75", :longitude => "81.7").save
City.new(:country_id => "107", :name => "Tandur", :aliases => "Tandur,TÄndÅ«r,TÄndÅ«r", :latitude => "17.23333", :longitude => "77.58333").save
City.new(:country_id => "107", :name => "Tanda", :aliases => ",TÄnda", :latitude => "28.98333", :longitude => "78.93333").save
City.new(:country_id => "107", :name => "Tanda", :aliases => ",TÄndÄ", :latitude => "26.55", :longitude => "82.65").save
City.new(:country_id => "107", :name => "Tanakpur", :aliases => "Tanakpur,Tanakpur", :latitude => "29.08333", :longitude => "80.11667").save
City.new(:country_id => "107", :name => "Tamluk", :aliases => "Tamluk,TamlÅ«k,TamlÅ«k", :latitude => "22.3", :longitude => "87.91667").save
City.new(:country_id => "107", :name => "Talwara", :aliases => "Talwara,TalwÄra,TalwÄra", :latitude => "31.94861", :longitude => "75.86667").save
City.new(:country_id => "107", :name => "Talwandi Bhai", :aliases => ",Talwandi BhÄi", :latitude => "30.85", :longitude => "74.93333").save
City.new(:country_id => "107", :name => "Taloda", :aliases => ",Taloda", :latitude => "21.56667", :longitude => "74.21667").save
City.new(:country_id => "107", :name => "Taliparamba", :aliases => "Taliparamba,Talipparamba,Tullipurmbu,Taliparamba", :latitude => "12.05", :longitude => "75.35").save
City.new(:country_id => "107", :name => "Talikota", :aliases => "Talikota,Talikoti,TÄlÄ«kota,TÄlÄ«kota", :latitude => "16.48333", :longitude => "76.31667").save
City.new(:country_id => "107", :name => "Taleigao", :aliases => ",Taleigao", :latitude => "15.46667", :longitude => "73.8").save
City.new(:country_id => "107", :name => "Talegaon Dabhade", :aliases => "Dabhade,Talegaon Dabhade,Talegaon DÄbhÄde,Talegaon-Dabhada,Talegaon DÄbhÄde", :latitude => "18.71667", :longitude => "73.68333").save
City.new(:country_id => "107", :name => "Talcher", :aliases => "Talchar,Talcher,TÄlcher,TÄlcher", :latitude => "20.95", :longitude => "85.21667").save
City.new(:country_id => "107", :name => "Talaja", :aliases => "Talaja,TalÄja,TalÄja", :latitude => "21.35", :longitude => "72.05").save
City.new(:country_id => "107", :name => "Taki", :aliases => "Taki,Takoj,TÄki,Ð¢Ð°ÐºÐ¾Ð¹,TÄki", :latitude => "22.58611", :longitude => "88.92139").save
City.new(:country_id => "107", :name => "Takhatpur", :aliases => "Takhatpur,Takhatpur", :latitude => "22.15", :longitude => "81.86667").save
City.new(:country_id => "107", :name => "Takhatgarh", :aliases => "Takhatgarh,Takhatgarh", :latitude => "25.33333", :longitude => "73").save
City.new(:country_id => "107", :name => "Tajpur", :aliases => ",TÄjpur", :latitude => "29.16667", :longitude => "78.48333").save
City.new(:country_id => "107", :name => "Tadpatri", :aliases => "Tadpatri,TÄdpatri,TÄdpatri", :latitude => "14.91667", :longitude => "78.01667").save
City.new(:country_id => "107", :name => "Tadepallegudem", :aliases => "Tadepallegudem,Tadepalligudem,TÄdepallegÅ«dem,TÄdepalligÅ«dem,TÄdepallegÅ«dem", :latitude => "16.83333", :longitude => "81.5").save
City.new(:country_id => "107", :name => "Tadepalle", :aliases => ",TÄdepalle", :latitude => "16.48333", :longitude => "80.6").save
City.new(:country_id => "107", :name => "Suriapet", :aliases => "Suriapet,SuriÄpet,Suryapet,SuriÄpet", :latitude => "17.15", :longitude => "79.61667").save
City.new(:country_id => "107", :name => "Surianwan", :aliases => ",SuriÄnwÄn", :latitude => "25.46667", :longitude => "82.41667").save
City.new(:country_id => "107", :name => "Surendranagar", :aliases => "Civil Station,Surendranagar,Wadhwan,Wadhwan Camp,Wadhwan City,Wadhwan Civil Station,WadhwÄn,WadhwÄn Civil Station,Surendranagar", :latitude => "22.7", :longitude => "71.68333").save
City.new(:country_id => "107", :name => "Suratgarh", :aliases => "Suratgarh,Suratgarkh,SÅ«ratgarh,Ð¡ÑÑÐ°ÑÐ³Ð°ÑÑ,SÅ«ratgarh", :latitude => "29.31667", :longitude => "73.9").save
City.new(:country_id => "107", :name => "Surat", :aliases => "Surat,Suratas,Surate,SÅ«rat,su la te,surata,surato,Ð¡ÑÑÐ°Ñ,à¤¸à¥à¤°à¤¤,à¦¸à§à¦°à¦¾à¦¤,àª¸à«àª°àª¤,ã¹ã¼ã©ã,èæç¹,SÅ«rat", :latitude => "21.16667", :longitude => "72.83333").save
City.new(:country_id => "107", :name => "Surandai", :aliases => "Surandai,SÅ«randai,SÅ«randai", :latitude => "8.96667", :longitude => "77.4").save
City.new(:country_id => "107", :name => "Surajgarh", :aliases => "Surajgarh,SÅ«rajgarh,SÅ«rajgarh", :latitude => "28.3124", :longitude => "75.7347").save
City.new(:country_id => "107", :name => "Supaul", :aliases => ",Supaul", :latitude => "26.11667", :longitude => "86.6").save
City.new(:country_id => "107", :name => "Sunel", :aliases => ",Sunel", :latitude => "24.36667", :longitude => "75.96667").save
City.new(:country_id => "107", :name => "Sundarnagar", :aliases => ",Sundarnagar", :latitude => "31.53333", :longitude => "76.88333").save
City.new(:country_id => "107", :name => "Sundargarh", :aliases => "Sundargarh,Sundergarh,Sundargarh", :latitude => "22.11667", :longitude => "84.03333").save
City.new(:country_id => "107", :name => "Sunam", :aliases => "Sunam,SunÄm,SunÄm", :latitude => "30.13333", :longitude => "75.8").save
City.new(:country_id => "107", :name => "Sulya", :aliases => "Sulya,Sulya", :latitude => "12.56667", :longitude => "75.38333").save
City.new(:country_id => "107", :name => "Suluru", :aliases => "Sulurpet,Sulurpeta,Suluru,SÅ«lÅ«rpet,SÅ«lÅ«ru,SÅ«lÅ«ru", :latitude => "13.7", :longitude => "80.01667").save
City.new(:country_id => "107", :name => "Sulur", :aliases => "Sulur,SÅ«lÅ«r,SÅ«lÅ«r", :latitude => "11.03333", :longitude => "77.13333").save
City.new(:country_id => "107", :name => "Sultanpur", :aliases => ",SultÄnpur", :latitude => "31.21528", :longitude => "75.19972").save
City.new(:country_id => "107", :name => "Sultanpur", :aliases => ",SultÄnpur", :latitude => "26.26667", :longitude => "82.06667").save
City.new(:country_id => "107", :name => "Suket", :aliases => "Suke,Suket,Suket-Kotah,Suket", :latitude => "24.65", :longitude => "76.03333").save
City.new(:country_id => "107", :name => "Suar", :aliases => "Suar,SuÄr,Ð¡ÑÐ°Ñ,SuÄr", :latitude => "29.03333", :longitude => "79.05").save
City.new(:country_id => "107", :name => "Srivilliputtur", :aliases => ",SrÄ«villiputtÅ«r", :latitude => "9.51667", :longitude => "77.63333").save
City.new(:country_id => "107", :name => "Srivardhan", :aliases => "Shriwardham,Srivardhan,SrÄ«vardhan,SrÄ«vardhan", :latitude => "18.03333", :longitude => "73.01667").save
City.new(:country_id => "107", :name => "Srivaikuntam", :aliases => "Srivaikuntam,SrÄ«vaikuntam,SrÄ«vaikuntam", :latitude => "8.61667", :longitude => "77.93333").save
City.new(:country_id => "107", :name => "Srisailam", :aliases => "Srisailam,SrÄ«sailam,SrÄ«sailam", :latitude => "16.08333", :longitude => "78.86667").save
City.new(:country_id => "107", :name => "Sriramnagar", :aliases => "Sri Rama Nagar,Sriramnagar,SrÄ«rÄmnagar,SrÄ«rÄmnagar", :latitude => "17.26652", :longitude => "78.25544").save
City.new(:country_id => "107", :name => "Sriperumbudur", :aliases => "Sriperumbubur,Sriperumbudur,SrÄ«perumbÅ«dÅ«r,SrÄ«perumbÅ«dÅ«r", :latitude => "12.96889", :longitude => "79.94889").save
City.new(:country_id => "107", :name => "Srinivaspur", :aliases => "Srinivaspur,SrÄ«nivÄspur,SrÄ«nivÄspur", :latitude => "13.33333", :longitude => "78.21667").save
City.new(:country_id => "107", :name => "Srinagar", :aliases => "Shrinagar,Srinagar,Srinigar,Suryanagar,si li na jia,srinagara,sryngar,surinagaru,Ð¨ÑÐ¸Ð½Ð°Ð³Ð°Ñ,×¡×¨×× ×××¨,Ø³Ø±ÛÙÚ¯Ø§Ø±,à¤¶à¥à¤°à¥à¤¨à¤à¤°,à¦¶à§à¦°à§à¦¨à¦à¦°,ã¹ãªãã¬ã«,æ¯å©é£å ,SrÄ«nagar", :latitude => "34.08333", :longitude => "74.81667").save
City.new(:country_id => "107", :name => "Srinagar", :aliases => "Shrinagar,Srinagar,Srinagar Garhwal,SrÄ«nagar,Ð¨ÑÐ¸Ð½Ð°Ð³Ð°Ñ,SrÄ«nagar", :latitude => "30.21667", :longitude => "78.78333").save
City.new(:country_id => "107", :name => "Sri Madhopur", :aliases => "Sri Madhopur,Sri MÄdhopur,Sri MÄdhopur", :latitude => "27.46667", :longitude => "75.6").save
City.new(:country_id => "107", :name => "Sri Karanpur", :aliases => "Karanpur,Karanpura,Sri Karanpur,Sri Karanpur", :latitude => "29.84194", :longitude => "73.45417").save
City.new(:country_id => "107", :name => "Srikakulam", :aliases => "Chicacole,Srikakulam,SrÄ«kÄkulam,SrÄ«kÄkulam", :latitude => "18.3", :longitude => "83.9").save
City.new(:country_id => "107", :name => "Sri Dungargarh", :aliases => "Shri Dungargarh,Sri Dungargarh,Sri Dungargarh", :latitude => "28.08333", :longitude => "74.01667").save
City.new(:country_id => "107", :name => "Soygaon", :aliases => ",Soygaon", :latitude => "20.6", :longitude => "75.61667").save
City.new(:country_id => "107", :name => "Soron", :aliases => "Soron,Ð¡Ð¾ÑÐ¾Ð½,Soron", :latitude => "27.88333", :longitude => "78.75").save
City.new(:country_id => "107", :name => "Soro", :aliases => ",Soro", :latitude => "21.28806", :longitude => "86.68583").save
City.new(:country_id => "107", :name => "Sorada", :aliases => "Sorada,Surada,Sorada", :latitude => "19.75", :longitude => "84.43333").save
City.new(:country_id => "107", :name => "Sopur", :aliases => "Sopor,Sopore,Sopur,Sopur", :latitude => "34.3", :longitude => "74.46667").save
City.new(:country_id => "107", :name => "Sonipat", :aliases => "Sonepat,Sonepat Punjab,Sonipat,SonÄ«pat,SonÄ«pat", :latitude => "28.98333", :longitude => "77.01667").save
City.new(:country_id => "107", :name => "Songadh", :aliases => "Songadh,Songarh,Songadh", :latitude => "21.16667", :longitude => "73.56667").save
City.new(:country_id => "107", :name => "Sonepur", :aliases => "Sonapur,Sonepur,Sonpur,Sonepur", :latitude => "20.83333", :longitude => "83.91667").save
City.new(:country_id => "107", :name => "Sonari", :aliases => "Sonari,SonÄri,SonÄri", :latitude => "27.06667", :longitude => "95.03333").save
City.new(:country_id => "107", :name => "Sonamukhi", :aliases => "Sonamukhi,SonÄmukhi,SonÄmukhi", :latitude => "23.3", :longitude => "87.41667").save
City.new(:country_id => "107", :name => "Sompeta", :aliases => "Sompeta,Sompeta", :latitude => "18.93333", :longitude => "84.6").save
City.new(:country_id => "107", :name => "Someshwar", :aliases => "Somaishwar,Someshwar,Someshwar", :latitude => "13.5", :longitude => "75.06667").save
City.new(:country_id => "107", :name => "Solan", :aliases => "Solan,Solana,Solon,Ð¡Ð¾Ð»Ð°Ð½Ð°,Solan", :latitude => "30.91667", :longitude => "77.11667").save
City.new(:country_id => "107", :name => "Sojitra", :aliases => ",SojÄ«tra", :latitude => "22.55", :longitude => "72.71667").save
City.new(:country_id => "107", :name => "Sojat", :aliases => "Sojat,Sojat", :latitude => "25.91667", :longitude => "73.66667").save
City.new(:country_id => "107", :name => "Sohna", :aliases => "Sohna,Sohna", :latitude => "28.25", :longitude => "77.06667").save
City.new(:country_id => "107", :name => "Sohagpur", :aliases => "Sohagpur,SohÄgpur,SohÄgpur", :latitude => "22.7", :longitude => "78.2").save
City.new(:country_id => "107", :name => "Siwana", :aliases => "Siwana,SiwÄna,SiwÄna", :latitude => "25.63333", :longitude => "72.41667").save
City.new(:country_id => "107", :name => "Siwan", :aliases => "Savan,Sivan,Siwan,SiwÄn,Ð¡Ð¸Ð²Ð°Ð½,SiwÄn", :latitude => "26.21667", :longitude => "84.36667").save
City.new(:country_id => "107", :name => "Sivakasi", :aliases => "Sivakasi,SivakÄsi,SivakÄsi", :latitude => "9.45", :longitude => "77.81667").save
City.new(:country_id => "107", :name => "Sivagiri", :aliases => ",Sivagiri", :latitude => "11.11667", :longitude => "77.8").save
City.new(:country_id => "107", :name => "Sivagiri", :aliases => ",Sivagiri", :latitude => "9.33333", :longitude => "77.43333").save
City.new(:country_id => "107", :name => "Sivaganga", :aliases => "Sivaganga,Sivaganga", :latitude => "9.86667", :longitude => "78.48333").save
City.new(:country_id => "107", :name => "Siuri", :aliases => "Siuri,Suri,SÅ«ri,Siuri", :latitude => "23.91667", :longitude => "87.53333").save
City.new(:country_id => "107", :name => "Sitarganj", :aliases => "Sitarganj,SitÄrganj,SitÄrganj", :latitude => "28.93333", :longitude => "79.7").save
City.new(:country_id => "107", :name => "Sitapur", :aliases => "Sitapur,SÄ«tÄpur,SÄ«tÄpur", :latitude => "27.56667", :longitude => "80.68333").save
City.new(:country_id => "107", :name => "Sitamarhi", :aliases => "Sitamarhi,SÄ«tÄmarhi,SÄ«tÄmarhi", :latitude => "26.6", :longitude => "85.48333").save
City.new(:country_id => "107", :name => "Siswa Bazar", :aliases => ",SiswÄ BÄzÄr", :latitude => "27.15", :longitude => "83.76667").save
City.new(:country_id => "107", :name => "Sisauli", :aliases => "Sisauli,Sisauli", :latitude => "29.41667", :longitude => "77.46667").save
City.new(:country_id => "107", :name => "Sirur", :aliases => "Ghodnadi,Sirur,SirÅ«r,SirÅ«r", :latitude => "18.83333", :longitude => "74.38333").save
City.new(:country_id => "107", :name => "Sirumugai", :aliases => "Sirumugai,Sirumugal,Sirumugai", :latitude => "11.33333", :longitude => "77.01667").save
City.new(:country_id => "107", :name => "Siruguppa", :aliases => "Siruguppa,Siruguppa", :latitude => "15.63333", :longitude => "76.9").save
City.new(:country_id => "107", :name => "Sirsilla", :aliases => "Sirsilla,Sirsilla", :latitude => "18.38333", :longitude => "78.83333").save
City.new(:country_id => "107", :name => "Sirsi", :aliases => ",Sirsi", :latitude => "28.65", :longitude => "78.65").save
City.new(:country_id => "107", :name => "Sirsi", :aliases => "Sirsi,Sirsi", :latitude => "14.61667", :longitude => "74.85").save
City.new(:country_id => "107", :name => "Sirsaganj", :aliases => "Sirsaganj,SirsÄganj,SirsÄganj", :latitude => "27.05", :longitude => "78.7").save
City.new(:country_id => "107", :name => "Sirsa", :aliases => ",Sirsa", :latitude => "29.53333", :longitude => "75.01667").save
City.new(:country_id => "107", :name => "Sironj", :aliases => "Sironj,Sironj", :latitude => "24.1", :longitude => "77.7").save
City.new(:country_id => "107", :name => "Sirohi", :aliases => "Sirohi,Sirohi", :latitude => "24.88333", :longitude => "72.86667").save
City.new(:country_id => "107", :name => "Sirkazhi", :aliases => "Cikal,CÄ«kÄl,Shiyali,ShÄ«yali,Sirkali,Sirkazhi,SÄ«rkÄzhi,SÄ«rkÄzhi", :latitude => "11.23333", :longitude => "79.73333").save
City.new(:country_id => "107", :name => "Sirhind", :aliases => ",Sirhind", :latitude => "30.64556", :longitude => "76.3825").save
City.new(:country_id => "107", :name => "Sira", :aliases => ",SÄ«ra", :latitude => "13.74528", :longitude => "76.90917").save
City.new(:country_id => "107", :name => "Sinnar", :aliases => "Sinnar,Ð¡Ð¸Ð½Ð½Ð°Ñ,Sinnar", :latitude => "19.85", :longitude => "74").save
City.new(:country_id => "107", :name => "Singur", :aliases => "Singur,Singur", :latitude => "22.80917", :longitude => "88.22944").save
City.new(:country_id => "107", :name => "Singarayakonda", :aliases => "Singaraya Konda Pagoda,Singarayakonda,SingarÄyakonda,SingarÄyakonda", :latitude => "15.25", :longitude => "80.03333").save
City.new(:country_id => "107", :name => "Singanallur", :aliases => ",SingÄnallÅ«r", :latitude => "11", :longitude => "77.01667").save
City.new(:country_id => "107", :name => "Sindhnur", :aliases => ",SindhnÅ«r", :latitude => "15.78333", :longitude => "76.76667").save
City.new(:country_id => "107", :name => "Sindgi", :aliases => "Sindgi,Sindgi", :latitude => "16.91667", :longitude => "76.23333").save
City.new(:country_id => "107", :name => "Shimla", :aliases => "Shimla,Simla,cimla,shimura,simala,symlh,xi mu la,Ð¨Ð¸Ð¼Ð»Ð°,×©××××,à¤¶à¤¿à¤®à¤²à¤¾,à¦¸à¦¿à¦®à¦²à¦¾,à®à®¿à®®à¯à®²à®¾,ã·ã ã©,ã·ã ã©ã¼,è¥¿å§æ,Shimla", :latitude => "31.1", :longitude => "77.16667").save
City.new(:country_id => "107", :name => "Simdega", :aliases => "Simdega,Simdega", :latitude => "22.61667", :longitude => "84.51667").save
City.new(:country_id => "107", :name => "Silvassa", :aliases => "Selvasa,SelvÄsa,Silvassa,Silvassa", :latitude => "20.26667", :longitude => "73.01667").save
City.new(:country_id => "107", :name => "Sillod", :aliases => "Sillod,Sillod", :latitude => "20.3", :longitude => "75.65").save
City.new(:country_id => "107", :name => "Silchar", :aliases => "Silchar,Ð¡Ð¸Ð»ÑÐ°Ñ,Silchar", :latitude => "24.81667", :longitude => "92.8").save
City.new(:country_id => "107", :name => "Silao", :aliases => "Silao,Ð¡Ð¸Ð»Ð°Ð¾,Silao", :latitude => "25.08333", :longitude => "85.41667").save
City.new(:country_id => "107", :name => "Sikar", :aliases => "Sikar,SÄ«kar,SÄ«kar", :latitude => "27.61667", :longitude => "75.15").save
City.new(:country_id => "107", :name => "Sikandra Rao", :aliases => "Sikandra Rao,Sikandra Rao", :latitude => "27.7", :longitude => "78.4").save
City.new(:country_id => "107", :name => "Sikandarpur", :aliases => ",Sikandarpur", :latitude => "26.05", :longitude => "84.05").save
City.new(:country_id => "107", :name => "Sikandarabad", :aliases => "Sikandarabad,SikandarÄbÄd,Sikandrabad,SikandarÄbÄd", :latitude => "28.45", :longitude => "77.7").save
City.new(:country_id => "107", :name => "Sikka", :aliases => "Sika,Siki,Sikka,Sikka", :latitude => "22.43333", :longitude => "69.83333").save
City.new(:country_id => "107", :name => "Sijua", :aliases => "Sijua,Sijua", :latitude => "23.78333", :longitude => "86.31667").save
City.new(:country_id => "107", :name => "Sihora", :aliases => "Sihora,SihorÄ,SihorÄ", :latitude => "23.48333", :longitude => "80.11667").save
City.new(:country_id => "107", :name => "Sihor", :aliases => "Shihor,Sihara,Sihor,Sihor", :latitude => "21.7", :longitude => "71.96667").save
City.new(:country_id => "107", :name => "Sidlaghatta", :aliases => "Sidlaghatta,Sidlaghatta", :latitude => "13.38806", :longitude => "77.86278").save
City.new(:country_id => "107", :name => "Sidhi", :aliases => "Sidhi,Sidi,Sidkhi,Ð¡Ð¸Ð´ÑÐ¸,Sidhi", :latitude => "24.41667", :longitude => "81.88333").save
City.new(:country_id => "107", :name => "Sidhauli", :aliases => "Sidhauli,SidhaulÄ«,SidhaulÄ«", :latitude => "27.28333", :longitude => "80.83333").save
City.new(:country_id => "107", :name => "Siddipet", :aliases => "Siddipet,Siddipet", :latitude => "18.1", :longitude => "78.85").save
City.new(:country_id => "107", :name => "Siddhapur", :aliases => "Siddhapur,Sidhpur,Siddhapur", :latitude => "23.91667", :longitude => "72.38333").save
City.new(:country_id => "107", :name => "Sibsagar", :aliases => "Sibsagar,Sibsagor Naga Bhumi,SibsÄgar,Ð¡Ð¸Ð±ÑÐ°Ð³Ð°Ñ,SibsÄgar", :latitude => "26.98333", :longitude => "94.63333").save
City.new(:country_id => "107", :name => "Shujalpur", :aliases => "Shujalpur,ShujÄlpur,ShujÄlpur", :latitude => "23.4", :longitude => "76.71667").save
City.new(:country_id => "107", :name => "Shrirangapattana", :aliases => "Shrirangapattana,ShrÄ«rangapattana,ShrÄ«rangapattana", :latitude => "12.41361", :longitude => "76.70417").save
City.new(:country_id => "107", :name => "Shrirampur", :aliases => "Serampore,Serampur,Shrirampur,ShrÄ«rÄmpur,ShrÄ«rÄmpur", :latitude => "22.75278", :longitude => "88.34222").save
City.new(:country_id => "107", :name => "Shrigonda", :aliases => "Shrigonda,ShrÄ«gonda,ShrÄ«gonda", :latitude => "18.61667", :longitude => "74.68333").save
City.new(:country_id => "107", :name => "Shorapur", :aliases => "Shorapur,Shoratur,ShorÄpur,Surapur,Suratur,SÅ«rÄpur,ShorÄpur", :latitude => "16.51667", :longitude => "76.75").save
City.new(:country_id => "107", :name => "Shoranur", :aliases => "Shoranur,ShoranÅ«r,ShoranÅ«r", :latitude => "10.76667", :longitude => "76.28333").save
City.new(:country_id => "107", :name => "Sholinghur", :aliases => "Sholinghur,Sholinghur", :latitude => "13.11667", :longitude => "79.41667").save
City.new(:country_id => "107", :name => "Solapur", :aliases => "Sholapur,SholÄpur,Solapur,SolÄpur,shorapuru,solapura,sollapura,Ð¡Ð¾Ð»Ð°Ð¿ÑÑ,à¤¸à¥à¤²à¤¾à¤ªà¥à¤°,à²¸à³à²²à³à²²à²¾à²ªà³à²°,ã·ã§ã©ã¼ãã«,SolÄpur", :latitude => "17.68333", :longitude => "75.91667").save
City.new(:country_id => "107", :name => "Shivpuri", :aliases => ",ShivpurÄ«", :latitude => "25.43333", :longitude => "77.65").save
City.new(:country_id => "107", :name => "Shishgarh", :aliases => "Shishgarh,ShÄ«shgarh,ShÄ«shgarh", :latitude => "28.71667", :longitude => "79.31667").save
City.new(:country_id => "107", :name => "Shirpur", :aliases => "Shirpur,Shirpure,Ð¨Ð¸ÑÐ¿ÑÑÐµ,Shirpur", :latitude => "21.35", :longitude => "74.88333").save
City.new(:country_id => "107", :name => "Shirhatti", :aliases => "Shirhatti,Shirhatti", :latitude => "15.23333", :longitude => "75.58333").save
City.new(:country_id => "107", :name => "Shirdi", :aliases => "Shirdi,Ð¨Ð¸ÑÐ´Ð¸,Shirdi", :latitude => "19.76667", :longitude => "74.48333").save
City.new(:country_id => "107", :name => "Shimoga", :aliases => "Shimogga,Shimoga", :latitude => "13.91667", :longitude => "75.56667").save
City.new(:country_id => "107", :name => "Shillong", :aliases => "Shillong,shiron,shylang,silam,silanga,sillan,Ð¨Ð¸Ð»Ð»Ð¾Ð½Ð³,Ø´ÛÙØ§ÙÚ¯,à¤¶à¤¿à¤²à¤¾à¤à¤,à¦¶à¦¿à¦²à¦,à®·à®¿à®²à¯à®²à®¾à®à¯,ã·ã­ã³,Shillong", :latitude => "25.56892", :longitude => "91.88313").save
City.new(:country_id => "107", :name => "Shiliguri", :aliases => "Shiliguri,Silguri,Siligun,Siliguri,SilÄ«gurÃ­,siliguri,xi li gu li,Ð¡Ð¸Ð»Ð¸Ð³ÑÑÐ¸,à¤¸à¤¿à¤²à¥à¤à¥à¤¡à¤¼à¥,è¥¿éå¤é,Shiliguri", :latitude => "26.7", :longitude => "88.43333").save
City.new(:country_id => "107", :name => "Shikohabad", :aliases => "Shikohabad,ShikohÄbÄd,ShikohÄbÄd", :latitude => "27.1", :longitude => "78.6").save
City.new(:country_id => "107", :name => "Shikarpur", :aliases => ",ShikÄrpur", :latitude => "28.28333", :longitude => "78.01667").save
City.new(:country_id => "107", :name => "Shikarpur", :aliases => ",ShikÄrpur", :latitude => "14.26667", :longitude => "75.35").save
City.new(:country_id => "107", :name => "Shiggaon", :aliases => "Shigaon,Shiggaon,Shiggaon", :latitude => "15", :longitude => "75.23333").save
City.new(:country_id => "107", :name => "Shertallai", :aliases => "Shertalla,Shertallai,Shertally,Shertallai", :latitude => "9.7", :longitude => "76.33333").save
City.new(:country_id => "107", :name => "Sherkot", :aliases => "Bijnor,Sherkot,Sherkot", :latitude => "29.35", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Sherghati", :aliases => "Sherghati,SherghÄti,SherghÄti", :latitude => "24.56667", :longitude => "84.78333").save
City.new(:country_id => "107", :name => "Sheopur", :aliases => "Sheopur,Sheopur Kalan,Sheopur", :latitude => "25.66667", :longitude => "76.7").save
City.new(:country_id => "107", :name => "Sheohar", :aliases => ",Sheohar", :latitude => "26.51667", :longitude => "85.3").save
City.new(:country_id => "107", :name => "Sheoganj", :aliases => "Sheoganj,Sheoganj", :latitude => "25.15", :longitude => "73.06667").save
City.new(:country_id => "107", :name => "Shegaon", :aliases => "Shegaon,Shegaon", :latitude => "20.78333", :longitude => "76.68333").save
City.new(:country_id => "107", :name => "Shantipur", :aliases => "Santipur,Shantipur,ShÄntipur,SÄntipur,ShÄntipur", :latitude => "23.25", :longitude => "88.46667").save
City.new(:country_id => "107", :name => "Shamsabad", :aliases => ",ShamsÄbÄd", :latitude => "27.53333", :longitude => "79.43333").save
City.new(:country_id => "107", :name => "Shamsabad", :aliases => ",ShamsÄbÄd", :latitude => "27.01667", :longitude => "78.13333").save
City.new(:country_id => "107", :name => "Shamli", :aliases => "Shamli,ShÄmli,ShÄmli", :latitude => "29.45", :longitude => "77.31667").save
City.new(:country_id => "107", :name => "Shamgarh", :aliases => "Shamgarh,ShÄmgarh,ShÄmgarh", :latitude => "24.18333", :longitude => "75.63333").save
City.new(:country_id => "107", :name => "Shajapur", :aliases => "Shajapur,ShÄjÄpur,ShÄjÄpur", :latitude => "23.43333", :longitude => "76.26667").save
City.new(:country_id => "107", :name => "Shaikhpura", :aliases => ",Shaikhpura", :latitude => "25.15", :longitude => "85.85").save
City.new(:country_id => "107", :name => "Shahpura", :aliases => ",ShÄhpura", :latitude => "27.38333", :longitude => "75.96667").save
City.new(:country_id => "107", :name => "Shahpura", :aliases => ",ShÄhpura", :latitude => "25.63333", :longitude => "74.93333").save
City.new(:country_id => "107", :name => "Shahpur", :aliases => "Shahpur,Shakhpura,ShÄhpur,Ð¨Ð°ÑÐ¿ÑÑÐ°,ShÄhpur", :latitude => "29.35", :longitude => "77.55").save
City.new(:country_id => "107", :name => "Shahpur", :aliases => ",ShÄhpur", :latitude => "25.58333", :longitude => "84.45").save
City.new(:country_id => "107", :name => "Shahpur", :aliases => ",ShÄhpur", :latitude => "21.23333", :longitude => "76.21667").save
City.new(:country_id => "107", :name => "Shahpur", :aliases => "Shahpur,Shakhpura,ShÄhpur,Ð¨Ð°ÑÐ¿ÑÑÐ°,ShÄhpur", :latitude => "16.7", :longitude => "76.83333").save
City.new(:country_id => "107", :name => "Shahjahanpur", :aliases => "Shahjahanpur,ShÄhjahÄnpur,ShÄhjahÄnpur", :latitude => "27.88333", :longitude => "79.91667").save
City.new(:country_id => "107", :name => "Shahi", :aliases => ",ShÄhi", :latitude => "28.55", :longitude => "79.31667").save
City.new(:country_id => "107", :name => "Shahganj", :aliases => "Jaunpur,Shahganj,ShÄhganj,ShÄhganj", :latitude => "26.05", :longitude => "82.68333").save
City.new(:country_id => "107", :name => "Shahdol", :aliases => "Sahdol,Shahdol,Shahdol", :latitude => "23.28333", :longitude => "81.35").save
City.new(:country_id => "107", :name => "Shahada", :aliases => ",ShÄhÄda", :latitude => "21.55", :longitude => "74.46667").save
City.new(:country_id => "107", :name => "Shahabad", :aliases => ",ShÄhÄbÄd", :latitude => "30.1681", :longitude => "76.8715").save
City.new(:country_id => "107", :name => "Shahabad", :aliases => "Sahabad,Shahabad,ShÄhÄbÄd,SÄhÄbÄd,ShÄhÄbÄd", :latitude => "28.56667", :longitude => "79.01667").save
City.new(:country_id => "107", :name => "Shahabad", :aliases => "Hardoi,Shahabad,ShÄhÄbÄd,ShÄhÄbÄd", :latitude => "27.65", :longitude => "79.95").save
City.new(:country_id => "107", :name => "Shahabad", :aliases => "Shahabad,Shahabad Deccan,ShÄhÄbÄd,ShÄhÄbÄd", :latitude => "17.13333", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Serchhip", :aliases => "Serchhip,SerchhÄ«p,SerchhÄ«p", :latitude => "23.3", :longitude => "92.83333").save
City.new(:country_id => "107", :name => "Seram", :aliases => "Sedam,Seram,Ð¡ÐµÑÐ°Ð¼,Seram", :latitude => "17.18333", :longitude => "77.28333").save
City.new(:country_id => "107", :name => "Seoni Malwa", :aliases => "Seoni Malwa,Seoni Marwa,SeonÄ« MÄlwÄ,SeonÄ« MÄlwÄ", :latitude => "22.45", :longitude => "77.46667").save
City.new(:country_id => "107", :name => "Seoni", :aliases => "Seoni,SeonÄ«,SeonÄ«", :latitude => "22.08333", :longitude => "79.53333").save
City.new(:country_id => "107", :name => "Seondha", :aliases => "Seondha,Seora,Seondha", :latitude => "26.15778", :longitude => "78.77972").save
City.new(:country_id => "107", :name => "Seohara", :aliases => "Seohara,SeohÄrÄ,SeohÄrÄ", :latitude => "29.21667", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Sendhwa", :aliases => "Sendhawa,Sendhwa,Sendhwa", :latitude => "21.68333", :longitude => "75.1").save
City.new(:country_id => "107", :name => "Sehore", :aliases => "Sehore,Sehore", :latitude => "23.2", :longitude => "77.08333").save
City.new(:country_id => "107", :name => "Sayla", :aliases => ",SÄyla", :latitude => "22.55", :longitude => "71.46667").save
City.new(:country_id => "107", :name => "Sawai Madhopur", :aliases => "Sawai Madhopur,SawÄi MÄdhopur,SawÄi MÄdhopur", :latitude => "25.98333", :longitude => "76.36667").save
City.new(:country_id => "107", :name => "Savda", :aliases => "Savda,SÄvda,SÄvda", :latitude => "21.15", :longitude => "75.88333").save
City.new(:country_id => "107", :name => "Savanur", :aliases => "Savanur,SavanÅ«r,SavanÅ«r", :latitude => "14.96667", :longitude => "75.35").save
City.new(:country_id => "107", :name => "Savantvadi", :aliases => ",SÄvantvÄdi", :latitude => "15.9", :longitude => "73.81667").save
City.new(:country_id => "107", :name => "Sausar", :aliases => "Sausar,Sausar", :latitude => "21.65", :longitude => "78.78333").save
City.new(:country_id => "107", :name => "Saundatti", :aliases => "Saundatti,Saundatti Yellamma,Saundatti", :latitude => "15.78333", :longitude => "75.11667").save
City.new(:country_id => "107", :name => "Satyamangalam", :aliases => ",Satyamangalam", :latitude => "11.51667", :longitude => "77.25").save
City.new(:country_id => "107", :name => "Sattur", :aliases => "Sattur,SÄttÅ«r,SÄttÅ«r", :latitude => "9.36667", :longitude => "77.93333").save
City.new(:country_id => "107", :name => "Sattenapalle", :aliases => "Sattenapalle,Sattenapalle", :latitude => "16.4", :longitude => "80.18333").save
City.new(:country_id => "107", :name => "Satna", :aliases => "Satna,Satna", :latitude => "24.58333", :longitude => "80.83333").save
City.new(:country_id => "107", :name => "Satara", :aliases => "Satara,SÄtÄra,Ð¡Ð°ÑÐ°ÑÐ°,SÄtÄra", :latitude => "17.68333", :longitude => "73.98333").save
City.new(:country_id => "107", :name => "Satana", :aliases => "Satana,SatÄna,SatÄna", :latitude => "20.58333", :longitude => "74.2").save
City.new(:country_id => "107", :name => "Sasvad", :aliases => "Sasvad,SÄsvad,SÄsvad", :latitude => "18.33333", :longitude => "74.03333").save
City.new(:country_id => "107", :name => "Sarwar", :aliases => "Sarvar,SarvÄr,Sarwar,SarwÄr,SarwÄr", :latitude => "26.06667", :longitude => "75").save
City.new(:country_id => "107", :name => "Sarkhej", :aliases => ",Sarkhej", :latitude => "22.98333", :longitude => "72.5").save
City.new(:country_id => "107", :name => "Sardulgarh", :aliases => "Sardulgarh,Sardulgarh", :latitude => "29.7", :longitude => "75.25").save
City.new(:country_id => "107", :name => "Sardhana", :aliases => ",Sardhana", :latitude => "29.15", :longitude => "77.61667").save
City.new(:country_id => "107", :name => "Sardarshahr", :aliases => ",SardÄrshahr", :latitude => "28.43333", :longitude => "74.48333").save
City.new(:country_id => "107", :name => "Sarauli", :aliases => "Saranli,Sarauli,Sarauli", :latitude => "28.5", :longitude => "79.1").save
City.new(:country_id => "107", :name => "Sarangpur", :aliases => "Sarangpur,SÄrangpur,SÄrangpur", :latitude => "23.56667", :longitude => "76.46667").save
City.new(:country_id => "107", :name => "Saraipali", :aliases => "Saraipaili,Saraipali,SaraipÄli,SaraipÄli", :latitude => "21.33333", :longitude => "83").save
City.new(:country_id => "107", :name => "Sarai Mir", :aliases => ",SarÄi MÄ«r", :latitude => "26.01667", :longitude => "82.91667").save
City.new(:country_id => "107", :name => "Sarai Akil", :aliases => ",SarÄi Äkil", :latitude => "25.38333", :longitude => "81.51667").save
City.new(:country_id => "107", :name => "Saoner", :aliases => ",Saoner", :latitude => "21.38333", :longitude => "78.9").save
City.new(:country_id => "107", :name => "Sankrail", :aliases => "Sankrail,Shankrail,SÄnkrÄil,SÄnkrÄil", :latitude => "22.55", :longitude => "88.2").save
City.new(:country_id => "107", :name => "Sankeshwar", :aliases => "Sankeshvar,Sankeshwar,Sankeshwar", :latitude => "16.26667", :longitude => "74.48333").save
City.new(:country_id => "107", :name => "Sangrur", :aliases => "Sangrur,SangrÅ«r,SangrÅ«r", :latitude => "30.23333", :longitude => "75.83333").save
City.new(:country_id => "107", :name => "Sangola", :aliases => ",SÄngola", :latitude => "17.43333", :longitude => "75.2").save
City.new(:country_id => "107", :name => "Sangod", :aliases => "Sangod,Sangod", :latitude => "24.91667", :longitude => "76.28333").save
City.new(:country_id => "107", :name => "Sangli", :aliases => "Sangla,Sangli,SÄngli,Turmeric city,SÄngli", :latitude => "16.85438", :longitude => "74.56417").save
City.new(:country_id => "107", :name => "Sangaria", :aliases => "Sangaria,Sangaria", :latitude => "29.8", :longitude => "74.45").save
City.new(:country_id => "107", :name => "Sangareddi", :aliases => "Sangareddi,Sangareddipet,SangÄreddi,SangÄreddi", :latitude => "17.62944", :longitude => "78.09167").save
City.new(:country_id => "107", :name => "Sangamner", :aliases => "Sangamner,Sangamnor,Sangamner", :latitude => "19.56667", :longitude => "74.21667").save
City.new(:country_id => "107", :name => "Sandur", :aliases => "Sandur,SandÅ«r,SandÅ«r", :latitude => "15.1", :longitude => "76.55").save
City.new(:country_id => "107", :name => "Sandila", :aliases => "Sandila,SandÄ«la,SandÄ«la", :latitude => "27.08333", :longitude => "80.51667").save
City.new(:country_id => "107", :name => "Sandi", :aliases => ",SÄndi", :latitude => "27.3", :longitude => "79.95").save
City.new(:country_id => "107", :name => "Sancoale", :aliases => "Sancoale,Sancoale", :latitude => "15.36667", :longitude => "73.9").save
City.new(:country_id => "107", :name => "Sanchor", :aliases => ",SÄnchor", :latitude => "24.75528", :longitude => "71.77222").save
City.new(:country_id => "107", :name => "Sanawad", :aliases => "Sanavad,Sanawad,SÄnÄwad,SÄnÄwad", :latitude => "22.18333", :longitude => "76.06667").save
City.new(:country_id => "107", :name => "Sanaur", :aliases => "Sanaur,Sanaur", :latitude => "30.3025", :longitude => "76.45528").save
City.new(:country_id => "107", :name => "Sanand", :aliases => "Sanand,SÄnand,SÄnand", :latitude => "22.98333", :longitude => "72.38333").save
City.new(:country_id => "107", :name => "Samthar", :aliases => "Samthar,Samthar", :latitude => "25.85", :longitude => "78.91667").save
City.new(:country_id => "107", :name => "Samrala", :aliases => "Samrala,SamrÄla,SamrÄla", :latitude => "30.83667", :longitude => "76.18972").save
City.new(:country_id => "107", :name => "Samdari", :aliases => ",Samdari", :latitude => "25.81667", :longitude => "72.58333").save
City.new(:country_id => "107", :name => "Sambhar", :aliases => "Sambhar,Sambhar Lake,Sambkhara,SÄmbhar,Ð¡Ð°Ð¼Ð±ÑÐ°ÑÐ°,SÄmbhar", :latitude => "26.91667", :longitude => "75.2").save
City.new(:country_id => "107", :name => "Sambhal", :aliases => "Sambhal,Sambhal", :latitude => "28.58333", :longitude => "78.55").save
City.new(:country_id => "107", :name => "Sambalpur", :aliases => "Sambalpore,Sambalpur,Sambalpur", :latitude => "21.45", :longitude => "83.96667").save
City.new(:country_id => "107", :name => "Samba", :aliases => "Samba,SÄmba,SÄmba", :latitude => "32.56667", :longitude => "75.11667").save
City.new(:country_id => "107", :name => "Samastipur", :aliases => "Samastipur,SamastÄ«pur,SamastÄ«pur", :latitude => "25.85", :longitude => "85.78333").save
City.new(:country_id => "107", :name => "Samalkot", :aliases => ",SÄmalkot", :latitude => "17.05", :longitude => "82.18333").save
City.new(:country_id => "107", :name => "Samalkha", :aliases => "Samalkha,SamÄlkha,SamÄlkha", :latitude => "29.23333", :longitude => "77.01667").save
City.new(:country_id => "107", :name => "Salur", :aliases => "Salur,SÄlÅ«r,SÄlÅ«r", :latitude => "18.53333", :longitude => "83.21667").save
City.new(:country_id => "107", :name => "Salumbar", :aliases => "Salumbar,SÄlÅ«mbar,SÄlÅ«mbar", :latitude => "24.13333", :longitude => "74.05").save
City.new(:country_id => "107", :name => "Salem", :aliases => "Salem,Selam,selam,seramu,Ð¡Ð°Ð»ÐµÐ¼,à´¸àµà´²à´,ã»ã¼ã©ã ,Salem", :latitude => "11.65", :longitude => "78.16667").save
City.new(:country_id => "107", :name => "Salaya", :aliases => "Salaya,SalÄya,SalÄya", :latitude => "22.31667", :longitude => "69.6").save
City.new(:country_id => "107", :name => "Sakti", :aliases => "Sakti,Shakti,Ð¨Ð°ÐºÑÐ¸,Sakti", :latitude => "22.03333", :longitude => "82.96667").save
City.new(:country_id => "107", :name => "Sakleshpur", :aliases => "Saklaspur,Sakleshpur,Sakleshpur", :latitude => "12.96667", :longitude => "75.78333").save
City.new(:country_id => "107", :name => "Saint Thomas Mount", :aliases => "Madras Saint Thomas Mount,Parangimalai,Paranginealai,Saint Thomas Mount,Saint Thomas's Mount,Saint Thomasâs Mount,Saint Thomas Mount", :latitude => "12.99639", :longitude => "80.20306").save
City.new(:country_id => "107", :name => "Sainthia", :aliases => "Sainthia,Sainthia", :latitude => "23.95", :longitude => "87.66667").save
City.new(:country_id => "107", :name => "Sailu", :aliases => "Sailu,Selu,Sailu", :latitude => "19.46667", :longitude => "76.46667").save
City.new(:country_id => "107", :name => "Saiha", :aliases => "Saiha,Saiha", :latitude => "22.48333", :longitude => "92.96667").save
City.new(:country_id => "107", :name => "Saidpur", :aliases => ",Saidpur", :latitude => "25.55", :longitude => "83.18333").save
City.new(:country_id => "107", :name => "Sahibganj", :aliases => ",SÄhibganj", :latitude => "25.25", :longitude => "87.65").save
City.new(:country_id => "107", :name => "Sahawar", :aliases => "Sahawar,SahÄwar,SahÄwar", :latitude => "27.8", :longitude => "78.85").save
City.new(:country_id => "107", :name => "Sahaswan", :aliases => "Sahaswan,SahaswÄn,SahaswÄn", :latitude => "28.08333", :longitude => "78.75").save
City.new(:country_id => "107", :name => "Sahaspur", :aliases => "Sahaspur,Sahaspur", :latitude => "29.13333", :longitude => "78.61667").save
City.new(:country_id => "107", :name => "Saharsa", :aliases => "Saharsa,Saharsa", :latitude => "25.88333", :longitude => "86.6").save
City.new(:country_id => "107", :name => "Saharanpur", :aliases => "Saharanpur,SahÄranpur,SahÄranpur", :latitude => "29.96667", :longitude => "77.55").save
City.new(:country_id => "107", :name => "Sagauli", :aliases => "Saganli,Sagauli,Saghauli,Sagowlee,Segowlee,Segowlie,Sugauli,Sagauli", :latitude => "26.78333", :longitude => "84.73333").save
City.new(:country_id => "107", :name => "Sagar", :aliases => "Sagar,Saugor,SÄgar,Ð¡Ð°Ð³Ð°Ñ,SÄgar", :latitude => "23.83333", :longitude => "78.71667").save
City.new(:country_id => "107", :name => "Sagar", :aliases => ",SÄgar", :latitude => "14.16667", :longitude => "75.03333").save
City.new(:country_id => "107", :name => "Safipur", :aliases => "Safipur,SafÄ«pur,SafÄ«pur", :latitude => "26.73333", :longitude => "80.35").save
City.new(:country_id => "107", :name => "Safidon", :aliases => "Safidon,Safidon", :latitude => "29.41667", :longitude => "76.66667").save
City.new(:country_id => "107", :name => "Sadri", :aliases => ",SÄdri", :latitude => "25.18333", :longitude => "73.43333").save
City.new(:country_id => "107", :name => "Sadaseopet", :aliases => "Sadaseopet,Sadasivpet,SadÄseopet,SadÄseopet", :latitude => "17.61667", :longitude => "77.95").save
City.new(:country_id => "107", :name => "Sadalgi", :aliases => "Sadalga,Sadalgi,Sadalgi", :latitude => "16.56667", :longitude => "74.55").save
City.new(:country_id => "107", :name => "Sadabad", :aliases => "Sadabad,SadÄbÄd,SadÄbÄd", :latitude => "27.45", :longitude => "78.05").save
City.new(:country_id => "107", :name => "Sabalgarh", :aliases => "Sabalgarh,Sabalgarh", :latitude => "26.25", :longitude => "77.4").save
City.new(:country_id => "107", :name => "Rusera", :aliases => ",Rusera", :latitude => "25.75", :longitude => "86.03333").save
City.new(:country_id => "107", :name => "Rura", :aliases => "Rura,Rura", :latitude => "26.48333", :longitude => "79.9").save
City.new(:country_id => "107", :name => "Rupnagar", :aliases => "Ropar,Rupar,Rupnagar,RÅ«par,RÅ«pnagar,RÅ«pnagar", :latitude => "30.96639", :longitude => "76.53306").save
City.new(:country_id => "107", :name => "Rudarpur", :aliases => ",RÅ«darpur", :latitude => "26.43944", :longitude => "83.61444").save
City.new(:country_id => "107", :name => "Roorkee", :aliases => "Roorkee,Roorkee", :latitude => "29.86667", :longitude => "77.88333").save
City.new(:country_id => "107", :name => "Ron", :aliases => "Ron,Rona,Ð Ð¾Ð½Ð°,Ron", :latitude => "15.66667", :longitude => "75.73333").save
City.new(:country_id => "107", :name => "Rohtak", :aliases => "Rohtak,Rohtak", :latitude => "28.9", :longitude => "76.56667").save
City.new(:country_id => "107", :name => "Roha", :aliases => "Roha,Roha-Kolaba,Roha", :latitude => "18.43333", :longitude => "73.11667").save
City.new(:country_id => "107", :name => "Robertsonpet", :aliases => "Robertsonpet,Robertsonpet", :latitude => "12.96667", :longitude => "78.28333").save
City.new(:country_id => "107", :name => "Robertsganj", :aliases => "Robertsganj,Robertsganj", :latitude => "24.7", :longitude => "83.06667").save
City.new(:country_id => "107", :name => "Risod", :aliases => "Risod,Risod", :latitude => "19.96667", :longitude => "76.78333").save
City.new(:country_id => "107", :name => "Rishra", :aliases => "Rishra,Rishra", :latitude => "22.71417", :longitude => "88.34778").save
City.new(:country_id => "107", :name => "Rishikesh", :aliases => "Rikhikesh,Rishikesh,RishÄ«kesh,Ð Ð¸ÑÐ¸ÐºÐµÑ,RishÄ«kesh", :latitude => "30.11667", :longitude => "78.31667").save
City.new(:country_id => "107", :name => "Ringas", :aliases => "Reengus,Ringas,Ringus,RÄ«ngas,RÄ«ngas", :latitude => "27.35", :longitude => "75.56667").save
City.new(:country_id => "107", :name => "Richha", :aliases => "Richha,Richha", :latitude => "28.7", :longitude => "79.51667").save
City.new(:country_id => "107", :name => "Rewari", :aliases => "Rewari,RewÄri,RewÄri", :latitude => "28.18333", :longitude => "76.61667").save
City.new(:country_id => "107", :name => "Rewa", :aliases => "Reva,Rewa,Rewah,Ð ÐµÐ²Ð°,Rewa", :latitude => "24.53333", :longitude => "81.3").save
City.new(:country_id => "107", :name => "Revelganj", :aliases => "Revelganj,Revelganj", :latitude => "25.78333", :longitude => "84.66667").save
City.new(:country_id => "107", :name => "Repalle", :aliases => "Repalle,Ð ÐµÐ¿Ð°Ð»Ð»Ðµ,Repalle", :latitude => "16.01667", :longitude => "80.85").save
City.new(:country_id => "107", :name => "Reoti", :aliases => "Reoti,Reoti", :latitude => "25.85", :longitude => "84.38333").save
City.new(:country_id => "107", :name => "Renukut", :aliases => "Renukoot,Renukut,RenukÅ«t,RenukÅ«t", :latitude => "24.2", :longitude => "83.03333").save
City.new(:country_id => "107", :name => "Renigunta", :aliases => "Renigunta,Renigunta", :latitude => "13.65", :longitude => "79.51667").save
City.new(:country_id => "107", :name => "Remuna", :aliases => "Remuna,Remuna", :latitude => "21.52611", :longitude => "86.87222").save
City.new(:country_id => "107", :name => "Rehli", :aliases => "Rehli,RehlÄ«,RehlÄ«", :latitude => "23.63333", :longitude => "79.08333").save
City.new(:country_id => "107", :name => "Razam", :aliases => ",RÄzÄm", :latitude => "18.46667", :longitude => "83.66667").save
City.new(:country_id => "107", :name => "Raybag", :aliases => "Raybag,Raybagh,RÄybÄg,RÄybÄg", :latitude => "16.48333", :longitude => "74.78333").save
City.new(:country_id => "107", :name => "Rayadrug", :aliases => ",RÄyadrug", :latitude => "14.7", :longitude => "76.86667").save
City.new(:country_id => "107", :name => "Rayachoti", :aliases => "Rayachoti,RÄyachoti,RÄyachoti", :latitude => "14.05", :longitude => "78.75").save
City.new(:country_id => "107", :name => "Raya", :aliases => "Raja,Raya,RÄya,Ð Ð°Ñ,RÄya", :latitude => "27.56667", :longitude => "77.78333").save
City.new(:country_id => "107", :name => "Raxaul", :aliases => "Raksaul,Rasaul,Raxaul,Ð Ð°ÐºÑÐ°ÑÐ»,Raxaul", :latitude => "26.98333", :longitude => "84.85").save
City.new(:country_id => "107", :name => "Rawatsar", :aliases => "Rawatsar,RÄwatsÄr,RÄwatsÄr", :latitude => "29.28333", :longitude => "74.38333").save
City.new(:country_id => "107", :name => "Rawatbhata", :aliases => "Rawat Bhatta,Rawatbhaia,Rawatbhata,RÄwatbhÄta,RÄwatbhÄta", :latitude => "24.93333", :longitude => "75.58333").save
City.new(:country_id => "107", :name => "Raver", :aliases => "Raver,RÄver,RÄver", :latitude => "21.25", :longitude => "76.03333").save
City.new(:country_id => "107", :name => "Ratnagiri", :aliases => "Ratnagiri,RatnÄgiri,Rutnagherry,Ð Ð°ÑÐ½Ð°Ð³Ð¸ÑÐ¸,RatnÄgiri", :latitude => "16.98333", :longitude => "73.3").save
City.new(:country_id => "107", :name => "Ratlam", :aliases => "Hatlam,Ratlam,RatlÄm,RatlÄm", :latitude => "23.31667", :longitude => "75.06667").save
City.new(:country_id => "107", :name => "Ratia", :aliases => "Ratia,Ð Ð°ÑÐ¸Ð°,Ratia", :latitude => "29.68333", :longitude => "75.58333").save
City.new(:country_id => "107", :name => "Rath", :aliases => "Rata,Rath,RÄth,Ð Ð°ÑÐ°,RÄth", :latitude => "25.58333", :longitude => "79.56667").save
City.new(:country_id => "107", :name => "Ratanpur", :aliases => "Ratanpur,Ratanpur", :latitude => "22.3", :longitude => "82.16667").save
City.new(:country_id => "107", :name => "Ratangarh", :aliases => ",Ratangarh", :latitude => "28.08333", :longitude => "74.6").save
City.new(:country_id => "107", :name => "Rasra", :aliases => "Rasra,RasrÄ,RasrÄ", :latitude => "25.85", :longitude => "83.85").save
City.new(:country_id => "107", :name => "Rasipuram", :aliases => "Rasipur,Rasipuram,RÄsipuram,RÄsÄ«pur,RÄsipuram", :latitude => "11.46667", :longitude => "78.16667").save
City.new(:country_id => "107", :name => "Rapar", :aliases => "Rapar,RÄpar,RÄpar", :latitude => "23.56667", :longitude => "70.63333").save
City.new(:country_id => "107", :name => "Ranipur", :aliases => "Ranipur,RÄnÄ«pur,RÄnÄ«pur", :latitude => "25.25", :longitude => "79.06667").save
City.new(:country_id => "107", :name => "Ranikhet", :aliases => "Ranikhet,Rawikhet,RÄnÄ«khet,RÄwikhet,RÄnÄ«khet", :latitude => "29.65", :longitude => "79.41667").save
City.new(:country_id => "107", :name => "Raniganj", :aliases => "Ranigandzhe,Raniganj,RÄnÄ«ganj,Ð Ð°Ð½Ð¸Ð³Ð°Ð½Ð´Ð¶Ðµ,RÄnÄ«ganj", :latitude => "23.61667", :longitude => "87.13333").save
City.new(:country_id => "107", :name => "Ranibennur", :aliases => "Ranibennur,Renibennur,RÄnÄ«bennur,RÄnÄ«bennur", :latitude => "14.61667", :longitude => "75.61667").save
City.new(:country_id => "107", :name => "Rania", :aliases => "Rania,Ranija,Raniya,RÄnia,Ð Ð°Ð½Ð¸Ñ,RÄnia", :latitude => "29.53333", :longitude => "74.83333").save
City.new(:country_id => "107", :name => "Rangia", :aliases => "Ranga Nadi,Rangia,Rangiya,RangÄ NadÄ«,Rangia", :latitude => "26.46667", :longitude => "91.63333").save
City.new(:country_id => "107", :name => "Rangapara", :aliases => "Rangapara,RangÄpÄra,RangÄpÄra", :latitude => "26.81667", :longitude => "92.65").save
City.new(:country_id => "107", :name => "Ranchi", :aliases => "Ranchi,ramci,ranchi,ranci,Ð Ð°Ð½ÑÐ¸,à¤°à¤¾à¤à¤à¥,à¦°à¦¾à¦à¦à§,à®°à®¾à®à¯à®à®¿,ã©ã¼ã³ãã¼,RÄnchÄ«", :latitude => "23.35", :longitude => "85.33333").save
City.new(:country_id => "107", :name => "Ranavav", :aliases => "Ranavav,Ranawao,RÄnÄvÄv,RÄnÄwÄo,RÄnÄvÄv", :latitude => "21.68417", :longitude => "69.74083").save
City.new(:country_id => "107", :name => "Ranaghat", :aliases => "Ranaghat,RÄnÄghÄt,RÄnÄghÄt", :latitude => "23.18333", :longitude => "88.58333").save
City.new(:country_id => "107", :name => "Ramtek", :aliases => "Ramtek,RÄmtek,Ð Ð°Ð¼ÑÐµÐº,RÄmtek", :latitude => "21.4", :longitude => "79.33333").save
City.new(:country_id => "107", :name => "Rampur Hat", :aliases => ",RÄmpur HÄt", :latitude => "24.16667", :longitude => "87.78333").save
City.new(:country_id => "107", :name => "Rampura", :aliases => ",RÄmpura", :latitude => "30.25", :longitude => "75.23333").save
City.new(:country_id => "107", :name => "Rampura", :aliases => ",RÄmpura", :latitude => "24.46667", :longitude => "75.43333").save
City.new(:country_id => "107", :name => "Rampur", :aliases => ",RÄmpur", :latitude => "29.81667", :longitude => "77.45").save
City.new(:country_id => "107", :name => "Rampur", :aliases => ",RÄmpur", :latitude => "28.81667", :longitude => "79.03333").save
City.new(:country_id => "107", :name => "Ramnagar", :aliases => "Ramnagar,RÄmnagar,RÄmnagar", :latitude => "29.4", :longitude => "79.11667").save
City.new(:country_id => "107", :name => "Ramnagar", :aliases => ",RÄmnagar", :latitude => "27.16667", :longitude => "84.31667").save
City.new(:country_id => "107", :name => "Ramnagar", :aliases => ",RÄmnagar", :latitude => "25.28333", :longitude => "83.03333").save
City.new(:country_id => "107", :name => "Ramjibanpur", :aliases => "Ramjibanpur,RÄmjÄ«banpur,RÄmjÄ«banpur", :latitude => "22.83333", :longitude => "87.61667").save
City.new(:country_id => "107", :name => "Ramgarh", :aliases => "Ramgarh,RÄmgarh,RÄmgarh", :latitude => "27.25", :longitude => "75.18333").save
City.new(:country_id => "107", :name => "Ramgarh", :aliases => ",RÄmgarh", :latitude => "23.63333", :longitude => "85.51667").save
City.new(:country_id => "107", :name => "Ramganj Mandi", :aliases => "Ramganj Mandi,RÄmganj Mandi,RÄmganj Mandi", :latitude => "24.65", :longitude => "75.93333").save
City.new(:country_id => "107", :name => "Rameswaram", :aliases => "Ramesvaram,Rameswaram,RÄmeswaram,RÄmeswaram", :latitude => "9.28333", :longitude => "79.3").save
City.new(:country_id => "107", :name => "Ramapuram", :aliases => ",RÄmÄpuram", :latitude => "13.11667", :longitude => "79.2").save
City.new(:country_id => "107", :name => "Ramanathapuram", :aliases => "Ramanathapuram,Ramanatkhapurama,Ramanthapuram,Ramnad,RÄmanÄthapuram,Ð Ð°Ð¼Ð°Ð½Ð°ÑÑÐ°Ð¿ÑÑÐ°Ð¼Ð°,RÄmanÄthapuram", :latitude => "9.38333", :longitude => "78.83333").save
City.new(:country_id => "107", :name => "Ramanagaram", :aliases => "Closepet,Ramanagaram,RÄmanagaram,Ð Ð°Ð¼Ð°Ð½Ð°Ð³Ð°ÑÐ°Ð¼,RÄmanagaram", :latitude => "12.71667", :longitude => "77.3").save
City.new(:country_id => "107", :name => "Ramachandrapuram", :aliases => ",RÄmachandrapuram", :latitude => "16.85", :longitude => "82.01667").save
City.new(:country_id => "107", :name => "Rajura", :aliases => "Rajura,RÄjÅ«ra,RÄjÅ«ra", :latitude => "19.78333", :longitude => "79.36667").save
City.new(:country_id => "107", :name => "Rajula", :aliases => "Rajula,RÄjula,RÄjula", :latitude => "21.05", :longitude => "71.43333").save
City.new(:country_id => "107", :name => "Rajsamand", :aliases => "Rajsamand,RÄjsamand,RÄjsamand", :latitude => "25.06667", :longitude => "73.88333").save
City.new(:country_id => "107", :name => "Rajpura", :aliases => "Kajpura,Rajpura,RÄjpura,RÄjpura", :latitude => "30.48306", :longitude => "76.595").save
City.new(:country_id => "107", :name => "Rajpur", :aliases => "Alirajpur,Rajpur,RÄjpur,RÄjpur", :latitude => "22.3", :longitude => "74.35").save
City.new(:country_id => "107", :name => "Rajpur", :aliases => "Rajpur,RÄjpur,RÄjpur", :latitude => "21.93333", :longitude => "75.13333").save
City.new(:country_id => "107", :name => "Rajpipla", :aliases => ",RÄjpÄ«pla", :latitude => "21.86667", :longitude => "73.5").save
City.new(:country_id => "107", :name => "Raj Nandgaon", :aliases => "Raj Nandga,Raj Nandgaon,RÄj NÄndgaon,RÄj NÄndgaon", :latitude => "21.1", :longitude => "81.03333").save
City.new(:country_id => "107", :name => "Rajmahal", :aliases => ",RÄjmahal", :latitude => "25.05", :longitude => "87.83333").save
City.new(:country_id => "107", :name => "Rajkot", :aliases => "Radzhkot,Radzkot,Radzkotas,RadÅºkot,RadÅ¾kotas,Rajkot,RÄjkot,rajikotto,Ð Ð°Ð´Ð¶ÐºÐ¾Ñ,ã©ã¼ã¸ã³ãã,RÄjkot", :latitude => "22.3", :longitude => "70.78333").save
City.new(:country_id => "107", :name => "Rajgurunagar", :aliases => "Rajgurunagar,RÄjgurunagar,RÄjgurunagar", :latitude => "18.86667", :longitude => "73.9").save
City.new(:country_id => "107", :name => "Rajgir", :aliases => "Radzhgir,Rajagriha,Rajgir,Rajgriha,RÄjagriha,RÄjgÄ«r,Ð Ð°Ð´Ð¶Ð³Ð¸Ñ,RÄjgÄ«r", :latitude => "25.03333", :longitude => "85.41667").save
City.new(:country_id => "107", :name => "Rajgarh", :aliases => ",RÄjgarh", :latitude => "28.63333", :longitude => "75.38333").save
City.new(:country_id => "107", :name => "Rajgarh", :aliases => ",RÄjgarh", :latitude => "27.23333", :longitude => "76.63333").save
City.new(:country_id => "107", :name => "Rajgarh", :aliases => ",RÄjgarh", :latitude => "24", :longitude => "76.71667").save
City.new(:country_id => "107", :name => "Rajgarh", :aliases => "Rajgarh,RÄjgarh,RÄjgarh", :latitude => "22.68333", :longitude => "74.95").save
City.new(:country_id => "107", :name => "Rajauri", :aliases => "Rajaori,Rajauri,RÄjaori,RÄjauri,RÄjauri", :latitude => "33.38333", :longitude => "74.3").save
City.new(:country_id => "107", :name => "Rajapalaiyam", :aliases => "Rajapalaiyam,Rajapalayam,RÄjapÄlaiyam,RÄjapÄlaiyam", :latitude => "9.45", :longitude => "77.56667").save
City.new(:country_id => "107", :name => "Rajampet", :aliases => "Rajampet,Razampeta,RÄjampet,RÄzampeta,RÄjampet", :latitude => "14.18333", :longitude => "79.16667").save
City.new(:country_id => "107", :name => "Rajaldesar", :aliases => "Rajaldesar,RÄjaldesar,RÄjaldesar", :latitude => "28.03333", :longitude => "74.46667").save
City.new(:country_id => "107", :name => "Rajakhera", :aliases => "Rajakhera,RÄjÄkhera,RÄjÄkhera", :latitude => "26.89611", :longitude => "78.17139").save
City.new(:country_id => "107", :name => "Rajahmundry", :aliases => "Radzhamandri,Rajahmondry,Rajahmundry,Rajamahendravaram,Rajamahendri,Rajamandri,RÄjahmundry,RÄjamahendravaram,Ð Ð°Ð´Ð¶Ð°Ð¼Ð°Ð½Ð´ÑÐ¸,RÄjahmundry", :latitude => "16.98333", :longitude => "81.78333").save
City.new(:country_id => "107", :name => "Raisinghnagar", :aliases => "Raisinghnagar,RÄisinghnagar,RÄisinghnagar", :latitude => "29.53583", :longitude => "73.44917").save
City.new(:country_id => "107", :name => "Raisen", :aliases => "Raisen,Raisen", :latitude => "23.33333", :longitude => "77.8").save
City.new(:country_id => "107", :name => "Raipur", :aliases => ",RÄipur", :latitude => "30.31667", :longitude => "78.1").save
City.new(:country_id => "107", :name => "Raipur", :aliases => ",Raipur", :latitude => "26.05", :longitude => "74.01667").save
City.new(:country_id => "107", :name => "Raipur", :aliases => "Raipur,Raipur", :latitude => "21.23333", :longitude => "81.63333").save
City.new(:country_id => "107", :name => "Raikot", :aliases => "Raikot,RÄikot,RÄikot", :latitude => "30.65", :longitude => "75.6").save
City.new(:country_id => "107", :name => "Raigarh Fort", :aliases => "Raigad,Raigad District,Raigad Fort,Raigarh,Raigarh District,Raigarh Fort,Raigarh Fort", :latitude => "18.25", :longitude => "73.43333").save
City.new(:country_id => "107", :name => "Raigarh", :aliases => "Raigarh,Rajgarkh,Ð Ð°Ð¹Ð³Ð°ÑÑ,Raigarh", :latitude => "21.9", :longitude => "83.4").save
City.new(:country_id => "107", :name => "Raiganj", :aliases => "Raiganj,Rayganj,RÄiganj,RÄiganj", :latitude => "25.61667", :longitude => "88.11667").save
City.new(:country_id => "107", :name => "Raichur", :aliases => "Raichur,Rajchur,RÄichÅ«r,Ð Ð°Ð¹ÑÑÑ,RÄichÅ«r", :latitude => "16.2", :longitude => "77.36667").save
City.new(:country_id => "107", :name => "Rahuri", :aliases => "Rahuri,RÄhuri,RÄhuri", :latitude => "19.38333", :longitude => "74.65").save
City.new(:country_id => "107", :name => "Rahimatpur", :aliases => "Rahimatpur,Rahunatpur,Rahimatpur", :latitude => "17.6", :longitude => "74.2").save
City.new(:country_id => "107", :name => "Rahatgarh", :aliases => "Rahatgarh,RÄhatgarh,RÄhatgarh", :latitude => "23.78333", :longitude => "78.36667").save
City.new(:country_id => "107", :name => "Raghunathpur", :aliases => ",RaghunÄthpur", :latitude => "23.55", :longitude => "86.66667").save
City.new(:country_id => "107", :name => "Raghogarh", :aliases => "Raghogarh,Raghugarh,RÄghogarh,RÄghugarh,RÄghogarh", :latitude => "24.45", :longitude => "77.2").save
City.new(:country_id => "107", :name => "Rafiganj", :aliases => "Rafiganj,Rafiganj", :latitude => "24.81667", :longitude => "84.65").save
City.new(:country_id => "107", :name => "Rae Bareli", :aliases => ",RÄe Bareli", :latitude => "26.21667", :longitude => "81.23333").save
City.new(:country_id => "107", :name => "Radhanpur", :aliases => "Radhanpur,RÄdhanpur,RÄdhanpur", :latitude => "23.83333", :longitude => "71.6").save
City.new(:country_id => "107", :name => "Rabkavi", :aliases => ",Rabkavi", :latitude => "16.46667", :longitude => "75.1").save
City.new(:country_id => "107", :name => "Quilon", :aliases => "Coulao,CoulÃ£o,Kollam,Kullamalai,Kvilon,Quilon,keallam,kollam,ÐÐ²Ð¸Ð»Ð¾Ð½,à®à¯à®²à¯à®²à®®à¯,à´àµà´²àµà´²à´,Quilon", :latitude => "8.88333", :longitude => "76.6").save
City.new(:country_id => "107", :name => "Qasba", :aliases => "Kasba,Qasba,Qasba", :latitude => "25.85", :longitude => "87.55").save
City.new(:country_id => "107", :name => "Qadian", :aliases => "Kadian,KÄdiÄn,Qadian,QÄdiÄn,QÄdiÄn", :latitude => "31.81778", :longitude => "75.39194").save
City.new(:country_id => "107", :name => "Puttur", :aliases => "Puttur,PuttÅ«r,PuttÅ«r", :latitude => "13.45", :longitude => "79.55").save
City.new(:country_id => "107", :name => "Puttur", :aliases => "Puttur,PuttÅ«r,PuttÅ«r", :latitude => "12.76667", :longitude => "75.21667").save
City.new(:country_id => "107", :name => "Pushkar", :aliases => "Pushkar,Pushkar", :latitude => "26.5", :longitude => "74.55").save
City.new(:country_id => "107", :name => "Pusad", :aliases => "Pusad,Pusad", :latitude => "19.9", :longitude => "77.58333").save
City.new(:country_id => "107", :name => "Purwa", :aliases => "Purwa,Purwa", :latitude => "26.46667", :longitude => "80.78333").save
City.new(:country_id => "107", :name => "Puruliya", :aliases => "Purulia,Puruliya,Puruliya", :latitude => "23.33333", :longitude => "86.36667").save
City.new(:country_id => "107", :name => "Purnia", :aliases => "Purnea,Purnia,PÅ«rnia,PÅ«rnia", :latitude => "25.78333", :longitude => "87.46667").save
City.new(:country_id => "107", :name => "Purna", :aliases => "Purna,PÅ«rna,ÐÑÑÐ½Ð°,PÅ«rna", :latitude => "19.18333", :longitude => "77.05").save
City.new(:country_id => "107", :name => "Puri", :aliases => "Jagannath,Jagannathpur,JagannÄth,Puri,Puri District,PurÃ®,puri,pwry,ÐÑÑÐ¸,×¤××¨×,à¦ªà§à¦°à¦¿,à®ªà¯à®°à®¿,ãã¼ãª,Puri", :latitude => "19.8", :longitude => "85.85").save
City.new(:country_id => "107", :name => "Puranpur", :aliases => "Puranpur,PÅ«ranpur,PÅ«ranpur", :latitude => "28.51667", :longitude => "80.15").save
City.new(:country_id => "107", :name => "Pupri", :aliases => "Janakpur Road,Pupri,Pupri", :latitude => "26.48333", :longitude => "85.71667").save
City.new(:country_id => "107", :name => "Punjai Puliyampatti", :aliases => ",Punjai Puliyampatti", :latitude => "11.35", :longitude => "77.2").save
City.new(:country_id => "107", :name => "Punganuru", :aliases => ",PunganÅ«ru", :latitude => "13.36667", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Pune", :aliases => "Poona,Puna,Pune,poona,pu na,pune,pune sahara,pwnh,ÐÑÐ½Ð°,×¤×× ×,à¤ªà¥à¤£à¥,à¤ªà¥à¤£à¥ à¤¶à¤¹à¤°,à¦ªà§à¦¨à§,à®ªà¯à®©à¯,à²ªà³à²£à³,ããã¼,æµ¦é£,Pune", :latitude => "18.51957", :longitude => "73.85535").save
City.new(:country_id => "107", :name => "Pundri", :aliases => "Pundri,PÅ«ndri,PÅ«ndri", :latitude => "29.75", :longitude => "76.55").save
City.new(:country_id => "107", :name => "Punasa", :aliases => ",PunÄsa", :latitude => "22.23333", :longitude => "76.4").save
City.new(:country_id => "107", :name => "Punalur", :aliases => "Punalur,PunalÅ«r,PunalÅ«r", :latitude => "9", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Punahana", :aliases => "Punahana,PunÄhÄna,PunÄhÄna", :latitude => "27.86667", :longitude => "77.2").save
City.new(:country_id => "107", :name => "Pulwama", :aliases => "Pulawom,Pulwama,Pulwama", :latitude => "33.88333", :longitude => "74.91667").save
City.new(:country_id => "107", :name => "Puliyangudi", :aliases => "Puliyangudi,Puliyankudi,Puliyangudi", :latitude => "9.16667", :longitude => "77.41667").save
City.new(:country_id => "107", :name => "Pulivendla", :aliases => ",Pulivendla", :latitude => "14.41667", :longitude => "78.23333").save
City.new(:country_id => "107", :name => "Pulgaon", :aliases => "Pulgaon,Pulgaon", :latitude => "20.73333", :longitude => "78.33333").save
City.new(:country_id => "107", :name => "Pukhrayan", :aliases => "Pukhrayan,PukhrÄyÄn,PukhrÄyÄn", :latitude => "26.23333", :longitude => "79.85").save
City.new(:country_id => "107", :name => "Pudukkottai", :aliases => "Poodoocottah,Pudukattai,Pudukkottai,Pudukkottai-Trichinopoly,Pudukotah,pudo~ukkottai,putukkottai,à®ªà¯à®¤à¯à®à¯à®à¯à®à¯à®à¯,ããã¥ãã³ã¼ãã¿ã¤,Pudukkottai", :latitude => "10.38333", :longitude => "78.81667").save
City.new(:country_id => "107", :name => "Proddatur", :aliases => "Proddatur,ProddatÅ«r,ProddatÅ«r", :latitude => "14.73333", :longitude => "78.55").save
City.new(:country_id => "107", :name => "Pratapgarh", :aliases => "Partabgarh,Partapgarh,Pratabgarh,Pratapgarh,PratÄbgarh,PratÄpgarh,PratÄpgarh", :latitude => "24.03333", :longitude => "74.78333").save
City.new(:country_id => "107", :name => "Port Blair", :aliases => "Port Blair,Port-Blehr,bu lai er gang,porta bleyara,potoburea,ÐÐ¾ÑÑ-ÐÐ»ÑÑ,à¤ªà¥à¤°à¥à¤ à¤¬à¥à¤²à¥à¤¯à¤°,à¦ªà§à¦°à§à¦ à¦¬à§à¦²à§à¦¯à¦¼à¦¾à¦°,ãã¼ããã¬ã¢,å¸èç¾æ¸¯,Port Blair", :latitude => "11.66667", :longitude => "92.75").save
City.new(:country_id => "107", :name => "Porsa", :aliases => "Porsa,ÐÐ¾ÑÑÐ°,Porsa", :latitude => "26.67", :longitude => "78.37472").save
City.new(:country_id => "107", :name => "Porbandar", :aliases => "Poorbunder,Porbandar,Porbandarom,Port Porbandar,Purbandar,bo er ben de er,porabandara,ÐÐ¾ÑÐ±Ð°Ð½Ð´Ð°ÑÐ¾Ð¼,à¤ªà¥à¤°à¤¬à¤¨à¥à¤¦à¤°,åå°æ¬å¾·å°,Porbandar", :latitude => "21.64219", :longitude => "69.60929").save
City.new(:country_id => "107", :name => "Poonamallee", :aliases => "Poonamallee,Poonamallee", :latitude => "13.04833", :longitude => "80.1075").save
City.new(:country_id => "107", :name => "Ponnuru", :aliases => ",PonnÅ«ru", :latitude => "16.06667", :longitude => "80.56667").save
City.new(:country_id => "107", :name => "Ponneri", :aliases => "Ponneri,Ponneri", :latitude => "13.31667", :longitude => "80.2").save
City.new(:country_id => "107", :name => "Ponnani", :aliases => "Ponani,Ponnani,PonnÄni,PonnÄni", :latitude => "10.76667", :longitude => "75.9").save
City.new(:country_id => "107", :name => "Pondicherry", :aliases => "Pondicero,Pondicheri,Pondicherry,Pondichery,PondichÃ©ri,PondichÃ©ry,Pondiseri,Pondisheri,PondiÄero,Puduchcheri,Puducherri,Puducherry,Puduvai,Territoire de Pondichery,Territoire de PondichÃ©ry,ben de zhi li,ben de zhi li shi,pandiceri,panticceri,pondiceri,pondisheri,ÐÐ¾Ð½Ð´Ð¸ÑÐµÑÐ¸,ÐÐ¾Ð½Ð´ÑÑÐµÑÑ,à¤ªà¥à¤£à¥à¤¡à¤¿à¤à¥à¤°à¥,à¦ªà¦¨à§à¦¡à¦¿à¦à§à¦°à§,àªªà«àªàª¡àª¿àªà«àª°à«,à®ªà®¾à®£à¯à®à®¿à®à¯à®à¯à®°à®¿,áááááá¨áá á,ãã³ãã£ã·ã§ãª,æ¬å°æ²»é,æ¬å°æ²»éå¸,Pondicherry", :latitude => "11.93", :longitude => "79.83").save
City.new(:country_id => "107", :name => "Ponda", :aliases => "Cassabe de Ponda,CassabÃ© de PondÃ¡,Ponda,Ponda", :latitude => "15.4", :longitude => "74.01667").save
City.new(:country_id => "107", :name => "Polur", :aliases => "Polur,PolÅ«r,PolÅ«r", :latitude => "12.5", :longitude => "79.13333").save
City.new(:country_id => "107", :name => "Pollachi", :aliases => "Pollachi,PollÄchi,PollÄchi", :latitude => "10.66667", :longitude => "77.01667").save
City.new(:country_id => "107", :name => "Polasara", :aliases => "Polasara,Polasara", :latitude => "19.7", :longitude => "84.81667").save
City.new(:country_id => "107", :name => "Pokaran", :aliases => ",Pokaran", :latitude => "26.91667", :longitude => "71.91667").save
City.new(:country_id => "107", :name => "Pithoragarh", :aliases => "Pathorgarh,Pithoragarh,Pithoragari,PithorÄgarh,PithorÄgarh", :latitude => "29.58333", :longitude => "80.21667").save
City.new(:country_id => "107", :name => "Pithapuram", :aliases => "Pithapuram,PithÄpuram,PithÄpuram", :latitude => "17.11667", :longitude => "82.26667").save
City.new(:country_id => "107", :name => "Piro", :aliases => ",Piro", :latitude => "25.33333", :longitude => "84.41667").save
City.new(:country_id => "107", :name => "Piriyapatna", :aliases => "Piriyapatna,PiriyÄpatna,PiriyÄpatna", :latitude => "12.33972", :longitude => "76.09917").save
City.new(:country_id => "107", :name => "Piravam", :aliases => "Piravam,Piravom,Piravam", :latitude => "9.86667", :longitude => "76.5").save
City.new(:country_id => "107", :name => "Pipri", :aliases => "Peepri,Pipri,PÄ«pri,PÄ«pri", :latitude => "19.8", :longitude => "75.53333").save
City.new(:country_id => "107", :name => "Pipraich", :aliases => "Pipraich,Pipraich", :latitude => "26.82639", :longitude => "83.53").save
City.new(:country_id => "107", :name => "Pipili", :aliases => "Pipili,Pipli,Pipili", :latitude => "20.11667", :longitude => "85.83333").save
City.new(:country_id => "107", :name => "Pipar", :aliases => ",PÄ«pÄr", :latitude => "26.38556", :longitude => "73.53778").save
City.new(:country_id => "107", :name => "Pinjaur", :aliases => ",Pinjaur", :latitude => "30.79722", :longitude => "76.91722").save
City.new(:country_id => "107", :name => "Pindwara", :aliases => "Pindwara,PindwÄra,PindwÄra", :latitude => "24.8", :longitude => "73.06667").save
City.new(:country_id => "107", :name => "Pinahat", :aliases => "Pinahat,PinÄhat,PinÄhat", :latitude => "26.88389", :longitude => "78.37806").save
City.new(:country_id => "107", :name => "Pimpri", :aliases => ",Pimpri", :latitude => "18.61667", :longitude => "73.8").save
City.new(:country_id => "107", :name => "Pilkhua", :aliases => "Pilkhua,Pilkhuwa,Pilkhua", :latitude => "28.71667", :longitude => "77.65").save
City.new(:country_id => "107", :name => "Pilibhit", :aliases => "Pilibhhit,Pilibhit,Pilibkhit,PÄ«lÄ«bhÄ«t,ÐÐ¸Ð»Ð¸Ð±ÑÐ¸Ñ,PÄ«lÄ«bhÄ«t", :latitude => "28.63333", :longitude => "79.8").save
City.new(:country_id => "107", :name => "Pilibangan", :aliases => "Pilibanga,Pilibangan,Pilibangan", :latitude => "29.45", :longitude => "74.08333").save
City.new(:country_id => "107", :name => "Pilani", :aliases => "Pilani,PilÄni,PilÄni", :latitude => "28.3684", :longitude => "75.6041").save
City.new(:country_id => "107", :name => "Pihani", :aliases => "Pihani,PihÄni,PihÄni", :latitude => "27.63333", :longitude => "80.2").save
City.new(:country_id => "107", :name => "Phulpur", :aliases => ",PhÅ«lpur", :latitude => "25.55", :longitude => "82.1").save
City.new(:country_id => "107", :name => "Phulera", :aliases => "Phalera,Phulera,Phulera", :latitude => "26.86667", :longitude => "75.23333").save
City.new(:country_id => "107", :name => "Phulabani", :aliases => "Phulabani,PhulabÄni,Phulbam,Phulbani,PhulbÄni,PhulabÄni", :latitude => "20.46667", :longitude => "84.23333").save
City.new(:country_id => "107", :name => "Phirangipuram", :aliases => "Phirangipuram,Phirangipuram", :latitude => "16.3", :longitude => "80.26667").save
City.new(:country_id => "107", :name => "Phillaur", :aliases => "Phillaur,Phillaur", :latitude => "31.02917", :longitude => "75.78417").save
City.new(:country_id => "107", :name => "Phek", :aliases => ",Phek", :latitude => "25.66667", :longitude => "94.5").save
City.new(:country_id => "107", :name => "Phaphund", :aliases => "Phaphund,PhaphÅ«nd,PhaphÅ«nd", :latitude => "26.6", :longitude => "79.46667").save
City.new(:country_id => "107", :name => "Phaltan", :aliases => "Phaltan,Phaltan", :latitude => "17.98333", :longitude => "74.43333").save
City.new(:country_id => "107", :name => "Phalodi", :aliases => ",Phalodi", :latitude => "27.13333", :longitude => "72.36667").save
City.new(:country_id => "107", :name => "Phalauda", :aliases => "Phalauda,Phalauda", :latitude => "29.18333", :longitude => "77.81667").save
City.new(:country_id => "107", :name => "Phagwara", :aliases => "Phagwara,PhagwÄra,PhagwÄra", :latitude => "31.21778", :longitude => "75.76944").save
City.new(:country_id => "107", :name => "Petlad", :aliases => "Petlad,PetlÄd,PetlÄd", :latitude => "22.46667", :longitude => "72.8").save
City.new(:country_id => "107", :name => "Perundurai", :aliases => "Perundurai,Perundural,Perundurai", :latitude => "11.26667", :longitude => "77.58333").save
City.new(:country_id => "107", :name => "Perumpavur", :aliases => ",PerumpÄvÅ«r", :latitude => "10.13333", :longitude => "76.48333").save
City.new(:country_id => "107", :name => "Periyanayakkanpalaiyam", :aliases => "Periyanaikanpalayam,Periyanayakkanpalaiyam,PeriyanÄyakkanpÄlaiyam,PeriyanÄyakkanpÄlaiyam", :latitude => "11.15", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Periyakulam", :aliases => "Periyakulam,Periyakulam", :latitude => "10.11667", :longitude => "77.55").save
City.new(:country_id => "107", :name => "Peravurani", :aliases => "Peravurani,Peravurni,PerÄvÅ«rani,PerÄvÅ«rani", :latitude => "10.3", :longitude => "79.18333").save
City.new(:country_id => "107", :name => "Peranampattu", :aliases => "Peranambattu,Peranampattu,PeranÄmbattu,PeranÄmpattu,Pernambut,PeranÄmpattu", :latitude => "12.93333", :longitude => "78.71667").save
City.new(:country_id => "107", :name => "Perambalur", :aliases => "Perambalur,PerambalÅ«r,PerambalÅ«r", :latitude => "11.23333", :longitude => "78.88333").save
City.new(:country_id => "107", :name => "Penukonda", :aliases => "Penukonda,Penukonda", :latitude => "14.08333", :longitude => "77.58333").save
City.new(:country_id => "107", :name => "Penugonda", :aliases => ",Penugonda", :latitude => "16.66667", :longitude => "81.73333").save
City.new(:country_id => "107", :name => "Pennagaram", :aliases => "Pennagaram,PennÄgaram,PennÄgaram", :latitude => "12.13333", :longitude => "77.9").save
City.new(:country_id => "107", :name => "Pennadam", :aliases => "Pennadam,PennÄdam,PennÄdam", :latitude => "11.4", :longitude => "79.23333").save
City.new(:country_id => "107", :name => "Pen", :aliases => ",Pen", :latitude => "18.75", :longitude => "73.08333").save
City.new(:country_id => "107", :name => "Pehowa", :aliases => "Pehowa,Pehowa", :latitude => "29.98333", :longitude => "76.58333").save
City.new(:country_id => "107", :name => "Peddapuram", :aliases => "Peddapuram,Peddapuram Town,PeddÄpuram,PeddÄpuram", :latitude => "17.08333", :longitude => "82.13333").save
City.new(:country_id => "107", :name => "Peddapalli", :aliases => ",Peddapalli", :latitude => "18.61667", :longitude => "79.36667").save
City.new(:country_id => "107", :name => "Pedana", :aliases => "Pedana,Pedana", :latitude => "16.26667", :longitude => "81.16667").save
City.new(:country_id => "107", :name => "Payyannur", :aliases => "Payyannur,PayyannÅ«r,Payyanur,PayyannÅ«r", :latitude => "12.1", :longitude => "75.2").save
City.new(:country_id => "107", :name => "Pawayan", :aliases => "Pawayan,PawÄyan,PawÄyan", :latitude => "28.06667", :longitude => "80.1").save
City.new(:country_id => "107", :name => "Pavagada", :aliases => "Pavagada,Pavugada,PÄvagada,PÄvugada,PÄvagada", :latitude => "14.1", :longitude => "77.26667").save
City.new(:country_id => "107", :name => "Pauri", :aliases => ",Pauri", :latitude => "30.15", :longitude => "78.78333").save
City.new(:country_id => "107", :name => "Pauni", :aliases => "Pauni,Pauni", :latitude => "20.78333", :longitude => "79.63333").save
City.new(:country_id => "107", :name => "Patur", :aliases => "Patur,PÄtÅ«r,PÄtÅ«r", :latitude => "20.45", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Pattukkottai", :aliases => "Pattukkottai,Pattukkottai", :latitude => "10.43333", :longitude => "79.31667").save
City.new(:country_id => "107", :name => "Patti", :aliases => ",Patti", :latitude => "31.28083", :longitude => "74.85722").save
City.new(:country_id => "107", :name => "Patnagarh", :aliases => "Patnagarh,PatnÄgarh,PatnÄgarh", :latitude => "20.71667", :longitude => "83.15").save
City.new(:country_id => "107", :name => "Patna", :aliases => "New Patna,Patna,Patna New City,ba te na,patana,patna,patona,ÐÐ°ÑÐ½Ð°,à¤ªà¤à¤¨à¤¾,à¦ªà¦¾à¦à¦¨à¦¾,à®ªà®à¯à®©à®¾,à®ªà®¾à®à¯à®©à®¾,ããã,ãããã¼,å·´ç¹é£,Patna", :latitude => "25.6", :longitude => "85.11667").save
City.new(:country_id => "107", :name => "Patiala", :aliases => "Pat'jala,Patiala,PatiÄla,ÐÐ°ÑÑÑÐ»Ð°,PatiÄla", :latitude => "30.32667", :longitude => "76.40028").save
City.new(:country_id => "107", :name => "Pathri", :aliases => "Pathri,Patri,PÄthri,ÐÐ°ÑÑÐ¸,PÄthri", :latitude => "19.25", :longitude => "76.45").save
City.new(:country_id => "107", :name => "Patharia", :aliases => "Patharia,Patharia", :latitude => "23.9", :longitude => "79.2").save
City.new(:country_id => "107", :name => "Pathardih", :aliases => "Pathardih,Pathardihi,PÄthardih,PÄthardih", :latitude => "23.66667", :longitude => "86.43333").save
City.new(:country_id => "107", :name => "Pathardi", :aliases => "Pathardi,PÄthardi,PÄthardi", :latitude => "19.16667", :longitude => "75.18333").save
City.new(:country_id => "107", :name => "Pathankot", :aliases => "Pathankot,PathÄnkot,Rathankot,PathÄnkot", :latitude => "32.28333", :longitude => "75.65").save
City.new(:country_id => "107", :name => "Pathanamthitta", :aliases => "Pathanamthitta,PathanÄmthitta,Pattanamtitta,PathanÄmthitta", :latitude => "9.26667", :longitude => "76.78333").save
City.new(:country_id => "107", :name => "Pathalgaon", :aliases => "Pathalgaon,Pathargaon,Pathalgaon", :latitude => "22.56667", :longitude => "83.46667").save
City.new(:country_id => "107", :name => "Pataudi", :aliases => "Pataudi,Pataudi", :latitude => "28.31667", :longitude => "76.78333").save
City.new(:country_id => "107", :name => "Patancheru", :aliases => "Patancheroo,Patancheru,Patancheru", :latitude => "17.53139", :longitude => "78.265").save
City.new(:country_id => "107", :name => "Patan", :aliases => "Patan,PÄtan,ÐÐ°ÑÐ°Ð½,PÄtan", :latitude => "23.83333", :longitude => "72.11667").save
City.new(:country_id => "107", :name => "Patamundai", :aliases => "Patamudai,Patamundai,PatÄmundai,PatÄmundai", :latitude => "20.56667", :longitude => "86.56667").save
City.new(:country_id => "107", :name => "Pasighat", :aliases => "Pasighat,PÄsighÄt,PÄsighÄt", :latitude => "28.06667", :longitude => "95.33333").save
City.new(:country_id => "107", :name => "Pasan", :aliases => "Pasan,PasÄn,PasÄn", :latitude => "22.85", :longitude => "82.2").save
City.new(:country_id => "107", :name => "Parvatsar", :aliases => "Parbatsar,Parvatsar,Parvatsar", :latitude => "26.88333", :longitude => "74.76667").save
City.new(:country_id => "107", :name => "Parvatipuram", :aliases => ",PÄrvatÄ«puram", :latitude => "18.78333", :longitude => "83.43333").save
City.new(:country_id => "107", :name => "Partur", :aliases => "Partur,PartÅ«r,PartÅ«r", :latitude => "19.6", :longitude => "76.21667").save
City.new(:country_id => "107", :name => "Parola", :aliases => ",PÄrola", :latitude => "20.88333", :longitude => "75.11667").save
City.new(:country_id => "107", :name => "Parli Vaijnath", :aliases => "Parli,Parli Vaijnath,Parli VaijnÄth,Purli,Purli Vaijnath,Parli VaijnÄth", :latitude => "18.85", :longitude => "76.53333").save
City.new(:country_id => "107", :name => "Parlakimidi", :aliases => "Paria Kimedi,Parlakimidi,ParlÄkimidi,PurlaKimedy,ParlÄkimidi", :latitude => "18.76667", :longitude => "84.08333").save
City.new(:country_id => "107", :name => "Parichhatgarh", :aliases => ",ParÄ«chhatgarh", :latitude => "28.98333", :longitude => "77.93333").save
City.new(:country_id => "107", :name => "Pardi", :aliases => "Pardi,PÄrdi,PÄrdi", :latitude => "20.51667", :longitude => "72.95").save
City.new(:country_id => "107", :name => "Parbhani", :aliases => "Parbaini,Parbhani,Parbhani", :latitude => "19.26667", :longitude => "76.78333").save
City.new(:country_id => "107", :name => "Paravur", :aliases => "Paravar,Paravoor,Paravur,ParavÅ«r,ParavÅ«r", :latitude => "8.78333", :longitude => "76.7").save
City.new(:country_id => "107", :name => "Parasia", :aliases => "Dongar Parasia,Dongar ParÄsia,Parasia,ParÄsia,ParÄsia", :latitude => "22.2", :longitude => "78.76667").save
City.new(:country_id => "107", :name => "Paramagudi", :aliases => ",Paramagudi", :latitude => "9.55", :longitude => "78.6").save
City.new(:country_id => "107", :name => "Paradip Garh", :aliases => "Paradeep,Paradip,Paradip Garh,Paradipur,Paradwip,ParÄdÄ«p Garh,PÄrÄdwÄ«p,ParÄdÄ«p Garh", :latitude => "20.31667", :longitude => "86.61667").save
City.new(:country_id => "107", :name => "Pappinisseri", :aliases => "Pappinisseri,Pappinissheri,PÄppinisseri,PÄppinissheri,PÄppinisseri", :latitude => "11.95", :longitude => "75.35").save
City.new(:country_id => "107", :name => "Papanasam", :aliases => "Papanasam,PapanÄsam,Pavanasi,PapanÄsam", :latitude => "10.93333", :longitude => "79.28333").save
City.new(:country_id => "107", :name => "Paonta Sahib", :aliases => "Paonta,Paonta Sahib,PÄonta SÄhib,PÄonta SÄhib", :latitude => "30.45", :longitude => "77.61667").save
City.new(:country_id => "107", :name => "Panvel", :aliases => "Panvel,Panwel,Panvel", :latitude => "18.98333", :longitude => "73.1").save
City.new(:country_id => "107", :name => "Panruti", :aliases => "Panruti,Panruti", :latitude => "11.76667", :longitude => "79.55").save
City.new(:country_id => "107", :name => "Panna", :aliases => ",Panna", :latitude => "24.71667", :longitude => "80.2").save
City.new(:country_id => "107", :name => "Panipat", :aliases => "Panipat,Panipata,PÄnÄ«pat,ÐÐ°Ð½Ð¸Ð¿Ð°ÑÐ°,PÄnÄ«pat", :latitude => "29.38889", :longitude => "76.96806").save
City.new(:country_id => "107", :name => "Panihati", :aliases => "Panihati,PÄnihÄti,PÄnihÄti", :latitude => "22.69417", :longitude => "88.37444").save
City.new(:country_id => "107", :name => "Pandua", :aliases => ",Pandua", :latitude => "23.08333", :longitude => "88.28333").save
City.new(:country_id => "107", :name => "Pandhurna", :aliases => "Pandhurna,PÄndhurna,PÄndhurna", :latitude => "21.6", :longitude => "78.51667").save
City.new(:country_id => "107", :name => "Pandharpur", :aliases => "Pandharpur,Pandharpur", :latitude => "17.66667", :longitude => "75.33333").save
City.new(:country_id => "107", :name => "Pandavapura", :aliases => "French Rocks,Hirod,Pandavapura,PÄndavapura,PÄndavapura", :latitude => "12.50056", :longitude => "76.67333").save
City.new(:country_id => "107", :name => "Panaji", :aliases => "Nova Goa,Panadzhi,Panaji,Pangim,Panjim,panaji,ÐÐ°Ð½Ð°Ð´Ð¶Ð¸,à¤ªà¤£à¤à¥,à¦ªà¦¾à¦¨à¦¾à¦à¦¿,à®ªà®£à®à®¿,à®ªà®©à®¾à®à®¿,ããã¸,Panaji", :latitude => "15.48333", :longitude => "73.83333").save
City.new(:country_id => "107", :name => "Panagar", :aliases => "Panagar,Panagar Bazar,Panagara,PÄnÄgar,PÄnÄgar", :latitude => "23.3", :longitude => "79.98333").save
City.new(:country_id => "107", :name => "Palwal", :aliases => "Palwal,Palwal", :latitude => "28.15", :longitude => "77.33333").save
City.new(:country_id => "107", :name => "Paloncha", :aliases => ",PÄloncha", :latitude => "17.6", :longitude => "80.68333").save
City.new(:country_id => "107", :name => "Palni", :aliases => "Palani,Palni,ÐÐ°Ð»Ð°Ð½Ð¸,Palni", :latitude => "10.46667", :longitude => "77.53333").save
City.new(:country_id => "107", :name => "Palmaner", :aliases => ",Palmaner", :latitude => "13.2", :longitude => "78.75").save
City.new(:country_id => "107", :name => "Pallippatti", :aliases => ",Pallippatti", :latitude => "11.93333", :longitude => "78.41667").save
City.new(:country_id => "107", :name => "Pallikondai", :aliases => "Pallikonda,Pallikondai,Pallikondai", :latitude => "12.91667", :longitude => "78.93333").save
City.new(:country_id => "107", :name => "Pallavaram", :aliases => "Pallavaram,PallÄvaram,PallÄvaram", :latitude => "12.97611", :longitude => "80.18361").save
City.new(:country_id => "107", :name => "Pallappatti", :aliases => "Pallapatti,Pallappatti,Pallappatti", :latitude => "10.7", :longitude => "77.88333").save
City.new(:country_id => "107", :name => "Palladam", :aliases => "Palladam,Palladam", :latitude => "10.98333", :longitude => "77.3").save
City.new(:country_id => "107", :name => "Palkonda", :aliases => "Palakonda,Palkonda,PÄlkonda,PÄlkonda", :latitude => "18.6", :longitude => "83.75").save
City.new(:country_id => "107", :name => "Palitana", :aliases => "Palitana,PÄlitÄna,ÐÐ°Ð»Ð¸ÑÐ°Ð½Ð°,PÄlitÄna", :latitude => "21.51667", :longitude => "71.83333").save
City.new(:country_id => "107", :name => "Palia Kalan", :aliases => "Palia,Palia Kalan,PaliÄ KalÄn,PaliÄ KalÄn", :latitude => "28.45", :longitude => "80.58333").save
City.new(:country_id => "107", :name => "Pali", :aliases => "Pali,Pali-Marwar,PÄli,ÐÐ°Ð»Ð¸,PÄli", :latitude => "25.76667", :longitude => "73.33333").save
City.new(:country_id => "107", :name => "Pali", :aliases => "Birsinghapur,Pali,PÄli,ÐÐ°Ð»Ð¸,PÄli", :latitude => "23.35", :longitude => "81.05").save
City.new(:country_id => "107", :name => "Palghat", :aliases => "Palakkad,PÄlghÄt", :latitude => "10.78333", :longitude => "76.65").save
City.new(:country_id => "107", :name => "Palghar", :aliases => ",PÄlghar", :latitude => "19.68333", :longitude => "72.75").save
City.new(:country_id => "107", :name => "Palera", :aliases => "Palera,Palera", :latitude => "25.01667", :longitude => "79.23333").save
City.new(:country_id => "107", :name => "Palasa", :aliases => ",PalÄsa", :latitude => "18.76667", :longitude => "84.41667").save
City.new(:country_id => "107", :name => "Palanpur", :aliases => "Palanpur,PÄlanpur,PÄlanpur", :latitude => "24.16667", :longitude => "72.43333").save
City.new(:country_id => "107", :name => "Palakollu", :aliases => "Palacole,Palakollu,PÄlakollu,PÄlakollu", :latitude => "16.53333", :longitude => "81.73333").save
City.new(:country_id => "107", :name => "Palakkodu", :aliases => "Palakkodu,Palakod,PÄlakkodu,PÄlakkodu", :latitude => "12.3", :longitude => "78.08333").save
City.new(:country_id => "107", :name => "Pakaur", :aliases => ",PÄkaur", :latitude => "24.63333", :longitude => "87.85").save
City.new(:country_id => "107", :name => "Pakala", :aliases => "Pakal,Pakala,PÄkÄla,PÄkÄla", :latitude => "13.46667", :longitude => "79.11667").save
City.new(:country_id => "107", :name => "Paithan", :aliases => "Paithan,Paithan", :latitude => "19.48333", :longitude => "75.38333").save
City.new(:country_id => "107", :name => "Pahasu", :aliases => "Pahasu,PahÄsu,PahÄsu", :latitude => "28.18333", :longitude => "78.05").save
City.new(:country_id => "107", :name => "Padrauna", :aliases => "Padrauna,Padrauna", :latitude => "26.9025", :longitude => "83.98194").save
City.new(:country_id => "107", :name => "Padra", :aliases => "Padra,Padra", :latitude => "22.23333", :longitude => "73.08333").save
City.new(:country_id => "107", :name => "Padmanabhapuram", :aliases => "Padmanabhapuram,PadmanÄbhapuram,PadmanÄbhapuram", :latitude => "8.23333", :longitude => "77.33333").save
City.new(:country_id => "107", :name => "Padampur", :aliases => "Padampur,Padampur", :latitude => "29.68333", :longitude => "73.61667").save
City.new(:country_id => "107", :name => "Padampur", :aliases => "Padampur,Podampur,Padampur", :latitude => "20.98333", :longitude => "83.06667").save
City.new(:country_id => "107", :name => "Pachperwa", :aliases => "Pachperwa,Pachperwa", :latitude => "27.51667", :longitude => "82.65").save
City.new(:country_id => "107", :name => "Pachora", :aliases => "Pachora,PÄchora,PÄchora", :latitude => "20.66667", :longitude => "75.35").save
City.new(:country_id => "107", :name => "Ottappalam", :aliases => "Ottapalam,Ottappalam,OttappÄlam,OttappÄlam", :latitude => "10.76667", :longitude => "76.38333").save
City.new(:country_id => "107", :name => "Osmanabad", :aliases => "Osmanabad,OsmÄnÄbÄd,Usmanabad,ÐÑÐ¼Ð°Ð½Ð°Ð±Ð°Ð´,OsmÄnÄbÄd", :latitude => "18.16667", :longitude => "76.05").save
City.new(:country_id => "107", :name => "Orai", :aliases => "Orai,Orai", :latitude => "25.98333", :longitude => "79.46667").save
City.new(:country_id => "107", :name => "Ongole", :aliases => "Ongole,onkol,à®à®à¯à®à¯à®²à¯,Ongole", :latitude => "15.5", :longitude => "80.05").save
City.new(:country_id => "107", :name => "Okha", :aliases => "Okha,Okha Port,Port Okha,ÐÑÐ°,Okha", :latitude => "22.46944", :longitude => "69.06056").save
City.new(:country_id => "107", :name => "Ojhar", :aliases => "Ojhai,Ojhar,Ojhar", :latitude => "20.1", :longitude => "73.93333").save
City.new(:country_id => "107", :name => "Obra", :aliases => ",Obra", :latitude => "24.41667", :longitude => "82.98333").save
City.new(:country_id => "107", :name => "Nuzvid", :aliases => "Nuzvid,NÅ«zvÄ«d,NÅ«zvÄ«d", :latitude => "16.78333", :longitude => "80.85").save
City.new(:country_id => "107", :name => "Nurpur", :aliases => ",NÅ«rpur", :latitude => "29.15", :longitude => "78.41667").save
City.new(:country_id => "107", :name => "North Lakhimpur", :aliases => "Lakhimpur,North Lakhimpur,North Lakhimpur", :latitude => "27.23333", :longitude => "94.11667").save
City.new(:country_id => "107", :name => "North Guwahati", :aliases => "North Gauhati,North GauhÄti,North Guwahati,North GuwÄhÄti,North GuwÄhÄti", :latitude => "26.20139", :longitude => "91.72361").save
City.new(:country_id => "107", :name => "Nongstoin", :aliases => "Nongstoin,Nongstoin", :latitude => "25.51667", :longitude => "91.26667").save
City.new(:country_id => "107", :name => "Nokha", :aliases => "Noka,Nokha,Nokha mani,Nokhamandi,Nokha", :latitude => "27.6", :longitude => "73.41667").save
City.new(:country_id => "107", :name => "Nohar", :aliases => "Nohar,Nohor Tehsils,Nohar", :latitude => "29.18333", :longitude => "74.76667").save
City.new(:country_id => "107", :name => "Noamundi", :aliases => "Noamundi,NoÄmundi,NoÄmundi", :latitude => "22.15", :longitude => "85.53333").save
City.new(:country_id => "107", :name => "Nizamabad", :aliases => ",NizÄmÄbÄd", :latitude => "18.66667", :longitude => "78.11667").save
City.new(:country_id => "107", :name => "Nirmali", :aliases => "Nirmali,NirmÄli,NirmÄli", :latitude => "26.31667", :longitude => "86.58333").save
City.new(:country_id => "107", :name => "Nirmal", :aliases => "Nirmal,Nirmala,ÐÐ¸ÑÐ¼Ð°Ð»Ð°,Nirmal", :latitude => "19.1", :longitude => "78.35").save
City.new(:country_id => "107", :name => "Nipani", :aliases => "Nimpani,Nipani,NipÄni,NipÄni", :latitude => "16.4", :longitude => "74.38333").save
City.new(:country_id => "107", :name => "Nim ka Thana", :aliases => ",NÄ«m ka ThÄna", :latitude => "27.73333", :longitude => "75.8").save
City.new(:country_id => "107", :name => "Nimbahera", :aliases => "Nimbahera,NÄ«mbÄhera,NÄ«mbÄhera", :latitude => "24.61667", :longitude => "74.68333").save
City.new(:country_id => "107", :name => "Nimaparha", :aliases => "Nimapara,Nimaparha,NimapÄra,NimÄparha,NimÄparha", :latitude => "20.06667", :longitude => "86.01667").save
City.new(:country_id => "107", :name => "Nimaj", :aliases => ",NÄ«mÄj", :latitude => "26.14972", :longitude => "74").save
City.new(:country_id => "107", :name => "Nilokheri", :aliases => "Nilokeri,Nilokhera,Nilokheri,Nilu Kheri,NÄ«lÅ« Kheri,Nilokheri", :latitude => "29.83333", :longitude => "76.91667").save
City.new(:country_id => "107", :name => "Nileshwar", :aliases => ",NÄ«leshwar", :latitude => "12.25", :longitude => "75.1").save
City.new(:country_id => "107", :name => "Nilanga", :aliases => "Nilanga,Nilanga", :latitude => "18.1", :longitude => "76.76667").save
City.new(:country_id => "107", :name => "Nilakkottai", :aliases => "Nilakkottai,Nilakkottai-Madura,Nilakkottai", :latitude => "10.16667", :longitude => "77.86667").save
City.new(:country_id => "107", :name => "Nilgiri", :aliases => "Nilagiri,Nilgiri,NÄ«lgiri,Raj Nilgiri,NÄ«lgiri", :latitude => "21.45806", :longitude => "86.76694").save
City.new(:country_id => "107", :name => "Nihtaur", :aliases => ",Nihtaur", :latitude => "29.33333", :longitude => "78.38333").save
City.new(:country_id => "107", :name => "Nidadavole", :aliases => "Nidadavol,Nidadavole,Nidadavole", :latitude => "16.91667", :longitude => "81.66667").save
City.new(:country_id => "107", :name => "Nichlaul", :aliases => "Nichlaul,Nichlaul", :latitude => "27.31667", :longitude => "83.73333").save
City.new(:country_id => "107", :name => "Neyyattinkara", :aliases => "Neyattinkara,Neyyattinkara,NeyyÄttinkara,NeyyÄttinkara", :latitude => "8.4", :longitude => "77.08333").save
City.new(:country_id => "107", :name => "New Delhi", :aliases => "Dellium Novum,Dilli,DillÃ­,N'ju-Deli,Neo Delchi,Neu-Delhi,Nev Deli,New Delhi,New Dilli,Nju Delkhi,Nov-Delhio,Nova Delhi,Nova Deli,Nova Deli - na'i dilli,Nova Deli - à¤¨à¤ à¤¦à¤¿à¤²à¥à¤²à¥,Nova-Delhi,Nove Dilli,NovÃ© DillÃ­,Nueba Deli,Nueva Delhi,Nuova Delhi,Nyja Deli,Nyu Deli,NÃ²va Delhi,NÃ½ja DelÃ­,Yeni Delhi,na'i dilli,naya dilli,niu-deli,niwde li,nyudelli,nyuderi,nyw dlhy,nywdlhy,putu tilli,xin de li,ÎÎ­Î¿ ÎÎµÎ»ÏÎ¯,ÐÑ ÐÐµÐ»ÑÐ¸,ÐÐµÐ² ÐÐµÐ»Ð¸,ÐÑÑ-ÐÐµÐ»Ð¸,ÕÕµÕ¸Ö Ô´Õ¥Õ¬Õ«,× ×× ××××,ÙÙÙØ¯ÙÙÙ,à¤¨à¤ à¤¦à¤¿à¤²à¥à¤²à¥,à¦¨à¦¯à¦¼à¦¾ à¦¦à¦¿à¦²à§à¦²à§,à®ªà¯à®¤à¯ à®¤à®¿à®²à¯à®²à®¿,à¸à¸´à¸§à¹à¸à¸¥à¸µ,à½à½ºà½ à½´à¼à½à½²à½£à¼à½£à½²à½ à½²,ááá£-áááá,áá á´á,ãã¥ã¼ããªã¼,æ°å¾·é,ë´ë¸ë¦¬,New Delhi", :latitude => "28.63576", :longitude => "77.22445").save
City.new(:country_id => "107", :name => "Neral", :aliases => "Neral,Neral", :latitude => "19.03333", :longitude => "73.31667").save
City.new(:country_id => "107", :name => "Nepa Nagar", :aliases => ",Nepa Nagar", :latitude => "21.46667", :longitude => "76.4").save
City.new(:country_id => "107", :name => "Nellore", :aliases => "Nellore,Nellore", :latitude => "14.43333", :longitude => "79.96667").save
City.new(:country_id => "107", :name => "Nellikkuppam", :aliases => "Nellikkuppam,Nellikuppami,Nellikkuppam", :latitude => "11.76667", :longitude => "79.68333").save
City.new(:country_id => "107", :name => "Nelamangala", :aliases => ",Nelamangala", :latitude => "13.10222", :longitude => "77.39").save
City.new(:country_id => "107", :name => "Nedumangad", :aliases => "Nedumangad,NedumangÄd,NedumangÄd", :latitude => "8.6", :longitude => "77").save
City.new(:country_id => "107", :name => "Nayudupeta", :aliases => "Nayudupet,Nayudupeta,NÄyudupeta,NÄyudupeta", :latitude => "13.9", :longitude => "79.9").save
City.new(:country_id => "107", :name => "Nayagarh", :aliases => "Nayagarh,NayÄgarh,NayÄgarh", :latitude => "20.13333", :longitude => "85.1").save
City.new(:country_id => "107", :name => "Nawashahr", :aliases => ",NawÄshahr", :latitude => "31.11667", :longitude => "76.13333").save
City.new(:country_id => "107", :name => "Nawalgarh", :aliases => "Nawalgarh,Nawalgarh", :latitude => "27.85", :longitude => "75.26667").save
City.new(:country_id => "107", :name => "Nawai", :aliases => ",Nawai", :latitude => "26.35", :longitude => "75.91667").save
City.new(:country_id => "107", :name => "Nawada", :aliases => "Nawada,NawÄda,NawÄda", :latitude => "24.88333", :longitude => "85.53333").save
City.new(:country_id => "107", :name => "Nawabganj", :aliases => ",NawÄbganj", :latitude => "28.55", :longitude => "79.63333").save
City.new(:country_id => "107", :name => "Nawabganj", :aliases => "Nawabgang,Nawabganj,NawÄbganj,NawÄbganj", :latitude => "26.93333", :longitude => "81.21667").save
City.new(:country_id => "107", :name => "Nawabganj", :aliases => ",NawÄbganj", :latitude => "26.86667", :longitude => "82.13333").save
City.new(:country_id => "107", :name => "Nawa", :aliases => ",NÄwa", :latitude => "27.01667", :longitude => "75").save
City.new(:country_id => "107", :name => "Navalgund", :aliases => "Navalgund,Navalgund", :latitude => "15.56667", :longitude => "75.36667").save
City.new(:country_id => "107", :name => "Navadwip", :aliases => "Nabadurip,Nabadwip,Nadia,Navadvip,Navadwip,NavadwÄ«p,ÐÐ°Ð²Ð°Ð´Ð²Ð¸Ð¿,NavadwÄ«p", :latitude => "23.41667", :longitude => "88.36667").save
City.new(:country_id => "107", :name => "Nautanwa", :aliases => "Nautanwa,Nautanwa Bazar,Nautanwa", :latitude => "27.43333", :longitude => "83.41667").save
City.new(:country_id => "107", :name => "Naugachhia", :aliases => "Naugachhia,Naugachia,Naugachhia", :latitude => "25.4", :longitude => "87.1").save
City.new(:country_id => "107", :name => "Nattam", :aliases => "Nattam,Nuttam,Nattam", :latitude => "10.23333", :longitude => "78.23333").save
City.new(:country_id => "107", :name => "Nathdwara", :aliases => "Nathdwara,Nathwara,NÄthdwÄra,NÄthdwÄra", :latitude => "24.93333", :longitude => "73.81667").save
City.new(:country_id => "107", :name => "Nasrullahganj", :aliases => "Nasrullaganj,Nasrullahganj,Nasrullahganj", :latitude => "22.68333", :longitude => "77.26667").save
City.new(:country_id => "107", :name => "Nasriganj", :aliases => "Nasriganj,Nasriganji,NÄsriganj,NÄsriganj", :latitude => "25.05", :longitude => "84.33333").save
City.new(:country_id => "107", :name => "Naspur", :aliases => "Naspur,NÄspur,NÄspur", :latitude => "18.83333", :longitude => "79.45").save
City.new(:country_id => "107", :name => "Nasirabad", :aliases => ",NasÄ«rÄbÄd", :latitude => "26.3", :longitude => "74.73333").save
City.new(:country_id => "107", :name => "Nasik", :aliases => "Nasik,NÄsik,NÄsik", :latitude => "19.98333", :longitude => "73.8").save
City.new(:country_id => "107", :name => "Narwar", :aliases => ",Narwar", :latitude => "25.65", :longitude => "77.9").save
City.new(:country_id => "107", :name => "Narwana", :aliases => "Narwana,Narwanal,NarwÄna,NarwÄna", :latitude => "29.61667", :longitude => "76.11667").save
City.new(:country_id => "107", :name => "Narsipatnam", :aliases => "Narsipatnam,NarsÄ«patnam,NarsÄ«patnam", :latitude => "17.66667", :longitude => "82.61667").save
City.new(:country_id => "107", :name => "Narsinghgarh", :aliases => ",Narsinghgarh", :latitude => "23.7", :longitude => "77.1").save
City.new(:country_id => "107", :name => "Narsimhapur", :aliases => "Narsimahpur,Narsimhapur,Narsinghpur,Narsimhapur", :latitude => "22.95", :longitude => "79.2").save
City.new(:country_id => "107", :name => "Narnaund", :aliases => "Narnaund,NÄrnaund,NÄrnaund", :latitude => "29.21667", :longitude => "76.15").save
City.new(:country_id => "107", :name => "Narnaul", :aliases => "Narnaul,NÄrnaul,NÄrnaul", :latitude => "28.04444", :longitude => "76.10833").save
City.new(:country_id => "107", :name => "Nargund", :aliases => "Nargund,Nargund", :latitude => "15.71667", :longitude => "75.38333").save
City.new(:country_id => "107", :name => "Naregal", :aliases => "Naregal,Naregal", :latitude => "15.58333", :longitude => "75.81667").save
City.new(:country_id => "107", :name => "Narayanpet", :aliases => "Narayanpet,NÄrÄyanpet,NÄrÄyanpet", :latitude => "16.73333", :longitude => "77.5").save
City.new(:country_id => "107", :name => "Narayangarh", :aliases => "Naraingarh,Narayangarh,NÄrÄyangarh,NÄrÄyangarh", :latitude => "30.48333", :longitude => "77.13333").save
City.new(:country_id => "107", :name => "Naravarikuppam", :aliases => "Naravanikuppam,Naravarikuppam,NaravÄnikuppam,NÄravÄrikuppam,NÄravÄrikuppam", :latitude => "13.19556", :longitude => "80.17417").save
City.new(:country_id => "107", :name => "Naraura", :aliases => ",Naraura", :latitude => "28.2", :longitude => "78.38333").save
City.new(:country_id => "107", :name => "Narauli", :aliases => "Narauli,Narauli", :latitude => "28.5", :longitude => "78.71667").save
City.new(:country_id => "107", :name => "Narasaraopet", :aliases => "Narasaraopet,Narasaraopet", :latitude => "16.25", :longitude => "80.06667").save
City.new(:country_id => "107", :name => "Narasapur", :aliases => ",Narasapur", :latitude => "16.45", :longitude => "81.66667").save
City.new(:country_id => "107", :name => "Narasannapeta", :aliases => "Narasannapeta,Narsannapet,Narasannapeta", :latitude => "18.41667", :longitude => "84.05").save
City.new(:country_id => "107", :name => "Naraini", :aliases => "Naraini,Naraini", :latitude => "25.18333", :longitude => "80.48333").save
City.new(:country_id => "107", :name => "Naraina", :aliases => ",Naraina", :latitude => "26.78333", :longitude => "75.2").save
City.new(:country_id => "107", :name => "Napasar", :aliases => ",NapÄsar", :latitude => "27.96667", :longitude => "73.55").save
City.new(:country_id => "107", :name => "Nanpara", :aliases => "Nanpara,NÄnpÄra,NÄnpÄra", :latitude => "27.86667", :longitude => "81.5").save
City.new(:country_id => "107", :name => "Nanjangud", :aliases => "Nanjangud,Nanjangud Town,NanjangÅ«d,NanjangÅ«d", :latitude => "12.11972", :longitude => "76.68278").save
City.new(:country_id => "107", :name => "Nangloi Jat", :aliases => "Nangloi,Nangloi Jat,NÄngloi JÄt,NÄngloi JÄt", :latitude => "28.68333", :longitude => "77.06667").save
City.new(:country_id => "107", :name => "Nangal", :aliases => "Nangal,NÄngal,ÐÐ°Ð½Ð³Ð°Ð»,NÄngal", :latitude => "31.36667", :longitude => "76.38333").save
City.new(:country_id => "107", :name => "Nandyal", :aliases => "Nandial,Nandyal,Nandyala,NandyÄl,NandyÄla,NandyÄl", :latitude => "15.48333", :longitude => "78.48333").save
City.new(:country_id => "107", :name => "Nandurbar", :aliases => "Nandurbar,NandurbÄr,NandurbÄr", :latitude => "21.36667", :longitude => "74.25").save
City.new(:country_id => "107", :name => "Nandura", :aliases => "Nandur Buzruk,Nandura,Nandura Buzruk,NÄndÅ«r Buzruk,NÄndÅ«ra,NÄndÅ«ra Buzruk,NÄndÅ«ra", :latitude => "20.83333", :longitude => "76.45").save
City.new(:country_id => "107", :name => "Nandikotkur", :aliases => "Nandikotkur,NandikotkÅ«r,NandikotkÅ«r", :latitude => "15.86667", :longitude => "78.26667").save
City.new(:country_id => "107", :name => "Nandigama", :aliases => "Nandigama,NandigÄma,NandigÄma", :latitude => "16.78333", :longitude => "80.3").save
City.new(:country_id => "107", :name => "Nandgaon", :aliases => ",NÄndgaon", :latitude => "20.31667", :longitude => "74.65").save
City.new(:country_id => "107", :name => "Nanauta", :aliases => "Nanauta,Phuta Shahr,Nanauta", :latitude => "29.7125", :longitude => "77.41583").save
City.new(:country_id => "107", :name => "Namrup", :aliases => "Namrup,NÄmrup,NÄmrup", :latitude => "27.18333", :longitude => "95.33333").save
City.new(:country_id => "107", :name => "Nambiyur", :aliases => "Nambiyur,NambiyÅ«r,NambiyÅ«r", :latitude => "11.36667", :longitude => "77.33333").save
City.new(:country_id => "107", :name => "Namakkal", :aliases => "Namakkal,NÄmakkal", :latitude => "11.22126", :longitude => "78.16524").save
City.new(:country_id => "107", :name => "Namagiripettai", :aliases => "Namagiripetai,Namagiripettai,NÄmagiripettai,NÄmagiripettai", :latitude => "11.46667", :longitude => "78.26667").save
City.new(:country_id => "107", :name => "Nalhati", :aliases => ",NalhÄti", :latitude => "24.3", :longitude => "87.81667").save
City.new(:country_id => "107", :name => "Nalgonda", :aliases => "Nalgonda,nalagonda jila,nalgonda,nalkonta,ÐÐ°Ð»Ð³Ð¾Ð½Ð´Ð°,à¤¨à¤¾à¤²à¤à¥à¤à¤¡à¤¾ à¤à¤¿à¤²à¤¾,à®¨à®²à¯à®à¯à®£à¯à®à®¾,à°¨à°²à±à°à±à°à°¡,Nalgonda", :latitude => "17.05", :longitude => "79.26667").save
City.new(:country_id => "107", :name => "Naldurg", :aliases => "Naldrug,Naldurg,Naldurg", :latitude => "17.81667", :longitude => "76.3").save
City.new(:country_id => "107", :name => "Nakur", :aliases => "Nakur,NakÅ«r,NakÅ«r", :latitude => "29.91667", :longitude => "77.3").save
City.new(:country_id => "107", :name => "Nakodar", :aliases => "Nakodar,Nakodar", :latitude => "31.12583", :longitude => "75.47333").save
City.new(:country_id => "107", :name => "Najibabad", :aliases => "Najibabab,NajÄ«bÄbÄb,NajÄ«bÄbÄd", :latitude => "29.63333", :longitude => "78.33333").save
City.new(:country_id => "107", :name => "Nainwa", :aliases => "Naenwa,Nainwa,Nainwa", :latitude => "25.76667", :longitude => "75.85").save
City.new(:country_id => "107", :name => "Nainpur", :aliases => "Nainpur,Nainpur", :latitude => "22.43333", :longitude => "80.11667").save
City.new(:country_id => "107", :name => "Naini Tal", :aliases => "Nainital,Naini TÄl", :latitude => "29.39743", :longitude => "79.44686").save
City.new(:country_id => "107", :name => "Naihati", :aliases => "Naihati,NaihÄti,NaihÄti", :latitude => "22.90278", :longitude => "88.41694").save
City.new(:country_id => "107", :name => "Nahorkatiya", :aliases => "Naharkativa,Naharkatiya,Nahorkatiya,Nahorkatiya", :latitude => "27.28333", :longitude => "95.33333").save
City.new(:country_id => "107", :name => "Nahan", :aliases => "Nahan,NÄhan,NÄhan", :latitude => "30.55", :longitude => "77.3").save
City.new(:country_id => "107", :name => "Nagpur", :aliases => "Ajni,Nagpore,Nagpur,Nagpuras,NÄgpur,nagapura,nagupuru,nakpur,ÐÐ°Ð³Ð¿ÑÑ,à¤¨à¤¾à¤à¤ªà¥à¤°,à¦¨à¦¾à¦à¦ªà§à¦°,à®¨à®¾à®à¯à®ªà¯à®°à¯,ãã¼ã°ãã«,NÄgpur", :latitude => "21.15", :longitude => "79.1").save
City.new(:country_id => "107", :name => "Nagod", :aliases => "Nagod,NÄgod,NÄgod", :latitude => "24.56667", :longitude => "80.6").save
City.new(:country_id => "107", :name => "Nagina", :aliases => "Nagina,NagÄ«na,NagÄ«na", :latitude => "29.45", :longitude => "78.45").save
City.new(:country_id => "107", :name => "Nagercoil", :aliases => "Nagarkoil,Nagarkovil,Nagercoil,NÄgercoil", :latitude => "8.16667", :longitude => "77.43333").save
City.new(:country_id => "107", :name => "Nagda", :aliases => "Nagda,Nagda-Dhar,Nagda", :latitude => "23.45", :longitude => "75.41667").save
City.new(:country_id => "107", :name => "Nagaur", :aliases => "Nagaur,Nagaur Marwar,NÄgaur,NÄgaur", :latitude => "27.2", :longitude => "73.73333").save
City.new(:country_id => "107", :name => "Nagar Karnul", :aliases => "Karnul,KarnÅ«l,Nagar Karnul,NÄgar KarnÅ«l,NÄgar KarnÅ«l", :latitude => "16.4821", :longitude => "78.32471").save
City.new(:country_id => "107", :name => "Nagari", :aliases => "Nagari,Nagari", :latitude => "13.33333", :longitude => "79.58333").save
City.new(:country_id => "107", :name => "Nagar", :aliases => ",Nagar", :latitude => "27.43333", :longitude => "77.1").save
City.new(:country_id => "107", :name => "Nagappattinam", :aliases => "Nagapatinam,Nagapattinam,Nagappattinam,Negapainttam City,Negapatam,Negapattinam,NÄgappattinam,nagappattinamu,nagappattinamu xian,nakappattinam,à®¨à®¾à®à®ªà¯à®ªà®à¯à®à®¿à®©à®®à¯,ãã¼ã¬ããããã£ãã ,ãã¼ã¬ããããã£ãã ç,NÄgappattinam", :latitude => "10.76667", :longitude => "79.83333").save
City.new(:country_id => "107", :name => "Nagamangala", :aliases => "Nagamangala,NÄgamangala,NÄgamangala", :latitude => "12.81556", :longitude => "76.7575").save
City.new(:country_id => "107", :name => "Nadiad", :aliases => "Hadiad,Nadiad,NadiÄd,Naidad,NadiÄd", :latitude => "22.7", :longitude => "72.86667").save
City.new(:country_id => "107", :name => "Nadbai", :aliases => "Nadbai,NÄdbai,NÄdbai", :latitude => "27.23333", :longitude => "77.2").save
City.new(:country_id => "107", :name => "Nadapuram", :aliases => "Kummankod,Nadapuram,NÄdÄpuram,NÄdÄpuram", :latitude => "11.7", :longitude => "75.66667").save
City.new(:country_id => "107", :name => "Nabinagar", :aliases => "Nabinagar,NabÄ«nagar,NabÄ«nagar", :latitude => "24.61667", :longitude => "84.11667").save
City.new(:country_id => "107", :name => "Nabha", :aliases => "Nabha,NÄbha,NÄbha", :latitude => "30.37472", :longitude => "76.14861").save
City.new(:country_id => "107", :name => "Mysore", :aliases => "Kongedommet Mysore,KongedÃ¸mmet Mysore,Mahisur,MahisÅ«r,Maisur,MaisÅ«r,Majsur,Mysore,Mysore Kiralysag,Mysore KirÃ¡lysÃ¡g,Mysuru,mai suo er,maisura,maisuru,mhaisura,ÐÐ°Ð¹ÑÑÑ,à¤®à¥à¤¸à¥à¤°,à¤®à¥à¤¹à¥à¤¸à¥à¤°,à²®à³à²¸à³à²°à³,è¿ç´¢å°,Mysore", :latitude => "12.30722", :longitude => "76.64972").save
City.new(:country_id => "107", :name => "Muzaffarpur", :aliases => "Muzaffarpur,Tirhoot,Muzaffarpur", :latitude => "26.11667", :longitude => "85.4").save
City.new(:country_id => "107", :name => "Muzaffarnagar", :aliases => "Muzaffarnagar,Muzaffarnagar", :latitude => "29.46667", :longitude => "77.68333").save
City.new(:country_id => "107", :name => "Muvattupula", :aliases => "Muvattupula,Muvatupusha,Muvatupuzha,MÅ«vattupula,MÅ«vattupula", :latitude => "9.96667", :longitude => "76.58333").save
City.new(:country_id => "107", :name => "Muttupet", :aliases => "Muttapet,Muttupet,Mutupet,Muttupet", :latitude => "10.4", :longitude => "79.48333").save
City.new(:country_id => "107", :name => "Mussoorie", :aliases => "Masuri,Musoori,Mussooree,Mussoorie,Mussuri,ÐÑÑÑÑÑÐ¸,Mussoorie", :latitude => "30.45", :longitude => "78.08333").save
City.new(:country_id => "107", :name => "Musiri", :aliases => "Musiri,Musiri", :latitude => "10.93333", :longitude => "78.45").save
City.new(:country_id => "107", :name => "Mushabani", :aliases => "Mosaboni,Mosaboni Mines,Musabani,Mushabani,MushÄbani,MushÄbani", :latitude => "22.51667", :longitude => "86.45").save
City.new(:country_id => "107", :name => "Murwara", :aliases => "Katni,Murwara,MurwÄra,MurwÄra", :latitude => "23.85", :longitude => "80.4").save
City.new(:country_id => "107", :name => "Murtajapur", :aliases => "Murtajapur,MurtajÄpur,Murtazapur,MurtazÄpur,MurtajÄpur", :latitude => "20.73333", :longitude => "77.38333").save
City.new(:country_id => "107", :name => "Murshidabad", :aliases => "Murshidabad,MurshidÄbÄd,ÐÑÑÑÐ¸Ð´Ð°Ð±Ð°Ð´,MurshidÄbÄd", :latitude => "24.18333", :longitude => "88.26667").save
City.new(:country_id => "107", :name => "Murliganj", :aliases => "Murliganj,MurlÄ«ganj,MurlÄ«ganj", :latitude => "25.9", :longitude => "86.98333").save
City.new(:country_id => "107", :name => "Morinda", :aliases => "Morinda,Murinda,MÅ«rinda,ÐÐ¾ÑÐ¸Ð½Ð´Ð°,Morinda", :latitude => "30.79194", :longitude => "76.49639").save
City.new(:country_id => "107", :name => "Murbad", :aliases => "Murbad,MurbÄd,MurbÄd", :latitude => "19.25", :longitude => "73.4").save
City.new(:country_id => "107", :name => "Muradnagar", :aliases => "Muradnagar,Muravnagar,MurÄdnagar,MurÄdnagar", :latitude => "28.78333", :longitude => "77.5").save
City.new(:country_id => "107", :name => "Munnar", :aliases => "Munnar,ÐÑÐ½Ð½Ð°Ñ,Munnar", :latitude => "10.1", :longitude => "77.06667").save
City.new(:country_id => "107", :name => "Munger", :aliases => "Manger,Monghyr,Munger,ÐÐ°Ð½Ð³ÐµÑ,Munger", :latitude => "25.38333", :longitude => "86.46667").save
City.new(:country_id => "107", :name => "Mungeli", :aliases => "Mungeli,Mungeli", :latitude => "22.06667", :longitude => "81.68333").save
City.new(:country_id => "107", :name => "Mungaoli", :aliases => "Mungaoli,MungaolÄ«,MungaolÄ«", :latitude => "24.41667", :longitude => "78.1").save
City.new(:country_id => "107", :name => "Mundwa", :aliases => "Mundwa,MÅ«ndwa,MÅ«ndwa", :latitude => "27.06667", :longitude => "73.81667").save
City.new(:country_id => "107", :name => "Mundra", :aliases => "Mundra,Mundra", :latitude => "22.85", :longitude => "69.73333").save
City.new(:country_id => "107", :name => "Mundgod", :aliases => "Mundgod,Mundgod", :latitude => "14.96667", :longitude => "75.03333").save
City.new(:country_id => "107", :name => "Mundargi", :aliases => "Mundargi,Mundargi", :latitude => "15.21667", :longitude => "75.9").save
City.new(:country_id => "107", :name => "Multai", :aliases => "Multai,Multai", :latitude => "21.76667", :longitude => "78.25").save
City.new(:country_id => "107", :name => "Mulki", :aliases => "Mulki,MÅ«lki,MÅ«lki", :latitude => "13.1", :longitude => "74.8").save
City.new(:country_id => "107", :name => "Mulgund", :aliases => "Mulgund,Mulgund", :latitude => "15.25", :longitude => "75.53333").save
City.new(:country_id => "107", :name => "Mulbagal", :aliases => "Mulbagal,MulbÄgal,MulbÄgal", :latitude => "13.16667", :longitude => "78.4").save
City.new(:country_id => "107", :name => "Mulappilangad", :aliases => "Mulappilangad,Mulappilangal,MulappilangÄd,Muzhappilangad,MulappilangÄd", :latitude => "11.8", :longitude => "75.45").save
City.new(:country_id => "107", :name => "Mul", :aliases => ",MÅ«l", :latitude => "20.06667", :longitude => "79.66667").save
City.new(:country_id => "107", :name => "Muktsar", :aliases => "Muktsar,Muktsar", :latitude => "30.48333", :longitude => "74.51667").save
City.new(:country_id => "107", :name => "Mukher", :aliases => ",Mukher", :latitude => "18.7", :longitude => "77.36667").save
City.new(:country_id => "107", :name => "Mukerian", :aliases => "Mukerian,MukeriÄn,MukeriÄn", :latitude => "31.95056", :longitude => "75.61583").save
City.new(:country_id => "107", :name => "Muhammadabad", :aliases => ",MuhammadÄbÄd", :latitude => "27.31667", :longitude => "79.45").save
City.new(:country_id => "107", :name => "Muhammadabad", :aliases => ",MuhammadÄbÄd", :latitude => "26.03306", :longitude => "83.38389").save
City.new(:country_id => "107", :name => "Muhammadabad", :aliases => "Muhammadabad,MuhammadÄbÄd,MuhammadÄbÄd", :latitude => "25.63333", :longitude => "83.75").save
City.new(:country_id => "107", :name => "Mughal Sarai", :aliases => "Moghal Sarai,Moghulserdai,Mughal Sarai,Mughal SarÄi,Mughal SarÄi", :latitude => "25.3", :longitude => "83.11667").save
City.new(:country_id => "107", :name => "Mudkhed", :aliases => ",Mudkhed", :latitude => "19.16667", :longitude => "77.51667").save
City.new(:country_id => "107", :name => "Mudhol", :aliases => "Mudhol,Mudhol", :latitude => "16.35", :longitude => "75.28333").save
City.new(:country_id => "107", :name => "Mudgal", :aliases => "Mudgal,Mudgal", :latitude => "16.01667", :longitude => "76.43333").save
City.new(:country_id => "107", :name => "Muddebihal", :aliases => "Muddebihal,MuddebihÄl,MuddebihÄl", :latitude => "16.33333", :longitude => "76.13333").save
City.new(:country_id => "107", :name => "Mudbidri", :aliases => "Mudabidri,Mudbidri,MÅ«dbidri,MÅ«dbidri", :latitude => "13.08333", :longitude => "74.98333").save
City.new(:country_id => "107", :name => "Mubarakpur", :aliases => "Azamgarh,Mubarakpur,MubÄrakpur,MubÄrakpur", :latitude => "26.09", :longitude => "83.29222").save
City.new(:country_id => "107", :name => "Motihari", :aliases => "Motihan,Motihari,MotÄ«hÄri,MotÄ«hÄri", :latitude => "26.65", :longitude => "84.91667").save
City.new(:country_id => "107", :name => "Morwa", :aliases => "Morva,Morwa,Morwa", :latitude => "22.9", :longitude => "73.83333").save
City.new(:country_id => "107", :name => "Morsi", :aliases => ",Morsi", :latitude => "21.33917", :longitude => "78.01306").save
City.new(:country_id => "107", :name => "Morena", :aliases => "Morena,Pech Morena,ÐÐ¾ÑÐµÐ½Ð°,Morena", :latitude => "26.49694", :longitude => "78").save
City.new(:country_id => "107", :name => "Morbi", :aliases => "Morbi,Morvi,Morbi", :latitude => "22.81667", :longitude => "70.83333").save
City.new(:country_id => "107", :name => "Morar", :aliases => ",MorÄr", :latitude => "26.22611", :longitude => "78.22611").save
City.new(:country_id => "107", :name => "Moram", :aliases => ",Moram", :latitude => "17.8", :longitude => "76.46667").save
City.new(:country_id => "107", :name => "Moradabad", :aliases => "Moradabad,MorÄdÄbÄd,Muradabad,MurÄdÄbÄd,ÐÐ¾ÑÐ°Ð´Ð°Ð±Ð°Ð´,MorÄdÄbÄd", :latitude => "28.83333", :longitude => "78.78333").save
City.new(:country_id => "107", :name => "Mon", :aliases => ",Mon", :latitude => "26.75", :longitude => "95.1").save
City.new(:country_id => "107", :name => "Mokokchung", :aliases => "Mkokchung,Mokokchung,MokokchÅ«ng,Mokokshung,MokokchÅ«ng", :latitude => "26.33333", :longitude => "94.53333").save
City.new(:country_id => "107", :name => "Mokama", :aliases => "Mokama,Mokamah,Mokameh,MokÄma,MokÄma", :latitude => "25.4", :longitude => "85.91667").save
City.new(:country_id => "107", :name => "Moirang", :aliases => "Moirang,MoirÄng,MoirÄng", :latitude => "24.5", :longitude => "93.76667").save
City.new(:country_id => "107", :name => "Moga", :aliases => "Moga,Mogu,ÐÐ¾Ð³Ñ,Moga", :latitude => "30.8", :longitude => "75.16667").save
City.new(:country_id => "107", :name => "Modasa", :aliases => "Modasa,Modassa,ModÄsa,ModÄsa", :latitude => "23.46667", :longitude => "73.3").save
City.new(:country_id => "107", :name => "Misrikh", :aliases => ",Misrikh", :latitude => "27.45", :longitude => "80.51667").save
City.new(:country_id => "107", :name => "Mirzapur", :aliases => "Mirzapur,Mirzapur-cum-Vindhyachal,Mirzarpur,MirzÄpur,ÐÐ¸ÑÐ·Ð°Ð¿ÑÑ,MirzÄpur", :latitude => "25.15", :longitude => "82.58333").save
City.new(:country_id => "107", :name => "Mirialguda", :aliases => "Mirialguda,Miriyalguda,MiriÄlgÅ«da,Miryalguda,MiriÄlgÅ«da", :latitude => "16.86667", :longitude => "79.58333").save
City.new(:country_id => "107", :name => "Mirganj", :aliases => "Mirganj,MÄ«rganj,MÄ«rganj", :latitude => "28.55", :longitude => "79.2").save
City.new(:country_id => "107", :name => "Miranpur Katra", :aliases => ",MÄ«rÄnpur Katra", :latitude => "28.03333", :longitude => "79.65").save
City.new(:country_id => "107", :name => "Miranpur", :aliases => "Miranpur,MÄ«rÄnpur,MÄ«rÄnpur", :latitude => "29.3", :longitude => "77.93333").save
City.new(:country_id => "107", :name => "Minjur", :aliases => "Minjur,MÄ«njÅ«r,MÄ«njÅ«r", :latitude => "13.26667", :longitude => "80.26667").save
City.new(:country_id => "107", :name => "Milak", :aliases => "Milak,ÐÐ¸Ð»Ð°Ðº,Milak", :latitude => "28.61667", :longitude => "79.18333").save
City.new(:country_id => "107", :name => "Mihona", :aliases => "Mehona,Mihona,Mihona", :latitude => "26.28444", :longitude => "78.98167").save
City.new(:country_id => "107", :name => "Mhasvad", :aliases => ",MhÄsvÄd", :latitude => "17.63333", :longitude => "74.78333").save
City.new(:country_id => "107", :name => "Mettur", :aliases => "Mettur,MettÅ«r,MettÅ«r", :latitude => "11.8", :longitude => "77.8").save
City.new(:country_id => "107", :name => "Mettuppalaiyam", :aliases => "Mettupalaiyam,Mettupalayam-Coimbatore,Mettuppalaiyam,MettuppÄlaiyam,MettupÄlaiyam,MettuppÄlaiyam", :latitude => "11.3", :longitude => "76.95").save
City.new(:country_id => "107", :name => "Merta", :aliases => ",Merta", :latitude => "26.65", :longitude => "74.03333").save
City.new(:country_id => "107", :name => "Mendarda", :aliases => ",Mendarda", :latitude => "21.31667", :longitude => "70.43333").save
City.new(:country_id => "107", :name => "Memari", :aliases => "Memari,MemÄri,MemÄri", :latitude => "23.2", :longitude => "88.11667").save
City.new(:country_id => "107", :name => "Melur", :aliases => "Mailore,Melur,MelÅ«r,MelÅ«r", :latitude => "10.05", :longitude => "78.33333").save
City.new(:country_id => "107", :name => "Mehndawal", :aliases => "Mahdawal,Mehdawal,Mehndawal,MehndÄwal,MehndÄwal", :latitude => "26.97528", :longitude => "83.11167").save
City.new(:country_id => "107", :name => "Mehekar", :aliases => "Mehekar,Mehkar,Mehekar", :latitude => "20.15", :longitude => "76.56667").save
City.new(:country_id => "107", :name => "Meerut", :aliases => "Meerut,Meerut City,Merath,Miratas,meratha,merato,mirat,ÐÐµÐµÑÑÑ,à¤®à¥à¤°à¤ ,à®®à¯à®°à®à¯,ã¡ã¼ã©ã,Meerut", :latitude => "28.98333", :longitude => "77.7").save
City.new(:country_id => "107", :name => "Medinipur", :aliases => "Medinipur,MedinÄ«pur,Midnapor,Midnapore,Midnapur,ÐÐ¸Ð´Ð½Ð°Ð¿Ð¾Ñ,MedinÄ«pur", :latitude => "22.43333", :longitude => "87.33333").save
City.new(:country_id => "107", :name => "Medak", :aliases => "Medak,ÐÐµÐ´Ð°Ðº,Medak", :latitude => "18.03333", :longitude => "78.26667").save
City.new(:country_id => "107", :name => "Mayuram", :aliases => "Mayavaram,Mayaveram,Mayuram,MÄyavaram,MÄyuram,MÄyÅ«ram,mayilatuturai,à®®à®¯à®¿à®²à®¾à®à¯à®¤à¯à®±à¯,MÄyÅ«ram", :latitude => "11.1", :longitude => "79.66667").save
City.new(:country_id => "107", :name => "Mayang Imphal", :aliases => ",MayÄng ImphÄl", :latitude => "24.61667", :longitude => "93.88333").save
City.new(:country_id => "107", :name => "Mawana", :aliases => "Mawana,MawÄna,MawÄna", :latitude => "29.1", :longitude => "77.91667").save
City.new(:country_id => "107", :name => "Mavur", :aliases => ",MÄvÅ«r", :latitude => "11.26667", :longitude => "75.91667").save
City.new(:country_id => "107", :name => "Mavelikara", :aliases => "Mavalikara,Mavelikara,MÄvelikara,MÄvelikara", :latitude => "9.26667", :longitude => "76.55").save
City.new(:country_id => "107", :name => "Maur", :aliases => ",Maur", :latitude => "30.08333", :longitude => "75.25").save
City.new(:country_id => "107", :name => "Mauganj", :aliases => "Mauganj,Mauganj", :latitude => "24.68333", :longitude => "81.88333").save
City.new(:country_id => "107", :name => "Maudaha", :aliases => ",Maudaha", :latitude => "25.68333", :longitude => "80.11667").save
City.new(:country_id => "107", :name => "Mau Aimma", :aliases => "Mau Aima,Mau Aimma,Mau Aimma", :latitude => "25.7", :longitude => "81.91667").save
City.new(:country_id => "107", :name => "Mau", :aliases => ",Mau", :latitude => "26.26694", :longitude => "78.67306").save
City.new(:country_id => "107", :name => "Mau", :aliases => ",Mau", :latitude => "25.95", :longitude => "83.55").save
City.new(:country_id => "107", :name => "Mattanur", :aliases => "Mattanur,MattanÅ«r,MattanÅ«r", :latitude => "11.91667", :longitude => "75.58333").save
City.new(:country_id => "107", :name => "Mathura", :aliases => "Mathura,Matkhura,Muttra,ÐÐ°ÑÑÑÑÐ°,Mathura", :latitude => "27.5", :longitude => "77.68333").save
City.new(:country_id => "107", :name => "Matabhanga", :aliases => ",MÄtÄbhÄnga", :latitude => "26.33333", :longitude => "89.21667").save
City.new(:country_id => "107", :name => "Masaurhi Buzurg", :aliases => "Masaurhi,Masaurhi Buzurg,Masaurki,Masaurhi Buzurg", :latitude => "25.35", :longitude => "85.03333").save
City.new(:country_id => "107", :name => "Marmagao", :aliases => "Goa,Marmagao,Marmagoa,Marmugao,Mermugao,Mormugao,Porio,ÐÐ°ÑÐ¼Ð°Ð³Ð°Ð¾,Marmagao", :latitude => "15.4", :longitude => "73.8").save
City.new(:country_id => "107", :name => "Markapur", :aliases => "Markapur,MÄrkÄpur,MÄrkÄpur", :latitude => "15.73333", :longitude => "79.28333").save
City.new(:country_id => "107", :name => "Mariani", :aliases => "Mariani,MariÄni,ÐÐ°ÑÐ¸Ð°Ð½Ð¸,MariÄni", :latitude => "26.66667", :longitude => "94.33333").save
City.new(:country_id => "107", :name => "Mariahu", :aliases => "Mariahu,MariÄhÅ«,MariÄhÅ«", :latitude => "25.61667", :longitude => "82.61667").save
City.new(:country_id => "107", :name => "Marhaura", :aliases => "Marhaura,Marhaura", :latitude => "25.96667", :longitude => "84.86667").save
City.new(:country_id => "107", :name => "Margherita", :aliases => ",Margherita", :latitude => "27.28333", :longitude => "95.68333").save
City.new(:country_id => "107", :name => "Marakkanam", :aliases => "Marakkanam,MarakkÄnam,Markanum,Merkanam,MerkÄnam,MarakkÄnam", :latitude => "12.2", :longitude => "79.95").save
City.new(:country_id => "107", :name => "Marahra", :aliases => ",MÄrahra", :latitude => "27.73333", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Mapuca", :aliases => "Mapusa,ÐÐ°Ð¿ÑÑÐ°,MÄpuca", :latitude => "15.59154", :longitude => "73.80898").save
City.new(:country_id => "107", :name => "Manwat", :aliases => "Manwat,Manwath,MÄnwat,MÄnwat", :latitude => "19.3", :longitude => "76.5").save
City.new(:country_id => "107", :name => "Manvi", :aliases => "Manvi,MÄnvi,MÄnvi", :latitude => "15.98333", :longitude => "77.05").save
City.new(:country_id => "107", :name => "Manthani", :aliases => "Manthani,Manthani", :latitude => "18.65", :longitude => "79.66667").save
City.new(:country_id => "107", :name => "Mansa", :aliases => ",MÄnsa", :latitude => "29.98333", :longitude => "75.38333").save
City.new(:country_id => "107", :name => "Mansa", :aliases => ",MÄnsa", :latitude => "23.43333", :longitude => "72.66667").save
City.new(:country_id => "107", :name => "Manoharpur", :aliases => ",Manoharpur", :latitude => "27.3", :longitude => "75.95").save
City.new(:country_id => "107", :name => "Mannargudi", :aliases => "Mannargudi,MannÄrgudi,MannÄrgudi", :latitude => "10.66667", :longitude => "79.43333").save
City.new(:country_id => "107", :name => "Mannarakkat", :aliases => ",MannÄrakkÄt", :latitude => "10.98333", :longitude => "76.46667").save
City.new(:country_id => "107", :name => "Manmad", :aliases => "Manmad,ManmÄd,ManmÄd", :latitude => "20.25", :longitude => "74.45").save
City.new(:country_id => "107", :name => "Mankachar", :aliases => "Manikarchar,Mankachar,MankÄchar,MankÄchar", :latitude => "25.53333", :longitude => "89.86667").save
City.new(:country_id => "107", :name => "Manjlegaon", :aliases => "Majalgaon,Manjlegaon,MÄjalgaon,Manjlegaon", :latitude => "19.15", :longitude => "76.23333").save
City.new(:country_id => "107", :name => "Manjhanpur", :aliases => "Manjhanpur,Manjhanpur", :latitude => "25.53333", :longitude => "81.38333").save
City.new(:country_id => "107", :name => "Manjeri", :aliases => "Manjeri,Manjeri", :latitude => "11.11667", :longitude => "76.11667").save
City.new(:country_id => "107", :name => "Manihari", :aliases => "Manihari,ManihÄri,ManihÄri", :latitude => "25.35", :longitude => "87.63333").save
City.new(:country_id => "107", :name => "Maniar", :aliases => ",Maniar", :latitude => "25.98333", :longitude => "84.16667").save
City.new(:country_id => "107", :name => "Mangrul Pir", :aliases => ",MangrÅ«l PÄ«r", :latitude => "20.31667", :longitude => "77.35").save
City.new(:country_id => "107", :name => "Mangrol", :aliases => "Kaiztori,Kazitori,KÄiztori,KÄzitori,Mangrol,MÄngrol,MÄngrol", :latitude => "25.33333", :longitude => "76.51667").save
City.new(:country_id => "107", :name => "Mangrol", :aliases => "Mangrol,Mungrol,MÄngrol,MÅ«ngrol,MÄngrol", :latitude => "21.11667", :longitude => "70.11667").save
City.new(:country_id => "107", :name => "Manglaur", :aliases => "Manglaur,Manglaur Town,Manglaur", :latitude => "29.8", :longitude => "77.86667").save
City.new(:country_id => "107", :name => "Mangalore", :aliases => "Mangalore,Mangalur,Mangaluru,mangalora,mangaluru,mankalur,ÐÐ°Ð½Ð³Ð°Ð»ÑÑÑ,à¦®à¦¾à¦à§à¦à¦¾à¦²à§à¦°,à®®à®à¯à®à®³à¯à®°à¯,à²®à²à²à²³à³à²°à³,Mangalore", :latitude => "12.86667", :longitude => "74.88333").save
City.new(:country_id => "107", :name => "Mangaldai", :aliases => ",Mangaldai", :latitude => "26.43333", :longitude => "92.03333").save
City.new(:country_id => "107", :name => "Mangalagiri", :aliases => "Mangalagiri,Mangalagiri", :latitude => "16.43333", :longitude => "80.55").save
City.new(:country_id => "107", :name => "Maner", :aliases => "Maner,Maner Sharif,Manera,ÐÐ°Ð½ÐµÑÐ°,Maner", :latitude => "25.65", :longitude => "84.88333").save
City.new(:country_id => "107", :name => "Mandya", :aliases => "Mandya,man di ya,mandya,à²®à²à²¡à³à²¯,æ¼è¿ªäº,Mandya", :latitude => "12.52417", :longitude => "76.89583").save
City.new(:country_id => "107", :name => "Mandvi", :aliases => "Cutch Mandi,Cutch-Mandvi,Mandvi,MÄndvi,ÐÐ°Ð½Ð´Ð²Ð¸,MÄndvi", :latitude => "22.83333", :longitude => "69.36667").save
City.new(:country_id => "107", :name => "Mandvi", :aliases => ",MÄndvi", :latitude => "21.25", :longitude => "73.3").save
City.new(:country_id => "107", :name => "Mandsaur", :aliases => "Mandasor,Mandsaur,Mandsaur", :latitude => "24.06667", :longitude => "75.06667").save
City.new(:country_id => "107", :name => "Mandla", :aliases => "Mandla,MandlÄ,ÐÐ°Ð½Ð´Ð»Ð°,MandlÄ", :latitude => "22.6", :longitude => "80.38333").save
City.new(:country_id => "107", :name => "Mandi", :aliases => ",Mandi", :latitude => "31.71667", :longitude => "76.91667").save
City.new(:country_id => "107", :name => "Mandawar", :aliases => "Mandawar,MandÄwar,MandÄwar", :latitude => "29.5", :longitude => "78.13333").save
City.new(:country_id => "107", :name => "Mandapeta", :aliases => ",Mandapeta", :latitude => "16.86667", :longitude => "81.93333").save
City.new(:country_id => "107", :name => "Mandapam", :aliases => "Mandapam,Mandapam", :latitude => "9.28333", :longitude => "79.11667").save
City.new(:country_id => "107", :name => "Mandalgarh", :aliases => "Mandalgarh,MÄndalgarh,MÄndalgarh", :latitude => "25.2", :longitude => "75.1").save
City.new(:country_id => "107", :name => "Mandal", :aliases => ",MÄndal", :latitude => "25.45", :longitude => "74.56667").save
City.new(:country_id => "107", :name => "Mancheral", :aliases => "Mancheral,Mancherial,MancherÄl,MancherÄl", :latitude => "18.86667", :longitude => "79.43333").save
City.new(:country_id => "107", :name => "Manawar", :aliases => "Manawar,ManÄwar,ManÄwar", :latitude => "22.23333", :longitude => "75.08333").save
City.new(:country_id => "107", :name => "Manavadar", :aliases => "Manavadar,Manawadar,MÄnÄvadar,MÄnÄvadar", :latitude => "21.5", :longitude => "70.13333").save
City.new(:country_id => "107", :name => "Manasa", :aliases => ",ManÄsa", :latitude => "24.48371", :longitude => "75.26871").save
City.new(:country_id => "107", :name => "Manapparai", :aliases => "Manaparai,Manapparai,ManappÄrai,ManappÄrai", :latitude => "10.6", :longitude => "78.41667").save
City.new(:country_id => "107", :name => "Manamadurai", :aliases => "Manamadura,Manamadurai,MÄnÄmadurai,MÄnÄmadurai", :latitude => "9.7", :longitude => "78.48333").save
City.new(:country_id => "107", :name => "Manali", :aliases => ",Manali", :latitude => "13.16667", :longitude => "80.26667").save
City.new(:country_id => "107", :name => "Malvan", :aliases => "Malvan,Malwan,MÄlvan,MÄlvan", :latitude => "16.06667", :longitude => "73.46667").save
City.new(:country_id => "107", :name => "Malur", :aliases => "Malur,MÄlÅ«r,MÄlÅ«r", :latitude => "13.0075", :longitude => "77.93778").save
City.new(:country_id => "107", :name => "Malpura", :aliases => "Malpura,MÄlpura,MÄlpura", :latitude => "26.28333", :longitude => "75.38333").save
City.new(:country_id => "107", :name => "Malpe", :aliases => "Malpe,Malpe", :latitude => "13.35", :longitude => "74.71667").save
City.new(:country_id => "107", :name => "Mallasamudram", :aliases => ",Mallasamudram", :latitude => "11.48333", :longitude => "78.03333").save
City.new(:country_id => "107", :name => "Malkapur", :aliases => ",MalkÄpur", :latitude => "20.88333", :longitude => "76.2").save
City.new(:country_id => "107", :name => "Malkangiri", :aliases => "Malakanagiri,Malakangairi,Malkanagiri,Malkangiri,MÄlkÄngiri,MÄlkÄngiri", :latitude => "18.35", :longitude => "81.9").save
City.new(:country_id => "107", :name => "Malihabad", :aliases => "Malihabad,MalÄ«hÄbÄd,MalÄ«hÄbÄd", :latitude => "26.91667", :longitude => "80.71667").save
City.new(:country_id => "107", :name => "Maler Kotla", :aliases => ",MÄler Kotla", :latitude => "30.51667", :longitude => "75.88333").save
City.new(:country_id => "107", :name => "Malegaon", :aliases => "Malegaon,MÄlegaon,ÐÐ°Ð»ÐµÐ³Ð°Ð¾Ð½,MÄlegaon", :latitude => "20.55", :longitude => "74.53333").save
City.new(:country_id => "107", :name => "Malavalli", :aliases => "Malavalli,Malavalli", :latitude => "12.38333", :longitude => "77.08333").save
City.new(:country_id => "107", :name => "Malaut", :aliases => ",Malaut", :latitude => "30.21667", :longitude => "74.48333").save
City.new(:country_id => "107", :name => "Malappuram", :aliases => "Malappuram,Malappuram", :latitude => "11.06667", :longitude => "76.06667").save
City.new(:country_id => "107", :name => "Makum", :aliases => "Makum,Makum-Junction,MÄkum,MÄkum", :latitude => "27.5", :longitude => "95.45").save
City.new(:country_id => "107", :name => "Maksi", :aliases => "Maksi,ÐÐ°ÐºÑÐ¸,Maksi", :latitude => "23.26667", :longitude => "76.15").save
City.new(:country_id => "107", :name => "Makrana", :aliases => "Makrana,MakrÄna,MakrÄna", :latitude => "27.05", :longitude => "74.71667").save
City.new(:country_id => "107", :name => "Mairwa", :aliases => "Mairwa,Mairwa", :latitude => "26.23333", :longitude => "84.15").save
City.new(:country_id => "107", :name => "Mainpuri", :aliases => "Mainpuri,Mainpuri", :latitude => "27.23333", :longitude => "79.01667").save
City.new(:country_id => "107", :name => "Mainaguri", :aliases => "Mainaguri,MainÄguri,MainÄguri", :latitude => "26.56667", :longitude => "88.81667").save
City.new(:country_id => "107", :name => "Maihar", :aliases => "Maihar,Maihar", :latitude => "24.26667", :longitude => "80.75").save
City.new(:country_id => "107", :name => "Mahwah", :aliases => "Mahwa,Mahwah,Mahwah", :latitude => "27.05", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Mahudha", :aliases => "Mahudha,Mahudha", :latitude => "22.81667", :longitude => "72.93333").save
City.new(:country_id => "107", :name => "Maholi", :aliases => "Maholi,Maholi", :latitude => "27.66667", :longitude => "80.46667").save
City.new(:country_id => "107", :name => "Mahoba", :aliases => "Mahoba,Mahoba", :latitude => "25.28333", :longitude => "79.86667").save
City.new(:country_id => "107", :name => "Mahmudabad", :aliases => "Mahmudabad,MahmÅ«dÄbÄd,MahmÅ«dÄbÄd", :latitude => "27.3", :longitude => "81.11667").save
City.new(:country_id => "107", :name => "Mahishadal", :aliases => ",MahÄ«shÄdal", :latitude => "22.18333", :longitude => "87.98333").save
City.new(:country_id => "107", :name => "Mahgawan", :aliases => ",MahgawÄn", :latitude => "26.5", :longitude => "78.60417").save
City.new(:country_id => "107", :name => "Maheshwar", :aliases => "Maheshwar,Makheshvar,ÐÐ°ÑÐµÑÐ²Ð°Ñ,Maheshwar", :latitude => "22.18333", :longitude => "75.58333").save
City.new(:country_id => "107", :name => "Mahendragarh", :aliases => "Kanaud,KÄnaud,Mahendragarh,Mohindargarh,Mahendragarh", :latitude => "28.28333", :longitude => "76.15").save
City.new(:country_id => "107", :name => "Mahemdavad", :aliases => "Mahemdavad,MahemdÄvÄd,Mehmadabad,MehmadÄbÄd,MahemdÄvÄd", :latitude => "22.83333", :longitude => "72.76667").save
City.new(:country_id => "107", :name => "Mahe", :aliases => "Mahe,Makh,Mayyazhi,ÐÐ°Ñ,Mahe", :latitude => "11.7", :longitude => "75.53333").save
City.new(:country_id => "107", :name => "Mahbubnagar", :aliases => "Mahboobnagar,Mahbubnagar,MahbÅ«bnagar,MahbÅ«bnagar", :latitude => "16.73333", :longitude => "77.98333").save
City.new(:country_id => "107", :name => "Mahbubabad", :aliases => "Mahboobabad,Mahbubabad,MahbÅ«bÄbÄd,MahbÅ«bÄbÄd", :latitude => "17.61667", :longitude => "80.01667").save
City.new(:country_id => "107", :name => "Mahasamund", :aliases => "Mahasamund,MahÄsamund,MahÄsamund", :latitude => "21.1", :longitude => "82.1").save
City.new(:country_id => "107", :name => "Maharajganj", :aliases => ",MahÄrÄjganj", :latitude => "27.13333", :longitude => "83.56667").save
City.new(:country_id => "107", :name => "Maharajganj", :aliases => "Maharajganj,MahÄrÄjganj,MahÄrÄjganj", :latitude => "26.11667", :longitude => "84.48333").save
City.new(:country_id => "107", :name => "Maham", :aliases => "Maham,Maham", :latitude => "28.98333", :longitude => "76.3").save
City.new(:country_id => "107", :name => "Mahalingpur", :aliases => "Mahalingpur,MahÄlingpur,MahÄlingpur", :latitude => "16.38333", :longitude => "75.11667").save
City.new(:country_id => "107", :name => "Mahad", :aliases => "Mahad,MahÄd,Makhad,ÐÐ°ÑÐ°Ð´,MahÄd", :latitude => "18.08333", :longitude => "73.41667").save
City.new(:country_id => "107", :name => "Maghar", :aliases => "Maghar,Maghar", :latitude => "26.75722", :longitude => "83.12778").save
City.new(:country_id => "107", :name => "Magadi", :aliases => "Magadi,MÄgadi,ÐÐ°Ð³Ð°Ð´Ð¸,MÄgadi", :latitude => "12.96667", :longitude => "77.23333").save
City.new(:country_id => "107", :name => "Madurantakam", :aliases => "Madurantakam,MadurÄntakam,MadurÄntakam", :latitude => "12.51667", :longitude => "79.9").save
City.new(:country_id => "107", :name => "Madurai", :aliases => "Madura,Madurai,Maduraj,Mathurai,ma du lai,mado~urai,madura'i,maturai,ÐÐ°Ð´ÑÑÐ°,à¦®à¦¦à§à¦°à¦¾à¦,à®®à®¤à¯à®°à¯,ããã¥ã©ã¤,é©¬æèµ,Madurai", :latitude => "9.93333", :longitude => "78.11667").save
City.new(:country_id => "107", :name => "Madukkur", :aliases => "Madukkur,MadukkÅ«r,MadukkÅ«r", :latitude => "10.48333", :longitude => "79.4").save
City.new(:country_id => "107", :name => "Madukkarai", :aliases => "Madukarai,Madukkarai,Mudukarai,Madukkarai", :latitude => "10.9", :longitude => "76.96667").save
City.new(:country_id => "107", :name => "Chennai", :aliases => "Cenaja,Cenajo,Chennai,Chennai - cennai,Chennai - à®à¯à®©à¯à®©à¯,Madras,MadrÃ¡s,Tamizhagam,Tamulinadu,cenna'i,cennai,chen'nai,jin nai,Äenajo,Äenaja,ÐÐ°Ð´ÑÐ°Ñ,Ð§ÐµÐ½Ð½Ð°Ð¸,à¤à¥à¤¨à¥à¤¨à¤,à¦à§à¦¨à§à¦¨à¦¾à¦,àªà«àª¨à«àª¨àª,à®à¯à®©à¯à®©à¯,à²à³à²¨à³à²¨à³,ãã§ã³ãã¤,éå¥,Chennai", :latitude => "13.08784", :longitude => "80.27847").save
City.new(:country_id => "107", :name => "Madikeri", :aliases => "Madikeri,Mercara,MercÄra,Merkara,Madikeri", :latitude => "12.41667", :longitude => "75.73333").save
City.new(:country_id => "107", :name => "Madhyamgram", :aliases => "Maddham Gram,Madhyamgram,Madhyamgram", :latitude => "22.7", :longitude => "88.45").save
City.new(:country_id => "107", :name => "Madhupur", :aliases => ",Madhupur", :latitude => "24.25", :longitude => "86.65").save
City.new(:country_id => "107", :name => "Madhugiri", :aliases => "Maddagiri,Madhugiri,Madhugiri", :latitude => "13.66056", :longitude => "77.20917").save
City.new(:country_id => "107", :name => "Madhubani", :aliases => "Madhubani,Madkhubani,ÐÐ°Ð´ÑÑÐ±Ð°Ð½Ð¸,Madhubani", :latitude => "26.36667", :longitude => "86.08333").save
City.new(:country_id => "107", :name => "Madhipura", :aliases => "Madhipura,Madhupura,Madhipura", :latitude => "25.91667", :longitude => "86.78333").save
City.new(:country_id => "107", :name => "Madgaon", :aliases => "Madgaon,Margao,MargÃ£o,ÐÐ°ÑÐ³Ð°Ð¾,Madgaon", :latitude => "15.3", :longitude => "73.95").save
City.new(:country_id => "107", :name => "Maddur", :aliases => "Maddur,MaddÅ«r,MaddÅ«r", :latitude => "12.6", :longitude => "77.06667").save
City.new(:country_id => "107", :name => "Madanapalle", :aliases => ",Madanapalle", :latitude => "13.55", :longitude => "78.5").save
City.new(:country_id => "107", :name => "Machilipatnam", :aliases => "Bandar,Kistna,Krishna,Machilipatnam,MachilÄ«patnam,Masulipatam,Masulipatnam,MachilÄ«patnam", :latitude => "16.16667", :longitude => "81.13333").save
City.new(:country_id => "107", :name => "Machhlishahr", :aliases => ",MachhlÄ«shahr", :latitude => "25.68333", :longitude => "82.41667").save
City.new(:country_id => "107", :name => "Machhiwara", :aliases => "Machhiwara,MÄchhÄ«wÄra,MÄchhÄ«wÄra", :latitude => "30.91472", :longitude => "76.19833").save
City.new(:country_id => "107", :name => "Macherla", :aliases => "Macherla,MÄcherla,MÄcherla", :latitude => "16.48333", :longitude => "79.43333").save
City.new(:country_id => "107", :name => "Lunglei", :aliases => "Lungleh,Lunglei,Lungliah,ÐÑÐ½Ð³Ð»ÐµÐ¸,Lunglei", :latitude => "22.88333", :longitude => "92.73333").save
City.new(:country_id => "107", :name => "Lunavada", :aliases => "Lunavada,LÅ«nÄvÄda,LÅ«nÄvÄda", :latitude => "23.13333", :longitude => "73.61667").save
City.new(:country_id => "107", :name => "Ludhiana", :aliases => "Ludhiana,Ludhijana,LudhiÄna,Ludkhijana,ludhi'ana,ludhiyana,lutiyana,rudiana,rudiyana,ÐÑÐ´ÑÐ¸ÑÐ½Ð°,à¤²à¥à¤§à¤¿à¤¯à¤¾à¤¨à¤¾,à¨²à©à¨§à¨¿à¨à¨£à¨¾,à®²à¯à®¤à®¿à®¯à®¾à®©à®¾,ã«ãã£ã¢ã¼ã,ã«ãã£ã¤ã¼ãã¼,LudhiÄna", :latitude => "30.9", :longitude => "75.85").save
City.new(:country_id => "107", :name => "Lucknow", :aliases => "Lakhnau,Lakkhnau,Laknau,Lakno,Lucknow,Lucknow City,lakhanau,laknau,lei ke nao,rakunau,ÐÐ°ÐºÑÐ½Ð°Ñ,ÙÙÙÙÙ,ÙÚ©Ú¾ÙØ¤,à¤²à¤à¤¨à¤,à¦²à¦à¦¨à§,à®²à®à¯à®©à¯,ã©ã¯ãã¦,ã©ã¯ãã¦ã¼,ååç,Lucknow", :latitude => "26.85", :longitude => "80.91667").save
City.new(:country_id => "107", :name => "Luckeesarai", :aliases => "Lakhisarai,Luckeesarai,Luckesserai,Luckeesarai", :latitude => "25.18333", :longitude => "86.08333").save
City.new(:country_id => "107", :name => "Losal", :aliases => "Losal,Losal", :latitude => "27.4", :longitude => "74.91667").save
City.new(:country_id => "107", :name => "Loni", :aliases => "Lone,Loni,ÐÐ¾Ð½Ðµ,Loni", :latitude => "28.75", :longitude => "77.28333").save
City.new(:country_id => "107", :name => "Lonavale", :aliases => "Lonauli,Lonavala,Lonavale,Lonavla,Lonsvala,LonÄvale,LonÄvla,LonÄvale", :latitude => "18.75", :longitude => "73.41667").save
City.new(:country_id => "107", :name => "Lonar", :aliases => ",LonÄr", :latitude => "19.98333", :longitude => "76.53333").save
City.new(:country_id => "107", :name => "Lohardaga", :aliases => "Lohardaga,LohÄrdaga,LohÄrdaga", :latitude => "23.43333", :longitude => "84.68333").save
City.new(:country_id => "107", :name => "Lingsugur", :aliases => "Lingsugur,LingsugÅ«r,LingsugÅ«r", :latitude => "16.16667", :longitude => "76.51667").save
City.new(:country_id => "107", :name => "Limbdi", :aliases => "Limbdi,Limri,Limbdi", :latitude => "22.56667", :longitude => "71.8").save
City.new(:country_id => "107", :name => "Leteri", :aliases => ",Leteri", :latitude => "24.05", :longitude => "77.4").save
City.new(:country_id => "107", :name => "Leh", :aliases => "Leh,Lekh,Len,leha,re,ÐÐµÑ,à¤²à¥à¤¹,ã¬ã¼,Leh", :latitude => "34.16667", :longitude => "77.58333").save
City.new(:country_id => "107", :name => "Lawar Khas", :aliases => "Lawar,Lawar Khas,LÄwar,LÄwar KhÄs,LÄwar KhÄs", :latitude => "29.11667", :longitude => "77.76667").save
City.new(:country_id => "107", :name => "Laungowal", :aliases => ",LaungowÄl", :latitude => "30.21667", :longitude => "75.68333").save
City.new(:country_id => "107", :name => "Latur", :aliases => "Latur,LÄtÅ«r,ÐÐ°ÑÑÑ,LÄtÅ«r", :latitude => "18.4", :longitude => "76.58333").save
City.new(:country_id => "107", :name => "Lathi", :aliases => "Lathi,Lati,LÄthi,LÄthi", :latitude => "21.71667", :longitude => "71.38333").save
City.new(:country_id => "107", :name => "Latehar", :aliases => ",LÄtehÄr", :latitude => "23.75", :longitude => "84.5").save
City.new(:country_id => "107", :name => "Lar", :aliases => ",LÄr", :latitude => "26.20389", :longitude => "83.97167").save
City.new(:country_id => "107", :name => "Lalsot", :aliases => "Lalsot,LÄlsot,LÄlsot", :latitude => "26.56667", :longitude => "76.33333").save
City.new(:country_id => "107", :name => "Lalpur", :aliases => ",LÄlpur", :latitude => "22.2", :longitude => "69.96667").save
City.new(:country_id => "107", :name => "Lalitpur", :aliases => "Lalitpur,ÐÐ°Ð»Ð¸ÑÐ¿ÑÑ,Lalitpur", :latitude => "24.68333", :longitude => "78.41667").save
City.new(:country_id => "107", :name => "Lalgudi", :aliases => "Lalgudi,LÄlgudi,LÄlgudi", :latitude => "10.86667", :longitude => "78.83333").save
City.new(:country_id => "107", :name => "Lalgola", :aliases => "Lalgola,Lalgola Ghat,LÄlgola,LÄlgola", :latitude => "24.41667", :longitude => "88.25").save
City.new(:country_id => "107", :name => "Lalganj", :aliases => ",LÄlganj", :latitude => "25.93333", :longitude => "81.7").save
City.new(:country_id => "107", :name => "Lalganj", :aliases => "Lalganj,LÄlganj,LÄlganj", :latitude => "25.86667", :longitude => "85.18333").save
City.new(:country_id => "107", :name => "Lakshmeshwar", :aliases => "Lakshmeshvar,Lakshmeshwar,Lakshmeshwar", :latitude => "15.13333", :longitude => "75.46667").save
City.new(:country_id => "107", :name => "Laksar", :aliases => "Laksar,Laksar", :latitude => "29.76667", :longitude => "78.05").save
City.new(:country_id => "107", :name => "Lakhyabad", :aliases => "Lakhyabad,LakhyÄbÄd,Layabad,Loyabad,LakhyÄbÄd", :latitude => "23.66667", :longitude => "86.66667").save
City.new(:country_id => "107", :name => "Lakhnadon", :aliases => "Lakhnadon,LakhnÄdon,LakhnÄdon", :latitude => "22.6", :longitude => "79.6").save
City.new(:country_id => "107", :name => "Lakhimpur", :aliases => "Lakhimpur,LakhÄ«mpur,LakhÄ«mpur", :latitude => "27.95", :longitude => "80.76667").save
City.new(:country_id => "107", :name => "Lakheri", :aliases => "Lakheri,LÄkheri,LÄkheri", :latitude => "25.66667", :longitude => "76.16667").save
City.new(:country_id => "107", :name => "Laharpur", :aliases => "Laharpur,LÄharpur,LÄharpur", :latitude => "27.71667", :longitude => "80.9").save
City.new(:country_id => "107", :name => "Lahar", :aliases => ",LahÄr", :latitude => "26.19833", :longitude => "78.945").save
City.new(:country_id => "107", :name => "Ladwa", :aliases => ",LÄdwa", :latitude => "29.99444", :longitude => "77.04444").save
City.new(:country_id => "107", :name => "Ladnun", :aliases => ",LÄdnÅ«n", :latitude => "27.65", :longitude => "74.38333").save
City.new(:country_id => "107", :name => "Lachhmangarh Sikar", :aliases => "Lachhmangarh,Lachhmangarh Sikar,Lachhmangarh SÄ«kar,Lachmangarh,Lachhmangarh SÄ«kar", :latitude => "27.81667", :longitude => "75.03333").save
City.new(:country_id => "107", :name => "Kuzhittura", :aliases => "Kuzhithurai,Kuzhittura,Kuzhittura", :latitude => "8.31667", :longitude => "77.18333").save
City.new(:country_id => "107", :name => "Kuttanallur", :aliases => "Koothanallur,Kuttanallur,KÅ«ttÄnallÅ«r,KÅ«ttÄnallÅ«r", :latitude => "10.7", :longitude => "79.53333").save
City.new(:country_id => "107", :name => "Kutiyana", :aliases => "Kuntiyana,KuntiyÄna,Kurtiyana,Kutiyana,KutiyÄna,KutiyÄna", :latitude => "21.62333", :longitude => "69.98167").save
City.new(:country_id => "107", :name => "Kushtagi", :aliases => "Kushtagi,Kushtagi", :latitude => "15.76667", :longitude => "76.2").save
City.new(:country_id => "107", :name => "Kurinjippadi", :aliases => "Kurinjipadi,Kurinjippadi,KurinjippÄdi,KurinjippÄdi", :latitude => "11.56667", :longitude => "79.6").save
City.new(:country_id => "107", :name => "Kurduvadi", :aliases => "Kurduvadi,KurduvÄdi,KurduvÄdi", :latitude => "18.08333", :longitude => "75.43333").save
City.new(:country_id => "107", :name => "Kurandvad", :aliases => ",KurandvÄd", :latitude => "16.68333", :longitude => "74.58333").save
City.new(:country_id => "107", :name => "Kuppam", :aliases => "Kuppam,Kuppam", :latitude => "12.75", :longitude => "78.36667").save
City.new(:country_id => "107", :name => "Kunnamkulam", :aliases => "Kunamkulam,Kunnamkulam,Kunnamkulam", :latitude => "10.65", :longitude => "76.08333").save
City.new(:country_id => "107", :name => "Kunnamangalam", :aliases => ",Kunnamangalam", :latitude => "11.31667", :longitude => "75.88333").save
City.new(:country_id => "107", :name => "Kunigal", :aliases => "Kunigal,Kunigal", :latitude => "13.02222", :longitude => "77.02667").save
City.new(:country_id => "107", :name => "Kundla", :aliases => ",Kundla", :latitude => "21.33333", :longitude => "71.3").save
City.new(:country_id => "107", :name => "Kundgol", :aliases => "Kundgol,Kundgol", :latitude => "15.25", :longitude => "75.25").save
City.new(:country_id => "107", :name => "Kundarkhi", :aliases => "Kundarkhi,Kundarki,Kundarkhi", :latitude => "28.7", :longitude => "78.78333").save
City.new(:country_id => "107", :name => "Kunda", :aliases => ",Kunda", :latitude => "25.71667", :longitude => "81.51667").save
City.new(:country_id => "107", :name => "Kumta", :aliases => "Coompta,Kumpta,Kumta,Kumta", :latitude => "14.41667", :longitude => "74.4").save
City.new(:country_id => "107", :name => "Kumher", :aliases => "Kumher,KÅ«mher,KÅ«mher", :latitude => "27.31667", :longitude => "77.36667").save
City.new(:country_id => "107", :name => "Kumhari", :aliases => "Kumhari,KumhÄri,KumhÄri", :latitude => "21.26667", :longitude => "81.51667").save
City.new(:country_id => "107", :name => "Kumbhraj", :aliases => "Kumbhraj,KumbhrÄj,KumbhrÄj", :latitude => "24.36667", :longitude => "77.05").save
City.new(:country_id => "107", :name => "Kumbakonam", :aliases => "Kumbakonam,kumpakonam,à®à¯à®®à¯à®ªà®à¯à®£à®®à¯,Kumbakonam", :latitude => "10.96667", :longitude => "79.38333").save
City.new(:country_id => "107", :name => "Kulu", :aliases => "Kulu,Sultanpur,SultÄnpur,Kulu", :latitude => "31.96667", :longitude => "77.1").save
City.new(:country_id => "107", :name => "Kulti", :aliases => "Kulti,ÐÑÐ»ÑÐ¸,Kulti", :latitude => "23.73333", :longitude => "86.85").save
City.new(:country_id => "107", :name => "Kulpahar", :aliases => "Kulpahar,KulpahÄr,KulpahÄr", :latitude => "25.31667", :longitude => "79.65").save
City.new(:country_id => "107", :name => "Kulittalai", :aliases => ",Kulittalai", :latitude => "10.91667", :longitude => "78.41667").save
City.new(:country_id => "107", :name => "Kulgam", :aliases => "Kulgam,KulgÄm,KulgÄm", :latitude => "33.65", :longitude => "75.01667").save
City.new(:country_id => "107", :name => "Kukshi", :aliases => "Kukshi,Kukshi", :latitude => "22.2", :longitude => "74.75").save
City.new(:country_id => "107", :name => "Kukatpalli", :aliases => "Kukatpalli,Kukatpally,KÅ«katpalli,KÅ«katpalli", :latitude => "17.48333", :longitude => "78.41667").save
City.new(:country_id => "107", :name => "Kuju", :aliases => ",Kuju", :latitude => "23.71667", :longitude => "85.5").save
City.new(:country_id => "107", :name => "Kudligi", :aliases => "Kudligi,KÅ«dligi,KÅ«dligi", :latitude => "14.9", :longitude => "76.38333").save
City.new(:country_id => "107", :name => "Kudachi", :aliases => "Kudachi,Kudchi,Kudachi", :latitude => "16.63333", :longitude => "74.85").save
City.new(:country_id => "107", :name => "Kuchera", :aliases => "Kucher,Kuchera,ÐÑÑÐµÑ,Kuchera", :latitude => "26.98389", :longitude => "73.97194").save
City.new(:country_id => "107", :name => "Kuchaman", :aliases => "Kuchaman,Kuchawan,KuchÄman,KuchÄwan,KuchÄman", :latitude => "27.15", :longitude => "74.85").save
City.new(:country_id => "107", :name => "Kuchaiburi", :aliases => "Kuchaiburi,Rairangpur,Kuchaiburi", :latitude => "22.26667", :longitude => "86.16667").save
City.new(:country_id => "107", :name => "Krishnarajpet", :aliases => "Krishnarajpet,KrishnarÄjpet,KrishnarÄjpet", :latitude => "12.655", :longitude => "76.48833").save
City.new(:country_id => "107", :name => "Krishnanagar", :aliases => "Krishnagar,Krishnagar City,Krishnanagar,Krishnigar,Krishnanagar", :latitude => "23.4", :longitude => "88.5").save
City.new(:country_id => "107", :name => "Krishnagiri", :aliases => "Krishnagiri,Krishnagiri", :latitude => "12.53333", :longitude => "78.23333").save
City.new(:country_id => "107", :name => "Calicut", :aliases => "Calecute,Calicut,Kal'kutta,Kolikod,Kozhikkot,Kozhikode,karikatto,ke ze ke de,kealikkeat jilla,kolikkotu,ÐÐ°Ð»ÑÐºÑÑÑÐ°,à®à¯à®´à®¿à®à¯à®à¯à®à¯,à´àµà´´à´¿à´àµà´àµà´àµ à´à´¿à´²àµà´²,à´àµà´´à´¿à´àµà´àµà´àµâ,ã«ãªã«ãã,ç§æ³½ç§å¾·,Calicut", :latitude => "11.25", :longitude => "75.76667").save
City.new(:country_id => "107", :name => "Kovvur", :aliases => "Kovur,Kovvur,KovvÅ«r,KovvÅ«r", :latitude => "17.01667", :longitude => "81.73333").save
City.new(:country_id => "107", :name => "Kovur", :aliases => "Kovur,KovÅ«r,KovÅ«r", :latitude => "14.48333", :longitude => "79.98333").save
City.new(:country_id => "107", :name => "Kovilpatti", :aliases => "Koilpatti,Kovilpatti,Kovilpatti", :latitude => "9.16667", :longitude => "77.86667").save
City.new(:country_id => "107", :name => "Kotturu", :aliases => "Kothur,Kottur,Kotturu,KottÅ«ru,KottÅ«ru", :latitude => "14.81667", :longitude => "76.21667").save
City.new(:country_id => "107", :name => "Kottayam", :aliases => "Kotayam,Kottayam,Kottayam", :latitude => "9.58333", :longitude => "76.51667").save
City.new(:country_id => "107", :name => "Kottagudem", :aliases => "Kothagudem,Kottagudem,KottagÅ«dem,KottagÅ«dem", :latitude => "17.55", :longitude => "80.63333").save
City.new(:country_id => "107", :name => "Kot Putli", :aliases => ",Kot PÅ«tli", :latitude => "27.71667", :longitude => "76.2").save
City.new(:country_id => "107", :name => "Kotma", :aliases => "Kotma,Kotma", :latitude => "23.2", :longitude => "81.96667").save
City.new(:country_id => "107", :name => "Kotdwara", :aliases => ",KotdwÄra", :latitude => "29.75", :longitude => "78.53333").save
City.new(:country_id => "107", :name => "Kotaparh", :aliases => "Kotapad,Kotaparh,KotapÄd,KotapÄrh,KotapÄrh", :latitude => "19.15", :longitude => "82.35").save
City.new(:country_id => "107", :name => "Kotamangalam", :aliases => ",Kotamangalam", :latitude => "10.06667", :longitude => "76.63333").save
City.new(:country_id => "107", :name => "Kotagiri", :aliases => "Kotagiri,Kotagiri", :latitude => "11.43333", :longitude => "76.88333").save
City.new(:country_id => "107", :name => "Kota", :aliases => "Kota,Kotah,Kotah City,ÐÐ¾ÑÐ°,Kota", :latitude => "25.18333", :longitude => "75.83333").save
City.new(:country_id => "107", :name => "Kota", :aliases => ",Kota", :latitude => "22.3", :longitude => "82.03333").save
City.new(:country_id => "107", :name => "Kosigi", :aliases => "Kesigi,Kosgi,Kosigi,Kosigi", :latitude => "15.85", :longitude => "77.26667").save
City.new(:country_id => "107", :name => "Kosi", :aliases => ",Kosi", :latitude => "27.8", :longitude => "77.43333").save
City.new(:country_id => "107", :name => "Kosamba", :aliases => "Kosamba,Kosamba", :latitude => "21.48333", :longitude => "72.95").save
City.new(:country_id => "107", :name => "Korwai", :aliases => ",Korwai", :latitude => "24.1167", :longitude => "78.0419").save
City.new(:country_id => "107", :name => "Koregaon", :aliases => "Koregaon,Koregaon-Bhima,Koregaon", :latitude => "18.65", :longitude => "74.08333").save
City.new(:country_id => "107", :name => "Korba", :aliases => "Korba,koraba jila,ÐÐ¾ÑÐ±Ð°,à¤à¥à¤°à¤¬à¤¾ à¤à¤¿à¤²à¤¾,Korba", :latitude => "22.35", :longitude => "82.68333").save
City.new(:country_id => "107", :name => "Koratla", :aliases => "Koratla,Koratla", :latitude => "18.81667", :longitude => "78.71667").save
City.new(:country_id => "107", :name => "Koraput", :aliases => "Koraput,ÐÐ¾ÑÐ°Ð¿ÑÑ,Koraput", :latitude => "18.81667", :longitude => "82.71667").save
City.new(:country_id => "107", :name => "Koppal", :aliases => "Kappal,Kopbal,Koppal,Koppal", :latitude => "15.35", :longitude => "76.15").save
City.new(:country_id => "107", :name => "Kopargaon", :aliases => "Kopargaon,Kopargaon", :latitude => "19.88333", :longitude => "74.48333").save
City.new(:country_id => "107", :name => "Kopaganj", :aliases => "Kopaganj,KopÄganj,KopÄganj", :latitude => "26.02333", :longitude => "83.56583").save
City.new(:country_id => "107", :name => "Konnur", :aliases => "Konnur,KonnÅ«r,KonnÅ«r", :latitude => "16.2", :longitude => "74.75").save
City.new(:country_id => "107", :name => "Konnagar", :aliases => "Konnagar,Konnagar", :latitude => "22.7", :longitude => "88.3475").save
City.new(:country_id => "107", :name => "Kondapalle", :aliases => "Kondapalle,Kondapalli,Kondapalle", :latitude => "16.61667", :longitude => "80.53333").save
City.new(:country_id => "107", :name => "Kondagaon", :aliases => "Kondagaon,Kondegaon,Kondagaon", :latitude => "19.6", :longitude => "81.66667").save
City.new(:country_id => "107", :name => "Konch", :aliases => "Konch,Kunch,KÅ«nch,Konch", :latitude => "25.98333", :longitude => "79.15").save
City.new(:country_id => "107", :name => "Konarka", :aliases => "Kanarak,Konarak,Konark,Konarka,KonÃ¢rak,KonÄrak,KonÄrka,ke na ke tai yang shen miao,konarak,à²à³à²¨à²¾à²°à²à³,ç§çº³åå¤ªé³ç¥åº,KonÄrka", :latitude => "19.9", :longitude => "86.11667").save
City.new(:country_id => "107", :name => "Kolosib", :aliases => ",Kolosib", :latitude => "24.23333", :longitude => "92.7").save
City.new(:country_id => "107", :name => "Kollegal", :aliases => "Collegal,Kollegal,Kollegalam,KollegÄl,KollegÄlam,KollegÄl", :latitude => "12.15", :longitude => "77.11667").save
City.new(:country_id => "107", :name => "Kolhapur", :aliases => "Kolhapur,KolhÄpur,KolhÄpur", :latitude => "16.7", :longitude => "74.21667").save
City.new(:country_id => "107", :name => "Kolaras", :aliases => "Kolaras,KolÄras,KolÄras", :latitude => "25.23333", :longitude => "77.6").save
City.new(:country_id => "107", :name => "Kolar", :aliases => "Kolar,KolÄr,ÐÐ¾Ð»Ð°Ñ,KolÄr", :latitude => "13.13333", :longitude => "78.13333").save
City.new(:country_id => "107", :name => "Kolachel", :aliases => ",Kolachel", :latitude => "8.16667", :longitude => "77.25").save
City.new(:country_id => "107", :name => "Kokrajhar", :aliases => "Kokradzhar,Kokrajhar,ÐÐ¾ÐºÑÐ°Ð´Ð¶Ð°Ñ,Kokrajhar", :latitude => "26.4", :longitude => "90.26667").save
City.new(:country_id => "107", :name => "Kohima", :aliases => "Kohima,Kokhima,kohima,kokima,ÐÐ¾ÑÐ¸Ð¼Ð°,à¤à¥à¤¹à¤¿à¤®à¤¾,à¦à§à¦¹à¦¿à¦®à¦¾,à®à¯à®à®¿à®®à®¾,ã³ãã,KohÄ«ma", :latitude => "25.66667", :longitude => "94.11667").save
City.new(:country_id => "107", :name => "Koelwar", :aliases => ",KoelwÄr", :latitude => "25.58333", :longitude => "84.8").save
City.new(:country_id => "107", :name => "Kodungallur", :aliases => "Cranganore,Cranganur,CrÄnganÅ«r,Methala,KodungallÅ«r", :latitude => "10.21667", :longitude => "76.21667").save
City.new(:country_id => "107", :name => "Kodoli", :aliases => "Kodoli,Kodoli", :latitude => "16.88333", :longitude => "74.2").save
City.new(:country_id => "107", :name => "Kodinar", :aliases => "Kodina,Kodinar,KodÄ«nar,Korinar,KodÄ«nar", :latitude => "20.79028", :longitude => "70.70306").save
City.new(:country_id => "107", :name => "Kodarma", :aliases => "Kodarma,Kodarma", :latitude => "24.46667", :longitude => "85.6").save
City.new(:country_id => "107", :name => "Kodar", :aliases => ",KodÄr", :latitude => "16.98333", :longitude => "79.96667").save
City.new(:country_id => "107", :name => "Kodaikanal", :aliases => "Kodaikan,Kodaikanal,KodaikÄn,KodaikÄnÄl,Kodajkanal,ÐÐ¾Ð´Ð°Ð¹ÐºÐ°Ð½Ð°Ð»,KodaikÄnÄl", :latitude => "10.23333", :longitude => "77.48333").save
City.new(:country_id => "107", :name => "Koch Bihar", :aliases => "Cooch Behar,Koch Bihar,Koch BihÄr,Kuch Bihar,Kuch BihÄr,Koch BihÄr", :latitude => "26.31667", :longitude => "89.43333").save
City.new(:country_id => "107", :name => "Koath", :aliases => "Koath,KoÄth,KoÄth", :latitude => "25.31667", :longitude => "84.26667").save
City.new(:country_id => "107", :name => "Kizhake Chalakudi", :aliases => "Chalakudi,ChÄlakudi,Kizhake Chalakudi,Kizhake ChÄlakudi,Kizhake ChÄlakudi", :latitude => "10.3", :longitude => "76.35").save
City.new(:country_id => "107", :name => "Kithor", :aliases => ",Kithor", :latitude => "28.86667", :longitude => "77.93333").save
City.new(:country_id => "107", :name => "Kishtwar", :aliases => "Kishtvare,Kishtwar,Kishtwer,KishtwÄr,ÐÐ¸ÑÑÐ²Ð°ÑÐµ,KishtwÄr", :latitude => "33.31667", :longitude => "75.76667").save
City.new(:country_id => "107", :name => "Kishangarh", :aliases => "Kishangarh,Kishangarkh,ÐÐ¸ÑÐ°Ð½Ð³Ð°ÑÑ,Kishangarh", :latitude => "26.56667", :longitude => "74.86667").save
City.new(:country_id => "107", :name => "Kishanganj", :aliases => "Kishanganj,Kishanganj Bazar,Kishanganj", :latitude => "26.11667", :longitude => "87.93333").save
City.new(:country_id => "107", :name => "Kiratpur", :aliases => "Kiratpur,KÄ«ratpur,KÄ«ratpur", :latitude => "29.51667", :longitude => "78.2").save
City.new(:country_id => "107", :name => "Kiraoli", :aliases => "Kiraoli,Kiraoli", :latitude => "27.15", :longitude => "77.78333").save
City.new(:country_id => "107", :name => "Kinwat", :aliases => "Kinvat,Kinwat,Kinwat", :latitude => "19.63333", :longitude => "78.2").save
City.new(:country_id => "107", :name => "Kichha", :aliases => "Kichha,Kichha", :latitude => "28.91667", :longitude => "79.5").save
City.new(:country_id => "107", :name => "Khutar", :aliases => "Khutar,KhÅ«tÄr,KhÅ«tÄr", :latitude => "28.2", :longitude => "80.28333").save
City.new(:country_id => "107", :name => "Khurja", :aliases => "Khurja,Khurja", :latitude => "28.25", :longitude => "77.85").save
City.new(:country_id => "107", :name => "Khurda", :aliases => "Khordha,Khurda,Khurda", :latitude => "20.18333", :longitude => "85.61667").save
City.new(:country_id => "107", :name => "Khurai", :aliases => "Khurai,Khurai", :latitude => "24.0436", :longitude => "78.3319").save
City.new(:country_id => "107", :name => "Khunti", :aliases => "Khunti,Khunti", :latitude => "23.08333", :longitude => "85.28333").save
City.new(:country_id => "107", :name => "Khowai", :aliases => "Khowai,Khowai", :latitude => "24.1", :longitude => "91.63333").save
City.new(:country_id => "107", :name => "Khopoli", :aliases => "Khopoli,Khopoli", :latitude => "18.78333", :longitude => "73.33333").save
City.new(:country_id => "107", :name => "Khirkian", :aliases => "Khirkian,Khirkiya,KhirkiÄn,KhirkiÄn", :latitude => "22.16667", :longitude => "76.85").save
City.new(:country_id => "107", :name => "Khilchipur", :aliases => "Khilchipur,Khilchipur", :latitude => "24.03333", :longitude => "76.56667").save
City.new(:country_id => "107", :name => "Khetri", :aliases => "Khetri,Khetri", :latitude => "27.98333", :longitude => "75.8").save
City.new(:country_id => "107", :name => "Khetia", :aliases => "Khetia,Khetia", :latitude => "21.66667", :longitude => "74.58333").save
City.new(:country_id => "107", :name => "Kheri", :aliases => "Kheri,Kheri", :latitude => "27.9", :longitude => "80.8").save
City.new(:country_id => "107", :name => "Kheralu", :aliases => "Kheralu,KherÄlu,KherÄlu", :latitude => "23.88333", :longitude => "72.61667").save
City.new(:country_id => "107", :name => "Khekra", :aliases => ",Khekra", :latitude => "28.86667", :longitude => "77.28333").save
City.new(:country_id => "107", :name => "Khed Brahma", :aliases => ",Khed Brahma", :latitude => "24.03333", :longitude => "73.05").save
City.new(:country_id => "107", :name => "Kheda", :aliases => "Kaira,Kheda,Ð¥ÐµÐ´Ð°,Kheda", :latitude => "22.75", :longitude => "72.68333").save
City.new(:country_id => "107", :name => "Khatra", :aliases => ",KhÄtra", :latitude => "22.98333", :longitude => "86.85").save
City.new(:country_id => "107", :name => "Khatima", :aliases => "Khatima,KhatÄ«ma,KhatÄ«ma", :latitude => "28.91667", :longitude => "79.96667").save
City.new(:country_id => "107", :name => "Khategaon", :aliases => "Khategaon,KhÄtegaon,KhÄtegaon", :latitude => "22.6", :longitude => "76.91667").save
City.new(:country_id => "107", :name => "Khatauli", :aliases => "Khatauli,Khatauli", :latitude => "29.28333", :longitude => "77.71667").save
City.new(:country_id => "107", :name => "Kharupatia", :aliases => "Kharupatia,Kharupatia Ghat,KhÄrupatia,KhÄrupatia", :latitude => "26.51667", :longitude => "92.13333").save
City.new(:country_id => "107", :name => "Kharsia", :aliases => "Kharsia,Kharsia", :latitude => "21.96667", :longitude => "83.11667").save
City.new(:country_id => "107", :name => "Kharkhauda", :aliases => ",Kharkhauda", :latitude => "28.88333", :longitude => "76.85").save
City.new(:country_id => "107", :name => "Khargon", :aliases => "Khargon,Khargone,Khargon", :latitude => "21.81667", :longitude => "75.6").save
City.new(:country_id => "107", :name => "Khardah", :aliases => "Khardah,Khardaha,Khardah", :latitude => "22.71861", :longitude => "88.37806").save
City.new(:country_id => "107", :name => "Kharar", :aliases => "Kharar,Kharar", :latitude => "30.74444", :longitude => "76.64778").save
City.new(:country_id => "107", :name => "Kharakvasla", :aliases => "Khadakvaslal,Khadakwasla,Khandakwalsa,Kharakvasla,Kharakvasla", :latitude => "18.43333", :longitude => "73.76667").save
City.new(:country_id => "107", :name => "Kharagpur", :aliases => "Kharagpur,Ð¥Ð°ÑÐ°Ð³Ð¿ÑÑ,Kharagpur", :latitude => "25.11667", :longitude => "86.55").save
City.new(:country_id => "107", :name => "Kharagpur", :aliases => "Kharagpur,Khargpur,Ð¥Ð°ÑÐ°Ð³Ð¿ÑÑ,Kharagpur", :latitude => "22.33333", :longitude => "87.33333").save
City.new(:country_id => "107", :name => "Khapa", :aliases => ",KhÄpa", :latitude => "21.43333", :longitude => "78.96667").save
City.new(:country_id => "107", :name => "Khanna", :aliases => "Khanna,Ð¥Ð°Ð½Ð½Ð°,Khanna", :latitude => "30.70444", :longitude => "76.22306").save
City.new(:country_id => "107", :name => "Khandwa", :aliases => "Khandwa,Khandwa", :latitude => "21.83333", :longitude => "76.33333").save
City.new(:country_id => "107", :name => "Khandela", :aliases => ",Khandela", :latitude => "27.6", :longitude => "75.5").save
City.new(:country_id => "107", :name => "Khanapur", :aliases => "Khanapur,KhÄnÄpur,KhÄnÄpur", :latitude => "15.63333", :longitude => "74.51667").save
City.new(:country_id => "107", :name => "Khammam", :aliases => "Khammam,Khammamett,Khammamette,kam'mam,à®à®®à¯à®®à®®à¯,Khammam", :latitude => "17.25", :longitude => "80.15").save
City.new(:country_id => "107", :name => "Khamgaon", :aliases => "Khamgaon,KhÄmgaon,KhÄmgaon", :latitude => "20.68333", :longitude => "76.56667").save
City.new(:country_id => "107", :name => "Khambhat", :aliases => "Cambay,Kambay,Khambayat,Khambhat,KhambhÄt,KhambÄyat,KhambhÄt", :latitude => "22.3", :longitude => "72.61667").save
City.new(:country_id => "107", :name => "Khambhaliya", :aliases => "Khambhalia,Khambhaliva,Khambhaliya,KhambhÄliya,KhambhÄliya", :latitude => "22.20722", :longitude => "69.66833").save
City.new(:country_id => "107", :name => "Khamaria", :aliases => ",Khamaria", :latitude => "23.21667", :longitude => "79.88333").save
City.new(:country_id => "107", :name => "Khalilabad", :aliases => "Khalilabad,KhalÄ«lÄbÄd,KhalÄ«lÄbÄd", :latitude => "26.775", :longitude => "83.07361").save
City.new(:country_id => "107", :name => "Khajuraho", :aliases => "Khadzhurakho,Khadzuraho,KhadÅ¼uraho,Khajraho,KhajrÄho,Khajuraho,KhajurÃ¢ho,KhajurÄho,kajuraho,khajuraha,khajuraho,Ð¥Ð°Ð´Ð¶ÑÑÐ°ÑÐ¾,à¤à¤à¥à¤°à¤¾à¤¹à¥,à¦à¦¾à¦à§à¦°à¦¾à¦¹,à²à²à³à²°à²¾à²¹à³,ã«ã¸ã¥ã©ã¼ãã¼,KhajurÄho", :latitude => "24.85", :longitude => "79.93333").save
City.new(:country_id => "107", :name => "Khairagarh", :aliases => ",KhairÄgarh", :latitude => "26.95", :longitude => "77.81667").save
City.new(:country_id => "107", :name => "Khairagarh", :aliases => "Khairagarh,Khairagarh Raj,KhairÄgarh,KhairÄgarh", :latitude => "21.41667", :longitude => "80.96667").save
City.new(:country_id => "107", :name => "Khairabad", :aliases => ",KhairÄbÄd", :latitude => "27.53333", :longitude => "80.75").save
City.new(:country_id => "107", :name => "Khair", :aliases => ",Khair", :latitude => "27.95", :longitude => "77.83333").save
City.new(:country_id => "107", :name => "Khagaul", :aliases => "Khagaul,Khagaul", :latitude => "25.58333", :longitude => "85.05").save
City.new(:country_id => "107", :name => "Khagaria", :aliases => "Khagaria,Khagaria", :latitude => "25.5", :longitude => "86.48333").save
City.new(:country_id => "107", :name => "Khadki", :aliases => "Khadki,Kirkee,Khadki", :latitude => "18.56667", :longitude => "73.86667").save
City.new(:country_id => "107", :name => "Khada", :aliases => ",Khada", :latitude => "27.18333", :longitude => "83.88333").save
City.new(:country_id => "107", :name => "Khachrod", :aliases => "Khachrod,KhÄchrod,KhÄchrod", :latitude => "23.41667", :longitude => "75.28333").save
City.new(:country_id => "107", :name => "Kesinga", :aliases => "Kesinga,Kesinga", :latitude => "20.2", :longitude => "83.23333").save
City.new(:country_id => "107", :name => "Keshorai Patan", :aliases => ",Keshorai PÄtan", :latitude => "25.3", :longitude => "75.93333").save
City.new(:country_id => "107", :name => "Keshod", :aliases => "Keshod,Kesod,Keshod", :latitude => "21.3", :longitude => "70.25").save
City.new(:country_id => "107", :name => "Kerur", :aliases => "Kerur,KerÅ«r,KerÅ«r", :latitude => "16.01667", :longitude => "75.56667").save
City.new(:country_id => "107", :name => "Kendraparha", :aliases => "Kendrapara,Kendraparha,KendrÄparha,KendrÄpÄra,KendrÄparha", :latitude => "20.5", :longitude => "86.41667").save
City.new(:country_id => "107", :name => "Kenda", :aliases => ",Kenda", :latitude => "23.2", :longitude => "86.53333").save
City.new(:country_id => "107", :name => "Kemri", :aliases => "Kemri,Kemri", :latitude => "28.81667", :longitude => "79.21667").save
City.new(:country_id => "107", :name => "Kekri", :aliases => "Kekri,Kekri", :latitude => "25.96667", :longitude => "75.15").save
City.new(:country_id => "107", :name => "Kayankulam", :aliases => "Kayamkulam,Kayangulam,Kayankulam,KÄyankulam,KÄyankulam", :latitude => "9.18333", :longitude => "76.5").save
City.new(:country_id => "107", :name => "Kayalpattinam", :aliases => "Aramaganori,Coilnapatam,Kayalpatnam,Kayalpattinam,Kayalpatuam,KÄyalpatnam,KÄyalpattinam,KÄyalpattinam", :latitude => "8.56667", :longitude => "78.11667").save
City.new(:country_id => "107", :name => "Kawardha", :aliases => "Kawardha,Kawardha", :latitude => "22.01667", :longitude => "81.25").save
City.new(:country_id => "107", :name => "Kavali", :aliases => "Kavali,KÄvali,KÄvali", :latitude => "14.91667", :longitude => "79.98333").save
City.new(:country_id => "107", :name => "Kattivakkam", :aliases => "Kattivakkam,KattivÄkkam,KattivÄkkam", :latitude => "13.21667", :longitude => "80.31667").save
City.new(:country_id => "107", :name => "Katras", :aliases => "Katras,KÄtrÄs,KÄtrÄs", :latitude => "23.8", :longitude => "86.28333").save
City.new(:country_id => "107", :name => "Katpadi", :aliases => "Katpadi,KÄtpÄdi,KÄtpÄdi", :latitude => "12.98333", :longitude => "79.13333").save
City.new(:country_id => "107", :name => "Katoya", :aliases => "Katoya,Katwa,KÄtoya,KÄtoya", :latitude => "23.65", :longitude => "88.13333").save
City.new(:country_id => "107", :name => "Katol", :aliases => "Katol,KÄtol,KÄtol", :latitude => "21.26667", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Katihar", :aliases => "Hafiz Saifganj,Katihar,KatihÄr,KatihÄr", :latitude => "25.53333", :longitude => "87.58333").save
City.new(:country_id => "107", :name => "Kathua", :aliases => "Kathua,Kathua", :latitude => "32.36667", :longitude => "75.51667").save
City.new(:country_id => "107", :name => "Kathor", :aliases => ",KÄthor", :latitude => "21.3", :longitude => "72.93333").save
City.new(:country_id => "107", :name => "Katghora", :aliases => "Katghora,Katghora", :latitude => "22.5", :longitude => "82.55").save
City.new(:country_id => "107", :name => "Katangi", :aliases => "Katangi,Nagra Katangi,Katangi", :latitude => "23.45", :longitude => "79.78333").save
City.new(:country_id => "107", :name => "Katangi", :aliases => "Katangi,KatÄngi,KatÄngi", :latitude => "21.78333", :longitude => "79.78333").save
City.new(:country_id => "107", :name => "Kasrawad", :aliases => "Kasrawad,KasrÄwad,KasrÄwad", :latitude => "22.13333", :longitude => "75.6").save
City.new(:country_id => "107", :name => "Kashipur", :aliases => ",KÄshÄ«pur", :latitude => "29.21667", :longitude => "78.95").save
City.new(:country_id => "107", :name => "Kasganj", :aliases => "Kasganj,KÄsganj,KÄsganj", :latitude => "27.81667", :longitude => "78.65").save
City.new(:country_id => "107", :name => "Kasaragod", :aliases => "Kasaragod,Kasaragod Fort,KÄsaragod,KÄsaragod", :latitude => "12.5", :longitude => "75").save
City.new(:country_id => "107", :name => "Karwar", :aliases => "Kawar,KÄrwÄr", :latitude => "14.8", :longitude => "74.13333").save
City.new(:country_id => "107", :name => "Karur", :aliases => "Karur,KarÅ«r,KarÅ«r", :latitude => "10.95", :longitude => "78.08333").save
City.new(:country_id => "107", :name => "Kartarpur", :aliases => "Kartarpur,KartÄrpur,KartÄrpur", :latitude => "31.44", :longitude => "75.49972").save
City.new(:country_id => "107", :name => "Karsiyang", :aliases => "Karsiyang,Kharasana,Kurseong,KÄrsiyÄng,KÄrsiyÄng", :latitude => "26.88333", :longitude => "88.28333").save
City.new(:country_id => "107", :name => "Karnal", :aliases => "Karnal,KarnÄl,ÐÐ°ÑÐ½Ð°Ð»,KarnÄl", :latitude => "29.68333", :longitude => "76.98333").save
City.new(:country_id => "107", :name => "Karmala", :aliases => "Karmala,KarmÄla,KarmÄla", :latitude => "18.41667", :longitude => "75.2").save
City.new(:country_id => "107", :name => "Karkal", :aliases => "Karaka,Karkal,Karkala,KÄrkÄl,KÄrkÄl", :latitude => "13.2", :longitude => "74.98333").save
City.new(:country_id => "107", :name => "Karjat", :aliases => "Karjat,Karjat", :latitude => "18.91667", :longitude => "73.33333").save
City.new(:country_id => "107", :name => "Karimnagar", :aliases => "Karimnagar,KarÄ«mnagar,KarÄ«mnagar", :latitude => "18.43333", :longitude => "79.15").save
City.new(:country_id => "107", :name => "Karimganj", :aliases => "Karimganj,KarÄ«mganj,KarÄ«mganj", :latitude => "24.86667", :longitude => "92.35").save
City.new(:country_id => "107", :name => "Karhal", :aliases => "Karhal,Karhal", :latitude => "27.00028", :longitude => "78.94139").save
City.new(:country_id => "107", :name => "Karera", :aliases => "Karera,Karery,ÐÐ°ÑÐµÑÑ,Karera", :latitude => "25.46667", :longitude => "78.15").save
City.new(:country_id => "107", :name => "Kareli", :aliases => "Kareli,KarelÄ«,ÐÐ°ÑÐµÐ»Ð¸,KarelÄ«", :latitude => "22.91667", :longitude => "79.06667").save
City.new(:country_id => "107", :name => "Karauli", :aliases => "Karauli,Karauli", :latitude => "26.5", :longitude => "77.01667").save
City.new(:country_id => "107", :name => "Karanja", :aliases => "Karandzha,Karanja,Karanja Bibi,KÄranja,KÄranja Bibi,ÐÐ°ÑÐ°Ð½Ð´Ð¶Ð°,KÄranja", :latitude => "20.48333", :longitude => "77.48333").save
City.new(:country_id => "107", :name => "Karamsad", :aliases => "Karamsad,Karamsad", :latitude => "22.55", :longitude => "72.9").save
City.new(:country_id => "107", :name => "Karamadai", :aliases => "Karamadai,KÄramadai,KÄramadai", :latitude => "11.24058", :longitude => "76.96009").save
City.new(:country_id => "107", :name => "Karaikkudi", :aliases => "Karaikkudi,Karaikudi,KÄraikkudi,KÄraikkudi", :latitude => "10.06667", :longitude => "78.78333").save
City.new(:country_id => "107", :name => "karaikal", :aliases => "Karikal,KÄrikÄl,karaikal,kÄraikÄl,kÄraikÄl", :latitude => "10.91667", :longitude => "79.83333").save
City.new(:country_id => "107", :name => "Karad", :aliases => "Karad,KarÄd,KarÄd", :latitude => "17.28333", :longitude => "74.2").save
City.new(:country_id => "107", :name => "Kapurthala", :aliases => "Kapurtala,Kapurthala,Kapurthala Town,KapÅ«rthala,KapÅ«rthala", :latitude => "31.37944", :longitude => "75.38472").save
City.new(:country_id => "107", :name => "Kapren", :aliases => ",KÄpren", :latitude => "25.41667", :longitude => "76.06667").save
City.new(:country_id => "107", :name => "Kapadvanj", :aliases => "Kapadranj,Kapadvanj,Kapadvanj", :latitude => "23.01667", :longitude => "73.06667").save
City.new(:country_id => "107", :name => "Kanth", :aliases => ",KÄnth", :latitude => "29.06667", :longitude => "78.63333").save
City.new(:country_id => "107", :name => "Kantabanji", :aliases => "Kantabanji,KantÄbÄnji,KantÄbÄnji", :latitude => "20.48333", :longitude => "82.91667").save
City.new(:country_id => "107", :name => "Kant", :aliases => ",KÄnt", :latitude => "27.8", :longitude => "79.8").save
City.new(:country_id => "107", :name => "Kanpur", :aliases => "Cawnpore,Kanpur,Kanpuras,Kanpwr,KÄnpur,KÄnpwr,kanapura,kanpur,kanpuru,ÐÐ°Ð½Ð¿ÑÑ,×§×× ×¤××¨,à¤à¤¾à¤¨à¤ªà¥à¤°,à¦à¦¾à¦¨à¦ªà§à¦°,à®à®¾à®©à¯à®ªà¯à®°à¯,ã«ã¼ã³ãã«,KÄnpur", :latitude => "26.46667", :longitude => "80.35").save
City.new(:country_id => "107", :name => "Kannod", :aliases => "Kannod,Kannod", :latitude => "22.66667", :longitude => "76.73333").save
City.new(:country_id => "107", :name => "Kanniyakumari", :aliases => "Cap Comorin,Cape Comorin,Comorin,Kan'jakumari,Kanniakumari,Kanniyakumar,KanniyÄkumar,Kanyakumari,ÐÐ°Ð½ÑÑÐºÑÐ¼Ð°ÑÐ¸,KanniyÄkumÄri", :latitude => "8.08333", :longitude => "77.56667").save
City.new(:country_id => "107", :name => "Kannauj", :aliases => "Kanauj,Kannauj,Kannauj", :latitude => "27.0546", :longitude => "79.922").save
City.new(:country_id => "107", :name => "Kannangad", :aliases => "Kanhangad,Kannangad,KÄnnangÄd,KÄnnangÄd", :latitude => "12.30814", :longitude => "75.10632").save
City.new(:country_id => "107", :name => "Kannad", :aliases => "Kannad,Kannad", :latitude => "20.26667", :longitude => "75.13333").save
City.new(:country_id => "107", :name => "Kanker", :aliases => "Kanker,KÄnker,KÄnker", :latitude => "20.27194", :longitude => "81.49306").save
City.new(:country_id => "107", :name => "Kanke", :aliases => "Kanke,KÄnke,KÄnke", :latitude => "23.43333", :longitude => "85.31667").save
City.new(:country_id => "107", :name => "Kankauli", :aliases => "Kankauli,Kankavli,Kankauli", :latitude => "16.26667", :longitude => "73.7").save
City.new(:country_id => "107", :name => "Kanigiri", :aliases => "Kanigiri,Kanigiri", :latitude => "15.4", :longitude => "79.51667").save
City.new(:country_id => "107", :name => "Kangayam", :aliases => ",KÄngayam", :latitude => "11", :longitude => "77.56667").save
City.new(:country_id => "107", :name => "Kandukur", :aliases => ",KandukÅ«r", :latitude => "15.21667", :longitude => "79.91667").save
City.new(:country_id => "107", :name => "Kandla", :aliases => "Kandla,Kundla,KÄndla,ÐÐ°Ð½Ð´Ð»Ð°,KÄndla", :latitude => "23.03333", :longitude => "70.21667").save
City.new(:country_id => "107", :name => "Kandi", :aliases => ",KÄndi", :latitude => "23.95", :longitude => "88.03333").save
City.new(:country_id => "107", :name => "Kandhla", :aliases => "Kandhla,KÄndhla,KÄndhla", :latitude => "29.31667", :longitude => "77.26667").save
City.new(:country_id => "107", :name => "Kanchipuram", :aliases => "Conjeeveram,Conjevaram,Conjeveram,Kancheepuram,Kanchipuram,Kancipuram,Kanjippuram,KaÅÄipuram,KÄnchipuram,gan ji bu lei mu,kanchipuramu,kancipuram,kancipurama,ÐÐ°Ð½ÑÐ¸Ð¿ÑÑÐ°Ð¼,à¦à¦¾à¦à§à¦à¦¿à¦ªà§à¦°à¦®,à®à®¾à®à¯à®à®¿à®ªà¯à®°à®®à¯,ã«ã¼ã³ããã©ã ,çåå¸åå§,KÄnchipuram", :latitude => "12.83333", :longitude => "79.71667").save
City.new(:country_id => "107", :name => "Kanakapura", :aliases => "Kanakapura,Kanakpura,Kankanhalli,KÄnkÄnhalli,Kanakapura", :latitude => "12.55", :longitude => "77.41667").save
City.new(:country_id => "107", :name => "Kamthi", :aliases => "Kamptee,Kamtha,Kamthi,KÄmtha,KÄmthi,kampti,KÄmthi", :latitude => "21.23333", :longitude => "79.2").save
City.new(:country_id => "107", :name => "Kampli", :aliases => "Kampli,Kampli", :latitude => "15.4", :longitude => "76.61667").save
City.new(:country_id => "107", :name => "Kambam", :aliases => ",Kambam", :latitude => "9.73333", :longitude => "77.3").save
City.new(:country_id => "107", :name => "Kamarhati", :aliases => "Kamarhati,Kamarhatty,KÄmÄrhÄti,KÄmÄrhÄti", :latitude => "22.67111", :longitude => "88.37472").save
City.new(:country_id => "107", :name => "Kamareddi", :aliases => "Kamareddi,Kamareddipet,Kamaredi,KÄmÄreddi,KÄmÄreddi", :latitude => "18.31667", :longitude => "78.35").save
City.new(:country_id => "107", :name => "Kaman", :aliases => "Kaman,KÄman,ÐÐ°Ð¼Ð°Ð½,KÄman", :latitude => "27.65", :longitude => "77.26667").save
City.new(:country_id => "107", :name => "Kamalganj", :aliases => "Kamalganj,Kamalganj", :latitude => "27.26667", :longitude => "79.65").save
City.new(:country_id => "107", :name => "Kamakhyanagar", :aliases => "Kamakhyanagar,KÄmÄkhyÄnagar,Murhi,KÄmÄkhyÄnagar", :latitude => "20.93333", :longitude => "85.55").save
City.new(:country_id => "107", :name => "Kalyani", :aliases => ",Kalyani", :latitude => "22.98333", :longitude => "88.48333").save
City.new(:country_id => "107", :name => "Kalyan", :aliases => "Kal'jan,Kalyan,KalyÄn,ÐÐ°Ð»ÑÑÐ½,KalyÄn", :latitude => "19.25", :longitude => "73.15").save
City.new(:country_id => "107", :name => "Kalugumalai", :aliases => "Kalugumalai,Kalugumali,Kalugumalai", :latitude => "9.15", :longitude => "77.71667").save
City.new(:country_id => "107", :name => "Kalpi", :aliases => "Kalpi,KÄlpi,ÐÐ°Ð»Ð¿Ð¸,KÄlpi", :latitude => "26.11667", :longitude => "79.73333").save
City.new(:country_id => "107", :name => "Kalpetta", :aliases => "Kalpatta,Kalpetta,Kalpetta", :latitude => "11.61056", :longitude => "76.08222").save
City.new(:country_id => "107", :name => "Kalol", :aliases => "Kalol,KÄlol,KÄlol", :latitude => "22.6", :longitude => "73.45").save
City.new(:country_id => "107", :name => "Kalna", :aliases => "Kalna,KÄlna,ÐÐ°Ð»Ð½Ð°,KÄlna", :latitude => "23.21667", :longitude => "88.36667").save
City.new(:country_id => "107", :name => "Kalmeshwar", :aliases => ",Kalmeshwar", :latitude => "21.23333", :longitude => "78.9").save
City.new(:country_id => "107", :name => "Kallidaikurichchi", :aliases => "Kailidaikorichchi,Kallidaikurichchi,Kallidaikurichchi", :latitude => "8.66667", :longitude => "77.48333").save
City.new(:country_id => "107", :name => "Kallakkurichchi", :aliases => ",Kallakkurichchi", :latitude => "11.73333", :longitude => "78.96667").save
City.new(:country_id => "107", :name => "Kalka", :aliases => "Kalka,Kalki,KÄlka,ÐÐ°Ð»ÐºÐ¸,KÄlka", :latitude => "30.83444", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Kaliyaganj", :aliases => "Kaliaganj,Kaliyagan,Kaliyaganj,KÄliyÄgan,KÄliyÄganj,KÄliyÄganj", :latitude => "25.63333", :longitude => "88.31667").save
City.new(:country_id => "107", :name => "Kalimpang", :aliases => "Kalimpang,Kalimpong,KÄlimpang,ÐÐ°Ð»Ð¸Ð¼Ð¿Ð¾Ð½Ð³,KÄlimpang", :latitude => "27.06667", :longitude => "88.48333").save
City.new(:country_id => "107", :name => "Kalghatgi", :aliases => "Kalghatgi,Kalghatgi", :latitude => "15.18333", :longitude => "74.96667").save
City.new(:country_id => "107", :name => "Kalavad", :aliases => "Kalavad,KÄlÄvad,KÄlÄvad", :latitude => "22.21667", :longitude => "70.38333").save
City.new(:country_id => "107", :name => "Kalanwali", :aliases => ",KÄlÄnwÄli", :latitude => "29.85", :longitude => "74.95").save
City.new(:country_id => "107", :name => "Kalanaur", :aliases => "Kalanaur,KalÄnaur,KalÄnaur", :latitude => "28.83333", :longitude => "76.4").save
City.new(:country_id => "107", :name => "Kalamnuri", :aliases => "Kalamnuri,KalamnÅ«ri,KalamnÅ«ri", :latitude => "19.66667", :longitude => "77.33333").save
City.new(:country_id => "107", :name => "Kalamb", :aliases => ",Kalamb", :latitude => "19.05", :longitude => "73.95").save
City.new(:country_id => "107", :name => "Kalakkadu", :aliases => "Kalakad,Kalakkadu,KalakkÄdu,KalakkÄdu", :latitude => "8.5", :longitude => "77.56667").save
City.new(:country_id => "107", :name => "Kakrala", :aliases => "Kakrala,KakrÄla,KakrÄla", :latitude => "27.8927", :longitude => "79.1965").save
City.new(:country_id => "107", :name => "Kakori", :aliases => "Kakori,KÄkori,KÄkori", :latitude => "26.88333", :longitude => "80.8").save
City.new(:country_id => "107", :name => "Kakinada", :aliases => "Cocanada,Coconada,East Godavari,Godavari,Kakinada,KÄkinÄda,ÐÐ°ÐºÐ¸Ð½Ð°Ð´Ð°,KÄkinÄda", :latitude => "16.93333", :longitude => "82.21667").save
City.new(:country_id => "107", :name => "Kakching", :aliases => "Kakching,Kakching", :latitude => "24.48333", :longitude => "93.98333").save
City.new(:country_id => "107", :name => "Kaithal", :aliases => "Kaithal,Kaithal", :latitude => "29.8", :longitude => "76.38333").save
City.new(:country_id => "107", :name => "Kairana", :aliases => "Kairana,KairÄna,KairÄna", :latitude => "29.4", :longitude => "77.2").save
City.new(:country_id => "107", :name => "Kaimori", :aliases => "Kaimori,Kaimur,Kymore,Kaimori", :latitude => "23.38333", :longitude => "79.75").save
City.new(:country_id => "107", :name => "Kaimganj", :aliases => "Kaimganj,Kaimganj", :latitude => "27.56667", :longitude => "79.35").save
City.new(:country_id => "107", :name => "Kailashahar", :aliases => "Kailasahar,Kailashahar,KailÄshahar,KailÄshahar", :latitude => "24.33333", :longitude => "92.01667").save
City.new(:country_id => "107", :name => "Kailaras", :aliases => "Kailaras,KailÄras,KailÄras", :latitude => "26.31667", :longitude => "77.61667").save
City.new(:country_id => "107", :name => "Kaikalur", :aliases => ",KaikalÅ«r", :latitude => "16.56667", :longitude => "81.2").save
City.new(:country_id => "107", :name => "Kagal", :aliases => "Kagal,KÄgal,KÄgal", :latitude => "16.58333", :longitude => "74.31667").save
City.new(:country_id => "107", :name => "Kadur", :aliases => "Kadur,KadÅ«r,KadÅ«r", :latitude => "13.55333", :longitude => "76.01306").save
City.new(:country_id => "107", :name => "Kadod", :aliases => ",Kadod", :latitude => "21.21667", :longitude => "73.23333").save
City.new(:country_id => "107", :name => "Kadiri", :aliases => "Kadiri,ÐÐ°Ð´Ð¸ÑÐ¸,Kadiri", :latitude => "14.11667", :longitude => "78.16667").save
City.new(:country_id => "107", :name => "Kadi", :aliases => ",Kadi", :latitude => "23.3", :longitude => "72.33333").save
City.new(:country_id => "107", :name => "Kadaiyanallur", :aliases => "Kadaiyanallur,KadaiyanallÅ«r,Kadayanallur,KadaiyanallÅ«r", :latitude => "9.08333", :longitude => "77.35").save
City.new(:country_id => "107", :name => "Kanchrapara", :aliases => "Kachrapara,Kancharapara,Kanchrapara,KÄchrÄpÄra,KÄnchrÄpÄra,KÄnchrÄpÄra", :latitude => "22.97", :longitude => "88.43194").save
City.new(:country_id => "107", :name => "Kachhwa", :aliases => "Kachhwa,KachhwÄ,KachhwÄ", :latitude => "25.21667", :longitude => "82.71667").save
City.new(:country_id => "107", :name => "Kabrai", :aliases => "Kabrai,Kabral,Kabrai", :latitude => "25.41667", :longitude => "80.01667").save
City.new(:country_id => "107", :name => "Junnar", :aliases => "Junnar,Shivner,Junnar", :latitude => "19.2", :longitude => "73.88333").save
City.new(:country_id => "107", :name => "Junagarh", :aliases => ",JÅ«nÄgarh", :latitude => "19.86667", :longitude => "82.93333").save
City.new(:country_id => "107", :name => "Junagadh", :aliases => "Junagad,Junagadh,Junagarh,Junaghur,JÅ«nÄgadh,JÅ«nÄgadh", :latitude => "21.51667", :longitude => "70.46667").save
City.new(:country_id => "107", :name => "Jumri Tilaiya", :aliases => "Jhumri Telaiya,Jhumri Tellaya,Jumri Tilaiya,Jumri TilaiyÄ,Kodarma,Jumri TilaiyÄ", :latitude => "24.43333", :longitude => "85.51667").save
City.new(:country_id => "107", :name => "Jalandhar", :aliases => "Jalandhar,Jullundur,Jullundur City,Jalandhar", :latitude => "31.32556", :longitude => "75.57917").save
City.new(:country_id => "107", :name => "Jugsalai", :aliases => "Jugsalai,JugsÄlai,Tatanagar,JugsÄlai", :latitude => "22.76667", :longitude => "86.18333").save
City.new(:country_id => "107", :name => "Jorhat", :aliases => "Dzhorkhat,Jorhat,JorhÄt,Sibsagar,SibsÃ¡gar,ÐÐ¶Ð¾ÑÑÐ°Ñ,JorhÄt", :latitude => "26.75", :longitude => "94.21667").save
City.new(:country_id => "107", :name => "Jora", :aliases => "Jora,Joura,Zhora,ÐÐ¾ÑÐ°,Jora", :latitude => "26.33333", :longitude => "77.81667").save
City.new(:country_id => "107", :name => "Jolarpettai", :aliases => "Jalarpet,JalÄrpet,Jolarpettai,JolÄrpettai,JolÄrpettai", :latitude => "12.56667", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Jogbani", :aliases => "Jogbani,Jogbani", :latitude => "26.41667", :longitude => "87.25").save
City.new(:country_id => "107", :name => "Jodiya Bandar", :aliases => "Jodiya,Jodiya Bandar,Jodiya Bandar", :latitude => "22.71667", :longitude => "70.28333").save
City.new(:country_id => "107", :name => "Jodhpur", :aliases => "Dzhodkhpur,Dzodhpur,DÅ¼odhpur,Jodhpur,Jodhpur City,jodhapura,jodopuru,ÐÐ¶Ð¾Ð´ÑÐ¿ÑÑ,à¤à¥à¤§à¤ªà¥à¤°,á¯áááá£á á,ã¸ã§ããã«,ã¸ã§ã¼ããã«,Jodhpur", :latitude => "26.28667", :longitude => "73.03").save
City.new(:country_id => "107", :name => "Jodhpur", :aliases => ",Jodhpur", :latitude => "21.88333", :longitude => "70.03333").save
City.new(:country_id => "107", :name => "Jintur", :aliases => "Jintur,JintÅ«r,JintÅ«r", :latitude => "19.61667", :longitude => "76.7").save
City.new(:country_id => "107", :name => "Jind", :aliases => "Jind,JÄ«nd,JÄ«nd", :latitude => "29.31667", :longitude => "76.31667").save
City.new(:country_id => "107", :name => "Jhusi", :aliases => "Jhusi,JhÅ«si,Pratishthanpur,JhÅ«si", :latitude => "25.43333", :longitude => "81.93333").save
City.new(:country_id => "107", :name => "Jhunjhunun", :aliases => "Jhunjhunu,Jhunjhunun,JhunjhunÅ«n,JhÅ«njhunu,JhunjhunÅ«n", :latitude => "28.1307", :longitude => "75.4014").save
City.new(:country_id => "107", :name => "Jhinjhana", :aliases => "Jhinjhana,JhinjhÄna,JhinjhÄna", :latitude => "29.51667", :longitude => "77.21667").save
City.new(:country_id => "107", :name => "Jhinjhak", :aliases => "Jhinjhak,Jhinjhak", :latitude => "26.56667", :longitude => "79.73333").save
City.new(:country_id => "107", :name => "Jharsuguda", :aliases => "Jharsaguda,Jharsguda,Jharsogra,Jharsugra,Jharsuguda,Jharsugude,JhÄrsugra,JhÄrsuguda,JhÄrsuguda", :latitude => "21.85", :longitude => "84.03333").save
City.new(:country_id => "107", :name => "Jharia", :aliases => ",Jharia", :latitude => "23.75", :longitude => "86.4").save
City.new(:country_id => "107", :name => "Jhargram", :aliases => "Jharagram,Jhargram,JhÄragrÄm,JhÄrgrÄm,JhÄrgrÄm", :latitude => "22.45", :longitude => "86.98333").save
City.new(:country_id => "107", :name => "Jhansi", :aliases => "Jhansi,JhÄnsi,JhÄnsi", :latitude => "25.43333", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Jhanjharpur", :aliases => "Jhanjharpur,JhanjhÄrpur,JhanjhÄrpur", :latitude => "26.26667", :longitude => "86.28333").save
City.new(:country_id => "107", :name => "Jhalu", :aliases => "Jhalu,JhÄlÅ«,JhÄlÅ«", :latitude => "29.35", :longitude => "78.25").save
City.new(:country_id => "107", :name => "Jhalrapatan", :aliases => "Jhalrapatan,Jhalrapatan Chhroni,Jhalrapatan City,Jhalrapatna City,JhÄlrapÄtan,JhÄlrapÄtan Chhroni,Patan,PÄtan,JhÄlrapÄtan", :latitude => "24.55", :longitude => "76.16667").save
City.new(:country_id => "107", :name => "Jhalida", :aliases => ",Jhalida", :latitude => "23.36667", :longitude => "85.96667").save
City.new(:country_id => "107", :name => "Jhalawar", :aliases => "Brijnagar,Jhalawar,JhÄlÄwÄr,JhÄlÄwÄr", :latitude => "24.6", :longitude => "76.15").save
City.new(:country_id => "107", :name => "Jhajjar", :aliases => "Jhajjar,Jhajjar", :latitude => "28.61667", :longitude => "76.65").save
City.new(:country_id => "107", :name => "Jha Jha", :aliases => ",JhÄ JhÄ", :latitude => "24.76667", :longitude => "86.36667").save
City.new(:country_id => "107", :name => "Jhabua", :aliases => "Dkhabua,Jhabua,JhÄbua,ÐÑÐ°Ð±ÑÐ°,JhÄbua", :latitude => "22.76667", :longitude => "74.6").save
City.new(:country_id => "107", :name => "Jewar", :aliases => "Jewar,Jewar", :latitude => "28.13333", :longitude => "77.55").save
City.new(:country_id => "107", :name => "Jevargi", :aliases => "Jalvergi,Jevargi,Jevargi", :latitude => "17.01667", :longitude => "76.76667").save
City.new(:country_id => "107", :name => "Jetpur", :aliases => ",Jetpur", :latitude => "21.73333", :longitude => "70.61667").save
City.new(:country_id => "107", :name => "Jaypur", :aliases => "Jaypur,Jeyepore,Jeypore,Jaypur", :latitude => "18.85", :longitude => "82.58333").save
City.new(:country_id => "107", :name => "Jaynagar", :aliases => "Jayanagar,Jaynagar,Jaynagar", :latitude => "26.58333", :longitude => "86.15").save
City.new(:country_id => "107", :name => "Jaynagar-Majilpur", :aliases => "Jaynagar,Jaynagar-Majilpur,Jaynagar-Majilpur", :latitude => "22.17583", :longitude => "88.41778").save
City.new(:country_id => "107", :name => "Jayamkondacholapuram", :aliases => "Jayamkondacholapuram,Jayankondacholpuram,Jayamkondacholapuram", :latitude => "11.21667", :longitude => "79.36667").save
City.new(:country_id => "107", :name => "Jawad", :aliases => "Jawad,JÄwad,JÄwad", :latitude => "24.6", :longitude => "74.85").save
City.new(:country_id => "107", :name => "Jaunpur", :aliases => "Jaunpur,Jaunpur", :latitude => "25.73333", :longitude => "82.68333").save
City.new(:country_id => "107", :name => "Jatara", :aliases => "Jatara,JatÄra,JatÄra", :latitude => "25.01667", :longitude => "79.05").save
City.new(:country_id => "107", :name => "Jatani", :aliases => "Jatani,Jatni,JÄtni,Jatani", :latitude => "20.16667", :longitude => "85.7").save
City.new(:country_id => "107", :name => "Jaswantnagar", :aliases => "Jaswantnagar,Jaswantnagar", :latitude => "26.87861", :longitude => "78.90278").save
City.new(:country_id => "107", :name => "Jaspur", :aliases => ",Jaspur", :latitude => "29.28333", :longitude => "78.81667").save
City.new(:country_id => "107", :name => "Jasidih", :aliases => "Jasidih,Jasidih", :latitude => "24.51667", :longitude => "86.65").save
City.new(:country_id => "107", :name => "Jashpurnagar", :aliases => "Jashpur,Jashpurnagar,Jashpurnagar", :latitude => "22.9", :longitude => "84.15").save
City.new(:country_id => "107", :name => "Jasdan", :aliases => "Jasdan,Jasdan", :latitude => "22.03333", :longitude => "71.2").save
City.new(:country_id => "107", :name => "Jarwal", :aliases => "Jarwal,Jarwal", :latitude => "27.16667", :longitude => "81.55").save
City.new(:country_id => "107", :name => "Jaora", :aliases => "Jaora,JaorÄ,JaorÄ", :latitude => "23.63333", :longitude => "75.13333").save
City.new(:country_id => "107", :name => "Jansath", :aliases => "Jansath,JÄnsath,JÄnsath", :latitude => "29.33333", :longitude => "77.85").save
City.new(:country_id => "107", :name => "Jangipur", :aliases => ",Jangipur", :latitude => "24.46667", :longitude => "88.06667").save
City.new(:country_id => "107", :name => "Jangaon", :aliases => "Jangaon,Jangoon,Jangaon", :latitude => "17.71667", :longitude => "79.18333").save
City.new(:country_id => "107", :name => "Jandiala", :aliases => "Jandiala,Jandiali,JandiÄla,JandiÄla", :latitude => "31.16667", :longitude => "75.61667").save
City.new(:country_id => "107", :name => "Jamuria", :aliases => "Jamuria,Jaykayanagar,Jaykaynagar,JÄmuria,JÄmuria", :latitude => "23.7", :longitude => "87.08333").save
City.new(:country_id => "107", :name => "Jamui", :aliases => "Jamui,JamÅ«i,JamÅ«i", :latitude => "24.91667", :longitude => "86.21667").save
City.new(:country_id => "107", :name => "Jamtara", :aliases => "Jamtara,JÄmtÄra,JÄmtÄra", :latitude => "23.95", :longitude => "86.8").save
City.new(:country_id => "107", :name => "Jamshedpur", :aliases => "Dzhamshedpur,Jamshedpur,Jarnshedpur,Tatanagar,jamasedapura,jamsetpur,jamushedopuru,jia mu xie de bu er,ÐÐ¶Ð°Ð¼ÑÐµÐ´Ð¿ÑÑ,à¤à¤®à¤¶à¥à¤¦à¤ªà¥à¤°,à¦à¦®à¦¶à§à¦¦à¦ªà§à¦°,à®à®¾à®®à¯à®·à¯à®à¯à®ªà¯à®°à¯,ã¸ã£ã ã·ã§ããã«,ã¸ã£ã ã·ã§ã¼ããã«,è´¾å§è°¢å¾·å¸å°,Jamshedpur", :latitude => "22.8", :longitude => "86.18333").save
City.new(:country_id => "107", :name => "Jamnagar", :aliases => "Dzhamnagarom,Jamnagar,Jamnogar,JÄmnagar,Navanagar,Navangar,Nawanagar,Nowanagar,Nowanuggur,ÐÐ¶Ð°Ð¼Ð½Ð°Ð³Ð°ÑÐ¾Ð¼,JÄmnagar", :latitude => "22.46667", :longitude => "70.06667").save
City.new(:country_id => "107", :name => "Jammu", :aliases => "Dzammu,Dzhammu,DÅ¾ammÃº,Jammu,Jammu City,jam'mu,janmu,ÐÐ¶Ð°Ð¼Ð¼Ñ,Ø¬ÙÙÚº,à¤à¤®à¥à¤®à¥,à¦à¦®à§à¦®à§,ã¸ã£ã³ã ã¼,Jammu", :latitude => "32.73333", :longitude => "74.86667").save
City.new(:country_id => "107", :name => "Jammalamadugu", :aliases => "Jammalamadugu,Jammalamadugu", :latitude => "14.83333", :longitude => "78.4").save
City.new(:country_id => "107", :name => "Jamkhandi", :aliases => "Jamkhandi,Jamkhandi", :latitude => "16.51667", :longitude => "75.3").save
City.new(:country_id => "107", :name => "Jambusar", :aliases => "Jambusar,Jambusar", :latitude => "22.05", :longitude => "72.8").save
City.new(:country_id => "107", :name => "Jamalpur", :aliases => ",JamÄlpur", :latitude => "25.3", :longitude => "86.5").save
City.new(:country_id => "107", :name => "Jamai", :aliases => "Jamai,JÄmai,JÄmai", :latitude => "22.2", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Jamadoba", :aliases => "Jamadoba,JÄmadoba,JÄmadoba", :latitude => "23.71667", :longitude => "86.4").save
City.new(:country_id => "107", :name => "Jalpaiguri", :aliases => "Jalpaiguri,JalpÄiguri,Paiguri,JalpÄiguri", :latitude => "26.51667", :longitude => "88.73333").save
City.new(:country_id => "107", :name => "Jalor", :aliases => ",Jalor", :latitude => "25.35", :longitude => "72.61667").save
City.new(:country_id => "107", :name => "Jalna", :aliases => "Jalna,JÄlna,JÄlna", :latitude => "19.83333", :longitude => "75.88333").save
City.new(:country_id => "107", :name => "Jalgaon", :aliases => "Dzhalgaone,Jaigaon,Jalgaon,JÄigaon,JÄlgaon,ÐÐ¶Ð°Ð»Ð³Ð°Ð¾Ð½Ðµ,JÄlgaon", :latitude => "21.04861", :longitude => "76.53444").save
City.new(:country_id => "107", :name => "Jalgaon", :aliases => "Dzhalgaone,Jalgaon,JÄlgaon,ÐÐ¶Ð°Ð»Ð³Ð°Ð¾Ð½Ðµ,JÄlgaon", :latitude => "21.01667", :longitude => "75.56667").save
City.new(:country_id => "107", :name => "Jaleshwar", :aliases => "Jaleshwar,Jaleswar,Jaleshwar", :latitude => "21.81667", :longitude => "87.21667").save
City.new(:country_id => "107", :name => "Jalesar", :aliases => "Jalesar,Jalesar Town,Jalesar", :latitude => "27.48333", :longitude => "78.31667").save
City.new(:country_id => "107", :name => "Jalaun", :aliases => "Jalaun,JÄlaun,JÄlaun", :latitude => "26.1451", :longitude => "79.3366").save
City.new(:country_id => "107", :name => "Jalalpur", :aliases => ",JalÄlpur", :latitude => "26.31667", :longitude => "82.73333").save
City.new(:country_id => "107", :name => "Jalalpur", :aliases => "Jalalpore,Jalalpur,JalÄlpur,Surat,JalÄlpur", :latitude => "20.96667", :longitude => "72.9").save
City.new(:country_id => "107", :name => "Jalali", :aliases => "Jalali,JalÄli,JalÄli", :latitude => "27.86667", :longitude => "78.26667").save
City.new(:country_id => "107", :name => "Jalalabad", :aliases => ",JalÄlÄbÄd", :latitude => "30.61667", :longitude => "74.25").save
City.new(:country_id => "107", :name => "Jalalabad", :aliases => ",JalÄlÄbÄd", :latitude => "29.61861", :longitude => "77.43833").save
City.new(:country_id => "107", :name => "Jalalabad", :aliases => ",JalÄlÄbÄd", :latitude => "27.7242", :longitude => "79.6599").save
City.new(:country_id => "107", :name => "Jajpur", :aliases => "Gaypur,Jajpur,JÄjpur,JÄjpur", :latitude => "20.85", :longitude => "86.33333").save
City.new(:country_id => "107", :name => "Jaito", :aliases => ",Jaito", :latitude => "30.46667", :longitude => "74.88333").save
City.new(:country_id => "107", :name => "Jaitaran", :aliases => "Jaitaran,JaitÄran,JaitÄran", :latitude => "26.20306", :longitude => "73.93639").save
City.new(:country_id => "107", :name => "Jaisingpur", :aliases => "Jaisingpur,Jayasingpar,Jaysingpur,Jaisingpur", :latitude => "16.8", :longitude => "74.56667").save
City.new(:country_id => "107", :name => "Jaisalmer", :aliases => "Dzhajsalmer,Jaisalmer,ÐÐ¶Ð°Ð¹ÑÐ°Ð»Ð¼ÐµÑ,Jaisalmer", :latitude => "26.91468", :longitude => "70.91808").save
City.new(:country_id => "107", :name => "Jais", :aliases => "Jais,JÄis,JÄis", :latitude => "26.25", :longitude => "81.53333").save
City.new(:country_id => "107", :name => "Jaipur", :aliases => "Dzaipur,Dzaipuras,Dzajpur,Dzhajpur,DÅºajpur,DÅ¾aipur,DÅ¾aipuras,Jainagar,Jaipur,Jaipur City,Jayapur,Jeypore,jaipuleu,jaipuru,jayapura,jeyppur,ÐÐ°ÑÐ¿ÑÑ,ÐÐ¶Ð°Ð¹Ð¿ÑÑ,Ø¬Û Ù¾ÙØ±,à¤à¤¯à¤ªà¥à¤°,à¤à¤¯à¤ªà¥à¤°,à¦à¦¯à¦¼à¦ªà§à¦°,à®à¯à®¯à¯à®ªà¯à®ªà¯à®°à¯,ã¸ã£ã¤ãã«,ìì´í¸ë¥´,Jaipur", :latitude => "26.91667", :longitude => "75.81667").save
City.new(:country_id => "107", :name => "Jahazpur", :aliases => "Jahazpur,JahÄzpur,JahÄzpur", :latitude => "25.61667", :longitude => "75.28333").save
City.new(:country_id => "107", :name => "Jahangirabad", :aliases => ",JahÄngÄ«rÄbÄd", :latitude => "28.41667", :longitude => "78.1").save
City.new(:country_id => "107", :name => "Jahanabad", :aliases => ",JahÄnÄbÄd", :latitude => "25.21667", :longitude => "84.98333").save
City.new(:country_id => "107", :name => "Jagtial", :aliases => "Jagtial,JagtiÄl,JagtiÄl", :latitude => "18.8", :longitude => "78.93333").save
City.new(:country_id => "107", :name => "Jagraon", :aliases => "Jagraon,Jagraon", :latitude => "30.78333", :longitude => "75.48333").save
City.new(:country_id => "107", :name => "Jaggayyapeta", :aliases => ",Jaggayyapeta", :latitude => "16.9", :longitude => "80.1").save
City.new(:country_id => "107", :name => "Jagdispur", :aliases => ",JagdÄ«spur", :latitude => "25.48333", :longitude => "84.41667").save
City.new(:country_id => "107", :name => "Jagdalpur", :aliases => "Jagdalpur,Jagdalpur", :latitude => "19.06667", :longitude => "82.03333").save
City.new(:country_id => "107", :name => "Jagatsinghapur", :aliases => "Jagatsinghapur,Jagatsinghpur,Jagatsingpur,Jagatsinghapur", :latitude => "20.26667", :longitude => "86.16667").save
City.new(:country_id => "107", :name => "Jagalur", :aliases => "Jagalur,JagalÅ«r,JagalÅ«r", :latitude => "14.53333", :longitude => "76.35").save
City.new(:country_id => "107", :name => "Jagadhri", :aliases => "Jagadhri,JagÄdhri,JagÄdhri", :latitude => "30.16667", :longitude => "77.3").save
City.new(:country_id => "107", :name => "Jabalpur", :aliases => "Dzabalpur,Dzabalpuras,Dzhabalpur,DÅºabalpur,DÅ¾abalpuras,Jabalpur,Jubbulpore,jabalapura,jabarupuru,jblpur,ÐÐ¶Ð°Ð±Ð°Ð»Ð¿ÑÑ,Ø¬Ø¨ÙÙ¾ÙØ±,à¤à¤¬à¤²à¤ªà¥à¤°,ã¸ã£ãã«ãã«,Jabalpur", :latitude => "23.16697", :longitude => "79.95006").save
City.new(:country_id => "107", :name => "Itimadpur", :aliases => ",ItimÄdpur", :latitude => "27.25", :longitude => "78.2").save
City.new(:country_id => "107", :name => "Itarsi", :aliases => "Itarsi,ItÄrsi,ItÄrsi", :latitude => "22.61667", :longitude => "77.75").save
City.new(:country_id => "107", :name => "Itanagar", :aliases => "Itanagar,ItÄnagar,Kalyanpur,itanagara,itanagaru,ittanakar,ÐÑÐ°Ð½Ð°Ð³Ð°Ñ,à¤à¤à¤¾à¤¨à¤à¤°,à¤à¤à¤¾à¤¨à¤à¤°,à¦à¦à¦¾à¦¨à¦à¦°,à®à®à¯à®à®¾à®¨à®à®°à¯,ã¤ã¿ãã¬ã«,ã¤ã¼ã¿ã¼ãã¬ã«,ItÄnagar", :latitude => "27.1", :longitude => "93.61667").save
City.new(:country_id => "107", :name => "Islampur", :aliases => ",IslÄmpur", :latitude => "26.26667", :longitude => "88.2").save
City.new(:country_id => "107", :name => "Islampur", :aliases => "Islampur,IslÄmpur,IslÄmpur", :latitude => "25.15", :longitude => "85.2").save
City.new(:country_id => "107", :name => "Islamnagar", :aliases => "Islamnagar,IslÄmnagar,IslÄmnagar", :latitude => "28.33333", :longitude => "78.71667").save
City.new(:country_id => "107", :name => "Irugur", :aliases => "Irugur,IrugÅ«r,IrugÅ«r", :latitude => "11.01667", :longitude => "77.06667").save
City.new(:country_id => "107", :name => "Irinjalakuda", :aliases => "Irinjalakuda,IrinjÄlakuda,IrinjÄlakuda", :latitude => "10.33333", :longitude => "76.23333").save
City.new(:country_id => "107", :name => "Ingraj Bazar", :aliases => "English Bazar,English BÄzÄr,Ingraj Bazar,IngrÄj BÄzÄr,IngrÄj BÄzÄr", :latitude => "25", :longitude => "88.15").save
City.new(:country_id => "107", :name => "Indri", :aliases => "Indri,Ramgarh,RÄmgarh,Indri", :latitude => "29.88", :longitude => "77.07111").save
City.new(:country_id => "107", :name => "Indore", :aliases => "Indaur,Indor,Indore,Induras,indaura,indora,indoru,indura,ÐÐ½Ð´Ð¾Ñ,à¤à¤à¤¦à¥à¤°,à¤à¤à¤¦à¥à¤°,à¦à¦¨à§à¦¦à§à¦°,ã¤ã³ãã¼ã«,Indore", :latitude => "22.71792", :longitude => "75.8333").save
City.new(:country_id => "107", :name => "Indi", :aliases => ",Indi", :latitude => "17.16667", :longitude => "75.96667").save
City.new(:country_id => "107", :name => "Indergarh", :aliases => "Indergarh,Indergarh", :latitude => "26.9352", :longitude => "79.6724").save
City.new(:country_id => "107", :name => "Indapur", :aliases => "Indapur,Indapuri,IndÄpur,IndÄpur", :latitude => "18.3", :longitude => "73.25").save
City.new(:country_id => "107", :name => "Imphal", :aliases => "Imphal,ImphÄl,Impkhal,impal,imphala,inparu,ÐÐ¼Ð¿ÑÐ°Ð»,à¤à¤à¤«à¤¾à¤²,à¤à¤®à¥à¤«à¤¾à¤²,à¦à¦®à§à¦«à¦²,à®à®®à¯à®ªà®¾à®²à¯,ã¤ã³ãã¼ã«,ImphÄl", :latitude => "24.81667", :longitude => "93.95").save
City.new(:country_id => "107", :name => "Ilkal", :aliases => "Ilkal,Ilkal", :latitude => "15.96667", :longitude => "76.13333").save
City.new(:country_id => "107", :name => "Igatpuri", :aliases => "Igatpuri,Vigatpuri,Wigatpura,Igatpuri", :latitude => "19.7", :longitude => "73.55").save
City.new(:country_id => "107", :name => "Idappadi", :aliases => ",IdÄppÄdi", :latitude => "11.58333", :longitude => "77.85").save
City.new(:country_id => "107", :name => "Ichchapuram", :aliases => "Ichapuram,Ichchapur,Ichchapuram,IchchÄpuram,Ichekapuram,IchchÄpuram", :latitude => "19.11667", :longitude => "84.7").save
City.new(:country_id => "107", :name => "Ichalkaranji", :aliases => "Ichalkaranji,Ichalkaranji", :latitude => "16.7", :longitude => "74.46667").save
City.new(:country_id => "107", :name => "Hyderabad", :aliases => "Bhaganagar,Haidarabadas,Haiderabad,Hajdarabad,HajdarÃ¡bÃ¡d,Hyderabad,Hyderabad-Deccan,HyderÄbÄd,Khajdarabad,Khajderabad,hai de la ba,haidarabada,haidarabadu,haiderabado,haitarapat,hayadarabada ema. karporesana,hayadrabada,hydr abad,hydr abad dkn,hydrabad,Ð¥Ð°Ð¹Ð´Ð°ÑÐ°Ð±Ð°Ð´,Ð¥Ð°ÑÐ´ÐµÑÐ°Ð±Ð°Ð´,Ø­ÛØ¯Ø± Ø¢Ø¨Ø§Ø¯,Ø­ÛØ¯Ø± Ø¢Ø¨Ø§Ø¯ Ø¯Ú©Ù,Ø­ÛØ¯Ø±Ø¢Ø¨Ø§Ø¯,à¤¹à¥à¤¦à¤°à¤¾à¤¬à¤¾à¤¦,à¦¹à¦¾à¦¯à¦¼à¦¦à¦°à¦¾à¦¬à¦¾à¦¦ à¦à¦®. à¦à¦°à§à¦ªà§à¦°à§à¦¶à¦¨,à¦¹à¦¾à¦¯à¦¼à¦¦à§à¦°à¦¾à¦¬à¦¾à¦¦,à®¹à¯à®¤à®°à®¾à®ªà®¾à®¤à¯,à°¹à±à°¦à°°à°¾à°¬à°¾à°¦à±,ãã¤ãã©ãã¼ã,æµ·å¾æå·´,HyderÄbÄd", :latitude => "17.37528", :longitude => "78.47444").save
City.new(:country_id => "107", :name => "Huvinabadgalli", :aliases => "Hadagalli,Huvinabadgalli,Huvvmahadagalli,Huvinabadgalli", :latitude => "15.01667", :longitude => "75.95").save
City.new(:country_id => "107", :name => "Husainabad", :aliases => "Husainabad,HusainÄbÄd,Jopla,HusainÄbÄd", :latitude => "24.53333", :longitude => "84.01667").save
City.new(:country_id => "107", :name => "Hunsur", :aliases => "Hunsur,HunsÅ«r,Khunsur,Ð¥ÑÐ½ÑÑÑ,HunsÅ«r", :latitude => "12.3075", :longitude => "76.28778").save
City.new(:country_id => "107", :name => "Hungund", :aliases => "Hungund,Hungund", :latitude => "16.06667", :longitude => "76.05").save
City.new(:country_id => "107", :name => "Hukeri", :aliases => "Hukeri,Hukeri", :latitude => "16.23333", :longitude => "74.6").save
City.new(:country_id => "107", :name => "Hugli", :aliases => "Hooghly,Hooghly-Chinsura,Hooghly-Chinsurah,Hugli,Khugli,Ð¥ÑÐ³Ð»Ð¸,Hugli", :latitude => "22.89556", :longitude => "88.4025").save
City.new(:country_id => "107", :name => "Hubli", :aliases => "Hubballi,Hubli,Hubli City,à²¹à³à²¬à³à²¬à²³à³à²³à²¿,Hubli", :latitude => "15.35", :longitude => "75.16667").save
City.new(:country_id => "107", :name => "Howli", :aliases => "Howli,Howli", :latitude => "26.43333", :longitude => "90.96667").save
City.new(:country_id => "107", :name => "Hosur", :aliases => "Hosur,HosÅ«r,Oossoor,HosÅ«r", :latitude => "12.71667", :longitude => "77.81667").save
City.new(:country_id => "107", :name => "Hospet", :aliases => "Hosapete,Hospet,Khospet,Ð¥Ð¾ÑÐ¿ÐµÑ,à²¹à³à²¸à³à²ªà³à²à³,Hospet", :latitude => "15.26667", :longitude => "76.4").save
City.new(:country_id => "107", :name => "Hoskote", :aliases => "Hoskote,Hoskote", :latitude => "13.06694", :longitude => "77.79833").save
City.new(:country_id => "107", :name => "Hoshiarpur", :aliases => "Hoshiarpur,HoshiÄrpur,Hushiarpur,HoshiÄrpur", :latitude => "31.53222", :longitude => "75.91722").save
City.new(:country_id => "107", :name => "Hoshangabad", :aliases => "Hoshangabad,HoshangÄbÄd,HoshangÄbÄd", :latitude => "22.75", :longitude => "77.71667").save
City.new(:country_id => "107", :name => "Hosdurga", :aliases => "Hosadurga,Hosdurga,Hosdurga", :latitude => "13.79806", :longitude => "76.28611").save
City.new(:country_id => "107", :name => "Honnali", :aliases => "Honnali,HonnÄli,HonnÄli", :latitude => "14.25", :longitude => "75.66667").save
City.new(:country_id => "107", :name => "Honavar", :aliases => "Honavar,Honawar,Honore,HonÄvar,Onore,HonÄvar", :latitude => "14.28333", :longitude => "74.45").save
City.new(:country_id => "107", :name => "Homnabad", :aliases => "Hominabad,Homnabad,HomnÄbÄd,HomnÄbÄd", :latitude => "17.76667", :longitude => "77.13333").save
City.new(:country_id => "107", :name => "Hole Narsipur", :aliases => ",Hole Narsipur", :latitude => "12.78278", :longitude => "76.24306").save
City.new(:country_id => "107", :name => "Holalkere", :aliases => "Holalkere,Holalkere", :latitude => "14.03333", :longitude => "76.18333").save
City.new(:country_id => "107", :name => "Hojai", :aliases => "Hojai,HojÄi,HojÄi", :latitude => "26", :longitude => "92.86667").save
City.new(:country_id => "107", :name => "Hodal", :aliases => "Hodal,Hodal", :latitude => "27.9", :longitude => "77.36667").save
City.new(:country_id => "107", :name => "Hisua", :aliases => "Hisua,Hisua", :latitude => "24.83333", :longitude => "85.41667").save
City.new(:country_id => "107", :name => "Hisar", :aliases => "Hisar,Hissar,HissÄr,HisÄr,Khisar,Ð¥Ð¸ÑÐ°Ñ,HisÄr", :latitude => "29.16667", :longitude => "75.71667").save
City.new(:country_id => "107", :name => "Hiriyur", :aliases => "Hiriyur,HiriyÅ«r,HiriyÅ«r", :latitude => "13.94556", :longitude => "76.61917").save
City.new(:country_id => "107", :name => "Hirekerur", :aliases => "Hirekerur,HirekerÅ«r,HirekerÅ«r", :latitude => "14.46667", :longitude => "75.38333").save
City.new(:country_id => "107", :name => "Hirakud", :aliases => "Hirakud,HÄ«rÄkÅ«d,HÄ«rÄkÅ«d", :latitude => "21.51667", :longitude => "83.86667").save
City.new(:country_id => "107", :name => "Hinjilikatu", :aliases => "Hinjili,Hinjilicut,Hinjilikatu,Hinjilikatu", :latitude => "19.48333", :longitude => "84.75").save
City.new(:country_id => "107", :name => "Hingoli", :aliases => "Hingoli,Hingoli", :latitude => "19.71667", :longitude => "77.15").save
City.new(:country_id => "107", :name => "Hinganghat", :aliases => "Hinganghat,HinganghÄt,HinganghÄt", :latitude => "20.56667", :longitude => "78.83333").save
City.new(:country_id => "107", :name => "Hindupur", :aliases => "Hindupur,Hindupur", :latitude => "13.82889", :longitude => "77.49333").save
City.new(:country_id => "107", :name => "Hindoria", :aliases => "Hindoria,HindoriÄ,HindoriÄ", :latitude => "23.9", :longitude => "79.56667").save
City.new(:country_id => "107", :name => "Hindaun", :aliases => "Hindaun,Hindaun", :latitude => "26.71667", :longitude => "77.01667").save
City.new(:country_id => "107", :name => "Himatnagar", :aliases => "Ahmadnagar,Ahmednagar,Himatnagar,Himatnagar", :latitude => "23.6", :longitude => "72.95").save
City.new(:country_id => "107", :name => "Hilsa", :aliases => "Hilsa,Hilsa", :latitude => "25.31667", :longitude => "85.28333").save
City.new(:country_id => "107", :name => "Hazaribag", :aliases => "Hazaribag,Hazaribagh,Hazarybaugh,HazÄribÄgh,HazÄrÄ«bÄg,Khazaribag,hajaribaga,Ð¥Ð°Ð·Ð°ÑÐ¸Ð±Ð°Ð³,à¤¹à¤à¤¾à¤°à¥à¤¬à¤¾à¤,HazÄrÄ«bÄg", :latitude => "23.98333", :longitude => "85.35").save
City.new(:country_id => "107", :name => "Haveri", :aliases => "Haveri,HÄveri,HÄveri", :latitude => "14.8", :longitude => "75.4").save
City.new(:country_id => "107", :name => "Hatta", :aliases => "Hatla,Hatta,Khatta,Ð¥Ð°ÑÑÐ°,Hatta", :latitude => "24.11667", :longitude => "79.6").save
City.new(:country_id => "107", :name => "Hathras", :aliases => "Hathras,HÄthras,HÄthras", :latitude => "27.6", :longitude => "78.05").save
City.new(:country_id => "107", :name => "Hastinapur", :aliases => "Hastinapur,HastinÄpur,HastinÄpur", :latitude => "29.16667", :longitude => "78.01667").save
City.new(:country_id => "107", :name => "Hassan", :aliases => "Hassan,Khasan,ha sang,hasana,Ð¥Ð°ÑÐ°Ð½,à²¹à²¾à²¸à²¨,åæ¡,Hassan", :latitude => "13.00056", :longitude => "76.09944").save
City.new(:country_id => "107", :name => "Hasimara", :aliases => "Hashimara,Hasimara,HÄsimÄra,HÄsimÄra", :latitude => "26.75", :longitude => "89.35").save
City.new(:country_id => "107", :name => "Hasanpur", :aliases => "Hasanpur,Hasanpur", :latitude => "28.71667", :longitude => "78.28333").save
City.new(:country_id => "107", :name => "Harur", :aliases => "Harur,HarÅ«r,HarÅ«r", :latitude => "12.06667", :longitude => "78.5").save
City.new(:country_id => "107", :name => "Harsud", :aliases => "Harsud,HarsÅ«d,HarsÅ«d", :latitude => "22.1", :longitude => "76.73333").save
City.new(:country_id => "107", :name => "Harpanahalli", :aliases => "Harpanahalli,Harpanahalli", :latitude => "14.8", :longitude => "75.98333").save
City.new(:country_id => "107", :name => "Harpalpur", :aliases => ",HarpÄlpur", :latitude => "25.2884", :longitude => "79.3347").save
City.new(:country_id => "107", :name => "Harij", :aliases => "Harij,HÄrij,HÄrij", :latitude => "23.7", :longitude => "71.9").save
City.new(:country_id => "107", :name => "Harihar", :aliases => "Harihar,Harihar", :latitude => "14.51667", :longitude => "75.8").save
City.new(:country_id => "107", :name => "Haridwar", :aliases => "Hardwar,HardwÄr,Haridwar,HaridwÄr,Kharidvar,haridvara,Ð¥Ð°ÑÐ¸Ð´Ð²Ð°Ñ,à¤¹à¤°à¤¿à¤¦à¥à¤µà¤¾à¤°,HaridwÄr", :latitude => "29.96667", :longitude => "78.16667").save
City.new(:country_id => "107", :name => "Hardoi", :aliases => "Hardoi,HardoÄ«,HardoÄ«", :latitude => "27.41667", :longitude => "80.11667").save
City.new(:country_id => "107", :name => "Harda", :aliases => "Harda,Harda", :latitude => "22.33333", :longitude => "77.1").save
City.new(:country_id => "107", :name => "Hapur", :aliases => "Hapur,HÄpur,HÄpur", :latitude => "28.71667", :longitude => "77.78333").save
City.new(:country_id => "107", :name => "Haora", :aliases => "Haora,Haura,Hawrah,Howrah,HÄora,ha'ora,haura,à¦¹à¦¾à¦à¦¡à¦¼à¦¾,ãã¦ã©ã¼,ãã¼ã¦ã©ã¼,HÄora", :latitude => "22.58917", :longitude => "88.31028").save
City.new(:country_id => "107", :name => "Hanumangarh", :aliases => "Hanumangarh,HanumÄngarh,Sadulgarh,HanumÄngarh", :latitude => "29.58333", :longitude => "74.31667").save
City.new(:country_id => "107", :name => "Hansi", :aliases => "Hansi,HÄnsi,Khansi,Ð¥Ð°Ð½ÑÐ¸,HÄnsi", :latitude => "29.1", :longitude => "75.96667").save
City.new(:country_id => "107", :name => "Hangal", :aliases => "Hangal,HÄngal,HÄngal", :latitude => "14.76667", :longitude => "75.13333").save
City.new(:country_id => "107", :name => "Handia", :aliases => "Handia,HandiÄ,HandiÄ", :latitude => "25.38333", :longitude => "82.18333").save
City.new(:country_id => "107", :name => "Hamirpur", :aliases => ",HamÄ«rpur", :latitude => "31.68333", :longitude => "76.51667").save
City.new(:country_id => "107", :name => "Hamirpur", :aliases => ",HamÄ«rpur", :latitude => "25.95", :longitude => "80.15").save
City.new(:country_id => "107", :name => "Halvad", :aliases => "Halvad,Halwad,Halvad", :latitude => "23.01667", :longitude => "71.18333").save
City.new(:country_id => "107", :name => "Halol", :aliases => "Halol,HÄlol,HÄlol", :latitude => "22.5", :longitude => "73.46667").save
City.new(:country_id => "107", :name => "Haliyal", :aliases => "Haliyal,HaliyÄl,HaliyÄl", :latitude => "15.33333", :longitude => "74.76667").save
City.new(:country_id => "107", :name => "Halisahar", :aliases => "Halisahar,Halishahar,HÄlÄ«sahar,HÄlÄ«sahar", :latitude => "22.94972", :longitude => "88.41944").save
City.new(:country_id => "107", :name => "Haldwani", :aliases => "Haldwani,HaldwÄni,HaldwÄni", :latitude => "29.21667", :longitude => "79.51667").save
City.new(:country_id => "107", :name => "Haldaur", :aliases => "Haldaur,Haldaur", :latitude => "29.3", :longitude => "78.28333").save
City.new(:country_id => "107", :name => "Hajo", :aliases => "Hajo,HÄjo,Nij Hajo,Nij HÄjo,HÄjo", :latitude => "26.25", :longitude => "91.53333").save
City.new(:country_id => "107", :name => "Hajipur", :aliases => "Khadzhipur,Ð¥Ð°Ð´Ð¶Ð¸Ð¿ÑÑ,HÄjÄ«pur", :latitude => "25.68333", :longitude => "85.21667").save
City.new(:country_id => "107", :name => "Hailakandi", :aliases => "Hailakandi,Hailikandi,HailÄkÄndi,Hylakandi,HailÄkÄndi", :latitude => "24.68333", :longitude => "92.56667").save
City.new(:country_id => "107", :name => "Haflong", :aliases => "Haflang,Haflong,HÄflong,HÄflong", :latitude => "25.18333", :longitude => "93.03333").save
City.new(:country_id => "107", :name => "Hadgaon", :aliases => "Hadgaon,Hadgaon", :latitude => "19.5", :longitude => "77.66667").save
City.new(:country_id => "107", :name => "Habra", :aliases => "Habra,HÄbra,HÄbra", :latitude => "22.83444", :longitude => "88.6275").save
City.new(:country_id => "107", :name => "Gwalior", :aliases => "Gvalior,Gwalior,ÐÐ²Ð°Ð»Ð¸Ð¾Ñ,Gwalior", :latitude => "26.22361", :longitude => "78.17917").save
City.new(:country_id => "107", :name => "Guskhara", :aliases => "Gushkara,Guskhara,Guskhara", :latitude => "23.5", :longitude => "87.75").save
City.new(:country_id => "107", :name => "Guruvayur", :aliases => "Guruvayur,GuruvÄyÅ«r,GuruvÄyÅ«r", :latitude => "10.6", :longitude => "76.05").save
City.new(:country_id => "107", :name => "Guru Har Sahai", :aliases => ",Guru Har SahÄi", :latitude => "30.71667", :longitude => "74.41667").save
City.new(:country_id => "107", :name => "Gursarai", :aliases => "Gursarai,GursarÄi,GursarÄi", :latitude => "25.6148", :longitude => "79.1788").save
City.new(:country_id => "107", :name => "Gursahaiganj", :aliases => "Gursahaiganj,GursahÄiganj,GursahÄiganj", :latitude => "27.11667", :longitude => "79.71667").save
City.new(:country_id => "107", :name => "Gurmatkal", :aliases => "Gurmatkal,Gurmatkol,Gurmatkal", :latitude => "16.86667", :longitude => "77.4").save
City.new(:country_id => "107", :name => "Gurgaon", :aliases => "Gurgaon,ÐÑÑÐ³Ð°Ð¾Ð½,Gurgaon", :latitude => "28.46667", :longitude => "77.03333").save
City.new(:country_id => "107", :name => "Gunupur", :aliases => "Gunupur,Gunupur", :latitude => "19.08333", :longitude => "83.81667").save
City.new(:country_id => "107", :name => "Guntur", :aliases => "Guntur,Guntura,GuntÅ«r,ÐÑÐ½ÑÑÑÐ°,GuntÅ«r", :latitude => "16.3", :longitude => "80.45").save
City.new(:country_id => "107", :name => "Guntakal", :aliases => "Guntakai,Guntakal,Guntakal", :latitude => "15.16667", :longitude => "77.38333").save
City.new(:country_id => "107", :name => "Gunnaur", :aliases => "Gunnaur,Gunnaur", :latitude => "28.25", :longitude => "78.43333").save
City.new(:country_id => "107", :name => "Gundlupet", :aliases => "Gundalpet,Gundlupet,Gundlupet", :latitude => "11.8", :longitude => "76.68333").save
City.new(:country_id => "107", :name => "Guna", :aliases => ",Guna", :latitude => "24.65", :longitude => "77.31667").save
City.new(:country_id => "107", :name => "Gummidipundi", :aliases => "Gummidipundi,GummidipÅ«ndi,Gummudipundi,GummudipÅ«ndi,GummidipÅ«ndi", :latitude => "13.4", :longitude => "80.15").save
City.new(:country_id => "107", :name => "Gumla", :aliases => ",Gumla", :latitude => "23.05", :longitude => "84.55").save
City.new(:country_id => "107", :name => "Gumia", :aliases => "Gumia,Gumia", :latitude => "23.78333", :longitude => "85.81667").save
City.new(:country_id => "107", :name => "Guledagudda", :aliases => "Guledagudda,Guledgarh,Guledgud,Guledgudd,Guledagudda", :latitude => "16.05", :longitude => "75.8").save
City.new(:country_id => "107", :name => "Gulbarga", :aliases => "Gul'barga,Gulbarga,Gulburga,Kalburgi,Kulbarga,gu er bo jia,gulbarga,gurubaruga,ÐÑÐ»ÑÐ±Ð°ÑÐ³Ð°,à²à²¾à²²à²¬à³à²°à³à²à²¿,à²à³à²²à³à²¬à²°à³à²,ã°ã«ãã«ã¬,å¤å°ä¼¯å ,Gulbarga", :latitude => "17.33333", :longitude => "76.83333").save
City.new(:country_id => "107", :name => "Gulaothi", :aliases => "Gulaothi,Gulaothi", :latitude => "28.6", :longitude => "77.78333").save
City.new(:country_id => "107", :name => "Gulabpura", :aliases => "Gulabpura,GulÄbpura,GulÄbpura", :latitude => "25.9", :longitude => "74.66667").save
City.new(:country_id => "107", :name => "Guduvancheri", :aliases => ",GÅ«duvÄncheri", :latitude => "12.8425", :longitude => "80.06389").save
City.new(:country_id => "107", :name => "Gudur", :aliases => "Gudur,GÅ«dÅ«r,GÅ«dÅ«r", :latitude => "14.13333", :longitude => "79.85").save
City.new(:country_id => "107", :name => "Gudiyattam", :aliases => ",GudiyÄttam", :latitude => "12.95", :longitude => "78.86667").save
City.new(:country_id => "107", :name => "Gudivada", :aliases => "Gudivada,GudivÄda,GudivÄda", :latitude => "16.45", :longitude => "80.98333").save
City.new(:country_id => "107", :name => "Gudalur", :aliases => "Gudalur,GÅ«dalÅ«r,GÅ«dalÅ«r", :latitude => "9.68333", :longitude => "77.26667").save
City.new(:country_id => "107", :name => "Gubbi", :aliases => "Gubbi,Gubbi", :latitude => "13.31056", :longitude => "76.94444").save
City.new(:country_id => "107", :name => "Goyerkata", :aliases => ",GoyerkÄta", :latitude => "26.69984", :longitude => "89.02565").save
City.new(:country_id => "107", :name => "Govardhan", :aliases => "Gobardhan,Govardhan,Govardkhan,ÐÐ¾Ð²Ð°ÑÐ´ÑÐ°Ð½,Govardhan", :latitude => "27.5", :longitude => "77.46667").save
City.new(:country_id => "107", :name => "Gorakhpur", :aliases => "Gorakhpur,Gorakpura,ÐÐ¾ÑÐ°ÐºÐ¿ÑÑÐ°,Gorakhpur", :latitude => "29.45", :longitude => "75.68333").save
City.new(:country_id => "107", :name => "Gorakhpur", :aliases => "Gorakhpur,Gorakpura,Goruckpur,Korakhpur,ÐÐ¾ÑÐ°ÐºÐ¿ÑÑÐ°,Gorakhpur", :latitude => "26.755", :longitude => "83.37389").save
City.new(:country_id => "107", :name => "Gopichettipalaiyam", :aliases => "Gobichettipalaiyam,Gobichettipalayam,Gobichettipalyam,Gopichettipalaiyam,GopichettipÄlaiyam,GopichettipÄlaiyam", :latitude => "11.46667", :longitude => "77.45").save
City.new(:country_id => "107", :name => "Gopalganj", :aliases => ",GopÄlganj", :latitude => "26.46667", :longitude => "84.43333").save
City.new(:country_id => "107", :name => "Gondia", :aliases => ",Gondia", :latitude => "21.45", :longitude => "80.2").save
City.new(:country_id => "107", :name => "Gondal", :aliases => "Gondal,Gondal", :latitude => "21.96667", :longitude => "70.8").save
City.new(:country_id => "107", :name => "Gonda", :aliases => "Gonda,Gonda Oudh,ÐÐ¾Ð½Ð´Ð°,Gonda", :latitude => "27.13333", :longitude => "81.93333").save
City.new(:country_id => "107", :name => "Gomoh", :aliases => "Gomoh,Gomoh", :latitude => "23.86667", :longitude => "86.16667").save
City.new(:country_id => "107", :name => "Gola Gokarannath", :aliases => "Gola,Gola Gokarannath,Gola GokarannÄth,Gola GokarannÄth", :latitude => "28.08333", :longitude => "80.46667").save
City.new(:country_id => "107", :name => "Golaghat", :aliases => "Golaghat,GolÄghÄt,GolÄghÄt", :latitude => "26.51667", :longitude => "93.96667").save
City.new(:country_id => "107", :name => "Gokarna", :aliases => "Gokarn,ÐÐ¾ÐºÐ°ÑÐ½,Gokarna", :latitude => "14.55", :longitude => "74.31667").save
City.new(:country_id => "107", :name => "Gokak", :aliases => "Gokak,GokÄk,ÐÐ¾ÐºÐ°Ðº,GokÄk", :latitude => "16.16667", :longitude => "74.83333").save
City.new(:country_id => "107", :name => "Gohana", :aliases => "Gohana,GohÄna,GohÄna", :latitude => "29.13333", :longitude => "76.7").save
City.new(:country_id => "107", :name => "Gohad", :aliases => "Gohad,Gohad", :latitude => "26.42611", :longitude => "78.44472").save
City.new(:country_id => "107", :name => "Godhra", :aliases => "Godhr,Godhra,Godkhre,ÐÐ¾Ð´ÑÑÐµ,Godhra", :latitude => "22.75", :longitude => "73.63333").save
City.new(:country_id => "107", :name => "Godda", :aliases => "Godda,GoddÄ,GoddÄ", :latitude => "24.83333", :longitude => "87.21667").save
City.new(:country_id => "107", :name => "Gobindpur", :aliases => ",Gobindpur", :latitude => "22.63333", :longitude => "86.06667").save
City.new(:country_id => "107", :name => "Gobardanga", :aliases => "Gobardanga,GobÄrdÄnga,GobÄrdÄnga", :latitude => "22.87472", :longitude => "88.75861").save
City.new(:country_id => "107", :name => "Goalpara", :aliases => "Goalpara,GoÄlpÄra,GoÄlpÄra", :latitude => "26.16667", :longitude => "90.61667").save
City.new(:country_id => "107", :name => "Giridih", :aliases => "Giridih,GirÄ«dÄ«h,girid'iha,girid'iha jila,giridi,Ú¯Ø±ÛÚÛÛÛ,à¤à¤¿à¤°à¥à¤¡à¥à¤¹,à¤à¤¿à¤°à¥à¤¡à¥à¤¹ à¤à¤¿à¤²à¤¾,à¦à¦¿à¦°à¦¿à¦¡à¦¿,GirÄ«dÄ«h", :latitude => "24.18333", :longitude => "86.3").save
City.new(:country_id => "107", :name => "Gingee", :aliases => "Gingee,Gingee", :latitude => "12.25", :longitude => "79.41667").save
City.new(:country_id => "107", :name => "Giddarbaha", :aliases => ",GiddarbÄha", :latitude => "30.2", :longitude => "74.66667").save
City.new(:country_id => "107", :name => "Giddalur", :aliases => ",GiddalÅ«r", :latitude => "15.35", :longitude => "78.91667").save
City.new(:country_id => "107", :name => "Ghugus", :aliases => "Ghugus,GhÅ«gus,GhÅ«gus", :latitude => "19.93333", :longitude => "79.13333").save
City.new(:country_id => "107", :name => "Ghoti Budrukh", :aliases => "Ghoti,Ghoti Budrukh,Ghoti Budrukh", :latitude => "19.71667", :longitude => "73.63333").save
City.new(:country_id => "107", :name => "Ghosi", :aliases => "Ghosi,Ghosi", :latitude => "26.10833", :longitude => "83.54361").save
City.new(:country_id => "107", :name => "Ghazipur", :aliases => "Ghazipur,GhÄzÄ«pur,GhÄzÄ«pur", :latitude => "25.58333", :longitude => "83.56667").save
City.new(:country_id => "107", :name => "Ghaziabad", :aliases => "Gaziabad,Ghaziabad,Ghazibad,GhÄziÄbÄd,ÐÐ°Ð·Ð¸Ð°Ð±Ð°Ð´,GhÄziÄbÄd", :latitude => "28.66667", :longitude => "77.43333").save
City.new(:country_id => "107", :name => "Ghatsila", :aliases => "Ghatshila,Ghatsila,GhÄtsÄ«la,GhÄtsÄ«la", :latitude => "22.6", :longitude => "86.48333").save
City.new(:country_id => "107", :name => "Ghatanji", :aliases => "Ghatanji,GhÄtanji,GhÄtanji", :latitude => "20.13333", :longitude => "78.31667").save
City.new(:country_id => "107", :name => "Ghatampur", :aliases => "Ghatampur,GhÄtampur,GhÄtampur", :latitude => "26.16667", :longitude => "80.16667").save
City.new(:country_id => "107", :name => "Ghatal", :aliases => "Ghatal,GhÄtÄl,GhÄtÄl", :latitude => "22.66667", :longitude => "87.71667").save
City.new(:country_id => "107", :name => "Gharaunda", :aliases => "Gharaunda,Gharaunda", :latitude => "29.5375", :longitude => "76.97167").save
City.new(:country_id => "107", :name => "Gevrai", :aliases => ",Gevrai", :latitude => "19.26667", :longitude => "75.75").save
City.new(:country_id => "107", :name => "Gaya", :aliases => ",Gaya", :latitude => "24.78333", :longitude => "85").save
City.new(:country_id => "107", :name => "Gauripur", :aliases => "Gauripur,Gauripur", :latitude => "26.08333", :longitude => "89.96667").save
City.new(:country_id => "107", :name => "Gauribidanur", :aliases => "Gauibidanur,Gauribidanur,GauribidanÅ«r,Goribidnur,GoribidnÅ«r,GauribidanÅ«r", :latitude => "13.61111", :longitude => "77.51667").save
City.new(:country_id => "107", :name => "Guwahati", :aliases => "Gauhati,GauhÄti,Guvakhati,Guwahati,guraahati,guvahati,guwahati,ÐÑÐ²Ð°ÑÐ°ÑÐ¸,à¤à¥à¤µà¤¾à¤¹à¤¾à¤à¥,à¦à§à§±à¦¾à¦¹à¦¾à¦à¦¿,ã°ã¯ããã£,ã°ã¯ã¼ãã¼ãã£ã¼,GuwÄhÄti", :latitude => "26.18617", :longitude => "91.75095").save
City.new(:country_id => "107", :name => "Garwa", :aliases => ",Garwa", :latitude => "24.18333", :longitude => "83.81667").save
City.new(:country_id => "107", :name => "Garui", :aliases => ",Garui", :latitude => "22.63333", :longitude => "88.4").save
City.new(:country_id => "107", :name => "Gariadhar", :aliases => "Gariadhar,Gariyadhar,Gariadhar", :latitude => "21.53333", :longitude => "71.58333").save
City.new(:country_id => "107", :name => "Garhshankar", :aliases => "Garhshankar,Garshankar,Garhshankar", :latitude => "31.21667", :longitude => "76.13333").save
City.new(:country_id => "107", :name => "Garhmuktesar", :aliases => ",Garhmuktesar", :latitude => "28.8", :longitude => "78.1").save
City.new(:country_id => "107", :name => "Garhakota", :aliases => "Garhakota,GarhÄkotÄ,GarhÄkotÄ", :latitude => "23.76667", :longitude => "79.15").save
City.new(:country_id => "107", :name => "Gannavaram", :aliases => ",Gannavaram", :latitude => "16.53333", :longitude => "80.8").save
City.new(:country_id => "107", :name => "Gangtok", :aliases => "Gangtok,Gangtok", :latitude => "27.33333", :longitude => "88.61667").save
City.new(:country_id => "107", :name => "Gangolli", :aliases => "Gangolli,Ganguli,Gangolli", :latitude => "13.65", :longitude => "74.66667").save
City.new(:country_id => "107", :name => "Gangoh", :aliases => "Gangoh,Gangoh", :latitude => "29.76667", :longitude => "77.25").save
City.new(:country_id => "107", :name => "Gangawati", :aliases => "Gangavati,Gangawati,GangÄwati,GangÄwati", :latitude => "15.43333", :longitude => "76.53333").save
City.new(:country_id => "107", :name => "Gangarampur", :aliases => "Gangarampur,GangÄrÄmpur,GangÄrÄmpur", :latitude => "25.4", :longitude => "88.51667").save
City.new(:country_id => "107", :name => "Gangapur", :aliases => ",GangÄpur", :latitude => "26.48333", :longitude => "76.71667").save
City.new(:country_id => "107", :name => "Gangapur", :aliases => ",GangÄpur", :latitude => "25.21667", :longitude => "74.26667").save
City.new(:country_id => "107", :name => "Gangapur", :aliases => ",GangÄpur", :latitude => "19.68333", :longitude => "75.01667").save
City.new(:country_id => "107", :name => "Ganganagar", :aliases => "Ganganagar,GangÄnagar,Sri Ganganagar,Sri GangÄnagar,Sriganga Najar,GangÄnagar", :latitude => "29.91667", :longitude => "73.88333").save
City.new(:country_id => "107", :name => "Gangakher", :aliases => ",GangÄkher", :latitude => "18.95", :longitude => "76.75").save
City.new(:country_id => "107", :name => "Gandhinagar", :aliases => "Gandhinagar,Gandinagar,Ghandinagar,GÄndhÄ«nagar,gamdhinagara,gandhinagara,gandinagaru,ganjinagaru,kanti nakar,ÐÐ°Ð½Ð´Ð¸Ð½Ð°Ð³Ð°Ñ,à¤à¤¾à¤à¤§à¥à¤¨à¤à¤°,à¦à¦¾à¦¨à§à¦§à¦¿à¦¨à¦à¦°,à¦à¦¾à¦¨à§à¦§à§à¦¨à¦à¦°,àªàª¾àªàª§à«àª¨àªàª°,à®à®¾à®¨à¯à®¤à®¿ à®¨à®à®°à¯,ã¬ã³ã¸ãã¬ã«,ã¬ã¼ã³ãã£ã¼ãã¬ã«,GÄndhÄ«nagar", :latitude => "23.21667", :longitude => "72.68333").save
City.new(:country_id => "107", :name => "Gandevi", :aliases => "Ganadevi,Gandevi,Gandevi", :latitude => "20.81667", :longitude => "72.98333").save
City.new(:country_id => "107", :name => "Gandarbal", :aliases => "Gandarbal,Ganderbal,GÄndarbal,GÄndarbal", :latitude => "34.23333", :longitude => "74.78333").save
City.new(:country_id => "107", :name => "Gajraula", :aliases => "Gajraula,Gajraula", :latitude => "28.85", :longitude => "78.23333").save
City.new(:country_id => "107", :name => "Gajendragarh", :aliases => "Gajendragad,Gajendragarh,Gajendragarh", :latitude => "15.73333", :longitude => "75.98333").save
City.new(:country_id => "107", :name => "Gadwal", :aliases => "Gadwal,GadwÄl,GadwÄl", :latitude => "16.23333", :longitude => "77.8").save
City.new(:country_id => "107", :name => "Gadhinglaj", :aliases => "Gadhinglaj,Gadhinglaj", :latitude => "16.23333", :longitude => "74.35").save
City.new(:country_id => "107", :name => "Gadhada", :aliases => "Gadhada,Gadhada", :latitude => "21.96667", :longitude => "71.56667").save
City.new(:country_id => "107", :name => "Gadarwara", :aliases => "Gadarwara,GÄdarwÄra,GÄdarwÄra", :latitude => "22.91667", :longitude => "78.78333").save
City.new(:country_id => "107", :name => "Gadag", :aliases => "Gadag,Gadag", :latitude => "15.41667", :longitude => "75.61667").save
City.new(:country_id => "107", :name => "Fort Gloster", :aliases => ",Fort Gloster", :latitude => "22.50444", :longitude => "88.18333").save
City.new(:country_id => "107", :name => "Forbesganj", :aliases => "Forbesganj,Forbesganj", :latitude => "26.3", :longitude => "87.25").save
City.new(:country_id => "107", :name => "Firozpur Jhirka", :aliases => "Ferozepur,Ferozepur-Jhirka,Ferozpur Jhirka,Firozpur Jhirka,FÄrozpur Jhirka,FÄ«rozpur Jhirka,FÄ«rozpur Jhirka", :latitude => "27.8", :longitude => "76.95").save
City.new(:country_id => "107", :name => "Firozpur", :aliases => "Ferozepore,Ferozepur,Feruzpur,Firozpur,FÄrÅ«zpur,FÄ«rozpur,FÄ«rozpur", :latitude => "30.91667", :longitude => "74.6").save
City.new(:country_id => "107", :name => "Firozabad", :aliases => "Firozabad,FÄ«rozÄbÄd,FÄ«rozÄbÄd", :latitude => "27.15", :longitude => "78.41667").save
City.new(:country_id => "107", :name => "Ferokh", :aliases => "Ferok,Feroke,Ferokh,Ferokh", :latitude => "11.18333", :longitude => "75.85").save
City.new(:country_id => "107", :name => "Fazilka", :aliases => "Fazika,Fazilka,FÄzilka,FÄzilka", :latitude => "30.4", :longitude => "74.03333").save
City.new(:country_id => "107", :name => "Fatwa", :aliases => ",Fatwa", :latitude => "25.51667", :longitude => "85.31667").save
City.new(:country_id => "107", :name => "Fatehpur Sikri", :aliases => "Fatehpur Sikri,Fatehpur SÄ«kri,Fatehpur-Sikri,Fatehpur-SikrÃ®,Fatekhpur Sikri,phatehapura sikari,phatepur sikri,Ð¤Ð°ÑÐµÑÐ¿ÑÑ Ð¡Ð¸ÐºÑÐ¸,Ù¾Ú¾ØªÛÛÙ¾ÙÙØ± Ø³ÙÚ©Ø±Û,à¤«à¤¤à¥à¤¹à¤ªà¥à¤° à¤¸à¤¿à¤à¤°à¥,à²«à²¤à³à²ªà³à²°à³ à²¸à²¿à²à³à²°à²¿,Fatehpur SÄ«kri", :latitude => "27.1", :longitude => "77.66667").save
City.new(:country_id => "107", :name => "Fatehpur", :aliases => ",Fatehpur", :latitude => "27.98333", :longitude => "74.95").save
City.new(:country_id => "107", :name => "Fatehpur", :aliases => ",Fatehpur", :latitude => "27.16667", :longitude => "81.21667").save
City.new(:country_id => "107", :name => "Fatehpur", :aliases => "Fatehpur,Fatehpur City,Fatekhpur,Ð¤Ð°ÑÐµÑÐ¿ÑÑ,Fatehpur", :latitude => "25.93333", :longitude => "80.8").save
City.new(:country_id => "107", :name => "Fatehgarh Churian", :aliases => "Chaurian Fatehgarh,Fatehgarh Churian,Fatehgarh ChÅ«riÄn,Fatehgarh ChÅ«riÄn", :latitude => "31.86207", :longitude => "74.95534").save
City.new(:country_id => "107", :name => "Fatehganj West", :aliases => ",Fatehganj West", :latitude => "28.46667", :longitude => "79.3").save
City.new(:country_id => "107", :name => "Fatehabad", :aliases => "Fatahabad,Fatehabad,FatehÄbÄd,FatehÄbÄd", :latitude => "29.51667", :longitude => "75.45").save
City.new(:country_id => "107", :name => "Fatehabad", :aliases => ",FatehÄbÄd", :latitude => "27.01667", :longitude => "78.31667").save
City.new(:country_id => "107", :name => "Farrukhnagar", :aliases => ",Farrukhnagar", :latitude => "17.07778", :longitude => "78.20111").save
City.new(:country_id => "107", :name => "Farrukhabad", :aliases => "Farrukhabad,FarrukhÄbÄd,FarrukhÄbÄd", :latitude => "27.4", :longitude => "79.56667").save
City.new(:country_id => "107", :name => "Faridpur", :aliases => ",FarÄ«dpur", :latitude => "28.21667", :longitude => "79.55").save
City.new(:country_id => "107", :name => "Faridkot", :aliases => ",FarÄ«dkot", :latitude => "30.66667", :longitude => "74.75").save
City.new(:country_id => "107", :name => "Faridabad", :aliases => "Faridabad,Faridabadas,FarÄ«dÄbÄd,faridabado,pharidabada,Ð¤Ð°ÑÐ¸Ð´Ð°Ð±Ð°Ð´,à¤«à¤°à¥à¤¦à¤¾à¤¬à¤¾à¤¦,ãã¡ãªããã¼ã,ãã¡ãªã¼ãã¼ãã¼ã,FarÄ«dÄbÄd", :latitude => "28.43333", :longitude => "77.31667").save
City.new(:country_id => "107", :name => "Farakka", :aliases => ",Farakka", :latitude => "24.81667", :longitude => "87.9").save
City.new(:country_id => "107", :name => "Falakata", :aliases => "Falakata,FÄlÄkÄta,FÄlÄkÄta", :latitude => "26.53333", :longitude => "89.2").save
City.new(:country_id => "107", :name => "Faizpur", :aliases => "Faizpur,Faizpur", :latitude => "21.16667", :longitude => "75.85").save
City.new(:country_id => "107", :name => "Faizabad", :aliases => "Faizabad,FaizÄbÄd,Fajzabad,Fyzabad,Ð¤Ð°Ð¹Ð·Ð°Ð±Ð°Ð´,FaizÄbÄd", :latitude => "26.78333", :longitude => "82.13333").save
City.new(:country_id => "107", :name => "Etawah", :aliases => "Etawah,EtÄwah,EtÄwah", :latitude => "26.7769", :longitude => "79.0239").save
City.new(:country_id => "107", :name => "Erraguntla", :aliases => "Erraguntla,Yerraguntla,Erraguntla", :latitude => "14.63333", :longitude => "78.53333").save
City.new(:country_id => "107", :name => "Erode", :aliases => "Brod,Erode,Irodu,Periyar,PeriyÄr,erode,irodo~u,irotu,ÐÑÐ¾Ð´,à¦à¦°à§à¦¡à§,à®à®°à¯à®à¯,ã¤ã¼ã­ã¼ãã¥,Erode", :latitude => "11.35", :longitude => "77.73333").save
City.new(:country_id => "107", :name => "Erattupetta", :aliases => "Erattupetta,Eratupeta,ErÄttupetta,ErÄttupetta", :latitude => "9.7", :longitude => "76.78333").save
City.new(:country_id => "107", :name => "Erandol", :aliases => "Erandol,Erandol", :latitude => "20.91667", :longitude => "75.33333").save
City.new(:country_id => "107", :name => "Emmiganuru", :aliases => "Emmiganur,Emmiganuru,EmmiganÅ«r,EmmiganÅ«ru,Yemmiganur,EmmiganÅ«ru", :latitude => "15.73333", :longitude => "77.48333").save
City.new(:country_id => "107", :name => "Eluru", :aliases => "Ellore,Eluru,ElÅ«ru,West Godavari,West GodÄvari,ElÅ«ru", :latitude => "16.7", :longitude => "81.1").save
City.new(:country_id => "107", :name => "Elur", :aliases => ",ElÅ«r", :latitude => "10.06667", :longitude => "76.28333").save
City.new(:country_id => "107", :name => "Ellenabad", :aliases => "Ellenabad,EllenÄbÄd,Kharyal,EllenÄbÄd", :latitude => "29.45", :longitude => "74.65").save
City.new(:country_id => "107", :name => "Elamanchili", :aliases => "Elamanchili,Yellamanchili,Yellamanchilli,Elamanchili", :latitude => "17.55", :longitude => "82.86667").save
City.new(:country_id => "107", :name => "Egra", :aliases => "Egra,Egra", :latitude => "21.9", :longitude => "87.53333").save
City.new(:country_id => "107", :name => "Dwarka", :aliases => "Dvarka,Dwarka,DwÄrka,ÐÐ²Ð°ÑÐºÐ°,DwÄrka", :latitude => "22.23944", :longitude => "68.96778").save
City.new(:country_id => "107", :name => "Durgapur", :aliases => "Durgapur,DurgÄpur,ÐÑÑÐ³Ð°Ð¿ÑÑ,DurgÄpur", :latitude => "23.48333", :longitude => "87.31667").save
City.new(:country_id => "107", :name => "Durgapur", :aliases => ",DurgÄpur", :latitude => "20", :longitude => "79.3").save
City.new(:country_id => "107", :name => "Durg", :aliases => "Drug,Durg,Durg", :latitude => "21.18333", :longitude => "81.28333").save
City.new(:country_id => "107", :name => "Dungarpur", :aliases => "Dungarpur,DÅ«ngarpur,DÅ«ngarpur", :latitude => "23.83333", :longitude => "73.71667").save
City.new(:country_id => "107", :name => "Dundwaraganj", :aliases => ",DundwÄrÄganj", :latitude => "27.73333", :longitude => "78.95").save
City.new(:country_id => "107", :name => "Dumraon", :aliases => "Dumraon,Dumraon", :latitude => "25.55", :longitude => "84.15").save
City.new(:country_id => "107", :name => "Dumra", :aliases => ",Dumra", :latitude => "26.56667", :longitude => "85.51667").save
City.new(:country_id => "107", :name => "Dumka", :aliases => "Dumka,ÐÑÐ¼ÐºÐ°,Dumka", :latitude => "24.26667", :longitude => "87.25").save
City.new(:country_id => "107", :name => "Dum Duma", :aliases => "Doom-Dooma,Dum Duma,Sookerating,Dum Duma", :latitude => "27.56667", :longitude => "95.56667").save
City.new(:country_id => "107", :name => "Dam Dam", :aliases => "Dam Dam,Dum Dum,Dam Dam", :latitude => "22.62222", :longitude => "88.41694").save
City.new(:country_id => "107", :name => "Duliagaon", :aliases => ",DuliÄgaon", :latitude => "27.36667", :longitude => "95.31667").save
City.new(:country_id => "107", :name => "Dugda", :aliases => "Dugda,Dugda", :latitude => "23.75", :longitude => "86.16667").save
City.new(:country_id => "107", :name => "Dubrajpur", :aliases => "Dubrajpur,DubrÄjpur,DubrÄjpur", :latitude => "23.8", :longitude => "87.38333").save
City.new(:country_id => "107", :name => "Dornakal", :aliases => ",Dornakal", :latitude => "17.45", :longitude => "80.16667").save
City.new(:country_id => "107", :name => "Doraha", :aliases => ",DorÄha", :latitude => "30.81667", :longitude => "76.01667").save
City.new(:country_id => "107", :name => "Dongargarh", :aliases => ",Dongargarh", :latitude => "21.2", :longitude => "80.73333").save
City.new(:country_id => "107", :name => "Dondaicha", :aliases => ",Dondaicha", :latitude => "21.33333", :longitude => "74.56667").save
City.new(:country_id => "107", :name => "Dombivli", :aliases => "Dombivali,Dombivli", :latitude => "19.21667", :longitude => "73.08333").save
City.new(:country_id => "107", :name => "Dod Ballapur", :aliases => ",Dod BallÄpur", :latitude => "13.29194", :longitude => "77.54306").save
City.new(:country_id => "107", :name => "Doda", :aliases => "Doda,Doda", :latitude => "33.13333", :longitude => "75.56667").save
City.new(:country_id => "107", :name => "Diu", :aliases => "Diu,Div,ÐÐ¸Ñ,Diu", :latitude => "20.71405", :longitude => "70.98224").save
City.new(:country_id => "107", :name => "Disa", :aliases => "Deesa,Dis,Disa,DÄ«sa,ÐÐ¸Ñ,DÄ«sa", :latitude => "24.25", :longitude => "72.16667").save
City.new(:country_id => "107", :name => "Diphu", :aliases => "Diphn,Diphu,Diphu", :latitude => "25.83333", :longitude => "93.43333").save
City.new(:country_id => "107", :name => "Dinhata", :aliases => "Dinhata,DÄ«nhÄta,DÄ«nhÄta", :latitude => "26.13333", :longitude => "89.46667").save
City.new(:country_id => "107", :name => "Dindori", :aliases => "Dindori,Dindori", :latitude => "22.95", :longitude => "81.08333").save
City.new(:country_id => "107", :name => "Dindigul", :aliases => "Dhundgal,Dindigul,Dindukkal,Dundigal,tindo~ukkaru,tindo~ukkaru xian,tintukkal,à®¤à®¿à®£à¯à®à¯à®à¯à®à®²à¯,ãã£ã³ãã¥ãã«ã«,ãã£ã³ãã¥ãã«ã«ç,Dindigul", :latitude => "10.35", :longitude => "77.95").save
City.new(:country_id => "107", :name => "Dinanagar", :aliases => ",DÄ«nÄnagar", :latitude => "32.15", :longitude => "75.46667").save
City.new(:country_id => "107", :name => "Dimapur", :aliases => "Dimapur,DimÄpur,ÐÐ¸Ð¼Ð°Ð¿ÑÑ,DimÄpur", :latitude => "25.9", :longitude => "93.73333").save
City.new(:country_id => "107", :name => "Digras", :aliases => ",Digras", :latitude => "20.11667", :longitude => "77.71667").save
City.new(:country_id => "107", :name => "Diglur", :aliases => "Deglur,Diglur,DÄ«glÅ«r,DÄ«glÅ«r", :latitude => "18.55", :longitude => "77.6").save
City.new(:country_id => "107", :name => "Dighwara", :aliases => "Digha,Dighwara,DighwÄra,DighwÄra", :latitude => "25.73333", :longitude => "85").save
City.new(:country_id => "107", :name => "Digboi", :aliases => "Digbol,Digbor,Digboi", :latitude => "27.38333", :longitude => "95.63333").save
City.new(:country_id => "107", :name => "Dig", :aliases => "Deeg,Dig,DÄ«g,DÄ«g", :latitude => "27.46667", :longitude => "77.33333").save
City.new(:country_id => "107", :name => "Didwana", :aliases => "Didwana,DÄ«dwÄna,DÄ«dwÄna", :latitude => "27.4", :longitude => "74.56667").save
City.new(:country_id => "107", :name => "Dicholi", :aliases => "Bicholim,Bicholim Town,Cassabe de Bicholim,CassabÃ© de Bicholim,Dicholi,Dicholi", :latitude => "15.6", :longitude => "73.95").save
City.new(:country_id => "107", :name => "Dibrugarh", :aliases => "Dibrugarh,Lakhinpur,dibrugadha jila,à¤¡à¤¿à¤¬à¥à¤°à¥à¤à¤¢ à¤à¤¿à¤²à¤¾,Dibrugarh", :latitude => "27.48333", :longitude => "94.9").save
City.new(:country_id => "107", :name => "Dibai", :aliases => "Dibai,Dibai", :latitude => "28.21667", :longitude => "78.25").save
City.new(:country_id => "107", :name => "Diamond Harbour", :aliases => "Diamond Harbor,Diamond Harbour,Diamond Harbour", :latitude => "22.19167", :longitude => "88.18472").save
City.new(:country_id => "107", :name => "Dhuri", :aliases => "Dhuri,DhÅ«ri,DhÅ«ri", :latitude => "30.36667", :longitude => "75.86667").save
City.new(:country_id => "107", :name => "Dhupgari", :aliases => "Dhupgari,Dhupguri,DhupgÄri,DhupgÄri", :latitude => "26.6", :longitude => "89.01667").save
City.new(:country_id => "107", :name => "Dhulian", :aliases => "Dhulian,DhuliÄn,DhuliÄn", :latitude => "24.68333", :longitude => "87.96667").save
City.new(:country_id => "107", :name => "Dhule", :aliases => "Dhule,Dhulia,DhÅ«lia,Dkhule,ÐÑÑÐ»Ðµ,Dhule", :latitude => "20.9", :longitude => "74.78333").save
City.new(:country_id => "107", :name => "Dhuburi", :aliases => "Dhubri,Dhuburi,Dubri,dhubari jila,à¤§à¥à¤¬à¤°à¥ à¤à¤¿à¤²à¤¾,Dhuburi", :latitude => "26.03333", :longitude => "89.96667").save
City.new(:country_id => "107", :name => "Dhrol", :aliases => "Dhrol,Dhrol", :latitude => "22.56667", :longitude => "70.41667").save
City.new(:country_id => "107", :name => "Dhrangadhra", :aliases => "Dhrangadhra,Dhrangadra,DhrÄngadhra,DhrÄngadra,DhrÄngadhra", :latitude => "22.98333", :longitude => "71.46667").save
City.new(:country_id => "107", :name => "Dhoraji", :aliases => "Dhorail,Dhoraji,DhorÄji,DhorÄji", :latitude => "21.73333", :longitude => "70.45").save
City.new(:country_id => "107", :name => "Dhone", :aliases => "Dhone,Dhone", :latitude => "15.41667", :longitude => "77.88333").save
City.new(:country_id => "107", :name => "Dholka", :aliases => "Dholka,Dholka", :latitude => "22.71667", :longitude => "72.46667").save
City.new(:country_id => "107", :name => "Dhing", :aliases => "Dhing,Dhing", :latitude => "26.46667", :longitude => "92.46667").save
City.new(:country_id => "107", :name => "Dhenkanal", :aliases => ",DhenkÄnÄl", :latitude => "20.66667", :longitude => "85.6").save
City.new(:country_id => "107", :name => "Dhekiajuli", :aliases => "Dhekiajuli,Dhekiajuli", :latitude => "26.7", :longitude => "92.5").save
City.new(:country_id => "107", :name => "Dhaurahra", :aliases => ",Dhaurahra", :latitude => "28", :longitude => "81.08333").save
City.new(:country_id => "107", :name => "Dhaulpur", :aliases => "Dhaulpur,Dholpur,Dhaulpur", :latitude => "26.7", :longitude => "77.9").save
City.new(:country_id => "107", :name => "Dharur", :aliases => "Dharur,DhÄrÅ«r,Fatehabad,FatehabÄd,Fatheabad,DhÄrÅ«r", :latitude => "18.81667", :longitude => "76.11667").save
City.new(:country_id => "107", :name => "Dharuhera", :aliases => "Dharuhera,DhÄruhera,DhÄruhera", :latitude => "28.21667", :longitude => "76.78333").save
City.new(:country_id => "107", :name => "Dharmsala", :aliases => "Dharamsala,Dharmsala,Dharmshala,DharmsÄla,Dkharamsala,McLeod Ganj,da lan sa la,dalamsalla,daramusara,daramushara,dharmasala,ÐÑÐ°ÑÐ°Ð¼ÑÐ°Ð»Ð°,à¤§à¤°à¥à¤®à¤¶à¤¾à¤²à¤¾,à¦§à¦°à§à¦®à¦¶à¦¾à¦²à¦¾,ãã©ã ãµã©,ãã©ã ã·ã£ã¼ã©ã¼,è¾¾å°è¨æ,ë¤ëì´ë¼,DharmsÄla", :latitude => "32.21667", :longitude => "76.31667").save
City.new(:country_id => "107", :name => "Dharmavaram", :aliases => "Dharmavaram,Dharmavaram", :latitude => "14.43333", :longitude => "77.71667").save
City.new(:country_id => "107", :name => "Dharmapuri", :aliases => "Dharmapuri,darumapuri,tarmapuri,à®¤à®°à¯à®®à®ªà¯à®°à®¿,ãã«ãããª,Dharmapuri", :latitude => "12.13333", :longitude => "78.16667").save
City.new(:country_id => "107", :name => "Dharmanagar", :aliases => "Dharmanagar,Dharmanagar", :latitude => "24.36667", :longitude => "92.16667").save
City.new(:country_id => "107", :name => "Dharmadam", :aliases => "Dharmadam,Dharmadam", :latitude => "11.78333", :longitude => "75.43333").save
City.new(:country_id => "107", :name => "Dharmabad", :aliases => "Dharmabad,DharmÄbÄd,DharmÄbÄd", :latitude => "18.9", :longitude => "77.85").save
City.new(:country_id => "107", :name => "Dhariwal", :aliases => "Dhariwal,DhÄriwÄl,DhÄriwÄl", :latitude => "31.95417", :longitude => "75.31917").save
City.new(:country_id => "107", :name => "Dhari", :aliases => ",DhÄri", :latitude => "21.33333", :longitude => "71.01667").save
City.new(:country_id => "107", :name => "Dharapuram", :aliases => "Dharapuram,DhÄrÄpuram,DhÄrÄpuram", :latitude => "10.73333", :longitude => "77.51667").save
City.new(:country_id => "107", :name => "Dharangaon", :aliases => "Darangaon,Dharangaon,Dharangaon", :latitude => "21.01667", :longitude => "75.26667").save
City.new(:country_id => "107", :name => "Dharampur", :aliases => "Dharampore,Dharampur,Dhurrumpur,Dilarampur,Dharampur", :latitude => "20.53333", :longitude => "73.18333").save
City.new(:country_id => "107", :name => "Dhar", :aliases => "Dhar,DhÄr,Dkhar,ÐÑÐ°Ñ,DhÄr", :latitude => "22.6", :longitude => "75.3").save
City.new(:country_id => "107", :name => "Dhanera", :aliases => "Dhanera,Dhanera", :latitude => "24.51667", :longitude => "72.01667").save
City.new(:country_id => "107", :name => "Dhandhuka", :aliases => "Dhandhuka,Dhandhuka", :latitude => "22.36667", :longitude => "71.98333").save
City.new(:country_id => "107", :name => "Dhanbad", :aliases => "Dhanabad,Dhanbad,Dhanbaid,DhanbÄd,Dkhanbad,danbado,dhanabada,ÐÑÐ°Ð½Ð±Ð°Ð´,à¤§à¤¨à¤¬à¤¾à¤¦,à¦§à¦¾à¦¨à¦¾à¦¬à¦¾à¦¦,ãã³ãã¼ã,DhanbÄd", :latitude => "23.8", :longitude => "86.45").save
City.new(:country_id => "107", :name => "Dhanaura", :aliases => "Dhanaura,Dhanaura", :latitude => "28.96667", :longitude => "78.25").save
City.new(:country_id => "107", :name => "Dhanaula", :aliases => "Dhanaula,Dhanaula", :latitude => "30.28333", :longitude => "75.58333").save
City.new(:country_id => "107", :name => "Dhamtari", :aliases => "Dhamtari,Dhamtari", :latitude => "20.70722", :longitude => "81.54972").save
City.new(:country_id => "107", :name => "Dhampur", :aliases => "Dhampur,DhÄmpur,DhÄmpur", :latitude => "29.31667", :longitude => "78.51667").save
City.new(:country_id => "107", :name => "Dhamnod", :aliases => "Dhamnod,DhÄmnod,DhÄmnod", :latitude => "22.21667", :longitude => "75.46667").save
City.new(:country_id => "107", :name => "Dhaka", :aliases => ",DhÄka", :latitude => "26.68333", :longitude => "85.16667").save
City.new(:country_id => "107", :name => "Dewas", :aliases => "Dewas,DewÄs,DewÄs", :latitude => "22.96667", :longitude => "76.06667").save
City.new(:country_id => "107", :name => "Devli", :aliases => "Deoli,Devli,Dioli,Devli", :latitude => "25.75", :longitude => "75.38333").save
City.new(:country_id => "107", :name => "Devgarh", :aliases => "Deogarh,Devgarh,Devgarh", :latitude => "25.53333", :longitude => "73.9").save
City.new(:country_id => "107", :name => "Devgadh Bariya", :aliases => "Baria,Bariya,BÄria,Devgad Baria,Devgad BÄria,Devgadh Bariya,Devgadh BÄriya,Devgadh BÄriya", :latitude => "22.7", :longitude => "73.9").save
City.new(:country_id => "107", :name => "Devarkonda", :aliases => ",Devarkonda", :latitude => "16.7", :longitude => "78.93333").save
City.new(:country_id => "107", :name => "Devanhalli", :aliases => ",Devanhalli", :latitude => "13.2325", :longitude => "77.69917").save
City.new(:country_id => "107", :name => "Devakottai", :aliases => "Devakottai,Devakottai", :latitude => "9.95", :longitude => "78.81667").save
City.new(:country_id => "107", :name => "Deulgaon Raja", :aliases => "Deulgaon Raja,DeÅ«lgaon RÄja,DeÅ«lgaon RÄja", :latitude => "20.01667", :longitude => "76.03333").save
City.new(:country_id => "107", :name => "Deshnoke", :aliases => "Deshnok,Deshnoke,Deshnoke", :latitude => "27.8", :longitude => "73.35").save
City.new(:country_id => "107", :name => "Depalpur", :aliases => "Depalpur,DepÄlpur,DepÄlpur", :latitude => "22.85", :longitude => "75.55").save
City.new(:country_id => "107", :name => "Deori Khas", :aliases => "Deore,Deori,Deori Khas,DeorÄ« KhÄs,DeorÄ« KhÄs", :latitude => "23.4", :longitude => "79.01667").save
City.new(:country_id => "107", :name => "Deoria", :aliases => "Deoria,Deoria", :latitude => "26.50472", :longitude => "83.78722").save
City.new(:country_id => "107", :name => "Deoranian", :aliases => "Deorania,Deoranian,DeoraniÄn,DeoraniÄn", :latitude => "28.63333", :longitude => "79.48333").save
City.new(:country_id => "107", :name => "Deoli", :aliases => "Deoli,Deoli", :latitude => "20.66667", :longitude => "78.48333").save
City.new(:country_id => "107", :name => "Deolali", :aliases => ",DeolÄli", :latitude => "19.95", :longitude => "73.83333").save
City.new(:country_id => "107", :name => "Deogarh", :aliases => ",Deogarh", :latitude => "21.53333", :longitude => "84.73333").save
City.new(:country_id => "107", :name => "Deoband", :aliases => "Deoband,Deobande,ÐÐµÐ¾Ð±Ð°Ð½Ð´Ðµ,Deoband", :latitude => "29.7", :longitude => "77.68333").save
City.new(:country_id => "107", :name => "Denkanikota", :aliases => ",Denkanikota", :latitude => "12.53333", :longitude => "77.8").save
City.new(:country_id => "107", :name => "Delhi", :aliases => "Dehli,DehlÄ«,Delhi,DelhÃ­,Deli,Delis,Delkhi,Dilli,DillÃ­,DillÄ«,Old Delhi,de li,deli,delli,deri,dhilli,dil'hi,dilli,dlhy,dly,tilli,ÐÐµÐ»Ð¸,ÐÐµÐ»ÑÐ¸,××××,Ø¯ÙÛ,Ø¯ÛÙÛ,à¤¦à¤¿à¤²à¥à¤²à¥,à¨¦à¨¿à©±à¨²à©,àª¦àª¿àª²à«àª¹à«,à®¤à®¿à®²à¯à®²à®¿,à°¢à°¿à°²à±à°²à±,áááá,ããªã¼,å¾·é,ë¸ë¦¬,Delhi", :latitude => "28.66667", :longitude => "77.21667").save
City.new(:country_id => "107", :name => "Dehri", :aliases => "Dehm,Dehri,Dehri", :latitude => "24.86667", :longitude => "84.18333").save
City.new(:country_id => "107", :name => "Dehra Dun", :aliases => "Dehra,Dehra Dun,Dehra DÅ«n,Dekhradune,ÐÐµÑÑÐ°Ð´ÑÐ½Ðµ,Dehra DÅ«n", :latitude => "30.31667", :longitude => "78.03333").save
City.new(:country_id => "107", :name => "Dausa", :aliases => "Daosa,Dausa,ÐÐ°ÑÑÐ°,Dausa", :latitude => "26.88333", :longitude => "76.33333").save
City.new(:country_id => "107", :name => "Daund", :aliases => "Daund,Dhond,Daund", :latitude => "18.46667", :longitude => "74.6").save
City.new(:country_id => "107", :name => "Daudnagar", :aliases => "Daudnagar,Daudnagar", :latitude => "25.03333", :longitude => "84.4").save
City.new(:country_id => "107", :name => "Dattapur", :aliases => ",DattÄpur", :latitude => "20.76667", :longitude => "78.16667").save
City.new(:country_id => "107", :name => "Datia", :aliases => "Datia,Datia", :latitude => "25.66667", :longitude => "78.46667").save
City.new(:country_id => "107", :name => "Dataganj", :aliases => "Dataganj,DÄtÄganj,DÄtÄganj", :latitude => "28.03333", :longitude => "79.4").save
City.new(:country_id => "107", :name => "Dasua", :aliases => "Dasua,Dasuya,DasÅ«a,DasÅ«ya,DasÅ«a", :latitude => "31.81833", :longitude => "75.65972").save
City.new(:country_id => "107", :name => "Dasna", :aliases => "Dasna,DÄsna,DÄsna", :latitude => "28.68333", :longitude => "77.53333").save
City.new(:country_id => "107", :name => "Daryapur", :aliases => "Daryapur,DaryÄpur,DaryÄpur", :latitude => "20.93333", :longitude => "77.33333").save
City.new(:country_id => "107", :name => "Darwha", :aliases => "Darwha,DÄrwhÄ,DÄrwhÄ", :latitude => "20.31667", :longitude => "77.76667").save
City.new(:country_id => "107", :name => "Darjiling", :aliases => "Dardzhiling,Dardzilingas,DardÅ¾ilingas,Dargiling,Darjeeling,Darjiling,DarÄiling,DÄrjiling,Rdorje gling,da ji ling,daleujilling,dar jylng,darjilim,drg'ylyng,ÐÐ°ÑÐ´Ð¶Ð¸Ð»Ð¸Ð½Ð³,××¨×'×××× ×,Ø¯Ø§Ø± Ø¬ÛÙÙÚ¯,à¦¦à¦¾à¦°à§à¦à¦¿à¦²à¦¿à¦,å¤§åå¶º,ë¤ë¥´ì§ë§,DÄrjiling", :latitude => "27.03333", :longitude => "88.26667").save
City.new(:country_id => "107", :name => "Darbhanga", :aliases => "Darbhanga,Darbhanga", :latitude => "26.16667", :longitude => "85.9").save
City.new(:country_id => "107", :name => "Dandeli", :aliases => ",Dandeli", :latitude => "15.26667", :longitude => "74.61667").save
City.new(:country_id => "107", :name => "Danapur", :aliases => "Danapur,Dinapore,DÄnÄpur,DÄnÄpur", :latitude => "25.63333", :longitude => "85.05").save
City.new(:country_id => "107", :name => "Damoh", :aliases => ",Damoh", :latitude => "23.83333", :longitude => "79.45").save
City.new(:country_id => "107", :name => "Damnagar", :aliases => "Damnagar,DÄmnagar,DÄmnagar", :latitude => "21.7", :longitude => "71.51667").save
City.new(:country_id => "107", :name => "Daman", :aliases => "Daman,Damao,Damaun,DamÃ£o,DamÄn,ÐÐ°Ð¼Ð°Ð½,DamÄn", :latitude => "20.41667", :longitude => "72.85").save
City.new(:country_id => "107", :name => "Daltenganj", :aliases => "Daltenganj,Daltonganj,DÄltenganj,daltanaganja,à¤¡à¤¾à¤²à¥à¤à¤¨à¤à¤à¤,DÄltenganj", :latitude => "24.03333", :longitude => "84.06667").save
City.new(:country_id => "107", :name => "Dalsingh Sarai", :aliases => "Dalsingh Sarai,Dalsingh-Sari,Dalsingh Sarai", :latitude => "25.66667", :longitude => "85.83333").save
City.new(:country_id => "107", :name => "Dalkola", :aliases => ",DÄlkola", :latitude => "25.85", :longitude => "87.85").save
City.new(:country_id => "107", :name => "Dakor", :aliases => "Dakor,DÄkor,ÐÐ°ÐºÐ¾Ñ,DÄkor", :latitude => "22.75", :longitude => "73.15").save
City.new(:country_id => "107", :name => "Dahod", :aliases => "Dahod,Dohad,DÄhod,DÄhod", :latitude => "22.83333", :longitude => "74.26667").save
City.new(:country_id => "107", :name => "Dahegam", :aliases => "Dahegam,DahegÄm,Dehgam,DehgÄm,DahegÄm", :latitude => "23.16667", :longitude => "72.81667").save
City.new(:country_id => "107", :name => "Dahanu", :aliases => "Dahanu,DÄhÄnu,DÄhÄnu", :latitude => "19.96667", :longitude => "72.73333").save
City.new(:country_id => "107", :name => "Dadri", :aliases => "Dadri,DÄdri,DÄdri", :latitude => "28.56667", :longitude => "77.55").save
City.new(:country_id => "107", :name => "Dabwali", :aliases => ",DabwÄli", :latitude => "29.95", :longitude => "74.73333").save
City.new(:country_id => "107", :name => "Dabra", :aliases => ",Dabra", :latitude => "25.9", :longitude => "78.33333").save
City.new(:country_id => "107", :name => "Daboh", :aliases => "Daboh,Daboh", :latitude => "26.0025", :longitude => "78.87611").save
City.new(:country_id => "107", :name => "Dabhoi", :aliases => "Dabhoi,Dabhoi", :latitude => "22.18333", :longitude => "73.43333").save
City.new(:country_id => "107", :name => "Cuttack", :aliases => "Kattake,ÐÐ°ÑÑÐ°ÐºÐµ,Cuttack", :latitude => "20.46497", :longitude => "85.87927").save
City.new(:country_id => "107", :name => "Curchorem", :aliases => "Curchorem,Curchurem,Curchorem", :latitude => "15.25", :longitude => "74.1").save
City.new(:country_id => "107", :name => "Cuncolim", :aliases => ",Cuncolim", :latitude => "15.16667", :longitude => "73.98333").save
City.new(:country_id => "107", :name => "Cumbum", :aliases => "Cumbum,Kambhamu,Cumbum", :latitude => "15.56667", :longitude => "79.11667").save
City.new(:country_id => "107", :name => "Cuddapah", :aliases => "Cuddapah,Kadapa,Kurpah,kadapa,katappa,à®à®à®ªà¯à®ªà®¾,à°à°¡à°ª,Cuddapah", :latitude => "14.46667", :longitude => "78.81667").save
City.new(:country_id => "107", :name => "Cuddalore", :aliases => "Cuddalore,Gudalur,Kudalur,Kuddalore,KÅ«dalÅ«r,ÐÑÐ´Ð´Ð°Ð»Ð¾ÑÐµ,Cuddalore", :latitude => "11.75", :longitude => "79.75").save
City.new(:country_id => "107", :name => "Coondapoor", :aliases => "Coondapoor,Coondapur,Kundapur,Coondapoor", :latitude => "13.63333", :longitude => "74.7").save
City.new(:country_id => "107", :name => "Colonelganj", :aliases => "Colonelganj,Colonelganj", :latitude => "27.13333", :longitude => "81.7").save
City.new(:country_id => "107", :name => "Colgong", :aliases => "Colgong,Colgong", :latitude => "25.26667", :longitude => "87.21667").save
City.new(:country_id => "107", :name => "Calangute", :aliases => "Calangute,Kalangut,ÐÐ°Ð»Ð°Ð½Ð³ÑÑ,Calangute", :latitude => "15.5439", :longitude => "73.7553").save
City.new(:country_id => "107", :name => "Coimbatore", :aliases => "Coimbatore,Koimbatore,Kojamputtur,Koyambattur,KoyambattÅ«r,Koyamuttur,KoyamuttÅ«r,koyambatura,koyamputtur,koyanbutto~uru,ÐÐ¾ÑÐ¼Ð¿ÑÑÑÑÑ,à¤à¥à¤¯à¤à¤¬à¤¤à¥à¤°,à®à¯à®¯à®®à¯à®ªà¯à®¤à¯à®¤à¯à®°à¯,à´àµà´¯à´®àµà´ªà´¤àµà´¤àµà´°àµâ,ã³ã¼ã¤ã³ãããã¥ã¼ã«,Coimbatore", :latitude => "11", :longitude => "76.96667").save
City.new(:country_id => "107", :name => "Cochin", :aliases => "British Cochin,Cochim,Cochin,CochÃ­n,Fort Cochin,Kochi,Kochin,Koczin,Kuchi Bandar,Malabar,ke zhi,keacci,kocci,kochi,kocina,qwz'y,ÐÐ¾ÑÐ¸Ð½,×§××¦'×,à¤à¥à¤à¥à¤¨,à¦à§à¦à¦¿à¦¨,à®à¯à®à¯à®à®¿,à´àµà´àµà´à´¿,ã³ã¼ã,æ¯æ,Cochin", :latitude => "9.96667", :longitude => "76.23333").save
City.new(:country_id => "107", :name => "Clement Town", :aliases => "Clement Town,Clement Town", :latitude => "30.26667", :longitude => "78.06667").save
City.new(:country_id => "107", :name => "Churu", :aliases => ",ChÅ«ru", :latitude => "28.3", :longitude => "74.95").save
City.new(:country_id => "107", :name => "Churachandpur", :aliases => ",ChurÄchÄndpur", :latitude => "24.33333", :longitude => "93.66667").save
City.new(:country_id => "107", :name => "Chunar", :aliases => "Chunar,ChunÄr,ChunÄr", :latitude => "25.13333", :longitude => "82.9").save
City.new(:country_id => "107", :name => "Chotila", :aliases => ",Chotila", :latitude => "22.41667", :longitude => "71.18333").save
City.new(:country_id => "107", :name => "Chopda", :aliases => "Chopda,Chopda", :latitude => "21.25", :longitude => "75.3").save
City.new(:country_id => "107", :name => "Chodavaram", :aliases => "Chodavaram,Chodavaram", :latitude => "17.83333", :longitude => "82.95").save
City.new(:country_id => "107", :name => "Chodavaram", :aliases => ",Chodavaram", :latitude => "17.45", :longitude => "81.76667").save
City.new(:country_id => "107", :name => "Chittur", :aliases => "Chittur,Chittur-Cochin,ChittÅ«r,ChittÅ«r", :latitude => "10.7", :longitude => "76.75").save
City.new(:country_id => "107", :name => "Chittaurgarh", :aliases => "Chitor,Chitorgarh,Chittaurgarh,Chittaurgarh", :latitude => "24.88333", :longitude => "74.63333").save
City.new(:country_id => "107", :name => "Chittaranjan", :aliases => "Chittarandzhan,Chittaranjan,Mihijam,Mihijan,MihijÄm,Ð§Ð¸ÑÑÐ°ÑÐ°Ð½Ð´Ð¶Ð°Ð½,Chittaranjan", :latitude => "23.86667", :longitude => "86.86667").save
City.new(:country_id => "107", :name => "Chitradurga", :aliases => "Chitaldroog,Chitaldrug,Chitaldurg,Chitradurg,Chitradurga,Chitrakaldurga,Chitteldrug,Chitradurga", :latitude => "14.23333", :longitude => "76.4").save
City.new(:country_id => "107", :name => "Chitapur", :aliases => "Chitapur,ChÄ«tÄpur,ChÄ«tÄpur", :latitude => "17.11667", :longitude => "77.08333").save
City.new(:country_id => "107", :name => "Chirawa", :aliases => "Chirawa,ChirÄwa,ChirÄwa", :latitude => "28.2401", :longitude => "75.6456").save
City.new(:country_id => "107", :name => "Chirala", :aliases => "Chirala,ChÄ«rÄla,ChÄ«rÄla", :latitude => "15.81667", :longitude => "80.35").save
City.new(:country_id => "107", :name => "Chipurupalle", :aliases => ",ChÄ«purupalle", :latitude => "18.3", :longitude => "83.56667").save
City.new(:country_id => "107", :name => "Chiplun", :aliases => "Chiplun,ChiplÅ«n,ChiplÅ«n", :latitude => "17.53333", :longitude => "73.51667").save
City.new(:country_id => "107", :name => "Chintamani", :aliases => "Chintamani,ChintÄmani,Ð§Ð¸Ð½ÑÐ°Ð¼Ð°Ð½Ð¸,ChintÄmani", :latitude => "13.4", :longitude => "78.06667").save
City.new(:country_id => "107", :name => "Chinna Salem", :aliases => ",Chinna Salem", :latitude => "11.65", :longitude => "78.9").save
City.new(:country_id => "107", :name => "Chinnamanur", :aliases => "Chinnamanur,ChinnamanÅ«r,Chinnammanur,ChinnamanÅ«r", :latitude => "9.83333", :longitude => "77.38333").save
City.new(:country_id => "107", :name => "Chincholi", :aliases => "Chincholi,Chincholi", :latitude => "17.46667", :longitude => "77.43333").save
City.new(:country_id => "107", :name => "Chillupar", :aliases => "Barhalganj,Chillupar,ChillÅ«pÄr,ChillÅ«pÄr", :latitude => "26.28222", :longitude => "83.50833").save
City.new(:country_id => "107", :name => "Chilakalurupet", :aliases => ",ChilakalÅ«rupet", :latitude => "16.08333", :longitude => "80.16667").save
City.new(:country_id => "107", :name => "Chikodi", :aliases => "Chikodi,Chikodi", :latitude => "16.43333", :longitude => "74.6").save
City.new(:country_id => "107", :name => "Chiknayakanhalli", :aliases => ",ChiknÄyakanhalli", :latitude => "13.41722", :longitude => "76.62278").save
City.new(:country_id => "107", :name => "Chikmagalur", :aliases => "Chickmagalur,Chikkamagaluru,ChikkamagalÅ«ru,Chikmagalur,ChikmagalÅ«r,Chikmanglur,Chikmugalur,ChikmugalÅ«r,à²à²¿à²à³à²à²®à²à²³à³à²°à³,ChikmagalÅ«r", :latitude => "13.31667", :longitude => "75.78333").save
City.new(:country_id => "107", :name => "Chikhli", :aliases => ",Chikhli", :latitude => "20.35", :longitude => "76.25").save
City.new(:country_id => "107", :name => "Chik Ballapur", :aliases => ",Chik BallÄpur", :latitude => "13.43417", :longitude => "77.72417").save
City.new(:country_id => "107", :name => "Chidambaram", :aliases => "Chidambajram,Chidambaram,Chitdambaram,Ð§Ð¸Ð´Ð°Ð¼Ð±Ð°Ð¹ÑÐ°Ð¼,Ð§Ð¸Ð´Ð°Ð¼Ð±Ð°ÑÐ°Ð¼,Chidambaram", :latitude => "11.4", :longitude => "79.7").save
City.new(:country_id => "107", :name => "Chicholi", :aliases => "Chicholi,ChÄ«choli,ChÄ«choli", :latitude => "21.46667", :longitude => "79.68333").save
City.new(:country_id => "107", :name => "Chhoti Sadri", :aliases => "Chhoti Sadri,Chhoti SÄdri,Chhoti SÄdri", :latitude => "24.38333", :longitude => "74.7").save
City.new(:country_id => "107", :name => "Chhota Udepur", :aliases => "Chhota Udepur,Chota Udaipur,Chhota Udepur", :latitude => "22.31667", :longitude => "74.01667").save
City.new(:country_id => "107", :name => "Chhindwara", :aliases => "Chhindwara,ChhindwÄra,Chindwara,Sindwara,ChhindwÄra", :latitude => "22.06667", :longitude => "78.93333").save
City.new(:country_id => "107", :name => "Chhibramau", :aliases => "Chhibramau,ChhibrÄmau,ChhibrÄmau", :latitude => "27.1483", :longitude => "79.4979").save
City.new(:country_id => "107", :name => "Chhatarpur", :aliases => "Chantarpur,Chhatarpur,Chkatarpur,Chhatarpur", :latitude => "24.9", :longitude => "79.6").save
City.new(:country_id => "107", :name => "Chhatapur", :aliases => ",ChhÄtÄpur", :latitude => "26.21667", :longitude => "87.01667").save
City.new(:country_id => "107", :name => "Chhata", :aliases => "Chhata,ChhÄta,ChhÄta", :latitude => "27.71667", :longitude => "77.5").save
City.new(:country_id => "107", :name => "Chharra", :aliases => ",Chharra", :latitude => "27.93333", :longitude => "78.41667").save
City.new(:country_id => "107", :name => "Chhaprauli", :aliases => "Chhaprauli,Chhaprauli", :latitude => "29.21667", :longitude => "77.18333").save
City.new(:country_id => "107", :name => "Chhapar", :aliases => "Chhapar,ChhÄpar,ChhÄpar", :latitude => "27.81667", :longitude => "74.4").save
City.new(:country_id => "107", :name => "Chhala", :aliases => ",Chhala", :latitude => "23.3", :longitude => "72.76667").save
City.new(:country_id => "107", :name => "Chhabra", :aliases => "Chhabra,Chhabra", :latitude => "24.66667", :longitude => "76.83333").save
City.new(:country_id => "107", :name => "Chettipalaiyam", :aliases => "Chettipalaiyam,Chettipalayam,ChettipÄlaiyam,ChettipÄlaiyam", :latitude => "10.9", :longitude => "77.06667").save
City.new(:country_id => "107", :name => "Chetput", :aliases => "Chetpat,Chetpet,Chetput,Madras Chetput,Chetput", :latitude => "13.07", :longitude => "80.24083").save
City.new(:country_id => "107", :name => "Chennimalai", :aliases => "Chennimalai,Chennimalai", :latitude => "11.16667", :longitude => "77.61667").save
City.new(:country_id => "107", :name => "Chengannur", :aliases => "Chengannur,ChengannÅ«r,ChengannÅ«r", :latitude => "9.33333", :longitude => "76.63333").save
City.new(:country_id => "107", :name => "Chengam", :aliases => "Chengam,Chengam", :latitude => "12.3", :longitude => "78.8").save
City.new(:country_id => "107", :name => "Chengalpattu", :aliases => "Chengalpat,Chengalpattu,Chingleput,Chengalpattu", :latitude => "12.7", :longitude => "79.98333").save
City.new(:country_id => "107", :name => "Chavakkad", :aliases => "Chaughat,Chavakkad,Chetwagi,Chetwayi,Chitwye,Chowghat,ChÄvakkÄd,ChÄvakkÄd", :latitude => "10.53333", :longitude => "76.05").save
City.new(:country_id => "107", :name => "Chatsu", :aliases => "Chaksu,Chatsu,ChÄksu,ChÄtsu,ChÄtsu", :latitude => "26.6", :longitude => "75.95").save
City.new(:country_id => "107", :name => "Chatrapur", :aliases => "Chatrapur,Chhatrapur,Chatrapur", :latitude => "19.35", :longitude => "84.98333").save
City.new(:country_id => "107", :name => "Chatra", :aliases => "Chatra,Chatra", :latitude => "24.21667", :longitude => "84.86667").save
City.new(:country_id => "107", :name => "Chas", :aliases => "Chas,ChÄs,Ð§Ð°Ñ,ChÄs", :latitude => "23.63333", :longitude => "86.16667").save
City.new(:country_id => "107", :name => "Charthawal", :aliases => ",CharthÄwÄl", :latitude => "29.55", :longitude => "77.58333").save
City.new(:country_id => "107", :name => "Charkhi Dadri", :aliases => "Charkhi Dadri,Charkhi DÄdri,Charki Dadrai,Charki Dadri,Dadri,DÄdri,Charkhi DÄdri", :latitude => "28.6", :longitude => "76.26667").save
City.new(:country_id => "107", :name => "Charkhari", :aliases => "Charkhari,CharkhÄri,Maharajnagar,MÄhÄrÄjnagar,CharkhÄri", :latitude => "25.4", :longitude => "79.75").save
City.new(:country_id => "107", :name => "Chapar", :aliases => "Chapar,ChÄpar,ChÄpar", :latitude => "26.26667", :longitude => "90.46667").save
City.new(:country_id => "107", :name => "Channarayapatna", :aliases => "Channarayapatna,ChannarÄyapatna,Chanzarayapatna,ChannarÄyapatna", :latitude => "12.90444", :longitude => "76.39167").save
City.new(:country_id => "107", :name => "Channapatna", :aliases => "Channapatan,Channapatna,Channapatna", :latitude => "12.65", :longitude => "77.21667").save
City.new(:country_id => "107", :name => "Channagiri", :aliases => "Channagiri,Channagiri", :latitude => "14.03333", :longitude => "75.93333").save
City.new(:country_id => "107", :name => "Changanacheri", :aliases => "Changanacheri,Changanacherry,ChanganÄcheri,ChanganÄcheri", :latitude => "9.46667", :longitude => "76.55").save
City.new(:country_id => "107", :name => "Chandvad", :aliases => "Chandor,Chandvad,Chandwar,ChÄndor,ChÄndvad,ChÄndwar,ChÄndvad", :latitude => "20.33333", :longitude => "74.25").save
City.new(:country_id => "107", :name => "Chandur Bazar", :aliases => ",ChÄndÅ«r BÄzÄr", :latitude => "21.24167", :longitude => "77.74556").save
City.new(:country_id => "107", :name => "Chandur", :aliases => ",ChÄndur", :latitude => "20.81667", :longitude => "77.96667").save
City.new(:country_id => "107", :name => "Chandur", :aliases => ",ChÄndur", :latitude => "19.73333", :longitude => "79.18333").save
City.new(:country_id => "107", :name => "Chandrapur", :aliases => "Chanda,Chandrapur,ChÄnda,Chandrapur", :latitude => "19.95", :longitude => "79.3").save
City.new(:country_id => "107", :name => "Chandrakona", :aliases => "Chandrakona,Chandshona,Chandrakona", :latitude => "22.73333", :longitude => "87.51667").save
City.new(:country_id => "107", :name => "Chandpur", :aliases => "Bijnor,Chandpur,ChÄndpur,ChÄndpur", :latitude => "29.15", :longitude => "78.26667").save
City.new(:country_id => "107", :name => "Chandigarh", :aliases => "Candigarchas,Candigarh,Chandigar,Chandigarh,Chandigarkh,ChandÄ«garh,Czandigarh,cadigarha,candhigad,candigadh,candigadha,candigara,candigarha,cantikar,chandigadh,chandigarhi,chandigaru,chang di jia er,Äandigarchas,ÄandÃ­garh,Ð§Ð°Ð½Ð´Ð¸Ð³Ð°Ñ,Ð§Ð°Ð½Ð´Ð¸Ð³Ð°ÑÑ,×¦'×× ×××××¨,à¤à¤à¤¡à¥à¤à¤¢à¤¼,à¦à¦¨à§à¦¡à¦¿à¦à¦¡à¦¼,à¦à¦¨à§à¦¡à§à¦à¦¡à¦¼,à¨à©°à¨¡à©à¨à©à©à¨¹,àªàªàª¡à«àªàª¢,à®à®£à¯à®à®¿à®à®°à¯,à°à°à°¡à±à°à°¢à±,à°à°à°¡à±à°à°¢à±,à´à´£àµà´¢àµà´à´¡àµ,á©ááááááá á°á,ãã£ã³ãã£ã¼ã¬ã«,æè¿ªå å°,ChandÄ«garh", :latitude => "30.7343", :longitude => "76.7933").save
City.new(:country_id => "107", :name => "Chanderi", :aliases => "Chanderi,Ð§Ð°Ð½Ð´ÐµÑÐ¸,Chanderi", :latitude => "24.71667", :longitude => "78.13333").save
City.new(:country_id => "107", :name => "Chandausi", :aliases => "Chandausi,Chandausi", :latitude => "28.45", :longitude => "78.76667").save
City.new(:country_id => "107", :name => "Chandauli", :aliases => "Chandauli,Chandauli", :latitude => "25.26667", :longitude => "83.26667").save
City.new(:country_id => "107", :name => "Chandannagar", :aliases => "Chandannagar,Chandernagor,Chandernagore,Chandannagar", :latitude => "22.86917", :longitude => "88.37722").save
City.new(:country_id => "107", :name => "Chanasma", :aliases => "Chanasma,ChÄnasma,ChÄnasma", :latitude => "23.71667", :longitude => "72.11667").save
City.new(:country_id => "107", :name => "Chamrajnagar", :aliases => ",ChÄmrÄjnagar", :latitude => "11.91667", :longitude => "76.95").save
City.new(:country_id => "107", :name => "Champa", :aliases => ",ChÄmpa", :latitude => "22.05", :longitude => "82.65").save
City.new(:country_id => "107", :name => "Chamba", :aliases => "Chamba,Chamba", :latitude => "32.56667", :longitude => "76.13333").save
City.new(:country_id => "107", :name => "Challapalle", :aliases => ",Challapalle", :latitude => "16.11667", :longitude => "80.93333").save
City.new(:country_id => "107", :name => "Challakere", :aliases => "Challakere,Challakere", :latitude => "14.31667", :longitude => "76.65").save
City.new(:country_id => "107", :name => "Chalisgaon", :aliases => "Chalisgaon,ChÄlisgaon,ChÄlisgaon", :latitude => "20.46667", :longitude => "75.01667").save
City.new(:country_id => "107", :name => "Chalala", :aliases => "Chalala,ChalÄla,ChalÄla", :latitude => "21.41667", :longitude => "71.16667").save
City.new(:country_id => "107", :name => "Chakradharpur", :aliases => "Chakardharpore,Chakradharpur,Chakradharpur", :latitude => "22.7", :longitude => "85.63333").save
City.new(:country_id => "107", :name => "Chaklasi", :aliases => "Chaklasi,ChaklÄsi,ChaklÄsi", :latitude => "22.65", :longitude => "72.93333").save
City.new(:country_id => "107", :name => "Chakia", :aliases => "Chakia,ChÄkia,ChÄkia", :latitude => "26.41667", :longitude => "85.05").save
City.new(:country_id => "107", :name => "Chakan", :aliases => "Chakan,ChÄkan,ChÄkan", :latitude => "18.75", :longitude => "73.85").save
City.new(:country_id => "107", :name => "Chaibasa", :aliases => "Chaibasa,ChÄÄ«bÄsa,ChÄÄ«bÄsa", :latitude => "22.56667", :longitude => "85.81667").save
City.new(:country_id => "107", :name => "Canning", :aliases => "Canning,Canning Town,Port Canning,Canning", :latitude => "22.31889", :longitude => "88.67139").save
City.new(:country_id => "107", :name => "Cannanore", :aliases => "Cananor,Kananorskom,Kannanur,Kannur,Kanoor,ÐÐ°Ð½Ð°Ð½Ð¾ÑÑÐºÐ¾Ð¼,Cannanore", :latitude => "11.86752", :longitude => "75.35763").save
City.new(:country_id => "107", :name => "Calcutta", :aliases => "Calcuta,Calcuta - kalakata,Calcuta - à¦à¦²à¦à¦¾à¦¤à¦¾,Calcutta,CalcutÃ¡,Caliquit,Kal'kutta,Kalikata,KalikÄtÄ,Kalkata,Kalkato,Kalkuta,Kalkutta,KalkÃºtta,Kolkata,Sealdah,jia er ge da,kalakata,klkwth,kolakata,kolkata,kolkatta,korukata,qwlqth,ÐÐ°Ð»ÐºÑÑÐ°,ÐÐ°Ð»ÑÐºÑÑÑÐ°,ÐÐ¾Ð»ÐºÐ°ÑÐ°,×××××ª×,×§×××§××,à¤à¤²à¤à¤¾à¤¤à¤¾,à¤à¥à¤²à¤à¤¾à¤¤à¤¾,à¦à¦²à¦à¦¾à¦¤à¦¾,à®à¯à®²à¯à®à®¤à¯à®¤à®¾,à´àµà´²àµâà´àµà´à´¤àµà´¤,à½à¼à½£à½²à¼à½à½´à¼à½,ááááá£á¢á,ã³ã«ã«ã¿,å å°åç­,ì½ì¹´í,Calcutta", :latitude => "22.56972", :longitude => "88.36972").save
City.new(:country_id => "107", :name => "Byadgi", :aliases => "Byadgi,ByÄdgi,ByÄdgi", :latitude => "14.68333", :longitude => "75.48333").save
City.new(:country_id => "107", :name => "Buxar", :aliases => ",Buxar", :latitude => "25.58333", :longitude => "83.98333").save
City.new(:country_id => "107", :name => "Burla", :aliases => ",Burla", :latitude => "21.5", :longitude => "83.86667").save
City.new(:country_id => "107", :name => "Burhar", :aliases => "Burhar,Burhar", :latitude => "23.21667", :longitude => "81.53333").save
City.new(:country_id => "107", :name => "Burhanpur", :aliases => "Burhanpur,BurhÄnpur,BurhÄnpur", :latitude => "21.3", :longitude => "76.23333").save
City.new(:country_id => "107", :name => "Bundu", :aliases => "Bundu,BÅ«ndu,BÅ«ndu", :latitude => "23.18333", :longitude => "85.58333").save
City.new(:country_id => "107", :name => "Bundi", :aliases => "Bundi,Bundi City,BÅ«ndi,ÐÑÐ½Ð´Ð¸,BÅ«ndi", :latitude => "25.44167", :longitude => "75.64167").save
City.new(:country_id => "107", :name => "Buldana", :aliases => ",BuldÄna", :latitude => "20.53333", :longitude => "76.18333").save
City.new(:country_id => "107", :name => "Bulandshahr", :aliases => "Bulandshahr,Bulandshakhre,ÐÑÐ»Ð°Ð½Ð´ÑÐ°ÑÑÐµ,Bulandshahr", :latitude => "28.4", :longitude => "77.85").save
City.new(:country_id => "107", :name => "Budhlada", :aliases => "Budhlada,BudhlÄda,BudhlÄda", :latitude => "29.93333", :longitude => "75.56667").save
City.new(:country_id => "107", :name => "Budhana", :aliases => "Budhana,BudhÄna,BudhÄna", :latitude => "29.28333", :longitude => "77.46667").save
City.new(:country_id => "107", :name => "Budaun", :aliases => "Budaun,Budaun", :latitude => "28.05", :longitude => "79.11667").save
City.new(:country_id => "107", :name => "Brajarajnagar", :aliases => "Brajarajnagar,Brajrajnagar,BrÄjarÄjnagar,BrÄjarÄjnagar", :latitude => "21.81667", :longitude => "83.91667").save
City.new(:country_id => "107", :name => "Brahmapur", :aliases => "Berhampore,Berhampur,Brahmapur,Brahmapuramu,Ganjam,Brahmapur", :latitude => "19.31667", :longitude => "84.78333").save
City.new(:country_id => "107", :name => "Botad", :aliases => "Botad,BotÄd,BotÄd", :latitude => "22.16667", :longitude => "71.66667").save
City.new(:country_id => "107", :name => "Borsad", :aliases => "Borsad,Borsad", :latitude => "22.41667", :longitude => "72.9").save
City.new(:country_id => "107", :name => "Borivli", :aliases => "Borivali,Borivli,Borivli", :latitude => "19.23333", :longitude => "72.85").save
City.new(:country_id => "107", :name => "Bongaigaon", :aliases => "Bongaigaon,Bongaigaon", :latitude => "26.46667", :longitude => "90.56667").save
City.new(:country_id => "107", :name => "Mumbai", :aliases => "Asumumbay,Bombai,Bombaim,Bombaj,Bombay,Bombaya,Bombej,Bombejus,BombÄjus,Bumbaj,BÅ¯mbaj,Dakbayan sa Bombay,Gorad Mumbai,Lungsod ng Mumbai,Moembaai,Mumbai,Mumbai - à¤®à¥à¤®à¤¼à¤¬à¤,Mumbaj,Mumbaja,Mumbajo,Mumbajus,Mumbay,Numbai,Vomvai,bamba'i,bmbyy,gretara mumba'i,meng mai,mmbyy,mu0bai,muba'i,mum bi,mumba'i,mumbai,mumpai,mumâba'i,munbai,mwmbay,mwmbyy,mymbais,pullapa mumba'i,ÎÎ¿Î¼Î²Î¬Î·,ÐÐ¾Ð¼Ð±Ð°Ð¹,ÐÐ¾Ð¼Ð±ÐµÐ¹,ÐÐ¾ÑÐ°Ð´ ÐÑÐ¼Ð±Ð°Ñ,ÐÑÐ¼Ð±Ð°Ð¸,ÐÑÐ¼Ð±Ð°Ð¹,ÐÑÐ¼Ð±Ð°Ñ,ÐÑÐ¼Ð±Ð°Ñ,ÐÑÐ¼Ð±Ð°Ñ,ÕÕ¸ÖÕ´Õ¢Õ¡Õµ,××××××,××××××,Ø¨ÙØ¨Ø¦Û,ÙÙØ¨Ø¦Ù,ÙÙØ¨Ø¦Û,ÙÙÙØ¨Ø§Ù,ÙÙÙØ¨Ø§Ù,ÙÙÙØ¨Ø§Û,ÞÞªÞÞ°ÞÞ§ÞÞ©,à¤à¥à¤°à¥à¤à¤° à¤®à¥à¤®à¥à¤¬à¤,à¤¬à¤®à¥à¤¬à¤,à¤®à¥à¤à¤¬à¤,à¤®à¥à¤®à¥à¤¬à¤,à¤®à¥à¤®à¥âà¤¬à¤,à¦ªà§à¦²à§à¦²à¦¾à¦ª à¦®à§à¦®à§à¦¬à¦¾à¦,à¦®à§à¦®à§à¦¬à¦,à¦®à§à¦®à§à¦¬à¦¾à¦,à¨®à©à©°à¨¬à¨,àª®à«àªàª¬àª,à¬®à­à¬®à­à¬¬à¬¾à¬,à®®à¯à®®à¯à®ªà¯,à°®à±à°à°¬à±,à²®à³à²à²¬à³,à²®à³à³¦à²¬à³,à´®àµà´à´¬àµ,à¸¡à¸¸à¸¡à¹à¸,à½ à½à½¼à½à¼à½¦à¾¦à½º,áá£áááá,ã ã³ãã¤,å­ä¹°,ë­ë°ì´,Mumbai", :latitude => "19.01441", :longitude => "72.84794").save
City.new(:country_id => "107", :name => "Bolpur", :aliases => "Bolpur,Bolpur", :latitude => "23.66667", :longitude => "87.71667").save
City.new(:country_id => "107", :name => "Bokaro", :aliases => "Bokaro,BokÄro,ÐÐ¾ÐºÐ°ÑÐ¾,BokÄro", :latitude => "23.78333", :longitude => "85.96667").save
City.new(:country_id => "107", :name => "Bokajan", :aliases => "Bokajan,Bokajan O. Noajan,BokajÄn,BokajÄn", :latitude => "26.01667", :longitude => "93.78333").save
City.new(:country_id => "107", :name => "Boisar", :aliases => "Boisar,Boisar", :latitude => "19.8", :longitude => "72.75").save
City.new(:country_id => "107", :name => "Bodinayakkanur", :aliases => "Bodinayakanur,Bodinayakkanur,BodinÄyakkanÅ«r,BodinÄyakkanÅ«r", :latitude => "10.01667", :longitude => "77.35").save
City.new(:country_id => "107", :name => "Bodh Gaya", :aliases => "Bodh Gaja,Bodh Gaya,Bodh-Gaya,Bodhgaja,Bodhgaya,Buddh Gaya,Buddha Gaya,BÃ³dhgaja,bodha gaya,bodhagaya,bodkh-gaja,buddagaya,phuthth kh ya,pu ti jia ye,ÐÐ¾Ð´Ñ-ÐÐ°Ñ,à¤¬à¥à¤§à¤à¤¯à¤¾,à¦¬à§à¦§ à¦à¦¯à¦¼à¦¾,à¸à¸¸à¸à¸à¸à¸¢à¸²,ãããã¬ã¤,è©æä¼½è¶,Bodh Gaya", :latitude => "24.7", :longitude => "84.98333").save
City.new(:country_id => "107", :name => "Bodhan", :aliases => "Bodhan,Bodhan", :latitude => "18.66667", :longitude => "77.9").save
City.new(:country_id => "107", :name => "Bobbili", :aliases => "Bobbili,Bobbili", :latitude => "18.56667", :longitude => "83.36667").save
City.new(:country_id => "107", :name => "Biswan", :aliases => "Biswan,BiswÄn,BiswÄn", :latitude => "27.5", :longitude => "81").save
City.new(:country_id => "107", :name => "Bissau", :aliases => "Bisau,Bissau,ÐÐ¸ÑÐ°Ñ,Bissau", :latitude => "28.25", :longitude => "75.08333").save
City.new(:country_id => "107", :name => "Bishnupur", :aliases => "Bishnupur,Vishnupur,ÐÐ¸ÑÐ½ÑÐ¿ÑÑ,Bishnupur", :latitude => "23.08333", :longitude => "87.31667").save
City.new(:country_id => "107", :name => "Bisauli", :aliases => "Bisauli,Bisauli", :latitude => "28.31667", :longitude => "78.93333").save
City.new(:country_id => "107", :name => "Bisalpur", :aliases => "Bisalpur,BÄ«salpur,BÄ«salpur", :latitude => "28.3", :longitude => "79.8").save
City.new(:country_id => "107", :name => "Birur", :aliases => "Birur,BirÅ«r,BirÅ«r", :latitude => "13.61667", :longitude => "75.96667").save
City.new(:country_id => "107", :name => "Birpur", :aliases => ",BÄ«rpur", :latitude => "26.51667", :longitude => "87.01667").save
City.new(:country_id => "107", :name => "Birmitrapur", :aliases => ",Birmitrapur", :latitude => "22.4", :longitude => "84.76667").save
City.new(:country_id => "107", :name => "Binika", :aliases => "Binika,Binka,Binika", :latitude => "21.03333", :longitude => "83.8").save
City.new(:country_id => "107", :name => "Bindki", :aliases => "Bindki,Bindki", :latitude => "26.03333", :longitude => "80.6").save
City.new(:country_id => "107", :name => "Etawa", :aliases => "Bina-Etawa,BÄ«na-EtÄwa,Etawa,Etawah,EtÄwa,EtÄwa", :latitude => "24.1855", :longitude => "78.2031").save
City.new(:country_id => "107", :name => "Belthara", :aliases => "Belthara,Bilthar,Bilthra,Belthara", :latitude => "26.12306", :longitude => "83.86889").save
City.new(:country_id => "107", :name => "Bilsi", :aliases => "Bilsi,Bilsi", :latitude => "28.13333", :longitude => "78.91667").save
City.new(:country_id => "107", :name => "Bilsanda", :aliases => "Bilsanda,Bilsanda", :latitude => "28.25", :longitude => "79.95").save
City.new(:country_id => "107", :name => "Bilhaur", :aliases => "Bilhaur,Bilhaur", :latitude => "26.85", :longitude => "80.08333").save
City.new(:country_id => "107", :name => "Bilgram", :aliases => "Bilgram,BilgrÄm,BilgrÄm", :latitude => "27.18333", :longitude => "80.03333").save
City.new(:country_id => "107", :name => "Bilgi", :aliases => "Bilg,Bilgi,Bilgi", :latitude => "16.35", :longitude => "75.61667").save
City.new(:country_id => "107", :name => "Bilaspur", :aliases => ",BilÄspur", :latitude => "28.88333", :longitude => "79.26667").save
City.new(:country_id => "107", :name => "Bilaspur", :aliases => "Bilaspur,Bilaspura,BilÄspur,ÐÐ¸Ð»Ð°ÑÐ¿ÑÑÐ°,BilÄspur", :latitude => "22.08333", :longitude => "82.15").save
City.new(:country_id => "107", :name => "Bilasipara", :aliases => "Bilasipara,BilÄsipÄra,BilÄsipÄra", :latitude => "26.23333", :longitude => "90.23333").save
City.new(:country_id => "107", :name => "Bilari", :aliases => ",BilÄri", :latitude => "28.63333", :longitude => "78.8").save
City.new(:country_id => "107", :name => "Bilara", :aliases => "Bilara,BilÄra,BilÄra", :latitude => "26.17917", :longitude => "73.70556").save
City.new(:country_id => "107", :name => "Bikramganj", :aliases => "Bikramganj,Bikramganj", :latitude => "25.2", :longitude => "84.25").save
City.new(:country_id => "107", :name => "Bikaner", :aliases => "Bikaner,BÃ®kÃ¢ner,BÄ«kÄner,bikanera,ÐÐ¸ÐºÐ°Ð½ÐµÑ,à¤¬à¥à¤à¤¾à¤¨à¥à¤°,BÄ«kÄner", :latitude => "28.01667", :longitude => "73.3").save
City.new(:country_id => "107", :name => "Bijnor", :aliases => "Bijnor,Bijnor", :latitude => "29.36667", :longitude => "78.13333").save
City.new(:country_id => "107", :name => "Bijbiara", :aliases => "Bijbiara,BijbiÄra,Vejibyor,VejibyÅr,BijbiÄra", :latitude => "33.8", :longitude => "75.1").save
City.new(:country_id => "107", :name => "Bijawar", :aliases => "Bijawar,BijÄwar,BijÄwar", :latitude => "24.63333", :longitude => "79.5").save
City.new(:country_id => "107", :name => "Bijapur", :aliases => "Bidzapur,Bidzhapur,BidÅºapur,Bijapur,BijÄpur,BÃ®jÃ¢pur,Vijayapur,Visiapur,bi jia bu er,bijapura,ÐÐ¸Ð´Ð¶Ð°Ð¿ÑÑ,à²¬à²¿à²à²¾à²ªà³à²°,æ¯è´¾å¸å°,BijÄpur", :latitude => "16.83333", :longitude => "75.7").save
City.new(:country_id => "107", :name => "Bihar Sharif", :aliases => "Behar,Bihar,Bihar Sharif,BihÄr,BihÄr SharÄ«f,BihÄr SharÄ«f", :latitude => "25.18333", :longitude => "85.51667").save
City.new(:country_id => "107", :name => "Bihariganj", :aliases => ",BihÄrÄ«ganj", :latitude => "25.73333", :longitude => "86.98333").save
City.new(:country_id => "107", :name => "Bidhuna", :aliases => "Bidhuna,BidhÅ«na,BidhÅ«na", :latitude => "26.8022", :longitude => "79.5088").save
City.new(:country_id => "107", :name => "Bidar", :aliases => "Bidar,BÄ«dar,ÐÐ¸Ð´Ð°Ñ,BÄ«dar", :latitude => "17.9", :longitude => "77.55").save
City.new(:country_id => "107", :name => "Biaora", :aliases => "Biaora,Biaora", :latitude => "23.86667", :longitude => "76.91667").save
City.new(:country_id => "107", :name => "Bhuvanagiri", :aliases => "Bhavanagiri,Bhuvanagiri,Bliuvanagiri,Bhuvanagiri", :latitude => "11.46667", :longitude => "79.63333").save
City.new(:country_id => "107", :name => "Bhusawal", :aliases => "Bhusaval,Bhusawal,BhusÄval,BhusÄwal,BhusÄwal", :latitude => "21.05", :longitude => "75.76667").save
City.new(:country_id => "107", :name => "Bhum", :aliases => "Bhoom,Bhum,BhÅ«m,BhÅ«m", :latitude => "18.46667", :longitude => "75.66667").save
City.new(:country_id => "107", :name => "Bhuj", :aliases => "Bhooj,Bhuj,bhuja,àª­à«àª,Bhuj", :latitude => "23.26667", :longitude => "69.66667").save
City.new(:country_id => "107", :name => "Bhudgaon", :aliases => "Bhudgaon,Budhgaon,Bhudgaon", :latitude => "16.9", :longitude => "74.6").save
City.new(:country_id => "107", :name => "Bhubaneshwar", :aliases => "BBSR,Bhubaneshwar,Bhubaneswar,BhubaneÅwar,Bkhubaneshvar,Temple City of India,bhubanesbara,bhuvanesvara,buvu~aneshuvu~aru,puvanesvar,ÐÑÑÐ±Ð°Ð½ÐµÑÐ²Ð°Ñ,×××× ×©××××¨,à¤­à¥à¤µà¤¨à¥à¤¶à¥à¤µà¤°,à¦­à§à¦¬à¦¨à§à¦¶à§à¦¬à¦°,à®ªà¯à®µà®©à¯à®¸à¯à®µà®°à¯,ãã´ã¡ãã¼ã·ã¥ã´ã¡ã«,Bhubaneshwar", :latitude => "20.23333", :longitude => "85.83333").save
City.new(:country_id => "107", :name => "Bhuban", :aliases => "Bhuban,Bhuban", :latitude => "20.88333", :longitude => "85.83333").save
City.new(:country_id => "107", :name => "Bhor", :aliases => "Bhor,Bhor", :latitude => "18.16667", :longitude => "73.85").save
City.new(:country_id => "107", :name => "Bhopal", :aliases => "Bhopal,Bhopalas,Bkhopal,bhopala,bo pa er,boparu,popal,ÐÑÐ¾Ð¿Ð°Ð»,à¤­à¥à¤ªà¤¾à¤²,à¤­à¥à¤ªà¤¾à¤³,à¦­à§à¦ªà¦¾à¦²,à®ªà¯à®ªà®¾à®²à¯,ããã¼ã«,ãã¼ãã¼ã«,åå¸å°,BhopÄl", :latitude => "23.26667", :longitude => "77.4").save
City.new(:country_id => "107", :name => "Bhongir", :aliases => ",BhongÄ«r", :latitude => "17.51083", :longitude => "78.88889").save
City.new(:country_id => "107", :name => "Bhongaon", :aliases => ",Bhongaon", :latitude => "27.25", :longitude => "79.18333").save
City.new(:country_id => "107", :name => "Bhogpur", :aliases => "Bhogpur,Bhogpur Sirwal,Bhogpur", :latitude => "31.55", :longitude => "75.6325").save
City.new(:country_id => "107", :name => "Bhiwani", :aliases => "Bhiwani,BhiwÄni,BhiwÄni", :latitude => "28.78333", :longitude => "76.13333").save
City.new(:country_id => "107", :name => "Bhiwandi", :aliases => "Bhiwandi,Bhiwndi,Bhiwandi", :latitude => "19.3", :longitude => "73.06667").save
City.new(:country_id => "107", :name => "Bhitarwar", :aliases => "Bhitarwar,BhitarwÄr,BhitarwÄr", :latitude => "25.8", :longitude => "78.11667").save
City.new(:country_id => "107", :name => "Bhinmal", :aliases => "Bhinmal,BhÄ«nmÄl,BhÄ«nmÄl", :latitude => "25", :longitude => "72.25").save
City.new(:country_id => "107", :name => "Bhinga", :aliases => "Bhinga,Bhinga", :latitude => "27.71667", :longitude => "81.93333").save
City.new(:country_id => "107", :name => "Bhindar", :aliases => ",BhÄ«ndar", :latitude => "24.5", :longitude => "74.18333").save
City.new(:country_id => "107", :name => "Bhind", :aliases => "Bhind,Bhind", :latitude => "26.56417", :longitude => "78.78833").save
City.new(:country_id => "107", :name => "Bhimunipatnam", :aliases => "Bheemunipatnam,Bhimunipatnam,BhÄ«munipatnam,Bimlipatam,BhÄ«munipatnam", :latitude => "17.88333", :longitude => "83.43333").save
City.new(:country_id => "107", :name => "Bhimavaram", :aliases => "Bhimavaram,BhÄ«mavaram,BhÄ«mavaram", :latitude => "16.53333", :longitude => "81.53333").save
City.new(:country_id => "107", :name => "Bhilwara", :aliases => "Bhilwara,BhÄ«lwÄra,BhÄ«lwÄra", :latitude => "25.35", :longitude => "74.63333").save
City.new(:country_id => "107", :name => "Bhilai", :aliases => "Bhilai,Bkhilai,birai,ÐÑÐ¸Ð»Ð°Ð¸,ãã©ã¤,Bhilai", :latitude => "21.21667", :longitude => "81.43333").save
City.new(:country_id => "107", :name => "Bhikhi", :aliases => "Bhikhi,BhÄ«khi,BhÄ«khi", :latitude => "30.06667", :longitude => "75.53333").save
City.new(:country_id => "107", :name => "Bhikangaon", :aliases => "Bhikangaon,Bhikangaon", :latitude => "21.86667", :longitude => "75.95").save
City.new(:country_id => "107", :name => "Bhayavadar", :aliases => "Bhaya nadar,Bhayaradar,Bhayavadar,Bhayawadar,BhÄyÄradar,BhÄyÄvadar,BhÄyÄvadar", :latitude => "21.85", :longitude => "70.25").save
City.new(:country_id => "107", :name => "Bhawanipatna", :aliases => "Bhawanipatna,BhawÄnipatna,BhawÄnipatna", :latitude => "19.9", :longitude => "83.16667").save
City.new(:country_id => "107", :name => "Bhawanigarh", :aliases => "Bhawanigarh,BhawÄnÄ«garh,BhawÄnÄ«garh", :latitude => "30.26667", :longitude => "76.035").save
City.new(:country_id => "107", :name => "Bhawaniganj", :aliases => ",BhawÄniganj", :latitude => "24.41667", :longitude => "75.83333").save
City.new(:country_id => "107", :name => "Bhavnagar", :aliases => "Baunagar,Bharnagar,Bhaunagar,Bhavnagar,Bhunagar,BhÄvnagar,Bkhavnagarom,bhavanagara,ÐÑÐ°Ð²Ð½Ð°Ð³Ð°ÑÐ¾Ð¼,àª­àª¾àªµàª¨àªàª°,BhÄvnagar", :latitude => "21.76667", :longitude => "72.15").save
City.new(:country_id => "107", :name => "Bhavani", :aliases => "Bhavani,BhavÄni,BhavÄni", :latitude => "11.45", :longitude => "77.68333").save
City.new(:country_id => "107", :name => "Bhattiprolu", :aliases => "Bhattiprolu,Bhattiprolu", :latitude => "16.1", :longitude => "80.78333").save
City.new(:country_id => "107", :name => "Bhatpara", :aliases => "Bhatpara,BhÄtpÄra,BhÄtpÄra", :latitude => "22.87139", :longitude => "88.40889").save
City.new(:country_id => "107", :name => "Bhatkal", :aliases => "Bhatkal,Bhatkal", :latitude => "13.96667", :longitude => "74.56667").save
City.new(:country_id => "107", :name => "Bhatinda", :aliases => ",Bhatinda", :latitude => "30.2", :longitude => "74.95").save
City.new(:country_id => "107", :name => "Bhatapara", :aliases => "Bhatapara,BhÄtÄpÄra,BhÄtÄpÄra", :latitude => "21.73333", :longitude => "81.93333").save
City.new(:country_id => "107", :name => "Bhasawar", :aliases => ",BhasÄwar", :latitude => "27.03333", :longitude => "77.03333").save
City.new(:country_id => "107", :name => "Bharwari", :aliases => "Bharwari,BharwÄri,BharwÄri", :latitude => "25.55", :longitude => "81.5").save
City.new(:country_id => "107", :name => "Bharuch", :aliases => "Baroach,Bharoch,Bharuch,BharÅ«ch,Broach,BharÅ«ch", :latitude => "21.7", :longitude => "72.96667").save
City.new(:country_id => "107", :name => "Bharthana", :aliases => "Bharthana,Bharthana", :latitude => "26.7571", :longitude => "79.2248").save
City.new(:country_id => "107", :name => "Bharatpur", :aliases => ",Bharatpur", :latitude => "27.21667", :longitude => "77.48333").save
City.new(:country_id => "107", :name => "Bhanvad", :aliases => "Bhanvad,Bhanwar,Bhauwar,BhÄnvad,BhÄnvad", :latitude => "21.92639", :longitude => "69.77361").save
City.new(:country_id => "107", :name => "Bhanpuri", :aliases => "Bhanpuri,BhÄnpuri,BhÄnpuri", :latitude => "21.1", :longitude => "80.91667").save
City.new(:country_id => "107", :name => "Bhanpura", :aliases => "Bhanpura,BhÄnpura,BhÄnpura", :latitude => "24.513", :longitude => "75.7469").save
City.new(:country_id => "107", :name => "Bhanjanagar", :aliases => "Bhanjanagar,Russelkonda,Russellkonda,Bhanjanagar", :latitude => "19.93333", :longitude => "84.58333").save
City.new(:country_id => "107", :name => "Bhander", :aliases => "Bhander,BhÄnder,BhÄnder", :latitude => "25.73333", :longitude => "78.75").save
City.new(:country_id => "107", :name => "Bhandara", :aliases => "Bhandara,BhandÄra,Bkhandara,ÐÑÐ°Ð½Ð´Ð°ÑÐ°,BhandÄra", :latitude => "21.16667", :longitude => "79.65").save
City.new(:country_id => "107", :name => "Bhalki", :aliases => "Bhalki,BhÄlki,BhÄlki", :latitude => "18.03333", :longitude => "77.21667").save
City.new(:country_id => "107", :name => "Bhaisa", :aliases => "Bhainsa,Bhaisa,Bhaisa", :latitude => "19.1", :longitude => "77.96667").save
City.new(:country_id => "107", :name => "Bhainsdehi", :aliases => ",Bhainsdehi", :latitude => "21.64667", :longitude => "77.6325").save
City.new(:country_id => "107", :name => "Bhagalpur", :aliases => ",BhÄgalpur", :latitude => "25.25", :longitude => "87").save
City.new(:country_id => "107", :name => "Bhadreswar", :aliases => "Bhadreswar,Bhadreswar", :latitude => "22.82444", :longitude => "88.35056").save
City.new(:country_id => "107", :name => "Bhadravati", :aliases => "Bhadravati,BhadrÄvati,BhadrÄvati", :latitude => "13.86667", :longitude => "75.71667").save
City.new(:country_id => "107", :name => "Bhadrakh", :aliases => "Bhadrak,Bhadrakh,Bhadrakh", :latitude => "21.05278", :longitude => "86.52").save
City.new(:country_id => "107", :name => "Bhadrachalam", :aliases => "Bhadrachalam,Bhadrachellam Road,BhadrÄchalam,BhadrÄchalam", :latitude => "17.66667", :longitude => "80.88333").save
City.new(:country_id => "107", :name => "Bhadra", :aliases => "Bhadra,BhÄdra,Bkhadra,ÐÑÐ°Ð´ÑÐ°,BhÄdra", :latitude => "29.11667", :longitude => "75.16667").save
City.new(:country_id => "107", :name => "Bhadohi", :aliases => "Bhadohi,BhadohÄ«,BhadohÄ«", :latitude => "25.41667", :longitude => "82.56667").save
City.new(:country_id => "107", :name => "Bhadaur", :aliases => "Bhadaur,Bhadaur", :latitude => "30.48333", :longitude => "75.31667").save
City.new(:country_id => "107", :name => "Bhadasar", :aliases => ",BhÄdÄsar", :latitude => "28.28333", :longitude => "74.31667").save
City.new(:country_id => "107", :name => "Bhachau", :aliases => "Bachau,Bhachau,BhachÄu,Buchow,BhachÄu", :latitude => "23.28333", :longitude => "70.35").save
City.new(:country_id => "107", :name => "Bhabua", :aliases => "Bhabua,Bhabua", :latitude => "25.05", :longitude => "83.61667").save
City.new(:country_id => "107", :name => "Beypore", :aliases => "Beipur,Beppur,Beypore,Beypur,Beypore", :latitude => "11.18333", :longitude => "75.81667").save
City.new(:country_id => "107", :name => "Bewar", :aliases => ",Bewar", :latitude => "27.2184", :longitude => "79.3005").save
City.new(:country_id => "107", :name => "Betul", :aliases => "Badnur,BadnÃºr,Betul,BetÅ«l,BetÅ«l", :latitude => "21.91528", :longitude => "77.89611").save
City.new(:country_id => "107", :name => "Bettiah", :aliases => "Bettiah,Bettiah", :latitude => "26.8", :longitude => "84.5").save
City.new(:country_id => "107", :name => "Betamcherla", :aliases => ",Betamcherla", :latitude => "15.46667", :longitude => "78.16667").save
City.new(:country_id => "107", :name => "Beri Khas", :aliases => "Beri,Beri Khas,Beri KhÄs,Beri KhÄs", :latitude => "28.7", :longitude => "76.58333").save
City.new(:country_id => "107", :name => "Berasia", :aliases => "Berasia,Berasia", :latitude => "23.63333", :longitude => "77.43333").save
City.new(:country_id => "107", :name => "Beohari", :aliases => "Beohari,BeohÄri,BeohÄri", :latitude => "24.05", :longitude => "81.38333").save
City.new(:country_id => "107", :name => "Bemetara", :aliases => ",BemetÄra", :latitude => "21.7", :longitude => "81.53333").save
City.new(:country_id => "107", :name => "Belur", :aliases => "Belur,BelÅ«r,ÐÐµÐ»ÑÑ,BelÅ«r", :latitude => "13.16667", :longitude => "75.86667").save
City.new(:country_id => "107", :name => "Belsand", :aliases => "Belsand,Belsand", :latitude => "26.45", :longitude => "85.4").save
City.new(:country_id => "107", :name => "Belonia", :aliases => "Belonia,Beloniya,Belonia", :latitude => "23.25278", :longitude => "91.45139").save
City.new(:country_id => "107", :name => "Bellary", :aliases => "Ballari,BallÄri,Bellari,Bellary,BellÄri,ÐÐµÐ»Ð»Ð°ÑÐ¸,Bellary", :latitude => "15.15", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Belgaum", :aliases => "Belgaum,bei er gao mu,belaganva,belagavi,belgam,à¤¬à¥à¤³à¤à¤¾à¤à¤µ,à°¬à±à°²à±à°à°¾à°,à²¬à³à²³à²à²¾à²µà²¿,è´å°é«å§,Belgaum", :latitude => "15.86667", :longitude => "74.5").save
City.new(:country_id => "107", :name => "Beldanga", :aliases => "Beldanga,BeldÄnga,BeldÄnga", :latitude => "23.93333", :longitude => "88.25").save
City.new(:country_id => "107", :name => "Bela", :aliases => "Bela,Bela Partabgarh,Partapgarh,Pratapgarh,ÐÐµÐ»Ð°,Bela", :latitude => "25.93333", :longitude => "81.98333").save
City.new(:country_id => "107", :name => "Behror", :aliases => "Behror,Behror", :latitude => "27.88333", :longitude => "76.28333").save
City.new(:country_id => "107", :name => "Behat", :aliases => ",Behat", :latitude => "30.16667", :longitude => "77.61667").save
City.new(:country_id => "107", :name => "Begusarai", :aliases => "Begusarai,Begusarai", :latitude => "25.41667", :longitude => "86.13333").save
City.new(:country_id => "107", :name => "Begun", :aliases => "Begun,BegÅ«n,ÐÐµÐ³ÑÐ½,BegÅ«n", :latitude => "24.98333", :longitude => "75").save
City.new(:country_id => "107", :name => "Begamganj", :aliases => "Begamganj,Begamganj", :latitude => "23.6", :longitude => "78.33333").save
City.new(:country_id => "107", :name => "Bedi", :aliases => "Beda,Bedi,Bedi Bandar,ÐÐµÐ´Ð°,Bedi", :latitude => "22.5", :longitude => "70.05").save
City.new(:country_id => "107", :name => "Beawar", :aliases => "Beawar,BeÄwar,BeÄwar", :latitude => "26.1", :longitude => "74.31667").save
City.new(:country_id => "107", :name => "Bazpur", :aliases => ",BÄzpur", :latitude => "29.15", :longitude => "79.11667").save
City.new(:country_id => "107", :name => "Bayana", :aliases => "Bajan,Bayaha,Bayana,BayÄna,ÐÐ°ÑÐ½,BayÄna", :latitude => "26.9", :longitude => "77.28333").save
City.new(:country_id => "107", :name => "Bawana", :aliases => "Bawana,Bawana Delhi,BawÄna,BawÄna", :latitude => "28.8", :longitude => "77.03333").save
City.new(:country_id => "107", :name => "Bauda", :aliases => "Bauda,Baudh,Baudh Raj,Baudh RÄj,Baudh-Ral,Bauda", :latitude => "20.83333", :longitude => "84.31667").save
City.new(:country_id => "107", :name => "Batala", :aliases => "Batala,BatÄla,Butala,BatÄla", :latitude => "31.81861", :longitude => "75.20278").save
City.new(:country_id => "107", :name => "Baswa", :aliases => ",Baswa", :latitude => "27.15", :longitude => "76.58333").save
City.new(:country_id => "107", :name => "Basudebpur", :aliases => "Basudebpur,BÄsudebpur,BÄsudebpur", :latitude => "21.13528", :longitude => "86.73861").save
City.new(:country_id => "107", :name => "Basti", :aliases => "Basti,ÐÐ°ÑÑÐ¸,Basti", :latitude => "26.8", :longitude => "82.71667").save
City.new(:country_id => "107", :name => "Basoda", :aliases => "Basoda,BÄsoda,BÄsoda", :latitude => "23.85", :longitude => "77.93333").save
City.new(:country_id => "107", :name => "Basni", :aliases => "Basni,Basni Bailima,ÐÐ°ÑÐ½Ð¸,Basni", :latitude => "27.16667", :longitude => "73.65").save
City.new(:country_id => "107", :name => "Basmat", :aliases => "Basmat,Basmath,Basmat", :latitude => "19.31667", :longitude => "77.16667").save
City.new(:country_id => "107", :name => "Basi", :aliases => ",Basi", :latitude => "30.69167", :longitude => "76.39861").save
City.new(:country_id => "107", :name => "Basi", :aliases => "Basi,Dera Basi,Dera Bassi,Basi", :latitude => "30.5888", :longitude => "76.8456").save
City.new(:country_id => "107", :name => "Basi", :aliases => ",Basi", :latitude => "26.83333", :longitude => "76.03333").save
City.new(:country_id => "107", :name => "Basavana Bagevadi", :aliases => "Bagevadi,Basavana Bagevadi,Basavana BÄgevÄdi,BÄgevÄdi,Basavana BÄgevÄdi", :latitude => "16.58333", :longitude => "75.96667").save
City.new(:country_id => "107", :name => "Basavakalyan", :aliases => "Basavakalyan,BasavakalyÄn,Kalyani,KalyÄni,BasavakalyÄn", :latitude => "17.86667", :longitude => "76.95").save
City.new(:country_id => "107", :name => "Barwani", :aliases => "Barwani,BarwÄni,BarwÄni", :latitude => "22.03333", :longitude => "74.9").save
City.new(:country_id => "107", :name => "Barwala", :aliases => "Barwala,BarwÄla,BarwÄla", :latitude => "29.38333", :longitude => "75.91667").save
City.new(:country_id => "107", :name => "Baruni", :aliases => "Barani,Baruni,BÄruni,ÐÐ°ÑÑÐ½Ð¸,BÄruni", :latitude => "25.48333", :longitude => "85.98333").save
City.new(:country_id => "107", :name => "Baruipur", :aliases => "Baruipur,BÄruipur,BÄruipur", :latitude => "22.34972", :longitude => "88.43917").save
City.new(:country_id => "107", :name => "Barsi", :aliases => ",BÄrsi", :latitude => "18.23333", :longitude => "75.7").save
City.new(:country_id => "107", :name => "Barpeta", :aliases => "Barpeta,Barpeta", :latitude => "26.31667", :longitude => "91").save
City.new(:country_id => "107", :name => "Barpali", :aliases => ",BarpÄli", :latitude => "21.2", :longitude => "83.58333").save
City.new(:country_id => "107", :name => "Barnala", :aliases => "Barnala,BarnÄla,ÐÐ°ÑÐ½Ð°Ð»Ð°,BarnÄla", :latitude => "30.38333", :longitude => "75.55").save
City.new(:country_id => "107", :name => "Barmer", :aliases => ",BÄrmer", :latitude => "25.75", :longitude => "71.38333").save
City.new(:country_id => "107", :name => "Barki Saria", :aliases => ",Barki Saria", :latitude => "24.16667", :longitude => "85.88333").save
City.new(:country_id => "107", :name => "Barka Kana", :aliases => ",Barka KÄna", :latitude => "23.61667", :longitude => "85.48333").save
City.new(:country_id => "107", :name => "Barjala", :aliases => ",Barjala", :latitude => "23.61667", :longitude => "91.36667").save
City.new(:country_id => "107", :name => "Bari Sadri", :aliases => "Bari Sadri,Bari SÄdri,Bari SÄdri", :latitude => "24.41667", :longitude => "74.46667").save
City.new(:country_id => "107", :name => "Bari", :aliases => ",BÄri", :latitude => "26.65", :longitude => "77.6").save
City.new(:country_id => "107", :name => "Barhiya", :aliases => ",Barhiya", :latitude => "25.28333", :longitude => "86.03333").save
City.new(:country_id => "107", :name => "Barh", :aliases => "Barh,Barkh,BÄrh,ÐÐ°ÑÑ,BÄrh", :latitude => "25.48333", :longitude => "85.71667").save
City.new(:country_id => "107", :name => "Bargi", :aliases => ",Bargi", :latitude => "22.98333", :longitude => "79.86667").save
City.new(:country_id => "107", :name => "Bargarh", :aliases => "Baragarh,Bargarh,Bargarh", :latitude => "21.33333", :longitude => "83.61667").save
City.new(:country_id => "107", :name => "Bareilly", :aliases => "Bareilly,Barejli,Bareli,BarelÄ«,ÐÐ°ÑÐµÐ¹Ð»Ð¸,Bareilly", :latitude => "28.35", :longitude => "79.41667").save
City.new(:country_id => "107", :name => "Bardoli", :aliases => "Bardoli,Bardoti,BÄrdoli,ÐÐ°ÑÐ´Ð¾Ð»Ð¸,BÄrdoli", :latitude => "21.11667", :longitude => "73.11667").save
City.new(:country_id => "107", :name => "Barddhaman", :aliases => "Bardhaman,BardhamÄn,Burdwan,BurdwÄn,BarddhamÄn", :latitude => "23.25", :longitude => "87.85").save
City.new(:country_id => "107", :name => "Bar Bigha", :aliases => ",Bar Bigha", :latitude => "25.21667", :longitude => "85.73333").save
City.new(:country_id => "107", :name => "Baraut", :aliases => "Baraut,Baraut", :latitude => "29.1", :longitude => "77.26667").save
City.new(:country_id => "107", :name => "Barauli", :aliases => "Barauli,Barauli", :latitude => "26.4", :longitude => "84.58333").save
City.new(:country_id => "107", :name => "Barasat", :aliases => ",BÄrÄsat", :latitude => "22.71667", :longitude => "88.51667").save
City.new(:country_id => "107", :name => "Baranagar", :aliases => "Baranagar,Baranagore,Baranagar", :latitude => "22.64333", :longitude => "88.36528").save
City.new(:country_id => "107", :name => "Baran", :aliases => "Baran,BÄrÄn,ÐÐ°ÑÐ°Ð½,BÄrÄn", :latitude => "25.1", :longitude => "76.51667").save
City.new(:country_id => "107", :name => "Baramula", :aliases => ",BÄramÅ«la", :latitude => "34.2", :longitude => "74.35").save
City.new(:country_id => "107", :name => "Baramati", :aliases => "Baramati,BÄrÄmati,ÐÐ°ÑÐ°Ð¼Ð°ÑÐ¸,BÄrÄmati", :latitude => "18.15", :longitude => "74.58333").save
City.new(:country_id => "107", :name => "Barakpur", :aliases => "Barakpur,Barrackpore,BÄrÄkpur,Chanak,BÄrÄkpur", :latitude => "22.76139", :longitude => "88.37194").save
City.new(:country_id => "107", :name => "Bapatla", :aliases => "Bapatla,BÄpatla,BÄpatla", :latitude => "15.9", :longitude => "80.46667").save
City.new(:country_id => "107", :name => "Banur", :aliases => ",BanÅ«r", :latitude => "30.55556", :longitude => "76.71833").save
City.new(:country_id => "107", :name => "Bantval", :aliases => "Bantval,BantvÄl,Bantwall,Bantyal,Bartval,BantvÄl", :latitude => "12.9", :longitude => "75.03333").save
City.new(:country_id => "107", :name => "Bantva", :aliases => "Bantva,Bantwa,BÄntva,BÄntva", :latitude => "21.48639", :longitude => "70.06889").save
City.new(:country_id => "107", :name => "Banswara", :aliases => "Banswara,BÄnswÄra,BÄnswÄra", :latitude => "23.55", :longitude => "74.45").save
City.new(:country_id => "107", :name => "Banswada", :aliases => "Banswada,BÄnswÄda,BÄnswÄda", :latitude => "18.38333", :longitude => "77.88333").save
City.new(:country_id => "107", :name => "Bansi", :aliases => ",BÄnsi", :latitude => "27.18333", :longitude => "82.93333").save
City.new(:country_id => "107", :name => "Bansdih", :aliases => ",BÄnsdÄ«h", :latitude => "25.88333", :longitude => "84.21667").save
City.new(:country_id => "107", :name => "Bansbaria", :aliases => "Bansbaria,Bansberia,BÄnsbÄria,BÄnsbÄria", :latitude => "22.97194", :longitude => "88.39944").save
City.new(:country_id => "107", :name => "Bannur", :aliases => "Bannur,BannÅ«r,BannÅ«r", :latitude => "12.33083", :longitude => "76.86306").save
City.new(:country_id => "107", :name => "Banmankhi", :aliases => "Banmankhi,Banmanki,Banmankhi", :latitude => "25.88333", :longitude => "87.18333").save
City.new(:country_id => "107", :name => "Bankura", :aliases => "Bankura,BÄnkura,ÐÐ°Ð½ÐºÑÑÐ°,BÄnkura", :latitude => "23.25", :longitude => "87.06667").save
City.new(:country_id => "107", :name => "Banki", :aliases => "Banki,Bankigarh,BÄnki,BÄnkÄ«garh,BÄnki", :latitude => "20.38333", :longitude => "85.53333").save
City.new(:country_id => "107", :name => "Banka", :aliases => "Banka,Bhagalpur,BÄnka,BÄnka", :latitude => "24.88333", :longitude => "86.91667").save
City.new(:country_id => "107", :name => "Bangarmau", :aliases => "Bangarmau,BÄngarmau,BÄngarmau", :latitude => "26.9", :longitude => "80.21667").save
City.new(:country_id => "107", :name => "Bangarapet", :aliases => "Bangarapet,BangÄrapet,Bowringpet,BangÄrapet", :latitude => "12.96667", :longitude => "78.2").save
City.new(:country_id => "107", :name => "Bangaon", :aliases => "Bangaon,Bongaon,ÐÐ°Ð½Ð³Ð°Ð¾Ð½,Bangaon", :latitude => "23.06667", :longitude => "88.81667").save
City.new(:country_id => "107", :name => "Banganapalle", :aliases => "Banaganapalli,Banganapalle,Banganapilly,Banganapalle", :latitude => "15.31667", :longitude => "78.23333").save
City.new(:country_id => "107", :name => "Bengalore", :aliases => "Bangalor,Bangalora,Bangalore,Bangalore - bengaluru,Bangalore - à²¬à³à²à²à²³à³à²°à³,Bangalore City,Bangaloro,Bangalur,Bangaluri,Bengalour,Bengaluras,Bengaluru,BengalÅ«ras,BengalÅ«ru,ban jia luo er,bangalora,bangalura,bangaroru,bengalora,bengaluru,bnglwr,penkalur,ÐÐ°Ð½Ð³Ð°Ð»Ð¾Ñ,Ø¨ÙÚ¯ÙÙØ±,à¤¬à¤à¤à¤²à¥à¤°,à¤¬à¤à¤à¤³à¥à¤°,à¦¬à¦¾à¦à§à¦à¦¾à¦²à§à¦°,à¦¬à§à¦à§à¦à¦¾à¦²à§à¦°à§,àª¬à«àªàªàª²à«àª°,à®ªà¯à®à¯à®à®³à¯à®°à¯,à°¬à±à°à°à°³à±à°°à±,à²¬à³à²à²à²³à³à²°à³,à´¬à´¾à´à´àµà´²àµà´°àµâ,ãã³ã¬ã­ã¼ã«,ç­å ç¾ç¾,Bengalore", :latitude => "12.97623", :longitude => "77.60329").save
City.new(:country_id => "107", :name => "Banga", :aliases => "Banga,Banga", :latitude => "31.18694", :longitude => "75.99222").save
City.new(:country_id => "107", :name => "Bandipura", :aliases => "Bandapur,Bandipur,Bandipura,Bandipura", :latitude => "34.41667", :longitude => "74.65").save
City.new(:country_id => "107", :name => "Bandikui", :aliases => "Bandikui,BÄndÄ«kÅ«i,BÄndÄ«kÅ«i", :latitude => "27.05", :longitude => "76.56667").save
City.new(:country_id => "107", :name => "Banda", :aliases => ",BÄnda", :latitude => "25.48333", :longitude => "80.33333").save
City.new(:country_id => "107", :name => "Banda", :aliases => ",Banda", :latitude => "24.0448", :longitude => "78.9626").save
City.new(:country_id => "107", :name => "Banat", :aliases => "Banat,ÐÐ°Ð½Ð°Ñ,Banat", :latitude => "29.46667", :longitude => "77.35").save
City.new(:country_id => "107", :name => "Banapur", :aliases => "Banapur,Banpur,BÄnapur,BÄnpur,BÄnapur", :latitude => "19.78333", :longitude => "85.18333").save
City.new(:country_id => "107", :name => "Bamor Kalan", :aliases => "Bamor,Bamor Kalan,BÄmor,BÄmor KalÄn,BÄmor KalÄn", :latitude => "24.9", :longitude => "78.15").save
City.new(:country_id => "107", :name => "Balurghat", :aliases => "Balurghat,BÄlurghÄt,BÄlurghÄt", :latitude => "25.21667", :longitude => "88.76667").save
City.new(:country_id => "107", :name => "Balugaon", :aliases => "Balugaon,BÄlugaon,BÄlugaon", :latitude => "20.16667", :longitude => "85.1").save
City.new(:country_id => "107", :name => "Balrampur", :aliases => "Balrampur,BalrÄmpur,BalrÄmpur", :latitude => "27.43333", :longitude => "82.18333").save
City.new(:country_id => "107", :name => "Balotra", :aliases => "Balotra,BÄlotra,BÄlotra", :latitude => "25.83333", :longitude => "72.23333").save
City.new(:country_id => "107", :name => "Baloda Bazar", :aliases => "Baloda Bazar,Baloda BÄzÄr,Baloda BÄzÄr", :latitude => "21.66667", :longitude => "82.16667").save
City.new(:country_id => "107", :name => "Balod", :aliases => "Balod,Balod", :latitude => "20.73", :longitude => "81.20472").save
City.new(:country_id => "107", :name => "Bali", :aliases => "Bali,Bally,BÄli,ÐÐ°Ð»Ð¸,BÄli", :latitude => "22.64611", :longitude => "88.34028").save
City.new(:country_id => "107", :name => "Ballalpur", :aliases => "Ballalpur,Ballarpur,BallÄlpur,BallÄlpur", :latitude => "19.83333", :longitude => "79.35").save
City.new(:country_id => "107", :name => "Bali", :aliases => ",BÄli", :latitude => "25.18333", :longitude => "73.28333").save
City.new(:country_id => "107", :name => "Balasore", :aliases => "Balasor,Balasore,Baleshwar,BÄleshwar,ÐÐ°Ð»Ð°ÑÐ¾Ñ,Balasore", :latitude => "21.49417", :longitude => "86.93167").save
City.new(:country_id => "107", :name => "Balarampur", :aliases => ",BalarÄmpur", :latitude => "23.11667", :longitude => "86.21667").save
City.new(:country_id => "107", :name => "Balapur", :aliases => ",BÄlÄpur", :latitude => "20.66667", :longitude => "76.76667").save
City.new(:country_id => "107", :name => "Balangir", :aliases => "Balangir,BalÄngÄ«r,Bolangir,BolÄngir,BalÄngÄ«r", :latitude => "20.71667", :longitude => "83.48333").save
City.new(:country_id => "107", :name => "Balaghat", :aliases => "Balaghat,Burha,BÄlÄghÄt,BÄlÄghÄt", :latitude => "21.8", :longitude => "80.18333").save
City.new(:country_id => "107", :name => "Balachor", :aliases => ",BÄlÄchor", :latitude => "31.06667", :longitude => "76.31667").save
City.new(:country_id => "107", :name => "Bakhtiyarpur", :aliases => ",BakhtiyÄrpur", :latitude => "25.46667", :longitude => "85.51667").save
City.new(:country_id => "107", :name => "Baj Baj", :aliases => "Baj Baj,Budge Budge,Baj Baj", :latitude => "22.47472", :longitude => "88.17028").save
City.new(:country_id => "107", :name => "Bairagnia", :aliases => ",BairÄgnia", :latitude => "26.75", :longitude => "85.28333").save
City.new(:country_id => "107", :name => "Baindur", :aliases => "Baindur,Bainduri,BaindÅ«r,BaindÅ«ri,Byndoor,Baindur", :latitude => "13.86667", :longitude => "74.63333").save
City.new(:country_id => "107", :name => "Bail Hongal", :aliases => ",Bail Hongal", :latitude => "15.81667", :longitude => "74.86667").save
City.new(:country_id => "107", :name => "Baihar", :aliases => "Baihar,Baihar", :latitude => "22.1", :longitude => "80.55").save
City.new(:country_id => "107", :name => "Baidyabati", :aliases => "Baidyabati,BaidyabÄti,BaidyabÄti", :latitude => "22.785", :longitude => "88.32472").save
City.new(:country_id => "107", :name => "Bahraich", :aliases => "Bahraich,Bahraich", :latitude => "27.58333", :longitude => "81.6").save
City.new(:country_id => "107", :name => "Bahjoi", :aliases => "Bahjoi,Bhajoi,Bahjoi", :latitude => "28.4", :longitude => "78.61667").save
City.new(:country_id => "107", :name => "Baheri", :aliases => "Baheri,Baheri", :latitude => "28.78333", :longitude => "79.5").save
City.new(:country_id => "107", :name => "Baharampur", :aliases => "Baharampur,Bahrampur,BahrÄmpur,Berhampore,Baharampur", :latitude => "24.1", :longitude => "88.25").save
City.new(:country_id => "107", :name => "Bahadurgarh", :aliases => "Bahadurgarh,BahÄdurgarh,BahÄdurgarh", :latitude => "28.68333", :longitude => "76.91667").save
City.new(:country_id => "107", :name => "Bahadurganj", :aliases => "Bahadurganj,BahÄdurganj,BahÄdurganj", :latitude => "26.26667", :longitude => "87.81667").save
City.new(:country_id => "107", :name => "Bah", :aliases => "Bah,BÄh,BÄh", :latitude => "26.87", :longitude => "78.5975").save
City.new(:country_id => "107", :name => "Bagula", :aliases => ",BagulÄ", :latitude => "23.31667", :longitude => "88.65").save
City.new(:country_id => "107", :name => "Baghpat", :aliases => "Baghpat,Bagpat,BÄghpat,BÄghpat", :latitude => "28.95", :longitude => "77.21667").save
City.new(:country_id => "107", :name => "Baghdogra", :aliases => "Bagdogra,Baghdogra,BÄghdogra,BÄghdogra", :latitude => "26.7", :longitude => "88.31667").save
City.new(:country_id => "107", :name => "Bagha Purana", :aliases => "Bagha Purana,Baghaparana,BÄgha PurÄna,BÄgha PurÄna", :latitude => "30.68333", :longitude => "75.1").save
City.new(:country_id => "107", :name => "Bagepalli", :aliases => "Bagepalli,BÄgepalli,BÄgepalli", :latitude => "13.78472", :longitude => "77.79306").save
City.new(:country_id => "107", :name => "Bagasra", :aliases => "Bagasara,Bagasra,Bagasra", :latitude => "21.48333", :longitude => "70.95").save
City.new(:country_id => "107", :name => "Bagar", :aliases => ",Bagar", :latitude => "28.1874", :longitude => "75.5005").save
City.new(:country_id => "107", :name => "Bagalkot", :aliases => "Bagalkot,BÄgalkot,BÄgalkot", :latitude => "16.18333", :longitude => "75.7").save
City.new(:country_id => "107", :name => "Bagaha", :aliases => ",Bagaha", :latitude => "27.1", :longitude => "84.08333").save
City.new(:country_id => "107", :name => "Badvel", :aliases => "Badvel,Badvel", :latitude => "14.75", :longitude => "79.05").save
City.new(:country_id => "107", :name => "Baduria", :aliases => "Baduria,Badurii,BadÅ«ria,ÐÐ°Ð´ÑÑÐ¸Ð¸,BadÅ«ria", :latitude => "22.74167", :longitude => "88.78583").save
City.new(:country_id => "107", :name => "Badnawar", :aliases => "Badnawar,BadnÄwar,BadnÄwar", :latitude => "23.01667", :longitude => "75.21667").save
City.new(:country_id => "107", :name => "Badlapur", :aliases => "Badlapur,Badlapur", :latitude => "19.15", :longitude => "73.26667").save
City.new(:country_id => "107", :name => "Badami", :aliases => "Badami,ÐÐ°Ð´Ð°Ð¼Ð¸,BÄdÄmi", :latitude => "15.91495", :longitude => "75.67683").save
City.new(:country_id => "107", :name => "Badagara", :aliases => ",Badagara", :latitude => "11.6", :longitude => "75.58333").save
City.new(:country_id => "107", :name => "Bada Barabil", :aliases => "Bada Barabil,Bada BarabÄ«l,Barabil,Bada BarabÄ«l", :latitude => "22.11667", :longitude => "85.4").save
City.new(:country_id => "107", :name => "Bachhraon", :aliases => "Bachhraon,Bachhraon", :latitude => "28.93333", :longitude => "78.21667").save
City.new(:country_id => "107", :name => "Babrala", :aliases => "Babrala,BabrÄla,BabrÄla", :latitude => "28.26667", :longitude => "78.4").save
City.new(:country_id => "107", :name => "Babra", :aliases => ",BÄbra", :latitude => "21.85", :longitude => "71.3").save
City.new(:country_id => "107", :name => "Babina", :aliases => "Babina,BabÄ«na,ÐÐ°Ð±Ð¸Ð½Ð°,BabÄ«na", :latitude => "25.25", :longitude => "78.46667").save
City.new(:country_id => "107", :name => "Baberu", :aliases => "Baberu,Baberu", :latitude => "25.55", :longitude => "80.71667").save
City.new(:country_id => "107", :name => "Babai", :aliases => "Babai,BÄbai,BÄbai", :latitude => "22.7", :longitude => "77.93333").save
City.new(:country_id => "107", :name => "Azamgarh", :aliases => ",Äzamgarh", :latitude => "26.06", :longitude => "83.18611").save
City.new(:country_id => "107", :name => "Ayodhya", :aliases => "Ajodhya,Ajodkh'e,Ayodhya,Oudh,a yue ti ya,ayodhya,ayodhye,ayotti,ÐÐ¹Ð¾Ð´ÑÑÐµ,à¤à¤¯à¥à¤§à¥à¤¯à¤¾,à¦à¦¯à§à¦§à§à¦¯à¦¾,à®à®¯à¯à®¤à¯à®¤à®¿,à²à²¯à³à²§à³à²¯à³,é¿çº¦æäº,Ayodhya", :latitude => "26.8", :longitude => "82.2").save
City.new(:country_id => "107", :name => "Ayakkudi", :aliases => "Ayakkudi,Ayakudi,Palaiya Ayakkudi,Ayakkudi", :latitude => "10.45", :longitude => "77.55").save
City.new(:country_id => "107", :name => "Avanigadda", :aliases => ",Avanigadda", :latitude => "16.02148", :longitude => "80.91808").save
City.new(:country_id => "107", :name => "Avanashi", :aliases => "Avanashi,AvanÄshi,AvanÄshi", :latitude => "11.2", :longitude => "77.28333").save
City.new(:country_id => "107", :name => "Avadi", :aliases => "Avadi,Ävadi,ÐÐ²Ð°Ð´Ð¸,Ävadi", :latitude => "13.11556", :longitude => "80.10167").save
City.new(:country_id => "107", :name => "Ausa", :aliases => "Ausa,Ausa", :latitude => "18.25", :longitude => "76.5").save
City.new(:country_id => "107", :name => "Aurangabad", :aliases => ",AurangÄbÄd", :latitude => "24.75", :longitude => "84.36667").save
City.new(:country_id => "107", :name => "Aurangabad", :aliases => "Aurangabad,Aurangabad - aurangabada,Aurangabad - à¤à¤°à¤à¤à¤¾à¤¬à¤¾à¤¦,Aurangabadas,AurangÃ¢bÃ¢d,AurangÄbÄd,a'orangabada,a'urangabada,aurangabada,aurangabada sahara,aurangabado,ÐÑÑÐ°Ð½Ð³Ð°Ð±Ð°Ð´,à¤à¤°à¤à¤à¤¾à¤¬à¤¾à¤¦,à¤à¤°à¤à¤à¤¾à¤¬à¤¾à¤¦ à¤¶à¤¹à¤°,à¦à¦à¦°à¦à§à¦à¦¾à¦¬à¦¾à¦¦,à¦à¦à¦°à¦à§à¦à¦¾à¦¬à¦¾à¦¦,ã¢ã¦ã©ã³ã¬ã¼ãã¼ã,AurangÄbÄd", :latitude => "19.88333", :longitude => "75.33333").save
City.new(:country_id => "107", :name => "Auraiya", :aliases => "Auraiya,Etawah,Auraiya", :latitude => "26.46667", :longitude => "79.51667").save
City.new(:country_id => "107", :name => "Aurad", :aliases => "Aurad,AurÄd,AurÄd", :latitude => "18.25", :longitude => "77.43333").save
City.new(:country_id => "107", :name => "Attur", :aliases => "Attur,Atur-Salem,ÄttÅ«r,ÄttÅ«r", :latitude => "11.6", :longitude => "78.61667").save
City.new(:country_id => "107", :name => "Attingal", :aliases => "Attingal,Attungal,Attingal", :latitude => "8.68333", :longitude => "76.83333").save
City.new(:country_id => "107", :name => "Atrauli", :aliases => "Aligarh,Atrauli,Atrauli", :latitude => "28.03333", :longitude => "78.28333").save
City.new(:country_id => "107", :name => "Atmakur", :aliases => ",AtmakÅ«r", :latitude => "15.88333", :longitude => "78.58333").save
City.new(:country_id => "107", :name => "Atirampattinam", :aliases => "Adirampatnam,Adirampattinam,AdirÄmpatnam,Atirampattinam,AtirÄmpattinam,Attirampattinam,AtirÄmpattinam", :latitude => "10.35", :longitude => "79.4").save
City.new(:country_id => "107", :name => "Athni", :aliases => ",Athni", :latitude => "16.73333", :longitude => "75.06667").save
City.new(:country_id => "107", :name => "Athagarh", :aliases => "Athagarh,Athgarh,Äthagarh,Äthagarh", :latitude => "20.53333", :longitude => "85.61667").save
City.new(:country_id => "107", :name => "Atarra", :aliases => "Atarra,Atarra Buzurg,Atarra", :latitude => "25.28333", :longitude => "80.56667").save
City.new(:country_id => "107", :name => "Asind", :aliases => "Asind,Äsind,Äsind", :latitude => "25.73333", :longitude => "74.33333").save
City.new(:country_id => "107", :name => "Asika", :aliases => "Asika,Aska,Äsika,Äsika", :latitude => "19.6", :longitude => "84.65").save
City.new(:country_id => "107", :name => "Asifabad", :aliases => "Asafabad,Asifabad,AsifÄbÄd,Jangaon,AsifÄbÄd", :latitude => "19.36667", :longitude => "79.28333").save
City.new(:country_id => "107", :name => "Ashta", :aliases => "Ashta,ÐÑÑÐ°,Ashta", :latitude => "23.01667", :longitude => "76.71667").save
City.new(:country_id => "107", :name => "Ashta", :aliases => "Ashta,Satara,ÐÑÑÐ°,Ashta", :latitude => "16.95", :longitude => "74.4").save
City.new(:country_id => "107", :name => "Ashoknagar", :aliases => "Ashoknagar,Pachhar,Ashoknagar", :latitude => "24.56667", :longitude => "77.71667").save
City.new(:country_id => "107", :name => "Asansol", :aliases => "Asanol,Asansol,asanasola,asansoru,Äsansol,ÐÑÐ°Ð½ÑÐ¾Ð»,à¤à¤¸à¤¨à¤¸à¥à¤²,à¦à¦¸à¦¾à¦¨à¦¸à§à¦²,ã¢ãµã³ã½ã«,Äsansol", :latitude => "23.68333", :longitude => "86.98333").save
City.new(:country_id => "107", :name => "Asandh", :aliases => ",Asandh", :latitude => "29.51667", :longitude => "76.6").save
City.new(:country_id => "107", :name => "Arvi", :aliases => ",Arvi", :latitude => "20.98333", :longitude => "78.23333").save
City.new(:country_id => "107", :name => "Aruppukkottai", :aliases => "Aruppukkottai,Aruppukkottai", :latitude => "9.51667", :longitude => "78.1").save
City.new(:country_id => "107", :name => "Arumuganeri", :aliases => "Arumuganeri,Arumuganeri", :latitude => "8.56667", :longitude => "78.11667").save
City.new(:country_id => "107", :name => "Arukutti", :aliases => ",Arukutti", :latitude => "9.86667", :longitude => "76.35").save
City.new(:country_id => "107", :name => "Arsikere", :aliases => "Arsikere,Arsikere", :latitude => "13.31389", :longitude => "76.25611").save
City.new(:country_id => "107", :name => "Aron", :aliases => ",Äron", :latitude => "24.38333", :longitude => "77.41667").save
City.new(:country_id => "107", :name => "Arkalgud", :aliases => "Arkalgud,ArkalgÅ«d,ArkalgÅ«d", :latitude => "12.765", :longitude => "76.05694").save
City.new(:country_id => "107", :name => "Ariyalur", :aliases => ",AriyalÅ«r", :latitude => "11.13333", :longitude => "79.08333").save
City.new(:country_id => "107", :name => "Arcot", :aliases => "Arcot,Arkota,ÐÑÐºÐ¾ÑÐ°,Arcot", :latitude => "12.9", :longitude => "79.33333").save
City.new(:country_id => "107", :name => "Araria", :aliases => "Araria,Ararija,ArÄria,ÐÑÐ°ÑÐ¸Ñ,ArÄria", :latitude => "26.15", :longitude => "87.51667").save
City.new(:country_id => "107", :name => "Arantangi", :aliases => "Arantangi,ArantÄngi,Arrantangy,ArantÄngi", :latitude => "10.16667", :longitude => "78.98333").save
City.new(:country_id => "107", :name => "Arani", :aliases => "Arani,Arni,Ärani,Ärani", :latitude => "12.66667", :longitude => "79.28333").save
City.new(:country_id => "107", :name => "Arangaon", :aliases => "Arangaon,Jamkhed,Ärangaon,Ärangaon", :latitude => "18.66667", :longitude => "75.18333").save
City.new(:country_id => "107", :name => "Arang", :aliases => "Arang,Arang", :latitude => "21.2", :longitude => "81.96667").save
City.new(:country_id => "107", :name => "Arambagh", :aliases => ",ArÄmbÄgh", :latitude => "22.88333", :longitude => "87.78333").save
City.new(:country_id => "107", :name => "Arakkonam", :aliases => "Arakkonam,Arkonam,Arakkonam", :latitude => "13.1", :longitude => "79.66667").save
City.new(:country_id => "107", :name => "Ara", :aliases => "Ara,Arrah,Shahabad,ÐÑÐ°,Ara", :latitude => "25.56667", :longitude => "84.66667").save
City.new(:country_id => "107", :name => "Aonla", :aliases => "Aonla,Aonla Kila,Aonla", :latitude => "28.28333", :longitude => "79.15").save
City.new(:country_id => "107", :name => "Anupshahr", :aliases => "Anupshahr,AnÅ«pshahr,AnÅ«pshahr", :latitude => "28.36667", :longitude => "78.26667").save
City.new(:country_id => "107", :name => "Anuppur", :aliases => "Anuppur,AnÅ«ppur,AnÅ«ppur", :latitude => "23.1", :longitude => "81.68333").save
City.new(:country_id => "107", :name => "Anupgarh", :aliases => "Anupgarh,AnÅ«pgarh,AnÅ«pgarh", :latitude => "29.19111", :longitude => "73.20861").save
City.new(:country_id => "107", :name => "Anta", :aliases => ",Anta", :latitude => "25.15", :longitude => "76.3").save
City.new(:country_id => "107", :name => "Anshing", :aliases => "Anshing,Ansing,Ansing (Shrungarushi Maharaj),Anshing", :latitude => "20.03333", :longitude => "77.31667").save
City.new(:country_id => "107", :name => "Annur", :aliases => "Annur,AnnÅ«r,AnnÅ«r", :latitude => "11.23333", :longitude => "77.13333").save
City.new(:country_id => "107", :name => "Annigeri", :aliases => "Annigeri,Annigeri", :latitude => "15.43333", :longitude => "75.43333").save
City.new(:country_id => "107", :name => "Ankleshwar", :aliases => "Ankleshwar,Anklesvar,Ankleshwar", :latitude => "21.6", :longitude => "73").save
City.new(:country_id => "107", :name => "Anjar", :aliases => "Andzharom,Anjar,AnjÄr,ÐÐ½Ð´Ð¶Ð°ÑÐ¾Ð¼,AnjÄr", :latitude => "23.13333", :longitude => "70.01667").save
City.new(:country_id => "107", :name => "Anjangaon", :aliases => ",Anjangaon", :latitude => "21.16306", :longitude => "77.30944").save
City.new(:country_id => "107", :name => "Anjad", :aliases => "Anjad,Anjad", :latitude => "22.03333", :longitude => "75.05").save
City.new(:country_id => "107", :name => "Angul", :aliases => "Angul,Anugul,Ungul,Angul", :latitude => "20.85", :longitude => "85.1").save
City.new(:country_id => "107", :name => "Angamali", :aliases => "Angamali,Angamally,AngamÄli,AngamÄli", :latitude => "10.2", :longitude => "76.4").save
City.new(:country_id => "107", :name => "Anekal", :aliases => "Anekal,Anekal", :latitude => "12.7", :longitude => "77.7").save
City.new(:country_id => "107", :name => "Andol", :aliases => ",Andol", :latitude => "17.81306", :longitude => "78.07722").save
City.new(:country_id => "107", :name => "Andiyur", :aliases => ",AndiyÅ«r", :latitude => "11.58333", :longitude => "77.6").save
City.new(:country_id => "107", :name => "Andippatti", :aliases => ",Ändippatti", :latitude => "9.98333", :longitude => "77.63333").save
City.new(:country_id => "107", :name => "Anantnag", :aliases => "Anantnag,AnantnÄg,Islamabad,AnantnÄg", :latitude => "33.73333", :longitude => "75.15").save
City.new(:country_id => "107", :name => "Anantapur", :aliases => "Anantapur,Anantapuramu,Anantapure,ÐÐ½Ð°Ð½ÑÐ°Ð¿ÑÑÐµ,Anantapur", :latitude => "14.68333", :longitude => "77.6").save
City.new(:country_id => "107", :name => "Anandpur Sahib", :aliases => "Anandpur,Anandpur Sahib,Anandpur SÄhib,Anandpur SÄhib", :latitude => "31.25", :longitude => "76.5").save
City.new(:country_id => "107", :name => "Anand", :aliases => "Aimand,Anand,Anaud,Änand,ÐÐ½Ð°Ð½Ð´,Änand", :latitude => "22.56667", :longitude => "72.93333").save
City.new(:country_id => "107", :name => "Anakapalle", :aliases => "Anakapalle,AnakÄpalle,AnakÄpalle", :latitude => "17.68333", :longitude => "83.01667").save
City.new(:country_id => "107", :name => "Anaimalai", :aliases => "Anaimalai,Anaimalais,Anamalai,Anaimalai", :latitude => "10.58333", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Amudalavalasa", :aliases => ",AmudÄlavalasa", :latitude => "18.41667", :longitude => "83.9").save
City.new(:country_id => "107", :name => "Amta", :aliases => ",Ämta", :latitude => "22.58", :longitude => "88.00833").save
City.new(:country_id => "107", :name => "Amroli", :aliases => ",Amroli", :latitude => "21.3", :longitude => "72.85").save
City.new(:country_id => "107", :name => "Amroha", :aliases => "Amroha,Amroha", :latitude => "28.91667", :longitude => "78.46667").save
City.new(:country_id => "107", :name => "Amritsar", :aliases => "Amritsar,Amritsar - amritasara,Amritsar - à¨à©°à¨®à©à¨°à¨¿à¨¤à¨¸à¨°,Amritsaras,amritasara,amritcar,amrtasara,amuritosaru,ÐÐ¼ÑÐ¸ÑÑÐ°Ñ,ÐÐ¼ÑÑÑÑÐ°Ñ,×××¨××¦×¨,à¤à¤®à¥à¤¤à¤¸à¤°,à¦à¦®à§à¦¤à¦¸à¦°,à¨à©°à¨®à©à¨°à¨¿à¨¤à¨¸à¨°,à®à®®à¯à®°à®¿à®¤à¯à®à®°à¯,ã¢ã ãªããµã«,Amritsar", :latitude => "31.63306", :longitude => "74.86556").save
City.new(:country_id => "107", :name => "Amreli", :aliases => "Amreli,Amreli", :latitude => "21.61667", :longitude => "71.23333").save
City.new(:country_id => "107", :name => "Amravati", :aliases => "Amaravati,Amraoti,AmraotÄ«,Amravati,AmrÄvati,AmrÄvati", :latitude => "20.93333", :longitude => "77.75").save
City.new(:country_id => "107", :name => "Amod", :aliases => "Amod,Broach,Amod", :latitude => "21.98333", :longitude => "72.9").save
City.new(:country_id => "107", :name => "Amli", :aliases => "Amli,Ämli,Ämli", :latitude => "20.28333", :longitude => "73.01667").save
City.new(:country_id => "107", :name => "Amlagora", :aliases => ",ÄmlÄgora", :latitude => "22.83333", :longitude => "87.33333").save
City.new(:country_id => "107", :name => "Amla", :aliases => ",Amla", :latitude => "21.93333", :longitude => "78.11667").save
City.new(:country_id => "107", :name => "Amet", :aliases => "Amet,Amet", :latitude => "25.3", :longitude => "73.93333").save
City.new(:country_id => "107", :name => "Ambur", :aliases => "Ambur,ÄmbÅ«r,ÄmbÅ«r", :latitude => "12.78333", :longitude => "78.7").save
City.new(:country_id => "107", :name => "Ambikapur", :aliases => "Ambikapur,AmbikÄpur,Surguja,Surquja,AmbikÄpur", :latitude => "23.11667", :longitude => "83.2").save
City.new(:country_id => "107", :name => "Ambattur", :aliases => "Ambattur,AmbattÅ«r,AmbattÅ«r", :latitude => "13.09833", :longitude => "80.16222").save
City.new(:country_id => "107", :name => "Ambasamudram", :aliases => "Ambasamudram,Ambassamudram,AmbÄsamudram,AmbÄsamudram", :latitude => "8.7", :longitude => "77.46667").save
City.new(:country_id => "107", :name => "Ambala", :aliases => "Ambala,Ambata,AmbÄla,AmbÄla", :latitude => "30.37833", :longitude => "76.78083").save
City.new(:country_id => "107", :name => "Ambajogai", :aliases => "Ambajogai,Ambe,Ambejogai,AmbÄjogÄi,Mominabad,MominÄbÄd,AmbÄjogÄi", :latitude => "18.73333", :longitude => "76.38333").save
City.new(:country_id => "107", :name => "Ambah", :aliases => "Ambah,AmbÄh,AmbÄh", :latitude => "26.7075", :longitude => "78.22611").save
City.new(:country_id => "107", :name => "Ambad", :aliases => ",Ambad", :latitude => "19.61667", :longitude => "75.8").save
City.new(:country_id => "107", :name => "Amarpur", :aliases => ",Amarpur", :latitude => "25.03333", :longitude => "86.9").save
City.new(:country_id => "107", :name => "Amarpatan", :aliases => "Amarpatan,AmarpÄtan,AmarpÄtan", :latitude => "24.31667", :longitude => "80.98333").save
City.new(:country_id => "107", :name => "Amarnath", :aliases => "Amarnath,Amarnatkh,AmarnÄth,Ambarnath,ÐÐ¼Ð°ÑÐ½Ð°ÑÑ,AmarnÄth", :latitude => "19.2", :longitude => "73.16667").save
City.new(:country_id => "107", :name => "Amalner", :aliases => ",Amalner", :latitude => "21.05", :longitude => "75.06667").save
City.new(:country_id => "107", :name => "Amalapuram", :aliases => "Amalapuram,AmalÄpuram,AmalÄpuram", :latitude => "16.58333", :longitude => "82.01667").save
City.new(:country_id => "107", :name => "Alwaye", :aliases => ",Alwaye", :latitude => "10.11667", :longitude => "76.35").save
City.new(:country_id => "107", :name => "Alwar", :aliases => "Alvar,Alvaro,Alwar,Alwar City,alaraara,Ãlvaro,ÃlwÃ¢r,ÐÐ»Ð²Ð°Ñ,à¦à¦²à§±à¦¾à¦°,Alwar", :latitude => "27.56667", :longitude => "76.6").save
City.new(:country_id => "107", :name => "Alot", :aliases => ",Alot", :latitude => "23.76667", :longitude => "75.55").save
City.new(:country_id => "107", :name => "Along", :aliases => "Along,Along", :latitude => "28.16667", :longitude => "94.76667").save
City.new(:country_id => "107", :name => "Alnavar", :aliases => "Alnavar,AlnÄvar,AlnÄvar", :latitude => "15.43333", :longitude => "74.73333").save
City.new(:country_id => "107", :name => "Almora", :aliases => "Al'mora,Almora,ÐÐ»ÑÐ¼Ð¾ÑÐ°,Almora", :latitude => "29.61667", :longitude => "79.66667").save
City.new(:country_id => "107", :name => "Alleppey", :aliases => "Alapalli,Alapolai,Alappula,Alappuzha,Alapulai,Aleppi,Allapuza,Alleppi,Aulapolai,alappula,ÐÐ»Ð°Ð¿Ð¿ÑÐ¶Ð°,à´à´²à´ªàµà´ªàµà´´,Alleppey", :latitude => "9.49004", :longitude => "76.3264").save
City.new(:country_id => "107", :name => "Allahabad", :aliases => "Alahabadas,Alla Abba Habab,Allahabad,Allahabad - ilahabada,Allahabad - à¤à¤²à¤¾à¤¹à¤¾à¤¬à¤¾à¤¦,Allakhabad,AllÃ¢hÃ¢bÃ¢d,Prayag,PrayÄg,alakapat,an la a ba de,arahabado,elahabada,ilahabada,irahabado,ÐÐ»Ð»Ð°ÑÐ°Ð±Ð°Ð´,Ø§ÙÛ Ø¢Ø¨Ø§Ø¯,à¤à¤²à¤¾à¤¹à¤¾à¤¬à¤¾à¤¦,à¦à¦²à¦¾à¦¹à¦¾à¦¬à¦¾à¦¦,à®à®²à®à®¾à®ªà®¾à®¤à¯,ã¢ã©ããã¼ã,ã¤ã©ã¼ãã¼ãã¼ã,å®æé¿å·´å¾·,AllahÄbÄd", :latitude => "25.45", :longitude => "81.85").save
City.new(:country_id => "107", :name => "Alipur", :aliases => ",AlÄ«pur", :latitude => "28.8", :longitude => "77.15").save
City.new(:country_id => "107", :name => "Aligarh", :aliases => "Aligarh,Aligarkh,AlÄ«garh,Koil,aligadha,aligara,ÐÐ»Ð¸Ð³Ð°ÑÑ,Ø¹ÙÛ Ú¯ÚÚ¾,à¤à¤²à¥à¤à¤¢,à¦à¦²à¦¿à¦à¦¡à¦¼,AlÄ«garh", :latitude => "27.88333", :longitude => "78.08333").save
City.new(:country_id => "107", :name => "Aliganj", :aliases => "Aliganj,AlÄ«ganj,AlÄ«ganj", :latitude => "27.5", :longitude => "79.18333").save
City.new(:country_id => "107", :name => "Alibag", :aliases => "Alibag,Alibagh,AlibÃ¡gh,AlÄ«bÄg,AlÄ«bÄg", :latitude => "18.64111", :longitude => "72.87917").save
City.new(:country_id => "107", :name => "Alangulam", :aliases => "Alangulam,Atangulam,Älangulam,Ätangulam,Älangulam", :latitude => "8.86667", :longitude => "77.5").save
City.new(:country_id => "107", :name => "Alangayam", :aliases => "Alangayam,ÄlangÄyam,ÄlangÄyam", :latitude => "12.6", :longitude => "78.75").save
City.new(:country_id => "107", :name => "Alandur", :aliases => "Alandoor,Alandur,Alandur", :latitude => "13.0025", :longitude => "80.20611").save
City.new(:country_id => "107", :name => "Alandi", :aliases => "Alandi,Alandi-Devachi,Alandi", :latitude => "18.66667", :longitude => "73.9").save
City.new(:country_id => "107", :name => "Aland", :aliases => "Aland,Alland,Aland", :latitude => "17.56667", :longitude => "76.56667").save
City.new(:country_id => "107", :name => "Akot", :aliases => "Akot,Akot", :latitude => "21.09639", :longitude => "77.05861").save
City.new(:country_id => "107", :name => "Akola", :aliases => "Akola,Akola", :latitude => "20.73333", :longitude => "77").save
City.new(:country_id => "107", :name => "Aklera", :aliases => "Akera,Aklera,Aklera", :latitude => "24.41667", :longitude => "76.56667").save
City.new(:country_id => "107", :name => "Akividu", :aliases => ",ÄkivÄ«du", :latitude => "16.6", :longitude => "81.38333").save
City.new(:country_id => "107", :name => "Akbarpur", :aliases => ",Akbarpur", :latitude => "26.41667", :longitude => "82.55").save
City.new(:country_id => "107", :name => "Akbarpur", :aliases => ",Akbarpur", :latitude => "26.38333", :longitude => "79.95").save
City.new(:country_id => "107", :name => "Akaltara", :aliases => "Akaltara,Akaltara", :latitude => "22.01667", :longitude => "82.43333").save
City.new(:country_id => "107", :name => "Akalkot", :aliases => ",Akalkot", :latitude => "17.53333", :longitude => "76.21667").save
City.new(:country_id => "107", :name => "Ajra", :aliases => "Ajra,Ajra", :latitude => "16.11667", :longitude => "74.2").save
City.new(:country_id => "107", :name => "Ajnala", :aliases => "Ajnala,AjnÄla,AjnÄla", :latitude => "31.8425", :longitude => "74.75889").save
City.new(:country_id => "107", :name => "Ajmer", :aliases => "Adzhmer,Adzmer,AdÅºmer,Ajmer,Ajmer City,ajamera,ajamira,ajmir,ajmyr,ÐÐ´Ð¶Ð¼ÐµÑ,Ø§Ø¬ÙÛØ±,à¤à¤à¤®à¥à¤°,à¦à¦à¦®à¦¿à¦°,à®à®à¯à®®à¯à®°à¯,Ajmer", :latitude => "26.45", :longitude => "74.63333").save
City.new(:country_id => "107", :name => "Aizawl", :aliases => "Aidzhal,Aijal,Aizal,Aizawl,Aizol,Aizwal,a'ijala,a'ijola,aizaula,aizauru,ÐÐ¸Ð´Ð¶Ð°Ð»,à¤à¤à¤à¥à¤²,à¤à¤à¤¼à¥à¤²,à¦à¦à¦à¦²,ã¢ã¤ã¶ã¦ã«,ÄÄ«zawl", :latitude => "23.73333", :longitude => "92.71667").save
City.new(:country_id => "107", :name => "Ahraura", :aliases => "Ahraura,AhraurÄ,AhraurÄ", :latitude => "25.01667", :longitude => "83.01667").save
City.new(:country_id => "107", :name => "Ahmadpur", :aliases => "Ahmadpur,Ahmedpur,Rajura,RÄjÅ«ra,Ahmadpur", :latitude => "18.7", :longitude => "76.93333").save
City.new(:country_id => "107", :name => "Ahmadnagar", :aliases => "Ahmadnagar,AhmadnÃ¢gar,Ahmednagar,ahamadanagara,ahamedanagara,ahmatnakar,ahmd ngr,Ø§Ø­ÙØ¯ ÙÚ¯Ø±,à¤à¤¹à¤®à¤¦à¤¨à¤à¤°,à¦à¦¹à¦®à§à¦¦à¦¨à¦à¦°,à®à®¹à¯à®®à®¤à¯à®¨à®à®°à¯,Ahmadnagar", :latitude => "19.08333", :longitude => "74.73333").save
City.new(:country_id => "107", :name => "Ahmadabad", :aliases => "Ahmadabad,Ahmadabado,AhmadÄbÄd,Ahmedabad,Ahmedabad - amadavada,Ahmedabad - àªàª®àª¦àª¾àªµàª¾àª¦,Akhmadabad,Akhmedabad,Amadavad,afumadabado,ahamadabada,ai ha mai da ba de,akamatapat,amadavada,ÐÑÐ¼Ð°Ð´Ð°Ð±Ð°Ð´,ÐÑÐ¼ÐµÐ´Ð°Ð±Ð°Ð´,à¤à¤¹à¤®à¤¦à¤¾à¤¬à¤¾à¤¦,àªàª®àª¦àª¾àªµàª¾àª¦,à®à®à®®à®¤à®¾à®ªà®¾à®¤à¯,ã¢ãããã¼ãã¼ã,è¾åè¿è¾¾å·´å¾·,AhmadÄbÄd", :latitude => "23.03333", :longitude => "72.61667").save
City.new(:country_id => "107", :name => "Agra", :aliases => "Agra,Agra - agara,Agra - à¤à¤à¤°à¤¾,Lungsod ng Agra,a ge la,agara,ageula,agra,agura,akra,ÃgrÃ¢,Ägra,ÐÐ³ÑÐ°,×××¨×,Ø¢Ú¯Ø±Û,à¤à¤à¤°à¤¾,à¦à¦à§à¦°à¦¾,à®à®à¯à®°à®¾,à²à²à³à²°à²¾,ã¢ã¼ã°ã©,ã¢ã¼ã°ã©ã¼,é¿æ ¼æ,ìê·¸ë¼,Ägra", :latitude => "27.18333", :longitude => "78.01667").save
City.new(:country_id => "107", :name => "Agartala", :aliases => "Agartala,Ajarthala,a jia er ta la,agaratala,agarutara,akartala,ÐÐ³Ð°ÑÑÐ°Ð»Ð°,à¤à¤à¤°à¤¤à¤²à¤¾,à¦à¦à¦°à¦¤à¦²à¦¾,à®à®à®°à¯à®¤à®²à®¾,ã¢ã¬ã«ã¿ã©,é¿å å°å¡æ,Agartala", :latitude => "23.83639", :longitude => "91.275").save
City.new(:country_id => "107", :name => "Agar", :aliases => "Agar,Agar-agar,ÐÐ³Ð°Ñ-Ð°Ð³Ð°Ñ,Agar", :latitude => "23.7", :longitude => "76.01667").save
City.new(:country_id => "107", :name => "Afzalpur", :aliases => "Afzalpur,Afzalpur", :latitude => "17.2", :longitude => "76.35").save
City.new(:country_id => "107", :name => "Afzalgarh", :aliases => "Afzalgarh,Afzalgarh", :latitude => "29.4", :longitude => "78.68333").save
City.new(:country_id => "107", :name => "Adur", :aliases => ",AdÅ«r", :latitude => "9.16667", :longitude => "76.73333").save
City.new(:country_id => "107", :name => "Adra", :aliases => "Adra,Ädra,ÐÐ´ÑÐ°,Ädra", :latitude => "23.5", :longitude => "86.66667").save
City.new(:country_id => "107", :name => "Adoni", :aliases => "Adoni,Ädoni,ÐÐ´Ð¾Ð½Ð¸,Ädoni", :latitude => "15.63333", :longitude => "77.28333").save
City.new(:country_id => "107", :name => "Adilabad", :aliases => "Adilabad,Edlabad,EdlÄbÄd,atilapat,ÄdilÄbÄd,à®à®¤à®¿à®²à®¾à®ªà®¾à®¤à¯,ÄdilÄbÄd", :latitude => "19.66667", :longitude => "78.53333").save
City.new(:country_id => "107", :name => "Addanki", :aliases => "Addanki,Addanki", :latitude => "15.81667", :longitude => "79.98333").save
City.new(:country_id => "107", :name => "Achhnera", :aliases => "Achhnera,Achnera,Achhnera", :latitude => "27.18333", :longitude => "77.76667").save
City.new(:country_id => "107", :name => "Achalpur", :aliases => "Achalpur,Ellichpur,Achalpur", :latitude => "21.25722", :longitude => "77.50861").save
City.new(:country_id => "107", :name => "Abu Road", :aliases => "Abu Road,Äbu Road,Äbu Road", :latitude => "24.48333", :longitude => "72.78333").save
City.new(:country_id => "107", :name => "Abu", :aliases => "Abu,Mount Abu,Äbu,ÐÐ±Ñ,Äbu", :latitude => "24.6", :longitude => "72.7").save
City.new(:country_id => "107", :name => "Abohar", :aliases => "Abohar,abohara,à¤à¤¬à¥à¤¹à¤°,Abohar", :latitude => "30.15", :longitude => "74.18333").save
City.new(:country_id => "107", :name => "Abhayapuri", :aliases => "Abhayapuri,AbhayÄpuri,AbhayÄpuri", :latitude => "26.33333", :longitude => "90.66667").save
City.new(:country_id => "107", :name => "Contai", :aliases => "Contai,Contai", :latitude => "21.77861", :longitude => "87.75361").save
City.new(:country_id => "107", :name => "Haldia", :aliases => "Haldia,Haldia", :latitude => "22.06046", :longitude => "88.10975").save
City.new(:country_id => "107", :name => "Srirampur", :aliases => "Srirampur,SrirÄmpur,SrirÄmpur", :latitude => "22.94889", :longitude => "88.01889").save
City.new(:country_id => "107", :name => "Dumjor", :aliases => "Domjur,Dumjor,Dumjor", :latitude => "22.64083", :longitude => "88.22028").save
City.new(:country_id => "107", :name => "Bankra", :aliases => "Bankra,Bankra", :latitude => "22.6275", :longitude => "88.29806").save
City.new(:country_id => "107", :name => "Chakapara", :aliases => "Chakapara,Chakapara", :latitude => "22.63222", :longitude => "88.34861").save
City.new(:country_id => "107", :name => "Mahiari", :aliases => "Mahiari,Mahiari", :latitude => "22.59222", :longitude => "88.23778").save
City.new(:country_id => "107", :name => "Dhulagari", :aliases => ",Dhulagari", :latitude => "22.58694", :longitude => "88.17306").save
City.new(:country_id => "107", :name => "Panchla", :aliases => "Panchla,PÄnchla,PÄnchla", :latitude => "22.54389", :longitude => "88.13806").save
City.new(:country_id => "107", :name => "Nangi", :aliases => ",Nangi", :latitude => "22.50833", :longitude => "88.21528").save
City.new(:country_id => "107", :name => "Pujali", :aliases => "Pujali,Pujali", :latitude => "22.46528", :longitude => "88.15167").save
City.new(:country_id => "107", :name => "Monoharpur", :aliases => "Monoharpur,Monoharpur", :latitude => "22.10833", :longitude => "88.07889").save
City.new(:country_id => "107", :name => "Nabagram", :aliases => "Nabagram,NabagrÄm,NabagrÄm", :latitude => "22.28806", :longitude => "88.50917").save
City.new(:country_id => "107", :name => "Soyibug", :aliases => ",SoyÄ«bug", :latitude => "34.07917", :longitude => "74.71111").save
City.new(:country_id => "107", :name => "Singapur", :aliases => ",SingÄpur", :latitude => "17.46972", :longitude => "78.1275").save
City.new(:country_id => "107", :name => "Ghatkesar", :aliases => "Ghatkesar,Ghatkesar", :latitude => "17.44944", :longitude => "78.68528").save
City.new(:country_id => "107", :name => "Vijayapura", :aliases => "Vijayapura,Vijayapura", :latitude => "13.29361", :longitude => "77.80167").save
City.new(:country_id => "107", :name => "Adampur", :aliases => "Adampur,Ädampur,Ädampur", :latitude => "31.43278", :longitude => "75.7175").save
City.new(:country_id => "107", :name => "Porur", :aliases => "Porur,Porur", :latitude => "13.03194", :longitude => "80.1575").save
City.new(:country_id => "107", :name => "Madipakkam", :aliases => ",Madipakkam", :latitude => "12.9725", :longitude => "80.20917").save
City.new(:country_id => "107", :name => "Perungudi", :aliases => "Perungudi,Perungudi", :latitude => "12.97139", :longitude => "80.24722").save
City.new(:country_id => "107", :name => "Madambakkam", :aliases => "Madambakkam,Madambakkam", :latitude => "12.8525", :longitude => "80.04667").save
City.new(:country_id => "107", :name => "Powai", :aliases => ",Powai", :latitude => "19.1164", :longitude => "72.90471").save
City.new(:country_id => "107", :name => "Murudeshwara", :aliases => "Murudeshvara,ÐÑÑÑÐ´ÐµÑÐ²Ð°ÑÐ°,Murudeshwara", :latitude => "14.0943", :longitude => "74.4845").save
City.new(:country_id => "107", :name => "Shivaji Nagar", :aliases => ",Shivaji Nagar", :latitude => "18.53017", :longitude => "73.85263").save
City.new(:country_id => "107", :name => "Mohali", :aliases => ",Mohali", :latitude => "30.67995", :longitude => "76.72211").save
City.new(:country_id => "107", :name => "Pithampur", :aliases => ",Pithampur", :latitude => "22.60197", :longitude => "75.69649").save
City.new(:country_id => "107", :name => "Barbil", :aliases => ",Barbil", :latitude => "21.65685", :longitude => "85.64349").save
City.new(:country_id => "107", :name => "Airoli", :aliases => ",Airoli", :latitude => "19.15096", :longitude => "72.99625").save
City.new(:country_id => "107", :name => "Aluva", :aliases => ",Aluva", :latitude => "10.10764", :longitude => "76.35158").save
City.new(:country_id => "107", :name => "Kotputli", :aliases => ",Kotputli", :latitude => "27.70148", :longitude => "76.19917").save
City.new(:country_id => "107", :name => "Kotkapura", :aliases => ",Kotkapura", :latitude => "30.5819", :longitude => "74.83298").save
City.new(:country_id => "107", :name => "Muvattupuzha", :aliases => ",Muvattupuzha", :latitude => "9.97985", :longitude => "76.57381").save
City.new(:country_id => "107", :name => "Perumbavoor", :aliases => ",Perumbavoor", :latitude => "10.10695", :longitude => "76.47366").save
City.new(:country_id => "107", :name => "Gummidipoondi", :aliases => ",Gummidipoondi", :latitude => "13.40665", :longitude => "80.1238").save
City.new(:country_id => "107", :name => "Vapi", :aliases => "Wapi,WÄpi,Vapi", :latitude => "20.37175", :longitude => "72.90493").save
City.new(:country_id => "107", :name => "Baddi", :aliases => ",Baddi", :latitude => "30.95783", :longitude => "76.79136").save
City.new(:country_id => "107", :name => "Noida", :aliases => "Naveen,New Okhla Industrial Development Authority,Noida", :latitude => "28.58", :longitude => "77.33").save
City.new(:country_id => "107", :name => "Bhiwadi", :aliases => ",Bhiwadi", :latitude => "28.21024", :longitude => "76.86056").save
City.new(:country_id => "107", :name => "Mandideep", :aliases => "Manideep,Mandideep", :latitude => "23.08166", :longitude => "77.53328").save
City.new(:country_id => "107", :name => "Singrauli", :aliases => ",Singrauli", :latitude => "24.19973", :longitude => "82.67535").save
City.new(:country_id => "107", :name => "Birpara", :aliases => ",Birpara", :latitude => "26.70421", :longitude => "89.14547").save
City.new(:country_id => "107", :name => "Jaigaon", :aliases => ",Jaigaon", :latitude => "26.84766", :longitude => "89.37558").save
City.new(:country_id => "107", :name => "Akkarampalle", :aliases => ",Akkarampalle", :latitude => "13.65", :longitude => "79.42").save
City.new(:country_id => "107", :name => "Bellampalli", :aliases => ",Bellampalli", :latitude => "19.05577", :longitude => "79.493").save
City.new(:country_id => "107", :name => "Chemmumiahpet", :aliases => ",Chemmumiahpet", :latitude => "15.89794", :longitude => "79.32129").save
City.new(:country_id => "107", :name => "Gaddi Annaram", :aliases => "Gaddi Annaram,Gaddiannaram,Gaddi Annaram", :latitude => "17.36687", :longitude => "78.5242").save
City.new(:country_id => "107", :name => "Dasnapur", :aliases => ",Dasnapur", :latitude => "19.65399", :longitude => "78.51213").save
City.new(:country_id => "107", :name => "Kanuru", :aliases => ",Kanuru", :latitude => "16.28584", :longitude => "81.25464").save
City.new(:country_id => "107", :name => "Lal Bahadur Nagar", :aliases => "L.B.Nagar,Lal Bahadur Nagar,Lalbahadur Nagar,Lal Bahadur Nagar", :latitude => "17.34769", :longitude => "78.55757").save
City.new(:country_id => "107", :name => "Malkajgiri", :aliases => ",Malkajgiri", :latitude => "17.44781", :longitude => "78.52633").save
City.new(:country_id => "107", :name => "Mandamarri", :aliases => ",Mandamarri", :latitude => "18.96506", :longitude => "79.47475").save
City.new(:country_id => "107", :name => "Chinnachowk", :aliases => "Chinna Chowk,Chinnachowk,Chinnachowk", :latitude => "14.47516", :longitude => "78.8354").save
City.new(:country_id => "107", :name => "Kyathampalle", :aliases => ",Kyathampalle", :latitude => "19.66781", :longitude => "78.5289").save
City.new(:country_id => "107", :name => "Gajuwaka", :aliases => ",Gajuwaka", :latitude => "17.7", :longitude => "83.21667").save
City.new(:country_id => "107", :name => "Manuguru", :aliases => "Manugur,Manuguru,Manuguru", :latitude => "17.98102", :longitude => "80.7547").save
City.new(:country_id => "107", :name => "Kalyandurg", :aliases => "Kalyandrug,Kalyandurg,KalyÄndrug,kalyandurg,kalyÄndurg,Kalyandurg", :latitude => "14.54519", :longitude => "77.10552").save
City.new(:country_id => "107", :name => "Ponnur", :aliases => ",Ponnur", :latitude => "16.07114", :longitude => "80.54944").save
City.new(:country_id => "107", :name => "Quthbullapur", :aliases => "Quthbullapur,Qutubullapur,Quthbullapur", :latitude => "17.50107", :longitude => "78.45818").save
City.new(:country_id => "107", :name => "Ramanayyapeta", :aliases => ",Ramanayyapeta", :latitude => "16.94516", :longitude => "82.2385").save
City.new(:country_id => "107", :name => "Palwancha", :aliases => "Paloncha,Palwancha,Palwancha", :latitude => "17.58152", :longitude => "80.67651").save
City.new(:country_id => "107", :name => "Barpeta Road", :aliases => ",Barpeta Road", :latitude => "26.50284", :longitude => "90.96937").save
City.new(:country_id => "107", :name => "Sathupalli", :aliases => ",Sathupalli", :latitude => "17.24968", :longitude => "80.86899").save
City.new(:country_id => "107", :name => "Yanamalakuduru", :aliases => "Yanamalakuduru,Yenamalakuduru,Yanamalakuduru", :latitude => "16.48531", :longitude => "80.66746").save
City.new(:country_id => "107", :name => "Marigaon", :aliases => ",Marigaon", :latitude => "26.37957", :longitude => "92.34146").save
City.new(:country_id => "107", :name => "Naharlagun", :aliases => ",Naharlagun", :latitude => "27.10467", :longitude => "93.69518").save
City.new(:country_id => "107", :name => "Serilingampalle", :aliases => "Serilingampalle,Serilingampally,Serilingampalle", :latitude => "17.49313", :longitude => "78.30196").save
City.new(:country_id => "107", :name => "Silapathar", :aliases => ",Silapathar", :latitude => "26.20597", :longitude => "93.80951").save
City.new(:country_id => "107", :name => "Lumding Railway Colony", :aliases => "Kumding,Lumding,Lumding Railway Colony,Lumding Railway Colony", :latitude => "25.74903", :longitude => "93.16998").save
City.new(:country_id => "107", :name => "Aistala", :aliases => ",Aistala", :latitude => "23.18", :longitude => "88.58").save
City.new(:country_id => "107", :name => "Ashoknagar Kalyangarh", :aliases => ",Ashoknagar Kalyangarh", :latitude => "22.86416", :longitude => "88.63701").save
City.new(:country_id => "107", :name => "Bahula", :aliases => ",Bahula", :latitude => "23.65176", :longitude => "87.16475").save
City.new(:country_id => "107", :name => "Zira", :aliases => ",Zira", :latitude => "30.96853", :longitude => "74.99106").save
