City.new(:country_id => "154", :name => "Plymouth", :aliases => "Plymouth,Plymouth", :latitude => "16.70555", :longitude => "-62.21292").save
City.new(:country_id => "154", :name => "Brades", :aliases => ",Brades", :latitude => "16.79183", :longitude => "-62.21058").save
