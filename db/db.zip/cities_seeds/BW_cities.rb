City.new(:country_id => "36", :name => "Tonota", :aliases => "Tonota,Tonoto,Tonota", :latitude => "-21.48333", :longitude => "27.48333").save
City.new(:country_id => "36", :name => "Thamaga", :aliases => "Thamaga,Thamaga", :latitude => "-24.71667", :longitude => "25.53333").save
City.new(:country_id => "36", :name => "Serowe", :aliases => "Serova,Serowe,Ð¡ÐµÑÐ¾Ð²Ð°,Serowe", :latitude => "-22.38333", :longitude => "26.71667").save
City.new(:country_id => "36", :name => "Selebi-Phikwe", :aliases => "Phikwe,Pikwe,Pikwe-Selibe,Selebi,Selebi-Phikwe,Selebi-Pikwe,Selibe,Selibe-Phikwe,Selibe-Pikwe Mine Lease Area,Selebi-Phikwe", :latitude => "-21.97903", :longitude => "27.84983").save
City.new(:country_id => "36", :name => "Ramotswa", :aliases => "Ramotswa,Ramoutsa,Ramotswa", :latitude => "-24.86667", :longitude => "25.81667").save
City.new(:country_id => "36", :name => "Palapye", :aliases => "Palapaye Road,Palapye,Palapye Road,Palatswe,Palapye", :latitude => "-22.55", :longitude => "27.13333").save
City.new(:country_id => "36", :name => "Mosopa", :aliases => "Moshupa,Mosopa,Mosopa", :latitude => "-24.8", :longitude => "25.38333").save
City.new(:country_id => "36", :name => "Molepolole", :aliases => "Molepolole,ÐÐ¾Ð»ÐµÐ¿Ð¾Ð»Ð¾Ð»Ðµ,Molepolole", :latitude => "-24.41667", :longitude => "25.53333").save
City.new(:country_id => "36", :name => "Mogoditshane", :aliases => "Mogoditsane,Mogoditshane,Mogoditshane", :latitude => "-24.62694", :longitude => "25.86556").save
City.new(:country_id => "36", :name => "Mochudi", :aliases => "Mochudi,Mochudi Village,ÐÐ¾ÑÑÐ´Ð¸,Mochudi", :latitude => "-24.41667", :longitude => "26.15").save
City.new(:country_id => "36", :name => "Maun", :aliases => "Maun,ÐÐ°ÑÐ½,Maun", :latitude => "-19.98333", :longitude => "23.41667").save
City.new(:country_id => "36", :name => "Mahalapye", :aliases => "Mahalapye,Mahalatswe,Mahalapye", :latitude => "-23.06667", :longitude => "26.83333").save
City.new(:country_id => "36", :name => "Lobatse", :aliases => "Lobace,Lobatse,Lobatsi,ÐÐ¾Ð±Ð°ÑÐµ,Lobatse", :latitude => "-25.21667", :longitude => "25.66667").save
City.new(:country_id => "36", :name => "Letlhakane", :aliases => "Lethakane,Letlhakane,Letlhakawe,Letlhakane", :latitude => "-21.41667", :longitude => "25.58333").save
City.new(:country_id => "36", :name => "Kanye", :aliases => "Kanye,Kanye", :latitude => "-24.98333", :longitude => "25.35").save
City.new(:country_id => "36", :name => "Janeng", :aliases => ",Janeng", :latitude => "-25.41667", :longitude => "25.55").save
City.new(:country_id => "36", :name => "Gaborone", :aliases => "Gaberones,Gaberones Village,Gaboronas,Gaborone,Gaborono,Nkamporone,gabolone,gabwrwn,gbrwn,haborone,jia bai long li,ÎÎºÎ±Î¼ÏÎ¿ÏÏÎ½Îµ,ÐÐ°Ð±Ð¾ÑÐ¾Ð½Ðµ,×××××¨××,Ú¯Ø§Ø¨ÙØ±ÙÙ,Ú¯Ø¨Ø±ÙÙ,áá á®á,áá¦á®á,ããã­ã¼ã,åæéé,ê°ë³´ë¡ë¤,Gaborone", :latitude => "-24.65451", :longitude => "25.90859").save
City.new(:country_id => "36", :name => "Francistown", :aliases => "Francistown,Fransistaun,Ð¤ÑÐ°Ð½ÑÐ¸ÑÑÐ°ÑÐ½,Francistown", :latitude => "-21.16667", :longitude => "27.51667").save
