City.new(:country_id => "143", :name => "Marigot", :aliases => "Marigo,Marigot,ÐÐ°ÑÐ¸Ð³Ð¾,Marigot", :latitude => "18.06667", :longitude => "-63.08333").save
