City.new(:country_id => "12", :name => "Zarate", :aliases => "General J.F. Uriburu,General Jose F. Uriburu,General JosÃ© F. Uriburu,General Uriburu,Sarate,SaratÄ,Zarate,ZÃ¡rate,ÐÐ°ÑÐ°ÑÐµ,ZÃ¡rate", :latitude => "-34.09222", :longitude => "-59.035").save
City.new(:country_id => "12", :name => "Villa Ocampo", :aliases => "Ocampo,Villa Ocampo,Villa Ocampo", :latitude => "-28.46667", :longitude => "-59.36667").save
City.new(:country_id => "12", :name => "Villaguay", :aliases => "Villaguay,Villaguay", :latitude => "-31.85", :longitude => "-59.01667").save
City.new(:country_id => "12", :name => "Villa Gesell", :aliases => "Vil'ja-Khesel',ÐÐ¸Ð»ÑÑ-Ð¥ÐµÑÐµÐ»Ñ,Villa Gesell", :latitude => "-37.26394", :longitude => "-56.97304").save
City.new(:country_id => "12", :name => "Tandil", :aliases => "Tandil,Tandil',Ð¢Ð°Ð½Ð´Ð¸Ð»Ñ,Tandil", :latitude => "-37.31667", :longitude => "-59.15").save
City.new(:country_id => "12", :name => "San Vicente", :aliases => ",San Vicente", :latitude => "-26.61667", :longitude => "-54.13333").save
City.new(:country_id => "12", :name => "Santo Tome", :aliases => "Santo Tome,Santo TomÃ©,Santo TomÃ©", :latitude => "-28.55", :longitude => "-56.05").save
City.new(:country_id => "12", :name => "Santa Elena", :aliases => "Santa Elena,Santa Elena", :latitude => "-30.95", :longitude => "-59.8").save
City.new(:country_id => "12", :name => "San Pedro", :aliases => ",San Pedro", :latitude => "-26.63333", :longitude => "-54.13333").save
City.new(:country_id => "12", :name => "San Luis del Palmar", :aliases => ",San Luis del Palmar", :latitude => "-27.51667", :longitude => "-58.56667").save
City.new(:country_id => "12", :name => "San Lorenzo", :aliases => ",San Lorenzo", :latitude => "-28.13333", :longitude => "-58.76667").save
City.new(:country_id => "12", :name => "San Javier", :aliases => ",San Javier", :latitude => "-30.58333", :longitude => "-59.95").save
City.new(:country_id => "12", :name => "Saladas", :aliases => ",Saladas", :latitude => "-28.25", :longitude => "-58.63333").save
City.new(:country_id => "12", :name => "Retiro", :aliases => "Retiro,Retiro", :latitude => "-34.58333", :longitude => "-58.38333").save
City.new(:country_id => "12", :name => "Resistencia", :aliases => "Resistencia,Resistensija,Ð ÐµÑÐ¸ÑÑÐµÐ½ÑÐ¸Ñ,Resistencia", :latitude => "-27.45", :longitude => "-58.98333").save
City.new(:country_id => "12", :name => "Reconquista", :aliases => "Reconquista,Rekonkista,Ð ÐµÐºÐ¾Ð½ÐºÐ¸ÑÑÐ°,Reconquista", :latitude => "-29.15", :longitude => "-59.65").save
City.new(:country_id => "12", :name => "Quilmes", :aliases => "Kil'mes,Quilmes,ÐÐ¸Ð»ÑÐ¼ÐµÑ,Quilmes", :latitude => "-34.72028", :longitude => "-58.26944").save
City.new(:country_id => "12", :name => "Puerto Rico", :aliases => "Libertador General San Martin,Libertador General San MartÃ­n,Puerto Libertador General San Martin,Puerto Libertador General San MartÃ­n,Puerto Rico,Puerto San Alberto,Puerto Rico", :latitude => "-26.8", :longitude => "-55.03333").save
City.new(:country_id => "12", :name => "Puerto Iguazu", :aliases => "Eva Peron,Eva PerÃ³n,Iguassu,Iguazu,IguazÃº,Puehrto-Iguasu,Puerto Aguirre,Puerto Iguazu,Puerto IguazÃº,Puerto Igvasu,ÐÑÑÑÑÐ¾-ÐÐ³ÑÐ°ÑÑ,Puerto IguazÃº", :latitude => "-25.59912", :longitude => "-54.57355").save
City.new(:country_id => "12", :name => "Puerto Esperanza", :aliases => "Esperanza,Puerto Esperanza,Puerto Esperanza", :latitude => "-26.01667", :longitude => "-54.65").save
City.new(:country_id => "12", :name => "Posadas", :aliases => "Posadas,ÐÐ¾ÑÐ°Ð´Ð°Ñ,Posadas", :latitude => "-27.38333", :longitude => "-55.88333").save
City.new(:country_id => "12", :name => "Pirane", :aliases => ",PiranÃ©", :latitude => "-25.71667", :longitude => "-59.1").save
City.new(:country_id => "12", :name => "Paso de los Libres", :aliases => "Paso de los Libres,Paso de los Libres", :latitude => "-29.71667", :longitude => "-57.08333").save
City.new(:country_id => "12", :name => "Obera", :aliases => "Obera,OberÃ¡,Yerbal Viejo,ÐÐ±ÐµÑÐ°,OberÃ¡", :latitude => "-27.48333", :longitude => "-55.13333").save
City.new(:country_id => "12", :name => "Necochea", :aliases => "Necochea,Necochea", :latitude => "-38.55", :longitude => "-58.75").save
City.new(:country_id => "12", :name => "Monte Caseros", :aliases => "Monte Caseros,Monte Caseros", :latitude => "-30.25", :longitude => "-57.65").save
City.new(:country_id => "12", :name => "Montecarlo", :aliases => "Montecarlo,Puerto Montecarlo,Montecarlo", :latitude => "-26.56667", :longitude => "-54.78333").save
City.new(:country_id => "12", :name => "Mercedes", :aliases => ",Mercedes", :latitude => "-34.65444", :longitude => "-59.43444").save
City.new(:country_id => "12", :name => "Mercedes", :aliases => "Mercedes,Mersedes,ÐÐµÑÑÐµÐ´ÐµÑ,Mercedes", :latitude => "-29.2", :longitude => "-58.08333").save
City.new(:country_id => "12", :name => "Mar del Plata", :aliases => "Mar de Plata,Mar del Plata,Mar-del'-Plata,ÐÐ°Ñ Ð´ÐµÐ» ÐÐ»Ð°ÑÐ°,ÐÐ°Ñ-Ð´ÐµÐ»Ñ-ÐÐ»Ð°ÑÐ°,ãã«ã»ãã«ã»ãã©ã¿,Mar del Plata", :latitude => "-38", :longitude => "-57.55").save
City.new(:country_id => "12", :name => "Lujan", :aliases => "Lujan,LujÃ¡n,Lukhan,ÐÑÑÐ°Ð½,LujÃ¡n", :latitude => "-34.57028", :longitude => "-59.105").save
City.new(:country_id => "12", :name => "La Plata", :aliases => "Eva Peron,Eva PerÃ³n,La Plata,La-Plata,lablata,rapurata,ÐÐ° ÐÐ»Ð°ÑÐ°,ÐÐ°-ÐÐ»Ð°ÑÐ°,ÙØ§Ø¨ÙØ§ØªØ§,ã©ãã©ã¿,La Plata", :latitude => "-34.93139", :longitude => "-57.94889").save
City.new(:country_id => "12", :name => "La Paz", :aliases => "La Paz,La Paz", :latitude => "-30.75", :longitude => "-59.65").save
City.new(:country_id => "12", :name => "Jardin America", :aliases => ",JardÃ­n AmÃ©rica", :latitude => "-27.04346", :longitude => "-55.22698").save
City.new(:country_id => "12", :name => "Gualeguaychu", :aliases => "Gualeguajchu,Gualeguaychu,GualeguaychÃº,ÐÑÐ°Ð»ÐµÐ³ÑÐ°Ð¹ÑÑ,GualeguaychÃº", :latitude => "-33.01028", :longitude => "-58.51417").save
City.new(:country_id => "12", :name => "Gualeguay", :aliases => "Gualeguay,Gualeguay", :latitude => "-33.14444", :longitude => "-59.32917").save
City.new(:country_id => "12", :name => "Goya", :aliases => "Goja,Gojja,Goya,ÐÐ¾Ð¹Ñ,Goya", :latitude => "-29.13333", :longitude => "-59.26667").save
City.new(:country_id => "12", :name => "Gobernador Ingeniero Valentin Virasoro", :aliases => "Gobernador Ingeniero Valentin Virasoro,Gobernador Ingeniero ValentÃ­n Virasoro,Vuelta del Ombu,Vuelta del OmbÃº,Gobernador Ingeniero ValentÃ­n Virasoro", :latitude => "-28.05", :longitude => "-56.03333").save
City.new(:country_id => "12", :name => "General Jose de San Martin", :aliases => "Colonia Zapallar,El Zapallar,General Jose de San Martin,General JosÃ© de San MartÃ­n,General San Martin,General San MartÃ­n,Zapallar,General JosÃ© de San MartÃ­n", :latitude => "-26.55", :longitude => "-59.35").save
City.new(:country_id => "12", :name => "Garupa", :aliases => ",GarupÃ¡", :latitude => "-27.48333", :longitude => "-55.83333").save
City.new(:country_id => "12", :name => "Formosa", :aliases => "Formosa,Formoza,Ð¤Ð¾ÑÐ¼Ð¾Ð·Ð°,Ð¤Ð¾ÑÐ¼Ð¾ÑÐ°,Formosa", :latitude => "-26.18333", :longitude => "-58.18333").save
City.new(:country_id => "12", :name => "Fontana", :aliases => ",Fontana", :latitude => "-27.41667", :longitude => "-59.03333").save
City.new(:country_id => "12", :name => "Federal", :aliases => "Federal,Villa Federal,Federal", :latitude => "-30.95", :longitude => "-58.8").save
City.new(:country_id => "12", :name => "Esquina", :aliases => ",Esquina", :latitude => "-30.01667", :longitude => "-59.53333").save
City.new(:country_id => "12", :name => "El Soberbio", :aliases => ",El Soberbio", :latitude => "-27.3", :longitude => "-54.21667").save
City.new(:country_id => "12", :name => "Dolores", :aliases => ",Dolores", :latitude => "-36.33333", :longitude => "-57.66667").save
City.new(:country_id => "12", :name => "Curuzu Cuatia", :aliases => "Curuzu Cuatia,CuruzÃº CuatiÃ¡,CuruzÃº CuatiÃ¡", :latitude => "-29.78333", :longitude => "-58.05").save
City.new(:country_id => "12", :name => "Corrientes", :aliases => "Corrientes,Korientes,Korientesas,Korrientes,kwryynts,ÐÐ¾ÑÐ¸ÐµÐ½ÑÐµÑ,ÐÐ¾ÑÑÐ¸ÐµÐ½ÑÐµÑ,ÙÙØ±ÙÙÙØªØ³,Corrientes", :latitude => "-27.46667", :longitude => "-58.83333").save
City.new(:country_id => "12", :name => "Concordia", :aliases => "Concordia,Konkordija,ÐÐ¾Ð½ÐºÐ¾ÑÐ´Ð¸Ñ,Concordia", :latitude => "-31.4", :longitude => "-58.03333").save
City.new(:country_id => "12", :name => "Concepcion del Uruguay", :aliases => "Concepcion del Uruguay,ConcepciÃ³n del Uruguay,Konseps'on-del'-Urugvaj,Konsepsion del Urugvajus,ÐÐ¾Ð½ÑÐµÐ¿ÑÑÐ¾Ð½-Ð´ÐµÐ»Ñ-Ð£ÑÑÐ³Ð²Ð°Ð¹,ConcepciÃ³n del Uruguay", :latitude => "-32.48333", :longitude => "-58.22833").save
City.new(:country_id => "12", :name => "Colegiales", :aliases => "Colegiales,Colegiales", :latitude => "-34.57365", :longitude => "-58.44924").save
City.new(:country_id => "12", :name => "Chajari", :aliases => "Chajari,ChajarÃ­,ChajarÃ­", :latitude => "-30.76667", :longitude => "-57.98333").save
City.new(:country_id => "12", :name => "Campana", :aliases => "Campana,Kampana,ÐÐ°Ð¼Ð¿Ð°Ð½Ð°,Campana", :latitude => "-34.17694", :longitude => "-58.92083").save
City.new(:country_id => "12", :name => "Buenos Aires", :aliases => "Bonaero,Bonaeropolis,BonaÃ«ropolis,Bos Aires,Bouenos Aires,Buehnos Ajres,Buehnos-Ajres,Buehnos-Ajres osh,Buenos Aires,Buenos AirÄs,Buenos Ajres,Buenos Ayres,Buenos-Ajres,Buenos-Ayres,Buenos-AÃ½res,Buenosairesa,BuÃ©nos AyrÃ©s,Bwenoze,BwÃ¨nozÃ¨,BÃºenos AÃ­res,Ciudad Autonoma de Buenos Aires,Ciudad AutÃ³noma de Buenos Aires,Gorad Buehnas-Ajrehs,Lungsod ng Buenos Aires,bawnosxires,bu yi nuo si ai li si,bu'enosa a'iresa,buenos-airesi,buenosaires,buenoseuaileseu,buenosuairesu,buraenosa a'iresa,buyenosa a'iresa,bwyns ayrs,bwynws ayrs,bwynws ayrys,byu'enosa erisa,byunas airis,byunas ayels,bywns ayrs,puvenas airis,ÎÏÎ¿ÏÎ­Î½Î¿Ï ÎAÎ¹ÏÎµÏ,ÎÏÎ¿ÏÎ­Î½Î¿Ï ÎÎ¹ÏÎµÏ,ÐÑÐµÐ½Ð¾Ñ ÐÐ¸ÑÐµÑ,ÐÑÐµÐ½Ð¾Ñ ÐÐ¹ÑÐµÑ,ÐÑÐµÐ½Ð¾Ñ ÐÑÑÐµÑ,ÐÑÐµÐ½Ð¾Ñ ÐÑÑÐµÑ,ÐÑÐµÐ½Ð¾Ñ-ÐÐ¹ÑÐµÑ,ÐÑÑÐ½Ð¾Ñ ÐÐ¹ÑÐµÑ,ÐÑÑÐ½Ð¾Ñ-ÐÐ¹ÑÐµÑ,ÐÑÑÐ½Ð¾Ñ-ÐÐ¹ÑÐµÑ Ð¾Ñ,ÐÐ¾ÑÐ°Ð´ ÐÑÑÐ½Ð°Ñ-ÐÐ¹ÑÑÑ,Ô²Õ¸ÖÕ¥Õ¶Õ¸Õ½ Ô±ÕµÖÕ¥Õ½,×××× ××¡ ××××¨×¡,×××¢× ××¡ ××××¨×¢×¡,Ø¨ÙØ¦ÙÙØ³ Ø¢ÛØ±Ø³,Ø¨ÙÙÙØ³ Ø¢ÙØ±Ø³,Ø¨ÙÙÙÙØ³ Ø§ÙØ±ÙØ³,Ø¨ÛÙÙØ³ Ø¢Ø¦Ø±Ø³,à¤¬à¥à¤à¤¨à¥à¤¸ à¤à¤à¤°à¥à¤¸,à¤¬à¥à¤¯à¥à¤à¤¨à¥à¤¸ à¤à¤°à¥à¤¸,à¦¬à§à¦¯à¦¼à§à¦¨à§à¦¸ à¦à¦à¦°à§à¦¸,à¦¬à§à§±à§à¦¨à§à¦¸ à¦à¦à¦°à§à¦¸,à®ªà¯à®µà¯à®©à®¸à¯ à®à®°à®¿à®¸à¯,à²¬à³à²¯à³à²¨à²¸à³ à²à²°à²¿à²¸à³,à´¬àµà´¯àµà´£à´¸àµ à´à´¯àµà´´àµà´¸àµ,à¸à¸±à¸§à¹à¸à¸ªà¹à¸­à¹à¸£à¸ª,à½à½´à¼à½¨à½ºà¼à½à½¼à¼à½¦à½²à¼à½¨à½¦à¼à½¢à½²à¼à½¦à½²à¼,áá£áááá¡-ááá áá¡á,á¥áááµ á á­á¬áµ,ãã¨ãã¹ã¢ã¤ã¬ã¹,å¸å®è«¾æ¯è¾å©æ¯,å¸å®è¯ºæ¯è¾å©æ¯,ë¶ìë¸ì¤ìì´ë ì¤,Buenos Aires", :latitude => "-34.61315", :longitude => "-58.37723").save
City.new(:country_id => "12", :name => "Barranqueras", :aliases => "Barranqueras,Barranqueras", :latitude => "-27.48333", :longitude => "-58.93333").save
City.new(:country_id => "12", :name => "Azul", :aliases => "Azul,ÐÐ·ÑÐ»,Azul", :latitude => "-36.78333", :longitude => "-59.85").save
City.new(:country_id => "12", :name => "Avellaneda", :aliases => "Avellaneda,Estacion Ewald,EstaciÃ³n Ewald,Avellaneda", :latitude => "-29.11667", :longitude => "-59.66667").save
City.new(:country_id => "12", :name => "Aristobulo del Valle", :aliases => ",AristÃ³bulo del Valle", :latitude => "-27.11667", :longitude => "-54.91667").save
City.new(:country_id => "12", :name => "Zapala", :aliases => "Zapala,Zapala", :latitude => "-38.9", :longitude => "-70.06667").save
City.new(:country_id => "12", :name => "Yerba Buena", :aliases => "Yerba Buena,Yerba Buena", :latitude => "-26.81667", :longitude => "-65.31667").save
City.new(:country_id => "12", :name => "Villa Regina", :aliases => ",Villa Regina", :latitude => "-39.1", :longitude => "-67.06667").save
City.new(:country_id => "12", :name => "Villa Paula de Sarmiento", :aliases => "Paula A. de Sarmiento,Villa Paula de Sarmiento,Villa Paula de Sarmiento", :latitude => "-31.48333", :longitude => "-68.56667").save
City.new(:country_id => "12", :name => "Villa Nueva", :aliases => ",Villa Nueva", :latitude => "-32.43333", :longitude => "-63.25").save
City.new(:country_id => "12", :name => "Villa Maria", :aliases => "Vilja Marija,Villa Maria,Villa MarÃ­a,Villa MarÃ­a", :latitude => "-32.41667", :longitude => "-63.25").save
City.new(:country_id => "12", :name => "Villa Dolores", :aliases => "Dolores,Villa Dolores,Villa Dolores", :latitude => "-31.93333", :longitude => "-65.2").save
City.new(:country_id => "12", :name => "Villa Constitucion", :aliases => "Villa Constitucion,Villa ConstituciÃ³n,Villa ConstituciÃ³n", :latitude => "-33.23333", :longitude => "-60.33333").save
City.new(:country_id => "12", :name => "Villa Carlos Paz", :aliases => "Karlos-Paz,Vilja Karlos Pasas,Villa Carlos Paz,ÐÐ°ÑÐ»Ð¾Ñ-ÐÐ°Ð·,Villa Carlos Paz", :latitude => "-31.4", :longitude => "-64.51667").save
City.new(:country_id => "12", :name => "Villa Angela", :aliases => ",Villa Ãngela", :latitude => "-27.58333", :longitude => "-60.71667").save
City.new(:country_id => "12", :name => "Villa Allende", :aliases => ",Villa Allende", :latitude => "-31.3", :longitude => "-64.3").save
City.new(:country_id => "12", :name => "Viedma", :aliases => "V'edma,Viedma,ÐÑÐµÐ´Ð¼Ð°,Viedma", :latitude => "-40.8", :longitude => "-63").save
City.new(:country_id => "12", :name => "Victoria", :aliases => "Viktorija,ÐÐ¸ÐºÑÐ¾ÑÐ¸Ñ,Victoria", :latitude => "-32.61841", :longitude => "-60.15478").save
City.new(:country_id => "12", :name => "Vera", :aliases => "Jobson,Vera,Vera", :latitude => "-29.46667", :longitude => "-60.21667").save
City.new(:country_id => "12", :name => "Venado Tuerto", :aliases => "Neuken,Venado Tuerto,ÐÐµÑÐºÐµÐ½,Venado Tuerto", :latitude => "-33.74972", :longitude => "-61.96694").save
City.new(:country_id => "12", :name => "Veinticinco de Mayo", :aliases => "25 de Mayo,Veinticinco de Mayo,Veinticinco de Mayo", :latitude => "-35.42806", :longitude => "-60.17417").save
City.new(:country_id => "12", :name => "Ushuaia", :aliases => "Ushuaia,Ushuaja,Ushuajja,UshuaÃ¯a,Usuaja,UÅ¡uaja,usyuaia,wu si huai ya,Ð£ÑÑÐ°Ð¹Ñ,Ð£ÑÑÐ°Ñ,×××©××××,ä¹æ¯æäº,ì°ììì´ì,Ushuaia", :latitude => "-54.8", :longitude => "-68.3").save
City.new(:country_id => "12", :name => "Unquillo", :aliases => "Unquillo,Unquillo", :latitude => "-31.23333", :longitude => "-64.31667").save
City.new(:country_id => "12", :name => "Tres Isletas", :aliases => ",Tres Isletas", :latitude => "-26.35", :longitude => "-60.43333").save
City.new(:country_id => "12", :name => "Tres Arroyos", :aliases => "Tres Arroyos,Tres Arroyos", :latitude => "-38.38333", :longitude => "-60.28333").save
City.new(:country_id => "12", :name => "Trelew", :aliases => "Trelew,Trelju,Trelew", :latitude => "-43.24895", :longitude => "-65.30505").save
City.new(:country_id => "12", :name => "Termas de Rio Hondo", :aliases => "Banos,BaÃ±os,Las Termas,Las Termas de Rio Hondo,Las Termas de RÃ­o Hondo,Termas de Rio Hondo,Termas de RÃ­o Hondo,Termas del Rio Hondo,Termas del RÃ­o Hondo,Termas de RÃ­o Hondo", :latitude => "-27.48333", :longitude => "-64.86667").save
City.new(:country_id => "12", :name => "Tartagal", :aliases => "Tartagal,Ð¢Ð°ÑÑÐ°Ð³Ð°Ð»,Tartagal", :latitude => "-22.53333", :longitude => "-63.81667").save
City.new(:country_id => "12", :name => "Tafi Viejo", :aliases => "Tafi,Tafi Viejo,TafÃ­,TafÃ­ Viejo,TafÃ­ Viejo", :latitude => "-26.73333", :longitude => "-65.26667").save
City.new(:country_id => "12", :name => "Sunchales", :aliases => "Sunchales,Sunchales", :latitude => "-30.93333", :longitude => "-61.56667").save
City.new(:country_id => "12", :name => "Santo Tome", :aliases => "Santo Tome,Santo TomÃ©,Santo TomÃ©", :latitude => "-31.66667", :longitude => "-60.76667").save
City.new(:country_id => "12", :name => "Santiago del Estero", :aliases => "Sant'jago-del'-Ehstero,Santiago del Estero,Santjago del Esteras,Ð¡Ð°Ð½ÑÑÑÐ³Ð¾-Ð´ÐµÐ»Ñ-Ð­ÑÑÐµÑÐ¾,Santiago del Estero", :latitude => "-27.78333", :longitude => "-64.26667").save
City.new(:country_id => "12", :name => "Santa Rosa", :aliases => "Santa Rosa,Santa Rosa de Toay,Santa-Rosa,Ð¡Ð°Ð½ÑÐ°-Ð Ð¾ÑÐ°,Santa Rosa", :latitude => "-36.61667", :longitude => "-64.28333").save
City.new(:country_id => "12", :name => "Santa Lucia", :aliases => ",Santa LucÃ­a", :latitude => "-31.53333", :longitude => "-68.48333").save
City.new(:country_id => "12", :name => "Santa Fe de la Vera Cruz", :aliases => "Santa Fe,Santa FÄ,Santa-Fe,Ð¡Ð°Ð½ÑÐ° Ð¤Ðµ,Ð¡Ð°Ð½ÑÐ°-Ð¤Ðµ,Santa Fe de la Vera Cruz", :latitude => "-31.63333", :longitude => "-60.7").save
City.new(:country_id => "12", :name => "San Salvador de Jujuy", :aliases => "Jujuy,Khukhuj,San Sal'vador de Khukhuj,San Salvador de Jujuy,San Salvador de Khukhuj,San Salvador de Zuzujus,San Salvador de Å½uÅ¾ujus,Ð¡Ð°Ð½ Ð¡Ð°Ð»Ð²Ð°Ð´Ð¾Ñ Ð´Ðµ Ð¥ÑÑÑÐ¹,Ð¡Ð°Ð½ Ð¡Ð°Ð»ÑÐ²Ð°Ð´Ð¾Ñ Ð´Ðµ Ð¥ÑÑÑÐ¹,Ð¥ÑÑÑÐ¹,San Salvador de Jujuy", :latitude => "-24.18333", :longitude => "-65.3").save
City.new(:country_id => "12", :name => "San Ramon de la Nueva Oran", :aliases => "Oran,OrÃ¡n,San Ramon de la Nueva Oran,San RamÃ³n de la Nueva OrÃ¡n,San RamÃ³n de la Nueva OrÃ¡n", :latitude => "-23.13223", :longitude => "-64.32598").save
City.new(:country_id => "12", :name => "San Rafael", :aliases => "San Rafael,San Rafael", :latitude => "-34.6", :longitude => "-68.33333").save
City.new(:country_id => "12", :name => "San Pedro", :aliases => ",San Pedro", :latitude => "-24.23333", :longitude => "-64.86667").save
City.new(:country_id => "12", :name => "San Nicolas de los Arroyos", :aliases => "San Nicolas,San Nicolas de los Arroyos,San NicolÃ¡s,San NicolÃ¡s de los Arroyos,San Nikolasas,San NicolÃ¡s de los Arroyos", :latitude => "-33.33028", :longitude => "-60.22694").save
City.new(:country_id => "12", :name => "San Miguel de Tucuman", :aliases => "San Miguel de Tucuman,San Miguel de TucumÃ¡n,Tucuman,TucumÃ¡n,Tukuman,Tukumanas,Ð¢ÑÐºÑÐ¼Ð°Ð½,ãµã³ã»ãã²ã«ã»ãã»ãã¥ã¯ãã³,San Miguel de TucumÃ¡n", :latitude => "-26.81667", :longitude => "-65.21667").save
City.new(:country_id => "12", :name => "San Martin de los Andes", :aliases => "San Martin de los Andes,San MartÃ­n de los Andes,San-Martin-De-Los-Andes,Ð¡Ð°Ð½-ÐÐ°ÑÑÐ¸Ð½-ÐÐµ-ÐÐ¾Ñ-ÐÐ½Ð´ÐµÑ,San MartÃ­n de los Andes", :latitude => "-40.16038", :longitude => "-71.34865").save
City.new(:country_id => "12", :name => "San Martin", :aliases => "General San Martin,General San MartÃ­n,San Martin,San MartÃ­n,San MartÃ­n", :latitude => "-33.06667", :longitude => "-68.46667").save
City.new(:country_id => "12", :name => "San Luis", :aliases => "San Luis,San Luisas,Ð¡Ð°Ð½ ÐÑÐ¸Ñ,San Luis", :latitude => "-33.3", :longitude => "-66.35").save
City.new(:country_id => "12", :name => "San Justo", :aliases => ",San Justo", :latitude => "-30.78333", :longitude => "-60.58333").save
City.new(:country_id => "12", :name => "San Juan", :aliases => "San Chuanas,San Juan,San Juan", :latitude => "-31.5375", :longitude => "-68.53639").save
City.new(:country_id => "12", :name => "San Jose de Jachal", :aliases => "Jachal,JÃ¡chal,San Jose de Jachal,San JosÃ© de JÃ¡chal,San JosÃ© de JÃ¡chal", :latitude => "-30.2425", :longitude => "-68.74583").save
City.new(:country_id => "12", :name => "San Jorge", :aliases => ",San Jorge", :latitude => "-31.9", :longitude => "-61.86667").save
City.new(:country_id => "12", :name => "San Francisco", :aliases => "San Francisco,San Francisco", :latitude => "-31.43333", :longitude => "-62.08333").save
City.new(:country_id => "12", :name => "San Fernando del Valle de Catamarca", :aliases => "Catamarca,Katamarka,San Fernando del Valle de Catamarca,San Fernando del Valle de Catamarca", :latitude => "-28.46667", :longitude => "-65.78333").save
City.new(:country_id => "12", :name => "San Antonio Oeste", :aliases => "Puerto San Antonio Oeste,San Antonio Oeste,San Antonio Oeste", :latitude => "-40.73333", :longitude => "-64.93333").save
City.new(:country_id => "12", :name => "Salta", :aliases => "Ciudad de Salta,Sal'ta,Salta,Ð¡Ð°Ð»ÑÐ°,Ð¡Ð°Ð»ÑÑÐ°,×¡××××,Salta", :latitude => "-24.78333", :longitude => "-65.41667").save
City.new(:country_id => "12", :name => "Rufino", :aliases => ",Rufino", :latitude => "-34.26667", :longitude => "-62.7").save
City.new(:country_id => "12", :name => "Rosario", :aliases => "Rosarijas,Rosario,RosÃ¡rio,Rozario,rosario,rwsaryw,Ð Ð¾Ð·Ð°ÑÐ¸Ð¾,Ð Ð¾ÑÐ°ÑÐ¸Ð¾,Ø±ÙØ³Ø§Ø±ÙÙ,ã­ãµãªãª,Rosario", :latitude => "-32.95111", :longitude => "-60.66639").save
City.new(:country_id => "12", :name => "Rio Tercero", :aliases => "Rio Tercero,RÃ­o Tercero,RÃ­o Tercero", :latitude => "-32.18333", :longitude => "-64.1").save
City.new(:country_id => "12", :name => "Rio Segundo", :aliases => ",RÃ­o Segundo", :latitude => "-31.66667", :longitude => "-63.91667").save
City.new(:country_id => "12", :name => "Rio Gallegos", :aliases => "Gallegos,Puerto Gallegos,Puerto Rio Gallegos,Puerto RÃ­o Gallegos,Rio Galjegosas,Rio Gallegos,RÃ­o Gallegos,li ao jia ye ge si,éå¥¥å è¶ææ¯,RÃ­o Gallegos", :latitude => "-51.63333", :longitude => "-69.21667").save
City.new(:country_id => "12", :name => "Rio Cuarto", :aliases => "Rio Cuarto,Rio Kuartas,Rio-Kuarto,RÃ­o Cuarto,Ð Ð¸Ð¾-ÐÑÐ°ÑÑÐ¾,RÃ­o Cuarto", :latitude => "-33.13333", :longitude => "-64.35").save
City.new(:country_id => "12", :name => "Rio Ceballos", :aliases => "Rio Ceballos,Rio Zeballos,RÃ­o Ceballos,RÃ­o Zeballos,RÃ­o Ceballos", :latitude => "-31.16667", :longitude => "-64.33333").save
City.new(:country_id => "12", :name => "Rawson", :aliases => "Rawson,Rosonas,Rouson,Ð Ð¾ÑÑÐ¾Ð½,Rawson", :latitude => "-43.3", :longitude => "-65.1").save
City.new(:country_id => "12", :name => "Rafaela", :aliases => "Rafaehla,Rafaela,Ð Ð°ÑÐ°ÑÐ»Ð°,Rafaela", :latitude => "-31.26667", :longitude => "-61.48333").save
City.new(:country_id => "12", :name => "Quitilipi", :aliases => ",Quitilipi", :latitude => "-26.86667", :longitude => "-60.21667").save
City.new(:country_id => "12", :name => "Punta Alta", :aliases => "Punta Alta,Punta-Al'ta,ÐÑÐ½ÑÐ°-ÐÐ»ÑÑÐ°,Punta Alta", :latitude => "-38.88333", :longitude => "-62.08333").save
City.new(:country_id => "12", :name => "Puerto Madryn", :aliases => "Madryn,Porth Madryn,Puehrto-Madrin,Puerto Madrinas,Puerto Madryn,ÐÑÑÑÑÐ¾-ÐÐ°Ð´ÑÐ¸Ð½,Puerto Madryn", :latitude => "-42.76667", :longitude => "-65.05").save
City.new(:country_id => "12", :name => "Presidencia Roque Saenz Pena", :aliases => "Presidencia Roque Saenz Pena,Presidencia Roque SÃ¡enz PeÃ±a,Presidensija Roke Saens Penja,Presidente Roque Saenz Pena,Presidente Roque SÃ¡enz PeÃ±a,Roque Saenz Pena,Roque SÃ¡enz PeÃ±a,Presidencia Roque SÃ¡enz PeÃ±a", :latitude => "-26.78333", :longitude => "-60.45").save
City.new(:country_id => "12", :name => "Pocito", :aliases => ",Pocito", :latitude => "-31.68333", :longitude => "-68.58333").save
City.new(:country_id => "12", :name => "Plottier", :aliases => "Plottier,Plottier", :latitude => "-38.96667", :longitude => "-68.23333").save
City.new(:country_id => "12", :name => "Pergamino", :aliases => "Pergamino,ÐÐµÑÐ³Ð°Ð¼Ð¸Ð½Ð¾,Pergamino", :latitude => "-33.8925", :longitude => "-60.5725").save
City.new(:country_id => "12", :name => "Perez", :aliases => "Perez,PÃ©rez,PÃ©rez", :latitude => "-33", :longitude => "-60.76667").save
City.new(:country_id => "12", :name => "Parana", :aliases => "Parana,ParanÃ¡,ÐÐ°ÑÐ°Ð½Ð°,ParanÃ¡", :latitude => "-31.73333", :longitude => "-60.53333").save
City.new(:country_id => "12", :name => "Palpala", :aliases => ",PalpalÃ¡", :latitude => "-24.25", :longitude => "-65.2").save
City.new(:country_id => "12", :name => "Olavarria", :aliases => "Olavarria,Olavarrija,OlavarrÃ­a,ÐÐ»Ð°Ð²Ð°ÑÑÐ¸Ñ,OlavarrÃ­a", :latitude => "-36.9", :longitude => "-60.28333").save
City.new(:country_id => "12", :name => "Nueve de Julio", :aliases => "9 de Julio,Nev-de-Khulio,Nueve de Julio,ÐÐµÐ²-Ð´Ðµ-Ð¥ÑÐ»Ð¸Ð¾,Nueve de Julio", :latitude => "-35.45417", :longitude => "-60.89139").save
City.new(:country_id => "12", :name => "Neuquen", :aliases => "Nequen,Neuken,Neukenas,Neuquen,NeuquÃ©n,ÐÐµÑÐºÐµÐ½,NeuquÃ©n", :latitude => "-38.95", :longitude => "-68.06667").save
City.new(:country_id => "12", :name => "Morteros", :aliases => "Morteros,Morteros", :latitude => "-30.7", :longitude => "-62").save
City.new(:country_id => "12", :name => "Monteros", :aliases => ",Monteros", :latitude => "-27.16667", :longitude => "-65.5").save
City.new(:country_id => "12", :name => "Mendoza", :aliases => "Mendosa,Mendoza,ÐÐµÐ½Ð´Ð¾ÑÐ°,Mendoza", :latitude => "-32.88333", :longitude => "-68.81667").save
City.new(:country_id => "12", :name => "Marcos Juarez", :aliases => "Marcos Juarez,Marcos JuÃ¡rez,Marcos JuÃ¡rez", :latitude => "-32.7", :longitude => "-62.1").save
City.new(:country_id => "12", :name => "Machagai", :aliases => ",Machagai", :latitude => "-26.93333", :longitude => "-60.05").save
City.new(:country_id => "12", :name => "Lincoln", :aliases => ",Lincoln", :latitude => "-34.865", :longitude => "-61.53194").save
City.new(:country_id => "12", :name => "Libertador General San Martin", :aliases => "General San Martin,Ledesma,Libertador General San Martin,Libertador General San MartÃ­n,Libertador General San MartÃ­n", :latitude => "-23.8", :longitude => "-64.8").save
City.new(:country_id => "12", :name => "Las Brenas", :aliases => ",Las BreÃ±as", :latitude => "-27.08333", :longitude => "-61.08333").save
City.new(:country_id => "12", :name => "La Rioja", :aliases => "La Riocha,La Rioja,La-Riokha,ÐÐ°-Ð Ð¸Ð¾ÑÐ°,La Rioja", :latitude => "-29.43333", :longitude => "-66.85").save
City.new(:country_id => "12", :name => "La Falda", :aliases => "La Falda,La Falda", :latitude => "-31.08333", :longitude => "-64.5").save
City.new(:country_id => "12", :name => "La Calera", :aliases => ",La Calera", :latitude => "-31.33333", :longitude => "-64.33333").save
City.new(:country_id => "12", :name => "Laboulaye", :aliases => ",Laboulaye", :latitude => "-34.11667", :longitude => "-63.4").save
City.new(:country_id => "12", :name => "Junin", :aliases => ",JunÃ­n", :latitude => "-34.585", :longitude => "-60.95889").save
City.new(:country_id => "12", :name => "Joaquin V. Gonzalez", :aliases => "J.V. Gonzalez,J.V. GonzÃ¡lez,Joaquin V. Gonzalez,JoaquÃ­n V. GonzÃ¡lez,JoaquÃ­n V. GonzÃ¡lez", :latitude => "-25.08333", :longitude => "-64.18333").save
City.new(:country_id => "12", :name => "Jesus Maria", :aliases => "Jesus Maria,JesÃºs MarÃ­a,JesÃºs MarÃ­a", :latitude => "-30.98333", :longitude => "-64.1").save
City.new(:country_id => "12", :name => "Granadero Baigorria", :aliases => "Granadero Baigorria,Granadero Baigorrio,Paganini,Granadero Baigorria", :latitude => "-32.86667", :longitude => "-60.7").save
City.new(:country_id => "12", :name => "Gobernador Galvez", :aliases => "Galvez,Gobernador Galvez,Gobernador GÃ¡lvez,Villa Gobernador Galvez,Villa Gobernador GÃ¡lvez,Gobernador GÃ¡lvez", :latitude => "-33.03333", :longitude => "-60.63333").save
City.new(:country_id => "12", :name => "General Roca", :aliases => "Cheneral Roka,Fuerte General Roca,General Roca,Kheneral',Ð¥ÐµÐ½ÐµÑÐ°Ð»Ñ,General Roca", :latitude => "-39.03333", :longitude => "-67.58333").save
City.new(:country_id => "12", :name => "General Pinedo", :aliases => "General Pinedo,General Pinedo", :latitude => "-27.31667", :longitude => "-61.28333").save
City.new(:country_id => "12", :name => "General Pico", :aliases => "General Pico,Pico,General Pico", :latitude => "-35.66667", :longitude => "-63.73333").save
City.new(:country_id => "12", :name => "General Enrique Mosconi", :aliases => "Ciro Echesortu,General Enrique Mosconi,General Mosconi,Vespucio,General Enrique Mosconi", :latitude => "-22.6", :longitude => "-63.81667").save
City.new(:country_id => "12", :name => "Galvez", :aliases => ",GÃ¡lvez", :latitude => "-32.02833", :longitude => "-61.22222").save
City.new(:country_id => "12", :name => "Firmat", :aliases => ",Firmat", :latitude => "-33.45", :longitude => "-61.48333").save
City.new(:country_id => "12", :name => "Famailla", :aliases => ",FamaillÃ¡", :latitude => "-27.05", :longitude => "-65.4").save
City.new(:country_id => "12", :name => "Esquel", :aliases => "Esquel,Esquel", :latitude => "-42.9", :longitude => "-71.31667").save
City.new(:country_id => "12", :name => "Esperanza", :aliases => ",Esperanza", :latitude => "-31.45", :longitude => "-60.93333").save
City.new(:country_id => "12", :name => "Embarcacion", :aliases => ",EmbarcaciÃ³n", :latitude => "-23.21667", :longitude => "-64.1").save
City.new(:country_id => "12", :name => "Embalse", :aliases => "Embalse,Embalse", :latitude => "-32.18333", :longitude => "-64.41667").save
City.new(:country_id => "12", :name => "El Bolson", :aliases => "El Bolson,El BolsÃ³n,El BolsÃ³n", :latitude => "-41.96667", :longitude => "-71.51667").save
City.new(:country_id => "12", :name => "Diamante", :aliases => ",Diamante", :latitude => "-32.06444", :longitude => "-60.6425").save
City.new(:country_id => "12", :name => "Dean Funes", :aliases => "Dean Funes,DeÃ¡n Funes,DeÃ¡n Funes", :latitude => "-30.43333", :longitude => "-64.35").save
City.new(:country_id => "12", :name => "Cutral-Co", :aliases => "Cutrai-Co,Cutrai-CÃ³,Cutral-Co,Cutral-CÃ³,Eva Peron,Eva PerÃ³n,Cutral-CÃ³", :latitude => "-38.93333", :longitude => "-69.23333").save
City.new(:country_id => "12", :name => "Cruz del Eje", :aliases => "Cruz del Eje,Cruz del Eje", :latitude => "-30.73333", :longitude => "-64.8").save
City.new(:country_id => "12", :name => "Crespo", :aliases => "Crespo,Crespo", :latitude => "-32.03333", :longitude => "-60.31667").save
City.new(:country_id => "12", :name => "Cosquin", :aliases => "Cosquin,CosquÃ­n,CosquÃ­n", :latitude => "-31.25", :longitude => "-64.48333").save
City.new(:country_id => "12", :name => "Coronel Suarez", :aliases => "Coronel Suarez,Coronel SuÃ¡rez,Koronel'-Suarez,ÐÐ¾ÑÐ¾Ð½ÐµÐ»Ñ-Ð¡ÑÐ°ÑÐµÐ·,Coronel SuÃ¡rez", :latitude => "-37.46667", :longitude => "-61.91667").save
City.new(:country_id => "12", :name => "Coronda", :aliases => "Cordona,Coronda,Coronda", :latitude => "-31.96667", :longitude => "-60.91667").save
City.new(:country_id => "12", :name => "Cordoba", :aliases => "Cordoba,CÃ²rdoba,CÃ³rdoba,Kordoba,Kordobo,Kordova,ke er duo wa,korudoba,qrtbt,qwrdwbh,ÐÐ¾ÑÐ´Ð¾Ð±Ð°,ÐÐ¾ÑÐ´Ð¾Ð²Ð°,×§××¨××××,ÙØ±Ø·Ø¨Ø©,ã³ã«ãã,ç§å°å¤ç¦,CÃ³rdoba", :latitude => "-31.4", :longitude => "-64.18333").save
City.new(:country_id => "12", :name => "Comodoro Rivadavia", :aliases => ",Comodoro Rivadavia", :latitude => "-45.86667", :longitude => "-67.5").save
City.new(:country_id => "12", :name => "Cipolletti", :aliases => "Chipolletti,Cipoletti,Cipolleti,Cipolletti,Ð§Ð¸Ð¿Ð¾Ð»Ð»ÐµÑÑÐ¸,Cipolletti", :latitude => "-38.93333", :longitude => "-67.98333").save
City.new(:country_id => "12", :name => "Cinco Saltos", :aliases => "Cinco Saltos,Cinco Saltos", :latitude => "-38.81667", :longitude => "-68.06667").save
City.new(:country_id => "12", :name => "Chivilcoy", :aliases => "Chivilcoy,Chivilcoy", :latitude => "-34.90833", :longitude => "-60.03056").save
City.new(:country_id => "12", :name => "Chimbas", :aliases => ",Chimbas", :latitude => "-31.48333", :longitude => "-68.53333").save
City.new(:country_id => "12", :name => "Chilecito", :aliases => "Chilecito,Chilecito", :latitude => "-29.16667", :longitude => "-67.5").save
City.new(:country_id => "12", :name => "Charata", :aliases => "Charata,Charatas,Charata", :latitude => "-27.21667", :longitude => "-61.2").save
City.new(:country_id => "12", :name => "Chacabuco", :aliases => "Chacabuco,Chakabuko,Ð§Ð°ÐºÐ°Ð±ÑÐºÐ¾,Chacabuco", :latitude => "-34.64167", :longitude => "-60.47389").save
City.new(:country_id => "12", :name => "Centenario", :aliases => "Centenario,Colonia Centenario,Centenario", :latitude => "-38.8", :longitude => "-68.13333").save
City.new(:country_id => "12", :name => "Caucete", :aliases => "Caucete,Villa Colon,Villa ColÃ³n,Caucete", :latitude => "-31.65417", :longitude => "-68.28528").save
City.new(:country_id => "12", :name => "Catriel", :aliases => "Catriel,Catriel", :latitude => "-37.86667", :longitude => "-67.83333").save
City.new(:country_id => "12", :name => "Castelli", :aliases => "Castelli,Colonia Castelli,J.J. Castelli,Juan Jose Castelli,Juan JosÃ© Castelli,Castelli", :latitude => "-25.95", :longitude => "-60.61667").save
City.new(:country_id => "12", :name => "Casilda", :aliases => "Casilda,Casilda", :latitude => "-33.04417", :longitude => "-61.16806").save
City.new(:country_id => "12", :name => "Carcarana", :aliases => ",CarcaraÃ±Ã¡", :latitude => "-32.85", :longitude => "-61.15").save
City.new(:country_id => "12", :name => "Capitan Bermudez", :aliases => "Capitan Bermudez,CapitÃ¡n BermÃºdez,Juan Ortiz,Juan OrtÃ­z,Villa Cassini,CapitÃ¡n BermÃºdez", :latitude => "-32.81667", :longitude => "-60.71667").save
City.new(:country_id => "12", :name => "Canada de Gomez", :aliases => "Canada de Gomez,CaÃ±ada de GÃ³mez,Ciudad Evita,Ciudad de Gomez,Ciudad de GÃ³mez,Kanada-de-Gomes,ÐÐ°Ð½Ð°Ð´Ð°-Ð´Ðµ-ÐÐ¾Ð¼ÐµÑ,CaÃ±ada de GÃ³mez", :latitude => "-32.81694", :longitude => "-61.40083").save
City.new(:country_id => "12", :name => "Caleta Olivia", :aliases => ",Caleta Olivia", :latitude => "-46.43333", :longitude => "-67.53333").save
City.new(:country_id => "12", :name => "Bell Ville", :aliases => ",Bell Ville", :latitude => "-32.61667", :longitude => "-62.7").save
City.new(:country_id => "12", :name => "Bella Vista", :aliases => ",Bella Vista", :latitude => "-27.03333", :longitude => "-65.3").save
City.new(:country_id => "12", :name => "Bahia Blanca", :aliases => "Bahia Blanca,Bahija Blanka,BahÃ­a Blanca,Bajja-Blanka,bahya blanka,ÐÐ°Ð¹Ñ-ÐÐ»Ð°Ð½ÐºÐ°,Ø¨Ø§ÙÙØ§ Ø¨ÙØ§ÙÙØ§,BahÃ­a Blanca", :latitude => "-38.71667", :longitude => "-62.28333").save
City.new(:country_id => "12", :name => "Arroyo Seco", :aliases => "Aguirre,Arroyo Seco,Posta de San Martin,Posta de San MartÃ­n,Arroyo Seco", :latitude => "-33.15", :longitude => "-60.51667").save
City.new(:country_id => "12", :name => "Arroyito", :aliases => ",Arroyito", :latitude => "-31.41667", :longitude => "-63.05").save
City.new(:country_id => "12", :name => "Anatuya", :aliases => "Anatuya,AÃ±atuya,Unatuya,UÃ±atuya,AÃ±atuya", :latitude => "-28.46667", :longitude => "-62.83333").save
City.new(:country_id => "12", :name => "Alta Gracia", :aliases => "Al'ta-Gracija,Alta Gracia,ÐÐ»ÑÑÐ°-ÐÑÐ°ÑÐ¸Ñ,Alta Gracia", :latitude => "-31.66667", :longitude => "-64.43333").save
City.new(:country_id => "12", :name => "Allen", :aliases => ",Allen", :latitude => "-38.96667", :longitude => "-67.83333").save
City.new(:country_id => "12", :name => "Alderetes", :aliases => "Alderetes,Alderetes", :latitude => "-26.81667", :longitude => "-65.13333").save
City.new(:country_id => "12", :name => "Albardon", :aliases => ",AlbardÃ³n", :latitude => "-31.43722", :longitude => "-68.52556").save
City.new(:country_id => "12", :name => "Aguilares", :aliases => "Aguilares,Aguilares", :latitude => "-27.43333", :longitude => "-65.61667").save
City.new(:country_id => "12", :name => "Villa Santa Rita", :aliases => ",Villa Santa Rita", :latitude => "-34.61082", :longitude => "-58.481").save
City.new(:country_id => "12", :name => "Villa Mercedes", :aliases => ",Villa Mercedes", :latitude => "-33.67571", :longitude => "-65.45783").save
City.new(:country_id => "12", :name => "San Carlos de Bariloche", :aliases => ",San Carlos de Bariloche", :latitude => "-41.14557", :longitude => "-71.30822").save
