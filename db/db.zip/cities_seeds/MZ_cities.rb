City.new(:country_id => "161", :name => "Xai-Xai", :aliases => "Chai Chai,Joa Belo,Joao Belo,JoÃ£o Belo,Sai Sai,Shai-Shai,Vila de Joao Belo,Vila de JoÃ£o Belo,Vila-Joao-Belo,Vila-JoÃ£o-Belo,Xai Xai,Xai-Xai,shaishai,Å ai Å ai,Ð¨Ð°Ð¸-Ð¨Ð°Ð¸,ã·ã£ã¤ã·ã£ã¤,Xai-Xai", :latitude => "-25.05194", :longitude => "33.64417").save
City.new(:country_id => "161", :name => "Dondo", :aliases => "Dondo,Vila do Dondo,ÐÐ¾Ð½Ð´Ð¾,Dondo", :latitude => "-19.60944", :longitude => "34.74306").save
City.new(:country_id => "161", :name => "Macia", :aliases => "Macia,Vila de Macia,Macia", :latitude => "-25.02694", :longitude => "33.09889").save
City.new(:country_id => "161", :name => "Tete", :aliases => "Tete,Vila-de-Santiago-Maior,tai te,Ð¢ÐµÑÐµ,å¤ªç¹,Tete", :latitude => "-16.15639", :longitude => "33.58667").save
City.new(:country_id => "161", :name => "Quelimane", :aliases => "Kelimane,KelimanÄ,Quelimane,ÐÐµÐ»Ð¸Ð¼Ð°Ð½Ðµ,Quelimane", :latitude => "-17.87861", :longitude => "36.88833").save
City.new(:country_id => "161", :name => "Pemba", :aliases => "Pemba,Porto Amelia,ÐÐµÐ¼Ð±Ð°,Pemba", :latitude => "-12.97395", :longitude => "40.51775").save
City.new(:country_id => "161", :name => "Nampula", :aliases => "Nampula,ÐÐ°Ð¼Ð¿ÑÐ»Ð°,Nampula", :latitude => "-15.11646", :longitude => "39.2666").save
City.new(:country_id => "161", :name => "Cidade de Nacala", :aliases => "Cidade de Nacala,Fernao Veloso,FernÃ£o Veloso,Gorod-de-Nakala,Maaia,Maiaia,Nacala,ÐÐ¾ÑÐ¾Ð´-Ð´Ðµ-ÐÐ°ÐºÐ°Ð»Ð°,Cidade de Nacala", :latitude => "-14.54278", :longitude => "40.67278").save
City.new(:country_id => "161", :name => "Montepuez", :aliases => "Montepuez,Montepveze,Vila de Montepuez,ÐÐ¾Ð½ÑÐµÐ¿Ð²ÐµÐ·Ðµ,Montepuez", :latitude => "-13.12556", :longitude => "38.99972").save
City.new(:country_id => "161", :name => "Mocuba", :aliases => ",Mocuba", :latitude => "-16.84028", :longitude => "38.25694").save
City.new(:country_id => "161", :name => "Mocimboa", :aliases => ",MocÃ­mboa", :latitude => "-11.31667", :longitude => "40.35").save
City.new(:country_id => "161", :name => "Ilha de Mocambique", :aliases => "Ilha de Mocambique,Ilha de MoÃ§ambique,Mocambique,Mozambique,MoÃ§ambique,Ilha de MoÃ§ambique", :latitude => "-15.03417", :longitude => "40.73583").save
City.new(:country_id => "161", :name => "Maxixe", :aliases => ",Maxixe", :latitude => "-23.85972", :longitude => "35.34722").save
City.new(:country_id => "161", :name => "Matola", :aliases => "Cidade da Matola,Matola,Vila Salazar,ÐÐ°ÑÐ¾Ð»Ð°,Matola", :latitude => "-25.96222", :longitude => "32.45889").save
City.new(:country_id => "161", :name => "Maputo", :aliases => "Can Pfumo,Kapfumo,Lourenco Marques,LourenÃ§o Marques,Mabutu,Mapouto,Maputo,Maputu,ma pu tuo,maputo,maputu,mapwtw,mpwtw,ÎÎ±ÏÎ¿ÏÏÎ¿,ÐÐ°Ð¿ÑÑÑ,××¤×××,ÙØ§Ù¾ÙØªÙ,ááá¶,ããã,é©¬æ®æ,ë§í¸í¬,Maputo", :latitude => "-25.96528", :longitude => "32.58917").save
City.new(:country_id => "161", :name => "Manjacaze", :aliases => "Cheverine,Manjacaze,Vila de Manjacaze,Manjacaze", :latitude => "-24.71167", :longitude => "33.88278").save
City.new(:country_id => "161", :name => "Lichinga", :aliases => "Lichinga,Lisinga,LiÅ¡inga,Vila Cabral,li xin jia,å©æ¬£å ,Lichinga", :latitude => "-13.31278", :longitude => "35.24056").save
City.new(:country_id => "161", :name => "Inhambane", :aliases => "In'jambane,Inhambane,ÐÐ½ÑÑÐ¼Ð±Ð°Ð½Ðµ,Inhambane", :latitude => "-23.865", :longitude => "35.38333").save
City.new(:country_id => "161", :name => "Cuamba", :aliases => "Cuamba,Cuanda,Guamba,Kwamba,Mucuamba,Mukwamba,Nova Freixo,ku an ba,kua mu ba,åºå®å·´,èªå§å·´,Cuamba", :latitude => "-14.80306", :longitude => "36.53722").save
City.new(:country_id => "161", :name => "Chokwe", :aliases => "Chokue,ChokuÃ©,Chokwe,ChokwÃ©,Choque,ChÃ³kwÃ¨,Trigo Morais,Trigo de Morais,Vila Trigo de Morais,ChokwÃ©", :latitude => "-24.53333", :longitude => "32.98333").save
City.new(:country_id => "161", :name => "Chimoio", :aliases => "Chimoio,Chimoyo,Shimojo,Vila Pery,Ð¨Ð¸Ð¼Ð¾Ð¹Ð¾,Chimoio", :latitude => "-19.11639", :longitude => "33.48333").save
City.new(:country_id => "161", :name => "Chibuto", :aliases => "Chibuto,Vila do Chibuto,Chibuto", :latitude => "-24.68667", :longitude => "33.53056").save
City.new(:country_id => "161", :name => "Beira", :aliases => "Beira,Bejra,bei la,beira,ÐÐµÐ¹ÑÐ°,ãã¤ã©,è´æ,Beira", :latitude => "-19.84361", :longitude => "34.83889").save
City.new(:country_id => "161", :name => "Antonio Enes", :aliases => "Angoche,Antonio Enes,Antonio Engs,Antonio Ennes,AntÃ³nio Enes,Vila de Antonio Enes,Vila de AntÃ³nio Enes,AntÃ³nio Enes", :latitude => "-16.2325", :longitude => "39.90861").save
City.new(:country_id => "161", :name => "Mutuali", :aliases => ",MutuÃ¡li", :latitude => "-14.87056", :longitude => "37.00444").save
