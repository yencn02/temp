City.new(:country_id => "184", :name => "Aguadilla", :aliases => ",Aguadilla", :latitude => "18.42745", :longitude => "-67.15407").save
City.new(:country_id => "184", :name => "Arecibo", :aliases => ",Arecibo", :latitude => "18.47244", :longitude => "-66.71573").save
City.new(:country_id => "184", :name => "Bayamon", :aliases => "Bajamon,Bayamon,BayamÃ³n,ÐÐ°ÑÐ¼Ð¾Ð½,BayamÃ³n", :latitude => "18.39856", :longitude => "-66.15572").save
City.new(:country_id => "184", :name => "Caguas", :aliases => ",Caguas", :latitude => "18.23412", :longitude => "-66.0485").save
City.new(:country_id => "184", :name => "Candelaria", :aliases => ",Candelaria", :latitude => "18.40411", :longitude => "-66.20878").save
City.new(:country_id => "184", :name => "Carolina", :aliases => ",Carolina", :latitude => "18.38078", :longitude => "-65.95739").save
City.new(:country_id => "184", :name => "Catano", :aliases => ",CataÃ±o", :latitude => "18.44134", :longitude => "-66.11822").save
City.new(:country_id => "184", :name => "Cayey", :aliases => ",Cayey", :latitude => "18.11191", :longitude => "-66.166").save
City.new(:country_id => "184", :name => "Fajardo", :aliases => "Fakhardo,Ð¤Ð°ÑÐ°ÑÐ´Ð¾,Fajardo", :latitude => "18.32579", :longitude => "-65.65238").save
City.new(:country_id => "184", :name => "Guayama", :aliases => ",Guayama", :latitude => "17.98413", :longitude => "-66.11378").save
City.new(:country_id => "184", :name => "Guaynabo", :aliases => ",Guaynabo", :latitude => "18.35745", :longitude => "-66.111").save
City.new(:country_id => "184", :name => "Humacao", :aliases => ",Humacao", :latitude => "18.14968", :longitude => "-65.82738").save
City.new(:country_id => "184", :name => "Levittown", :aliases => ",Levittown", :latitude => "18.44995", :longitude => "-66.18156").save
City.new(:country_id => "184", :name => "Manati", :aliases => ",ManatÃ­", :latitude => "18.42745", :longitude => "-66.49212").save
City.new(:country_id => "184", :name => "Mayagueez", :aliases => ",MayagÃ¼ez", :latitude => "18.20107", :longitude => "-67.13962").save
City.new(:country_id => "184", :name => "Ponce", :aliases => "Ponce,Ponse,ÐÐ¾Ð½ÑÐµ,Ponce", :latitude => "18.01108", :longitude => "-66.61406").save
City.new(:country_id => "184", :name => "San Juan", :aliases => "San Chuanas,San Juan,San Khuan,San-Khuan,sanfuan,sanhuan,Ð¡Ð°Ð½ Ð¥ÑÐ°Ð½,Ð¡Ð°Ð½-Ð¥ÑÐ°Ð½,ãµã³ãã¢ã³,ì°íì,San Juan", :latitude => "18.46633", :longitude => "-66.10572").save
City.new(:country_id => "184", :name => "Trujillo Alto", :aliases => ",Trujillo Alto", :latitude => "18.35467", :longitude => "-66.00739").save
City.new(:country_id => "184", :name => "Vega Baja", :aliases => ",Vega Baja", :latitude => "18.44439", :longitude => "-66.38767").save
City.new(:country_id => "184", :name => "Yauco", :aliases => ",Yauco", :latitude => "18.03496", :longitude => "-66.8499").save
