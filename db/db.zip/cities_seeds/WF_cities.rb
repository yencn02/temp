City.new(:country_id => "243", :name => "Mata'utu", :aliases => "Regina Spit,MatÃ¢'utu", :latitude => "-13.28163", :longitude => "-176.17453").save
