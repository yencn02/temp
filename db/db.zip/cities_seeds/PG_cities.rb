City.new(:country_id => "178", :name => "Wewak", :aliases => "Wewak,Wewak", :latitude => "-3.55", :longitude => "143.63333").save
City.new(:country_id => "178", :name => "Port Moresby", :aliases => "Port Moresby,Port Moresmpi,Port Morsbis,Port Morzbi,Port-Morsbi,Pot Mosbi,mo er zi bi gang,poteu moseubi,potomoresubi,pwrt mwrsby,Î Î¿ÏÏ ÎÏÏÎµÏÎ¼ÏÎ¹,ÐÐ¾ÑÑ ÐÐ¾ÑÐ·Ð±Ð¸,ÐÐ¾ÑÑ-ÐÐ¾ÑÑÐ±Ð¸,×¤××¨× ×××¨×¡××,Ù¾ÙØ±Øª ÙÙØ±Ø³Ø¨Û,áá­áµ áá­áµá¢,ãã¼ãã¢ã¬ã¹ãã¼,è«å°å¹æ¯æ¸¯,í¬í¸ ëª¨ì¤ë¹,Port Moresby", :latitude => "-9.44314", :longitude => "147.17972").save
City.new(:country_id => "178", :name => "Popondetta", :aliases => "Popendetta,Popondetta,ÐÐ¾Ð¿Ð¾Ð½Ð´ÐµÑÑÐ°,Popondetta", :latitude => "-8.76667", :longitude => "148.23333").save
City.new(:country_id => "178", :name => "Mount Hagen", :aliases => "Hagen,Mount Hagen,Mount Hagen", :latitude => "-5.86667", :longitude => "144.21667").save
City.new(:country_id => "178", :name => "Mendi", :aliases => "Mendi,ÐÐµÐ½Ð´Ð¸,Mendi", :latitude => "-6.15", :longitude => "143.65").save
City.new(:country_id => "178", :name => "Madang", :aliases => "Friedrich Wilhelms Harbour,Friedrich-Wilhelmshafen,Madang,ÐÐ°Ð´Ð°Ð½Ð³,Madang", :latitude => "-5.21667", :longitude => "145.8").save
City.new(:country_id => "178", :name => "Lae", :aliases => "Lae,Laeh,ÐÐ°Ñ,Lae", :latitude => "-6.73333", :longitude => "147").save
City.new(:country_id => "178", :name => "Kokopo", :aliases => "Kokopo,Kokopo", :latitude => "-4.35", :longitude => "152.26667").save
City.new(:country_id => "178", :name => "Kimbe", :aliases => "Kimbe,Kimbe", :latitude => "-5.55", :longitude => "150.15").save
City.new(:country_id => "178", :name => "Goroka", :aliases => "Garoka,Goroka,New Garoka,Goroka", :latitude => "-6.08333", :longitude => "145.38333").save
City.new(:country_id => "178", :name => "Daru", :aliases => "Daru,Daru Government Station,Daru", :latitude => "-9.08333", :longitude => "143.2").save
City.new(:country_id => "178", :name => "Bulolo", :aliases => "Bubolo,Bulolo,Bulolo", :latitude => "-7.2", :longitude => "146.65").save
City.new(:country_id => "178", :name => "Arawa", :aliases => "Arava,Arawa,ÐÑÐ°Ð²Ð°,Arawa", :latitude => "-6.21667", :longitude => "155.55").save
