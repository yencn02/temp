City.new(:country_id => "54", :name => "Flying Fish Cove", :aliases => "Flying Fish Cove,The Settlement,Flying Fish Cove", :latitude => "-10.42172", :longitude => "105.67912").save
