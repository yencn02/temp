City.new(:country_id => "48", :name => "Yaounde", :aliases => "Giaounte,Jaunde,JaundÄ,JaÃºnde,Yaounde,YaoundÃ©,Yaunde,YaundÃ©,ya wen de,yaunde,ÎÎ¹Î±Î¿ÏÎ½ÏÎ­,ÐÐ°ÑÐ½Ð´Ðµ,Ð¯ÑÐ½Ð´Ðµ,ÕÕ¡Õ¸ÖÕ¶Õ¤Õ¥,×××× ××,á«ááá´,ã¤ã¦ã³ã,éæ¸©å¾,ì¼ì´ë°,YaoundÃ©", :latitude => "3.86667", :longitude => "11.51667").save
City.new(:country_id => "48", :name => "Yagoua", :aliases => "Jagua,JÃ¡gua,Yagoua,Yagua,Yagoua", :latitude => "10.34107", :longitude => "15.23288").save
City.new(:country_id => "48", :name => "Wum", :aliases => "Wum,Wum", :latitude => "6.38333", :longitude => "10.06667").save
City.new(:country_id => "48", :name => "Tonga", :aliases => "Lagosdorf,Tonga,Tonga's,Tongaâs,Tonga", :latitude => "4.96667", :longitude => "10.7").save
City.new(:country_id => "48", :name => "Tiko", :aliases => "Tiko,Tiko", :latitude => "4.0745", :longitude => "9.3699").save
City.new(:country_id => "48", :name => "Tibati", :aliases => ",Tibati", :latitude => "6.46667", :longitude => "12.63333").save
City.new(:country_id => "48", :name => "Tchollire", :aliases => "Cholire,CholirÃ©,Chollire,Djolere,DjolÃ©rÃ©,Jolere,Tcholere,Tcholire,TcholirÃ©,Tchollire,TchollirÃ©,TcholÃ©rÃ©,Tscholere,TchollirÃ©", :latitude => "8.4022", :longitude => "14.1698").save
City.new(:country_id => "48", :name => "Sangmelima", :aliases => "Sangmelima,Sangmelina,SangmÃ©lima,Ð¡Ð°Ð½Ð³Ð¼ÐµÐ»Ð¸Ð¼Ð°,SangmÃ©lima", :latitude => "2.93333", :longitude => "11.98333").save
City.new(:country_id => "48", :name => "Penja", :aliases => ",Penja", :latitude => "4.63911", :longitude => "9.67987").save
City.new(:country_id => "48", :name => "Obala", :aliases => "Obala,Obala", :latitude => "4.16667", :longitude => "11.53333").save
City.new(:country_id => "48", :name => "Nkoteng", :aliases => ",Nkoteng", :latitude => "4.51667", :longitude => "12.03333").save
City.new(:country_id => "48", :name => "Nkongsamba", :aliases => "Nkongsamba,Nkongsomba,ÐÐºÐ¾Ð½Ð³ÑÐ°Ð¼Ð±Ð°,Nkongsamba", :latitude => "4.9547", :longitude => "9.9404").save
City.new(:country_id => "48", :name => "Ngaoundere", :aliases => "Ngaoundere,NgaoundÃ©rÃ©,Ngaundere,NgaoundÃ©rÃ©", :latitude => "7.31667", :longitude => "13.58333").save
City.new(:country_id => "48", :name => "Nanga Eboko", :aliases => "Nanga Eboko,Nanga Eboko", :latitude => "4.68333", :longitude => "12.36667").save
City.new(:country_id => "48", :name => "Muyuka", :aliases => "Mouyouka,Muyuka,Muyuka", :latitude => "4.2898", :longitude => "9.4103").save
City.new(:country_id => "48", :name => "Mutengene", :aliases => ",Mutengene", :latitude => "4.0913", :longitude => "9.3144").save
City.new(:country_id => "48", :name => "Mora", :aliases => "Mora,More,ÐÐ¾ÑÐµ,Mora", :latitude => "11.04611", :longitude => "14.14011").save
City.new(:country_id => "48", :name => "Mokolo", :aliases => "Mokolo,Mokolo", :latitude => "10.73978", :longitude => "13.80188").save
City.new(:country_id => "48", :name => "Melong", :aliases => ",Melong", :latitude => "5.1218", :longitude => "9.96143").save
City.new(:country_id => "48", :name => "Meiganga", :aliases => "Meiganda,Meiganga,Mejgange,MeÃ¯ganga,ÐÐµÐ¹Ð³Ð°Ð½Ð³Ðµ,MeÃ¯ganga", :latitude => "6.51667", :longitude => "14.3").save
City.new(:country_id => "48", :name => "Mbouda", :aliases => "Mbouda,Mbouda", :latitude => "5.62578", :longitude => "10.25517").save
City.new(:country_id => "48", :name => "Mbanga", :aliases => "M'Bange,Mbanga,MâBangÃ©,Mbanga", :latitude => "4.5016", :longitude => "9.5671").save
City.new(:country_id => "48", :name => "Mbandjok", :aliases => "Mbandjock,Mbandjok,Mbandjok", :latitude => "4.45", :longitude => "11.9").save
City.new(:country_id => "48", :name => "Mbalmayo", :aliases => "Mbal'majo,Mbalmajo,Mbalmayo,ÐÐ±Ð°Ð»ÑÐ¼Ð°Ð¹Ð¾,Mbalmayo", :latitude => "3.51667", :longitude => "11.5").save
City.new(:country_id => "48", :name => "Maroua", :aliases => "Maroua,Marua,ÐÐ°ÑÑÐ°,Maroua", :latitude => "10.59095", :longitude => "14.31592").save
City.new(:country_id => "48", :name => "Manjo", :aliases => ",Manjo", :latitude => "4.8428", :longitude => "9.8217").save
City.new(:country_id => "48", :name => "Mamfe", :aliases => "Mamfe,Mamfe", :latitude => "5.754", :longitude => "9.3123").save
City.new(:country_id => "48", :name => "Loum", :aliases => "Loum,Lum,ÐÑÐ¼,Loum", :latitude => "4.7182", :longitude => "9.7351").save
City.new(:country_id => "48", :name => "Lolodorf", :aliases => "Lelodorf,Lolodorf,Lolodrof,Lolodorf", :latitude => "3.23333", :longitude => "10.73333").save
City.new(:country_id => "48", :name => "Limbe", :aliases => "Limbe,LimbÃ©,Victoria,ÐÐ¸Ð¼Ð±Ðµ,Limbe", :latitude => "4.0242", :longitude => "9.2149").save
City.new(:country_id => "48", :name => "Lagdo", :aliases => ",Lagdo", :latitude => "9.05", :longitude => "13.73333").save
City.new(:country_id => "48", :name => "Kumbo", :aliases => "Kumbo,Kumbo", :latitude => "6.2", :longitude => "10.66667").save
City.new(:country_id => "48", :name => "Kumba", :aliases => "Kumba,Kumboj,ÐÑÐ¼Ð±Ð¾Ð¹,Kumba", :latitude => "4.6363", :longitude => "9.4469").save
City.new(:country_id => "48", :name => "Kribi", :aliases => "Kribi,ÐÑÐ¸Ð±Ð¸,Kribi", :latitude => "2.95", :longitude => "9.91667").save
City.new(:country_id => "48", :name => "Kousseri", :aliases => "Fort Fureau,Fort-Foureau,Kousseri,KoussÃ©ri,Kusseri,KoussÃ©ri", :latitude => "12.07689", :longitude => "15.03063").save
City.new(:country_id => "48", :name => "Kaele", :aliases => ",KaÃ©lÃ©", :latitude => "10.10917", :longitude => "14.45083").save
City.new(:country_id => "48", :name => "Guider", :aliases => "Gider,Guidder,Guider,Guider", :latitude => "9.93417", :longitude => "13.94861").save
City.new(:country_id => "48", :name => "Garoua Boulai", :aliases => ",Garoua BoulaÃ¯", :latitude => "5.88333", :longitude => "14.55").save
City.new(:country_id => "48", :name => "Garoua", :aliases => "Garoua,Garua,ÐÐ°ÑÑÐ°,Garoua", :latitude => "9.3", :longitude => "13.4").save
City.new(:country_id => "48", :name => "Fundong", :aliases => ",Fundong", :latitude => "6.25", :longitude => "10.26667").save
City.new(:country_id => "48", :name => "Foumbot", :aliases => "Foumbat,Foumbot,Foumbot", :latitude => "5.50787", :longitude => "10.6356").save
City.new(:country_id => "48", :name => "Foumban", :aliases => "Foumbam,Foumban,Fumban,Foumban", :latitude => "5.7291", :longitude => "10.90011").save
City.new(:country_id => "48", :name => "Fontem", :aliases => ",Fontem", :latitude => "5.4685", :longitude => "9.8818").save
City.new(:country_id => "48", :name => "Eseka", :aliases => "Eseka,EsÃ©ka,EsÃ©ka", :latitude => "3.65", :longitude => "10.76667").save
City.new(:country_id => "48", :name => "Edea", :aliases => "Edea,EdÃ©a,Ehdea,ÃdÃ©a,Ð­Ð´ÐµÐ°,EdÃ©a", :latitude => "3.8", :longitude => "10.13333").save
City.new(:country_id => "48", :name => "Ebolowa", :aliases => "Ebolova,Ebolowa,Ãbolowa,Ãbolowa", :latitude => "2.9", :longitude => "11.15").save
City.new(:country_id => "48", :name => "Dschang", :aliases => "Chang,Dchang,Djang,Dschang,Tchang,Dschang", :latitude => "5.44559", :longitude => "10.055").save
City.new(:country_id => "48", :name => "Douala", :aliases => "Douala,Doula,Duala,do~uara,du a la,ÐÑÐ°Ð»Ð°,ãã¥ã¢ã©,æé¿æ,Douala", :latitude => "4.0469", :longitude => "9.7084").save
City.new(:country_id => "48", :name => "Dizangue", :aliases => "Dizangue,DizanguÃ©,Dizanque,DizanquÃ©,DizanguÃ©", :latitude => "3.76667", :longitude => "9.98333").save
City.new(:country_id => "48", :name => "Buea", :aliases => "Buea,BuÃ©a,Buea", :latitude => "4.1527", :longitude => "9.241").save
City.new(:country_id => "48", :name => "Bogo", :aliases => ",Bogo", :latitude => "10.7336", :longitude => "14.60928").save
City.new(:country_id => "48", :name => "Bertoua", :aliases => "Bertoua,Bertua,Gamane,ÐÐµÑÑÑÐ°,Bertoua", :latitude => "4.58333", :longitude => "13.68333").save
City.new(:country_id => "48", :name => "Belabo", :aliases => "Belabo,BÃ©labo,ÐÐµÐ»Ð°Ð±Ð¾,BÃ©labo", :latitude => "4.93333", :longitude => "13.3").save
City.new(:country_id => "48", :name => "Batouri", :aliases => "Batouri,Baturi,Batouri", :latitude => "4.43333", :longitude => "14.36667").save
City.new(:country_id => "48", :name => "Banyo", :aliases => "Banjo,Banyo,Banyo", :latitude => "6.75", :longitude => "11.81667").save
City.new(:country_id => "48", :name => "Bangangte", :aliases => "Bangangte,BangangtÃ©,Bangante,BangantÃ©,BangangtÃ©", :latitude => "5.14091", :longitude => "10.51975").save
City.new(:country_id => "48", :name => "Bamusso", :aliases => "Bamuso,Bamusso,Bamusso", :latitude => "4.4591", :longitude => "8.9027").save
City.new(:country_id => "48", :name => "Bamenda", :aliases => "Bamenda,Bamendy,ÐÐ°Ð¼ÐµÐ½Ð´Ñ,Bamenda", :latitude => "5.95266", :longitude => "10.15824").save
City.new(:country_id => "48", :name => "Bali", :aliases => "Bali,ÐÐ°Ð»Ð¸,Bali", :latitude => "5.88724", :longitude => "10.01248").save
City.new(:country_id => "48", :name => "Bafoussam", :aliases => "Bafousam,Bafoussam,Bafusam,Bafussama,Befoussam,ÐÐ°ÑÑÑÑÐ°Ð¼Ð°,Bafoussam", :latitude => "5.47366", :longitude => "10.41786").save
City.new(:country_id => "48", :name => "Bafia", :aliases => "Bafia,Bafia Ngitakuba,BafiÄ Ngitakuba,Bafia", :latitude => "4.75", :longitude => "11.23333").save
City.new(:country_id => "48", :name => "Bafang", :aliases => "Bafang,Bafang", :latitude => "5.15625", :longitude => "10.17882").save
City.new(:country_id => "48", :name => "Akonolinga", :aliases => "Akomolinga,Akonolinga,Akonolinga", :latitude => "3.76667", :longitude => "12.25").save
City.new(:country_id => "48", :name => "Idenao", :aliases => ",Idenao", :latitude => "4.2475", :longitude => "9.00472").save
