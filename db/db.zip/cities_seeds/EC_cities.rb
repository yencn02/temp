City.new(:country_id => "63", :name => "Zamora", :aliases => ",Zamora", :latitude => "-4.06917", :longitude => "-78.95667").save
City.new(:country_id => "63", :name => "Yaguachi", :aliases => "Yaguachi,Yaguachi Nuevo,Yaguachi", :latitude => "-2.11667", :longitude => "-79.68333").save
City.new(:country_id => "63", :name => "Vinces", :aliases => "Vinces,Vinces", :latitude => "-1.55", :longitude => "-79.73333").save
City.new(:country_id => "63", :name => "Ventanas", :aliases => ",Ventanas", :latitude => "-1.45", :longitude => "-79.46667").save
City.new(:country_id => "63", :name => "Velasco Ibarra", :aliases => "El Empalme,Empalme,Velasco Ibarra,Velasco Ibarra", :latitude => "-1.05", :longitude => "-79.61667").save
City.new(:country_id => "63", :name => "Tena", :aliases => "Napo,San Juan de Tena,Tena,Tena", :latitude => "-0.98333", :longitude => "-77.81667").save
City.new(:country_id => "63", :name => "Sucre", :aliases => ",Sucre", :latitude => "-1.26667", :longitude => "-80.43333").save
City.new(:country_id => "63", :name => "Santo Domingo de los Colorados", :aliases => "Santo Domingo,Santo Domingo de los Colorados,Santo-Domingo-de-los-Kolorados,Ð¡Ð°Ð½ÑÐ¾-ÐÐ¾Ð¼Ð¸Ð½Ð³Ð¾-Ð´Ðµ-Ð»Ð¾Ñ-ÐÐ¾Ð»Ð¾ÑÐ°Ð´Ð¾Ñ,Santo Domingo de los Colorados", :latitude => "-0.25", :longitude => "-79.15").save
City.new(:country_id => "63", :name => "Santa Rosa", :aliases => ",Santa Rosa", :latitude => "-3.45", :longitude => "-79.96667").save
City.new(:country_id => "63", :name => "Santa Elena", :aliases => ",Santa Elena", :latitude => "-2.23333", :longitude => "-80.85").save
City.new(:country_id => "63", :name => "San Lorenzo de Esmeraldas", :aliases => "Puerto San Lorenzo,San Lorenzo,San Lorenzo de Esmeraldas,San Lorenzo de Esmeraldas", :latitude => "1.28833", :longitude => "-78.83694").save
City.new(:country_id => "63", :name => "San Gabriel", :aliases => "Montufar,MontÃºfar,San Gabriel,San Gabriel", :latitude => "0.6", :longitude => "-77.81667").save
City.new(:country_id => "63", :name => "Samborondon", :aliases => "Samborondon,SamborondÃ³n,Samrondon,SamrondÃ³n,Zamborondon,ZamborondÃ³n,SamborondÃ³n", :latitude => "-1.95", :longitude => "-79.73333").save
City.new(:country_id => "63", :name => "Salinas", :aliases => "Salinas,Ð¡Ð°Ð»Ð¸Ð½Ð°Ñ,Salinas", :latitude => "-2.21667", :longitude => "-80.96667").save
City.new(:country_id => "63", :name => "Rosa Zarate", :aliases => "Quininde,Rosa Zarate,Rosa ZÃ¡rate,Rosa ZÃ¡rate", :latitude => "0.33333", :longitude => "-79.46667").save
City.new(:country_id => "63", :name => "Riobamba", :aliases => "Riobamba,Riobamba", :latitude => "-1.66667", :longitude => "-78.63333").save
City.new(:country_id => "63", :name => "Quito", :aliases => "Kita,Kitas,Kito,Kitu,Quito,San Francisco de Quito,ji duo,ki to,kito,kytw,qytw,ÎÎ¯ÏÎ¿,ÐÐ¸ÑÐ¾,ÐÑÑÐ°,ÐÑÑÐ¾,Ô¿Õ«Õ¿Õ¸,×§×××,ÙÙØªÙ,à¸à¸µà¹à¸,áªá¶,ã­ã,åºå¤,í¤í ,Quito", :latitude => "-0.22985", :longitude => "-78.52495").save
City.new(:country_id => "63", :name => "Quevedo", :aliases => ",Quevedo", :latitude => "-1.03333", :longitude => "-79.45").save
City.new(:country_id => "63", :name => "Puyo", :aliases => "El Puyo,Pujo,Puyo,ÐÑÐ¹Ð¾,Puyo", :latitude => "-1.46667", :longitude => "-77.98333").save
City.new(:country_id => "63", :name => "Pujili", :aliases => "Pajili,Pujili,PujilÃ­,PujilÃ­", :latitude => "-0.95", :longitude => "-78.68333").save
City.new(:country_id => "63", :name => "Propicia", :aliases => ",Propicia", :latitude => "0.93333", :longitude => "-79.68333").save
City.new(:country_id => "63", :name => "Portoviejo", :aliases => "Portov'ekho,Portoviejo,ÐÐ¾ÑÑÐ¾Ð²ÑÐµÑÐ¾,Portoviejo", :latitude => "-1.05", :longitude => "-80.45").save
City.new(:country_id => "63", :name => "Playas", :aliases => "General Villamil,Playas,Villamil,Playas", :latitude => "-2.63333", :longitude => "-80.38333").save
City.new(:country_id => "63", :name => "Pinas", :aliases => "Pinas,PiÃ±as,PiÃ±as", :latitude => "-3.66667", :longitude => "-79.65").save
City.new(:country_id => "63", :name => "Pelileo", :aliases => ",Pelileo", :latitude => "-1.31667", :longitude => "-78.53333").save
City.new(:country_id => "63", :name => "Pedro Carbo", :aliases => ",Pedro Carbo", :latitude => "-1.83333", :longitude => "-80.23333").save
City.new(:country_id => "63", :name => "Pasaje", :aliases => ",Pasaje", :latitude => "-3.33333", :longitude => "-79.81667").save
City.new(:country_id => "63", :name => "Otavalo", :aliases => "Otavalo,Otovalo,ÐÑÐ°Ð²Ð°Ð»Ð¾,Otavalo", :latitude => "0.23333", :longitude => "-78.26667").save
City.new(:country_id => "63", :name => "Naranjito", :aliases => ",Naranjito", :latitude => "-2.21667", :longitude => "-79.48333").save
City.new(:country_id => "63", :name => "Naranjal", :aliases => ",Naranjal", :latitude => "-2.66667", :longitude => "-79.61667").save
City.new(:country_id => "63", :name => "Montecristi", :aliases => ",Montecristi", :latitude => "-1.05", :longitude => "-80.66667").save
City.new(:country_id => "63", :name => "Montalvo", :aliases => ",Montalvo", :latitude => "-1.8", :longitude => "-79.33333").save
City.new(:country_id => "63", :name => "Manta", :aliases => "Manta,Manta Ecuador,Puerto de Manta,ÐÐ°Ð½ÑÐ°,Manta", :latitude => "-0.95", :longitude => "-80.73333").save
City.new(:country_id => "63", :name => "Machala", :aliases => "Machala,machala,ÐÐ°ÑÐ°Ð»Ð°,ÙØ§ÚØ§ÙØ§,Machala", :latitude => "-3.26667", :longitude => "-79.96667").save
City.new(:country_id => "63", :name => "Machachi", :aliases => "Ciudad de Machachi,Machache,Machachi,Machachi", :latitude => "-0.5", :longitude => "-78.56667").save
City.new(:country_id => "63", :name => "Macas", :aliases => ",Macas", :latitude => "-2.31667", :longitude => "-78.11667").save
City.new(:country_id => "63", :name => "Loja", :aliases => "Loja,Lokha,ÐÐ¾ÑÐ°,Loja", :latitude => "-3.99313", :longitude => "-79.20422").save
City.new(:country_id => "63", :name => "La Troncal", :aliases => ",La Troncal", :latitude => "-2.4", :longitude => "-79.33333").save
City.new(:country_id => "63", :name => "Latacunga", :aliases => "Latacunga,Latacunga", :latitude => "-0.93333", :longitude => "-78.61667").save
City.new(:country_id => "63", :name => "La Mana", :aliases => ",La ManÃ¡", :latitude => "-0.93333", :longitude => "-79.21667").save
City.new(:country_id => "63", :name => "La Libertad", :aliases => "La Libertad,La Libertad", :latitude => "-2.23333", :longitude => "-80.9").save
City.new(:country_id => "63", :name => "Nueva Loja", :aliases => "Lago Agrio,Nuehva-Lokha,Nueva Loja,ÐÑÑÐ²Ð°-ÐÐ¾ÑÐ°,Nueva Loja", :latitude => "0.08472", :longitude => "-76.88278").save
City.new(:country_id => "63", :name => "Jipijapa", :aliases => ",Jipijapa", :latitude => "-1.33333", :longitude => "-80.58333").save
City.new(:country_id => "63", :name => "Ibarra", :aliases => "Ibarra,ÐÐ±Ð°ÑÑÐ°,Ibarra", :latitude => "0.35", :longitude => "-78.11667").save
City.new(:country_id => "63", :name => "Huaquillas", :aliases => ",Huaquillas", :latitude => "-3.48333", :longitude => "-80.23333").save
City.new(:country_id => "63", :name => "Guayaquil", :aliases => "Gouagiakil,Guajakil',Guayaquil,Gvajakil,Gvajakila,Gvajakilis,Wayakil,ghwayakyl,guayakiru,ÎÎ¿ÏÎ±Î³Î¹Î±ÎºÎ¯Î»,ÐÐ²Ð°ÑÐ°ÐºÐ¸Ð»,ÐÑÐ°ÑÐºÐ¸Ð»Ñ,ÒÑÐ°ÑÐºÑÐ»Ñ,ØºÙØ§ÙØ§ÙÙÙ,ã°ã¢ã¤ã­ã«,Guayaquil", :latitude => "-2.16667", :longitude => "-79.9").save
City.new(:country_id => "63", :name => "Guaranda", :aliases => "Guaranda,ÐÑÐ°ÑÐ°Ð½Ð´Ð°,Guaranda", :latitude => "-1.6", :longitude => "-79").save
City.new(:country_id => "63", :name => "Gualaceo", :aliases => "Gualaceo,Gualaceo", :latitude => "-2.9", :longitude => "-78.78333").save
City.new(:country_id => "63", :name => "El Triunfo", :aliases => ",El Triunfo", :latitude => "-1.93333", :longitude => "-79.96667").save
City.new(:country_id => "63", :name => "Duran", :aliases => "Alfaro,Duran,DurÃ¡n,Eloy alfaro,DurÃ¡n", :latitude => "-2.2", :longitude => "-79.83333").save
City.new(:country_id => "63", :name => "Cuenca", :aliases => "Cuenca,Kuehnka,ÐÑÑÐ½ÐºÐ°,Cuenca", :latitude => "-2.88333", :longitude => "-78.98333").save
City.new(:country_id => "63", :name => "Chone", :aliases => "Chone,Chone", :latitude => "-0.68333", :longitude => "-80.1").save
City.new(:country_id => "63", :name => "Cayambe", :aliases => "Cayambe,Kajambe,ÐÐ°ÑÐ¼Ð±Ðµ,Cayambe", :latitude => "0.05", :longitude => "-78.13333").save
City.new(:country_id => "63", :name => "Catamayo", :aliases => "Catamayo,La Toma,Catamayo", :latitude => "-3.98333", :longitude => "-79.35").save
City.new(:country_id => "63", :name => "Cariamanga", :aliases => "Calvas,Cariamanga,Cariamanga", :latitude => "-4.33333", :longitude => "-79.55").save
City.new(:country_id => "63", :name => "Calceta", :aliases => "Bolivar,BolÃ­var,Calceta,Calceta", :latitude => "-0.85", :longitude => "-80.16667").save
City.new(:country_id => "63", :name => "Boca Suno", :aliases => "Boca Suno,Suno,Boca Suno", :latitude => "-0.71667", :longitude => "-77.13333").save
City.new(:country_id => "63", :name => "Balzar", :aliases => ",Balzar", :latitude => "-1.36667", :longitude => "-79.9").save
City.new(:country_id => "63", :name => "Bahia de Caraquez", :aliases => "Bahia,Bahia de Caraques,Bahia de Caraquez,Bahia de CarÃ¡ques,BahÃ­a,BahÃ­a de CarÃ¡quez,Caracas,Sucre,BahÃ­a de CarÃ¡quez", :latitude => "-0.6", :longitude => "-80.41667").save
City.new(:country_id => "63", :name => "Babahoyo", :aliases => "Babahoya,Babahoyo,Babahoyo", :latitude => "-1.81667", :longitude => "-79.51667").save
City.new(:country_id => "63", :name => "Azogues", :aliases => "Azogues,Azoguez,Azogues", :latitude => "-2.73333", :longitude => "-78.83333").save
City.new(:country_id => "63", :name => "Atuntaqui", :aliases => ",Atuntaqui", :latitude => "0.33333", :longitude => "-78.21667").save
City.new(:country_id => "63", :name => "Ambato", :aliases => "Ambato,San Juan de Ambato,ÐÐ¼Ð±Ð°ÑÐ¾,Ambato", :latitude => "-1.24908", :longitude => "-78.61675").save
