City.new(:country_id => "16", :name => "Oranjestad", :aliases => "Oran'estad,Oraniestad,Oranjestad,oraniesutaddo,ÐÑÐ°Ð½Ð¸ÐµÑÑÐ°Ð´,ÐÑÐ°Ð½ÑÐµÑÑÐ°Ð´,ãªã©ãã¨ã¹ã¿ãã,Oranjestad", :latitude => "12.52398", :longitude => "-70.02703").save
City.new(:country_id => "16", :name => "Babijn", :aliases => ",Babijn", :latitude => "12.53333", :longitude => "-69.98333").save
City.new(:country_id => "16", :name => "Angochi", :aliases => ",Angochi", :latitude => "12.51667", :longitude => "-69.95").save
