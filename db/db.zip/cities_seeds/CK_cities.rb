City.new(:country_id => "46", :name => "Avarua", :aliases => "Avarua,AvarÃºa,abarua,ÐÐ²Ð°ÑÑÐ°,ã¢ãã«ã¢,Avarua", :latitude => "-21.20778", :longitude => "-159.775").save
