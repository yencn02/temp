City.new(:country_id => "239", :name => "Road Town", :aliases => "Road Town,rodotaun,×¨×××× ××××,ã­ã¼ãã¿ã¦ã³,Road Town", :latitude => "18.41667", :longitude => "-64.61667").save
