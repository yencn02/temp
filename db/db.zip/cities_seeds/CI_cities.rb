City.new(:country_id => "45", :name => "Zuenoula", :aliases => "Zenoula,Zouenoula,ZouÃ©noula,Zuenoula,ZuÃ©noula,ZÃ©noula,ZuÃ©noula", :latitude => "7.42917", :longitude => "-6.04306").save
City.new(:country_id => "45", :name => "Yamoussoukro", :aliases => "Giamoussoukro,Jamusukras,Jamusukro,Yamoussokro,Yamoussoukro,Yamussukro,Yamusukro,ya mu su ke luo,yamusukeulo,yamusukuro,ÎÎ¹Î±Î¼Î¿ÏÏÏÎ¿ÏÎºÏÎ¿,ÐÐ°Ð¼ÑÑÑÐºÑÐ¾,Ð¯Ð¼ÑÑÑÐºÑÐ¾,ÕÕ¡Õ´Õ¸ÖÕ½Õ¸ÖÕ¯ÖÕ¸,×××××¡××§×¨×,á«áá±á­á®,ã¤ã ã¹ã¯ã­,äºç©èåç½,ì¼ë¬´ìí¬ë¡,Yamoussoukro", :latitude => "6.81667", :longitude => "-5.28333").save
City.new(:country_id => "45", :name => "Vavoua", :aliases => "Vavoua,Vavua,ÐÐ°Ð²ÑÐ°,Vavoua", :latitude => "7.38194", :longitude => "-6.47778").save
City.new(:country_id => "45", :name => "Toumodi", :aliases => "Toumodi,Tumodi,Toumodi", :latitude => "6.55", :longitude => "-5.01667").save
City.new(:country_id => "45", :name => "Touba", :aliases => "Touba,Tuba,Touba", :latitude => "8.28333", :longitude => "-7.68333").save
City.new(:country_id => "45", :name => "Tengrela", :aliases => "Tengrela,Tingrela,TingrÃ©la,Tengrela", :latitude => "10.48694", :longitude => "-6.40972").save
City.new(:country_id => "45", :name => "Tiassale", :aliases => ",TiassalÃ©", :latitude => "5.89833", :longitude => "-4.82833").save
City.new(:country_id => "45", :name => "Tanda", :aliases => "Tan N'Da,Tan NâDa,Tanda,Tanga,Tanda", :latitude => "7.80639", :longitude => "-3.17139").save
City.new(:country_id => "45", :name => "Tabou", :aliases => "Tabou,Tabu,Tabou", :latitude => "4.41667", :longitude => "-7.35").save
City.new(:country_id => "45", :name => "Sinfra", :aliases => ",Sinfra", :latitude => "6.61667", :longitude => "-5.91667").save
City.new(:country_id => "45", :name => "Sassandra", :aliases => "Sassandra,Ð¡Ð°ÑÑÐ°Ð½Ð´ÑÐ°,Sassandra", :latitude => "4.95", :longitude => "-6.08333").save
City.new(:country_id => "45", :name => "San-Pedro", :aliases => "San-Pedro,San-PÃ©dro,San-PÃ©dro", :latitude => "4.73333", :longitude => "-6.61667").save
City.new(:country_id => "45", :name => "Sakassou", :aliases => "Sakasso,Sakassou,Sakassu,Sakassou", :latitude => "7.45806", :longitude => "-5.29417").save
City.new(:country_id => "45", :name => "Oume", :aliases => "Oume,OumÃ©,Ume,OumÃ©", :latitude => "6.38333", :longitude => "-5.41667").save
City.new(:country_id => "45", :name => "Odienne", :aliases => "Odienne,OdiennÃ©,ÐÐ´Ð¸ÐµÐ½Ð½Ðµ,OdiennÃ©", :latitude => "9.51", :longitude => "-7.56917").save
City.new(:country_id => "45", :name => "Mankono", :aliases => ",Mankono", :latitude => "8.05861", :longitude => "-6.18972").save
City.new(:country_id => "45", :name => "Man", :aliases => "Man,Man", :latitude => "7.40528", :longitude => "-7.5475").save
City.new(:country_id => "45", :name => "Lakota", :aliases => "Iakota,Lakota,ÐÐ°ÐºÐ¾ÑÐ°,Lakota", :latitude => "5.85278", :longitude => "-5.68833").save
City.new(:country_id => "45", :name => "Korhogo", :aliases => "Korhogo,Korogo,ÐÐ¾ÑÐ¾Ð³Ð¾,Korhogo", :latitude => "9.45", :longitude => "-5.63333").save
City.new(:country_id => "45", :name => "Katiola", :aliases => "Katiola,Lafouka,Katiola", :latitude => "8.13333", :longitude => "-5.1").save
City.new(:country_id => "45", :name => "Issia", :aliases => ",Issia", :latitude => "6.48333", :longitude => "-6.58333").save
City.new(:country_id => "45", :name => "Guiglo", :aliases => ",Guiglo", :latitude => "6.54028", :longitude => "-7.48583").save
City.new(:country_id => "45", :name => "Grand-Bassam", :aliases => "Gran-Bassam,Grand-Bassam,ÐÑÐ°Ð½-ÐÐ°ÑÑÐ°Ð¼,Grand-Bassam", :latitude => "5.20194", :longitude => "-3.735").save
City.new(:country_id => "45", :name => "Affery", :aliases => "Aferi,Affery,AfÃ©ri,Grand Aferi,Grand AfÃ©ri,Affery", :latitude => "6.315", :longitude => "-3.96028").save
City.new(:country_id => "45", :name => "Gagnoa", :aliases => "Gagnoa,Gragnoa,Gagnoa", :latitude => "6.13333", :longitude => "-5.93333").save
City.new(:country_id => "45", :name => "Ferkessedougou", :aliases => "Ferkesedugu,Ferkessedougou,FerkessÃ©dougou,Firkessedougou,Firkessedugu,FirkessÃ©dougou,FirkessÃ©dugu,Pofire,Serkessedougou,Ð¤ÐµÑÐºÐµÑÐµÐ´ÑÐ³Ñ,FerkessÃ©dougou", :latitude => "9.6", :longitude => "-5.2").save
City.new(:country_id => "45", :name => "Duekoue", :aliases => ",DuÃ©kouÃ©", :latitude => "6.73806", :longitude => "-7.34306").save
City.new(:country_id => "45", :name => "Divo", :aliases => "Boudougou,Divo,Divo", :latitude => "5.83972", :longitude => "-5.36").save
City.new(:country_id => "45", :name => "Dimbokro", :aliases => "Dimbokro,Dimbokro", :latitude => "6.65", :longitude => "-4.7").save
City.new(:country_id => "45", :name => "Daoukro", :aliases => "Daoukrou,Daukro,ÐÐ°ÑÐºÑÐ¾,Daoukro", :latitude => "7.0591", :longitude => "-3.9631").save
City.new(:country_id => "45", :name => "Danane", :aliases => "Danane,DananÃ©,Fort Hittos,ÐÐ°Ð½Ð°Ð½Ðµ,DananÃ©", :latitude => "7.26278", :longitude => "-8.15972").save
City.new(:country_id => "45", :name => "Daloa", :aliases => "Daloa,ÐÐ°Ð»Ð¾Ð°,Daloa", :latitude => "6.87472", :longitude => "-6.45194").save
City.new(:country_id => "45", :name => "Dabou", :aliases => "Dab,Dabou,Dabu,ÐÐ°Ð±,Dabou", :latitude => "5.32056", :longitude => "-4.38306").save
City.new(:country_id => "45", :name => "Boundiali", :aliases => "Boundiali,Boundiouli,Bundiali,ÐÑÐ½Ð´Ð¸Ð°Ð»Ð¸,Boundiali", :latitude => "9.52167", :longitude => "-6.48694").save
City.new(:country_id => "45", :name => "Bouna", :aliases => "Bouna,Buna,ÐÑÐ½Ð°,Bouna", :latitude => "9.26667", :longitude => "-3").save
City.new(:country_id => "45", :name => "Bouake", :aliases => "Bouake,BouakÃ©,Buake,Bwake,ÐÑÐ°ÐºÐµ,BouakÃ©", :latitude => "7.68333", :longitude => "-5.03306").save
City.new(:country_id => "45", :name => "Bouafle", :aliases => "Bouafle,BouaflÃ©,Buafle,BouaflÃ©", :latitude => "6.98333", :longitude => "-5.75").save
City.new(:country_id => "45", :name => "Bonoua", :aliases => "Bonoua,Bonua,Bunua,Grand Akapless,Bonoua", :latitude => "5.27222", :longitude => "-3.60083").save
City.new(:country_id => "45", :name => "Bongouanou", :aliases => "Bongouanou,Bonguanu,Bougouanou,Bongouanou", :latitude => "6.64861", :longitude => "-4.19917").save
City.new(:country_id => "45", :name => "Bondoukou", :aliases => "Bondoukau,Bondoukou,Bonduku,Boudoukou,Gontoukou,ÐÐ¾Ð½Ð´ÑÐºÑ,Bondoukou", :latitude => "8.03333", :longitude => "-2.8").save
City.new(:country_id => "45", :name => "Bingerville", :aliases => "Bingerville,Bingerville", :latitude => "5.35583", :longitude => "-3.89").save
City.new(:country_id => "45", :name => "Biankouma", :aliases => "Biankouma,Biankouma", :latitude => "7.73694", :longitude => "-7.61028").save
City.new(:country_id => "45", :name => "Beoumi", :aliases => "Beoumi,Beumi,BÃ©oumi,BÃ©oumi", :latitude => "7.67611", :longitude => "-5.57972").save
City.new(:country_id => "45", :name => "Bangolo", :aliases => "Bangolo,Zagna,Bangolo", :latitude => "7.00694", :longitude => "-7.475").save
City.new(:country_id => "45", :name => "Arrah", :aliases => "Arra,Arrah,Arrah", :latitude => "6.66528", :longitude => "-3.97222").save
City.new(:country_id => "45", :name => "Anyama", :aliases => "An'jame,Aniama,Anyama,Anyama Sossokoua,ÐÐ½ÑÑÐ¼Ðµ,Anyama", :latitude => "5.49583", :longitude => "-4.05472").save
City.new(:country_id => "45", :name => "Akoupe", :aliases => "Akoupe,AkoupÃ©,Akupe,AkoupÃ©", :latitude => "6.39", :longitude => "-3.90028").save
City.new(:country_id => "45", :name => "Agnibilekrou", :aliases => "Agnibilekrou,AgnibilÃ©krou,Anibelekru,AgnibilÃ©krou", :latitude => "7.13444", :longitude => "-3.20472").save
City.new(:country_id => "45", :name => "Agboville", :aliases => "Agbovile,Agboville,ÐÐ³Ð±Ð¾Ð²Ð¸Ð»Ðµ,Agboville", :latitude => "5.93417", :longitude => "-4.22139").save
City.new(:country_id => "45", :name => "Adzope", :aliases => "Adzope,AdzopÃ©,ÐÐ´Ð·Ð¾Ð¿Ðµ,AdzopÃ©", :latitude => "6.10694", :longitude => "-3.86194").save
City.new(:country_id => "45", :name => "Adiake", :aliases => "Adiake,AdiakÃ©,AdiakÃ©", :latitude => "5.28639", :longitude => "-3.3075").save
City.new(:country_id => "45", :name => "Aboisso", :aliases => "Abisso,Aboissa,Aboisso,Abuasso,ÐÐ±ÑÐ°ÑÑÐ¾,Aboisso", :latitude => "5.4675", :longitude => "-3.21444").save
City.new(:country_id => "45", :name => "Abobo", :aliases => ",Abobo", :latitude => "5.41889", :longitude => "-4.02056").save
City.new(:country_id => "45", :name => "Abidjan", :aliases => "Abican,Abidjan,Abidzan,Abidzana,Abidzanas,Abidzhan,AbidÅ¼an,AbidÅ¾an,AbidÅ¾anas,AbidÅ¾Äna,Abigano,Abijan,Abiyan,AbiyÃ¡n,AbiÄano,a bi rang,abijan,abijang,abyjan,ÐÐ±Ð¸Ð´Ð¶Ð°Ð½,ÐÐ±Ð¸ÑÐ°Ð½,ÐÐ±ÑÐ´Ð¶Ð°Ð½,××××'××,Ø£Ø¨ÙØ¬Ø§Ù,ã¢ãã¸ã£ã³,é¿æ¯è®©,ìë¹ì¥,Abidjan", :latitude => "5.34111", :longitude => "-4.02806").save
City.new(:country_id => "45", :name => "Abengourou", :aliases => "Abengourou,Abenguru,ÐÐ±ÐµÐ½Ð³ÑÑÑ,Abengourou", :latitude => "6.72972", :longitude => "-3.49639").save
City.new(:country_id => "45", :name => "Seguela", :aliases => "Segele,Seguela,SÃ©guÃ©la,Ð¡ÐµÐ³ÐµÐ»Ðµ,SÃ©guÃ©la", :latitude => "7.96111", :longitude => "-6.67306").save
City.new(:country_id => "45", :name => "Soubre", :aliases => ",SoubrÃ©", :latitude => "5.78556", :longitude => "-6.60833").save
