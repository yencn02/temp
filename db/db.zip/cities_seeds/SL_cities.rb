City.new(:country_id => "205", :name => "Waterloo", :aliases => "Waterloo,Waterloo", :latitude => "8.33833", :longitude => "-13.07194").save
City.new(:country_id => "205", :name => "Port Loko", :aliases => "Port Loka,Port Lokko,Port Loko,Port-Loko,ÐÐ¾ÑÑ-ÐÐ¾ÐºÐ¾,Port Loko", :latitude => "8.76667", :longitude => "-12.78333").save
City.new(:country_id => "205", :name => "Makeni", :aliases => "Makeni,ÐÐ°ÐºÐµÐ½Ð¸,Makeni", :latitude => "8.88333", :longitude => "-12.05").save
City.new(:country_id => "205", :name => "Lunsar", :aliases => "Lansar,Lunsar,Lunsare,ÐÑÐ½ÑÐ°ÑÐµ,Lunsar", :latitude => "8.68333", :longitude => "-12.53333").save
City.new(:country_id => "205", :name => "Koidu", :aliases => ",Koidu", :latitude => "8.41667", :longitude => "-10.83333").save
City.new(:country_id => "205", :name => "Kenema", :aliases => "Kenema,Keneme,ÐÐµÐ½ÐµÐ¼Ðµ,Kenema", :latitude => "7.87667", :longitude => "-11.1875").save
City.new(:country_id => "205", :name => "Kabala", :aliases => "Kabala,Kaballa,Kabala", :latitude => "9.58333", :longitude => "-11.55").save
City.new(:country_id => "205", :name => "Freetown", :aliases => "Freetown,Fritaun,Fritaunas,Fritauno,FritaÅ­no,Phritaoun,Saint George,fu li dun,furitaun,peulitaun,zi you shi,Î¦ÏÎ¯ÏÎ±Î¿ÏÎ½,Ð¤ÑÐ¸ÑÐ°ÑÐ½,×¤×¨×××××,ÙØ±ÛâØªØ§ÙÙ,ááªá³áá,ããªã¼ã¿ã¦ã³,å¼éæ¦,èªç±å¸,íë¦¬íì´,Freetown", :latitude => "8.484", :longitude => "-13.22994").save
City.new(:country_id => "205", :name => "Bo", :aliases => "Bo,ÐÐ¾,Bo", :latitude => "7.96472", :longitude => "-11.73833").save
