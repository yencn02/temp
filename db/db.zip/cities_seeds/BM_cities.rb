City.new(:country_id => "29", :name => "Hamilton", :aliases => "Hamilton,Hamilton", :latitude => "32.29149", :longitude => "-64.77797").save
