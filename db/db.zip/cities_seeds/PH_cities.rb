City.new(:country_id => "179", :name => "Zamboanga", :aliases => "Burleigh School,Zamboanga,Zamboanga City,ÐÐ°Ð¼Ð±Ð¾Ð°Ð½Ð³Ð°,Zamboanga", :latitude => "6.91028", :longitude => "122.07389").save
City.new(:country_id => "179", :name => "Wao", :aliases => ",Wao", :latitude => "7.68333", :longitude => "124.66667").save
City.new(:country_id => "179", :name => "Virac", :aliases => "Virac,Virac", :latitude => "13.5848", :longitude => "124.2374").save
City.new(:country_id => "179", :name => "Vigan", :aliases => "Vigan,Vigan", :latitude => "17.57472", :longitude => "120.38694").save
City.new(:country_id => "179", :name => "Victorias City", :aliases => "Dakbayan sa Victorias,Syudad han Victorias,Victorias,Victorias City,Victorias City", :latitude => "10.9", :longitude => "123.07778").save
City.new(:country_id => "179", :name => "Victoria", :aliases => "Nanhaya,Victoria,Viktorija,ÐÐ¸ÐºÑÐ¾ÑÐ¸Ñ,Victoria", :latitude => "14.2277", :longitude => "121.3292").save
City.new(:country_id => "179", :name => "Veruela", :aliases => "Veruela,Veruela", :latitude => "8.0731", :longitude => "125.9558").save
City.new(:country_id => "179", :name => "Valencia", :aliases => "Valencia,Valensija,ÐÐ°Ð»ÐµÐ½ÑÐ¸Ñ,Valencia", :latitude => "7.90639", :longitude => "125.09417").save
City.new(:country_id => "179", :name => "Urdaneta", :aliases => ",Urdaneta", :latitude => "15.97611", :longitude => "120.57111").save
City.new(:country_id => "179", :name => "Ualog", :aliases => "Ualog,Ualog", :latitude => "10.57396", :longitude => "123.3933").save
City.new(:country_id => "179", :name => "Tupi", :aliases => "Tupi,Tupi", :latitude => "6.33444", :longitude => "124.95278").save
City.new(:country_id => "179", :name => "Tuguegarao City", :aliases => "Lungsod ng Tuguegarao,Tuguegarao,Tuguegarao City,Tuguegaro,Tuguegarao City", :latitude => "17.61306", :longitude => "121.72694").save
City.new(:country_id => "179", :name => "Trento", :aliases => "Trento,Trento", :latitude => "8.04583", :longitude => "126.06361").save
City.new(:country_id => "179", :name => "Toledo", :aliases => "Ciudad ti Toledo,Dakbayan sa Talisay,Toledo,Toledo City,Ð¢Ð¾Ð»ÐµÐ´Ð¾,Toledo", :latitude => "10.37917", :longitude => "123.64194").save
City.new(:country_id => "179", :name => "Tiwi", :aliases => "Tiwi,Tiwi", :latitude => "13.4585", :longitude => "123.6805").save
City.new(:country_id => "179", :name => "Ternate", :aliases => "Ternate,Ternate", :latitude => "14.2897", :longitude => "120.7168").save
City.new(:country_id => "179", :name => "Teresa", :aliases => "Teresa,Tereza,Ð¢ÐµÑÐµÐ·Ð°,Teresa", :latitude => "14.5612", :longitude => "121.2195").save
City.new(:country_id => "179", :name => "Telabastagan", :aliases => ",Telabastagan", :latitude => "15.11667", :longitude => "120.61667").save
City.new(:country_id => "179", :name => "Taytay", :aliases => "Taytay,Taytay", :latitude => "14.5678", :longitude => "121.1394").save
City.new(:country_id => "179", :name => "Tayabas", :aliases => ",Tayabas", :latitude => "14.02889", :longitude => "121.59111").save
City.new(:country_id => "179", :name => "Tarlac", :aliases => ",Tarlac", :latitude => "15.48889", :longitude => "120.59861").save
City.new(:country_id => "179", :name => "Tanza", :aliases => "Tanza,Tanza", :latitude => "14.6753", :longitude => "120.9389").save
City.new(:country_id => "179", :name => "Tanjay", :aliases => ",Tanjay", :latitude => "9.51528", :longitude => "123.15833").save
City.new(:country_id => "179", :name => "Tangub", :aliases => "Tangob,Tangub City,Tangub", :latitude => "8.06", :longitude => "123.75").save
City.new(:country_id => "179", :name => "Tandag", :aliases => ",Tandag", :latitude => "9.07833", :longitude => "126.19861").save
City.new(:country_id => "179", :name => "Tanay", :aliases => "Tanay,Tanay", :latitude => "14.4968", :longitude => "121.2846").save
City.new(:country_id => "179", :name => "Tanauan", :aliases => ",Tanauan", :latitude => "14.08627", :longitude => "121.14975").save
City.new(:country_id => "179", :name => "Tanauan", :aliases => "Tanauan,Tanauan", :latitude => "11.10944", :longitude => "125.01556").save
City.new(:country_id => "179", :name => "Taloc", :aliases => "Taluc,Taloc", :latitude => "10.57222", :longitude => "122.89667").save
City.new(:country_id => "179", :name => "Talisay", :aliases => "Talisay,Talisay", :latitude => "14.0925", :longitude => "121.02194").save
City.new(:country_id => "179", :name => "Talisay", :aliases => ",Talisay", :latitude => "10.73722", :longitude => "122.96639").save
City.new(:country_id => "179", :name => "Talisay", :aliases => "Ciudad ti Talisay,Talisay,Talisay City,tarisai,ã¿ãªãµã¤,Talisay", :latitude => "10.24472", :longitude => "123.84944").save
City.new(:country_id => "179", :name => "Talavera", :aliases => "Talavera,Ð¢Ð°Ð»Ð°Ð²ÐµÑÐ°,Talavera", :latitude => "15.5883", :longitude => "120.9192").save
City.new(:country_id => "179", :name => "Talacogon", :aliases => ",Talacogon", :latitude => "8.45611", :longitude => "125.78417").save
City.new(:country_id => "179", :name => "Tagoloan", :aliases => "Tagoloan,Tagoloan", :latitude => "8.53889", :longitude => "124.75694").save
City.new(:country_id => "179", :name => "Tagbilaran", :aliases => "Dakbayan sa Tagbilaran,Syudad han Tagbilaran,Tagbilaran,Tagbilaran City,Tagbilaran", :latitude => "9.6475", :longitude => "123.85556").save
City.new(:country_id => "179", :name => "Tagas", :aliases => ",Tagas", :latitude => "13.16667", :longitude => "123.71667").save
City.new(:country_id => "179", :name => "Tacurong", :aliases => "Tacorong,Tacurong,Takrong,Takurong,Tacurong", :latitude => "6.6925", :longitude => "124.67639").save
City.new(:country_id => "179", :name => "Tabuk", :aliases => ",Tabuk", :latitude => "17.41889", :longitude => "121.44583").save
City.new(:country_id => "179", :name => "Tabaco", :aliases => "Tobaco,Tabaco", :latitude => "13.35861", :longitude => "123.73361").save
City.new(:country_id => "179", :name => "Taal", :aliases => "Taal,Ð¢Ð°Ð°Ð»,Taal", :latitude => "13.87944", :longitude => "120.92528").save
City.new(:country_id => "179", :name => "Surigao", :aliases => "Ciudad ti Surigao,Surigao,Surigao City,Surigao", :latitude => "9.78389", :longitude => "125.48889").save
City.new(:country_id => "179", :name => "Surallah", :aliases => "Surallah,Surallah", :latitude => "6.36667", :longitude => "124.73333").save
City.new(:country_id => "179", :name => "Subic", :aliases => "Subic,Subic", :latitude => "14.87999", :longitude => "120.23433").save
City.new(:country_id => "179", :name => "Suay", :aliases => ",Suay", :latitude => "10.06306", :longitude => "122.85528").save
City.new(:country_id => "179", :name => "Sorsogon", :aliases => ",Sorsogon", :latitude => "12.97389", :longitude => "123.99333").save
City.new(:country_id => "179", :name => "Solano", :aliases => "Solano,Ð¡Ð¾Ð»Ð°Ð½Ð¾,Solano", :latitude => "16.51918", :longitude => "121.18124").save
City.new(:country_id => "179", :name => "Sitangkai", :aliases => "Si Tangkay,Sitangkai,Sitankai,Sitangkai", :latitude => "4.66278", :longitude => "119.39278").save
City.new(:country_id => "179", :name => "Sipalay", :aliases => ",Sipalay", :latitude => "9.75194", :longitude => "122.40417").save
City.new(:country_id => "179", :name => "Silang", :aliases => ",Silang", :latitude => "14.23056", :longitude => "120.975").save
City.new(:country_id => "179", :name => "Sibulan", :aliases => "Sibulan,Sibulan", :latitude => "9.3584", :longitude => "123.285").save
City.new(:country_id => "179", :name => "Sexmoan", :aliases => "Sasmoan,Sasmuan,Sexmoan,Sexmoan", :latitude => "14.9438", :longitude => "120.6229").save
City.new(:country_id => "179", :name => "Sebu", :aliases => ",Sebu", :latitude => "6.22", :longitude => "124.69361").save
City.new(:country_id => "179", :name => "Sariaya", :aliases => ",Sariaya", :latitude => "13.96444", :longitude => "121.53").save
City.new(:country_id => "179", :name => "San Vicente", :aliases => "San Vicente,San Vicente", :latitude => "15.29546", :longitude => "120.64653").save
City.new(:country_id => "179", :name => "Santo Tomas", :aliases => "Santo Tomas,Santo Tomas", :latitude => "14.9923", :longitude => "120.7057").save
City.new(:country_id => "179", :name => "Santo Tomas", :aliases => "Santa Tomas,Santo Tomas,Santo-Tomas,Ð¡Ð°Ð½ÑÐ¾-Ð¢Ð¾Ð¼Ð°Ñ,Santo Tomas", :latitude => "14.1079", :longitude => "121.14136").save
City.new(:country_id => "179", :name => "Santol", :aliases => ",Santol", :latitude => "15.16222", :longitude => "120.5675").save
City.new(:country_id => "179", :name => "Santiago", :aliases => ",Santiago", :latitude => "16.68808", :longitude => "121.5487").save
City.new(:country_id => "179", :name => "Santa Rosa", :aliases => ",Santa Rosa", :latitude => "14.31222", :longitude => "121.11139").save
City.new(:country_id => "179", :name => "Santa Rita", :aliases => "Santa Rita,Santa Rita", :latitude => "14.9974", :longitude => "120.6183").save
City.new(:country_id => "179", :name => "Santa Maria", :aliases => "Basiauan,Basiawan,Santa Maria,Santa Maria", :latitude => "6.55361", :longitude => "125.47083").save
City.new(:country_id => "179", :name => "Santa Cruz", :aliases => "Sant Cruz,Santa Cruz,Santa-Krus,Ð¡Ð°Ð½ÑÐ°-ÐÑÑÑ,Santa Cruz", :latitude => "15.7654", :longitude => "119.9092").save
City.new(:country_id => "179", :name => "Santa Cruz", :aliases => "Santa Cruz,Santa Cruz", :latitude => "14.9132", :longitude => "120.5626").save
City.new(:country_id => "179", :name => "Santa Cruz", :aliases => "Santa Cruz,Santa Cruz", :latitude => "14.2814", :longitude => "121.4161").save
City.new(:country_id => "179", :name => "Santa Catalina", :aliases => "Santa Catalina,Santa Catalina", :latitude => "9.3337", :longitude => "122.8637").save
City.new(:country_id => "179", :name => "Santa Barbara", :aliases => "Santa Barbara,Santa Barbara", :latitude => "16.0009", :longitude => "120.4023").save
City.new(:country_id => "179", :name => "Santa Ana", :aliases => "San Joaquin,Santa Ana,Santa-Ana,Ð¡Ð°Ð½ÑÐ°-ÐÐ½Ð°,Santa Ana", :latitude => "15.0955", :longitude => "120.767").save
City.new(:country_id => "179", :name => "San Simon", :aliases => "San Simon,San Simon", :latitude => "14.9996", :longitude => "120.7808").save
City.new(:country_id => "179", :name => "San Pedro", :aliases => "San Pedro,San Pedro", :latitude => "14.3595", :longitude => "121.0473").save
City.new(:country_id => "179", :name => "San Pascual", :aliases => "San Pascual,San Pascual", :latitude => "13.7975", :longitude => "121.03417").save
City.new(:country_id => "179", :name => "San Pablo", :aliases => "San Pablo,San Pablo City,San Pablo", :latitude => "14.06694", :longitude => "121.32583").save
City.new(:country_id => "179", :name => "San Nicolas", :aliases => "San Nicolas,San Nicolas", :latitude => "18.1725", :longitude => "120.5953").save
City.new(:country_id => "179", :name => "San Narciso", :aliases => "San Narcisco,San Narciso,San Narciso", :latitude => "15.0143", :longitude => "120.0803").save
City.new(:country_id => "179", :name => "San Miguel", :aliases => ",San Miguel", :latitude => "15.42194", :longitude => "120.60056").save
City.new(:country_id => "179", :name => "San Miguel", :aliases => "San Miguel,San Miguel", :latitude => "15.1454", :longitude => "120.9789").save
City.new(:country_id => "179", :name => "San Mateo", :aliases => "San Mateo,San Mateo", :latitude => "16.88206", :longitude => "121.58694").save
City.new(:country_id => "179", :name => "San Mateo", :aliases => "San Mateo,San Mateo", :latitude => "14.6982", :longitude => "121.1236").save
City.new(:country_id => "179", :name => "San Mariano", :aliases => ",San Mariano", :latitude => "7.5", :longitude => "126").save
City.new(:country_id => "179", :name => "San Marcelino", :aliases => "San Marcelino,San Marcelino", :latitude => "14.97418", :longitude => "120.15733").save
City.new(:country_id => "179", :name => "San Luis", :aliases => "San Luis,San Luis", :latitude => "15.0401", :longitude => "120.7883").save
City.new(:country_id => "179", :name => "San Leonardo", :aliases => "San Leonardo,San Leonardo", :latitude => "15.363", :longitude => "120.9639").save
City.new(:country_id => "179", :name => "San Jose del Monte", :aliases => ",San Jose del Monte", :latitude => "14.81389", :longitude => "121.04528").save
City.new(:country_id => "179", :name => "San Ildefonso", :aliases => "San Ildefonso,San Ildefonso", :latitude => "15.0809", :longitude => "120.941").save
City.new(:country_id => "179", :name => "San Francisco", :aliases => "Caysyan,San Francisco,San Francisco", :latitude => "15.3525", :longitude => "120.8327").save
City.new(:country_id => "179", :name => "San Francisco", :aliases => "Aurora,San Francisco", :latitude => "13.34806", :longitude => "122.52056").save
City.new(:country_id => "179", :name => "San Francisco", :aliases => "San Francisco,San Francisco", :latitude => "8.53556", :longitude => "125.95").save
City.new(:country_id => "179", :name => "San Fernando", :aliases => "San Fernando,San Fernando", :latitude => "16.61591", :longitude => "120.31663").save
City.new(:country_id => "179", :name => "San Fernando", :aliases => "San Fernando,Santo Rosario,San Fernando", :latitude => "15.0286", :longitude => "120.6898").save
City.new(:country_id => "179", :name => "San Fernando", :aliases => "San Fernando,San Fernando", :latitude => "10.1624", :longitude => "123.7076").save
City.new(:country_id => "179", :name => "San Antonio", :aliases => "San Antonio,San Antonio", :latitude => "15.3062", :longitude => "120.856").save
City.new(:country_id => "179", :name => "San Antonio", :aliases => ",San Antonio", :latitude => "14.94", :longitude => "120.14722").save
City.new(:country_id => "179", :name => "Sampaloc", :aliases => "Sampaloc,Sampalok,Sampaloc", :latitude => "14.5402", :longitude => "121.3602").save
City.new(:country_id => "179", :name => "Samal", :aliases => "Samal,Ð¡Ð°Ð¼Ð°Ð»,Samal", :latitude => "14.76778", :longitude => "120.54306").save
City.new(:country_id => "179", :name => "Samal", :aliases => "Penaplata,PeÃ±aplata,Samal,Ð¡Ð°Ð¼Ð°Ð»,Samal", :latitude => "7.07444", :longitude => "125.70833").save
City.new(:country_id => "179", :name => "Sagay", :aliases => ",Sagay", :latitude => "10.94472", :longitude => "123.42417").save
City.new(:country_id => "179", :name => "Sablayan", :aliases => "Sablayan,Sablayan", :latitude => "12.8346", :longitude => "120.769").save
City.new(:country_id => "179", :name => "Roxas", :aliases => "Roxas,Roxas", :latitude => "17.11894", :longitude => "121.62014").save
City.new(:country_id => "179", :name => "Roxas City", :aliases => "Roxas,Roxas City", :latitude => "11.58528", :longitude => "122.75111").save
City.new(:country_id => "179", :name => "Roxas", :aliases => "Barbacan,Del Pilar,New Barbacan,Roxas,Roxas", :latitude => "10.3215", :longitude => "119.3451").save
City.new(:country_id => "179", :name => "Romblon", :aliases => "Romblon,Ð Ð¾Ð¼Ð±Ð»Ð¾Ð½,Romblon", :latitude => "12.57513", :longitude => "122.27081").save
City.new(:country_id => "179", :name => "Rizal", :aliases => "Nazaret,Rizal,Rizel,Ð Ð¸Ð·Ð°Ð»,Rizal", :latitude => "15.7118", :longitude => "121.1061").save
City.new(:country_id => "179", :name => "Recodo", :aliases => ",Recodo", :latitude => "6.95194", :longitude => "121.96361").save
City.new(:country_id => "179", :name => "Ramos", :aliases => "Bani,Ramos,Ramos", :latitude => "15.6653", :longitude => "120.6406").save
City.new(:country_id => "179", :name => "Ramon", :aliases => "Ramon,Ð Ð°Ð¼Ð¾Ð½,Ramon", :latitude => "16.78416", :longitude => "121.53504").save
City.new(:country_id => "179", :name => "Quezon", :aliases => "Keson-Siti,Quezon,ÐÐµÑÐ¾Ð½-Ð¡Ð¸ÑÐ¸,Quezon", :latitude => "15.5512", :longitude => "120.8147").save
City.new(:country_id => "179", :name => "Quezon", :aliases => "Keson,Kiokong,Quezon,ÐÐµÑÐ¾Ð½,Quezon", :latitude => "7.73028", :longitude => "125.09889").save
City.new(:country_id => "179", :name => "Pulupandan", :aliases => "Palupandan,Puhipandan,Pulupandan,Pulupandan", :latitude => "10.5203", :longitude => "122.8017").save
City.new(:country_id => "179", :name => "Pulilan", :aliases => "Pulilan,Pulilan", :latitude => "14.90167", :longitude => "120.84917").save
City.new(:country_id => "179", :name => "Puerto Princesa", :aliases => "Lungsod ng Puerto Princesa,Puerta Princesa,Puerto Princesa,Puerto Princesa City,Syudad han Puerto Princesa,pu lin sai sa gang,ÐÑÐµÑÑÐ¾ ÐÑÐ¸Ð½ÑÐµÑÐ°,æ®æå¡è©æ¸¯,Puerto Princesa", :latitude => "9.73917", :longitude => "118.73528").save
City.new(:country_id => "179", :name => "Porac", :aliases => "Porac,Porach,ÐÐ¾ÑÐ°Ñ,Porac", :latitude => "15.0711", :longitude => "120.5423").save
City.new(:country_id => "179", :name => "Polomolok", :aliases => "Polomoloc,Polomolok,Polomolok", :latitude => "6.22167", :longitude => "125.06398").save
City.new(:country_id => "179", :name => "Plaridel", :aliases => "Plaridel,Quingua,Quinqua,Plaridel", :latitude => "14.88722", :longitude => "120.85722").save
City.new(:country_id => "179", :name => "Pio", :aliases => "Pio,Pio", :latitude => "15.0466", :longitude => "120.5181").save
City.new(:country_id => "179", :name => "Pinamungahan", :aliases => "Pihamungajan,Pinamangajan,Pinamangayan,Pinamungahan,Pinamungajan,Pinamunganjan,Pinamungahan", :latitude => "10.2708", :longitude => "123.5839").save
City.new(:country_id => "179", :name => "Pinamalayan", :aliases => "Pinamalayan,Wawa,Pinamalayan", :latitude => "13.0357", :longitude => "121.48842").save
City.new(:country_id => "179", :name => "Pililla", :aliases => "Pililla,Pililla", :latitude => "14.4854", :longitude => "121.3062").save
City.new(:country_id => "179", :name => "Pili", :aliases => "Pili,Pili", :latitude => "13.5572", :longitude => "123.2735").save
City.new(:country_id => "179", :name => "Pilar", :aliases => "Pilar,Pilar", :latitude => "14.66", :longitude => "120.56528").save
City.new(:country_id => "179", :name => "Pila", :aliases => "Pila,Pily,ÐÐ¸Ð»Ñ,Pila", :latitude => "14.2325", :longitude => "121.3648").save
City.new(:country_id => "179", :name => "Penaranda", :aliases => "Pen'jaranda,Penaranda,PeÃ±aranda,ÐÐµÐ½ÑÑÑÐ°Ð½Ð´Ð°,PeÃ±aranda", :latitude => "15.35116", :longitude => "121.00393").save
City.new(:country_id => "179", :name => "Patuto", :aliases => ",Patuto", :latitude => "14.11667", :longitude => "120.96667").save
City.new(:country_id => "179", :name => "Passi", :aliases => ",Passi", :latitude => "11.10778", :longitude => "122.64194").save
City.new(:country_id => "179", :name => "Parang", :aliases => ",Parang", :latitude => "7.37035", :longitude => "124.26973").save
City.new(:country_id => "179", :name => "Paraiso", :aliases => ",Paraiso", :latitude => "10.88333", :longitude => "123.36667").save
City.new(:country_id => "179", :name => "Paombong", :aliases => "Paombong,Paonbong,Paombong", :latitude => "14.83111", :longitude => "120.78917").save
City.new(:country_id => "179", :name => "Pantukan", :aliases => "Kingking,Pantukan,Pantukan", :latitude => "7.13528", :longitude => "125.88972").save
City.new(:country_id => "179", :name => "Pantubig", :aliases => "Pantubig,Puting Tubig,Pantubig", :latitude => "14.96806", :longitude => "120.95472").save
City.new(:country_id => "179", :name => "Paniqui", :aliases => "Paniqui,Paniqui", :latitude => "15.6689", :longitude => "120.5806").save
City.new(:country_id => "179", :name => "Pangil", :aliases => "Pangil,Pangil", :latitude => "14.4008", :longitude => "121.4685").save
City.new(:country_id => "179", :name => "Pandi", :aliases => "Panda,Pandi,ÐÐ°Ð½Ð´Ð°,Pandi", :latitude => "14.865", :longitude => "120.95722").save
City.new(:country_id => "179", :name => "Pandacaqui", :aliases => "Pandacaqui,Pandakaki,Pandacaqui", :latitude => "15.1835", :longitude => "120.6455").save
City.new(:country_id => "179", :name => "Panalanoy", :aliases => ",Panalanoy", :latitude => "11.25111", :longitude => "125.00639").save
City.new(:country_id => "179", :name => "Panabo", :aliases => ",Panabo", :latitude => "7.30806", :longitude => "125.68417").save
City.new(:country_id => "179", :name => "Palo", :aliases => "Palo,Polo,Palo", :latitude => "11.1575", :longitude => "124.99083").save
City.new(:country_id => "179", :name => "Palayan City", :aliases => "Palayan,Palayan City", :latitude => "15.54139", :longitude => "121.08611").save
City.new(:country_id => "179", :name => "Pagbilao", :aliases => ",Pagbilao", :latitude => "13.975", :longitude => "121.69194").save
City.new(:country_id => "179", :name => "Paete", :aliases => "Paete,Paete", :latitude => "14.3647", :longitude => "121.4829").save
City.new(:country_id => "179", :name => "Pacol", :aliases => ",Pacol", :latitude => "10.45", :longitude => "122.81667").save
City.new(:country_id => "179", :name => "Ozamis", :aliases => "Ozamis City,Ozamiz,Ozamis", :latitude => "8.14583", :longitude => "123.84444").save
City.new(:country_id => "179", :name => "Oroquieta", :aliases => "Oroguieta,Oroquieta City,Oroquieta", :latitude => "8.48583", :longitude => "123.80444").save
City.new(:country_id => "179", :name => "Ormoc", :aliases => "Ciudad ti Ormoc,Dakbayan sa Ormoc,MacArthur,Ormco,Ormoc,Ormoc City,Oromoc,Syudad han Ormoc,Ormoc", :latitude => "11.00639", :longitude => "124.6075").save
City.new(:country_id => "179", :name => "Orion", :aliases => "Orion,ÐÑÐ¸Ð¾Ð½,Orion", :latitude => "14.62056", :longitude => "120.58167").save
City.new(:country_id => "179", :name => "Orani", :aliases => "Orani,Orani", :latitude => "14.8006", :longitude => "120.5371").save
City.new(:country_id => "179", :name => "Olongapo", :aliases => "Ciudad ti Olongapo,Olongapo,Olongapo City,OlÃ³ngapo,Olongapo", :latitude => "14.82917", :longitude => "120.28278").save
City.new(:country_id => "179", :name => "Obando", :aliases => "Obando,Obando", :latitude => "14.7098", :longitude => "120.9362").save
City.new(:country_id => "179", :name => "Noveleta", :aliases => ",Noveleta", :latitude => "14.43194", :longitude => "120.88028").save
City.new(:country_id => "179", :name => "Norzagaray", :aliases => "Norzagaray,Norzugaray,Norzagaray", :latitude => "14.9109", :longitude => "121.0493").save
City.new(:country_id => "179", :name => "New Corella", :aliases => "New Corella,New Corella", :latitude => "7.5866", :longitude => "125.8237").save
City.new(:country_id => "179", :name => "Nasugbu", :aliases => "Nasugbu,Nasugbu", :latitude => "14.0722", :longitude => "120.6332").save
City.new(:country_id => "179", :name => "Narra", :aliases => "Narra,Narra", :latitude => "9.26877", :longitude => "118.4043").save
City.new(:country_id => "179", :name => "Naic", :aliases => ",Naic", :latitude => "14.32028", :longitude => "120.7675").save
City.new(:country_id => "179", :name => "Nagcarlan", :aliases => "Nagcarlan,Nagcarlan", :latitude => "14.1364", :longitude => "121.4165").save
City.new(:country_id => "179", :name => "Naga", :aliases => "Naga City,Nagi,ÐÐ°Ð³Ð¸,Naga", :latitude => "13.61917", :longitude => "123.18139").save
City.new(:country_id => "179", :name => "Naga", :aliases => "Naga,Naga", :latitude => "10.20898", :longitude => "123.758").save
City.new(:country_id => "179", :name => "Nabunturan", :aliases => ",Nabunturan", :latitude => "7.60778", :longitude => "125.96639").save
City.new(:country_id => "179", :name => "Nabua", :aliases => "Nabua,Nabua", :latitude => "13.4075", :longitude => "123.3724").save
City.new(:country_id => "179", :name => "Muricay", :aliases => "Muricay,Muricay", :latitude => "7.8275", :longitude => "123.4782").save
City.new(:country_id => "179", :name => "Murcia", :aliases => "Murcia,Murcia", :latitude => "10.60516", :longitude => "123.0417").save
City.new(:country_id => "179", :name => "Munoz", :aliases => ",MuÃ±oz", :latitude => "15.71611", :longitude => "120.90306").save
City.new(:country_id => "179", :name => "Morong", :aliases => "Moron,Morong,ÐÐ¾ÑÐ¾Ð½Ð³,Morong", :latitude => "14.67889", :longitude => "120.26611").save
City.new(:country_id => "179", :name => "Morong", :aliases => "Morong,ÐÐ¾ÑÐ¾Ð½Ð³,Morong", :latitude => "14.5115", :longitude => "121.2393").save
City.new(:country_id => "179", :name => "Rodriguez", :aliases => "Montalban,Rodriges,Rodriguez,Ð Ð¾Ð´ÑÐ¸Ð³ÐµÑ,Rodriguez", :latitude => "14.7314", :longitude => "121.1417").save
City.new(:country_id => "179", :name => "Monkayo", :aliases => "Moncayo,Monkayo,Monkayo", :latitude => "7.81528", :longitude => "126.05444").save
City.new(:country_id => "179", :name => "Molave", :aliases => "Molave,Molave", :latitude => "8.0844", :longitude => "123.491").save
City.new(:country_id => "179", :name => "Minglanilla", :aliases => "Minglanilla,Minglanilla", :latitude => "10.24498", :longitude => "123.7964").save
City.new(:country_id => "179", :name => "Midsayap", :aliases => ",Midsayap", :latitude => "7.19083", :longitude => "124.53028").save
City.new(:country_id => "179", :name => "Meycauayan", :aliases => "Meycauayan,Meycawayan,Meycauayan", :latitude => "14.73694", :longitude => "120.96083").save
City.new(:country_id => "179", :name => "Mexico", :aliases => "Mexico,Mexico", :latitude => "15.0646", :longitude => "120.7198").save
City.new(:country_id => "179", :name => "Mercedes", :aliases => "Mercedes,Meredes,Mercedes", :latitude => "14.1093", :longitude => "123.0109").save
City.new(:country_id => "179", :name => "Mendez-Nunez", :aliases => "Mendez,Mendez-Nunez,Mendez-NuÃ±ez,Mendez-NuÃ±ez", :latitude => "14.12861", :longitude => "120.90583").save
City.new(:country_id => "179", :name => "Mauban", :aliases => ",Mauban", :latitude => "14.19111", :longitude => "121.73111").save
City.new(:country_id => "179", :name => "Mati", :aliases => "Mati,ÐÐ°ÑÐ¸,Mati", :latitude => "6.95508", :longitude => "126.21655").save
City.new(:country_id => "179", :name => "Masinloc", :aliases => "Masinloc,Masinloc", :latitude => "15.5363", :longitude => "119.9502").save
City.new(:country_id => "179", :name => "Masbate", :aliases => ",Masbate", :latitude => "12.36667", :longitude => "123.61667").save
City.new(:country_id => "179", :name => "Masantol", :aliases => "Masantol,Masantol", :latitude => "14.896", :longitude => "120.7092").save
City.new(:country_id => "179", :name => "Mariveles", :aliases => "Mariveles,Mariveles", :latitude => "14.4361", :longitude => "120.4857").save
City.new(:country_id => "179", :name => "Marilao", :aliases => "Marilao,ÐÐ°ÑÐ¸Ð»Ð°Ð¾,Marilao", :latitude => "14.75778", :longitude => "120.94833").save
City.new(:country_id => "179", :name => "Mariano", :aliases => ",Mariano", :latitude => "8.83333", :longitude => "125.11667").save
City.new(:country_id => "179", :name => "Marawi City", :aliases => "City of Dansalan,Dansalan,Dansalan City,Maraur,Marawi,Marawi City", :latitude => "8", :longitude => "124.28333").save
City.new(:country_id => "179", :name => "Marawi", :aliases => "Dansalan,Maravi,Marawi City,ÐÐ°ÑÐ°Ð²Ð¸,Marawi", :latitude => "7.99861", :longitude => "124.29278").save
City.new(:country_id => "179", :name => "Maramag", :aliases => "Maramag,Maramag", :latitude => "7.76333", :longitude => "125.00528").save
City.new(:country_id => "179", :name => "Maragondon", :aliases => "Maragandon,Maragondon,Maragondon", :latitude => "14.2733", :longitude => "120.7377").save
City.new(:country_id => "179", :name => "Mantampay", :aliases => ",Mantampay", :latitude => "8.16667", :longitude => "124.21667").save
City.new(:country_id => "179", :name => "Mansilingan", :aliases => ",Mansilingan", :latitude => "10.63111", :longitude => "122.97889").save
City.new(:country_id => "179", :name => "Mansalay", :aliases => "Bulalacao,Mansalay,Mansalay", :latitude => "12.52044", :longitude => "121.43851").save
City.new(:country_id => "179", :name => "Manolo Fortich", :aliases => "Manolo Fortich,Manolo Fortich", :latitude => "8.36972", :longitude => "124.86444").save
City.new(:country_id => "179", :name => "Manila", :aliases => "Manila,Manilla,Manille,Manilo,ManÃ­la,Maynila,Menila,ma ni la,manila,manilla,manira,manyla,mnila,mnylh,myanila,ÎÎ±Î½Î¯Î»Î±,ÐÐ°Ð½Ð¸Ð»Ð°,×× ×××,ÙØ§ÙÙÙØ§,ÙØ§ÙÙÙØ§,à¦®à§à¦¯à¦¾à¦¨à¦¿à¦²à¦¾,à®®à®£à®¿à®²à®¾,à¸¡à¸à¸´à¸¥à¸²,à¸¡à¸°à¸à¸´à¸¥à¸²,ááá,ããã©,é©¬å°¼æ,ë§ëë¼,Manila", :latitude => "14.6042", :longitude => "120.9822").save
City.new(:country_id => "179", :name => "Manibaug", :aliases => "Manibaug,Manibaug Pasig,Manibaug", :latitude => "15.1012", :longitude => "120.5604").save
City.new(:country_id => "179", :name => "Mangaldan", :aliases => "Mangaldan,Mangaldan", :latitude => "16.07", :longitude => "120.4025").save
City.new(:country_id => "179", :name => "Mandaue City", :aliases => ",Mandaue City", :latitude => "10.32361", :longitude => "123.92222").save
City.new(:country_id => "179", :name => "Mankayan", :aliases => "Mancayan,Mankayan,Mankayan", :latitude => "16.8632", :longitude => "120.7829").save
City.new(:country_id => "179", :name => "Manay", :aliases => "Manay,Manay", :latitude => "7.215", :longitude => "126.53972").save
City.new(:country_id => "179", :name => "Manapla", :aliases => "Manapala,Manapla,Manapla", :latitude => "10.95803", :longitude => "123.123").save
City.new(:country_id => "179", :name => "Manaoag", :aliases => "Manaoag,Manaoag", :latitude => "16.0438", :longitude => "120.4861").save
City.new(:country_id => "179", :name => "Mamburao", :aliases => "Mambulao,Mamburao,Mamburao", :latitude => "13.2233", :longitude => "120.596").save
City.new(:country_id => "179", :name => "Mamatid", :aliases => ",Mamatid", :latitude => "14.23417", :longitude => "121.15806").save
City.new(:country_id => "179", :name => "Malvar", :aliases => "Malvar,Malvar", :latitude => "14.04472", :longitude => "121.15861").save
City.new(:country_id => "179", :name => "Maluso", :aliases => "Maluso,Maluso", :latitude => "6.543", :longitude => "121.8753").save
City.new(:country_id => "179", :name => "Malungun", :aliases => "Malungon,Malungun,MaluÃ±gun,MaluÃ±gun", :latitude => "6.27917", :longitude => "125.28167").save
City.new(:country_id => "179", :name => "Malolos", :aliases => "Malalos,Malolas,Malolos,Malolos", :latitude => "14.84194", :longitude => "120.81167").save
City.new(:country_id => "179", :name => "Malita", :aliases => "Malit,Malita,Malita", :latitude => "6.415", :longitude => "125.61167").save
City.new(:country_id => "179", :name => "Malilipot", :aliases => "Malilipot,Malilipot", :latitude => "13.3188", :longitude => "123.7385").save
City.new(:country_id => "179", :name => "Malaybalay", :aliases => ",Malaybalay", :latitude => "8.15", :longitude => "125.08333").save
City.new(:country_id => "179", :name => "Malapatan", :aliases => "Malapatan,Malapatan", :latitude => "5.96917", :longitude => "125.28944").save
City.new(:country_id => "179", :name => "Malanday", :aliases => "Malanday,Malanday", :latitude => "14.7069", :longitude => "121.1306").save
City.new(:country_id => "179", :name => "Malabanban", :aliases => ",Malabanban", :latitude => "13.93333", :longitude => "121.46667").save
City.new(:country_id => "179", :name => "Mahayag", :aliases => "Mahayag,Mahayag", :latitude => "8.1183", :longitude => "123.4455").save
City.new(:country_id => "179", :name => "Magsaysay", :aliases => "Magsaysay,Magsaysay", :latitude => "6.76667", :longitude => "125.18333").save
City.new(:country_id => "179", :name => "Magarao", :aliases => "Magarao,Magarao", :latitude => "13.6604", :longitude => "123.1869").save
City.new(:country_id => "179", :name => "Maganoy", :aliases => "Maganai,Maganoy,Maganui,Maganuy,Magonay,Maganoy", :latitude => "6.86472", :longitude => "124.44167").save
City.new(:country_id => "179", :name => "Magalang", :aliases => "Magalan,Magalang,Magalang", :latitude => "15.2151", :longitude => "120.6596").save
City.new(:country_id => "179", :name => "Mabalacat", :aliases => "Mabalacat,Mabalacat", :latitude => "15.2216", :longitude => "120.5736").save
City.new(:country_id => "179", :name => "Maasin", :aliases => "Maasin,Massin,Maasin", :latitude => "10.13361", :longitude => "124.84472").save
City.new(:country_id => "179", :name => "Ma-ao", :aliases => "Ma-ao Barrio,Ma-ao", :latitude => "10.48333", :longitude => "122.98333").save
City.new(:country_id => "179", :name => "Lupon", :aliases => "Lupon,Sumlog,Lupon", :latitude => "6.89814", :longitude => "126.00961").save
City.new(:country_id => "179", :name => "Lumbang", :aliases => "Lumban,Lumbang,Lumbang", :latitude => "14.2973", :longitude => "121.4598").save
City.new(:country_id => "179", :name => "Lucena", :aliases => "Ciudad ti Lucena,Lucena,Lucena City,Lucena", :latitude => "13.93139", :longitude => "121.61722").save
City.new(:country_id => "179", :name => "Lucban", :aliases => ",Lucban", :latitude => "14.11333", :longitude => "121.55694").save
City.new(:country_id => "179", :name => "Lubao", :aliases => "Lubao,Lubao", :latitude => "14.9405", :longitude => "120.6011").save
City.new(:country_id => "179", :name => "Los Banos", :aliases => "Los Banos,Los BaÃ±os,Los-Ban'os,ÐÐ¾Ñ-ÐÐ°Ð½ÑÐ¾Ñ,Los BaÃ±os", :latitude => "14.1798", :longitude => "121.2234").save
City.new(:country_id => "179", :name => "Lopez", :aliases => ",Lopez", :latitude => "13.88444", :longitude => "122.26417").save
City.new(:country_id => "179", :name => "Loma de Gato", :aliases => ",Loma de Gato", :latitude => "14.78333", :longitude => "121").save
City.new(:country_id => "179", :name => "Lipa", :aliases => "Ciudad ti Lipa,Lipa,Lipa City,ÐÐ¸Ð¿Ð°,Lipa", :latitude => "13.93944", :longitude => "121.17389").save
City.new(:country_id => "179", :name => "Lingayen", :aliases => "Lingayen,Lingayen", :latitude => "16.02182", :longitude => "120.23194").save
City.new(:country_id => "179", :name => "Limay", :aliases => "Limay,Limay", :latitude => "14.56194", :longitude => "120.59833").save
City.new(:country_id => "179", :name => "Liloan", :aliases => "Liloan,Liloan", :latitude => "10.3991", :longitude => "123.9992").save
City.new(:country_id => "179", :name => "Lilio", :aliases => "Lilio,Liliw,Lilio", :latitude => "14.1313", :longitude => "121.4362").save
City.new(:country_id => "179", :name => "Libertad", :aliases => ",Libertad", :latitude => "8.94417", :longitude => "125.50194").save
City.new(:country_id => "179", :name => "Legaspi", :aliases => "Legaspi City,Legazpi,Legazpi City,Legaspi", :latitude => "13.13722", :longitude => "123.73444").save
City.new(:country_id => "179", :name => "Laur", :aliases => "Laur,San Estaban,Laur", :latitude => "15.5865", :longitude => "121.1834").save
City.new(:country_id => "179", :name => "La Trinidad", :aliases => "La Trinidad,La-Trinidad,Trinidad,ÐÐ°-Ð¢ÑÐ¸Ð½Ð¸Ð´Ð°Ð´,La Trinidad", :latitude => "16.455", :longitude => "120.5875").save
City.new(:country_id => "179", :name => "Lapu-Lapu City", :aliases => "Ciudad ti Lapu-Lapu,Dakbayan sa Lapu-Lapu,Lapu-Lapu,Lapu-Lapu City,Opon,la pu la pu shi,ã©ãã»ã©ãå¸,ææ®ææ®å¸,Lapu-Lapu City", :latitude => "10.31028", :longitude => "123.94944").save
City.new(:country_id => "179", :name => "La Paz", :aliases => "La Paz,La-Pas,ÐÐ°-ÐÐ°Ñ,La Paz", :latitude => "15.44125", :longitude => "120.72863").save
City.new(:country_id => "179", :name => "Laoang", :aliases => "Laoang,Loangan,Laoang", :latitude => "12.5698", :longitude => "125.0141").save
City.new(:country_id => "179", :name => "Laoag", :aliases => "Laoag City,Laoang,Laog,Loag,Laoag", :latitude => "18.19889", :longitude => "120.59361").save
City.new(:country_id => "179", :name => "Lala", :aliases => "Lala,Lala", :latitude => "7.9745", :longitude => "123.7458").save
City.new(:country_id => "179", :name => "Laguilayan", :aliases => ",Laguilayan", :latitude => "6.6525", :longitude => "124.52111").save
City.new(:country_id => "179", :name => "La Castellana", :aliases => "La Castellana,La Castellana", :latitude => "10.3239", :longitude => "123.0215").save
City.new(:country_id => "179", :name => "La Carlota", :aliases => "La Calota,La Carlota City,La-Karlota,ÐÐ°-ÐÐ°ÑÐ»Ð¾ÑÐ°,La Carlota", :latitude => "10.42333", :longitude => "122.92083").save
City.new(:country_id => "179", :name => "Labo", :aliases => "Labo,Labo", :latitude => "14.1532", :longitude => "122.8303").save
City.new(:country_id => "179", :name => "Koronadal", :aliases => "Koronadal,Marbel,Koronadal", :latitude => "6.50306", :longitude => "124.84694").save
City.new(:country_id => "179", :name => "Kidapawan", :aliases => "Kadapawan,Kidapawan,Kidapawan", :latitude => "7.00833", :longitude => "125.08944").save
City.new(:country_id => "179", :name => "Kawit", :aliases => ",Kawit", :latitude => "14.44556", :longitude => "120.905").save
City.new(:country_id => "179", :name => "Kalibo (poblacion)", :aliases => "Banwa it Kalibo,Kalibo Town,Pueblo de Calivo,Kalibo (poblacion)", :latitude => "11.70611", :longitude => "122.36444").save
City.new(:country_id => "179", :name => "Kabankalan", :aliases => ",Kabankalan", :latitude => "9.98889", :longitude => "122.81222").save
City.new(:country_id => "179", :name => "Kabacan", :aliases => "Kabacan,Kabakan,Kabacan", :latitude => "7.10667", :longitude => "124.82917").save
City.new(:country_id => "179", :name => "Jose Panganiban", :aliases => "Jose Panganiban,Jose PaÃ±ganiban,Mambulao,Jose PaÃ±ganiban", :latitude => "14.2906", :longitude => "122.6917").save
City.new(:country_id => "179", :name => "Jolo", :aliases => "Dzholi,Jolo,Sug,Sulu,Suluk,ÐÐ¶Ð¾Ð»Ð¸,Jolo", :latitude => "6.05222", :longitude => "121.00222").save
City.new(:country_id => "179", :name => "Jasaan", :aliases => "Hasaan,Jasaan,Jasaan", :latitude => "8.65417", :longitude => "124.75556").save
City.new(:country_id => "179", :name => "Jalajala", :aliases => "Jalajala,Jalajala", :latitude => "14.353", :longitude => "121.3225").save
City.new(:country_id => "179", :name => "Jaen", :aliases => "Jaen,Khaehn,Ð¥Ð°ÑÐ½,Jaen", :latitude => "15.3275", :longitude => "120.9192").save
City.new(:country_id => "179", :name => "Itogon", :aliases => "Itogon,Itogon", :latitude => "16.36389", :longitude => "120.67694").save
City.new(:country_id => "179", :name => "Isulan", :aliases => "Isulan,Kalawag,Isulan", :latitude => "6.62944", :longitude => "124.605").save
City.new(:country_id => "179", :name => "Isabela", :aliases => "Isabela,Isabella,Izabela,ÐÐ·Ð°Ð±ÐµÐ»Ð°,Isabela", :latitude => "10.2048", :longitude => "122.9888").save
City.new(:country_id => "179", :name => "Isabela", :aliases => "Basilan,Basilan City,Isabel,Isabela,Izabela,ÐÐ·Ð°Ð±ÐµÐ»Ð°,Isabela", :latitude => "6.7085", :longitude => "121.9711").save
City.new(:country_id => "179", :name => "Irosin", :aliases => "Irosin,Irosin", :latitude => "12.7026", :longitude => "124.0362").save
City.new(:country_id => "179", :name => "Iriga", :aliases => "Iriga City,Iriga", :latitude => "13.425", :longitude => "123.41778").save
City.new(:country_id => "179", :name => "Ipil", :aliases => "Ipil,Sanito,Tayun,Ipil", :latitude => "7.78444", :longitude => "122.58611").save
City.new(:country_id => "179", :name => "Indang", :aliases => ",Indang", :latitude => "14.19528", :longitude => "120.87694").save
City.new(:country_id => "179", :name => "Imus", :aliases => ",Imus", :latitude => "14.42972", :longitude => "120.93667").save
City.new(:country_id => "179", :name => "Iloilo", :aliases => "Iloilo,Iloilo City,Iloilo Proper,ÐÐ»Ð¾Ð¸Ð»Ð¾,Iloilo", :latitude => "10.69694", :longitude => "122.56444").save
City.new(:country_id => "179", :name => "Iligan City", :aliases => "City of Iligan,Idigan,Iligan,Iligan City", :latitude => "8.25", :longitude => "124.4").save
City.new(:country_id => "179", :name => "Ilagan", :aliases => "Ilagan,Ilagan", :latitude => "17.14854", :longitude => "121.88924").save
City.new(:country_id => "179", :name => "Iba", :aliases => "Iba,Ibra,ÐÐ±ÑÐ°,Iba", :latitude => "15.3276", :longitude => "119.978").save
City.new(:country_id => "179", :name => "Hinigaran", :aliases => "Hinigaran,Hinigaran", :latitude => "10.2706", :longitude => "122.8507").save
City.new(:country_id => "179", :name => "Himamaylan", :aliases => ",Himamaylan", :latitude => "10.09889", :longitude => "122.87056").save
City.new(:country_id => "179", :name => "Hermosa", :aliases => "Ehrmosa,Hermosa,Ð­ÑÐ¼Ð¾ÑÐ°,Hermosa", :latitude => "14.8314", :longitude => "120.5081").save
City.new(:country_id => "179", :name => "Hagunoy", :aliases => "Hagonoy,Hagony,Hagunoy,Hagunoy", :latitude => "14.8321", :longitude => "120.7336").save
City.new(:country_id => "179", :name => "Guyong", :aliases => ",Guyong", :latitude => "14.83861", :longitude => "120.97972").save
City.new(:country_id => "179", :name => "Gumaca", :aliases => ",Gumaca", :latitude => "13.91972", :longitude => "122.10028").save
City.new(:country_id => "179", :name => "Guiset East", :aliases => "Guiset,Guiset East,Guiset Este,Guiset Sur,Guiset East", :latitude => "16.06667", :longitude => "120.68333").save
City.new(:country_id => "179", :name => "Guimba", :aliases => "Guimba,Guimba", :latitude => "15.6605", :longitude => "120.7683").save
City.new(:country_id => "179", :name => "Guihulngan", :aliases => "Gihulngan,Guihulngan,GuihulÃ±gan,Guilhulngan,Gulhulngan,GuihulÃ±gan", :latitude => "10.1214", :longitude => "123.2742").save
City.new(:country_id => "179", :name => "Guiguinto", :aliases => "Guiguinto,Guiguinto", :latitude => "14.83333", :longitude => "120.88333").save
City.new(:country_id => "179", :name => "Goa", :aliases => "Goa,ÐÐ¾Ð°,Goa", :latitude => "13.6978", :longitude => "123.4892").save
City.new(:country_id => "179", :name => "Glan", :aliases => "Glan,Glan-Townsite,ÐÐ»Ð°Ð½,Glan", :latitude => "5.82417", :longitude => "125.20333").save
City.new(:country_id => "179", :name => "Gerona", :aliases => "Gerona,Zherona,ÐÐµÑÐ¾Ð½Ð°,Gerona", :latitude => "15.6065", :longitude => "120.5978").save
City.new(:country_id => "179", :name => "General Trias", :aliases => ",General Trias", :latitude => "14.38694", :longitude => "120.88167").save
City.new(:country_id => "179", :name => "General Tinio", :aliases => "General Tinio,Papaya,General Tinio", :latitude => "15.35076", :longitude => "121.04773").save
City.new(:country_id => "179", :name => "General Natividad", :aliases => "General Mamerto Natividad,General Natividad,Natividad,General Natividad", :latitude => "15.6025", :longitude => "121.0515").save
City.new(:country_id => "179", :name => "Gapan", :aliases => "Capan,Gapan,Gapan", :latitude => "15.3072", :longitude => "120.9464").save
City.new(:country_id => "179", :name => "Escalante", :aliases => ",Escalante", :latitude => "10.84028", :longitude => "123.49917").save
City.new(:country_id => "179", :name => "Saravia", :aliases => "Enrique B. Magalona,Saravia,Saravia", :latitude => "10.87754", :longitude => "122.9677").save
City.new(:country_id => "179", :name => "Dumaguete", :aliases => "Ciudad ti Dumaguete,Dumageute,Dumaguete,Dumaguete City,do~umagete,ãã¥ãã²ã,Dumaguete", :latitude => "9.31028", :longitude => "123.30806").save
City.new(:country_id => "179", :name => "Don Carlos", :aliases => "Don Carlos,Don Carlos", :latitude => "7.68", :longitude => "125.005").save
City.new(:country_id => "179", :name => "Domalanoan", :aliases => "Damaloguen,Domalandan,Domalanoan,Dumalandan,Domalanoan", :latitude => "16.00292", :longitude => "120.21154").save
City.new(:country_id => "179", :name => "Dologon", :aliases => "Dologon,Dulogan,Dulugon,Dologon", :latitude => "7.84083", :longitude => "125.04444").save
City.new(:country_id => "179", :name => "Dipolog", :aliases => "Dipolog City,Dipolog", :latitude => "8.58944", :longitude => "123.34139").save
City.new(:country_id => "179", :name => "Dinalupihan", :aliases => "Dinalupian,Dinalupihan,Dinalupihari,Dinalupinan,Dinalupihan", :latitude => "14.8732", :longitude => "120.4651").save
City.new(:country_id => "179", :name => "Digos", :aliases => ",Digos", :latitude => "6.74972", :longitude => "125.35722").save
City.new(:country_id => "179", :name => "Del Pilar", :aliases => ",Del Pilar", :latitude => "15.03333", :longitude => "120.7").save
City.new(:country_id => "179", :name => "Davao", :aliases => "Central,Davao,Davao City,ÐÐ°Ð²Ð°Ð¾,Davao", :latitude => "7.07306", :longitude => "125.61278").save
City.new(:country_id => "179", :name => "Dasmarinas", :aliases => "Dasmarinas,Dasmarines,DasmariÃ±as,DasmariÃ±as", :latitude => "14.32944", :longitude => "120.93667").save
City.new(:country_id => "179", :name => "Dapitan", :aliases => "Dapitan,Dapitan City,ÐÐ°Ð¿Ð¸ÑÐ°Ð½,Dapitan", :latitude => "8.64639", :longitude => "123.42083").save
City.new(:country_id => "179", :name => "Danao", :aliases => "Danao City,Idanao,Danao", :latitude => "10.52083", :longitude => "124.02722").save
City.new(:country_id => "179", :name => "Daet", :aliases => "Daet,ÐÐ°ÐµÑ,Daet", :latitude => "14.1122", :longitude => "122.9553").save
City.new(:country_id => "179", :name => "Cuenca", :aliases => "Cuenca,Kuehnka,ÐÑÑÐ½ÐºÐ°,Cuenca", :latitude => "13.902", :longitude => "121.0521").save
City.new(:country_id => "179", :name => "Cotabato", :aliases => "Catabate,Catabato,Cotabato,Cotabato City,Cottabato,Dakbayan sa Cotabato,Kota-Bato,Kotabato,kotabato shi,ÐÐ¾ÑÐ°Ð±Ð°ÑÐ¾,ã³ã¿ããå¸,Cotabato", :latitude => "7.22361", :longitude => "124.24639").save
City.new(:country_id => "179", :name => "Cordova", :aliases => "Cordoba,Cordova,Kordoba,ÐÐ¾ÑÐ´Ð¾Ð±Ð°,Cordova", :latitude => "10.25194", :longitude => "123.94944").save
City.new(:country_id => "179", :name => "Consolacion", :aliases => "Consolacion,Consolation,Consolacion", :latitude => "10.3766", :longitude => "123.9573").save
City.new(:country_id => "179", :name => "Concepcion", :aliases => "Concepcion,Conception,Konseps'on,ÐÐ¾Ð½ÑÐµÐ¿ÑÑÐ¾Ð½,Concepcion", :latitude => "15.32546", :longitude => "120.65723").save
City.new(:country_id => "179", :name => "Concepcion Ibaba", :aliases => "Concepcion,Concepcion Ibaba", :latitude => "13.92667", :longitude => "121.49333").save
City.new(:country_id => "179", :name => "Compostela", :aliases => "Compostela,Compostela", :latitude => "10.455", :longitude => "124.0106").save
City.new(:country_id => "179", :name => "Compostela", :aliases => ",Compostela", :latitude => "7.67306", :longitude => "126.08889").save
City.new(:country_id => "179", :name => "Cebu City", :aliases => "Cebu,Dakbayan sa Sugbo,Sebu,Ð¡ÐµÐ±Ñ,Cebu City", :latitude => "10.31672", :longitude => "123.89071").save
City.new(:country_id => "179", :name => "Cavite", :aliases => "Cavite City,Kavite,ÐÐ°Ð²Ð¸ÑÐµ,Cavite", :latitude => "14.4825", :longitude => "120.91694").save
City.new(:country_id => "179", :name => "Catbalogan", :aliases => "Catbalogan,Catbalogan", :latitude => "11.77528", :longitude => "124.88611").save
City.new(:country_id => "179", :name => "Catarman", :aliases => "Catarman,Catarman", :latitude => "12.4989", :longitude => "124.6377").save
City.new(:country_id => "179", :name => "Catanauan", :aliases => "Catanuan,Catanauan", :latitude => "13.59194", :longitude => "122.32306").save
City.new(:country_id => "179", :name => "Castillejos", :aliases => "Caslillejos,Castillejos,Kastil'ekhosu,ÐÐ°ÑÑÐ¸Ð»ÑÐµÑÐ¾ÑÑ,Castillejos", :latitude => "14.93039", :longitude => "120.20143").save
City.new(:country_id => "179", :name => "Carmona", :aliases => "Carmona,Carmona", :latitude => "14.3132", :longitude => "121.0576").save
City.new(:country_id => "179", :name => "Cogan", :aliases => "Carmen,Cogan,Karmen,Old Carmen,ÐÐ°ÑÐ¼ÐµÐ½,Cogan", :latitude => "10.59306", :longitude => "124.01778").save
City.new(:country_id => "179", :name => "Carigara", :aliases => "Carigara,Garigara,Carigara", :latitude => "11.29917", :longitude => "124.67556").save
City.new(:country_id => "179", :name => "Cardona", :aliases => "Cardona,Kardona,ÐÐ°ÑÐ´Ð¾Ð½Ð°,Cardona", :latitude => "14.486", :longitude => "121.2289").save
City.new(:country_id => "179", :name => "Carcar", :aliases => "Carcar,Carcar", :latitude => "10.1061", :longitude => "123.6402").save
City.new(:country_id => "179", :name => "Capas", :aliases => "Capas,Capaz,Kapas,ÐÐ°Ð¿Ð°Ñ,Capas", :latitude => "15.32936", :longitude => "120.59123").save
City.new(:country_id => "179", :name => "Canlaon", :aliases => "Canlaon City,Canlaon", :latitude => "10.38639", :longitude => "123.19639").save
City.new(:country_id => "179", :name => "Candelaria", :aliases => ",Candelaria", :latitude => "13.93111", :longitude => "121.42333").save
City.new(:country_id => "179", :name => "Candaba", :aliases => "Candaba,Candaba", :latitude => "15.0956", :longitude => "120.8267").save
City.new(:country_id => "179", :name => "Camiling", :aliases => "Camiling,Camiling", :latitude => "15.6866", :longitude => "120.4128").save
City.new(:country_id => "179", :name => "Calumpit", :aliases => "Calumpit,Calumpit", :latitude => "14.91639", :longitude => "120.76583").save
City.new(:country_id => "179", :name => "Calbayog", :aliases => "Calbayog,Calbayog City,Dakbayan sa Calbayog,Syudad san Calbayog,Calbayog", :latitude => "12.06722", :longitude => "124.60417").save
City.new(:country_id => "179", :name => "Calauan", :aliases => "Calauan,Calauan", :latitude => "14.1447", :longitude => "121.3152").save
City.new(:country_id => "179", :name => "Calauag", :aliases => "Calavag,Calauag", :latitude => "13.9575", :longitude => "122.2875").save
City.new(:country_id => "179", :name => "Calatagan", :aliases => "Calalagan,Calatagan,Calatagan", :latitude => "13.8327", :longitude => "120.6319").save
City.new(:country_id => "179", :name => "Calasiao", :aliases => "Calasiao,Colasiao,Calasiao", :latitude => "16.0111", :longitude => "120.36").save
City.new(:country_id => "179", :name => "Calapan", :aliases => "Calapan,Calapan", :latitude => "13.4117", :longitude => "121.1803").save
City.new(:country_id => "179", :name => "Calamba", :aliases => ",Calamba", :latitude => "14.21167", :longitude => "121.16528").save
City.new(:country_id => "179", :name => "Calaca", :aliases => "Calaca,Calaca", :latitude => "13.93111", :longitude => "120.81444").save
City.new(:country_id => "179", :name => "Calabanga", :aliases => "Calabanga,Calabunga,Calabanga", :latitude => "13.7068", :longitude => "123.2087").save
City.new(:country_id => "179", :name => "Cainta", :aliases => "Cainta,Cainta", :latitude => "14.5786", :longitude => "121.1222").save
City.new(:country_id => "179", :name => "Cagayan de Oro", :aliases => "Cagayan de Oro City,Cagayan de Oro", :latitude => "8.48222", :longitude => "124.64722").save
City.new(:country_id => "179", :name => "Cadiz Viejo", :aliases => ",Cadiz Viejo", :latitude => "10.95056", :longitude => "123.28556").save
City.new(:country_id => "179", :name => "Cabiao", :aliases => "Cabiao,Cabiao", :latitude => "15.2488", :longitude => "120.8548").save
City.new(:country_id => "179", :name => "Cabayangan", :aliases => ",Cabayangan", :latitude => "7.40722", :longitude => "125.73306").save
City.new(:country_id => "179", :name => "Cabanatuan", :aliases => "Cabanatuan,Cabanatuan City,CabanatÃºan,Ciudad ti Cabanatuan,Cabanatuan", :latitude => "15.48694", :longitude => "120.9675").save
City.new(:country_id => "179", :name => "Cabagan", :aliases => "Cabagan,Cabagan", :latitude => "17.42782", :longitude => "121.76955").save
City.new(:country_id => "179", :name => "Cabadbaran", :aliases => ",Cabadbaran", :latitude => "9.12361", :longitude => "125.53444").save
City.new(:country_id => "179", :name => "Bustos", :aliases => "Bustos,ÐÑÑÑÐ¾Ñ,Bustos", :latitude => "14.95806", :longitude => "120.91778").save
City.new(:country_id => "179", :name => "Boroon", :aliases => "Buru-un,Boroon", :latitude => "8.18778", :longitude => "124.17694").save
City.new(:country_id => "179", :name => "Burgos", :aliases => ",Burgos", :latitude => "15.73333", :longitude => "120.58333").save
City.new(:country_id => "179", :name => "Bunawan", :aliases => "Bunauan,Bunawan,Bunawan", :latitude => "8.16722", :longitude => "125.99083").save
City.new(:country_id => "179", :name => "Buluan", :aliases => ",Buluan", :latitude => "6.72028", :longitude => "124.80194").save
City.new(:country_id => "179", :name => "Bulaon", :aliases => "Bulaun,Bulaon", :latitude => "15.08833", :longitude => "120.66722").save
City.new(:country_id => "179", :name => "Bulan", :aliases => "Bulan,Bulsan,ÐÑÐ»Ð°Ð½,Bulan", :latitude => "12.67139", :longitude => "123.875").save
City.new(:country_id => "179", :name => "Bulacan", :aliases => "Bulacan,Bulacan", :latitude => "14.79278", :longitude => "120.87889").save
City.new(:country_id => "179", :name => "Buhi", :aliases => "Buhi,Bulu,Buhi", :latitude => "13.4322", :longitude => "123.517").save
City.new(:country_id => "179", :name => "Bugo", :aliases => ",Bugo", :latitude => "8.50833", :longitude => "124.75944").save
City.new(:country_id => "179", :name => "Buenavista", :aliases => "Buenavista,Buenavista", :latitude => "8.97694", :longitude => "125.40889").save
City.new(:country_id => "179", :name => "Botolan", :aliases => "Botolan,Botolan", :latitude => "15.2896", :longitude => "120.0245").save
City.new(:country_id => "179", :name => "Borongan", :aliases => ",Borongan", :latitude => "11.60806", :longitude => "125.43194").save
City.new(:country_id => "179", :name => "Bongao", :aliases => "Bangaw,Bongao,Bongao Poblacion,Bonggao,Bonggaw,Bongao", :latitude => "5.02917", :longitude => "119.77306").save
City.new(:country_id => "179", :name => "Bongabon", :aliases => "Bongabon,Bongabon", :latitude => "15.6321", :longitude => "121.1448").save
City.new(:country_id => "179", :name => "Bogo", :aliases => "Bogo,Bogo", :latitude => "11.0517", :longitude => "124.0055").save
City.new(:country_id => "179", :name => "Bocaue", :aliases => "Bocaue,Bocaue", :latitude => "14.79833", :longitude => "120.92611").save
City.new(:country_id => "179", :name => "Bislig", :aliases => ",Bislig", :latitude => "8.21528", :longitude => "126.31639").save
City.new(:country_id => "179", :name => "Binonga", :aliases => ",Binonga", :latitude => "10.77306", :longitude => "122.98278").save
City.new(:country_id => "179", :name => "Binmaley", :aliases => "Binmaley,Binmaley", :latitude => "16.0307", :longitude => "120.2712").save
City.new(:country_id => "179", :name => "Binangonan", :aliases => "Binangonan,Binangonan", :latitude => "14.4646", :longitude => "121.1929").save
City.new(:country_id => "179", :name => "Binalbagan", :aliases => "Binalbagan,Binalbagan", :latitude => "10.1948", :longitude => "122.8581").save
City.new(:country_id => "179", :name => "Bignay", :aliases => ",Bignay", :latitude => "13.86278", :longitude => "121.48944").save
City.new(:country_id => "179", :name => "Bayugan", :aliases => ",Bayugan", :latitude => "8.75611", :longitude => "125.7675").save
City.new(:country_id => "179", :name => "Bayombong", :aliases => "Bayombong,Bayombong", :latitude => "16.4812", :longitude => "121.1497").save
City.new(:country_id => "179", :name => "Baybay", :aliases => "Baybay,Baybay", :latitude => "10.6785", :longitude => "124.8006").save
City.new(:country_id => "179", :name => "Bayawan", :aliases => "Tolong,Tolong Nuevo,Tulong,Bayawan", :latitude => "9.36361", :longitude => "122.80111").save
City.new(:country_id => "179", :name => "Bayambang", :aliases => "Bayambang,Bayembang,Bayambang", :latitude => "15.8127", :longitude => "120.4557").save
City.new(:country_id => "179", :name => "Bay", :aliases => "Bay,Bej,ÐÐµÐ¹,Bay", :latitude => "14.1831", :longitude => "121.2848").save
City.new(:country_id => "179", :name => "Bauang", :aliases => ",Bauang", :latitude => "16.53083", :longitude => "120.33306").save
City.new(:country_id => "179", :name => "Bauan", :aliases => "Bauan,Bauan", :latitude => "13.7917", :longitude => "121.0085").save
City.new(:country_id => "179", :name => "Bato", :aliases => "Bato,Bato", :latitude => "13.3528", :longitude => "123.3677").save
City.new(:country_id => "179", :name => "Batangas", :aliases => "Batangas,Batangas City,ÐÐ°ÑÐ°Ð½Ð³Ð°Ñ,Batangas", :latitude => "13.75944", :longitude => "121.06").save
City.new(:country_id => "179", :name => "Batac City", :aliases => ",Batac City", :latitude => "18.0554", :longitude => "120.56489").save
City.new(:country_id => "179", :name => "Baras", :aliases => "Baras,ÐÐ°ÑÐ°Ñ,Baras", :latitude => "14.5234", :longitude => "121.2651").save
City.new(:country_id => "179", :name => "Bantayan", :aliases => "Banatayan,Bantayan,Bantayan", :latitude => "11.1683", :longitude => "123.7223").save
City.new(:country_id => "179", :name => "Bansalan", :aliases => "Bansalan,Dansalan,Miral,Bansalan", :latitude => "6.78611", :longitude => "125.21333").save
City.new(:country_id => "179", :name => "Banga", :aliases => ",BaÃ±ga", :latitude => "6.42389", :longitude => "124.77833").save
City.new(:country_id => "179", :name => "Banaybanay", :aliases => ",Banaybanay", :latitude => "13.85", :longitude => "121.2").save
City.new(:country_id => "179", :name => "Bambang", :aliases => "Bambang,Bambang", :latitude => "16.3865", :longitude => "121.1066").save
City.new(:country_id => "179", :name => "Baliuag", :aliases => "Baliuag,Baliuag", :latitude => "14.95472", :longitude => "120.89694").save
City.new(:country_id => "179", :name => "Balayan", :aliases => "Balajan,Balayan,ÐÐ°Ð»Ð°ÑÐ½,Balayan", :latitude => "13.9396", :longitude => "120.7312").save
City.new(:country_id => "179", :name => "Balanga", :aliases => ",Balanga", :latitude => "14.67611", :longitude => "120.53611").save
City.new(:country_id => "179", :name => "Balamban", :aliases => "Balamban,Balanban,Balamban", :latitude => "10.5039", :longitude => "123.7156").save
City.new(:country_id => "179", :name => "Balagtas", :aliases => "Balagtas,Tabang,Balagtas", :latitude => "14.81667", :longitude => "120.86667").save
City.new(:country_id => "179", :name => "Bais", :aliases => "Bais City,Bajs,Ciudad ti Bais,ÐÐ°Ð¹Ñ,Bais", :latitude => "9.59111", :longitude => "123.12278").save
City.new(:country_id => "179", :name => "Bah-Bah", :aliases => ",Bah-Bah", :latitude => "8.60722", :longitude => "125.91444").save
City.new(:country_id => "179", :name => "Baguio", :aliases => "Baguio,Baguio City,Baguio',Ciudad ti Baguio,Lungsod ng Baguio,bagio,ÐÐ°Ð³ÑÐ¸Ð¾Ñ,ãã®ãª,Baguio", :latitude => "16.41639", :longitude => "120.59306").save
City.new(:country_id => "179", :name => "Bago City", :aliases => "Bago,City of Bago,Bago City", :latitude => "10.53333", :longitude => "122.83333").save
City.new(:country_id => "179", :name => "Baggabag B", :aliases => "Bagabag,Baggabag B,Baggabag B", :latitude => "16.50588", :longitude => "121.19014").save
City.new(:country_id => "179", :name => "Bacoor", :aliases => ",Bacoor", :latitude => "14.45778", :longitude => "120.9425").save
City.new(:country_id => "179", :name => "Bacolod City", :aliases => "Baclod City,Bacolod,Bacolod City,Bacoloo City,BacÃ³lod,Ciudad ti Bacolod,Dakbayan sa Bacolod,Lungsod ng Bacolod,Syudad han Bacolod,Bacolod City", :latitude => "10.66667", :longitude => "122.95").save
City.new(:country_id => "179", :name => "Babo-Pangulo", :aliases => ",Babo-Pangulo", :latitude => "15.08333", :longitude => "120.51667").save
City.new(:country_id => "179", :name => "Baao", :aliases => "Baao,Baao", :latitude => "13.4549", :longitude => "123.3653").save
City.new(:country_id => "179", :name => "Atimonan", :aliases => "Antimonan,Atimonan", :latitude => "13.99583", :longitude => "121.905").save
City.new(:country_id => "179", :name => "Asia", :aliases => "Asia,Azija,Isio,ÐÐ·Ð¸Ñ,Asia", :latitude => "9.5506", :longitude => "122.5164").save
City.new(:country_id => "179", :name => "Aringay", :aliases => "Aringay,Aringay", :latitude => "16.394", :longitude => "120.3545").save
City.new(:country_id => "179", :name => "Arayat", :aliases => "Arayat,Arayat", :latitude => "15.1505", :longitude => "120.7697").save
City.new(:country_id => "179", :name => "Aparri", :aliases => "Aparri,Apparri,Aparri", :latitude => "18.3566", :longitude => "121.6406").save
City.new(:country_id => "179", :name => "Apalit", :aliases => "Apalit,Apalit", :latitude => "14.95333", :longitude => "120.77").save
City.new(:country_id => "179", :name => "Antipolo", :aliases => ",Antipolo", :latitude => "14.58639", :longitude => "121.17528").save
City.new(:country_id => "179", :name => "Angono", :aliases => "Angono,Angono", :latitude => "14.5266", :longitude => "121.1536").save
City.new(:country_id => "179", :name => "Angeles City", :aliases => "Angeles,Angeles City", :latitude => "15.15", :longitude => "120.58333").save
City.new(:country_id => "179", :name => "Angat", :aliases => "Angat,Santa Cruz,Angat", :latitude => "14.9285", :longitude => "121.03").save
City.new(:country_id => "179", :name => "Amadeo", :aliases => ",Amadeo", :latitude => "14.17056", :longitude => "120.92361").save
City.new(:country_id => "179", :name => "Alicia", :aliases => "Alicia,Alicia", :latitude => "16.77936", :longitude => "121.69734").save
City.new(:country_id => "179", :name => "Aliaga", :aliases => "Aliaga,ÐÐ»Ð¸Ð°Ð³Ð°,Aliaga", :latitude => "15.5", :longitude => "120.843").save
City.new(:country_id => "179", :name => "Alaminos", :aliases => "Alaminos,Alaminos", :latitude => "14.06391", :longitude => "121.24649").save
City.new(:country_id => "179", :name => "Alabel", :aliases => "Alabel,Alabel", :latitude => "6.10179", :longitude => "125.29048").save
City.new(:country_id => "179", :name => "Agoo", :aliases => ",Agoo", :latitude => "16.08333", :longitude => "120.1").save
City.new(:country_id => "179", :name => "Abuyog", :aliases => "Abuyog,Abuyog", :latitude => "10.747", :longitude => "125.0107").save
City.new(:country_id => "179", :name => "Abucay", :aliases => "Abucay,Abucay", :latitude => "14.72222", :longitude => "120.53833").save
