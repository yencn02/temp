City.new(:country_id => "39", :name => "Abbotsford", :aliases => "Abbotsford,ÐÐ±Ð±Ð¾ÑÑÑÐ¾ÑÐ´,Abbotsford", :latitude => "49.05798", :longitude => "-122.25257").save
City.new(:country_id => "39", :name => "Airdrie", :aliases => ",Airdrie", :latitude => "51.30011", :longitude => "-114.03528").save
City.new(:country_id => "39", :name => "Alma", :aliases => "Alma,ÐÐ»Ð¼Ð°,Alma", :latitude => "48.55009", :longitude => "-71.6491").save
City.new(:country_id => "39", :name => "Amos", :aliases => ",Amos", :latitude => "48.56688", :longitude => "-78.11624").save
City.new(:country_id => "39", :name => "Baie-Comeau", :aliases => ",Baie-Comeau", :latitude => "49.21679", :longitude => "-68.14894").save
City.new(:country_id => "39", :name => "Barrie", :aliases => ",Barrie", :latitude => "44.40011", :longitude => "-79.66634").save
City.new(:country_id => "39", :name => "Beaconsfield", :aliases => ",Beaconsfield", :latitude => "45.43341", :longitude => "-73.86586").save
City.new(:country_id => "39", :name => "Belleville", :aliases => ",Belleville", :latitude => "44.17876", :longitude => "-77.37053").save
City.new(:country_id => "39", :name => "Beloeil", :aliases => ",Beloeil", :latitude => "45.56678", :longitude => "-73.19915").save
City.new(:country_id => "39", :name => "Blainville", :aliases => ",Blainville", :latitude => "45.66678", :longitude => "-73.88249").save
City.new(:country_id => "39", :name => "Boisbriand", :aliases => ",Boisbriand", :latitude => "45.61678", :longitude => "-73.83249").save
City.new(:country_id => "39", :name => "Boucherville", :aliases => ",Boucherville", :latitude => "45.59104", :longitude => "-73.43605").save
City.new(:country_id => "39", :name => "Bradford West Gwillimbury", :aliases => ",Bradford West Gwillimbury", :latitude => "44.11681", :longitude => "-79.61633").save
City.new(:country_id => "39", :name => "Brampton", :aliases => "Brampton,Bramptono,buranputon,ãã©ã³ããã³,Brampton", :latitude => "43.68341", :longitude => "-79.76633").save
City.new(:country_id => "39", :name => "Brandon", :aliases => "Brehndon,ÐÑÑÐ½Ð´Ð¾Ð½,Brandon", :latitude => "49.84692", :longitude => "-99.95306").save
City.new(:country_id => "39", :name => "Brant", :aliases => ",Brant", :latitude => "43.1334", :longitude => "-80.34967").save
City.new(:country_id => "39", :name => "Brantford", :aliases => ",Brantford", :latitude => "43.1334", :longitude => "-80.26636").save
City.new(:country_id => "39", :name => "Brockville", :aliases => ",Brockville", :latitude => "44.58341", :longitude => "-75.68264").save
City.new(:country_id => "39", :name => "Brossard", :aliases => ",Brossard", :latitude => "45.45008", :longitude => "-73.46583").save
City.new(:country_id => "39", :name => "Burlington", :aliases => ",Burlington", :latitude => "43.38621", :longitude => "-79.83713").save
City.new(:country_id => "39", :name => "Burnaby", :aliases => "Burnaby,banabi,banabi shi,ben na bi,ãã¼ããã¼,ãã¼ããã¼å¸,æ¬é£æ¯,Burnaby", :latitude => "49.26636", :longitude => "-122.95263").save
City.new(:country_id => "39", :name => "Calgary", :aliases => "Calgaria,Calgary,Gorad Kalgary,Kalgari,Kalgario,Kalgaris,Kalnkary,Kalqari,ka er jia li,kaelgeoli,kailagari,kalgari,kalghary,kalgry,kalkari,karugari,kelgari,kyalgari,qlgry,ÎÎ¬Î»Î³ÎºÎ±ÏÏ,ÐÐ¾ÑÐ°Ð´ ÐÐ°Ð»Ð³Ð°ÑÑ,ÐÐ°Ð»Ð³Ð°ÑÐ¸,ÐÐ°Ð»Ð³Ð°ÑÑ,×§×××¨×,ÙØ§ÙØºØ§Ø±Ù,Ú©Ø§ÙÚ¯Ø±Û,à¤à¥à¤²à¥à¤à¤¾à¤°à¥,à¤à¥à¤²à¤à¤°à¥,à®à®¾à®²à¯à®à®°à®¿,à°à°¾à°²à±à°à°°à±,à²à³à²¯à²¾à²²à³à²à²°à²¿,áááºááá«áá®áá¼á­á¯á·,áááááá á,ã«ã«ã¬ãªã¼,å¡å°å é,ìºê±°ë¦¬,Calgary", :latitude => "51.05011", :longitude => "-114.08529").save
City.new(:country_id => "39", :name => "Cambridge", :aliases => ",Cambridge", :latitude => "43.3601", :longitude => "-80.31269").save
City.new(:country_id => "39", :name => "Campbell River", :aliases => ",Campbell River", :latitude => "50.01634", :longitude => "-125.24459").save
City.new(:country_id => "39", :name => "Camrose", :aliases => ",Camrose", :latitude => "53.01684", :longitude => "-112.83525").save
City.new(:country_id => "39", :name => "Candiac", :aliases => ",Candiac", :latitude => "45.38338", :longitude => "-73.51587").save
City.new(:country_id => "39", :name => "Chambly", :aliases => ",Chambly", :latitude => "45.45008", :longitude => "-73.28246").save
City.new(:country_id => "39", :name => "Charlottetown", :aliases => "Carolinapolis,Charlottetown,Sharlottaun,sharottotaun,xia luo te dun,Ð¨Ð°ÑÐ»Ð¾ÑÑÐ°ÑÐ½,ã·ã£ã¼ã­ããã¿ã¦ã³,å¤æ´ç¹é¡¿,Charlottetown", :latitude => "46.23525", :longitude => "-63.12671").save
City.new(:country_id => "39", :name => "Chateauguay", :aliases => ",ChÃ¢teauguay", :latitude => "45.38338", :longitude => "-73.74919").save
City.new(:country_id => "39", :name => "Chatham-Kent", :aliases => "Chatham-Kent,Municipality of Chatham-Kent,Chatham-Kent", :latitude => "42.40009", :longitude => "-82.1831").save
City.new(:country_id => "39", :name => "Chilliwack", :aliases => ",Chilliwack", :latitude => "49.17468", :longitude => "-121.94427").save
City.new(:country_id => "39", :name => "Clarence-Rockland", :aliases => ",Clarence-Rockland", :latitude => "45.5501", :longitude => "-75.29101").save
City.new(:country_id => "39", :name => "Cobourg", :aliases => ",Cobourg", :latitude => "43.95977", :longitude => "-78.16515").save
City.new(:country_id => "39", :name => "Cochrane", :aliases => ",Cochrane", :latitude => "51.18341", :longitude => "-114.46871").save
City.new(:country_id => "39", :name => "Collingwood", :aliases => ",Collingwood", :latitude => "44.4834", :longitude => "-80.21638").save
City.new(:country_id => "39", :name => "Conception Bay South", :aliases => ",Conception Bay South", :latitude => "47.49989", :longitude => "-52.99806").save
City.new(:country_id => "39", :name => "Coquitlam", :aliases => "Coquitlam,kokittoramu,kokittoramu shi,kokuittoramu,ã³ã­ããã©ã ,ã³ã­ããã©ã å¸,ã³ã¯ã¤ããã©ã ,Coquitlam", :latitude => "49.28297", :longitude => "-122.75262").save
City.new(:country_id => "39", :name => "Corner Brook", :aliases => ",Corner Brook", :latitude => "48.96671", :longitude => "-57.9484").save
City.new(:country_id => "39", :name => "Cornwall", :aliases => ",Cornwall", :latitude => "45.01809", :longitude => "-74.72815").save
City.new(:country_id => "39", :name => "Cote-Saint-Luc", :aliases => ",CÃ´te-Saint-Luc", :latitude => "45.46536", :longitude => "-73.66585").save
City.new(:country_id => "39", :name => "Courtenay", :aliases => "Kurteneh,ÐÑÑÑÐµÐ½Ñ,Courtenay", :latitude => "49.68657", :longitude => "-124.9936").save
City.new(:country_id => "39", :name => "Cranbrook", :aliases => ",Cranbrook", :latitude => "49.49991", :longitude => "-115.76879").save
City.new(:country_id => "39", :name => "Dartmouth", :aliases => ",Dartmouth", :latitude => "44.67134", :longitude => "-63.57719").save
City.new(:country_id => "39", :name => "Delta", :aliases => "Del'ta,ÐÐµÐ»ÑÑÐ°,Delta", :latitude => "49.14399", :longitude => "-122.9068").save
City.new(:country_id => "39", :name => "Deux-Montagnes", :aliases => ",Deux-Montagnes", :latitude => "45.53455", :longitude => "-73.90168").save
City.new(:country_id => "39", :name => "Dieppe", :aliases => ",Dieppe", :latitude => "46.07844", :longitude => "-64.68735").save
City.new(:country_id => "39", :name => "Dollard-Des Ormeaux", :aliases => ",Dollard-Des Ormeaux", :latitude => "45.49452", :longitude => "-73.82419").save
City.new(:country_id => "39", :name => "Dorval", :aliases => ",Dorval", :latitude => "45.4473", :longitude => "-73.75335").save
City.new(:country_id => "39", :name => "Drummondville", :aliases => ",Drummondville", :latitude => "45.88336", :longitude => "-72.48241").save
City.new(:country_id => "39", :name => "Duncan", :aliases => "Dunkan,ÐÑÐ½ÐºÐ°Ð½,Duncan", :latitude => "48.78293", :longitude => "-123.70266").save
City.new(:country_id => "39", :name => "Edmonton", :aliases => "Edmonton,Edmontonas,Edmontono,Ehdmonton,YEA,ai de meng dun,edeumeonteon,edomonton,ÐÐ´Ð¼Ð¾Ð½ÑÐ¾Ð½,Ð­Ð´Ð¼Ð¾Ð½ÑÐ¾Ð½,××××× ×××,ã¨ãã¢ã³ãã³,åå¾·èé¡¿,ìëë¨¼í´,Edmonton", :latitude => "53.55014", :longitude => "-113.46871").save
City.new(:country_id => "39", :name => "Fort Erie", :aliases => ",Fort Erie", :latitude => "42.90012", :longitude => "-78.93286").save
City.new(:country_id => "39", :name => "Fort St. John", :aliases => ",Fort St. John", :latitude => "56.24988", :longitude => "-120.85292").save
City.new(:country_id => "39", :name => "Fredericton", :aliases => "Fredericopolis,Fredericton,Frederikton,Phrentrikton,fu lei de li ke dun,furederikuton,peuledeoligteon,Î¦ÏÎ­Î½ÏÏÎ¹ÎºÏÎ¿Î½,Ð¤ÑÐµÐ´ÐµÑÐ¸ÐºÑÐ¾Ð½,ãã¬ããªã¯ãã³,å¼é·å¾·éåé ,íë ëë¦­í´,Fredericton", :latitude => "45.94541", :longitude => "-66.66558").save
City.new(:country_id => "39", :name => "Gatineau", :aliases => "Gatineau,Sablono:TabelKapoLauCarta,gatino,Åablono:TabelKapoLaÅ­Äarta,ã¬ãã£ãã¼,Gatineau", :latitude => "45.47723", :longitude => "-75.70164").save
City.new(:country_id => "39", :name => "Glace Bay", :aliases => ",Glace Bay", :latitude => "46.19695", :longitude => "-59.95698").save
City.new(:country_id => "39", :name => "Granby", :aliases => ",Granby", :latitude => "45.40008", :longitude => "-72.73243").save
City.new(:country_id => "39", :name => "Grande Prairie", :aliases => ",Grande Prairie", :latitude => "55.16667", :longitude => "-118.80271").save
City.new(:country_id => "39", :name => "Greater Sudbury", :aliases => "Grand Sudbury,Greater Sudbury,Sadberi,Sudbury,Ð¡Ð°Ð´Ð±ÐµÑÐ¸,Greater Sudbury", :latitude => "46.49", :longitude => "-80.99001").save
City.new(:country_id => "39", :name => "Greater Napanee", :aliases => "Napanee,Greater Napanee", :latitude => "44.25012", :longitude => "-76.94944").save
City.new(:country_id => "39", :name => "Guelph", :aliases => ",Guelph", :latitude => "43.5501", :longitude => "-80.24967").save
City.new(:country_id => "39", :name => "Haldimand County", :aliases => ",Haldimand County", :latitude => "42.98341", :longitude => "-79.86633").save
City.new(:country_id => "39", :name => "Hamilton", :aliases => ",Hamilton", :latitude => "43.23341", :longitude => "-79.94964").save
City.new(:country_id => "39", :name => "Huntsville", :aliases => ",Huntsville", :latitude => "45.33341", :longitude => "-79.21632").save
City.new(:country_id => "39", :name => "Joliette", :aliases => ",Joliette", :latitude => "46.01677", :longitude => "-73.44915").save
City.new(:country_id => "39", :name => "Kamloops", :aliases => "Kamloops,Kamlups,kamurupusu,ÐÐ°Ð¼Ð»ÑÐ¿Ñ,ã«ã ã«ã¼ãã¹,Kamloops", :latitude => "50.66648", :longitude => "-120.3192").save
City.new(:country_id => "39", :name => "Kawartha Lakes", :aliases => ",Kawartha Lakes", :latitude => "44.58342", :longitude => "-78.83288").save
City.new(:country_id => "39", :name => "Kelowna", :aliases => "Kelouna,Kelowna,kerouna,ÐÐµÐ»Ð¾ÑÐ½Ð°,ã±ã­ã¦ã,Kelowna", :latitude => "49.88307", :longitude => "-119.48568").save
City.new(:country_id => "39", :name => "Kenora", :aliases => ",Kenora", :latitude => "49.81671", :longitude => "-94.43373").save
City.new(:country_id => "39", :name => "Keswick", :aliases => ",Keswick", :latitude => "44.25011", :longitude => "-79.46632").save
City.new(:country_id => "39", :name => "Kingston", :aliases => "Kingston,jing shi dun,kingusuton,ÐÐ¸Ð½Ð³ÑÑÐ¾Ð½,ã­ã³ã°ã¹ãã³,äº¬å£«é ,Kingston", :latitude => "44.22976", :longitude => "-76.48098").save
City.new(:country_id => "39", :name => "Kirkland", :aliases => ",Kirkland", :latitude => "45.45008", :longitude => "-73.86586").save
City.new(:country_id => "39", :name => "Kitchener", :aliases => "Kicenero,Kitchener,KiÄenero,kychnr,ÐÐ¸ÑÑÐµÐ½ÐµÑ,Ú©ÛÚÙØ±,Kitchener", :latitude => "43.4501", :longitude => "-80.48299").save
City.new(:country_id => "39", :name => "Langford", :aliases => ",Langford", :latitude => "48.44963", :longitude => "-123.50261").save
City.new(:country_id => "39", :name => "Langley", :aliases => "City of Langley,Langley", :latitude => "49.09967", :longitude => "-122.6526").save
City.new(:country_id => "39", :name => "Langley", :aliases => "Township of Langley,Langley", :latitude => "49.08297", :longitude => "-122.58589").save
City.new(:country_id => "39", :name => "La Prairie", :aliases => ",La Prairie", :latitude => "45.41678", :longitude => "-73.49917").save
City.new(:country_id => "39", :name => "L'Assomption", :aliases => ",L'Assomption", :latitude => "45.82318", :longitude => "-73.4294").save
City.new(:country_id => "39", :name => "Laval", :aliases => "Laval,ravu~aru,ã©ã´ã¡ã«,Laval", :latitude => "45.56995", :longitude => "-73.692").save
City.new(:country_id => "39", :name => "Leamington", :aliases => ",Leamington", :latitude => "42.0549", :longitude => "-82.6062").save
City.new(:country_id => "39", :name => "Leduc", :aliases => ",Leduc", :latitude => "53.26682", :longitude => "-113.55201").save
City.new(:country_id => "39", :name => "Lethbridge", :aliases => "Letbridzas,LetbridÅ¾as,Lethbridge,Lethbridge", :latitude => "49.69999", :longitude => "-112.81856").save
City.new(:country_id => "39", :name => "Lloydminster", :aliases => ",Lloydminster", :latitude => "53.28346", :longitude => "-110.00157").save
City.new(:country_id => "39", :name => "London", :aliases => "London,Londono,lndn,lun dun,lwndwn,rondon,ÐÐ¾Ð½Ð´Ð¾Ð½,××× ×××,ÙÙØ¯Ù,ã­ã³ãã³,ä¼¦æ¦,London", :latitude => "42.98339", :longitude => "-81.23304").save
City.new(:country_id => "39", :name => "Longueuil", :aliases => "Longueuil,rongeru,ã­ã³ã²ã¼ã«,Longueuil", :latitude => "45.53121", :longitude => "-73.51806").save
City.new(:country_id => "39", :name => "Magog", :aliases => ",Magog", :latitude => "45.26678", :longitude => "-72.14909").save
City.new(:country_id => "39", :name => "Maple Ridge", :aliases => "Mehpl-Ridzh,ÐÑÐ¿Ð»-Ð Ð¸Ð´Ð¶,Maple Ridge", :latitude => "49.21939", :longitude => "-122.60193").save
City.new(:country_id => "39", :name => "Mascouche", :aliases => ",Mascouche", :latitude => "45.74965", :longitude => "-73.59956").save
City.new(:country_id => "39", :name => "Medicine Hat", :aliases => "Medicine Hat,Medicine Hat", :latitude => "50.05006", :longitude => "-110.66834").save
City.new(:country_id => "39", :name => "Midland", :aliases => ",Midland", :latitude => "44.7501", :longitude => "-79.88296").save
City.new(:country_id => "39", :name => "Mirabel", :aliases => ",Mirabel", :latitude => "45.65008", :longitude => "-74.08251").save
City.new(:country_id => "39", :name => "Miramichi", :aliases => ",Miramichi", :latitude => "47.00431", :longitude => "-65.46544").save
City.new(:country_id => "39", :name => "Mission", :aliases => "Mishen,ÐÐ¸ÑÐµÐ½,Mission", :latitude => "49.13377", :longitude => "-122.3144").save
City.new(:country_id => "39", :name => "Mississauga", :aliases => ",Mississauga", :latitude => "43.5789", :longitude => "-79.6583").save
City.new(:country_id => "39", :name => "Moncton", :aliases => "Moncton,Monkton,Monktono,ÐÐ¾Ð½ÐºÑÐ¾Ð½,Moncton", :latitude => "46.11594", :longitude => "-64.80186").save
City.new(:country_id => "39", :name => "Montreal", :aliases => "Lungsod ng Montreal,Lungsod ng MontrÃ©al,Monreal,Monreal',Monreala,Monrealis,Monreyal,MonreÄla,Mons Regius,Mont-real,Montreal,Montreal - Montreal,Montreal - MontrÃ©al,Montreal City,Montreali,Montrealo,MontrÃ©al,YMQ,meng te li er,monreali,monteuliol,montorioru,mwntral,mwntryal,ÎÎ¿Î½ÏÏÎµÎ±Î»,ÎÏÎ½ÏÏÎµÎ±Î»,ÐÐ¾Ð½ÑÐµÐ°Ð»,ÐÐ¾Ð½ÑÐµÐ°Ð»Ñ,ÐÐ¾Ð½ÑÑÐµÐ°Ð»,××× ××¨××××,ÙÙÙØªØ±Ø¢Ù,ÙÙÙØªØ±ÛØ§Ù,ÙÙÙØªØ±ÛØ¦Ø§Ù,áááá áááá,á§áááª,ã¢ã³ããªãªã¼ã«,èç¹å©å°,ëª¬í¸ë¦¬ì¬,MontrÃ©al", :latitude => "45.50884", :longitude => "-73.58781").save
City.new(:country_id => "39", :name => "Mont-Royal", :aliases => ",Mont-Royal", :latitude => "45.51675", :longitude => "-73.64918").save
City.new(:country_id => "39", :name => "Mont-Saint-Hilaire", :aliases => ",Mont-Saint-Hilaire", :latitude => "45.56678", :longitude => "-73.19915").save
City.new(:country_id => "39", :name => "Moose Jaw", :aliases => ",Moose Jaw", :latitude => "50.40005", :longitude => "-105.53445").save
City.new(:country_id => "39", :name => "Mount Pearl", :aliases => ",Mount Pearl", :latitude => "47.51659", :longitude => "-52.78135").save
City.new(:country_id => "39", :name => "Nanaimo", :aliases => "Nanaimo,Nanajmo,na nai mo,nanaimo,nanaymw, brytysh klmbya,ÐÐ°Ð½Ð°Ð¹Ð¼Ð¾,ÙØ§ÙØ§ÛÙÙØ Ø¨Ø±ÛØªÛØ´ Ú©ÙÙØ¨ÛØ§,ÙØ§ÙØ§ÛÙÙØ Ø¨Ø±ÛØªÛØ´ Ú©ÙÙØ¨ÛØ§â,ããã¤ã¢,çº³å¥è«,Nanaimo", :latitude => "49.16634", :longitude => "-123.93601").save
City.new(:country_id => "39", :name => "New Glasgow", :aliases => ",New Glasgow", :latitude => "45.58344", :longitude => "-62.64863").save
City.new(:country_id => "39", :name => "New Westminster", :aliases => ",New Westminster", :latitude => "49.20678", :longitude => "-122.91092").save
City.new(:country_id => "39", :name => "Niagara Falls", :aliases => "Niagara Falls,ni ya jia la pu bu cheng,å°¼äºå æçå¸å,Niagara Falls", :latitude => "43.10012", :longitude => "-79.06627").save
City.new(:country_id => "39", :name => "Norfolk County", :aliases => ",Norfolk County", :latitude => "42.8334", :longitude => "-80.38297").save
City.new(:country_id => "39", :name => "North Battleford", :aliases => ",North Battleford", :latitude => "52.78344", :longitude => "-108.28465").save
City.new(:country_id => "39", :name => "North Bay", :aliases => ",North Bay", :latitude => "46.3168", :longitude => "-79.46633").save
City.new(:country_id => "39", :name => "North Cowichan", :aliases => ",North Cowichan", :latitude => "48.84133", :longitude => "-123.68596").save
City.new(:country_id => "39", :name => "North Vancouver", :aliases => ",North Vancouver", :latitude => "49.31636", :longitude => "-123.06934").save
City.new(:country_id => "39", :name => "North York", :aliases => ",North York", :latitude => "43.76681", :longitude => "-79.4163").save
City.new(:country_id => "39", :name => "Orangeville", :aliases => ",Orangeville", :latitude => "43.9168", :longitude => "-80.09967").save
City.new(:country_id => "39", :name => "Orillia", :aliases => ",Orillia", :latitude => "44.60868", :longitude => "-79.42068").save
City.new(:country_id => "39", :name => "Oshawa", :aliases => ",Oshawa", :latitude => "43.90012", :longitude => "-78.84957").save
City.new(:country_id => "39", :name => "Ottawa", :aliases => "Otava,Otava - Ottawa,Otavo,Ottaba,Ottava,Ottawa,atawa,awtawa,otawa,ottava,wo tai hua,ÂAAÂ¬Â²Â±,ÎÏÏÎ¬Î²Î±,ÎÏÏÎ±Î²Î±,ÐÑÐ°Ð²Ð°,ÐÑÑÐ°Ð²Ð°,ÕÕ¿Õ¡Õ¾Õ¡,××××××,Ø£ÙØªØ§ÙØ§,Ø§ØªØ§ÙØ§,à®à®à¯à®à®¾à®µà®¾,á¦á³á,ááá,ãªã¿ã¯,æ¸¥å¤ªè¯,ì¤íì,Ottawa", :latitude => "45.41117", :longitude => "-75.69812").save
City.new(:country_id => "39", :name => "Owen Sound", :aliases => ",Owen Sound", :latitude => "44.56717", :longitude => "-80.94349").save
City.new(:country_id => "39", :name => "Parksville", :aliases => ",Parksville", :latitude => "49.31633", :longitude => "-124.31945").save
City.new(:country_id => "39", :name => "Pembroke", :aliases => ",Pembroke", :latitude => "45.81681", :longitude => "-77.11616").save
City.new(:country_id => "39", :name => "Penticton", :aliases => ",Penticton", :latitude => "49.48062", :longitude => "-119.58584").save
City.new(:country_id => "39", :name => "Peterborough", :aliases => "Piterboro,ÐÐ¸ÑÐµÑÐ±Ð¾ÑÐ¾,Peterborough", :latitude => "44.30012", :longitude => "-78.31623").save
City.new(:country_id => "39", :name => "Pickering", :aliases => ",Pickering", :latitude => "43.90012", :longitude => "-79.13289").save
City.new(:country_id => "39", :name => "Pitt Meadows", :aliases => "Pitt Meadows,Pitt-Medous,Pitts Meadows,ÐÐ¸ÑÑ-ÐÐµÐ´Ð¾ÑÑ,Pitt Meadows", :latitude => "49.22119", :longitude => "-122.68965").save
City.new(:country_id => "39", :name => "Pointe-Claire", :aliases => ",Pointe-Claire", :latitude => "45.44868", :longitude => "-73.81669").save
City.new(:country_id => "39", :name => "Port Alberni", :aliases => ",Port Alberni", :latitude => "49.24133", :longitude => "-124.8028").save
City.new(:country_id => "39", :name => "Port Colborne", :aliases => ",Port Colborne", :latitude => "42.90012", :longitude => "-79.23288").save
City.new(:country_id => "39", :name => "Port Moody", :aliases => ",Port Moody", :latitude => "49.28297", :longitude => "-122.85263").save
City.new(:country_id => "39", :name => "Prince Albert", :aliases => "Prince Albert,Prince Albert", :latitude => "53.20008", :longitude => "-105.76772").save
City.new(:country_id => "39", :name => "Prince Edward", :aliases => "Prince Edward,Prince Edward County,Prince Edward", :latitude => "44.00012", :longitude => "-77.24946").save
City.new(:country_id => "39", :name => "Prince George", :aliases => "Prince George,Prins-Dzhordzh,ÐÑÐ¸Ð½Ñ-ÐÐ¶Ð¾ÑÐ´Ð¶,Prince George", :latitude => "53.9166", :longitude => "-122.75301").save
City.new(:country_id => "39", :name => "Quinte West", :aliases => ",Quinte West", :latitude => "44.18342", :longitude => "-77.56618").save
City.new(:country_id => "39", :name => "Red Deer", :aliases => "Red Deer,Red Dyras,Red Deer", :latitude => "52.26682", :longitude => "-113.802").save
City.new(:country_id => "39", :name => "Regina", :aliases => "Redzajna,Redzhajna,RedÅ¾ajna,Regina,Regino,ReÄino,RÃ©gina,Urbs Reginae,li jia na,rejaina,Ð ÐµÐ´Ð¶Ð°Ð¹Ð½Ð°,ã¬ã¸ã£ã¤ã,éè³ç´,Regina", :latitude => "50.45008", :longitude => "-104.6178").save
City.new(:country_id => "39", :name => "Repentigny", :aliases => ",Repentigny", :latitude => "45.74222", :longitude => "-73.45008").save
City.new(:country_id => "39", :name => "Richmond", :aliases => "Richmond,Ð Ð¸ÑÐ¼Ð¾Ð½Ð´,Richmond", :latitude => "49.17003", :longitude => "-123.13683").save
City.new(:country_id => "39", :name => "Rouyn-Noranda", :aliases => ",Rouyn-Noranda", :latitude => "48.23985", :longitude => "-79.02878").save
City.new(:country_id => "39", :name => "Saguenay", :aliases => "Saguenay,sagune,ãµã°ã,Saguenay", :latitude => "48.41675", :longitude => "-71.06573").save
City.new(:country_id => "39", :name => "Saint-Basile-le-Grand", :aliases => ",Saint-Basile-le-Grand", :latitude => "45.53338", :longitude => "-73.28246").save
City.new(:country_id => "39", :name => "Saint-Bruno-de-Montarville", :aliases => ",Saint-Bruno-de-Montarville", :latitude => "45.53341", :longitude => "-73.34916").save
City.new(:country_id => "39", :name => "Saint-Constant", :aliases => ",Saint-Constant", :latitude => "45.36678", :longitude => "-73.56588").save
City.new(:country_id => "39", :name => "Sainte-Catherine", :aliases => ",Sainte-Catherine", :latitude => "46.31836", :longitude => "-72.56632").save
City.new(:country_id => "39", :name => "Sainte-Julie", :aliases => ",Sainte-Julie", :latitude => "45.58338", :longitude => "-73.33246").save
City.new(:country_id => "39", :name => "Sainte-Therese", :aliases => ",Sainte-ThÃ©rÃ¨se", :latitude => "45.63922", :longitude => "-73.82757").save
City.new(:country_id => "39", :name => "Saint-Eustache", :aliases => ",Saint-Eustache", :latitude => "45.565", :longitude => "-73.90554").save
City.new(:country_id => "39", :name => "Saint-Hyacinthe", :aliases => "Sankt-Giacint,Ð¡Ð°Ð½ÐºÑ-ÐÐ¸Ð°ÑÐ¸Ð½Ñ,Saint-Hyacinthe", :latitude => "45.61678", :longitude => "-72.94914").save
City.new(:country_id => "39", :name => "Saint-Jean-sur-Richelieu", :aliases => "Saint-Jean-sur-Richelieu,Sen-Zhan-sjur-Rishel'e,Ð¡ÐµÐ½-ÐÐ°Ð½-ÑÑÑ-Ð Ð¸ÑÐµÐ»ÑÐµ,Saint-Jean-sur-Richelieu", :latitude => "45.31678", :longitude => "-73.26586").save
City.new(:country_id => "39", :name => "Saint-Jerome", :aliases => ",Saint-JÃ©rÃ´me", :latitude => "45.78036", :longitude => "-74.00365").save
City.new(:country_id => "39", :name => "Saint John", :aliases => "Saint John,Saint-Jean,seinteujon,sentojon,ã»ã³ãã¸ã§ã³,ã»ã³ãã»ã¸ã§ã³,ì¸ì¸í¸ì¡´,Saint John", :latitude => "45.27271", :longitude => "-66.06766").save
City.new(:country_id => "39", :name => "Saint-Lambert", :aliases => ",Saint-Lambert", :latitude => "48.95272", :longitude => "-79.4593").save
City.new(:country_id => "39", :name => "Saint-Laurent", :aliases => "Saint-Laurent,Sen-Loran,St Laurent,Ville Saint-Laurent,Ville St Laurent,Ð¡ÐµÐ½-ÐÐ¾ÑÐ°Ð½,Saint-Laurent", :latitude => "45.50008", :longitude => "-73.66585").save
City.new(:country_id => "39", :name => "Saint-Lazare", :aliases => ",Saint-Lazare", :latitude => "45.40008", :longitude => "-74.13256").save
City.new(:country_id => "39", :name => "Salaberry-de-Valleyfield", :aliases => ",Salaberry-de-Valleyfield", :latitude => "45.25008", :longitude => "-74.13253").save
City.new(:country_id => "39", :name => "Salmon Arm", :aliases => "Sehlmon-Arm,Ð¡ÑÐ»Ð¼Ð¾Ð½-ÐÑÐ¼,Salmon Arm", :latitude => "50.6998", :longitude => "-119.30237").save
City.new(:country_id => "39", :name => "Sarnia", :aliases => "Sarnia,Sarnia", :latitude => "42.97866", :longitude => "-82.40407").save
City.new(:country_id => "39", :name => "Saskatoon", :aliases => "Saskatoon,Saskatun,Saskatuno,sasukato~un,Ð¡Ð°ÑÐºÐ°ÑÑÐ½,ãµã¹ã«ãã¥ã¼ã³,Saskatoon", :latitude => "52.11679", :longitude => "-106.63452").save
City.new(:country_id => "39", :name => "Sault Ste. Marie", :aliases => ",Sault Ste. Marie", :latitude => "46.51677", :longitude => "-84.33325").save
City.new(:country_id => "39", :name => "Sept-Iles", :aliases => "Set-Il',Ð¡ÐµÑ-ÐÐ»Ñ,Sept-Ãles", :latitude => "50.20011", :longitude => "-66.38208").save
City.new(:country_id => "39", :name => "Shawinigan", :aliases => ",Shawinigan", :latitude => "46.56675", :longitude => "-72.74913").save
City.new(:country_id => "39", :name => "Sherbrooke", :aliases => "Sherbruk,Ð¨ÐµÑÐ±ÑÑÐº,Sherbrooke", :latitude => "45.40008", :longitude => "-71.89908").save
City.new(:country_id => "39", :name => "Sherwood Park", :aliases => ",Sherwood Park", :latitude => "53.51684", :longitude => "-113.3187").save
City.new(:country_id => "39", :name => "Sorel-Tracy", :aliases => "Sorel'-Trejsi,Ð¡Ð¾ÑÐµÐ»Ñ-Ð¢ÑÐµÐ¹ÑÐ¸,Sorel-Tracy", :latitude => "46.03336", :longitude => "-73.11585").save
City.new(:country_id => "39", :name => "Spruce Grove", :aliases => ",Spruce Grove", :latitude => "53.53344", :longitude => "-113.91874").save
City.new(:country_id => "39", :name => "St. Albert", :aliases => ",St. Albert", :latitude => "53.63344", :longitude => "-113.63533").save
City.new(:country_id => "39", :name => "St. Catharines", :aliases => "Saint Catharines,Sankta Katarino,St. Catharines,sentokyasarinzu,ã»ã³ãã­ã£ãµãªã³ãº,St. Catharines", :latitude => "43.16681", :longitude => "-79.24958").save
City.new(:country_id => "39", :name => "Stratford", :aliases => "Stratford,Ð¡ÑÑÐ°ÑÑÐ¾ÑÐ´,Stratford", :latitude => "43.36679", :longitude => "-80.94972").save
City.new(:country_id => "39", :name => "St. Thomas", :aliases => ",St. Thomas", :latitude => "42.77361", :longitude => "-81.18038").save
City.new(:country_id => "39", :name => "Surrey", :aliases => ",Surrey", :latitude => "49.10635", :longitude => "-122.82509").save
City.new(:country_id => "39", :name => "Terrace", :aliases => ",Terrace", :latitude => "54.51634", :longitude => "-128.60345").save
City.new(:country_id => "39", :name => "Terrebonne", :aliases => ",Terrebonne", :latitude => "45.70004", :longitude => "-73.64732").save
City.new(:country_id => "39", :name => "Thorold", :aliases => ",Thorold", :latitude => "43.11682", :longitude => "-79.19958").save
City.new(:country_id => "39", :name => "Thunder Bay", :aliases => "Tander Bej,Tander-Bej,Thunder Bay,sandabei,Ð¢Ð°Ð½Ð´ÐµÑ ÐÐµÐ¹,Ð¢Ð°Ð½Ð´ÐµÑ-ÐÐµÐ¹,ãµã³ãã¼ãã¤,Thunder Bay", :latitude => "48.4001", :longitude => "-89.31683").save
City.new(:country_id => "39", :name => "Timmins", :aliases => ",Timmins", :latitude => "48.46686", :longitude => "-81.33312").save
City.new(:country_id => "39", :name => "Toronto", :aliases => "Torontas,Toronto,Torontu,TorontÃ³,YTO,duo lun duo,roranro,tho rxn to,tolonto,toronto,twrntw,twrwntw,Î¤Î¿ÏÏÎ½ÏÎ¿,Ð¢Ð¾ÑÐ¾Ð½ÑÐ¾,×××¨×× ××,ØªÙØ±ÙØªÙ,ØªÙØ±ÙÙØªÙ,à®°à¯à®±à®©à¯à®°à¯,à¹à¸à¸£à¸­à¸à¹à¸,ãã­ã³ã,å¤ä¼¦å¤,í ë¡ í ,Toronto", :latitude => "43.70011", :longitude => "-79.4163").save
City.new(:country_id => "39", :name => "Trois-Rivieres", :aliases => "Trois-Rivieres,Trois-RiviÃ¨res,Trua-Riv'er,torowaribieru,torowarivu~ieru,Ð¢ÑÑÐ°-Ð Ð¸Ð²ÑÐµÑ,ãã­ã¯ãªãã¨ã¼ã«,ãã­ã¯ãªã´ã£ã¨ã¼ã«,Trois-RiviÃ¨res", :latitude => "46.35006", :longitude => "-72.54912").save
City.new(:country_id => "39", :name => "Truro", :aliases => ",Truro", :latitude => "45.36685", :longitude => "-63.26538").save
City.new(:country_id => "39", :name => "Val-d'Or", :aliases => ",Val-d'Or", :latitude => "48.10018", :longitude => "-77.7828").save
City.new(:country_id => "39", :name => "Vancouver", :aliases => "Ban'kouber,Vancouver,Vankuver,Vankuvera,Vankuvero,Vankuvur,VankÅ«vera,baenkubeo,bankuba,bankuba shi,wen ge hua,wnkwwr,wnkwwr, brytysh klmbya,wnqwbr,ÎÎ±Î½ÎºÎ¿ÏÎ²ÎµÏ,ÐÐ°Ð½ÐºÑÐ²ÐµÑ,ÐÐ°Ð½ÐºÑÐ²ÑÑ,×× ×§×××¨,ÙÙÚ©ÙÙØ±,ÙÙÚ©ÙÙØ±Ø Ø¨Ø±ÛØªÛØ´ Ú©ÙÙØ¨ÛØ§,ÛÛÙÙÛÛÛØ±,ãã³ã¯ã¼ãã¼,ãã³ã¯ã¼ãã¼å¸,æº«å¥è¯,ë°´ì¿ ë²,Vancouver", :latitude => "49.24966", :longitude => "-123.11934").save
City.new(:country_id => "39", :name => "Varennes", :aliases => ",Varennes", :latitude => "45.68338", :longitude => "-73.43246").save
City.new(:country_id => "39", :name => "Vaudreuil-Dorion", :aliases => ",Vaudreuil-Dorion", :latitude => "45.40008", :longitude => "-74.03251").save
City.new(:country_id => "39", :name => "Vaughan", :aliases => ",Vaughan", :latitude => "43.83341", :longitude => "-79.53291").save
City.new(:country_id => "39", :name => "Vernon", :aliases => ",Vernon", :latitude => "50.25809", :longitude => "-119.26905").save
City.new(:country_id => "39", :name => "Victoria", :aliases => "Victoria,Viktorija,Viktorio,bikutoria,vu~ikutoria,wei duo li ya,wyqtwryh,ÐÐ¸ÐºÑÐ¾ÑÐ¸Ñ,ÐÐ¸ÐºÑÐ¾ÑÐ¸ÑÐ°,×××§×××¨××,ãã¯ããªã¢,ã´ã£ã¯ããªã¢,ç¶­å¤å©äº,Victoria", :latitude => "48.43294", :longitude => "-123.3693").save
City.new(:country_id => "39", :name => "Victoriaville", :aliases => ",Victoriaville", :latitude => "46.05007", :longitude => "-71.96579").save
City.new(:country_id => "39", :name => "Waterloo", :aliases => "Vaterloo,ÐÐ°ÑÐµÑÐ»Ð¾Ð¾,Waterloo", :latitude => "43.4668", :longitude => "-80.51639").save
City.new(:country_id => "39", :name => "Welland", :aliases => ",Welland", :latitude => "42.98342", :longitude => "-79.24958").save
City.new(:country_id => "39", :name => "Westmount", :aliases => ",Westmount", :latitude => "45.48341", :longitude => "-73.59918").save
City.new(:country_id => "39", :name => "Whitehorse", :aliases => "Equus Albus,Uajtkhors,Vajtkhors,Whitehorse,bai ma shi,howaitohosu,ÐÐ°ÑÑÑÐ¾ÑÑ,Ð£Ð°Ð¹ÑÑÐ¾ÑÑ,ãã¯ã¤ããã¼ã¹,ç½é¦¬å¸,Whitehorse", :latitude => "60.71611", :longitude => "-135.05375").save
City.new(:country_id => "39", :name => "White Rock", :aliases => "White Rock,White Rock", :latitude => "49.01636", :longitude => "-122.8026").save
City.new(:country_id => "39", :name => "Windsor", :aliases => "Vindzor,Windsor,uinza,u~inza,wen sha,wyndzwr,ÐÐ¸Ð½Ð´Ð·Ð¾Ñ,ÙÛÙØ¯Ø²ÙØ±,ã¦ã£ã³ã¶ã¼,ã¦ã¤ã³ã¶ã¼,æ¸©è,Windsor", :latitude => "42.30008", :longitude => "-83.01654").save
City.new(:country_id => "39", :name => "Winnipeg", :aliases => "Vinipeg,Vinipego,Vinnipeg,WPG,Winnipeg,Winnipeg City,u~inipegu,wen ni bo,wynypg,ÐÐ¸Ð½Ð¸Ð¿ÐµÐ³,ÐÐ¸Ð½Ð½Ð¸Ð¿ÐµÐ³,ÐÑÐ½Ð½ÑÐ¿ÐµÐ³,ÐÑÐ½Ð½ÑÐ¿ÐµÒ,××× ××¤×,ÙÛÙÛÙ¾Ú¯,ã¦ã£ããã°,æ¸©å°¼ä¼¯,Winnipeg", :latitude => "49.8844", :longitude => "-97.14704").save
City.new(:country_id => "39", :name => "Woodstock", :aliases => "Vudstok,ÐÑÐ´ÑÑÐ¾Ðº,Woodstock", :latitude => "43.13339", :longitude => "-80.7497").save
City.new(:country_id => "39", :name => "Yellowknife", :aliases => "Cultellus Flavus,Yellowknife,ieronaifu,ye luo na fu,yellonaipeu,ã¤ã¨ã­ã¼ãã¤ã,è¶ç½çº³å¤«,ìë¡ëì´í,Yellowknife", :latitude => "62.456", :longitude => "-114.35255").save
City.new(:country_id => "39", :name => "Yorkton", :aliases => ",Yorkton", :latitude => "51.2167", :longitude => "-102.46766").save
City.new(:country_id => "39", :name => "Halifax", :aliases => "Galifaks,Halifax,ÐÐ°Ð»Ð¸ÑÐ°ÐºÑ,Halifax", :latitude => "44.64533", :longitude => "-63.57239").save
City.new(:country_id => "39", :name => "St. John's", :aliases => "Saint John's,Sent-Dzhons,St Johns,St. John's,Ð¡ÐµÐ½Ñ-ÐÐ¶Ð¾Ð½Ñ,St. John's", :latitude => "47.56494", :longitude => "-52.70931").save
City.new(:country_id => "39", :name => "Quebec", :aliases => "Kvebek,Quebec,Quebec City,QuÃ©bec,Ville de Quebec,Ville de QuÃ©bec,ÐÐ²ÐµÐ±ÐµÐº,QuÃ©bec", :latitude => "46.81228", :longitude => "-71.21454").save
City.new(:country_id => "39", :name => "Levis", :aliases => ",LÃ©vis", :latitude => "46.80326", :longitude => "-71.17793").save
City.new(:country_id => "39", :name => "Rimouski", :aliases => ",Rimouski", :latitude => "48.44879", :longitude => "-68.52396").save
City.new(:country_id => "39", :name => "Riviere-du-Loup", :aliases => ",RiviÃ¨re-du-Loup", :latitude => "47.83044", :longitude => "-69.53419").save
City.new(:country_id => "39", :name => "Sydney", :aliases => ",Sydney", :latitude => "46.1351", :longitude => "-60.1831").save
City.new(:country_id => "39", :name => "L'Ancienne-Lorette", :aliases => ",L'Ancienne-Lorette", :latitude => "46.79392", :longitude => "-71.35191").save
City.new(:country_id => "39", :name => "Edmundston", :aliases => ",Edmundston", :latitude => "47.3737", :longitude => "-68.32512").save
City.new(:country_id => "39", :name => "Thetford-Mines", :aliases => ",Thetford-Mines", :latitude => "46.09371", :longitude => "-71.30539").save
City.new(:country_id => "39", :name => "Cole Harbour", :aliases => ",Cole Harbour", :latitude => "44.67244", :longitude => "-63.47506").save
City.new(:country_id => "39", :name => "West Kelowna", :aliases => "District of West Kelowna,West Kelowna,uesutokerouna,u~esutokerouna,ã¦ã§ã¹ãã±ã­ã¦ã,ã¦ã¨ã¹ãã±ã­ã¦ã,West Kelowna", :latitude => "49.8625", :longitude => "-119.58333").save
City.new(:country_id => "39", :name => "Bellechasse Regional County Municipality", :aliases => "Bellechasse,Bellechasse Regional County Municipality,Bellechasse Regional County Municipality", :latitude => "46.66667", :longitude => "-70.71667").save
City.new(:country_id => "39", :name => "Jonquiere", :aliases => ",JonquiÃ¨re", :latitude => "48.41648", :longitude => "-71.24884").save
City.new(:country_id => "39", :name => "Saint-Augustin-de-Desmaures", :aliases => ",Saint-Augustin-de-Desmaures", :latitude => "46.74064", :longitude => "-71.45131").save
City.new(:country_id => "39", :name => "Ladner", :aliases => ",Ladner", :latitude => "49.08938", :longitude => "-123.08241").save
City.new(:country_id => "39", :name => "Walnut Grove", :aliases => ",Walnut Grove", :latitude => "49.16473", :longitude => "-122.64042").save
