City.new(:country_id => "113", :name => "Saint Helier", :aliases => "Saint Helier,Sent-Khel'er,Ð¡ÐµÐ½Ñ-Ð¥ÐµÐ»ÑÐµÑ,Saint Helier", :latitude => "49.18333", :longitude => "-2.1").save
