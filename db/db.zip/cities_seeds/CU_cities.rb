City.new(:country_id => "52", :name => "Yara", :aliases => "Poblado Yara,Yara,Yara", :latitude => "20.27528", :longitude => "-76.95333").save
City.new(:country_id => "52", :name => "Yaguajay", :aliases => ",Yaguajay", :latitude => "22.32722", :longitude => "-79.23778").save
City.new(:country_id => "52", :name => "Vinales", :aliases => "Vin'jales,Vinales,ViÃ±ales,ÐÐ¸Ð½ÑÑÐ»ÐµÑ,ViÃ±ales", :latitude => "22.61639", :longitude => "-83.70778").save
City.new(:country_id => "52", :name => "Vertientes", :aliases => ",Vertientes", :latitude => "21.25944", :longitude => "-78.14639").save
City.new(:country_id => "52", :name => "Venezuela", :aliases => "Stewart,Venezuela,Venezuela", :latitude => "21.73528", :longitude => "-78.79639").save
City.new(:country_id => "52", :name => "Varadero", :aliases => "La Varadero,Varadero,Veradero,ÐÐ°ÑÐ°Ð´ÐµÑÐ¾,Varadero", :latitude => "23.15361", :longitude => "-81.25139").save
City.new(:country_id => "52", :name => "Union de Reyes", :aliases => "Union Reyes,Union de Reyes,UniÃ³n de Reyes,UniÃ³n de Reyes", :latitude => "22.79528", :longitude => "-81.5375").save
City.new(:country_id => "52", :name => "Trinidad", :aliases => "Trinidad,Ð¢ÑÐ¸Ð½Ð¸Ð´Ð°Ð´,Trinidad", :latitude => "21.80194", :longitude => "-79.98417").save
City.new(:country_id => "52", :name => "Sibanicu", :aliases => "Poblado Sibanicu,Sibanicu,SibanicÃº,SibanicÃº", :latitude => "21.235", :longitude => "-77.52639").save
City.new(:country_id => "52", :name => "Santo Domingo", :aliases => ",Santo Domingo", :latitude => "22.58667", :longitude => "-80.24361").save
City.new(:country_id => "52", :name => "Santiago de las Vegas", :aliases => "Sant'jago-de-las-Vegas,Santiago de las Vegas,Ð¡Ð°Ð½ÑÑÑÐ³Ð¾-Ð´Ðµ-Ð»Ð°Ñ-ÐÐµÐ³Ð°Ñ,Santiago de las Vegas", :latitude => "22.97", :longitude => "-82.38694").save
City.new(:country_id => "52", :name => "Santiago de Cuba", :aliases => "Sant'jago-de-Kuba,Santiago,Santiago de Cuba,Santiago de Kubo,Santiago di Cuba,Santjago de Kuba,Ð¡Ð°Ð½ÑÑÑÐ³Ð¾-Ð´Ðµ-ÐÑÐ±Ð°,Ð¡Ð°Ð½ÑÑÐ³Ð¾ Ð´Ðµ ÐÑÐ±Ð°,×¡× ××××× ×× ×§×××,ãµã³ãã£ã¢ã¼ã´ã»ãã»ã¯ã¼ã,Santiago de Cuba", :latitude => "20.02472", :longitude => "-75.82194").save
City.new(:country_id => "52", :name => "Santa Cruz del Sur", :aliases => ",Santa Cruz del Sur", :latitude => "20.71472", :longitude => "-77.99556").save
City.new(:country_id => "52", :name => "Santa Cruz del Norte", :aliases => "Santa Cruz del Norte,Santa Cruz del Norte", :latitude => "23.15389", :longitude => "-81.92361").save
City.new(:country_id => "52", :name => "Santa Clara", :aliases => "Santa Clara,Santa Klara,Î£Î¬Î½ÏÎ± ÎÎ»Î¬ÏÎ±,Ð¡Ð°Ð½ÑÐ° ÐÐ»Ð°ÑÐ°,ãµã³ã¿ã»ã¯ã©ã©,Santa Clara", :latitude => "22.4", :longitude => "-79.96667").save
City.new(:country_id => "52", :name => "San Luis", :aliases => "San Luis,San Luis", :latitude => "20.1875", :longitude => "-75.85083").save
City.new(:country_id => "52", :name => "San Jose de las Lajas", :aliases => ",San JosÃ© de las Lajas", :latitude => "22.96139", :longitude => "-82.15111").save
City.new(:country_id => "52", :name => "Sancti Spiritus", :aliases => "Sancti Spiritus,Sancti SpÃ­ritus,Sankti-Spiritus,Ð¡Ð°Ð½ÐºÑÐ¸-Ð¡Ð¿Ð¸ÑÐ¸ÑÑÑ,Sancti SpÃ­ritus", :latitude => "21.92972", :longitude => "-79.4425").save
City.new(:country_id => "52", :name => "San Cristobal", :aliases => ",San CristÃ³bal", :latitude => "22.71417", :longitude => "-83.04806").save
City.new(:country_id => "52", :name => "San Antonio de los Banos", :aliases => "San Antonio de los Banos,San Antonio de los BaÃ±os,San Antonio de los BaÃ±os", :latitude => "22.89111", :longitude => "-82.49917").save
City.new(:country_id => "52", :name => "Sagua la Grande", :aliases => "Sagua,Sagua la Grande,Sagua la Grande", :latitude => "22.80667", :longitude => "-80.07556").save
City.new(:country_id => "52", :name => "Sagua de Tanamo", :aliases => "Sagua de Tanamo,Sagua de Temamo,Sagua de TÃ¡namo,Sagua de TÃ¡namo", :latitude => "20.58194", :longitude => "-75.24139").save
City.new(:country_id => "52", :name => "Rodas", :aliases => "Robas,Rodas,Rodas", :latitude => "22.34083", :longitude => "-80.55722").save
City.new(:country_id => "52", :name => "Rio Guayabal de Yateras", :aliases => ",RÃ­o Guayabal de Yateras", :latitude => "20.36667", :longitude => "-75.01667").save
City.new(:country_id => "52", :name => "Rio Cauto", :aliases => ",RÃ­o Cauto", :latitude => "20.56028", :longitude => "-76.91611").save
City.new(:country_id => "52", :name => "Remedios", :aliases => "Remedios,San Juan de los Remedios,Ð ÐµÐ¼ÐµÐ´Ð¸Ð¾Ñ,Remedios", :latitude => "22.49472", :longitude => "-79.54583").save
City.new(:country_id => "52", :name => "Ranchuelo", :aliases => ",Ranchuelo", :latitude => "22.37722", :longitude => "-80.14889").save
City.new(:country_id => "52", :name => "Puerto Padre", :aliases => "Puehrto-Padre,Puerto Padre,ÐÑÑÑÑÐ¾-ÐÐ°Ð´ÑÐµ,Puerto Padre", :latitude => "21.195", :longitude => "-76.60278").save
City.new(:country_id => "52", :name => "Primero de Enero", :aliases => "Primero de Enero,Violeta,Primero de Enero", :latitude => "21.94694", :longitude => "-78.42833").save
City.new(:country_id => "52", :name => "Placetas", :aliases => ",Placetas", :latitude => "22.31194", :longitude => "-79.65333").save
City.new(:country_id => "52", :name => "Pinar del Rio", :aliases => "Pinar del Rio,Pinar del Rioko probintzia,Pinar del RÃ­o,Pinar-del'-Rio,ÐÐ¸Ð½Ð°Ñ Ð´ÐµÐ» Ð Ð¸Ð¾,ÐÐ¸Ð½Ð°Ñ-Ð´ÐµÐ»Ñ-Ð Ð¸Ð¾,Pinar del RÃ­o", :latitude => "22.4175", :longitude => "-83.69806").save
City.new(:country_id => "52", :name => "Perico", :aliases => ",Perico", :latitude => "22.76917", :longitude => "-81.01889").save
City.new(:country_id => "52", :name => "Pedro Betancourt", :aliases => "Corral Falso,Pedro Betancourt,Pedro Betancourt", :latitude => "22.72722", :longitude => "-81.29").save
City.new(:country_id => "52", :name => "Palmira", :aliases => ",Palmira", :latitude => "22.24167", :longitude => "-80.39028").save
City.new(:country_id => "52", :name => "Palma Soriano", :aliases => ",Palma Soriano", :latitude => "20.21722", :longitude => "-75.99889").save
City.new(:country_id => "52", :name => "Nuevitas", :aliases => ",Nuevitas", :latitude => "21.54528", :longitude => "-77.26444").save
City.new(:country_id => "52", :name => "Nueva Gerona", :aliases => "Nuehva-Kherona,Nueva Gerona,ÐÑÑÐ²Ð°-Ð¥ÐµÑÐ¾Ð½Ð°,Nueva Gerona", :latitude => "21.88333", :longitude => "-82.8").save
City.new(:country_id => "52", :name => "Niquero", :aliases => "Niguero,Niquero,Niquero", :latitude => "20.04306", :longitude => "-77.58278").save
City.new(:country_id => "52", :name => "Moron", :aliases => "Moron,MorÃ³n,ÐÐ¾ÑÐ¾Ð½,MorÃ³n", :latitude => "22.10944", :longitude => "-78.6275").save
City.new(:country_id => "52", :name => "Moa", :aliases => "Minas de Hierro Moa,Moa,Puerto Cayo Moa,ÐÐ¾Ð°,Moa", :latitude => "20.65694", :longitude => "-74.94028").save
City.new(:country_id => "52", :name => "Minas", :aliases => "Minas,Poblado Minas,ÐÐ¸Ð½Ð°Ñ,Minas", :latitude => "21.48333", :longitude => "-77.61667").save
City.new(:country_id => "52", :name => "Media Luna", :aliases => ",Media Luna", :latitude => "20.14194", :longitude => "-77.435").save
City.new(:country_id => "52", :name => "Matanzas", :aliases => "Matanzas,ÐÐ°ÑÐ°Ð½Ð·Ð°Ñ,Matanzas", :latitude => "23.04111", :longitude => "-81.5775").save
City.new(:country_id => "52", :name => "Mariel", :aliases => ",Mariel", :latitude => "22.9875", :longitude => "-82.75361").save
City.new(:country_id => "52", :name => "Manzanillo", :aliases => "Mansanil'o,Manzanillo,ÐÐ°Ð½ÑÐ°Ð½Ð¸Ð»ÑÐ¾,Manzanillo", :latitude => "20.34333", :longitude => "-77.11667").save
City.new(:country_id => "52", :name => "Manicaragua", :aliases => "Manicaragua,Poblado Manicaragua,Manicaragua", :latitude => "22.14944", :longitude => "-79.97361").save
City.new(:country_id => "52", :name => "Madruga", :aliases => ",Madruga", :latitude => "22.91139", :longitude => "-81.85611").save
City.new(:country_id => "52", :name => "Los Palacios", :aliases => ",Los Palacios", :latitude => "22.58722", :longitude => "-83.24861").save
City.new(:country_id => "52", :name => "Las Tunas", :aliases => "Las Tunas,Las-Tunas,Tunas,Victoria,Victoria de las Tunas,ÐÐ°Ñ-Ð¢ÑÐ½Ð°Ñ,Las Tunas", :latitude => "20.96167", :longitude => "-76.95111").save
City.new(:country_id => "52", :name => "La Salud", :aliases => "La Saljud,La Salud,Salud,ÐÐ° Ð¡Ð°Ð»ÑÐ´,La Salud", :latitude => "22.87139", :longitude => "-82.42389").save
City.new(:country_id => "52", :name => "Havana", :aliases => "A Habana - La Habana,Abana,Gavana,Habana,Havana,Havanna,Havano,Hawana,Khavana,L'Avana,L'Havana,La Habana,La Havane,abana,ha wa na,habana,hafana,havana,hawana,ÎÎ²Î¬Î½Î±,ÐÐ°Ð²Ð°Ð½Ð°,Ð¥Ð°Ð²Ð°Ð½Ð°,××××× ×,ÙØ§ÙØ§ÙØ§,ÙØ§ÙØ§ÙØ§,à½§à¼à½à½,á°ááááá,áá«á,ááá­,ããã,åç¦é£,ìë°ë,Havana", :latitude => "23.13302", :longitude => "-82.38304").save
City.new(:country_id => "52", :name => "Jovellanos", :aliases => "Bemba,Jovallanos,Jovellanos,Jovellanos", :latitude => "22.80444", :longitude => "-81.19444").save
City.new(:country_id => "52", :name => "Jobabo", :aliases => "Jaboba,Jobabo,Jobabo", :latitude => "20.96917", :longitude => "-76.29944").save
City.new(:country_id => "52", :name => "Jiguani", :aliases => ",JiguanÃ­", :latitude => "20.36667", :longitude => "-76.42722").save
City.new(:country_id => "52", :name => "Jatibonico", :aliases => "Jatibonico,Jatibonico", :latitude => "21.94194", :longitude => "-79.17").save
City.new(:country_id => "52", :name => "Jaruco", :aliases => "Jaruco,Jaruco", :latitude => "23.04306", :longitude => "-82.01083").save
City.new(:country_id => "52", :name => "Jaguey Grande", :aliases => ",JagÃ¼ey Grande", :latitude => "22.52694", :longitude => "-81.12861").save
City.new(:country_id => "52", :name => "Holguin", :aliases => "Holguin,HolguÃ­n,Holquin,Ol'gin,hwlgyn,orugin,ÐÐ»ÑÐ³Ð¸Ð½,××××××,ãªã«ã®ã³,HolguÃ­n", :latitude => "20.88722", :longitude => "-76.26306").save
City.new(:country_id => "52", :name => "Guisa", :aliases => "Guisa,Poblado Guisa,Guisa", :latitude => "20.255", :longitude => "-76.53861").save
City.new(:country_id => "52", :name => "Guira de Melena", :aliases => "Gueira de Melena,Guira de Melena,GÃ¼ira de Melena,GÃ¼ira de Melena", :latitude => "22.79056", :longitude => "-82.50528").save
City.new(:country_id => "52", :name => "Gueines", :aliases => "Guines,ÐÑÐ¸Ð½ÐµÑ,GÃ¼ines", :latitude => "22.83611", :longitude => "-82.02806").save
City.new(:country_id => "52", :name => "Guantanamo", :aliases => "Guantanama,Guantanamo,GuantÃ¡namo,Guatanamo,guantanamo,ÐÑÐ°Ð½ÑÐ°Ð½Ð°Ð¼Ð°,ÐÑÐ°Ð½ÑÐ°Ð½Ð°Ð¼Ð¾,×××× ×× ××,ã°ã¢ã³ã¿ãã¢,GuantÃ¡namo", :latitude => "20.14444", :longitude => "-75.20917").save
City.new(:country_id => "52", :name => "Guane", :aliases => ",Guane", :latitude => "22.2025", :longitude => "-84.0875").save
City.new(:country_id => "52", :name => "Guanajay", :aliases => ",Guanajay", :latitude => "22.92639", :longitude => "-82.6875").save
City.new(:country_id => "52", :name => "Guaimaro", :aliases => "Guaimaro,Guasimaro,Guaymaro,GuÃ¡imaro,GuÃ¡imaro", :latitude => "21.05", :longitude => "-77.35").save
City.new(:country_id => "52", :name => "Gibara", :aliases => ",Gibara", :latitude => "21.10972", :longitude => "-76.13167").save
City.new(:country_id => "52", :name => "Fomento", :aliases => ",Fomento", :latitude => "22.10389", :longitude => "-79.72167").save
City.new(:country_id => "52", :name => "Florida", :aliases => "Florida,La Florida,Ð¤Ð»Ð¾ÑÐ¸Ð´Ð°,Florida", :latitude => "21.52472", :longitude => "-78.22583").save
City.new(:country_id => "52", :name => "Esmeralda", :aliases => "Ehsmeral'da,Esmeralda,La Esmeralda,Ð­ÑÐ¼ÐµÑÐ°Ð»ÑÐ´Ð°,Esmeralda", :latitude => "21.8525", :longitude => "-78.11694").save
City.new(:country_id => "52", :name => "Encrucijada", :aliases => ",Encrucijada", :latitude => "22.61694", :longitude => "-79.87111").save
City.new(:country_id => "52", :name => "Cumanayagua", :aliases => ",Cumanayagua", :latitude => "22.14944", :longitude => "-80.20222").save
City.new(:country_id => "52", :name => "Cueto", :aliases => ",Cueto", :latitude => "20.64389", :longitude => "-75.93556").save
City.new(:country_id => "52", :name => "Cruces", :aliases => "Cruces,Crues,Kruses,Las Cruces,ÐÑÑÑÐµÑ,Cruces", :latitude => "22.34111", :longitude => "-80.26667").save
City.new(:country_id => "52", :name => "Corralillo", :aliases => "Coralillo,Corralillo,Corralillo", :latitude => "22.98194", :longitude => "-80.58556").save
City.new(:country_id => "52", :name => "Contramaestre", :aliases => ",Contramaestre", :latitude => "20.29778", :longitude => "-76.24139").save
City.new(:country_id => "52", :name => "Consolacion del Sur", :aliases => "Consolacion,Consolacion del Sur,ConsolaciÃ³n,ConsolaciÃ³n del Sur,ConsolaciÃ³n del Sur", :latitude => "22.50472", :longitude => "-83.51361").save
City.new(:country_id => "52", :name => "Condado", :aliases => "Condado,General Machado,Kondado,ÐÐ¾Ð½Ð´Ð°Ð´Ð¾,Condado", :latitude => "21.87667", :longitude => "-79.84028").save
City.new(:country_id => "52", :name => "Colon", :aliases => ",ColÃ³n", :latitude => "22.71917", :longitude => "-80.90583").save
City.new(:country_id => "52", :name => "Colombia", :aliases => ",Colombia", :latitude => "20.98806", :longitude => "-77.42972").save
City.new(:country_id => "52", :name => "Cifuentes", :aliases => ",Cifuentes", :latitude => "22.645", :longitude => "-80.04611").save
City.new(:country_id => "52", :name => "Cienfuegos", :aliases => "Cienfuegos,S'enfuehgos,shienfuegosu,Ð¡ÑÐµÐ½ÑÑÑÐ³Ð¾Ñ,ã·ã¨ã³ãã¨ã¼ã´ã¹,Cienfuegos", :latitude => "22.14611", :longitude => "-80.43556").save
City.new(:country_id => "52", :name => "Ciego de Avila", :aliases => "Ciego de Avila,Ciego de Ãvila,Ciego de Ãvila", :latitude => "21.84", :longitude => "-78.76194").save
City.new(:country_id => "52", :name => "Chambas", :aliases => ",Chambas", :latitude => "22.19278", :longitude => "-78.91361").save
City.new(:country_id => "52", :name => "Cardenas", :aliases => "Cardenas,CÃ¡rdenas,Kardenas,ÐÐ°ÑÐ´ÐµÐ½Ð°Ñ,CÃ¡rdenas", :latitude => "23.0375", :longitude => "-81.20472").save
City.new(:country_id => "52", :name => "Campechuela", :aliases => ",Campechuela", :latitude => "20.23417", :longitude => "-77.27889").save
City.new(:country_id => "52", :name => "Camajuani", :aliases => ",CamajuanÃ­", :latitude => "22.48333", :longitude => "-79.75").save
City.new(:country_id => "52", :name => "Camaguey", :aliases => "Camagueey,Camaguey,CamagÃ¼ey,Kamaguehj,Kamaguej,Puerto Principe,kamaguei,ÐÐ°Ð¼Ð°Ð³ÑÐµÐ¹,ÐÐ°Ð¼Ð°Ð³ÑÑÐ¹,×§×××××××,ã«ãã°ã¨ã¤,CamagÃ¼ey", :latitude => "21.38083", :longitude => "-77.91694").save
City.new(:country_id => "52", :name => "Calimete", :aliases => "Calimete,Poblado Calimete,Calimete", :latitude => "22.53333", :longitude => "-80.90611").save
City.new(:country_id => "52", :name => "Caibarien", :aliases => "Caibairien,Caibarien,CaibariÃ©n,CaibariÃ©n", :latitude => "22.52056", :longitude => "-79.46694").save
City.new(:country_id => "52", :name => "Cabaiguan", :aliases => "Cabaiguan,CabaiguÃ¡n,Poblado Cabaiguan,CabaiguÃ¡n", :latitude => "22.07889", :longitude => "-79.49917").save
City.new(:country_id => "52", :name => "Bejucal", :aliases => "Bejucal,Bejucall,Bejucal", :latitude => "22.92861", :longitude => "-82.38861").save
City.new(:country_id => "52", :name => "Bayamo", :aliases => "Bajamo,Bayamo,ÐÐ°ÑÐ¼Ð¾,Bayamo", :latitude => "20.37917", :longitude => "-76.64333").save
City.new(:country_id => "52", :name => "Bauta", :aliases => "Bauta,Hoyo Colorado,Bauta", :latitude => "22.98278", :longitude => "-82.54639").save
City.new(:country_id => "52", :name => "Baragua", :aliases => ",BaraguÃ¡", :latitude => "21.69667", :longitude => "-78.63278").save
City.new(:country_id => "52", :name => "Baracoa", :aliases => "Baracoa,Barakoa,ÐÐ°ÑÐ°ÐºÐ¾Ð°,Baracoa", :latitude => "20.34667", :longitude => "-74.49583").save
City.new(:country_id => "52", :name => "Banes", :aliases => ",Banes", :latitude => "20.9625", :longitude => "-75.71861").save
City.new(:country_id => "52", :name => "Bahia Honda", :aliases => ",BahÃ­a Honda", :latitude => "22.90361", :longitude => "-83.15917").save
City.new(:country_id => "52", :name => "Artemisa", :aliases => "Artemisa,ÐÑÑÐµÐ¼Ð¸ÑÐ°,Artemisa", :latitude => "22.81306", :longitude => "-82.76194").save
City.new(:country_id => "52", :name => "Alquizar", :aliases => ",AlquÃ­zar", :latitude => "22.80583", :longitude => "-82.58417").save
City.new(:country_id => "52", :name => "Alamar", :aliases => "Alamar,Nueva Villa Real,ÐÐ»Ð°Ð¼Ð°Ñ,Alamar", :latitude => "23.15833", :longitude => "-82.27694").save
City.new(:country_id => "52", :name => "Aguada de Pasajeros", :aliases => "Aguada,Aguada de Pasajeros,Aguada de Pasajeros", :latitude => "22.385", :longitude => "-80.85083").save
City.new(:country_id => "52", :name => "Abreus", :aliases => "Abreu,Abreus,Abreus", :latitude => "22.2775", :longitude => "-80.5675").save
City.new(:country_id => "52", :name => "Baguanos", :aliases => ",BÃ¡guanos", :latitude => "20.75167", :longitude => "-76.02694").save
