City.new(:country_id => "173", :name => "Wellington", :aliases => "Ouellinkton,Vellington,Wellington,ÎÏÎ­Î»Î»Î¹Î³ÎºÏÎ¿Î½,ÐÐµÐ»Ð»Ð¸Ð½Ð³ÑÐ¾Ð½,Wellington", :latitude => "-41.28664", :longitude => "174.77557").save
City.new(:country_id => "173", :name => "Wanganui", :aliases => "Vanganui,ÐÐ°Ð½Ð³Ð°Ð½ÑÐ¸,Wanganui", :latitude => "-39.93333", :longitude => "175.05").save
City.new(:country_id => "173", :name => "Timaru", :aliases => "Te Tihi-o-Maru,Timaru,Timaru City,Timaru-Distrikt,Ð¢Ð¸Ð¼Ð°ÑÑ,Timaru", :latitude => "-44.4", :longitude => "171.25").save
City.new(:country_id => "173", :name => "Taupo", :aliases => "Taupo,Taupo Town District,Taupo-nui-a-Tia,TaupÅ-nui-a-Tia,tao bo,Ð¢Ð°ÑÐ¿Ð¾,é¶æ³¢,Taupo", :latitude => "-38.68333", :longitude => "176.08333").save
City.new(:country_id => "173", :name => "Pukekohe East", :aliases => ",Pukekohe East", :latitude => "-37.2", :longitude => "174.95").save
City.new(:country_id => "173", :name => "Porirua", :aliases => "Porirua,ÐÐ¾ÑÐ¸ÑÑÐ°,Porirua", :latitude => "-41.13333", :longitude => "174.85").save
City.new(:country_id => "173", :name => "Paraparaumu", :aliases => "Paraparaumu,ÐÐ°ÑÐ°Ð¿Ð°ÑÐ°ÑÐ¼Ñ,Paraparaumu", :latitude => "-40.91667", :longitude => "175.01667").save
City.new(:country_id => "173", :name => "Palmerston North", :aliases => "Palmerston North,Palmerston North City,Palmerston-Nort,Te Papa-i-oea,bei pa mo si dun,ÐÐ°Ð»Ð¼ÐµÑÑÑÐ¾Ð½-ÐÐ¾ÑÑ,åå¸è«æ¯é¡¿,Palmerston North", :latitude => "-40.35", :longitude => "175.61667").save
City.new(:country_id => "173", :name => "North Shore", :aliases => "Boreia Akte,Nort-Shor,North Shore,bei an shi,ÎÏÏÎµÎ¹Î± ÎÎºÏÎ®,ÐÐ¾ÑÑ-Ð¨Ð¾Ñ,åå²¸å¸,North Shore", :latitude => "-36.8", :longitude => "174.75").save
City.new(:country_id => "173", :name => "New Plymouth", :aliases => "Aberplymm Nowydh,N'ju-Plimut,New Plymouth,New Plymouth City,New Plymouth Ngamotu,New Plymouth NgÄmotu,Nueva Plymouth,nyupeullimeoseu,ÐÑÑ-ÐÐ»Ð¸Ð¼ÑÑ,ë´íë¦¬ë¨¸ì¤,New Plymouth", :latitude => "-39.06667", :longitude => "174.08333").save
City.new(:country_id => "173", :name => "Nelson", :aliases => "Nel'son,Nelson City,Whakatu,ÐÐµÐ»ÑÑÐ¾Ð½,Nelson", :latitude => "-41.28333", :longitude => "173.28333").save
City.new(:country_id => "173", :name => "Napier", :aliases => "Napier City,Nejpir,ÐÐµÐ¹Ð¿Ð¸Ñ,Napier", :latitude => "-39.48333", :longitude => "176.91667").save
City.new(:country_id => "173", :name => "Manukau City", :aliases => "Manukau,Manukau City", :latitude => "-36.99282", :longitude => "174.87986").save
City.new(:country_id => "173", :name => "Mangere", :aliases => ",Mangere", :latitude => "-36.96807", :longitude => "174.79875").save
City.new(:country_id => "173", :name => "Lower Hutt", :aliases => "Lower Hutt,Lower Hutt City,Lower Hutt", :latitude => "-41.21667", :longitude => "174.91667").save
City.new(:country_id => "173", :name => "Invercargill", :aliases => "Invercargill,Inverkargill,Waihopai,ÐÐ½Ð²ÐµÑÐºÐ°ÑÐ³Ð¸Ð»Ð»,Invercargill", :latitude => "-46.4", :longitude => "168.35").save
City.new(:country_id => "173", :name => "Hastings", :aliases => "Khejstings,Ð¥ÐµÐ¹ÑÑÐ¸Ð½Ð³Ñ,Hastings", :latitude => "-39.6381", :longitude => "176.84918").save
City.new(:country_id => "173", :name => "Hamilton", :aliases => "Gamil'ton,Hamilton,Hamilton City,Khamilt'n,Kirikiriroa,hamiruton,han mi er dun,ÐÐ°Ð¼Ð¸Ð»ÑÑÐ¾Ð½,Ð¥Ð°Ð¼Ð¸Ð»ÑÑÐ½,ããã«ãã³,æ±å¯å°é¡¿,Hamilton", :latitude => "-37.78333", :longitude => "175.28333").save
City.new(:country_id => "173", :name => "Dunedin", :aliases => "Dunedin,Dunidin,Otepoti,Taieri,dan ni ding,Åtepoti,ÐÑÐ½Ð¸Ð´Ð¸Ð½,ä½å°¼ä¸,Dunedin", :latitude => "-45.87416", :longitude => "170.50361").save
City.new(:country_id => "173", :name => "Christchurch", :aliases => "Christchurch,Krajstchjorch,Otautahi,ji du cheng,ke lai si te che qi,keulaiseuteucheochi,kuraisutochachi,qryystz'rz',Åtautahi,ÐÑÐ°Ð¹ÑÑÑÑÑÑ,×§×¨×××¡××¦'×¨×¥',Ú©Ø±Ø§ÛØ³ØªâÚØ±Ú,ã¯ã©ã¤ã¹ããã£ã¼ã,åèµæ¯ç¹å½»å¥,åºç£å,í¬ë¼ì´ì¤í¸ì²ì¹,Christchurch", :latitude => "-43.53333", :longitude => "172.63333").save
City.new(:country_id => "173", :name => "Auckland", :aliases => "Oklend,ÐÐºÐ»ÐµÐ½Ð´,Auckland", :latitude => "-36.86667", :longitude => "174.76667").save
City.new(:country_id => "173", :name => "Levin", :aliases => ",Levin", :latitude => "-40.63333", :longitude => "175.275").save
City.new(:country_id => "173", :name => "Gisborne", :aliases => "East Cape,Gisborn,Gisborne,Turanga-nui-a-Kiwa,TÅ«ranga-nui-a-Kiwa,gyzbrn,ÐÐ¸ÑÐ±Ð¾ÑÐ½,×××××¨×,Gisborne", :latitude => "-38.65333", :longitude => "178.00417").save
City.new(:country_id => "173", :name => "Masterton", :aliases => "Masterton,ÐÐ°ÑÑÐµÑÑÐ¾Ð½,Masterton", :latitude => "-40.95972", :longitude => "175.6575").save
City.new(:country_id => "173", :name => "Tauranga", :aliases => "Tauranga,Tauranga-moana,tauranga,Ð¢Ð°ÑÑÐ°Ð½Ð³Ð°,ã¿ã¦ã©ã³ã¬,Tauranga", :latitude => "-37.68611", :longitude => "176.16667").save
City.new(:country_id => "173", :name => "Papakura", :aliases => ",Papakura", :latitude => "-37.06572", :longitude => "174.94393").save
City.new(:country_id => "173", :name => "Whakatane", :aliases => ",Whakatane", :latitude => "-37.95855", :longitude => "176.98545").save
City.new(:country_id => "173", :name => "Whangarei", :aliases => "Vangarei,Whangarei,ÐÐ°Ð½Ð³Ð°ÑÐµÐ¸,Whangarei", :latitude => "-35.73167", :longitude => "174.32391").save
City.new(:country_id => "173", :name => "Cambridge", :aliases => ",Cambridge", :latitude => "-37.87822", :longitude => "175.4402").save
City.new(:country_id => "173", :name => "Rotorua", :aliases => "Rotorua,Rotorua-nui-a-Kahu,luo tuo lu ya,Ð Ð¾ÑÐ¾ÑÑÐ°,ç½æè·¯äº,Rotorua", :latitude => "-38.13874", :longitude => "176.24516").save
City.new(:country_id => "173", :name => "Blenheim", :aliases => "Blenkhejm,Waiharakeke,ÐÐ»ÐµÐ½ÑÐµÐ¹Ð¼,Blenheim", :latitude => "-41.51603", :longitude => "173.9528").save
City.new(:country_id => "173", :name => "Upper Hutt", :aliases => ",Upper Hutt", :latitude => "-41.13827", :longitude => "175.0502").save
City.new(:country_id => "173", :name => "Taradale", :aliases => "Taradale,Taradale Town District,Taradale", :latitude => "-39.53333", :longitude => "176.85").save
City.new(:country_id => "173", :name => "Waitakere", :aliases => ",Waitakere", :latitude => "-36.91754", :longitude => "174.65773").save
