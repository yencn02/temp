City.new(:country_id => "82", :name => "Saint-Laurent-du-Maroni", :aliases => "Laurent,Maroni,Saint Laurent,Sainte Laurent,Sen-Loran-dju-Maroni,Ð¡ÐµÐ½-ÐÐ¾ÑÐ°Ð½-Ð´Ñ-ÐÐ°ÑÐ¾Ð½Ð¸,Saint-Laurent-du-Maroni", :latitude => "5.5", :longitude => "-54.03333").save
City.new(:country_id => "82", :name => "Remire-Montjoly", :aliases => "Montjoli,RÃ©mire-Montjoly", :latitude => "4.91667", :longitude => "-52.26667").save
City.new(:country_id => "82", :name => "Matoury", :aliases => "Matoary,Matoury,Matoury", :latitude => "4.85", :longitude => "-52.33333").save
City.new(:country_id => "82", :name => "Kourou", :aliases => "Bourg de Kourou,Kouro,Kourou,Kur,White City,ÐÑÑ,Kourou", :latitude => "5.15", :longitude => "-52.65").save
City.new(:country_id => "82", :name => "Cayenne", :aliases => "Caiena,Caienna,Cayene,Cayenne,Kajenas,Kajenna,kaien'nu,ÐÐ°Ð¹ÐµÐ½Ð½Ð°,×§××××,ã«ã¤ã¨ã³ã,Cayenne", :latitude => "4.93333", :longitude => "-52.33333").save
