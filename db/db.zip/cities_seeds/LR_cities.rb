City.new(:country_id => "133", :name => "Zwedru", :aliases => "Tchien,Zvedru,Zwadhru,Zwedru,ÐÐ²ÐµÐ´ÑÑ,Zwedru", :latitude => "6.06667", :longitude => "-8.12806").save
City.new(:country_id => "133", :name => "New Yekepa", :aliases => "Lamco,Lamco Community,New Yekepa,Yekepa,New Yekepa", :latitude => "7.57944", :longitude => "-8.53778").save
City.new(:country_id => "133", :name => "Voinjama", :aliases => "Voinjama,Voinyamai,Vonjama,Voinjama", :latitude => "8.42194", :longitude => "-9.74778").save
City.new(:country_id => "133", :name => "Monrovia", :aliases => "Monrobia,Monrovia,Monrovija,Monrovio,Monrowia,MonrÃ³via,MonrÃ³vÃ­a,manrwwya,meng luo wei ya,monlobia,monrobia,mwnrwbyh,mwnrwfya,ÎÎ¿Î½ÏÏÎ²Î¹Î±,ÐÐ¾Ð½ÑÐ¾Ð²Ð¸Ñ,ÐÐ¾Ð½ÑÐ¾Ð²Ð¸ÑÐ°,××× ×¨××××,ÙØ§ÙØ±ÙÙÛØ§,ÙÙÙØ±ÙÙÙØ§,ááá®áªá«,ã¢ã³ã­ãã¢,èç½ç»´äº,èç¾ç¶­äº,ëª¬ë¡ë¹ì,Monrovia", :latitude => "6.30054", :longitude => "-10.7969").save
City.new(:country_id => "133", :name => "Kakata", :aliases => ",Kakata", :latitude => "6.53", :longitude => "-10.35167").save
City.new(:country_id => "133", :name => "Harper", :aliases => "Cape Palmas,Harper,Harper", :latitude => "4.375", :longitude => "-7.71694").save
City.new(:country_id => "133", :name => "Greenville", :aliases => "Greenville,Sino,Sinoe,Sinu,Sinu Village,Greenville", :latitude => "5.01111", :longitude => "-9.03889").save
City.new(:country_id => "133", :name => "Gbarnga", :aliases => "Gbanga,Gbanka,Gbarnga,Gbarnge,Gbarnka,ÐÐ±Ð°ÑÐ½Ð³Ðµ,Gbarnga", :latitude => "6.99556", :longitude => "-9.47222").save
City.new(:country_id => "133", :name => "Buchanan", :aliases => "B'jukenen,Buchanan,Fish Town,Grand Bassa,Lower Buchanan,ÐÑÑÐºÐµÐ½ÐµÐ½,Buchanan", :latitude => "5.88083", :longitude => "-10.04667").save
City.new(:country_id => "133", :name => "Bensonville", :aliases => "Bensonville,Bentol,Bentol City,ÐÐµÐ½ÑÐ¾Ð½Ð²Ð¸Ð»Ð»Ðµ,Bensonville", :latitude => "6.44611", :longitude => "-10.6125").save
