City.new(:country_id => "158", :name => "Karonga", :aliases => "Karonga,ÐÐ°ÑÐ¾Ð½Ð³Ð°,Karonga", :latitude => "-9.93333", :longitude => "33.93333").save
City.new(:country_id => "158", :name => "Zomba", :aliases => "Zomba,song ba,zonba,ÐÐ¾Ð¼Ð±Ð°,ã¾ã³ã,æ¾å·´,Zomba", :latitude => "-15.38596", :longitude => "35.3188").save
City.new(:country_id => "158", :name => "Salima", :aliases => "Salima,Ð¡Ð°Ð»Ð¸Ð¼Ð°,Salima", :latitude => "-13.78333", :longitude => "34.43333").save
City.new(:country_id => "158", :name => "Rumphi", :aliases => "Rumphi,Rumpi,Rumpi Boma,Rumphi", :latitude => "-11.01667", :longitude => "33.86667").save
City.new(:country_id => "158", :name => "Nsanje", :aliases => "Chimombi,Nsanje,Port Herald,Nsanje", :latitude => "-16.91667", :longitude => "35.26667").save
City.new(:country_id => "158", :name => "Nkhotakota", :aliases => "Kota Kota,Nkhotakota,Nkhotakota", :latitude => "-12.91667", :longitude => "34.3").save
City.new(:country_id => "158", :name => "Mzimba", :aliases => "Mzimba,ÐÐ·Ð¸Ð¼Ð±Ð°,Mzimba", :latitude => "-11.9", :longitude => "33.6").save
City.new(:country_id => "158", :name => "Mulanje", :aliases => "Mlange,Mlanje,Mlanje Boma,Mulanje,Mulanje", :latitude => "-16.02544", :longitude => "35.50402").save
City.new(:country_id => "158", :name => "Mchinji", :aliases => "Chimji,Fort Manning,Mchinji,Mchinji", :latitude => "-13.8", :longitude => "32.9").save
City.new(:country_id => "158", :name => "Mangochi", :aliases => "Fort Johnston,Mangoche,Mangochi,Mponda,ÐÐ°Ð½Ð³Ð¾ÑÐ¸,Mangochi", :latitude => "-14.46667", :longitude => "35.26667").save
City.new(:country_id => "158", :name => "Liwonde", :aliases => "Liwonde,Old Liwonde Boma,Liwonde", :latitude => "-15.06667", :longitude => "35.21667").save
City.new(:country_id => "158", :name => "Lilongwe", :aliases => "Lilon'nkoue,Lilonguee,Lilongve,LilongvÄ,Lilongwe,LilongÃ¼e,LÃ­longve,li long gui,lillong-gwe,lylwngwwh,rironguu~e,ÎÎ¹Î»ÏÎ½Î³ÎºÎ¿ÏÎµ,ÐÐ¸Ð»Ð¾Ð½Ð³Ð²Ðµ,Ô¼Õ«Õ¬Õ¸Õ¶Õ£Õ¾Õ¥,××××× ××××,ááááá,ãªã­ã³ã°ã¦ã§,å©éå­,ë¦´ë¡±ê¶¤,Lilongwe", :latitude => "-13.98333", :longitude => "33.78333").save
City.new(:country_id => "158", :name => "Kasungu", :aliases => "Kasungu,ÐÐ°ÑÑÐ½Ð³Ñ,Kasungu", :latitude => "-13.03333", :longitude => "33.48333").save
City.new(:country_id => "158", :name => "Dedza", :aliases => "Dedza,Dedza", :latitude => "-14.36667", :longitude => "34.33333").save
City.new(:country_id => "158", :name => "Blantyre", :aliases => "Blantairas,Blantajr,Blantyre,Kapeni,burantaiya,ÐÐ»Ð°Ð½ÑÐ°Ð¹Ñ,ãã©ã³ã¿ã¤ã¤,Blantyre", :latitude => "-15.78682", :longitude => "35.01387").save
City.new(:country_id => "158", :name => "Balaka", :aliases => "Balaka,Balakas,Palaka,ÐÐ°Ð»Ð°ÐºÐ°,Balaka", :latitude => "-14.98333", :longitude => "34.95").save
