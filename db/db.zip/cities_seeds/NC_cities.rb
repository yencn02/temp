City.new(:country_id => "163", :name => "Noumea", :aliases => "Noumea,NoumÃ©a,Numea,Port de France,numea,ÐÑÐ¼ÐµÐ°,ãã¡ã¢,ëë©ì,NoumÃ©a", :latitude => "-22.27631", :longitude => "166.4572").save
City.new(:country_id => "163", :name => "Mont-Dore", :aliases => ",Mont-Dore", :latitude => "-22.28333", :longitude => "166.58333").save
City.new(:country_id => "163", :name => "Dumbea", :aliases => ",DumbÃ©a", :latitude => "-22.15", :longitude => "166.45").save
