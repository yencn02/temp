City.new(:country_id => "68", :name => "Zubia", :aliases => "La Zubia,Zubia,Zubia", :latitude => "37.11667", :longitude => "-3.58333").save
City.new(:country_id => "68", :name => "Zafra", :aliases => "Zafra,Zafra", :latitude => "38.41667", :longitude => "-6.41667").save
City.new(:country_id => "68", :name => "Yecla", :aliases => "Ekla,Iecla,Yecla,ÐÐºÐ»Ð°,Yecla", :latitude => "38.61365", :longitude => "-1.11468").save
City.new(:country_id => "68", :name => "Villena", :aliases => "Vil'ena,Villena,ÐÐ¸Ð»ÑÐµÐ½Ð°,Villena", :latitude => "38.63333", :longitude => "-0.85").save
City.new(:country_id => "68", :name => "Villarrobledo", :aliases => "Billarrobledo,Vil'jarrobledo,Villa Robletum,Villarrobledo,biryaroburedo,ÎÎ¹Î»Î»Î±ÏÏÎ¿Î²Î»Î­Î´Î¿,ÐÐ¸Ð»ÑÑÑÑÐ¾Ð±Ð»ÐµÐ´Ð¾,ããªã£ã­ãã¬ã,Villarrobledo", :latitude => "39.26667", :longitude => "-2.6").save
City.new(:country_id => "68", :name => "Vila-real", :aliases => "Vila-Real,Vila-real,Villareal,Villarreal,ÐÐ¸Ð»Ð°-Ð ÐµÐ°Ð»,Vila-real", :latitude => "39.93333", :longitude => "-0.1").save
City.new(:country_id => "68", :name => "Villanueva de la Serena", :aliases => "Vil'januehva-de-la-Serena,Villanueva de la Serena,ÐÐ¸Ð»ÑÑÐ½ÑÑÐ²Ð°-Ð´Ðµ-Ð»Ð°-Ð¡ÐµÑÐµÐ½Ð°,Villanueva de la Serena", :latitude => "38.96667", :longitude => "-5.8").save
City.new(:country_id => "68", :name => "Villajoyosa", :aliases => "La Vila Joiosa,Villajoyosa,Villajoyosa", :latitude => "38.50754", :longitude => "-0.23346").save
City.new(:country_id => "68", :name => "Vicar", :aliases => ",VÃ­car", :latitude => "36.83155", :longitude => "-2.64273").save
City.new(:country_id => "68", :name => "Velez-Malaga", :aliases => "Veles-Malaga,Velez-Malaga,VÃ©lez-MÃ laga,VÃ©lez-MÃ¡laga,ÐÐµÐ»ÐµÑ-ÐÐ°Ð»Ð°Ð³Ð°,VÃ©lez-MÃ¡laga", :latitude => "36.78333", :longitude => "-4.1").save
City.new(:country_id => "68", :name => "Valencia", :aliases => "Balenzia,Lungsod ng Valencia,Lungsod ng ValÃ¨ncia,Valence,Valencia,Valencia - Valencia,Valencia - ValÃ¨ncia,Valencija,Valencio,Valensia,Valensija,Valensiya,Valentia,Valentzia,Valenza,ValÃ¨ncia,ValÃ©ncia,ValÃªncia,Walencja,ba lun xi ya,barenshia,blnsyt,valensia,wlnsyh,ÐÐ°Ð»ÐµÐ½ÑÐ¸Ñ,××× ×¡××,Ø¨ÙÙØ³ÙØ©,áááááá¡áá,ãã¬ã³ã·ã¢,å·´å«è¥¿äº,Valencia", :latitude => "39.46975", :longitude => "-0.37739").save
City.new(:country_id => "68", :name => "Valdepenas", :aliases => "Val'depen'jase,Valdepenas,ValdepeÃ±as,Yaldepenas,ÐÐ°Ð»ÑÐ´ÐµÐ¿ÐµÐ½ÑÑÑÐµ,ValdepeÃ±as", :latitude => "38.76667", :longitude => "-3.38333").save
City.new(:country_id => "68", :name => "Utrera", :aliases => "Utrera,Ð£ÑÑÐµÑÐ°,Utrera", :latitude => "37.18611", :longitude => "-5.78667").save
City.new(:country_id => "68", :name => "Ubrique", :aliases => "Ubrique,Ubrique", :latitude => "36.68333", :longitude => "-5.45").save
City.new(:country_id => "68", :name => "Ubeda", :aliases => "Ubeda,ubeda,Ãbeda,ã¦ãã,Ãbeda", :latitude => "38.01667", :longitude => "-3.36667").save
City.new(:country_id => "68", :name => "Totana", :aliases => "Totana,Ð¢Ð¾ÑÐ°Ð½Ð°,Totana", :latitude => "37.76667", :longitude => "-1.5").save
City.new(:country_id => "68", :name => "Torrox", :aliases => ",Torrox", :latitude => "36.75793", :longitude => "-3.95233").save
City.new(:country_id => "68", :name => "Torrevieja", :aliases => "Torrev'ekha,Torrevella,Torrevella de la Mata,Torrevieja,Ð¢Ð¾ÑÑÐµÐ²ÑÐµÑÐ°,Torrevieja", :latitude => "37.98333", :longitude => "-0.68333").save
City.new(:country_id => "68", :name => "Torre-Pacheco", :aliases => "Torre-Pacheco,Torre-Pacheko,Ð¢Ð¾ÑÑÐµ-ÐÐ°ÑÐµÐºÐ¾,Torre-Pacheco", :latitude => "37.73333", :longitude => "-0.95").save
City.new(:country_id => "68", :name => "Torrent", :aliases => "Torrent,Torrente,Torrent", :latitude => "39.43705", :longitude => "-0.46546").save
City.new(:country_id => "68", :name => "Torremolinos", :aliases => "Toremolinos-Malaga,Toremolinos-MÃ¡laga,Torremolinos,Torremolinos-Malaga,Torremolinos-MÃ¡laga,Ð¢Ð¾ÑÑÐµÐ¼Ð¾Ð»Ð¸Ð½Ð¾Ñ,Torremolinos", :latitude => "36.62035", :longitude => "-4.49976").save
City.new(:country_id => "68", :name => "Tomelloso", :aliases => "Tomel'oso,Ð¢Ð¾Ð¼ÐµÐ»ÑÐ¾ÑÐ¾,Tomelloso", :latitude => "39.15218", :longitude => "-3.02431").save
City.new(:country_id => "68", :name => "Tomares", :aliases => "Tomares,Tomares", :latitude => "37.38333", :longitude => "-6.03333").save
City.new(:country_id => "68", :name => "Toledo", :aliases => "Tolede,Toledo,Toletum,TolÃ¨de,tlytlt,toredo,tuo lai duo,twldw,Ð¢Ð¾Ð»ÐµÐ´Ð¾,×××××,Ø·ÙÙØ·ÙØ©,ãã¬ã,æèå¤,Toledo", :latitude => "39.8581", :longitude => "-4.02263").save
City.new(:country_id => "68", :name => "Tias", :aliases => "Tias,TÃ­as,TÃ­as", :latitude => "28.95", :longitude => "-13.65").save
City.new(:country_id => "68", :name => "Telde", :aliases => "Tel'de,Telde,Ð¢ÐµÐ»ÑÐ´Ðµ,Telde", :latitude => "28", :longitude => "-15.41667").save
City.new(:country_id => "68", :name => "Teguise", :aliases => "Teguise,Teguise", :latitude => "29.05", :longitude => "-13.55").save
City.new(:country_id => "68", :name => "Tarifa", :aliases => "Tarifa,Ð¢Ð°ÑÐ¸ÑÐ°,Tarifa", :latitude => "36.0125", :longitude => "-5.60556").save
City.new(:country_id => "68", :name => "Talavera de la Reina", :aliases => "Talavera de la Reina,Talavera del Tajo,Talavera de la Reina", :latitude => "39.95", :longitude => "-4.83333").save
City.new(:country_id => "68", :name => "Tacoronte", :aliases => "Tacoronte,Tacoronte", :latitude => "28.46667", :longitude => "-16.4").save
City.new(:country_id => "68", :name => "Tavernes de la Valldigna", :aliases => "Tabernas,Tabernes de Valldigna,Tavernes de la Valldigna,Tavernes de la Valldigna", :latitude => "39.06667", :longitude => "-0.26667").save
City.new(:country_id => "68", :name => "Sueca", :aliases => "Sueca,Sueca", :latitude => "39.2026", :longitude => "-0.31114").save
City.new(:country_id => "68", :name => "Silla", :aliases => "Silla,Silla", :latitude => "39.36667", :longitude => "-0.41667").save
City.new(:country_id => "68", :name => "Sevilla", :aliases => "Hispalis,Lungsod ng Sevilla,Sebilla,Sebille,Sevil'ja,Sevila,Sevilha,Sevilia,Sevilija,Sevilja,Sevilla,Seville,Sevilo,Seviya,SeviÄ¼a,Sewilla,Siviglia,SÃ©ville,ashbylyt,sai wei li ya,sbylyh,se will,sebirya,sebirya shi,sebiya,sevilia,Î£ÎµÎ²Î¯Î»Î»Î·,Ð¡ÐµÐ²Ð¸Ð»ÑÑ,Ð¡ÐµÐ²Ð¸Ð»Ñ,Ð¡ÐµÐ²Ð¸ÑÐ°,Ð¡ÑÐ²ÑÐ»ÑÐ»Ñ,×¡×××××,Ø¥Ø´Ø¨ÙÙÙØ©,Ø§Ø´Ø¨ÛÙÛÛ,à¹à¸à¸§à¸´à¸¥à¸¥à¹,á¡áááááá,ã»ããªã£,ã»ããªã£å¸,å¡ç¶­å©äº,ì¸ë¹ì¼,Sevilla", :latitude => "37.37722", :longitude => "-5.98694").save
City.new(:country_id => "68", :name => "San Vicent del Raspeig", :aliases => "San Vicente,San Vicente del Raspeig,Sant Vicent del Raspeig,San Vicent del Raspeig", :latitude => "38.3964", :longitude => "-0.5255").save
City.new(:country_id => "68", :name => "Santomera", :aliases => ",Santomera", :latitude => "38.06147", :longitude => "-1.04877").save
City.new(:country_id => "68", :name => "Santa Pola", :aliases => "Santa Pola,Santa-Pola,Ð¡Ð°Ð½ÑÐ°-ÐÐ¾Ð»Ð°,Santa Pola", :latitude => "38.19165", :longitude => "-0.5658").save
City.new(:country_id => "68", :name => "Santa Lucia", :aliases => "Santa Lucia de Tirajana,Santa LucÃ­a de Tirajana,Santa LucÃ­a", :latitude => "27.91174", :longitude => "-15.54071").save
City.new(:country_id => "68", :name => "Santa Eularia des Riu", :aliases => "Santa Eulalia del Rio,Santa Eulalia del RÃ­o,Santa Eularia del Riu,Santa Eularia des Riu,Santa EulÃ ria del Riu,Santa EulÃ ria des Riu,Santa EulÃ ria des Riu", :latitude => "38.98457", :longitude => "1.53409").save
City.new(:country_id => "68", :name => "Santa Cruz de Tenerife", :aliases => "Santa Cruz,Santa Cruz de Tenerife,Santa Cruz de TÃ©nÃ©rife,Santa-Krus-de-Tenerife,Tenerife,Teneriffa,Ð¡Ð°Ð½ÑÐ°-ÐÑÑÑ-Ð´Ðµ-Ð¢ÐµÐ½ÐµÑÐ¸ÑÐµ,ãµã³ã¿ã»ã¯ã«ã¹ã»ãã»ãããªãã§,Santa Cruz de Tenerife", :latitude => "28.46824", :longitude => "-16.25462").save
City.new(:country_id => "68", :name => "Santa Cruz de la Palma", :aliases => "Santa Cruz de La Palma,Santa Cruz de la Palma,Santa Cruz de la Palma", :latitude => "28.68351", :longitude => "-17.76421").save
City.new(:country_id => "68", :name => "Santa Brigida", :aliases => "Santa Brigida,Santa BrÃ­gida,Santa BrÃ­gida", :latitude => "28.03333", :longitude => "-15.5").save
City.new(:country_id => "68", :name => "San Roque", :aliases => "San Roque,San Roque", :latitude => "36.20944", :longitude => "-5.38528").save
City.new(:country_id => "68", :name => "San Pedro del Pinatar", :aliases => "San Pedro del Pintar,San Pedro del Pinatar", :latitude => "37.83568", :longitude => "-0.79102").save
City.new(:country_id => "68", :name => "San Miguel", :aliases => ",San Miguel", :latitude => "28.09826", :longitude => "-16.61708").save
City.new(:country_id => "68", :name => "Sanlucar de Barrameda", :aliases => "Sanlucar de Barrameda,Sanlukar-de-Barrameda,SanlÃºcar de Barrameda,Sunlucar de Barrameda,Ð¡Ð°Ð½Ð»ÑÐºÐ°Ñ-Ð´Ðµ-ÐÐ°ÑÑÐ°Ð¼ÐµÐ´Ð°,SanlÃºcar de Barrameda", :latitude => "36.78333", :longitude => "-6.35").save
City.new(:country_id => "68", :name => "San Juan de Aznalfarache", :aliases => "San Juan de Aznalfarache,San Juan de Aznalfarache", :latitude => "37.36667", :longitude => "-6.03333").save
City.new(:country_id => "68", :name => "San Juan de Alicante", :aliases => "San Juan de Alicante,Sant Joan d'Alacant,San Juan de Alicante", :latitude => "38.40148", :longitude => "-0.43623").save
City.new(:country_id => "68", :name => "Sant Josep de sa Talaia", :aliases => "San Jose,San Jose de la Atalaya,Sant Josep de sa Talaia,Sant Josep de sa Talaia", :latitude => "38.91667", :longitude => "1.28333").save
City.new(:country_id => "68", :name => "San Javier", :aliases => ",San Javier", :latitude => "37.80626", :longitude => "-0.83736").save
City.new(:country_id => "68", :name => "San Fernando", :aliases => "San Fernanando,San Fernando,San-Fernando,San Fernando", :latitude => "36.46667", :longitude => "-6.2").save
City.new(:country_id => "68", :name => "La Laguna", :aliases => "La Laguna,La-Laguna,San Cristobal de La Laguna,San CristÃ³bal de La Laguna,ÐÐ°-ÐÐ°Ð³ÑÐ½Ð°,La Laguna", :latitude => "28.48333", :longitude => "-16.31667").save
City.new(:country_id => "68", :name => "San Bartolome", :aliases => "San Bartolome Tirajana,San Bartolome de Tirajana,San BartolomÃ© Tirajana,San BartolomÃ© de Tirajana,San BartolomÃ©", :latitude => "27.92481", :longitude => "-15.57329").save
City.new(:country_id => "68", :name => "San Bartolome", :aliases => "San - Bartolome,San Bartolome,San BartolomÃ©,Ð¡Ð°Ð½ - ÐÐ°ÑÑÐ¾Ð»Ð¾Ð¼Ðµ,San BartolomÃ©", :latitude => "29.00093", :longitude => "-13.613").save
City.new(:country_id => "68", :name => "Sant Antoni de Portmany", :aliases => "San Antonio,Sant Antoni,Sant Antoni de Portmany,Sant Antoni de Portmany", :latitude => "38.98068", :longitude => "1.30362").save
City.new(:country_id => "68", :name => "Sagunto", :aliases => "Morvedre,Sagonte,Sagunt,Sagunto,Saguntum,sgwntwm,Ð¡Ð°Ð³ÑÐ½ÑÐ¾,×¡××× ×××,Sagunto", :latitude => "39.68333", :longitude => "-0.26667").save
City.new(:country_id => "68", :name => "Rota", :aliases => "Rota,Ð Ð¾ÑÐ°,Rota", :latitude => "36.61667", :longitude => "-6.35").save
City.new(:country_id => "68", :name => "Roquetas de Mar", :aliases => "Roketas-de-Mar,Roquetas,Roquetas de Mar,Ð Ð¾ÐºÐµÑÐ°Ñ-Ð´Ðµ-ÐÐ°Ñ,Roquetas de Mar", :latitude => "36.76419", :longitude => "-2.61475").save
City.new(:country_id => "68", :name => "Ronda", :aliases => "Ronda,Ð Ð¾Ð½Ð´Ð°,Ronda", :latitude => "36.74231", :longitude => "-5.16709").save
City.new(:country_id => "68", :name => "Rojales", :aliases => "Rojales,Rojals,Rojales", :latitude => "38.08799", :longitude => "-0.72544").save
City.new(:country_id => "68", :name => "Rincon de la Victoria", :aliases => "Rinkon-de-la-Viktorija,Ð Ð¸Ð½ÐºÐ¾Ð½-Ð´Ðµ-Ð»Ð°-ÐÐ¸ÐºÑÐ¾ÑÐ¸Ñ,RincÃ³n de la Victoria", :latitude => "36.71715", :longitude => "-4.27583").save
City.new(:country_id => "68", :name => "Ribarroja", :aliases => ",Ribarroja", :latitude => "39.55", :longitude => "-0.56667").save
City.new(:country_id => "68", :name => "Requena", :aliases => "Requena,Requena", :latitude => "39.48834", :longitude => "-1.10044").save
City.new(:country_id => "68", :name => "Realejo Alto", :aliases => "Realejo Alto,Realejo Alto", :latitude => "28.36667", :longitude => "-16.56667").save
City.new(:country_id => "68", :name => "Pucol", :aliases => "Pucol,Puzol,PuÃ§ol,PuÃ§ol", :latitude => "39.61667", :longitude => "-0.3").save
City.new(:country_id => "68", :name => "Puerto Real", :aliases => "Puehrto-Real',Puerto Real,ÐÑÑÑÑÐ¾-Ð ÐµÐ°Ð»Ñ,Puerto Real", :latitude => "36.52819", :longitude => "-6.19011").save
City.new(:country_id => "68", :name => "Puertollano", :aliases => "Puehrtol'jano,Puertollano,ÐÑÑÑÑÐ¾Ð»ÑÑÐ½Ð¾,Puertollano", :latitude => "38.68712", :longitude => "-4.10734").save
City.new(:country_id => "68", :name => "Puerto del Rosario", :aliases => "Puehrto-del'-Rosario,Puerto Cabras,Puerto Rosario,Puerto de Cabras,Puerto del Rosario,ÐÑÑÑÑÐ¾-Ð´ÐµÐ»Ñ-Ð Ð¾ÑÐ°ÑÐ¸Ð¾,Puerto del Rosario", :latitude => "28.5", :longitude => "-13.86667").save
City.new(:country_id => "68", :name => "Puerto de la Cruz", :aliases => "Puerto de la Cruz,Puerto de la Cruz", :latitude => "28.41397", :longitude => "-16.54867").save
City.new(:country_id => "68", :name => "Puente-Genil", :aliases => ",Puente-Genil", :latitude => "37.38333", :longitude => "-4.78333").save
City.new(:country_id => "68", :name => "La Pobla de Vallbona", :aliases => "La Pobla de Vallbona,Puebla de Vallbona,La Pobla de Vallbona", :latitude => "39.6", :longitude => "-0.55").save
City.new(:country_id => "68", :name => "Priego de Cordoba", :aliases => "Priego,Priego de CÃ³rdoba", :latitude => "37.43807", :longitude => "-4.19523").save
City.new(:country_id => "68", :name => "Pozoblanco", :aliases => "Pozoblanco,Pozoblanco", :latitude => "38.36667", :longitude => "-4.85").save
City.new(:country_id => "68", :name => "Pollenca", :aliases => "Pollenca,Pollensa,PollenÃ§a,PollenÃ§a", :latitude => "39.87678", :longitude => "3.01626").save
City.new(:country_id => "68", :name => "Pilar de la Horadada", :aliases => "El Pilar de Horadada,Pilar de la Horadada,Pilar de la Horadada", :latitude => "37.86591", :longitude => "-0.79256").save
City.new(:country_id => "68", :name => "Picassent", :aliases => "Picasent,Picassent,Picassent", :latitude => "39.36667", :longitude => "-0.45").save
City.new(:country_id => "68", :name => "Paterna", :aliases => "Paterna,ÐÐ°ÑÐµÑÐ½Ð°,Paterna", :latitude => "39.5", :longitude => "-0.43333").save
City.new(:country_id => "68", :name => "Palma", :aliases => "Ciutat de Mallorca,Madina Mayurqa,Pal'ma-de-Majorka,Palma,Palma de Maiorca,Palma de Majorque,Palma de Malhorca,Palma de MalhÃ²rca,Palma de Mallorca,Palma di Majorca,balma dy maywrka,pa er ma,palmademayoleuka,plmh dh mywrqh,ÐÐ°Ð»ÑÐ¼Ð°-Ð´Ðµ-ÐÐ°Ð¹Ð¾ÑÐºÐ°,×¤××× ×× ××××¨×§×,Ø¨Ø§ÙÙØ§ Ø¯Ù ÙØ§ÙÙØ±ÙØ§,ãã«ãã»ãã»ããªã§ã«ã«,å¸ç¾é¦¬,íë§ë°ë§ìë¥´ì¹´,Palma", :latitude => "39.56939", :longitude => "2.65024").save
City.new(:country_id => "68", :name => "Palma del Rio", :aliases => "Pal'ma-del'-Rio,Palma del Rio,Palma del RÃ­o,ÐÐ°Ð»ÑÐ¼Ð°-Ð´ÐµÐ»Ñ-Ð Ð¸Ð¾,Palma del RÃ­o", :latitude => "37.7", :longitude => "-5.28333").save
City.new(:country_id => "68", :name => "Pajara", :aliases => "Pajara,PÃ¡jara,PÃ¡jara", :latitude => "28.35039", :longitude => "-14.1076").save
City.new(:country_id => "68", :name => "Paiporta", :aliases => "Paiporta,Pajporta,ÐÐ°Ð¹Ð¿Ð¾ÑÑÐ°,Paiporta", :latitude => "39.43333", :longitude => "-0.41667").save
City.new(:country_id => "68", :name => "Osuna", :aliases => "Osuna,Osuna", :latitude => "37.23333", :longitude => "-5.11667").save
City.new(:country_id => "68", :name => "Orihuela", :aliases => "Aurariola,Orihuela,Oriola,Oriuehla,ÐÑÐ¸ÑÑÐ»Ð°,Orihuela", :latitude => "38.08333", :longitude => "-0.95").save
City.new(:country_id => "68", :name => "Ontinyent", :aliases => "Onten'ente,Onteniente,Ontinyent,ÐÐ½ÑÐµÐ½ÑÐµÐ½ÑÐµ,Ontinyent", :latitude => "38.81667", :longitude => "-0.61667").save
City.new(:country_id => "68", :name => "Onda", :aliases => "Onda,ÐÐ½Ð´Ð°,Onda", :latitude => "39.96667", :longitude => "-0.25").save
City.new(:country_id => "68", :name => "Oliva", :aliases => "Oliva,ÐÐ»Ð¸Ð²Ð°,Oliva", :latitude => "38.91667", :longitude => "-0.11667").save
City.new(:country_id => "68", :name => "Novelda", :aliases => "Novel'da,Novelda,ÐÐ¾Ð²ÐµÐ»ÑÐ´Ð°,Novelda", :latitude => "38.38333", :longitude => "-0.76667").save
City.new(:country_id => "68", :name => "Nijar", :aliases => "Nikhar,ÐÐ¸ÑÐ°Ñ,NÃ­jar", :latitude => "36.96655", :longitude => "-2.20595").save
City.new(:country_id => "68", :name => "Nerja", :aliases => "Nerja,Nerja", :latitude => "36.75855", :longitude => "-3.88727").save
City.new(:country_id => "68", :name => "Navalmoral de la Mata", :aliases => "Navalmoral,Navalmoral de la Mata,Navalmoral de la Mota,Navalmoral de la Mata", :latitude => "39.9", :longitude => "-5.53333").save
City.new(:country_id => "68", :name => "Murcia", :aliases => "Ciutat de Murcia,Ciutat de MÃºrcia,Murcia,Murcie,Murcio,Murcja,Mursia,Mursija,MÃºrcia,mrsyt,mu er xi ya,murushia,mwrsya,mwrsyh,ÐÑÑÑÐ¸Ñ,×××¨×¡××,ÙØ±Ø³ÙØ©,ÙÙØ±Ø³ÛØ§,ã ã«ã·ã¢,ç©å°è¥¿äº,Murcia", :latitude => "37.98333", :longitude => "-1.11667").save
City.new(:country_id => "68", :name => "Mula", :aliases => "Mula,Mula", :latitude => "38.05", :longitude => "-1.5").save
City.new(:country_id => "68", :name => "Muchamiel", :aliases => "Muchamiel,Mutxamel,Muchamiel", :latitude => "38.4158", :longitude => "-0.44529").save
City.new(:country_id => "68", :name => "Motril", :aliases => "Motril,Motril',ÐÐ¾ÑÑÐ¸Ð»Ñ,Motril", :latitude => "36.75", :longitude => "-3.51667").save
City.new(:country_id => "68", :name => "Moron de la Frontera", :aliases => "Moron,Moron de la Frontera,Moron-de-la-Frontera,MorÃ³n,MorÃ³n de la Frontera,ÐÐ¾ÑÐ¾Ð½-Ð´Ðµ-Ð»Ð°-Ð¤ÑÐ¾Ð½ÑÐµÑÐ°,MorÃ³n de la Frontera", :latitude => "37.13333", :longitude => "-5.45").save
City.new(:country_id => "68", :name => "Montilla", :aliases => "Montil'ja,Montilla,ÐÐ¾Ð½ÑÐ¸Ð»ÑÑ,Montilla", :latitude => "37.58333", :longitude => "-4.63333").save
City.new(:country_id => "68", :name => "Montijo", :aliases => "Montijo,Montijo", :latitude => "38.91667", :longitude => "-6.61667").save
City.new(:country_id => "68", :name => "Moncada", :aliases => "Moncada,Monkada,Montcada,ÐÐ¾Ð½ÐºÐ°Ð´Ð°,Moncada", :latitude => "39.54555", :longitude => "-0.39551").save
City.new(:country_id => "68", :name => "Molina de Segura", :aliases => "Molina,Molina de Segura,Molina-de-Segura,ÐÐ¾Ð»Ð¸Ð½Ð°-Ð´Ðµ-Ð¡ÐµÐ³ÑÑÐ°,Molina de Segura", :latitude => "38.05", :longitude => "-1.2").save
City.new(:country_id => "68", :name => "Moguer", :aliases => "Moguer,Moguer", :latitude => "37.27583", :longitude => "-6.83556").save
City.new(:country_id => "68", :name => "Mogan", :aliases => "Mogan,MogÃ¡n,MogÃ¡n", :latitude => "27.88385", :longitude => "-15.72538").save
City.new(:country_id => "68", :name => "Mislata", :aliases => "Mislata,ÐÐ¸ÑÐ»Ð°ÑÐ°,Mislata", :latitude => "39.47523", :longitude => "-0.41825").save
City.new(:country_id => "68", :name => "Mijas", :aliases => "Mijas,Mikhas,ÐÐ¸ÑÐ°Ñ,Mijas", :latitude => "36.59575", :longitude => "-4.63728").save
City.new(:country_id => "68", :name => "Merida", :aliases => "Emerita Augusta,Merida,Merido,MÃ©rida,merida,mryda,mrydh,ÐÐµÑÐ¸Ð´Ð°,××¨×××,ÙØ±ÛØ¯Ø§,ã¡ãªã,MÃ©rida", :latitude => "38.91667", :longitude => "-6.33333").save
City.new(:country_id => "68", :name => "Melilla", :aliases => "Ciudad Autonoma de Melilla,Ciudad AutÃ³noma de Melilla,Ciudad de Melilla,Korisnik:Slaven Kosanovic/Melila,Lungsod ng Melilla,M'lila,Melil'ja,Melila,Melilla,Melilo,Melilya,Meliya,Millela,Rusaddir,Rusadir,Russadir,me li ya,mei li li ya,melilia,melliya,merirya,mlylyh,mlylyt,mlyyh,ÐÐ¾ÑÐ¸ÑÐ½Ð¸Ðº:Ð¡Ð»Ð°Ð²ÐµÐ½ ÐÐ¾ÑÐ°Ð½Ð¾Ð²Ð¸Ñ/ÐÐµÐ»Ð¸ÑÐ°,ÐÐµÐ»Ð¸Ð»Ð°,ÐÐµÐ»Ð¸Ð»ÑÑ,ÐÐµÐ»Ð¸ÑÐ°,×××××,ÙÙÙÙÙØ©,ÙÙÛÙÛÙ,à¹à¸¡à¸¥à¸µà¸¢à¸²,ááááááá,ã¡ãªãªã£,æ¢å©å©äº,ë©ë¦¬ì¼,Melilla", :latitude => "35.29369", :longitude => "-2.93833").save
City.new(:country_id => "68", :name => "Mazarron", :aliases => "Masarron,Mazarron,MazarrÃ³n,ÐÐ°ÑÐ°ÑÑÐ¾Ð½,MazarrÃ³n", :latitude => "37.5992", :longitude => "-1.31493").save
City.new(:country_id => "68", :name => "Massamagrell", :aliases => "Masamgrell,Massamagrell", :latitude => "39.56667", :longitude => "-0.33333").save
City.new(:country_id => "68", :name => "Martos", :aliases => "Martos,ÐÐ°ÑÑÐ¾Ñ,Martos", :latitude => "37.71667", :longitude => "-3.96667").save
City.new(:country_id => "68", :name => "Marratxi", :aliases => "Marrachi,Marratxi,MarratxÃ­,ÐÐ°ÑÑÐ°ÑÐ¸,MarratxÃ­", :latitude => "39.64208", :longitude => "2.75388").save
City.new(:country_id => "68", :name => "Marchena", :aliases => "Marchena,Marchena", :latitude => "37.33333", :longitude => "-5.4").save
City.new(:country_id => "68", :name => "Marbella", :aliases => "Marbel'ja,Marbela,Marbella,marbya,marbyla,ÐÐ°ÑÐ±ÐµÐ»ÑÑ,ÐÐ°ÑÐ±ÐµÑÐ°,ÙØ§Ø±Ø¨ÙØ§,ÙØ§Ø±Ø¨ÙÙØ§,Marbella", :latitude => "36.51543", :longitude => "-4.88583").save
City.new(:country_id => "68", :name => "Maracena", :aliases => ",Maracena", :latitude => "37.20764", :longitude => "-3.63493").save
City.new(:country_id => "68", :name => "Manzanares", :aliases => "Manzanares,Manzanarre,Manzanares", :latitude => "39", :longitude => "-3.36667").save
City.new(:country_id => "68", :name => "Manises", :aliases => "Manises,ÐÐ°Ð½Ð¸ÑÐµÑ,Manises", :latitude => "39.49139", :longitude => "-0.46349").save
City.new(:country_id => "68", :name => "Manacor", :aliases => "Manacor,Manakor,ÐÐ°Ð½Ð°ÐºÐ¾Ñ,Manacor", :latitude => "39.56964", :longitude => "3.20955").save
City.new(:country_id => "68", :name => "Malaga", :aliases => "Malaca,Malaga,Malago,MÃ laga,MÃ¡laga,ma la jia,malaga,malaka,malqt,maraga,mlqt,ÐÐ°Ð»Ð°Ð³Ð°,×××××,×××××,ÙØ§ÙØ§Ú¯Ø§,ÙØ§ÙÙØ©,ÙÙÙØ©,à¸¡à¸²à¸¥à¸²à¸à¸²,ãã©ã¬,é©¬æå ,MÃ¡laga", :latitude => "36.72016", :longitude => "-4.42034").save
City.new(:country_id => "68", :name => "Mairena del Aljarafe", :aliases => "Aljarafe,Mairena del Aljarafe,Mairena del Aljarafe", :latitude => "37.33333", :longitude => "-6.06667").save
City.new(:country_id => "68", :name => "Mairena del Alcor", :aliases => "Mairano del Alcor,Mairena del Alcor,Maireno del Alcor,Mairena del Alcor", :latitude => "37.36667", :longitude => "-5.75").save
City.new(:country_id => "68", :name => "Mao", :aliases => "Mahon,MahÃ³n,Mao,MaÃ³,ÐÐ°Ð¾,MaÃ³", :latitude => "39.88853", :longitude => "4.26583").save
City.new(:country_id => "68", :name => "Lucena", :aliases => ",Lucena", :latitude => "37.40881", :longitude => "-4.48522").save
City.new(:country_id => "68", :name => "Los Palacios y Villafranca", :aliases => "Los Palacios y Villafranca,Villafranca Los Palacios,Los Palacios y Villafranca", :latitude => "37.16056", :longitude => "-5.92361").save
City.new(:country_id => "68", :name => "Los Llanos de Aridane", :aliases => "Los Llanos,Los Llanos de Aridane,Los Llanos de Aridane", :latitude => "28.65", :longitude => "-17.9").save
City.new(:country_id => "68", :name => "Los Barrios", :aliases => "Barrios,Los Barrios", :latitude => "36.18482", :longitude => "-5.49213").save
City.new(:country_id => "68", :name => "Los Alcazares", :aliases => "Alcazares,AlcÃ¡zares,Los AlcÃ¡zares", :latitude => "37.74425", :longitude => "-0.85041").save
City.new(:country_id => "68", :name => "Lorca", :aliases => "Llorca,Lorca,Lorka,Lorko,lwrqh,ÐÐ¾ÑÐºÐ°,×××¨×§×,Lorca", :latitude => "37.66667", :longitude => "-1.7").save
City.new(:country_id => "68", :name => "Lora del Rio", :aliases => ",Lora del RÃ­o", :latitude => "37.65", :longitude => "-5.53333").save
City.new(:country_id => "68", :name => "Loja", :aliases => "Lokha,ÐÐ¾ÑÐ°,Loja", :latitude => "37.16887", :longitude => "-4.15129").save
City.new(:country_id => "68", :name => "Llucmajor", :aliases => "Llucmajor,Llucmajor", :latitude => "39.49093", :longitude => "2.89108").save
City.new(:country_id => "68", :name => "Lliria", :aliases => "Liria,Lliria,LlÃ­ria,LlÃ­ria", :latitude => "39.63333", :longitude => "-0.6").save
City.new(:country_id => "68", :name => "Linares", :aliases => "Linares,ÐÐ¸Ð½Ð°ÑÐµÑ,Linares", :latitude => "38.08333", :longitude => "-3.63333").save
City.new(:country_id => "68", :name => "Lepe", :aliases => "Lepe,ÐÐµÐ¿Ðµ,Lepe", :latitude => "37.25", :longitude => "-7.2").save
City.new(:country_id => "68", :name => "Lebrija", :aliases => "Lebrija,Lebrikha,ÐÐµÐ±ÑÐ¸ÑÐ°,Lebrija", :latitude => "36.91667", :longitude => "-6.06667").save
City.new(:country_id => "68", :name => "La Union", :aliases => "La Union,La UniÃ³n,Unio,La UniÃ³n", :latitude => "37.61667", :longitude => "-0.86667").save
City.new(:country_id => "68", :name => "Las Torres de Cotillas", :aliases => "La Torres de Cotillas,Las Torres de Cotillas,Las Torres de Cotillas", :latitude => "38.02822", :longitude => "-1.24188").save
City.new(:country_id => "68", :name => "Las Palmas de Gran Canaria", :aliases => "Kanaria Handiko Las Palmas,Las Palmas,Las Palmas de G.C.,Las Palmas de Gran Canaria,Las Palmas de Gran Kanaria,Las-Pal'mas-de-Gran-Kanarija,Laspalmasa,Les Palmes de Gran Canaria,Les Palmes de Gran CanÃ ria,Palmas,Palmas de Gran Canaria,la si pa er ma si,ÐÐ°Ñ ÐÐ°Ð»Ð¼Ð°Ñ Ð´Ðµ ÐÑÐ°Ð½ ÐÐ°Ð½Ð°ÑÐ¸Ð°,ÐÐ°Ñ-ÐÐ°Ð»ÑÐ¼Ð°Ñ-Ð´Ðµ-ÐÑÐ°Ð½-ÐÐ°Ð½Ð°ÑÐ¸Ñ,ã©ã¹ã»ãã«ãã¹ã»ãã»ã°ã©ã³ã»ã«ããªã¢,ææ¯å¸å°é©¬æ¯,Las Palmas de Gran Canaria", :latitude => "28.1", :longitude => "-15.41667").save
City.new(:country_id => "68", :name => "La Solana", :aliases => "La Solana,La Solana", :latitude => "38.93333", :longitude => "-3.23333").save
City.new(:country_id => "68", :name => "Las Cabezas de San Juan", :aliases => "Las Cabezas San Juan,Las Cabezas de San Juan,Las Cabezas de San Juan", :latitude => "36.98333", :longitude => "-5.93333").save
City.new(:country_id => "68", :name => "La Roda", :aliases => "La Roda,La Roda", :latitude => "39.21667", :longitude => "-2.15").save
City.new(:country_id => "68", :name => "La Rinconada", :aliases => "La Rinconada,La-Rinkonada,ÐÐ°-Ð Ð¸Ð½ÐºÐ¾Ð½Ð°Ð´Ð°,La Rinconada", :latitude => "37.48333", :longitude => "-5.96667").save
City.new(:country_id => "68", :name => "La Orotava", :aliases => "La Orotava,Orotava,Villa Orotava,Villa de la Orotava,La Orotava", :latitude => "28.39076", :longitude => "-16.52309").save
City.new(:country_id => "68", :name => "La Oliva", :aliases => "La Oliva,Oliva,La Oliva", :latitude => "28.61052", :longitude => "-13.92912").save
City.new(:country_id => "68", :name => "la Nucia", :aliases => "La-Nusia,la Nucia,ÐÐ°-ÐÑÑÐ¸Ð°,la Nucia", :latitude => "38.61372", :longitude => "-0.1269").save
City.new(:country_id => "68", :name => "La Linea de la Concepcion", :aliases => "La Linea,La Linea de la Concepcion,La LÃ­nea,La LÃ­nea de la ConcepciÃ³n,La-Linea-de-la-Konseps'on,ÐÐ°-ÐÐ¸Ð½ÐµÐ°-Ð´Ðµ-Ð»Ð°-ÐÐ¾Ð½ÑÐµÐ¿ÑÑÐ¾Ð½,La LÃ­nea de la ConcepciÃ³n", :latitude => "36.16809", :longitude => "-5.34777").save
City.new(:country_id => "68", :name => "L'Eliana", :aliases => "L'Eliana,La Eliana,L'Eliana", :latitude => "39.56667", :longitude => "-0.53333").save
City.new(:country_id => "68", :name => "La Carolina", :aliases => "La Carolina,La Carolina", :latitude => "38.25", :longitude => "-3.61667").save
City.new(:country_id => "68", :name => "Jumilla", :aliases => "Jumella,Jumilla,Khumil'e,Ð¥ÑÐ¼Ð¸Ð»ÑÐµ,Jumilla", :latitude => "38.48333", :longitude => "-1.28333").save
City.new(:country_id => "68", :name => "Jerez de la Frontera", :aliases => "Herezo,Jarez de la Frontera,Jerez,Jerez de la Frontera,Xeres,XÃ©rÃ¨s,hrs dh lh prwntrh,shrysh,Ä¤erezo,××¨×¡ ×× ×× ×¤×¨×× ××¨×,Ø´Ø±ÙØ´,ãã¬ã¹ã»ãã»ã©ã»ãã­ã³ãã¼ã©,Jerez de la Frontera", :latitude => "36.68333", :longitude => "-6.13333").save
City.new(:country_id => "68", :name => "Xabia", :aliases => "Javea,JÃ¡vea,Xabia,XÃ bia,XÃ bia", :latitude => "38.78333", :longitude => "0.16667").save
City.new(:country_id => "68", :name => "Xativa", :aliases => "Jativa,JÃ¡tiva,Khativa,Xativa,XÃ tiva,shatbt,Ð¥Ð°ÑÐ¸Ð²Ð°,Ø´Ø§Ø·Ø¨Ø©,XÃ tiva", :latitude => "38.98333", :longitude => "-0.51667").save
City.new(:country_id => "68", :name => "Jaen", :aliases => "Haeno,Jaen,JaÃ©n,Khaehn,Xaen - Jaen,XaÃ©n - JaÃ©n,haen,jyan,Ä¤aeno,Ð¥Ð°ÑÐ½,Ø¬ÙØ§Ù,ãã¨ã³,JaÃ©n", :latitude => "37.76667", :longitude => "-3.78333").save
City.new(:country_id => "68", :name => "Isla Cristina", :aliases => ",Isla Cristina", :latitude => "37.2", :longitude => "-7.31667").save
City.new(:country_id => "68", :name => "Ingenio", :aliases => "Carrizal de Ingenio,Ingenio,Ingenio", :latitude => "27.92086", :longitude => "-15.4406").save
City.new(:country_id => "68", :name => "Inca", :aliases => "Inca,Inka,ÐÐ½ÐºÐ°,Inca", :latitude => "39.7211", :longitude => "2.91093").save
City.new(:country_id => "68", :name => "Icod de los Vinos", :aliases => "Icod,Icod de los Vinos,Icod de los Vinos", :latitude => "28.35", :longitude => "-16.7").save
City.new(:country_id => "68", :name => "Eivissa", :aliases => "Eivissa,Ibica,Ibiza,Ibiza Town,Ibiza-Stadt,Ibiza-stad,Vila d'Eivissa,ÐÐ±Ð¸ÑÐ°,Eivissa", :latitude => "38.90883", :longitude => "1.43296").save
City.new(:country_id => "68", :name => "Ibi", :aliases => "Ibi,ÐÐ±Ð¸,Ibi", :latitude => "38.63333", :longitude => "-0.56667").save
City.new(:country_id => "68", :name => "Huercal-Overa", :aliases => "Huercal Overa,Huercal-Overa,Huescal-Overa,HuÃ©rcal Overa,HuÃ©rcal-Overa,HuÃ©rcal-Overa", :latitude => "37.38333", :longitude => "-1.95").save
City.new(:country_id => "68", :name => "Huelva", :aliases => "Huelva,Onubo,Uehl'va,ueruba,u~eruba,Ð£ÑÐ»ÑÐ²Ð°,ã¦ã§ã«ã,ã¦ã¨ã«ã,Huelva", :latitude => "37.25833", :longitude => "-6.95083").save
City.new(:country_id => "68", :name => "Hellin", :aliases => "Ehl'ine,Hellin,HellÃ­n,Ð­Ð»ÑÐ¸Ð½Ðµ,HellÃ­n", :latitude => "38.51667", :longitude => "-1.68333").save
City.new(:country_id => "68", :name => "Guimar", :aliases => "Guimar,GÃ¼imar,GÃ¼imar", :latitude => "28.3", :longitude => "-16.41667").save
City.new(:country_id => "68", :name => "Guia de Isora", :aliases => "Guia,Guia de Isora,Guia de Izara,GuÃ­a,GuÃ­a de Isora,GuÃ­a de Isora", :latitude => "28.21154", :longitude => "-16.77947").save
City.new(:country_id => "68", :name => "Guardamar del Segura", :aliases => "Guardamar,Guardamar de la Safor,Guardamar de la Segura,Guardamar del Segura,Guardamar del Segura", :latitude => "38.09031", :longitude => "-0.65556").save
City.new(:country_id => "68", :name => "Guadix", :aliases => "Guadix,Gvadiks,Quadix,ÐÐ²Ð°Ð´Ð¸ÐºÑ,Guadix", :latitude => "37.3", :longitude => "-3.13333").save
City.new(:country_id => "68", :name => "Granadilla de Abona", :aliases => "Granadilla,Granadilla de Abona,Granadilla de Abona", :latitude => "28.11667", :longitude => "-16.58333").save
City.new(:country_id => "68", :name => "Granada", :aliases => "Granada,Granada - Grenada,Granado,Granata,Grenada,Grenade,Grenado,Grenayd,ge la na da,ge lin na da,geulenada,ghrnatt,granada,grndh,guranada,gurenada,jrynada,pra thes kerne da,ÎÏÎµÎ½Î¬Î´Î±,ÐÑÐ°Ð½Ð°Ð´Ð°,ÐÑÐµÐ½Ð°Ð´Ð°,××¨× ××,Ø¬Ø±ÙÙØ§Ø¯Ø§,ØºØ±ÙØ§Ø·Ø©,Ú«Ø±ÛÙØ§Ø¯Ø§,Ú¯Ø±Ø§ÙØ§Ø¯Ø§,Ú¯Ø±ÛÙØ§Ø¯Ø§,à¸à¸£à¸°à¹à¸à¸¨à¹à¸à¸£à¹à¸à¸à¸²,ã°ã©ãã,ã°ã¬ãã,æ ¼æçº³è¾¾,æ ¼æçº³è¾¾,ê·¸ë ëë¤,Granada", :latitude => "37.18817", :longitude => "-3.60667").save
City.new(:country_id => "68", :name => "Gandia", :aliases => "Gandia,Gandie,Gandija,GandÃ­a,ÐÐ°Ð½Ð´Ð¸Ñ,Gandia", :latitude => "38.96667", :longitude => "-0.18333").save
City.new(:country_id => "68", :name => "Galdar", :aliases => "Gal'dar,Galdar,GÃ¡ldar,ÐÐ°Ð»ÑÐ´Ð°Ñ,GÃ¡ldar", :latitude => "28.14701", :longitude => "-15.6502").save
City.new(:country_id => "68", :name => "Fuengirola", :aliases => "Fuengirola,Fuengirola", :latitude => "36.53998", :longitude => "-4.62473").save
City.new(:country_id => "68", :name => "Felanitx", :aliases => "Felanitx,Felanitx", :latitude => "39.4696", :longitude => "3.14831").save
City.new(:country_id => "68", :name => "Estepona", :aliases => "Estepona,ÐÑÑÐµÐ¿Ð¾Ð½Ð°,Estepona", :latitude => "36.42764", :longitude => "-5.14589").save
City.new(:country_id => "68", :name => "El Viso del Alcor", :aliases => "El Viso del Alcor,Viso del Alcor,El Viso del Alcor", :latitude => "37.38333", :longitude => "-5.71667").save
City.new(:country_id => "68", :name => "El Puerto de Santa Maria", :aliases => "Ehl'-Puehrto-de-Santa-Marija,El Puerto,El Puerto de Santa Maria,El Puerto de Santa MarÃ­a,Pto. de Sta. Maria,Pto. de Sta. MarÃ­a,Puerto,Puerto de Santa Maria,Puerto de Santa MarÃ­a,Ð­Ð»Ñ-ÐÑÑÑÑÐ¾-Ð´Ðµ-Ð¡Ð°Ð½ÑÐ°-ÐÐ°ÑÐ¸Ñ,El Puerto de Santa MarÃ­a", :latitude => "36.59389", :longitude => "-6.23298").save
City.new(:country_id => "68", :name => "El Ejido", :aliases => "Barriada El Ejido,Ehl'-Ehkhido,Ejido,El Ejido,Ð­Ð»Ñ-Ð­ÑÐ¸Ð´Ð¾,El Ejido", :latitude => "36.77629", :longitude => "-2.81456").save
City.new(:country_id => "68", :name => "Elda", :aliases => "Ehl'da,Elda,Ð­Ð»ÑÐ´Ð°,Elda", :latitude => "38.48333", :longitude => "-0.78333").save
City.new(:country_id => "68", :name => "Elx", :aliases => "Ehl'ch,Elch,Elche,Elig,Elx,Elx / Elche,Illice,ai er qie,altshh,eruche,ÐÐ»Ñ,Ð­Ð»ÑÑ,×××¦'×,Ø¥ÙØªØ´Ù,ã¨ã«ãã§,åç¾å,Elx", :latitude => "38.26218", :longitude => "-0.70107").save
City.new(:country_id => "68", :name => "El Arahal", :aliases => "Arahal,El Arahal,El Arahal", :latitude => "37.26667", :longitude => "-5.55").save
City.new(:country_id => "68", :name => "Ecija", :aliases => "Ecija,Ehsikha,Ãcija,Ð­ÑÐ¸ÑÐ°,Ãcija", :latitude => "37.53333", :longitude => "-5.08333").save
City.new(:country_id => "68", :name => "Dos Hermanas", :aliases => "Dos Ermanas,Dos Hermanas,ÐÐ¾Ñ ÐÑÐ¼Ð°Ð½Ð°Ñ,Dos Hermanas", :latitude => "37.28444", :longitude => "-5.92417").save
City.new(:country_id => "68", :name => "Don Benito", :aliases => "Don Benito,Don-Benito,ÐÐ¾Ð½-ÐÐµÐ½Ð¸ÑÐ¾,Don Benito", :latitude => "38.95", :longitude => "-5.86667").save
City.new(:country_id => "68", :name => "Denia", :aliases => "Denia,Denija,DÃ©nia,ÐÐµÐ½Ð¸Ñ,Denia", :latitude => "38.84078", :longitude => "0.10574").save
City.new(:country_id => "68", :name => "Daimiel", :aliases => "Daimiel,Daimiel", :latitude => "39.06667", :longitude => "-3.61667").save
City.new(:country_id => "68", :name => "Cullera", :aliases => "Cullera,Kul'era,ÐÑÐ»ÑÐµÑÐ°,Cullera", :latitude => "39.16667", :longitude => "-0.25").save
City.new(:country_id => "68", :name => "Quart de Poblet", :aliases => "Cuart de Poblet,Kuart-de-Poblet,Quart de Poblet,ÐÑÐ°ÑÑ-Ð´Ðµ-ÐÐ¾Ð±Ð»ÐµÑ,Quart de Poblet", :latitude => "39.48139", :longitude => "-0.43937").save
City.new(:country_id => "68", :name => "Crevillente", :aliases => "Crevillent,Crevillente,Krevil'ente,ÐÑÐµÐ²Ð¸Ð»ÑÐµÐ½ÑÐµ,Crevillente", :latitude => "38.25", :longitude => "-0.8").save
City.new(:country_id => "68", :name => "Coria del Rio", :aliases => "Coria del Rio,Coria del RÃ­o,Koria-del'-Rio,ÐÐ¾ÑÐ¸Ð°-Ð´ÐµÐ»Ñ-Ð Ð¸Ð¾,ã³ãªã¢ã»ãã«ã»ãªãª,Coria del RÃ­o", :latitude => "37.28556", :longitude => "-6.05167").save
City.new(:country_id => "68", :name => "Cordoba", :aliases => "Cardoue,Cordoba,Cordoue,Cordova,Corduba,CÃ²rdova,CÃ³rdoba,Kordava,Kordoba,Kordova,Kordovo,Kordowa,korudoba,kwrdwba,kxr do ba,qrtbh,qrtbt,qwrdwbh,ÐÐ¾ÑÐ´Ð°Ð²Ð°,ÐÐ¾ÑÐ´Ð¾Ð±Ð°,ÐÐ¾ÑÐ´Ð¾Ð²Ð°,×§××¨××××,ÙØ±Ø·Ø¨Ø©,ÙØ±Ø·Ø¨Ù,ÙØ±Ø·Ø¨Û,Ú©ÙØ±Ø¯ÙØ¨Ø§,à¸à¸­à¸£à¹à¹à¸à¸à¸²,ã³ã«ãã,CÃ³rdoba", :latitude => "37.88333", :longitude => "-4.76667").save
City.new(:country_id => "68", :name => "Conil de la Frontera", :aliases => "Conil,Conil de la Frontera,Conil de la Frontera", :latitude => "36.27639", :longitude => "-6.0875").save
City.new(:country_id => "68", :name => "Coin", :aliases => ",CoÃ­n", :latitude => "36.65947", :longitude => "-4.75639").save
City.new(:country_id => "68", :name => "Ciudad Real", :aliases => "Ciudad Real,S'judad-Real',Villa-Real,lei a er cheng,Ð¡ÑÑÐ´Ð°Ð´-Ð ÐµÐ°Ð»Ñ,ã·ã¦ãã¼ã»ã¬ã¢ã«,é·é¿ç¾å,Ciudad Real", :latitude => "38.98333", :longitude => "-3.93333").save
City.new(:country_id => "68", :name => "Cieza", :aliases => "Cieza,S'esa,Ð¡ÑÐµÑÐ°,Cieza", :latitude => "38.23333", :longitude => "-1.41667").save
City.new(:country_id => "68", :name => "Xirivella", :aliases => "Chirivel'ja,Ð§Ð¸ÑÐ¸Ð²ÐµÐ»ÑÑ,Xirivella", :latitude => "39.46588", :longitude => "-0.42589").save
City.new(:country_id => "68", :name => "Chipiona", :aliases => "Chipiana,Chipiona,Chipiona", :latitude => "36.73333", :longitude => "-6.43333").save
City.new(:country_id => "68", :name => "Chiclana de la Frontera", :aliases => "Chiclana,Chiclana de la Frontera,Chiklana-de-la-Frontera,Ð§Ð¸ÐºÐ»Ð°Ð½Ð°-Ð´Ðµ-Ð»Ð°-Ð¤ÑÐ¾Ð½ÑÐµÑÐ°,Chiclana de la Frontera", :latitude => "36.41915", :longitude => "-6.14941").save
City.new(:country_id => "68", :name => "Cehegin", :aliases => "Cehegin,CehegÃ­n,CehegÃ­n", :latitude => "38.09242", :longitude => "-1.7985").save
City.new(:country_id => "68", :name => "Catarroja", :aliases => "Catarroja,Katarrokh,ÐÐ°ÑÐ°ÑÑÐ¾Ñ,Catarroja", :latitude => "39.4", :longitude => "-0.4").save
City.new(:country_id => "68", :name => "Castilleja de la Cuesta", :aliases => "Castilleja,Castilleja de la Cuesta,Castilleja de la Cuesta", :latitude => "37.38333", :longitude => "-6.05").save
City.new(:country_id => "68", :name => "Castello de la Plana", :aliases => "Castello,Castello de la Plana,Castellon,Castellon de la Plana,CastellÃ³,CastellÃ³ de la Plana,CastellÃ³n,CastellÃ³n de la Plana,Kastel'on-de-la-Plana,Kastelon de la Plana,ka si te li weng-de la pu la na,ÐÐ°ÑÑÐµÐ»ÑÐ¾Ð½-Ð´Ðµ-Ð»Ð°-ÐÐ»Ð°Ð½Ð°,ÐÐ°ÑÑÐµÑÐ¾Ð½ Ð´Ðµ Ð»Ð° ÐÐ»Ð°Ð½Ð°,×§××¡××××,ã«ã¹ããªã§ã³ã»ãã»ã©ã»ãã©ã,å¡æ¯ç¹å©ç¿-å¾·ææ®æç´,CastellÃ³ de la Plana", :latitude => "39.98333", :longitude => "-0.03333").save
City.new(:country_id => "68", :name => "Cartaya", :aliases => "Cartaya,Cartaya", :latitude => "37.28333", :longitude => "-7.15").save
City.new(:country_id => "68", :name => "Cartama", :aliases => ",CÃ¡rtama", :latitude => "36.71068", :longitude => "-4.63297").save
City.new(:country_id => "68", :name => "Cartagena", :aliases => "Cartagena,Carthagene,Carthago Nova,CarthagÃ¨ne,Kartagena,Kartakhena,karutahena,qrthnh,ÐÐ°ÑÑÐ°Ð³ÐµÐ½Ð°,ÐÐ°ÑÑÐ°ÑÐµÐ½Ð°,×§×¨××× ×,ã«ã«ã¿ãã,Cartagena", :latitude => "37.6", :longitude => "-0.98333").save
City.new(:country_id => "68", :name => "Carmona", :aliases => "Carmona,Karmona,ÐÐ°ÑÐ¼Ð¾Ð½Ð°,Carmona", :latitude => "37.46667", :longitude => "-5.63333").save
City.new(:country_id => "68", :name => "Carlet", :aliases => "Carlet,Carlet", :latitude => "39.23333", :longitude => "-0.51667").save
City.new(:country_id => "68", :name => "Carcaixent", :aliases => "Carcagente,Carcaixen,Carcaixent,CarcaixÃ©n,Karkakhente,ÐÐ°ÑÐºÐ°ÑÐµÐ½ÑÐµ,Carcaixent", :latitude => "39.13333", :longitude => "-0.45").save
City.new(:country_id => "68", :name => "Caravaca", :aliases => ",Caravaca", :latitude => "38.1", :longitude => "-1.85").save
City.new(:country_id => "68", :name => "Candelaria", :aliases => "Cancelaria,Candelaria,Kandelarii,ÐÐ°Ð½Ð´ÐµÐ»Ð°ÑÐ¸Ð¸,Candelaria", :latitude => "28.35", :longitude => "-16.36667").save
City.new(:country_id => "68", :name => "Campo de Criptana", :aliases => ",Campo de Criptana", :latitude => "39.40463", :longitude => "-3.12492").save
City.new(:country_id => "68", :name => "el Campello", :aliases => "Campello,El Campello,el Campello", :latitude => "38.42885", :longitude => "-0.39774").save
City.new(:country_id => "68", :name => "Camas", :aliases => "Camas,Kamas,ÐÐ°Ð¼Ð°Ñ,Camas", :latitude => "37.4", :longitude => "-6.03333").save
City.new(:country_id => "68", :name => "Calvia", :aliases => "Calvia,CalviÃ ,CalviÃ ", :latitude => "39.5657", :longitude => "2.50621").save
City.new(:country_id => "68", :name => "Calp", :aliases => "Calp,Calpe,Calp", :latitude => "38.6447", :longitude => "0.0445").save
City.new(:country_id => "68", :name => "Callosa de Segura", :aliases => "Callosa de Segura,Callosa de Segura", :latitude => "38.12497", :longitude => "-0.87822").save
City.new(:country_id => "68", :name => "Cadiz", :aliases => "Cadice,Cadis,Cadix,Cadiz,Cai,CÃ dice,CÃ¡dice,CÃ¡dis,CÃ¡diz,Gadeira,Gades,Gadir,GaÃ°es,Iungadir,Kadis,Kadisas,Kadiz,Kadizo,Kadyks,Kantith,La tacita de plata,jia de si,kadi s,kadiseu,kadisu,kads,kadydh,kadys,qads,qdys,ÎÎ¬Î½ÏÎ¹Î¸,ÐÐ°Ð´Ð¸Ð·,ÐÐ°Ð´Ð¸Ñ,ÐÐ°Ð´ÑÑ,×§×××¡,ÙØ§Ø¯Ø³,ÙØ§Ø¯ÙØ°,Ú©Ø§Ø¯Ø³,Ú©Ø§Ø¯ÛØ³,à¸à¸²à¸à¸´à¸,ááááá¡á,á«á²á,ã«ãã£ã¹,å çæ¯,ì¹´ëì¤,Cadiz", :latitude => "36.53361", :longitude => "-6.29944").save
City.new(:country_id => "68", :name => "Caceres", :aliases => "Caceres,CÃ ceres,CÃ¡ceres,Kaseres,Norba Caesarina,kaseresu,qsrs,ÐÐ°ÑÐµÑÐµÑ,×§×¡×¨×¡,ã«ã»ã¬ã¹,CÃ¡ceres", :latitude => "39.47649", :longitude => "-6.37224").save
City.new(:country_id => "68", :name => "Cabra", :aliases => "Cabra,Kabra,ÐÐ°Ð±ÑÐ°,Cabra", :latitude => "37.46667", :longitude => "-4.45").save
City.new(:country_id => "68", :name => "Burriana", :aliases => "Borriana,Burriana,Burriana", :latitude => "39.9", :longitude => "-0.06667").save
City.new(:country_id => "68", :name => "Burjassot", :aliases => "Bujursot,Burkhasot,ÐÑÑÑÐ°ÑÐ¾Ñ,Burjassot", :latitude => "39.51667", :longitude => "-0.41667").save
City.new(:country_id => "68", :name => "Bormujos", :aliases => "Bormujos,Bormujos", :latitude => "37.36667", :longitude => "-6.06667").save
City.new(:country_id => "68", :name => "Betera", :aliases => "Betera,BÃ©tera,BÃ©tera", :latitude => "39.58333", :longitude => "-0.45").save
City.new(:country_id => "68", :name => "Berja", :aliases => ",Berja", :latitude => "36.84693", :longitude => "-2.94966").save
City.new(:country_id => "68", :name => "Benidorm", :aliases => "Benidorm,ÐÐµÐ½Ð¸Ð´Ð¾ÑÐ¼,Benidorm", :latitude => "38.53816", :longitude => "-0.13098").save
City.new(:country_id => "68", :name => "Benetusser", :aliases => ",BenetÃºsser", :latitude => "39.41667", :longitude => "-0.4").save
City.new(:country_id => "68", :name => "Benalmadena", :aliases => "Benal'madena,Benalmadena,BenalmÃ¡dena,ÐÐµÐ½Ð°Ð»ÑÐ¼Ð°Ð´ÐµÐ½Ð°,BenalmÃ¡dena", :latitude => "36.59548", :longitude => "-4.56937").save
City.new(:country_id => "68", :name => "Baza", :aliases => "Baza,ÐÐ°Ð·Ð°,Baza", :latitude => "37.49073", :longitude => "-2.77259").save
City.new(:country_id => "68", :name => "Barbate de Franco", :aliases => "Barbate,Barbate de Franco,Barbate de Franco", :latitude => "36.18972", :longitude => "-5.92167").save
City.new(:country_id => "68", :name => "Bailen", :aliases => "Bailen,BailÃ©n,BailÃ©n", :latitude => "38.1", :longitude => "-3.76667").save
City.new(:country_id => "68", :name => "Baeza", :aliases => "Baeza,Baeza", :latitude => "37.98333", :longitude => "-3.46667").save
City.new(:country_id => "68", :name => "Baena", :aliases => "Baehna,Baena,ÐÐ°ÑÐ½Ð°,Baena", :latitude => "37.61667", :longitude => "-4.31667").save
City.new(:country_id => "68", :name => "Badajoz", :aliases => "Ara Pacis Augustalis,Badahozo,Badajoz,Badakhos,BadaÄ¥ozo,badahosu,badakhwz,ÐÐ°Ð´Ð°ÑÐ¾Ñ,Ø¨Ø§Ø¯Ø§Ø®ÙØ²,ãããã¹,Badajoz", :latitude => "38.88333", :longitude => "-6.96667").save
City.new(:country_id => "68", :name => "Ayamonte", :aliases => "Ayamonte,Ayamonte", :latitude => "37.21667", :longitude => "-7.4").save
City.new(:country_id => "68", :name => "Atarfe", :aliases => ",Atarfe", :latitude => "37.22479", :longitude => "-3.68686").save
City.new(:country_id => "68", :name => "Aspe", :aliases => "Asp,Aspe,Aspe", :latitude => "38.35", :longitude => "-0.76667").save
City.new(:country_id => "68", :name => "Arucas", :aliases => "Arucas,Arukas,ÐÑÑÐºÐ°Ñ,Arucas", :latitude => "28.11983", :longitude => "-15.52325").save
City.new(:country_id => "68", :name => "Arrecife", :aliases => "Aresife,Arrecife,ÐÑÐµÑÐ¸ÑÐµ,Arrecife", :latitude => "28.96302", :longitude => "-13.54769").save
City.new(:country_id => "68", :name => "Arona", :aliases => "Aron,Arona,ÐÑÐ¾Ð½,Arona", :latitude => "28.09962", :longitude => "-16.68102").save
City.new(:country_id => "68", :name => "Armilla", :aliases => ",Armilla", :latitude => "37.14102", :longitude => "-3.61854").save
City.new(:country_id => "68", :name => "Arcos de la Frontera", :aliases => "Arcos,Arcos de la Frontera,Arkos-de-la-Frontera,ÐÑÐºÐ¾Ñ-Ð´Ðµ-Ð»Ð°-Ð¤ÑÐ¾Ð½ÑÐµÑÐ°,Arcos de la Frontera", :latitude => "36.75", :longitude => "-5.8").save
City.new(:country_id => "68", :name => "Archena", :aliases => "Archena,Archena", :latitude => "38.11667", :longitude => "-1.3").save
City.new(:country_id => "68", :name => "Antequera", :aliases => "Anteguera,Antekera,Antequera,ÐÐ½ÑÐµÐºÐµÑÐ°,Antequera", :latitude => "37.01667", :longitude => "-4.55").save
City.new(:country_id => "68", :name => "Andujar", :aliases => "Andujar,AndÃºjar,AndÃºjar", :latitude => "38.05", :longitude => "-4.06667").save
City.new(:country_id => "68", :name => "Altea", :aliases => "Altea,Altea", :latitude => "38.59885", :longitude => "-0.05139").save
City.new(:country_id => "68", :name => "Almunecar", :aliases => "Almunecar,AlmuÃ±Ã©car,AlmuÃ±Ã©car", :latitude => "36.73393", :longitude => "-3.69072").save
City.new(:country_id => "68", :name => "Almoradi", :aliases => "Almoradi,AlmoradÃ­,Almordi,AlmoradÃ­", :latitude => "38.11667", :longitude => "-0.76667").save
City.new(:country_id => "68", :name => "Almonte", :aliases => "Almonte,Almonte", :latitude => "37.2647", :longitude => "-6.51667").save
City.new(:country_id => "68", :name => "Almeria", :aliases => "Al'meri,Al'merija,Almeria,Almerija,Almerio,AlmerÃ­a,Unci,a er mei li ya,almelia,almeriya,almrya,almryt,arumeria,ÎÎ»Î¼ÎµÏÎ¯Î±,ÐÐ»Ð¼ÐµÑÐ¸Ñ,ÐÐ»Ð¼ÐµÑÐ¸ÑÐ°,ÐÐ»ÑÐ¼ÐµÑÐ¸,ÐÐ»ÑÐ¼ÐµÑÐ¸Ñ,ÐÐ»ÑÐ¼ÐµÑÑÑ,Ø¢ÙÙØ±ÛØ§,Ø§ÙÙØ±ÙØ©,à®à®²à¯à®®à¯à®°à¯à®¯à®¾,ã¢ã«ã¡ãªã¢,é¿å°æ¢éäº,ìë©ë¦¬ì,AlmerÃ­a", :latitude => "36.83814", :longitude => "-2.45974").save
City.new(:country_id => "68", :name => "Almendralejo", :aliases => "Al'mendralekho,Almendralejo,ÐÐ»ÑÐ¼ÐµÐ½Ð´ÑÐ°Ð»ÐµÑÐ¾,Almendralejo", :latitude => "38.68333", :longitude => "-6.4").save
City.new(:country_id => "68", :name => "Almassora", :aliases => "Almassora,Almazora,Almassora", :latitude => "39.95", :longitude => "-0.05").save
City.new(:country_id => "68", :name => "Almansa", :aliases => "Al'mansa,Almansa,ÐÐ»ÑÐ¼Ð°Ð½ÑÐ°,Almansa", :latitude => "38.86667", :longitude => "-1.08333").save
City.new(:country_id => "68", :name => "Aljaraque", :aliases => "Aljaraque,Aljaraque", :latitude => "37.26667", :longitude => "-7.01667").save
City.new(:country_id => "68", :name => "Alicante", :aliases => "Akra Leuke,Alacant,Alakanto,Alicante,Alikante,AlÃ­kante,Lucentum,a li kan te,alykanth,arikante,ÐÐ»Ð¸ÐºÐ°Ð½ÑÐµ,Ø£ÙÙÙØ§ÙØªÙ,ã¢ãªã«ã³ã,é¿å©åç¹,Alicante", :latitude => "38.34517", :longitude => "-0.48149").save
City.new(:country_id => "68", :name => "Alhaurin el Grande", :aliases => "Alhaurin el Grande,AlhaurÃ­n el Grande,AlhaurÃ­n el Grande", :latitude => "36.63333", :longitude => "-4.68333").save
City.new(:country_id => "68", :name => "Alhaurin de la Torre", :aliases => ",AlhaurÃ­n de la Torre", :latitude => "36.66401", :longitude => "-4.56139").save
City.new(:country_id => "68", :name => "Alhama de Murcia", :aliases => "Alhama,Alhama de Murcia,Alhama de Murcia", :latitude => "37.85", :longitude => "-1.41667").save
City.new(:country_id => "68", :name => "Algemesi", :aliases => "Algemesi,AlgemesÃ­,AlgemesÃ­", :latitude => "39.18333", :longitude => "-0.43333").save
City.new(:country_id => "68", :name => "Algeciras", :aliases => "Al Jezita,Al'khesiras,Alchesirasas,Alchezira,Algeciras,Algecires,Algesiras,Algesires,Algethiras,AlgÃ©siras,Alkhesiras,Alxeciras,a er he xi la si,alhesilaseu,aruheshirasu,ÎÎ»Î³ÎµÎ¸Î¯ÏÎ±Ï,ÐÐ»ÑÐµÑÐ¸ÑÐ°Ñ,ÐÐ»ÑÑÐµÑÐ¸ÑÐ°Ñ,ÐÐ»ÑÑÐµÑÑÑÐ°Ñ,Ø§ÙØ¬Ø²ÙØ±Ø© Ø§ÙØ®Ø¶Ø±Ø§Ø¡,ã¢ã«ãã·ã©ã¹,é¿å°èµ«è¥¿ææ¯,ìí¤ìë¼ì¤,Algeciras", :latitude => "36.1275", :longitude => "-5.45389").save
City.new(:country_id => "68", :name => "Alfafar", :aliases => "Alfafar,Alfafar", :latitude => "39.41667", :longitude => "-0.38333").save
City.new(:country_id => "68", :name => "Aldaia", :aliases => "Al'dajja,Aldaia,Aldaya,ÐÐ»ÑÐ´Ð°Ð¹Ñ,Aldaia", :latitude => "39.46569", :longitude => "-0.46005").save
City.new(:country_id => "68", :name => "Alcudia", :aliases => "Alcudia,AlcÃºdia,AlcÃºdia", :latitude => "39.85316", :longitude => "3.12138").save
City.new(:country_id => "68", :name => "Alcoi", :aliases => "Al'ka,Alcoi,Alcoi/Alcoy,Alcoy,AlcÃ²i,ÐÐ»ÑÐºÐ°,Alcoi", :latitude => "38.7", :longitude => "-0.46667").save
City.new(:country_id => "68", :name => "Alzira", :aliases => "Al'sira,Alcira,Alzira,ÐÐ»ÑÑÐ¸ÑÐ°,Alzira", :latitude => "39.15", :longitude => "-0.43333").save
City.new(:country_id => "68", :name => "Alcazar de San Juan", :aliases => "Al'kasar-de-San-Khuan,Alcaraz de San Juan,Alcazar,AlcÃ¡zar,ÐÐ»ÑÐºÐ°ÑÐ°Ñ-Ð´Ðµ-Ð¡Ð°Ð½-Ð¥ÑÐ°Ð½,AlcÃ¡zar de San Juan", :latitude => "39.39011", :longitude => "-3.20827").save
City.new(:country_id => "68", :name => "Alcantarilla", :aliases => "Al'kantaril'ja,Alcantarilla,ÐÐ»ÑÐºÐ°Ð½ÑÐ°ÑÐ¸Ð»ÑÑ,Alcantarilla", :latitude => "37.96667", :longitude => "-1.21667").save
City.new(:country_id => "68", :name => "Alcala la Real", :aliases => "Al'kala-la-Real',Alcala la Real,AlcalÃ¡ la Real,ÐÐ»ÑÐºÐ°Ð»Ð°-Ð»Ð°-Ð ÐµÐ°Ð»Ñ,AlcalÃ¡ la Real", :latitude => "37.46667", :longitude => "-3.93333").save
City.new(:country_id => "68", :name => "Alcala de Guadaira", :aliases => "Al'kala-de-Gvadaira,Alcala de Guadaira,AlcalÃ¡ de Guadaira,AlcalÃ¡ de GuadaÃ­ra,ÐÐ»ÑÐºÐ°Ð»Ð°-Ð´Ðµ-ÐÐ²Ð°Ð´Ð°Ð¸ÑÐ°,AlcalÃ¡ de Guadaira", :latitude => "37.33333", :longitude => "-5.83333").save
City.new(:country_id => "68", :name => "Alboraya", :aliases => "Al'borajja,Alboraia,Alboraya,ÐÐ»ÑÐ±Ð¾ÑÐ°Ð¹Ñ,Alboraya", :latitude => "39.5", :longitude => "-0.35").save
City.new(:country_id => "68", :name => "Albolote", :aliases => ",Albolote", :latitude => "37.23088", :longitude => "-3.6551").save
City.new(:country_id => "68", :name => "Albal", :aliases => "Albal,Albal", :latitude => "39.4", :longitude => "-0.41667").save
City.new(:country_id => "68", :name => "Albacete", :aliases => "Al'basete,Albacete,Albasete,albsyt,arubasete,ÐÐ»Ð±Ð°ÑÐµÑÐµ,ÐÐ»ÑÐ±Ð°ÑÐµÑÐµ,××××¡××,Ø§ÙØ¨Ø³ÙØ·,ã¢ã«ãã»ã,Albacete", :latitude => "38.98333", :longitude => "-1.85").save
City.new(:country_id => "68", :name => "Alaquas", :aliases => "Alacuas,AlacuÃ¡s,Alakuas,Alaquas,AlaquÃ s,ÐÐ»Ð°ÐºÑÐ°Ñ,AlaquÃ s", :latitude => "39.45568", :longitude => "-0.461").save
City.new(:country_id => "68", :name => "Aguimes", :aliases => "Agueimes,Aguimes,AgÃ¼imes,ÐÐ³ÑÐ¸Ð¼ÐµÑ,AgÃ¼imes", :latitude => "27.90539", :longitude => "-15.44609").save
City.new(:country_id => "68", :name => "Aguilas", :aliases => "Agilas,Agudas,Aguilas,Ãguilas,ÐÐ³Ð¸Ð»Ð°Ñ,Ãguilas", :latitude => "37.4063", :longitude => "-1.58289").save
City.new(:country_id => "68", :name => "Adra", :aliases => "Abdera,Adra,ÐÐ´ÑÐ°,Adra", :latitude => "36.74961", :longitude => "-3.02055").save
City.new(:country_id => "68", :name => "Adeje", :aliases => "Adeje,Costa Adeje,Adeje", :latitude => "28.12271", :longitude => "-16.726").save
City.new(:country_id => "68", :name => "Groa de Murviedro", :aliases => ",Groa de Murviedro", :latitude => "39.64167", :longitude => "-0.23889").save
City.new(:country_id => "68", :name => "Zarautz", :aliases => "Zarautz,Zarauz,Zarautz", :latitude => "43.28444", :longitude => "-2.16992").save
City.new(:country_id => "68", :name => "Zaragoza", :aliases => "Caesaraugusta,Caesarea Augusta,Salduba,Salduie,Saragoca,Saragosa,Saragossa,Saragosse,Saragozza,SaragoÃ§a,ZGZ,Zaragosa,Zaragoza,Zaragozo,Zargoza,sa la ge sa,saragosa,srgwsh,srqstt,Ð¡Ð°ÑÐ°Ð³Ð¾ÑÐ°,×¡×¨×××¡×,Ø³Ø±ÙØ³Ø·Ø©,ãµã©ã´ãµ,è¨ææè¨,Zaragoza", :latitude => "41.65606", :longitude => "-0.87734").save
City.new(:country_id => "68", :name => "Zamora", :aliases => "Samora,Zamora,Zamoro,samora,thamora,zamwra,Ð¡Ð°Ð¼Ð¾ÑÐ°,Ø²Ø§ÙÙØ±Ø§,à¦¥à¦¾à¦®à§à¦°à¦¾,ãµã¢ã©,Zamora", :latitude => "41.5", :longitude => "-5.75").save
City.new(:country_id => "68", :name => "Viveiro", :aliases => ",Viveiro", :latitude => "43.66228", :longitude => "-7.59344").save
City.new(:country_id => "68", :name => "Vitoria-Gasteiz", :aliases => "Bittorixa,Gasteiz,Victoriacum,Vitoria,Vitoria-Gasteiz,Vitorija,Vitorio,VitÃ²ria,VitÃ³ria,bitoria,wytwryh,ÐÐ¸ÑÐ¾ÑÐ¸Ñ,×××××¨××,ãããªã¢,Vitoria-Gasteiz", :latitude => "42.85", :longitude => "-2.66667").save
City.new(:country_id => "68", :name => "Vinaros", :aliases => "Vinaros,Vinarose,Vinaroz,ÐÐ¸Ð½Ð°ÑÐ¾ÑÐµ,VinarÃ²s", :latitude => "40.47033", :longitude => "0.47559").save
City.new(:country_id => "68", :name => "Villaviciosa de Odon", :aliases => "Vil'javisiosa-de-Odon,Villaviciosa de Odon,Villaviciosa de OdÃ³n,ÐÐ¸Ð»ÑÑÐ²Ð¸ÑÐ¸Ð¾ÑÐ°-Ð´Ðµ-ÐÐ´Ð¾Ð½,Villaviciosa de OdÃ³n", :latitude => "40.36667", :longitude => "-3.9").save
City.new(:country_id => "68", :name => "Villaquilambre", :aliases => "Villaquilambre,Villaquilambre", :latitude => "42.65", :longitude => "-5.55").save
City.new(:country_id => "68", :name => "Vilanova i la Geltru", :aliases => "Vilanova,Vilanova i la Geltru,Vilanova i la GeltrÃº,Vilanova i la GeltrÃº", :latitude => "41.22392", :longitude => "1.72511").save
City.new(:country_id => "68", :name => "Villanueva del Pardillo", :aliases => "Villanueva del Pardillo,Villanueva del Pardillo", :latitude => "40.48333", :longitude => "-3.96667").save
City.new(:country_id => "68", :name => "Villanueva de la Canada", :aliases => "Villanueva de la Canada,Villanueva de la CaÃ±ada,Villanueva de la CaÃ±ada", :latitude => "40.45", :longitude => "-4").save
City.new(:country_id => "68", :name => "Vilalba", :aliases => "Vilalba,Villalba,Vilalba", :latitude => "43.3", :longitude => "-7.68333").save
City.new(:country_id => "68", :name => "Vilagarcia de Arousa", :aliases => "Vil'jagarsia-de-Arosa,Vilagarcia,VilagarcÃ­a,ÐÐ¸Ð»ÑÑÐ³Ð°ÑÑÐ¸Ð°-Ð´Ðµ-ÐÑÐ¾ÑÐ°,VilagarcÃ­a de Arousa", :latitude => "42.59631", :longitude => "-8.76426").save
City.new(:country_id => "68", :name => "Vilafranca del Penedes", :aliases => "Vil'jafranka-del'-Penedes,Vilafranca Penedes,Vilafranca del Penedes,Vilafranca del PenedÃ¨s,Vilafranca do Penedes - Vilafranca del Penedes,Vilafranca do PenedÃ©s - Vilafranca del PenedÃ¨s,Villafranca del Panades,Villafranca del PanadÃ©s,Villafranca del Penedes,Villafranca del PenedÃ©s,ÐÐ¸Ð»ÑÑÑÑÐ°Ð½ÐºÐ°-Ð´ÐµÐ»Ñ-ÐÐµÐ½ÐµÐ´ÐµÑ,Vilafranca del PenedÃ¨s", :latitude => "41.35", :longitude => "1.7").save
City.new(:country_id => "68", :name => "Vila-seca", :aliases => "Vila-seca,Vilaseca,Vilaseca de Solcina,Vila-seca", :latitude => "41.11667", :longitude => "1.15").save
City.new(:country_id => "68", :name => "Vilaseca", :aliases => "Vila-seka,Vilaseca,ÐÐ¸Ð»Ð°-ÑÐµÐºÐ°,Vilaseca", :latitude => "42.06174", :longitude => "2.25528").save
City.new(:country_id => "68", :name => "Viladecans", :aliases => "Viladekans,ÐÐ¸Ð»Ð°Ð´ÐµÐºÐ°Ð½Ñ,Viladecans", :latitude => "41.31405", :longitude => "2.01427").save
City.new(:country_id => "68", :name => "Vigo", :aliases => "Vigo,bigo,fyghw,wygw,ÐÐ¸Ð³Ð¾,××××,ÙÙØºÙ,ÙÛÚ¯Ù,ãã¼ã´,Vigo", :latitude => "42.23333", :longitude => "-8.71667").save
City.new(:country_id => "68", :name => "Vic", :aliases => "Vic,a'usa,à¦à¦à¦¸à¦¾,Vic", :latitude => "41.93012", :longitude => "2.25486").save
City.new(:country_id => "68", :name => "El Vendrell", :aliases => "El Vendrell,Vendrel',Vendrell,el Vendrell,ÐÐµÐ½Ð´ÑÐµÐ»Ñ,El Vendrell", :latitude => "41.21667", :longitude => "1.53333").save
City.new(:country_id => "68", :name => "Valls", :aliases => "Val's,Valls,ÐÐ°Ð»ÑÑ,Valls", :latitude => "41.28612", :longitude => "1.24993").save
City.new(:country_id => "68", :name => "Valladolid", :aliases => "Balladolid,Pincia,Pintia,Pucela,Val'jadolid,Valadolido,Valladolid,Vallis Tolitum,Vayadolid,baryadoriddo,bld alwlyd,ÐÐ°Ð»ÑÐ»ÑÐ´Ð°Ð»ÑÐ´,ÐÐ°Ð»ÑÑÐ´Ð¾Ð»Ð¸Ð´,××××××××,Ø¨ÙØ¯ Ø§ÙÙÙÙØ¯,ããªã£ããªãã,Valladolid", :latitude => "41.65", :longitude => "-4.71667").save
City.new(:country_id => "68", :name => "Valdemoro", :aliases => "Val'demoro,ÐÐ°Ð»ÑÐ´ÐµÐ¼Ð¾ÑÐ¾,Valdemoro", :latitude => "40.19081", :longitude => "-3.67887").save
City.new(:country_id => "68", :name => "Vaciamadrid", :aliases => "Vaciamadrid,Vasiamadrid,ÐÐ°ÑÐ¸Ð°Ð¼Ð°Ð´ÑÐ¸Ð´,Vaciamadrid", :latitude => "40.33333", :longitude => "-3.51667").save
City.new(:country_id => "68", :name => "Utebo", :aliases => "Utebo,Utebo", :latitude => "41.71667", :longitude => "-1").save
City.new(:country_id => "68", :name => "Tui", :aliases => "Tui,Tuy,Tui", :latitude => "42.04713", :longitude => "-8.64435").save
City.new(:country_id => "68", :name => "Tudela", :aliases => "Tudela,Ð¢ÑÐ´ÐµÐ»Ð°,Tudela", :latitude => "42.06166", :longitude => "-1.60452").save
City.new(:country_id => "68", :name => "Tortosa", :aliases => "Tortosa,Tortoza,twrtwsh,×××¨×××¡×,Tortosa", :latitude => "40.8", :longitude => "0.51667").save
City.new(:country_id => "68", :name => "Torrelodones", :aliases => ",Torrelodones", :latitude => "40.57654", :longitude => "-3.92658").save
City.new(:country_id => "68", :name => "Torrelavega", :aliases => "Torrelavega,Ð¢Ð¾ÑÑÐµÐ»Ð°Ð²ÐµÐ³Ð°,Torrelavega", :latitude => "43.34944", :longitude => "-4.04785").save
City.new(:country_id => "68", :name => "Torrejon de Ardoz", :aliases => "Torrejon de Ardos,Torrejon de Ardoz,TorrejÃ³n de Ardoz,Torrekhon-de-Ardos,Ð¢Ð¾ÑÑÐµÑÐ¾Ð½-Ð´Ðµ-ÐÑÐ´Ð¾Ñ,TorrejÃ³n de Ardoz", :latitude => "40.45", :longitude => "-3.48333").save
City.new(:country_id => "68", :name => "Torredembarra", :aliases => "Torredembara,Torredembarra", :latitude => "41.14505", :longitude => "1.39861").save
City.new(:country_id => "68", :name => "Tordera", :aliases => "Tordera,Tordera", :latitude => "41.69914", :longitude => "2.71888").save
City.new(:country_id => "68", :name => "Tolosa", :aliases => "Tolosa,Tolosa", :latitude => "43.13484", :longitude => "-2.07801").save
City.new(:country_id => "68", :name => "Teruel", :aliases => "Provincia Terulium,Tergueel,TergÃ¼el,Terol,Teruehl',Teruel,Teruelo,Terulium,terueru,Ð¢ÐµÑÑÑÐ»Ñ,ãã«ã¨ã«,Teruel", :latitude => "40.3456", :longitude => "-1.10646").save
City.new(:country_id => "68", :name => "Teo", :aliases => "Santa Maria,Santa MarÃ­a,Teo,Teo", :latitude => "42.75", :longitude => "-8.5").save
City.new(:country_id => "68", :name => "Tarrega", :aliases => "Tarrega,TÃ rrega,TÃ rrega", :latitude => "41.64704", :longitude => "1.13957").save
City.new(:country_id => "68", :name => "Terrassa", :aliases => "Terasa,Terrassa,telasa,terrasa,Î¤ÎµÏÎ¬ÏÎ±,Ð¢ÐµÑÑÐ°ÑÑÐ°,ããã©ã¼ãµ,íë¼ì¬,Terrassa", :latitude => "41.56667", :longitude => "2.01667").save
City.new(:country_id => "68", :name => "Tarragona", :aliases => "Taragono,Tarraco,Tarrago,Tarragona,Tarragone,taragona,taragwna,trgwnh,Ð¢Ð°ÑÑÐ°Ð³Ð¾Ð½Ð°,××¨××× ×,ØªØ§Ø±Ø§Ú¯ÙÙØ§,ã¿ã©ã´ã,Tarragona", :latitude => "41.11667", :longitude => "1.25").save
City.new(:country_id => "68", :name => "Tarancon", :aliases => "Tarancon,TarancÃ³n,TarancÃ³n", :latitude => "40.01667", :longitude => "-3").save
City.new(:country_id => "68", :name => "Soria", :aliases => "Sorija,Ð¡Ð¾ÑÐ¸Ñ,Soria", :latitude => "41.76401", :longitude => "-2.46883").save
City.new(:country_id => "68", :name => "Sitges", :aliases => "Sitges,Sitzhes,Ð¡Ð¸ÑÐ¶ÐµÑ,Sitges", :latitude => "41.23506", :longitude => "1.81193").save
City.new(:country_id => "68", :name => "Sestao", :aliases => "Sestao,Sestao", :latitude => "43.30975", :longitude => "-3.00716").save
City.new(:country_id => "68", :name => "Sesena", :aliases => ",SeseÃ±a", :latitude => "40.10473", :longitude => "-3.69793").save
City.new(:country_id => "68", :name => "Segovia", :aliases => "Segovia,Segovie,Segovija,Segovio,Segowia,SegÃ²via,SegÃ³via,SÃ©govie,segobia,Ð¡ÐµÐ³Ð¾Ð²Ð¸Ñ,ã»ã´ãã¢,Segovia", :latitude => "40.95", :longitude => "-4.11667").save
City.new(:country_id => "68", :name => "Cerdanyola del Valles", :aliases => "Cerdanyola,Cerdanyola del Valles,Cerdanyola del VallÃ¨s,Cerdanyola del VallÃ¨s", :latitude => "41.49109", :longitude => "2.14079").save
City.new(:country_id => "68", :name => "Sant Vicenc dels Horts", :aliases => "Sant Vicenc dels Horts,Sant VicenÃ§ dels Horts,Sant VicenÃ§ dels Horts", :latitude => "41.39317", :longitude => "2.00689").save
City.new(:country_id => "68", :name => "Barakaldo", :aliases => "Baracaldo,Barakaldo,Done Bikendi,San Bizente,San Bizenti-Barakaldo,San Vicente de Baracaldo,Sanbi,Barakaldo", :latitude => "43.29564", :longitude => "-2.99729").save
City.new(:country_id => "68", :name => "Santurtzi", :aliases => "Santurce,Santurce-Antiguo,Santurtzi,Santurtzi", :latitude => "43.32842", :longitude => "-3.03248").save
City.new(:country_id => "68", :name => "Sant Just Desvern", :aliases => "Sant Just Desvern,Sant Just Desvern", :latitude => "41.38602", :longitude => "2.07573").save
City.new(:country_id => "68", :name => "Santiago de Compostela", :aliases => "Compostelako Donejakue,Compostella,Lungsod ng Santiago de Compostela,Saint-Jacques-de-Compostelle,Sant'jago-de-Kompostela,Santiago,Santiago de Compostela,Santiago de Compostella,Santiago de CompostelÂ·la,Santiago di Compostela,Santjago de Kompostela,kong bo si te la de sheng de ya ge,santyagw d kampwstla,Ð¡Ð°Ð½ÑÑÑÐ³Ð¾-Ð´Ðµ-ÐÐ¾Ð¼Ð¿Ð¾ÑÑÐµÐ»Ð°,Ð¡Ð°Ð½ÑÑÐ³Ð¾ Ð´Ðµ ÐÐ¾Ð¼Ð¿Ð¾ÑÑÐµÐ»Ð°,×¡× ××××× ×× ×§×××¤××¡×××,Ø³Ø§ÙØªÛØ§Ú¯Ù Ø¯ Ú©Ø§ÙÙ¾ÙØ³ØªÙØ§,ãµã³ãã£ã¢ã´ã»ãã»ã³ã³ãã¹ãã¼ã©,å­æ³¢æ¯ç¹æçèå°çå¥,Santiago de Compostela", :latitude => "42.88052", :longitude => "-8.54569").save
City.new(:country_id => "68", :name => "Santa Perpetua de Mogoda", :aliases => "Santa Perpetua de Mogoda,Santa Perpetua de Moguda,Santa PerpÃ¨tua de Mogoda,Santa PerpÃ¨tua de Mogoda", :latitude => "41.53333", :longitude => "2.18333").save
City.new(:country_id => "68", :name => "Santander", :aliases => "Portus Victoriae Iuliobrigensium,Sanandere,Santandehr,Santander,Santandero,santanderu,sntndr,Ð¡Ð°Ð½ÑÐ°Ð½Ð´ÐµÑ,Ð¡Ð°Ð½ÑÐ°Ð½Ð´ÑÑ,×¡× ×× ××¨,ãµã³ã¿ã³ãã¼ã«,Santander", :latitude => "43.46472", :longitude => "-3.80444").save
City.new(:country_id => "68", :name => "Barbera del Valles", :aliases => "Barbera Del Valles,Santa Maria de Barbera,Santa MarÃ­a de BarberÃ ,BarberÃ  del VallÃ¨s", :latitude => "41.5159", :longitude => "2.12457").save
City.new(:country_id => "68", :name => "Santa Coloma de Gramenet", :aliases => "Santa Coloma de Gramenet,Santa-Koloma-de-Gramanet,Ð¡Ð°Ð½ÑÐ°-ÐÐ¾Ð»Ð¾Ð¼Ð°-Ð´Ðµ-ÐÑÐ°Ð¼Ð°Ð½ÐµÑ,Santa Coloma de Gramenet", :latitude => "41.45152", :longitude => "2.2081").save
City.new(:country_id => "68", :name => "San Sebastian de los Reyes", :aliases => "S.S. de los Reyes,SS de los Reyes,San Sebastian de los Reyes,San SebastiÃ¡n de los Reyes,Sanse,San SebastiÃ¡n de los Reyes", :latitude => "40.54433", :longitude => "-3.61588").save
City.new(:country_id => "68", :name => "San Sebastian", :aliases => "Donosti,Donostia,Donostia-San Sebastian,Donostia-San SebastiÃ¡n,Donostio,La Bella Easo,Saint-Sebastien,Saint-SÃ©bastien,San Sebastian,San SebastiÃ¡n,San-Sebast'jan,Sanse,Sant Sebastia,Sant SebastiÃ ,Sao Sebastiao,SÃ£o SebastiÃ£o,san sbastyan,sheng sai wa si ti an,Ð¡Ð°Ð½-Ð¡ÐµÐ±Ð°ÑÑÑÑÐ½,×¡× ×¡××¡××××,Ø³Ø§Ù Ø³Ø¨Ø§Ø³ØªÙØ§Ù,ãµã³ã»ã»ãã¹ãã£ã¢ã³,å£å¡ç¦æ¯æå®,San SebastiÃ¡n", :latitude => "43.31283", :longitude => "-1.97499").save
City.new(:country_id => "68", :name => "Sant Quirze del Valles", :aliases => "San Quirico de Tarrasa,San QuÃ­rico de Tarrasa,Sant Quirze del Valles,Sant Quirze del VallÃ¨s,Sant Quirze del VallÃ¨s", :latitude => "41.53333", :longitude => "2.08333").save
City.new(:country_id => "68", :name => "Sant Pere de Ribes", :aliases => "San Pedro de Ribas,Sant Pere de Ribes,Sant Pere de Ribes", :latitude => "41.26667", :longitude => "1.76667").save
City.new(:country_id => "68", :name => "San Martin de la Vega", :aliases => "San Martin de la Vega,San MartÃ­n de la Vega,San MartÃ­n de la Vega", :latitude => "40.21667", :longitude => "-3.56667").save
City.new(:country_id => "68", :name => "San Lorenzo de El Escorial", :aliases => "El Escorial,Eskorialo,San Lorenzo,San Lorenzo del Escorial,San Lorenzo de El Escorial", :latitude => "40.59144", :longitude => "-4.14738").save
City.new(:country_id => "68", :name => "Vilassar de Mar", :aliases => "Vilassar de Mar,Vilassar del Mar,Vilassar de Mar", :latitude => "41.50961", :longitude => "2.39365").save
City.new(:country_id => "68", :name => "Sant Joan Despi", :aliases => "Sant Joan Despi,Sant Joan DespÃ­,Sant Joan DespÃ­", :latitude => "41.36667", :longitude => "2.06667").save
City.new(:country_id => "68", :name => "Sanxenxo", :aliases => "Sangenjo,Sanxenxo,Sanxenxo", :latitude => "42.39996", :longitude => "-8.80698").save
City.new(:country_id => "68", :name => "San Fernando de Henares", :aliases => "San Fernando de Henares,San Fernando de Henares", :latitude => "40.43333", :longitude => "-3.53333").save
City.new(:country_id => "68", :name => "Sant Feliu de Llobregat", :aliases => "Feliu-de-L'obregat,San Feliu de Llobregat,San FeliÃº de Llobregat,Sant Feliu,Sant Feliu de Llobregat,Ð¤ÐµÐ»Ð¸Ñ-Ð´Ðµ-ÐÑÐ¾Ð±ÑÐµÐ³Ð°Ñ,Sant Feliu de Llobregat", :latitude => "41.38333", :longitude => "2.05").save
City.new(:country_id => "68", :name => "Sant Feliu de Guixols", :aliases => "Sant Feliu de Guixols,Sant Feliu de GuÃ­xols,Sant Feliu de GuÃ­xols", :latitude => "41.78333", :longitude => "3.03333").save
City.new(:country_id => "68", :name => "Sant Cugat del Valles", :aliases => "Sant Cugat,Sant Cugat del Valles,Sant Cugat del VallÃ¨s,Sant Cugat del VallÃ¨s", :latitude => "41.46667", :longitude => "2.08333").save
City.new(:country_id => "68", :name => "Sant Celoni", :aliases => "San Celoni,Sant Celoni,Sant Celoni", :latitude => "41.68333", :longitude => "2.48333").save
City.new(:country_id => "68", :name => "Sant Carles de la Rapita", :aliases => "San-Karlos-de-la-Rapita,Sant Carles de la Rapita,Sant Carles de la RÃ pita,Ð¡Ð°Ð½-ÐÐ°ÑÐ»Ð¾Ñ-Ð´Ðµ-Ð»Ð°-Ð Ð°Ð¿Ð¸ÑÐ°,Sant Carles de la RÃ pita", :latitude => "40.61667", :longitude => "0.6").save
City.new(:country_id => "68", :name => "Sant Boi de Llobregat", :aliases => "Sant Boi de Llobregat,Sant Boi de Llobregat", :latitude => "41.34357", :longitude => "2.03659").save
City.new(:country_id => "68", :name => "San Andres del Rabanedo", :aliases => "San Andres de Rabanedo,San Andres del Rabanedo,San AndrÃ©s de Rabanedo,San AndrÃ©s del Rabanedo,San AndrÃ©s del Rabanedo", :latitude => "42.61667", :longitude => "-5.6").save
City.new(:country_id => "68", :name => "Sant Andreu de la Barca", :aliases => "San Andres de la Barca,San AndrÃ©s de la Barca,Sant Andreu de la Barca,Sant Andreu de la Barca", :latitude => "41.44659", :longitude => "1.97187").save
City.new(:country_id => "68", :name => "Sant Adria de Besos", :aliases => "Sant Adria,Sant Adria de Besos,Sant AdriÃ ,Sant AdriÃ  de BesÃ²s,Sant AdriÃ  de BesÃ²s", :latitude => "41.43073", :longitude => "2.21855").save
City.new(:country_id => "68", :name => "Sama", :aliases => "Langreo,Llangreu,LlangrÃ©u,Sama de Langreo,Same,Ð¡Ð°Ð¼Ðµ,Sama", :latitude => "43.29568", :longitude => "-5.68416").save
City.new(:country_id => "68", :name => "Salt", :aliases => "Salt,Salt", :latitude => "41.97489", :longitude => "2.79281").save
City.new(:country_id => "68", :name => "Salou", :aliases => "Salou,Ð¡Ð°Ð»Ð¾Ñ,Salou", :latitude => "41.07663", :longitude => "1.14163").save
City.new(:country_id => "68", :name => "Salamanca", :aliases => "Helmantica,Salamanca,Salamanka,Salamanko,Salamanque,Salmantica,saramanka,slmnqt,Ð¡Ð°Ð»Ð°Ð¼Ð°Ð½ÐºÐ°,Ø³ÙÙÙÙØ©,ãµã©ãã³ã«,Salamanca", :latitude => "40.96667", :longitude => "-5.65").save
City.new(:country_id => "68", :name => "Sabadell", :aliases => "Sabadell,Sabadell", :latitude => "41.54329", :longitude => "2.10942").save
City.new(:country_id => "68", :name => "Rubi", :aliases => "Rubi,RubÃ­,Ð ÑÐ±Ð¸,RubÃ­", :latitude => "41.49226", :longitude => "2.03305").save
City.new(:country_id => "68", :name => "Roses", :aliases => "Rhode,Rosas,Roses,Ð Ð¾ÑÐ°Ñ,Roses", :latitude => "42.26199", :longitude => "3.17689").save
City.new(:country_id => "68", :name => "Ripollet", :aliases => "Ripollet,Ripollet", :latitude => "41.49686", :longitude => "2.15739").save
City.new(:country_id => "68", :name => "Ribeira", :aliases => "Ribeira,Ribeira", :latitude => "42.75", :longitude => "-8.43333").save
City.new(:country_id => "68", :name => "Reus", :aliases => "Reus,Ð ÐµÑÑ,Reus", :latitude => "41.15612", :longitude => "1.10687").save
City.new(:country_id => "68", :name => "Errenteria", :aliases => "Errenteria,Orereta,Renteria,RenterÃ­a,Errenteria", :latitude => "43.31195", :longitude => "-1.90234").save
City.new(:country_id => "68", :name => "Redondela", :aliases => "Redondela,Ð ÐµÐ´Ð¾Ð½Ð´ÐµÐ»Ð°,Redondela", :latitude => "42.28333", :longitude => "-8.6").save
City.new(:country_id => "68", :name => "Ponteareas", :aliases => ",Ponteareas", :latitude => "42.18333", :longitude => "-8.5").save
City.new(:country_id => "68", :name => "Premia de Mar", :aliases => "Premia de Mar,Premija-de-Mar,PremiÃ  de Mar,ÐÑÐµÐ¼Ð¸Ñ-Ð´Ðµ-ÐÐ°Ñ,PremiÃ  de Mar", :latitude => "41.49206", :longitude => "2.36524").save
City.new(:country_id => "68", :name => "Pozuelo de Alarcon", :aliases => "Posuehlo-de-Alarkon,Pozuelo,Pozuelo de Alarcon,Pozuelo de AlarcÃ³n,ÐÐ¾ÑÑÑÐ»Ð¾-Ð´Ðµ-ÐÐ»Ð°ÑÐºÐ¾Ð½,Pozuelo de AlarcÃ³n", :latitude => "40.43333", :longitude => "-3.81667").save
City.new(:country_id => "68", :name => "Poio", :aliases => "San Juan,Poio", :latitude => "42.44423", :longitude => "-8.71482").save
City.new(:country_id => "68", :name => "Portugalete", :aliases => "Portu,Portugalete,la villa jarrillera,ÐÐ¾ÑÑÑÐ³Ð°Ð»ÐµÑÐµ,Portugalete", :latitude => "43.32099", :longitude => "-3.02064").save
City.new(:country_id => "68", :name => "Porrino", :aliases => ",PorriÃ±o", :latitude => "42.16156", :longitude => "-8.6198").save
City.new(:country_id => "68", :name => "Pontevedra", :aliases => "Pontevedra,Pontevedro,pontebedora,ÐÐ¾Ð½ÑÐµÐ²ÐµÐ´ÑÐ°,ãã³ãããã©,Pontevedra", :latitude => "42.431", :longitude => "-8.64435").save
City.new(:country_id => "68", :name => "Ponferrada", :aliases => "Pomeriada,Ponferrada,ÐÐ¾Ð½ÑÐµÑÑÐ°Ð´Ð°,Ponferrada", :latitude => "42.55", :longitude => "-6.58333").save
City.new(:country_id => "68", :name => "Pola de Siero", :aliases => "Pola de Siero,Pola-de-S'ero,Siero,ÐÐ¾Ð»Ð°-Ð´Ðµ-Ð¡ÑÐµÑÐ¾,Pola de Siero", :latitude => "43.38333", :longitude => "-5.66667").save
City.new(:country_id => "68", :name => "Plasencia", :aliases => "Plasence,Plasencia,Plasencio,Plasensia,PlasÃ¨ncia,ÐÐ»Ð°ÑÐµÐ½ÑÐ¸Ð°,Plasencia", :latitude => "40.03333", :longitude => "-6.08333").save
City.new(:country_id => "68", :name => "Pinto", :aliases => "Pinto,ÐÐ¸Ð½ÑÐ¾,Pinto", :latitude => "40.24147", :longitude => "-3.69999").save
City.new(:country_id => "68", :name => "Pineda de Mar", :aliases => "Pineda,Pineda de Mar,ÐÐ¸Ð½ÐµÐ´Ð° Ð´Ðµ ÐÐ°Ñ,Pineda de Mar", :latitude => "41.62763", :longitude => "2.6889").save
City.new(:country_id => "68", :name => "Parla", :aliases => "Parla,ÐÐ°ÑÐ»Ð°,Parla", :latitude => "40.23333", :longitude => "-3.76667").save
City.new(:country_id => "68", :name => "Parets del Valles", :aliases => "Parets del Valles,Parets del VallÃ¨s,Sant Esteve de Parets,Parets del VallÃ¨s", :latitude => "41.58333", :longitude => "2.23333").save
City.new(:country_id => "68", :name => "Pamplona", :aliases => "Iruinea,Iruna,Irunea,IruÃ±a,IruÃ±ea,Lungsod ng Irunea,Lungsod ng IruÃ±ea,Pampeluna,Pampelune,Pampljona,Pamplona,Pamplono,Pompaelo,bamblwna,panpurona,ÐÐ°Ð¼Ð¿Ð»Ð¾Ð½Ð°,ÐÐ°Ð¼Ð¿Ð»ÑÐ½Ð°,Ø¨Ø§ÙØ¨ÙÙÙØ§,ãã³ãã­ã¼ã,Pamplona", :latitude => "42.81687", :longitude => "-1.64323").save
City.new(:country_id => "68", :name => "Palencia", :aliases => "Palencia,Palencio,Palensija,Pallantia,PalÃ¨ncia,PalÃªncia,parenshia,ÐÐ°Ð»ÐµÐ½ÑÐ¸Ñ,ãã¬ã³ã·ã¢,Palencia", :latitude => "42.01667", :longitude => "-4.53333").save
City.new(:country_id => "68", :name => "Palamos", :aliases => "Palamos,PalamÃ³s,PalamÃ³s", :latitude => "41.84843", :longitude => "3.12912").save
City.new(:country_id => "68", :name => "Palafrugell", :aliases => "Palafrugell,Palafruzhel',ÐÐ°Ð»Ð°ÑÑÑÐ¶ÐµÐ»Ñ,Palafrugell", :latitude => "41.91738", :longitude => "3.1631").save
City.new(:country_id => "68", :name => "Oviedo", :aliases => "Aueda,Ov'edo,Ovetus,Oviedo,Ovijedo,Uvieu,UviÃ©u,awfyydw,obiedo,ÐÑÐµÐ´Ð°,ÐÐ²Ð¸ÑÐµÐ´Ð¾,ÐÐ²ÑÐµÐ´Ð¾,×××××××,Ø£ÙÙÙÙØ¯Ù,ãªãã¨ã,Oviedo", :latitude => "43.36029", :longitude => "-5.84476").save
City.new(:country_id => "68", :name => "Oria", :aliases => "Oria,Oria", :latitude => "43.25541", :longitude => "-2.01873").save
City.new(:country_id => "68", :name => "Ourense", :aliases => "Orense,Orenso,Ourense,ourense,ÐÑÐµÐ½ÑÐµ,ãªã¦ã¬ã³ã»,Ourense", :latitude => "42.33333", :longitude => "-7.85").save
City.new(:country_id => "68", :name => "Olot", :aliases => "Olot,ÐÐ»Ð¾Ñ,Olot", :latitude => "42.18096", :longitude => "2.49012").save
City.new(:country_id => "68", :name => "Olesa de Montserrat", :aliases => "Olesa,Olesa de Montserrat,Olesa de Montserrat", :latitude => "41.54372", :longitude => "1.89408").save
City.new(:country_id => "68", :name => "Oleiros", :aliases => "Oleiros,Olejros,Santa Maria,Santa MarÃ­a,ÐÐ»ÐµÐ¹ÑÐ¾Ñ,Oleiros", :latitude => "43.33333", :longitude => "-8.31667").save
City.new(:country_id => "68", :name => "Nigran", :aliases => "San Felix,San FÃ©lix,NigrÃ¡n", :latitude => "42.14153", :longitude => "-8.80656").save
City.new(:country_id => "68", :name => "Navalcarnero", :aliases => "Navalcarnero,Navalcarnero", :latitude => "40.3", :longitude => "-4").save
City.new(:country_id => "68", :name => "Naron", :aliases => "Naron,NarÃ³n,San Julian,San Julian de Naron,ÐÐ°ÑÐ¾Ð½,NarÃ³n", :latitude => "43.51667", :longitude => "-8.15278").save
City.new(:country_id => "68", :name => "Mungia", :aliases => "Mungia,Munguia,MunguÃ­a,Mungia", :latitude => "43.35", :longitude => "-2.83333").save
City.new(:country_id => "68", :name => "Mostoles", :aliases => "Mostoles,ÐÐ¾ÑÑÐ¾Ð»ÐµÑ,MÃ³stoles", :latitude => "40.32234", :longitude => "-3.86496").save
City.new(:country_id => "68", :name => "Monzon", :aliases => "Montso,MontsÃ³,Monzon,MonzÃ³n,MonzÃ³n", :latitude => "41.91084", :longitude => "0.19406").save
City.new(:country_id => "68", :name => "Montornes del Valles", :aliases => "Montornes del Valles,MontornÃ¨s del VallÃ¨s,MontornÃ¨s del VallÃ¨s", :latitude => "41.53333", :longitude => "2.26667").save
City.new(:country_id => "68", :name => "Monforte de Lemos", :aliases => "Monforte,Monforte de Lemos,Monforte de Lemos", :latitude => "42.52165", :longitude => "-7.51422").save
City.new(:country_id => "68", :name => "Arrasate-Mondragon", :aliases => "Arrasate,Arrasate edo Mondragon,Arrasate-Mondragon,Arrasate-MondragÃ³n,Arresate,Mondragoe,Mondragon,Mondrague,MondragÃ³n,Montdragon,Arrasate", :latitude => "43.06441", :longitude => "-2.48977").save
City.new(:country_id => "68", :name => "Montcada i Reixac", :aliases => "Moncada i Reixac,Montcada,Montcada i Reixac,Montcada i Reixac", :latitude => "41.48333", :longitude => "2.18333").save
City.new(:country_id => "68", :name => "Mollet del Valles", :aliases => "Mollet del Valles,Mollet del VallÃ¨s,Mollet del VallÃ©s,Mollet del VallÃ¨s", :latitude => "41.54026", :longitude => "2.21306").save
City.new(:country_id => "68", :name => "Molins de Rei", :aliases => "Molins,Molins de Rei,Molins de Rei", :latitude => "41.41667", :longitude => "2.01667").save
City.new(:country_id => "68", :name => "Moana", :aliases => "Moana,MoaÃ±a,San Martin,San MartÃ­n,MoaÃ±a", :latitude => "42.28333", :longitude => "-8.75").save
City.new(:country_id => "68", :name => "Miranda de Ebro", :aliases => "Miranda,Miranda Ebro,Miranda de Ebro,Miranda del Ebro,Miranda-de-Ehbro,ÐÐ¸ÑÐ°Ð½Ð´Ð°-Ð´Ðµ-Ð­Ð±ÑÐ¾,Miranda de Ebro", :latitude => "42.6865", :longitude => "-2.94695").save
City.new(:country_id => "68", :name => "Mieres", :aliases => "M'eres,Mieres,ÐÑÐµÑÐµÑ,Mieres", :latitude => "43.25", :longitude => "-5.76667").save
City.new(:country_id => "68", :name => "Mejorada del Campo", :aliases => "Mejorada del Campo,Mejorada del Campo", :latitude => "40.4", :longitude => "-3.48333").save
City.new(:country_id => "68", :name => "Medina del Campo", :aliases => "Medina del Campo,Medina-del'-Kampo,ÐÐµÐ´Ð¸Ð½Ð°-Ð´ÐµÐ»Ñ-ÐÐ°Ð¼Ð¿Ð¾,Medina del Campo", :latitude => "41.3", :longitude => "-4.91667").save
City.new(:country_id => "68", :name => "Mataro", :aliases => "Iluro,Mataro,MatarÃ³,ÐÐ°ÑÐ°ÑÐ¾,MatarÃ³", :latitude => "41.54211", :longitude => "2.4445").save
City.new(:country_id => "68", :name => "El Masnou", :aliases => "el Masnou,El Masnou", :latitude => "41.47978", :longitude => "2.3188").save
City.new(:country_id => "68", :name => "Martorell", :aliases => "Martorell,Martorelle,ÐÐ°ÑÑÐ¾ÑÐµÐ»Ð»Ðµ,Martorell", :latitude => "41.47402", :longitude => "1.93062").save
City.new(:country_id => "68", :name => "Marin", :aliases => ",MarÃ­n", :latitude => "42.38333", :longitude => "-8.7").save
City.new(:country_id => "68", :name => "Manresa", :aliases => "Manresa,ÐÐ°Ð½ÑÐµÑÐ°,Manresa", :latitude => "41.72498", :longitude => "1.82656").save
City.new(:country_id => "68", :name => "Manlleu", :aliases => "Manlleu,Manlleu", :latitude => "42.00228", :longitude => "2.28476").save
City.new(:country_id => "68", :name => "Malgrat de Mar", :aliases => "Malgrat de Mar,Malgrat de Mar", :latitude => "41.64662", :longitude => "2.74135").save
City.new(:country_id => "68", :name => "Majadahonda", :aliases => "Makhadaonda,ÐÐ°ÑÐ°Ð´Ð°Ð¾Ð½Ð´Ð°,Majadahonda", :latitude => "40.47353", :longitude => "-3.87182").save
City.new(:country_id => "68", :name => "Madrid", :aliases => "La Villa y Corte,Los Madriles,Lungsod ng Madrid,Madrid,Madridas,Madride,Madridi,Madrido,Madril,Madrite,Madryd,Madryt,MadrÃ­d,Magerit,Maidrid,Matritum,Sanchinarro,ma de li,madeulideu,madorido,madorido shi,madrid,madrida,madridi,madryd,mdryd,ÎÎ±Î´ÏÎ¯ÏÎ·,ÐÐ°Ð´ÑÐ¸Ð´,ÐÐ°Ð´ÑÑÐ´,ÕÕ¡Õ¤ÖÕ«Õ¤,×××¨××,ÙØ§Ø¯Ø±ÙØ¯,ÙØ§Ø¯Ø±ÛØ¯,ÙØ¯Ø±ÙØ¯,ÙÛÚØ±Ú,Ü¡ÜÜªÜÜ,à¤®à¤¦à¥à¤°à¥à¤¦,à¤®à¤¾à¤¦à¥à¤°à¤¿à¤¦,à¸¡à¸²à¸à¸£à¸´à¸,áááá ááá,ááµáªáµ,ãããªã¼ã,ãããªã¼ãå¸,é¦¬å¾·é,é©¬å¾·é,ë§ëë¦¬ë,Madrid", :latitude => "40.4165", :longitude => "-3.70256").save
City.new(:country_id => "68", :name => "Lugo", :aliases => "Lugo,lwghw,rugo,ÐÑÐ³Ð¾,ÙÙØºÙ,ã«ã¼ã´,Lugo", :latitude => "43", :longitude => "-7.56667").save
City.new(:country_id => "68", :name => "Logrono", :aliases => "Logron'o,Logronjo,Logrono,Logronyo,LogroÃ±o,lwgrwnyw,roguronyo,ÐÐ¾Ð³ÑÐ¾Ð½ÑÐ¾,××××¨×× ××,ã­ã°ã­ã¼ãã§,LogroÃ±o", :latitude => "42.46667", :longitude => "-2.45").save
City.new(:country_id => "68", :name => "Lloret de Mar", :aliases => "L'oret-de-Mar,Ljoret de Mar,Lloret de Mar,ÐÐ¾ÑÐµÑ Ð´Ðµ ÐÐ°Ñ,ÐÑÐ¾ÑÐµÑ-Ð´Ðµ-ÐÐ°Ñ,Lloret de Mar", :latitude => "41.69993", :longitude => "2.84565").save
City.new(:country_id => "68", :name => "Llodio", :aliases => "Laudio,Laudio-Llodio,Llodio,Plaza,Plaza de Gogenuri,Llodio", :latitude => "43.14322", :longitude => "-2.96204").save
City.new(:country_id => "68", :name => "Lleida", :aliases => "Ilerda,Ilerdo,Lerida,Lheida,LhÃ¨ida,Ljeida,Lleida,LÃ©rida,lyydh,rerida,ryeida,ÐÐµÐ¸Ð´Ð°,ÐÐµÑÐ¸Ð´Ð°,×××××,ãªã§ã¤ã,ã¬ãªã,Lleida", :latitude => "41.61667", :longitude => "0.61667").save
City.new(:country_id => "68", :name => "Leon", :aliases => "Ciuda de Llion,CiudÃ¡ de LliÃ³n,Leon,Leono,LeÃ³n,Lleo,Lleon,LleÃ³,LleÃ³n,lywn,reon,ÐÐµÐ¾Ð½,ÙÙÙÙ,ã¬ãªã³,LeÃ³n", :latitude => "42.6", :longitude => "-5.56667").save
City.new(:country_id => "68", :name => "Leioa", :aliases => "Leioa,Lejona,Leioa", :latitude => "43.33333", :longitude => "-2.98333").save
City.new(:country_id => "68", :name => "Leganes", :aliases => "Leganes,LeganÃ©s,ÐÐµÐ³Ð°Ð½ÐµÑ,LeganÃ©s", :latitude => "40.32718", :longitude => "-3.7635").save
City.new(:country_id => "68", :name => "Las Rozas de Madrid", :aliases => "Las Rozas,Las Rozas de Madrid,Las-Rosas-de-Madrid,Rozas de Madrid,ÐÐ°Ñ-Ð Ð¾ÑÐ°Ñ-Ð´Ðµ-ÐÐ°Ð´ÑÐ¸Ð´,Las Rozas de Madrid", :latitude => "40.49292", :longitude => "-3.87371").save
City.new(:country_id => "68", :name => "Lasarte", :aliases => "Lasarte,Lasarte-Oria,Lasarte", :latitude => "43.26774", :longitude => "-2.02169").save
City.new(:country_id => "68", :name => "La Pineda", :aliases => "La Pineda,ÐÐ° ÐÐ¸Ð½ÐµÐ´Ð°,La Pineda", :latitude => "41.07625", :longitude => "1.18515").save
City.new(:country_id => "68", :name => "Lalin", :aliases => "Lalin,LalÃ­n,ÐÐ°Ð»Ð¸Ð½,LalÃ­n", :latitude => "42.65", :longitude => "-8.11667").save
City.new(:country_id => "68", :name => "Laguna de Duero", :aliases => "Laguna de Duero,Laguna-de-Duehro,ÐÐ°Ð³ÑÐ½Ð°-Ð´Ðµ-ÐÑÑÑÐ¾,Laguna de Duero", :latitude => "41.58333", :longitude => "-4.71667").save
City.new(:country_id => "68", :name => "A Estrada", :aliases => "Ehstrada,La Estrada,Ð­ÑÑÑÐ°Ð´Ð°,A Estrada", :latitude => "42.68333", :longitude => "-8.48333").save
City.new(:country_id => "68", :name => "A Coruna", :aliases => "A Coruna,A CoruÃ±a,A Cruna,A CruÃ±a,Caronium,Coruna,Corunako,Corunha,Corunna,Corunya,CoruÃ±a,CoruÃ±ako,La Corogne,La Coruna,La CoruÃ±a,La-Korun'ja,The Groyne,ÐÐ°-ÐÐ¾ÑÑÐ½ÑÑ,ã©ã»ã³ã«ã¼ãã£ç,A CoruÃ±a", :latitude => "43.37135", :longitude => "-8.396").save
City.new(:country_id => "68", :name => "Irun", :aliases => "Irun,Irun-Uranzu,IrÃºn,IrÃºn-Uranzu,yi lun,ÐÑÑÐ½,ä¼å«,Irun", :latitude => "43.33904", :longitude => "-1.78938").save
City.new(:country_id => "68", :name => "Illescas", :aliases => "Illescas,Illescas", :latitude => "40.11667", :longitude => "-3.83333").save
City.new(:country_id => "68", :name => "Igualada", :aliases => "Igualada,ÐÐ³ÑÐ°Ð»Ð°Ð´Ð°,Igualada", :latitude => "41.58098", :longitude => "1.6172").save
City.new(:country_id => "68", :name => "Humanes de Madrid", :aliases => ",Humanes de Madrid", :latitude => "40.25038", :longitude => "-3.83062").save
City.new(:country_id => "68", :name => "Huesca", :aliases => "Huesca,Osca,Oska,Uehska,Uesca,uesuka,wsqh,Ð£ÑÑÐºÐ°,××¡×§×,ã¦ã¨ã¹ã«,Huesca", :latitude => "42.13615", :longitude => "-0.4087").save
City.new(:country_id => "68", :name => "L'Hospitalet de Llobregat", :aliases => "Hospitalet de Llobregat,Ospitalet-de-L'obregat,l'Hospitalet,l'Hospitalet de Llobregat,ÐÑÐ¿Ð¸ÑÐ°Ð»ÐµÑ-Ð´Ðµ-ÐÑÐ¾Ð±ÑÐµÐ³Ð°Ñ,L'Hospitalet de Llobregat", :latitude => "41.35967", :longitude => "2.10028").save
City.new(:country_id => "68", :name => "Hernani", :aliases => "Hernani,Hernani", :latitude => "43.26615", :longitude => "-1.97615").save
City.new(:country_id => "68", :name => "Gernika-Lumo", :aliases => "Gernika,Gernika-Lumo,Guernica,Guernica y Luno,Gernika-Lumo", :latitude => "43.31667", :longitude => "-2.68333").save
City.new(:country_id => "68", :name => "Getxo", :aliases => "Getxo,Guecho,Getxo", :latitude => "43.35689", :longitude => "-3.01146").save
City.new(:country_id => "68", :name => "Guadalajara", :aliases => "Guadalajara,Gvadalaharo,Gvadalakhara,guadarahara,ÐÐ²Ð°Ð´Ð°Ð»Ð°ÑÐ°ÑÐ°,ã°ã¢ãã©ãã©,Guadalajara", :latitude => "40.63333", :longitude => "-3.16667").save
City.new(:country_id => "68", :name => "Granollers", :aliases => "Granollers,Granollers", :latitude => "41.60797", :longitude => "2.28773").save
City.new(:country_id => "68", :name => "Gijon", :aliases => "Gijon,GijÃ³n,Hihono,Khikhon,Kixoi,Xixon,Xixon - Gijon,XixÃ³n,XixÃ³n - GijÃ³n,hihon,khykhwn,Ä¤iÄ¥ono,Ð¥Ð¸ÑÐ¾Ð½,Ø®ÙØ®ÙÙ,ããã³,GijÃ³n", :latitude => "43.54111", :longitude => "-5.66444").save
City.new(:country_id => "68", :name => "Getafe", :aliases => "Getafe,Khetafe,Ð¥ÐµÑÐ°ÑÐµ,Getafe", :latitude => "40.30571", :longitude => "-3.73295").save
City.new(:country_id => "68", :name => "Girona", :aliases => "Gerona,Gerone,Girona,Girono,GÃ©rone,Kherona,Zherona,jirona,Äirono,ÐÐµÑÐ¾Ð½Ð°,Ð¥ÐµÑÐ¾Ð½Ð°,ã¸ã­ã¼ã,Girona", :latitude => "41.98311", :longitude => "2.82493").save
City.new(:country_id => "68", :name => "Gava", :aliases => "Gava,GavÃ ,ÐÐ°Ð²Ð°,GavÃ ", :latitude => "41.30605", :longitude => "2.00123").save
City.new(:country_id => "68", :name => "Galdakao", :aliases => "Gal'dakano,Galdacan,Galdacano,Galdacon,Galdakao,GaldÃ¡cano,ÐÐ°Ð»ÑÐ´Ð°ÐºÐ°Ð½Ð¾,Galdakao", :latitude => "43.23333", :longitude => "-2.83333").save
City.new(:country_id => "68", :name => "Galapagar", :aliases => "Galapagar,ÐÐ°Ð»Ð°Ð¿Ð°Ð³Ð°Ñ,Galapagar", :latitude => "40.5783", :longitude => "-4.00426").save
City.new(:country_id => "68", :name => "Fuenterrabia", :aliases => "Fontarabie,Fuenterrabia,FuenterrabÃ­a,Hondarribi,Hondarribia,Hondarribia", :latitude => "43.37202", :longitude => "-1.79448").save
City.new(:country_id => "68", :name => "Fuenlabrada", :aliases => "Fuenlabrada,Ð¤ÑÐµÐ½Ð»Ð°Ð±ÑÐ°Ð´Ð°,Fuenlabrada", :latitude => "40.28333", :longitude => "-3.8").save
City.new(:country_id => "68", :name => "Figueras", :aliases => "Figejras,Figueras,Ð¤Ð¸Ð³ÐµÐ¹ÑÐ°Ñ,Figueras", :latitude => "43.53333", :longitude => "-7.01667").save
City.new(:country_id => "68", :name => "Figueres", :aliases => "Figeras,Figeres,Figueres,Ð¤Ð¸Ð³ÐµÑeÑ,Ð¤Ð¸Ð³ÐµÑÐ°Ñ,Figueres", :latitude => "42.26645", :longitude => "2.96163").save
City.new(:country_id => "68", :name => "Esplugues de Llobregat", :aliases => "Esplugues de Llobregat,Esplugues de Llobregat", :latitude => "41.37732", :longitude => "2.08809").save
City.new(:country_id => "68", :name => "Esparreguera", :aliases => "Esparraguera,Esparreguera,Esparreguera", :latitude => "41.53333", :longitude => "1.86667").save
City.new(:country_id => "68", :name => "Ermua", :aliases => ",Ermua", :latitude => "43.18333", :longitude => "-2.5").save
City.new(:country_id => "68", :name => "Erandio", :aliases => "Ehrandio,Ð­ÑÐ°Ð½Ð´Ð¸Ð¾,Erandio", :latitude => "43.30788", :longitude => "-2.94502").save
City.new(:country_id => "68", :name => "el Prat de Llobregat", :aliases => "Ehl' Prat,El Prat de Llobregat,el Prat,el Prat de Llobregat,Ð­Ð»Ñ ÐÑÐ°Ñ,el Prat de Llobregat", :latitude => "41.33333", :longitude => "2.1").save
City.new(:country_id => "68", :name => "Ferrol", :aliases => "El Ferrol,El Ferrol del Caudillo,Fehrol',Ferrol,Ferrol del Caudillo,xian zhi chuang jian xin ye mian,Ð¤ÑÑÐ¾Ð»Ñ,×××¨×××©×× ×××¨× ×××××¨,éå¶åå»ºæ°é¡µé¢,Ferrol", :latitude => "43.48333", :longitude => "-8.23333").save
City.new(:country_id => "68", :name => "El Astillero", :aliases => "Astillero,El Astillero,El Astillero", :latitude => "43.40094", :longitude => "-3.82051").save
City.new(:country_id => "68", :name => "Ejea de los Caballeros", :aliases => "Egea de los Caballeros,Ejea,Ejea de los Caballeros,Exea,Ejea de los Caballeros", :latitude => "42.13333", :longitude => "-1.13333").save
City.new(:country_id => "68", :name => "Eibar", :aliases => "Ehibar,Ehjbar,Eibar,Eybar,Heivar,Heybar,Villanueva de San Andres,Villanueva de San Andres de Heybar,Villanueva de San AndrÃ©s,Villanueva de San AndrÃ©s de Heybar,Ãibar,Ð­Ð¹Ð±Ð°Ñ,Eibar", :latitude => "43.18493", :longitude => "-2.47158").save
City.new(:country_id => "68", :name => "Durango", :aliases => "Durango,Tavira,ÐÑÑÐ°Ð½Ð³Ð¾,Durango", :latitude => "43.17124", :longitude => "-2.6338").save
City.new(:country_id => "68", :name => "Culleredo", :aliases => "Culleredo,Kul'eredo,San Esteban,ÐÑÐ»ÑÐµÑÐµÐ´Ð¾,Culleredo", :latitude => "43.28333", :longitude => "-8.38333").save
City.new(:country_id => "68", :name => "Cuenca", :aliases => "Cuenca,Kuehnka,ÐÑÑÐ½ÐºÐ°,Cuenca", :latitude => "40.06667", :longitude => "-2.13333").save
City.new(:country_id => "68", :name => "Coslada", :aliases => "Coslada,Koslada,ÐÐ¾ÑÐ»Ð°Ð´Ð°,Coslada", :latitude => "40.43333", :longitude => "-3.56667").save
City.new(:country_id => "68", :name => "Corvera", :aliases => ",Corvera", :latitude => "43.26697", :longitude => "-3.9471").save
City.new(:country_id => "68", :name => "Cornella de Llobregat", :aliases => "Cornella de Llobregat,CornellÃ  de Llobregat,CornellÃ  de Llobregat", :latitude => "41.35", :longitude => "2.08333").save
City.new(:country_id => "68", :name => "Colmenar Viejo", :aliases => ",Colmenar Viejo", :latitude => "40.65909", :longitude => "-3.76762").save
City.new(:country_id => "68", :name => "Collado-Villalba", :aliases => "Collado Villalba,Kol'jado-Vil'jal'ba,ÐÐ¾Ð»ÑÑÐ´Ð¾-ÐÐ¸Ð»ÑÑÐ»ÑÐ±Ð°,Collado-Villalba", :latitude => "40.63506", :longitude => "-4.00486").save
City.new(:country_id => "68", :name => "Ciutadella", :aliases => "Ciudadela,Ciutadella,Ciutadella", :latitude => "40.00112", :longitude => "3.84144").save
City.new(:country_id => "68", :name => "Ciempozuelos", :aliases => ",Ciempozuelos", :latitude => "40.15913", :longitude => "-3.62103").save
City.new(:country_id => "68", :name => "Castro-Urdiales", :aliases => "Castro Urdiales,Castro-Urdiales,Urdialaitz,Castro-Urdiales", :latitude => "43.38286", :longitude => "-3.22043").save
City.new(:country_id => "68", :name => "Castrillon", :aliases => ",CastrillÃ³n", :latitude => "43.39788", :longitude => "-6.79217").save
City.new(:country_id => "68", :name => "Castelldefels", :aliases => "Castelldefels,Castelldefels", :latitude => "41.27794", :longitude => "1.97033").save
City.new(:country_id => "68", :name => "Castellar del Valles", :aliases => ",Castellar del VallÃ¨s", :latitude => "41.61667", :longitude => "2.08333").save
City.new(:country_id => "68", :name => "Cardedeu", :aliases => "Cardedeu,Cardedeu", :latitude => "41.63976", :longitude => "2.35739").save
City.new(:country_id => "68", :name => "Carballo", :aliases => "Carballo,Karbal'o,ÐÐ°ÑÐ±Ð°Ð»ÑÐ¾,Carballo", :latitude => "43.213", :longitude => "-8.69104").save
City.new(:country_id => "68", :name => "Canovelles", :aliases => "Canovellas,Canovelles,Canovelles", :latitude => "41.61667", :longitude => "2.28333").save
City.new(:country_id => "68", :name => "Cangas", :aliases => "Cangas,Cangas del Morrazo,Cangas do Morrazo,Kangas,ÐÐ°Ð½Ð³Ð°Ñ,Cangas", :latitude => "42.26667", :longitude => "-8.78333").save
City.new(:country_id => "68", :name => "Cambrils", :aliases => "Cambrils,Cambrils", :latitude => "41.06667", :longitude => "1.05").save
City.new(:country_id => "68", :name => "Cambre", :aliases => ",Cambre", :latitude => "43.28333", :longitude => "-8.33333").save
City.new(:country_id => "68", :name => "Camargo", :aliases => "Camargo,Kamargo,ÐÐ°Ð¼Ð°ÑÐ³Ð¾,Camargo", :latitude => "43.40744", :longitude => "-3.88498").save
City.new(:country_id => "68", :name => "Calella", :aliases => "Calella,Callella,Calella", :latitude => "41.61802", :longitude => "2.66781").save
City.new(:country_id => "68", :name => "Caldes de Montbui", :aliases => "Caldes de Montbui,Caldes de Montbuy,Caldes de Montbui", :latitude => "41.63333", :longitude => "2.16667").save
City.new(:country_id => "68", :name => "Calatayud", :aliases => "Calataiud,Calatayu,Calatayud,CalatayÃº,Calatayud", :latitude => "41.35", :longitude => "-1.63333").save
City.new(:country_id => "68", :name => "Calahorra", :aliases => "Calagorra,Calagurris,Calahorra,Kalagorria,Calahorra", :latitude => "42.3", :longitude => "-1.96667").save
City.new(:country_id => "68", :name => "Calafell", :aliases => "Calafell,Calafell", :latitude => "41.19997", :longitude => "1.5683").save
City.new(:country_id => "68", :name => "Burlata", :aliases => "Burlada,Burlata,Burlata", :latitude => "42.82562", :longitude => "-1.61671").save
City.new(:country_id => "68", :name => "Burgos", :aliases => "Burgos,Burgoso,burugosu,bwrghws,ÐÑÑÐ³Ð¾Ñ,Ø¨ÙØ±ØºÙØ³,ãã«ã´ã¹,Burgos", :latitude => "42.35", :longitude => "-3.7").save
City.new(:country_id => "68", :name => "Boiro", :aliases => "Boiro,Boiro", :latitude => "42.65", :longitude => "-8.9").save
City.new(:country_id => "68", :name => "Boadilla del Monte", :aliases => ",Boadilla del Monte", :latitude => "40.405", :longitude => "-3.87835").save
City.new(:country_id => "68", :name => "Blanes", :aliases => "Blanes,ÐÐ»Ð°Ð½ÐµÑ,Blanes", :latitude => "41.67419", :longitude => "2.79036").save
City.new(:country_id => "68", :name => "Bilbao", :aliases => "Bil'bao,Bilbao,Bilbau,Bilbaum,Bilbaw,Bilbo,Bilbo / Bilbao,Bilmpao,El Bocho,Gorad Bil'baa,bi er ba e,bil ba xo,bilba'o,bilbao,birubao,blbaw,bylbayw,ÎÏÎ¹Î»Î¼ÏÎ¬Î¿,ÐÐ¸Ð»Ð±Ð°Ð¾,ÐÐ¸Ð»ÑÐ±Ð°Ð¾,ÐÑÐ»ÑÐ±Ð°Ð¾,ÐÐ¾ÑÐ°Ð´ ÐÑÐ»ÑÐ±Ð°Ð°,××××××,Ø¨ÙØ¨Ø§Ù,Ø¨ÛÙØ¨Ø§Ø¦Ù,à¤¬à¤¿à¤²à¥à¤¬à¤¾à¤,à¸à¸´à¸¥à¸à¸²à¹à¸­,áááááá,ãã«ããª,æ¯å°å·´é,ë¹ë°ì¤,Bilbao", :latitude => "43.26271", :longitude => "-2.92528").save
City.new(:country_id => "68", :name => "Bermeo", :aliases => "Bermeo,Bermio,Bermeo", :latitude => "43.42088", :longitude => "-2.72152").save
City.new(:country_id => "68", :name => "Berga", :aliases => "Berga,Berga", :latitude => "42.10429", :longitude => "1.84628").save
City.new(:country_id => "68", :name => "Benicassim", :aliases => "Benicasim,Benicassim,BenicÃ ssim,BenicÃ¡sim,bnw qasm,Ø¨ÙÙ ÙØ§Ø³Ù,BenicÃ ssim", :latitude => "40.05", :longitude => "0.06667").save
City.new(:country_id => "68", :name => "Benicarlo", :aliases => "Benicarlo,BenicarlÃ³,Benikarlo,ÐÐµÐ½Ð¸ÐºÐ°ÑÐ»Ð¾,BenicarlÃ³", :latitude => "40.41667", :longitude => "0.43333").save
City.new(:country_id => "68", :name => "Benavente", :aliases => "Benavente,Benavente", :latitude => "42", :longitude => "-5.68333").save
City.new(:country_id => "68", :name => "Bejar", :aliases => "Bejar,BÃ©jar,BÃ©jar", :latitude => "40.38333", :longitude => "-5.76667").save
City.new(:country_id => "68", :name => "Barcelona", :aliases => "Barcellona,Barcellonn-a,Barcelona,Barcelone,Barcelono,Barceluna,BarcelÅ¯na,BarceÅona,Barcillona,Barcino,Barkelone,Barselona,Barselonae,BarselÃ³na,BarsÃ©lona,Bartzelona,Barzelona,BarÃ§ellonn-a,BarÄellona,Gorad Barselona,Lungsod ng Barcelona,ba sai luo na,baleusellona,bar se lon a,barselona,barsilona,barslwn,barslwna,barsylwna,baruserona,brshlwnt,brzlwnh,la Ciudad Condal,parcelona,ÎÎ±ÏÎºÎµÎ»ÏÎ½Î·,ÐÐ°ÑÑÐµÐ»Ð¾Ð½Ã¦,ÐÐ°ÑÑÐµÐ»Ð¾Ð½Ð°,ÐÐ¾ÑÐ°Ð´ ÐÐ°ÑÑÐµÐ»Ð¾Ð½Ð°,Ô²Õ¡ÖÕ½Õ¥Õ¬Õ¸Õ¶Õ¡,×××¨×¦×¢××× ×¢,××¨×¦××× ×,Ø¨Ø§Ø±Ø³ÙÙÙ,Ø¨Ø§Ø±Ø³ÙÙÙØ§,Ø¨Ø§Ø±Ø³ÛÙÙÙØ§,Ø¨Ø§Ø±Ø³ÛÙÛÙØ§,Ø¨Ø±Ø´ÙÙÙØ©,à¤¬à¤¾à¤°à¥à¤¸à¤¿à¤²à¥à¤¨à¤¾,à¦¬à¦¾à¦°à§à¦¸à§à¦²à§à¦¨à¦¾,à®ªà®¾à®°à¯à®à¯à®²à¯à®©à®¾,à´¬à´¾à´°àµâà´¸à´²àµà´£,à¸à¸²à¸£à¹à¹à¸à¹à¸¥à¸à¸²,à½à¾·à½¢à¼à½¦à½ºà¼à½£à½¼à¼à½à½±à¼,ááá á¡ááááá,ãã«ã»ã­ã,å·´å¡ç½é£,ë°ë¥´ìë¡ë,Barcelona", :latitude => "41.38879", :longitude => "2.15899").save
City.new(:country_id => "68", :name => "Barbastro", :aliases => "Balbastro,Barbastre,Barbastro,Barbastro", :latitude => "42.03565", :longitude => "0.12686").save
City.new(:country_id => "68", :name => "Baranain", :aliases => "Baran'jajn,Baranain,BaraÃ±Ã¡in,ÐÐ°ÑÐ°Ð½ÑÑÐ¹Ð½,BaraÃ±Ã¡in", :latitude => "42.8", :longitude => "-1.66667").save
City.new(:country_id => "68", :name => "Banyoles", :aliases => "Banolas,Banyoles,BaÃ±olas,Banyoles", :latitude => "42.11667", :longitude => "2.76667").save
City.new(:country_id => "68", :name => "Balaguer", :aliases => "Balaguer,Balaguer", :latitude => "41.79117", :longitude => "0.81094").save
City.new(:country_id => "68", :name => "Badalona", :aliases => "Badalona,ÐÐ°Ð´Ð°Ð»Ð¾Ð½Ð°,Badalona", :latitude => "41.45004", :longitude => "2.24741").save
City.new(:country_id => "68", :name => "Azuqueca de Henares", :aliases => "Asukeka-de-Ehnares,Azuqueca,Azuqueca de Henares,ÐÑÑÐºÐµÐºÐ°-Ð´Ðµ-Ð­Ð½Ð°ÑÐµÑ,Azuqueca de Henares", :latitude => "40.56667", :longitude => "-3.26667").save
City.new(:country_id => "68", :name => "Aviles", :aliases => "Aviles,AvilÃ©s,ÐÐ²Ð¸Ð»ÐµÑ,AvilÃ©s", :latitude => "43.55694", :longitude => "-5.92472").save
City.new(:country_id => "68", :name => "Avila de los Caballeros", :aliases => "Avila,Avila de los Caballeros,Avila de los Santos,Avilo,abira,Ãvila,Ãvila,Ãvila de los Caballeros,Ãvila de los Santos,ÐÐ²Ð¸Ð»Ð°,ã¢ãã©,Ãvila de los Caballeros", :latitude => "40.65", :longitude => "-4.7").save
City.new(:country_id => "68", :name => "Arteixo", :aliases => "Santiago,Arteixo", :latitude => "43.30482", :longitude => "-8.50749").save
City.new(:country_id => "68", :name => "Arganda", :aliases => "Arganda,ÐÑÐ³Ð°Ð½Ð´Ð°,Arganda", :latitude => "40.3", :longitude => "-3.43333").save
City.new(:country_id => "68", :name => "Aranjuez", :aliases => "Aranjuez,Arankhuehs,ÐÑÐ°Ð½ÑÑÑÑ,××¨× ××××¡,Aranjuez", :latitude => "40.03333", :longitude => "-3.6").save
City.new(:country_id => "68", :name => "Aranda de Duero", :aliases => "Aranda,Aranda de Duero,Aranda-de-Duehro,ÐÑÐ°Ð½Ð´Ð°-Ð´Ðµ-ÐÑÑÑÐ¾,Aranda de Duero", :latitude => "41.67041", :longitude => "-3.6892").save
City.new(:country_id => "68", :name => "Amposta", :aliases => "Amposta,Amposta", :latitude => "40.71308", :longitude => "0.58103").save
City.new(:country_id => "68", :name => "Amorebieta-Etxano", :aliases => "Amorebieta,Amorebieta-Echano,Amorebieta-Etxano,Zornotza,Amorebieta-Etxano", :latitude => "43.21667", :longitude => "-2.73333").save
City.new(:country_id => "68", :name => "Ames", :aliases => "Ehjmsa,Santo Tomas,Santo TomÃ¡s,Ð­Ð¹Ð¼ÑÐ°,AmÃ©s", :latitude => "42.9", :longitude => "-8.63333").save
City.new(:country_id => "68", :name => "Algorta", :aliases => "Algorta,Algorta", :latitude => "43.34927", :longitude => "-3.0094").save
City.new(:country_id => "68", :name => "Algete", :aliases => "Algete,Algete", :latitude => "40.6", :longitude => "-3.5").save
City.new(:country_id => "68", :name => "Alcorcon", :aliases => "Al'korkon,Alcorcon,AlcorcÃ³n,Alkorkono,ÐÐ»ÑÐºÐ¾ÑÐºÐ¾Ð½,AlcorcÃ³n", :latitude => "40.34582", :longitude => "-3.82487").save
City.new(:country_id => "68", :name => "Alcobendas", :aliases => "Alcobendas,Alkobendas,ÐÐ»ÐºÐ¾Ð±ÐµÐ½Ð´Ð°Ñ,Alcobendas", :latitude => "40.54746", :longitude => "-3.64197").save
City.new(:country_id => "68", :name => "Alcaniz", :aliases => "Alcaniz,Alcanyis,AlcanyÃ­s,AlcaÃ±iz,AlcaÃ±iz", :latitude => "41.05", :longitude => "-0.13333").save
City.new(:country_id => "68", :name => "Alcala de Henares", :aliases => "Alcala de Henares,AlcalÃ¡ de Henares,AlcÃ¡la de Henares,Alkala de Enares,Compluto,Complutum,CÃ³mpluto,ÐÐ»ÐºÐ°Ð»Ð° Ð´Ðµ ÐÐ½Ð°ÑÐµÑ,ã¢ã«ã«ã©ã»ãã»ã¨ãã¬ã¹,AlcalÃ¡ de Henares", :latitude => "40.48333", :longitude => "-3.36667").save
City.new(:country_id => "68", :name => "Nou Barris", :aliases => "Distrito Nou Barris,Nou Barris,Nou Barris", :latitude => "41.44163", :longitude => "2.17727").save
City.new(:country_id => "68", :name => "Pinar de Chamartin", :aliases => ",Pinar de ChamartÃ­n", :latitude => "40.47903", :longitude => "-3.66836").save
City.new(:country_id => "68", :name => "Playa del Ingles", :aliases => "Plaja del' Ingles,Playa del Ingles,Playa del InglÃ©s,ÐÐ»Ð°Ñ Ð´ÐµÐ»Ñ ÐÐ½Ð³Ð»ÐµÑ,Playa del Ingles", :latitude => "27.7567", :longitude => "-15.5787").save
City.new(:country_id => "68", :name => "Puerto del Carmen", :aliases => "Puehrto-del'-Karmen,ÐÑÑÑÑÐ¾-Ð´ÐµÐ»Ñ-ÐÐ°ÑÐ¼ÐµÐ½,Puerto del Carmen", :latitude => "28.92313", :longitude => "-13.66579").save
City.new(:country_id => "68", :name => "Ceuta", :aliases => "Seuta,Ð¡ÐµÑÑÐ°,Ceuta", :latitude => "35.88933", :longitude => "-5.31979").save
City.new(:country_id => "68", :name => "Eixample", :aliases => "Distrito Eixample,Eixample,L'Eixample,Eixample", :latitude => "41.38896", :longitude => "2.16179").save
City.new(:country_id => "68", :name => "Sant Marti", :aliases => "Districte de Sant Marti,Districte de Sant MartÃ­,Sant Marti,Sant MartÃ­,Sant MartÃ­", :latitude => "41.41814", :longitude => "2.19933").save
City.new(:country_id => "68", :name => "Ciutat Vella", :aliases => "Ciutat Vella,Distrito Ciutat Vella,Ciutat Vella", :latitude => "41.38022", :longitude => "2.17319").save
City.new(:country_id => "68", :name => "l'Alfas del Pi", :aliases => "Alfas Del Pi,Alfaz del Pi,L'Alfas Del Pi,l'AlfÃ s del Pi", :latitude => "38.58055", :longitude => "-0.10321").save
City.new(:country_id => "68", :name => "Las Gabias", :aliases => ",Las Gabias", :latitude => "37.13296", :longitude => "-3.69765").save
City.new(:country_id => "68", :name => "Delicias", :aliases => ",Delicias", :latitude => "41.64774", :longitude => "-0.91474").save
City.new(:country_id => "68", :name => "Almozara", :aliases => "Al'mozara,La Quimica,La QuÃ­mica,ÐÐ»ÑÐ¼Ð¾Ð·Ð°ÑÐ°,Almozara", :latitude => "41.66124", :longitude => "-0.90169").save
City.new(:country_id => "68", :name => "Montecanal", :aliases => ",Montecanal", :latitude => "41.62965", :longitude => "-0.93873").save
City.new(:country_id => "68", :name => "Oliver-Valdefierro, Oliver, Valdefierro", :aliases => ",Oliver-Valdefierro, Oliver, Valdefierro", :latitude => "41.64495", :longitude => "-0.92659").save
City.new(:country_id => "68", :name => "Santutxu", :aliases => ",Santutxu", :latitude => "43.25347", :longitude => "-2.9161").save
City.new(:country_id => "68", :name => "Los Realejos", :aliases => ",Los Realejos", :latitude => "28.36739", :longitude => "-16.58335").save
City.new(:country_id => "68", :name => "Pasaia", :aliases => ",Pasaia", :latitude => "43.3253", :longitude => "-1.92707").save
City.new(:country_id => "68", :name => "Basauri", :aliases => ",Basauri", :latitude => "43.2397", :longitude => "-2.8858").save
City.new(:country_id => "68", :name => "Llefia", :aliases => ",LlefiÃ ", :latitude => "41.43806", :longitude => "2.2195").save
City.new(:country_id => "68", :name => "Corvera de Asturias", :aliases => ",Corvera de Asturias", :latitude => "43.51062", :longitude => "-5.8691").save
City.new(:country_id => "68", :name => "Alpujarra Granadina", :aliases => "Alpujarra Granadina,Alpujarras,La Alpujarra,Las Alpujarras,Alpujarra Granadina", :latitude => "36.93068", :longitude => "-3.19565").save
