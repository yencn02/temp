City.new(:country_id => "246", :name => "Mamoudzou", :aliases => "Mambutzou,Mamoudzou,Mamoutzou,Mamudzu,Mamutzu,ÐÐ°Ð¼ÑÐ´Ð·Ñ,Mamoudzou", :latitude => "-12.77944", :longitude => "45.22722").save
City.new(:country_id => "246", :name => "Koungou", :aliases => "Kongo,Koungou,Koungou", :latitude => "-12.73361", :longitude => "45.20417").save
