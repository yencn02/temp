City.new(:country_id => "112", :name => "Vittoria", :aliases => "Vittoira,Vittoria,vu~ittoria,ã´ã£ããã¼ãªã¢,Vittoria", :latitude => "36.95374", :longitude => "14.53318").save
City.new(:country_id => "112", :name => "Villabate", :aliases => "Villabate,Villabbati,Villabate", :latitude => "38.07625", :longitude => "13.44485").save
City.new(:country_id => "112", :name => "Vibo Valentia", :aliases => "Monteleone di Calabria,Vibbu Valenzia,Vibo Valentia,Vibo-Valentija,ÐÐ¸Ð±Ð¾-ÐÐ°Ð»ÐµÐ½ÑÐ¸Ñ,ã´ã£ãã»ã´ã¡ã¬ã³ãã£ã¢,Vibo Valentia", :latitude => "38.67428", :longitude => "16.0951").save
City.new(:country_id => "112", :name => "Tricase", :aliases => "Tricase,Tricase", :latitude => "39.93042", :longitude => "18.35533").save
City.new(:country_id => "112", :name => "Trapani", :aliases => "Drepanum,Trapani,Trapena,TrÃ pani,TrÃ pena,TrÃ¡pani,torapani,Ð¢ÑÐ°Ð¿Ð°Ð½Ð¸,××¨×¤×× ×,ãã©ã¼ãã,Trapani", :latitude => "38.01584", :longitude => "12.51077").save
City.new(:country_id => "112", :name => "Termini Imerese", :aliases => "Termini,Termini Imerese,Thermae Himerarae,TÃ¨rmini,Termini Imerese", :latitude => "37.98365", :longitude => "13.69555").save
City.new(:country_id => "112", :name => "Taurianova", :aliases => "Iatrinoli,Taurianova,Taurianova", :latitude => "38.35627", :longitude => "16.0109").save
City.new(:country_id => "112", :name => "Siracusa", :aliases => "Sarausa,Siracusa,Sirakuza,Sirakuze,Syracusae,Syracuse,Syrakus,Syrakusa,Syrakuzy,shirakusa,silakusa,syraqwst,syrqwzh,xi la ku sa,Ð¡Ð¸ÑÐ°ÐºÑÐ·Ð°,×¡××¨×§×××,Ø³ÙØ±Ø§ÙÙØ³Ø©,ã·ã©ã¯ãµ,é¡æåºè¨,ìë¼ì¿ ì¬,Siracusa", :latitude => "37.08515", :longitude => "15.273").save
City.new(:country_id => "112", :name => "Sinnai", :aliases => "Sinnai,Sinnai", :latitude => "39.30222", :longitude => "9.20306").save
City.new(:country_id => "112", :name => "Siderno Superiore", :aliases => ",Siderno Superiore", :latitude => "38.28333", :longitude => "16.26667").save
City.new(:country_id => "112", :name => "Siderno Marina", :aliases => "Siderno,Siderno Marino,shideruno,ã·ãã«ã,Siderno", :latitude => "38.27788", :longitude => "16.302").save
City.new(:country_id => "112", :name => "Sestu", :aliases => "Sestu,Sestu", :latitude => "39.30056", :longitude => "9.09083").save
City.new(:country_id => "112", :name => "Selargius", :aliases => "Selargius,Selargius", :latitude => "39.25667", :longitude => "9.1675").save
City.new(:country_id => "112", :name => "Scordia", :aliases => "Scordia,Scurdia,Scordia", :latitude => "37.29805", :longitude => "14.84078").save
City.new(:country_id => "112", :name => "Scicli", :aliases => "Scicli,Shikli,shikuri,Ð¨Ð¸ÐºÐ»Ð¸,ã·ã¯ãª,Scicli", :latitude => "36.79024", :longitude => "14.70139").save
City.new(:country_id => "112", :name => "Sciacca", :aliases => "Sciacca,Sciacea,Shaka,Xaca,Ð¨Ð°ÐºÐ°,Sciacca", :latitude => "37.50693", :longitude => "13.08399").save
City.new(:country_id => "112", :name => "San Giovanni la Punta", :aliases => "San Giovanni,San Giovanni la Punta,San Giuvanni la Punta,San Giovanni la Punta", :latitude => "37.57605", :longitude => "15.09809").save
City.new(:country_id => "112", :name => "San Giovanni in Fiore", :aliases => "San Giovanni in Fiore,San Giovanni in Fiore", :latitude => "39.2633", :longitude => "16.6996").save
City.new(:country_id => "112", :name => "San Cataldo", :aliases => "San Cataldo,San Cataldu,San Cataldo", :latitude => "37.48412", :longitude => "13.98542").save
City.new(:country_id => "112", :name => "Rossano", :aliases => "Roscianum,Rossano,rossano,Ð Ð¾ÑÑÐ°Ð½Ð¾,ã­ããµã¼ã,Rossano", :latitude => "39.5751", :longitude => "16.6349").save
City.new(:country_id => "112", :name => "Rosolini", :aliases => "Rosolini,Rusalini,Rosolini", :latitude => "36.82424", :longitude => "14.94779").save
City.new(:country_id => "112", :name => "Rosarno", :aliases => "Rosarno,Rosarno", :latitude => "38.48408", :longitude => "15.979").save
City.new(:country_id => "112", :name => "Ribera", :aliases => "Ribera,Ð Ð¸Ð±ÐµÑÐ°,Ribera", :latitude => "37.49844", :longitude => "13.26415").save
City.new(:country_id => "112", :name => "Rende", :aliases => "Rende,Ð ÐµÐ½Ð´Ðµ,Rende", :latitude => "39.33199", :longitude => "16.18439").save
City.new(:country_id => "112", :name => "Reggio di Calabria", :aliases => "Redzho-Kalabrija,Reggio Calabria,Reggio de Calabre,Reggio de Calabria,Reggio de CalÃ bria,Reggio di Calabria,Regio,Rhegium,Riggiu Calabbria,lei jiao ka la bu li ya,rg'w dy qlbryh,rydjw kalabrya,Ð ÐµÐ´Ð¶Ð¾-ÐÐ°Ð»Ð°Ð±ÑÐ¸Ñ,×¨×'× ×× ×§×××¨××,Ø±ÙØ¯Ø¬Ù ÙØ§ÙØ§Ø¨Ø±ÙØ§,ã¬ãã¸ã§ã»ãã£ã»ã«ã©ããªã¢,é·ç¦å¡æå¸éäº,Reggio di Calabria", :latitude => "38.11047", :longitude => "15.66129").save
City.new(:country_id => "112", :name => "Ragusa", :aliases => "Ragusa,Raguse,Raguza,Rausa,raguza,rgwzh,Ð Ð°Ð³ÑÐ·Ð°,×¨××××,ã©ã°ã¼ã¶,Ragusa", :latitude => "36.92824", :longitude => "14.71719").save
City.new(:country_id => "112", :name => "Quartu Sant'Elena", :aliases => "Cuartu Santa Aleni,Cuartu Santa AlÃ¨ni,Quarto Sant'Elena,Quarto SantâElena,Quartu Sant'Elena,Quartu SantâElena,Quartu SantâElena", :latitude => "39.24194", :longitude => "9.18389").save
City.new(:country_id => "112", :name => "Pozzallo", :aliases => "Pozzallo,Puzzaddu,pottsu~arro,ãããã¡ãã­,Pozzallo", :latitude => "36.73054", :longitude => "14.84989").save
City.new(:country_id => "112", :name => "Porto Empedocle", :aliases => "Porto Empedocle,Portu Empedocli,Porto Empedocle", :latitude => "37.29344", :longitude => "13.52636").save
City.new(:country_id => "112", :name => "Piazza Armerina", :aliases => "Ciazza,Cjassa,Piazza Armerina,Piazza Armerina", :latitude => "37.38595", :longitude => "14.36717").save
City.new(:country_id => "112", :name => "Paterno", :aliases => "Paterno,PaternÃ²,Patirno,PatirnÃ²,pateruno,ÐÐ°ÑÐµÑÐ½Ð¾,ããã«ãã¼,PaternÃ²", :latitude => "37.57095", :longitude => "14.90268").save
City.new(:country_id => "112", :name => "Partinico", :aliases => ",Partinico", :latitude => "38.04395", :longitude => "13.12004").save
City.new(:country_id => "112", :name => "Paola", :aliases => "Paola,paora,ããªã©,Paola", :latitude => "39.35989", :longitude => "16.03959").save
City.new(:country_id => "112", :name => "Palmi", :aliases => "Palmi,parumi,ãã«ã,Palmi", :latitude => "38.36527", :longitude => "15.8615").save
City.new(:country_id => "112", :name => "Palma di Montechiaro", :aliases => "Palma di Montechiaro,Parma di Muntichiaru,Palma di Montechiaro", :latitude => "37.19264", :longitude => "13.76496").save
City.new(:country_id => "112", :name => "Palermo", :aliases => "Palerm,Palerma,Palermas,Palerme,Palermo,Palermu,Panormus,PaÅermo,ba lei mo shi,balyrmw,palermo,palrmw,parerumo,plrmw,ÐÐ°Ð»ÐµÑÐ¼Ð°,ÐÐ°Ð»ÐµÑÐ¼Ð¾,×¤××¨××,Ø¨Ø§ÙÙØ±ÙÙ,Ù¾Ø§ÙØ±ÙÙ,à¤ªà¤²à¥à¤°à¥à¤®à¥,ãã¬ã«ã¢,å·´åè«å¸,Palermo", :latitude => "38.11582", :longitude => "13.35976").save
City.new(:country_id => "112", :name => "Palagonia", :aliases => "Palagonia,Palagunia,Palagonia", :latitude => "37.32825", :longitude => "14.74478").save
City.new(:country_id => "112", :name => "Pachino", :aliases => "Pachino,Pachinu,Pakino,ÐÐ°ÐºÐ¸Ð½Ð¾,Pachino", :latitude => "36.71864", :longitude => "15.0907").save
City.new(:country_id => "112", :name => "Oristano", :aliases => "Aristanis,Oristano,Oristanum,Oristany,orisutano,ÐÑÐ¸ÑÑÐ°Ð½Ð¾,ãªãªã¹ã¿ã¼ã,Oristano", :latitude => "39.90306", :longitude => "8.59194").save
City.new(:country_id => "112", :name => "Noto", :aliases => "Netum,Noto,Nuotu,noto,ÐÐ¾ÑÐ¾,ãã¼ã,Noto", :latitude => "36.89014", :longitude => "15.06929").save
City.new(:country_id => "112", :name => "Niscemi", :aliases => "Niscemi,Nishemi,ÐÐ¸ÑÐµÐ¼Ð¸,Niscemi", :latitude => "37.14864", :longitude => "14.39128").save
City.new(:country_id => "112", :name => "Nicastro", :aliases => "Nicastro,Nikastro,ÐÐ¸ÐºÐ°ÑÑÑÐ¾,Nicastro", :latitude => "38.98333", :longitude => "16.31667").save
City.new(:country_id => "112", :name => "Montalto Uffugo", :aliases => "Montalto Uffugo,Montalto Uffugo", :latitude => "39.4048", :longitude => "16.15799").save
City.new(:country_id => "112", :name => "Monserrato", :aliases => "Monserrato,Monserratu,Monserrato", :latitude => "39.25611", :longitude => "9.13972").save
City.new(:country_id => "112", :name => "Monreale", :aliases => "Monreal',Monreale,Murriali,monreare,ÐÐ¾Ð½ÑÐµÐ°Ð»Ñ,ã¢ã³ã¬ã¢ã¼ã¬,Monreale", :latitude => "38.08005", :longitude => "13.28854").save
City.new(:country_id => "112", :name => "Modica", :aliases => "Modica,Modika,Muorica,MuÃ²rica,MÃ³dica,modika,ÐÐ¾Ð´Ð¸ÐºÐ°,ã¢ã¼ãã£ã«,Modica", :latitude => "36.84594", :longitude => "14.77399").save
City.new(:country_id => "112", :name => "Misterbianco", :aliases => "Misterbianco,Mistirjancu,Misterbianco", :latitude => "37.51815", :longitude => "15.03089").save
City.new(:country_id => "112", :name => "Misilmeri", :aliases => "Misilmeri,Misilmeri", :latitude => "38.03385", :longitude => "13.45175").save
City.new(:country_id => "112", :name => "Milazzo", :aliases => "Milacco,Milazzo,Milazzu,Mylae,mirattsu~o,ÐÐ¸Ð»Ð°ÑÑÐ¾,×××××,ãã©ããã©,Milazzo", :latitude => "38.22117", :longitude => "15.23828").save
City.new(:country_id => "112", :name => "Messina", :aliases => "Mesina,Messana,Messina,Messine,Mesyna,Missina,messhina,mo xi na,msynh,mysyna,ÐÐµÑÐ¸Ð½Ð°,ÐÐµÑÑÐ¸Ð½Ð°,××¡×× ×,ÙÙØ³ÙÙØ§,ã¡ãã·ã¼ã,å¢¨è¥¿æ¿,Messina", :latitude => "38.19327", :longitude => "15.54969").save
City.new(:country_id => "112", :name => "Mazara del Vallo", :aliases => "Mazara del Vallo,Mazzara,Mazara del Vallo", :latitude => "37.66414", :longitude => "12.58804").save
City.new(:country_id => "112", :name => "Mascalucia", :aliases => "Mascalucia,Maskalucha,ÐÐ°ÑÐºÐ°Ð»ÑÑÐ°,Mascalucia", :latitude => "37.59215", :longitude => "15.02989").save
City.new(:country_id => "112", :name => "Marsala", :aliases => "Marsala,marusara,ÐÐ°ÑÑÐ°Ð»Ð°,ãã«ãµã¼ã©,Marsala", :latitude => "37.79664", :longitude => "12.43518").save
City.new(:country_id => "112", :name => "Licata", :aliases => "Licata,Licata", :latitude => "37.10714", :longitude => "13.94607").save
City.new(:country_id => "112", :name => "Lentini", :aliases => "Lentini,Leontini,Lintini,lntyny,rentini,ÐÐµÐ½ÑÐ¸Ð½Ð¸,×× ××× ×,ã¬ã³ãã£ã¼ã,Lentini", :latitude => "37.28545", :longitude => "14.99959").save
City.new(:country_id => "112", :name => "Iglesias", :aliases => "Ecclesia,Esglesies,EsglÃ¨sies,EsglÃ©sies,Iglesias,Iglezias,igurejiasu,ÐÐ³Ð»ÐµÐ·Ð¸Ð°Ñ,ã¤ã°ã¬ã¼ã¸ã¢ã¹,Iglesias", :latitude => "39.31139", :longitude => "8.535").save
City.new(:country_id => "112", :name => "Gioia Tauro", :aliases => "Gioia Tauro,Gioia Tauro", :latitude => "38.42397", :longitude => "15.899").save
City.new(:country_id => "112", :name => "Giarre", :aliases => "Dzharre,Giarre,Giarre Riposto,Giarri,Girarre,ÐÐ¶Ð°ÑÑÐµ,Giarre", :latitude => "37.72686", :longitude => "15.18769").save
City.new(:country_id => "112", :name => "Gela", :aliases => "Dzhela,Gela,ge la,jera,jie la,ÐÐ¶ÐµÐ»Ð°,ã¸ã§ã¼ã©,æ°æ,æ ¼æ,Gela", :latitude => "37.08034", :longitude => "14.23068").save
City.new(:country_id => "112", :name => "Floridia", :aliases => "Ciuriddia,Floridia,Floridii,furoridia,Ð¤Ð»Ð¾ÑÐ¸Ð´Ð¸Ð¸,ãã­ãªã¼ãã£ã¢,Floridia", :latitude => "37.08695", :longitude => "15.15189").save
City.new(:country_id => "112", :name => "Favara", :aliases => "Favara,Favara", :latitude => "37.31754", :longitude => "13.66226").save
City.new(:country_id => "112", :name => "Erice", :aliases => "Ehriche,Erice,Erici,Mont Eryx,Mont Ãryx,Monte San Giuliano,Ãrici,Ð­ÑÐ¸ÑÐµ,Erice", :latitude => "38.03704", :longitude => "12.58653").save
City.new(:country_id => "112", :name => "Enna", :aliases => "Castrugiuvanni,Ehnna,Ena,Enna,Haenna,en'na,ÐÐ½Ð°,Ð­Ð½Ð½Ð°,×× ×,ã¨ã³ã,Enna", :latitude => "37.55885", :longitude => "14.28917").save
City.new(:country_id => "112", :name => "Crotone", :aliases => "Cotrone,Krotone,ÐÑÐ¾ÑÐ¾Ð½Ðµ,Crotone", :latitude => "39.0851", :longitude => "17.11781").save
City.new(:country_id => "112", :name => "Cosenza", :aliases => "Cosenza,Cusenza,Kozenca,kozentsu~a,ÐÐ¾Ð·ÐµÐ½ÑÐ°,ã³ã¼ã³ãã¡,Cosenza", :latitude => "39.30999", :longitude => "16.25019").save
City.new(:country_id => "112", :name => "Corigliano Calabro", :aliases => "Corigliano Calabro,ã³ãªãªã¢ã¼ãã»ã«ã¼ã©ãã­,Corigliano Calabro", :latitude => "39.595", :longitude => "16.5177").save
City.new(:country_id => "112", :name => "Comiso", :aliases => "Comiso,Comisu,Commisu,CÃ²misu,CÃ²mmisu,Komizo,komizo,ÐÐ¾Ð¼Ð¸Ð·Ð¾,ã³ã¼ãã¾,Comiso", :latitude => "36.95134", :longitude => "14.61018").save
City.new(:country_id => "112", :name => "Catanzaro", :aliases => "Catanzara,Catanzaro,Catanzaru,Katandzaro,katantsu~aro,ÐÐ°ÑÐ°Ð½Ð´Ð·Ð°ÑÐ¾,ã«ã¿ã³ãã¡ã¼ã­,Catanzaro", :latitude => "38.89079", :longitude => "16.5987").save
City.new(:country_id => "112", :name => "Catania", :aliases => "Catane,Catania,Catina,CatÃ nia,CatÃ¢nia,Katane,Katania,Katanija,KatÄnija,katania,katanya,qtnyh,ÎÎ±ÏÎ¬Î½Î·,ÐÐ°ÑÐ°Ð½Ð¸Ñ,ÐÐ°ÑÐ°Ð½Ð¸ÑÐ°,×§×× ××,ÙØ§ØªØ§ÙÙØ§,ááá¢áááá,ã«ã¿ã¼ãã¢,Catania", :latitude => "37.50213", :longitude => "15.08719").save
City.new(:country_id => "112", :name => "Castrovillari", :aliases => "Castrovillari,Kastrovillari,ÐÐ°ÑÑÑÐ¾Ð²Ð¸Ð»Ð»Ð°ÑÐ¸,Castrovillari", :latitude => "39.8203", :longitude => "16.21229").save
City.new(:country_id => "112", :name => "Castelvetrano", :aliases => "Castedduvitranu,Castelvetrano,Castelvetranu,Kastel'vetrano,kasuteruvu~etorano,ÐÐ°ÑÑÐµÐ»ÑÐ²ÐµÑÑÐ°Ð½Ð¾,ã«ã¹ãã«ã´ã§ãã©ã¼ã,Castelvetrano", :latitude => "37.68264", :longitude => "12.79164").save
City.new(:country_id => "112", :name => "Cassano al Ionio", :aliases => "Cassano Jonio,Cassano al Jonio,Cassano all'Ionio,Cassano all'IÃ³nio,Cassano allo Ionio", :latitude => "39.783", :longitude => "16.31819").save
City.new(:country_id => "112", :name => "Casarano", :aliases => "Casarano,Casaranu,Casarano", :latitude => "40.01502", :longitude => "18.16303").save
City.new(:country_id => "112", :name => "Carlentini", :aliases => "Carlentini,Carlintini,Carruntini,karurentini,ã«ã«ã¬ã³ãã£ã¼ã,Carlentini", :latitude => "37.26955", :longitude => "15.01259").save
City.new(:country_id => "112", :name => "Carini", :aliases => "Carini,Karina,ÐÐ°ÑÐ¸Ð½Ð°,Carini", :latitude => "38.15665", :longitude => "13.17764").save
City.new(:country_id => "112", :name => "Carbonia", :aliases => "Carbonia,Karbonija,karubonia,ÐÐ°ÑÐ±Ð¾Ð½Ð¸Ñ,ã«ã«ãã¼ãã¢,Carbonia", :latitude => "39.16722", :longitude => "8.52222").save
City.new(:country_id => "112", :name => "Capoterra", :aliases => "Cabuderra,Capoterra,Kapoterra,ÐÐ°Ð¿Ð¾ÑÐµÑÑÐ°,Capoterra", :latitude => "39.17444", :longitude => "8.97111").save
City.new(:country_id => "112", :name => "Canicatti", :aliases => "Canicatti,CanicattÃ¬,CanicattÃ¬", :latitude => "37.35894", :longitude => "13.85036").save
City.new(:country_id => "112", :name => "Caltanissetta", :aliases => "Caltanisetta,Caltanissetta,Kal'tanissetta,Nissa,karutanissetta,qltnysth,ÐÐ°Ð»ÑÑÐ°Ð½Ð¸ÑÑÐµÑÑÐ°,×§××× ××¡××,ã«ã«ã¿ããã»ãã¿,Caltanissetta", :latitude => "37.48774", :longitude => "14.04497").save
City.new(:country_id => "112", :name => "Caltagirone", :aliases => "Caltaggiruni,Caltagirone,Kal'tadzhirone,karutajirone,ÐÐ°Ð»ÑÑÐ°Ð´Ð¶Ð¸ÑÐ¾Ð½Ðµ,ã«ã«ã¿ã¸ã­ã¼ã,Caltagirone", :latitude => "37.23682", :longitude => "14.5132").save
City.new(:country_id => "112", :name => "Cagliari", :aliases => "Cagliari,Caller,Caralis,Casteddu,Castel,CastÃ¨l,CÃ gliari,CÃ ller,CÃ¡ller,Kal'jari,Kalari,ka li ya li,kalyary,karyari,ÐÐ°Ð»ÑÑÑÐ¸,ÐÐ°ÑÐ°ÑÐ¸,×§××××¨×,ÙØ§ÙÙØ§Ø±Ù,ã«ãªã£ãª,å¡å©äºé,Cagliari", :latitude => "39.20738", :longitude => "9.13462").save
City.new(:country_id => "112", :name => "Bronte", :aliases => "Bronte,Bronti,Bronte", :latitude => "37.78946", :longitude => "14.83418").save
City.new(:country_id => "112", :name => "Biancavilla", :aliases => "Biancavilla,Biancavilla", :latitude => "37.64515", :longitude => "14.86708").save
City.new(:country_id => "112", :name => "Belpasso", :aliases => "Belpasso,Belpassu,Belpasso", :latitude => "37.59465", :longitude => "14.98338").save
City.new(:country_id => "112", :name => "Barcellona-Pozzo di Gotto", :aliases => "Barcellona,Barcellona Pozzo di Gotto,Barcillona siciliana,Barcellona Pozzo di Gotto", :latitude => "38.14756", :longitude => "15.21048").save
City.new(:country_id => "112", :name => "Bagheria", :aliases => "Bagerija,Bagheria,ÐÐ°Ð³ÐµÑÐ¸Ñ,Bagheria", :latitude => "38.07935", :longitude => "13.50935").save
City.new(:country_id => "112", :name => "Avola", :aliases => "Avola,Avula,avu~ora,Ãvula,ã¢ã¼ã´ã©ã©,Avola", :latitude => "36.91134", :longitude => "15.1395").save
City.new(:country_id => "112", :name => "Augusta", :aliases => "Augusta,Austa,augusuta,ã¢ã¦ã°ã¹ã¿,Augusta", :latitude => "37.23655", :longitude => "15.21969").save
City.new(:country_id => "112", :name => "Assemini", :aliases => "Assemini,AssÃ¨mini,ÐÑÑÐµÐ¼Ð¸Ð½Ð¸,Assemini", :latitude => "39.29056", :longitude => "8.99694").save
City.new(:country_id => "112", :name => "Amato", :aliases => ",Amato", :latitude => "38.38333", :longitude => "16.13333").save
City.new(:country_id => "112", :name => "Alcamo", :aliases => "Al'kamo,Alcamo,Arcamu,Ãrcamu,ÐÐ»ÑÐºÐ°Ð¼Ð¾,Alcamo", :latitude => "37.99835", :longitude => "12.95654").save
City.new(:country_id => "112", :name => "Agrigento", :aliases => "Agridzentas,Agridzhento,AgridÅ¾entas,Agrigent,Agrigente,Agrigento,Agrigentum,Agrixento - Agrigento,Girgenti,agurijento,ÐÐ³ÑÐ¸Ð´Ð¶ÐµÐ½ÑÐ¾,×××¨××'× ××,ã¢ã°ãªã¸ã§ã³ã,Agrigento", :latitude => "37.32084", :longitude => "13.58876").save
City.new(:country_id => "112", :name => "Adrano", :aliases => "Aderno,AdernÃ³,Adrano,ÐÐ´ÑÐ°Ð½Ð¾,Adrano", :latitude => "37.66175", :longitude => "14.83478").save
City.new(:country_id => "112", :name => "Acri", :aliases => "Acri,Akri,akuri,ÐÐºÑÐ¸,ã¢ã¯ãª,Acri", :latitude => "39.4929", :longitude => "16.38379").save
City.new(:country_id => "112", :name => "Aci Sant'Antonio", :aliases => "Aci Sant'Antonio,Jaci Sant'Antoniu,Aci Sant'Antonio", :latitude => "37.60616", :longitude => "15.12019").save
City.new(:country_id => "112", :name => "Acireale", :aliases => ",Acireale", :latitude => "37.60666", :longitude => "15.16279").save
City.new(:country_id => "112", :name => "Aci Catena", :aliases => "Aci Catena,Jaci Catena,Aci Catena", :latitude => "37.59596", :longitude => "15.14019").save
City.new(:country_id => "112", :name => "Aci Castello", :aliases => "Aci Castello,Jaci Casteddu,Aci Castello", :latitude => "37.55825", :longitude => "15.13459").save
City.new(:country_id => "112", :name => "Zola Predosa", :aliases => ",Zola Predosa", :latitude => "44.48966", :longitude => "11.21831").save
City.new(:country_id => "112", :name => "Voghera", :aliases => "Iria,Vogera,Voghera,vu~ogera,ÐÐ¾Ð³ÐµÑÐ°,ã´ã©ã²ã¼ã©,Voghera", :latitude => "44.99467", :longitude => "9.00862").save
City.new(:country_id => "112", :name => "Vittorio Veneto", :aliases => "Vitorio,Vittorio,Vittorio Veneto,Vittorio-Veneto,VitÃ²rio,ÐÐ¸ÑÑÐ¾ÑÐ¸Ð¾-ÐÐµÐ½ÐµÑÐ¾,ã´ã£ãããªãªã»ã´ã§ãã,Vittorio Veneto", :latitude => "45.97667", :longitude => "12.30333").save
City.new(:country_id => "112", :name => "Viterbo", :aliases => "Viterbe,Viterbium,Viterbo,vu~iterubo,ÐÐ¸ÑÐµÑÐ±Ð¾,ã´ã£ãã«ã,Viterbo", :latitude => "42.41783", :longitude => "12.10856").save
City.new(:country_id => "112", :name => "Vimercate", :aliases => "Vicus Mercati,Vimercate,vu~imerukate,ã´ã£ã¡ã«ã«ã¼ã,Vimercate", :latitude => "45.61188", :longitude => "9.36705").save
City.new(:country_id => "112", :name => "Villorba", :aliases => "Villorba,Villorba", :latitude => "45.73833", :longitude => "12.23361").save
City.new(:country_id => "112", :name => "Villaricca", :aliases => "Villaricca,Villarikka,vu~irrarikka,ÐÐ¸Ð»Ð»Ð°ÑÐ¸ÐºÐºÐ°,ã´ã£ãã©ãªãã«,Villaricca", :latitude => "40.92161", :longitude => "14.18983").save
City.new(:country_id => "112", :name => "Villafranca di Verona", :aliases => "Villafranca di Verona,ã´ã£ãã©ãã©ã³ã«ã»ãã£ã»ã´ã§ã­ã¼ã,Villafranca di Verona", :latitude => "45.35238", :longitude => "10.84019").save
City.new(:country_id => "112", :name => "Vigonza", :aliases => ",Vigonza", :latitude => "45.4276", :longitude => "11.95941").save
City.new(:country_id => "112", :name => "Vignola", :aliases => "Vignola,Viynola,Vignola", :latitude => "44.48296", :longitude => "11.0048").save
City.new(:country_id => "112", :name => "Vigevano", :aliases => "Vidzhevano,Vigebanum,Vigevano,vu~ijevu~ano,ÐÐ¸Ð´Ð¶ÐµÐ²Ð°Ð½Ð¾,ã´ã£ã¸ã§ã¼ã´ã¡ã,Vigevano", :latitude => "45.31166", :longitude => "8.86114").save
City.new(:country_id => "112", :name => "Vico Equense", :aliases => "Vico Equense,ã´ã£ã¼ã³ã»ã¨ã¯ã¨ã³ã»,Vico Equense", :latitude => "40.65981", :longitude => "14.43174").save
City.new(:country_id => "112", :name => "Vicenza", :aliases => "Vicence,Vicenza,Vicenzsa,Vicetia,Vichenca,vu~ichentsu~a,ÐÐ¸ÑÐµÐ½ÑÐ°,ã´ã£ãã§ã³ãã¡,Vicenza", :latitude => "45.55729", :longitude => "11.5409").save
City.new(:country_id => "112", :name => "Viareggio", :aliases => "Viaredzhio,Viareggio,Viareggiu,vu~iarejjo,ÐÐ¸Ð°ÑÐµÐ´Ð¶Ð¸Ð¾,ã´ã£ã¢ã¬ãã¸ã§,Viareggio", :latitude => "43.87354", :longitude => "10.2558").save
City.new(:country_id => "112", :name => "Viadana", :aliases => "Viadana,Viadena,Viadana", :latitude => "44.92947", :longitude => "10.51859").save
City.new(:country_id => "112", :name => "Verona", :aliases => "Verona,Verone,VÃ©rone,Werona,fyrwna,verona,vu~erona,wei luo na,wrwna,wrwnh,ÐÐµÑÐ¾Ð½Ð°,××¨×× ×,ÙÙØ±ÙÙØ§,ÙØ±ÙÙØ§,à¤µà¥à¤°à¥à¤¨à¤¾,ã´ã§ã­ã¼ã,ç»´ç½çº³,Verona", :latitude => "45.43419", :longitude => "10.99779").save
City.new(:country_id => "112", :name => "Veroli", :aliases => "Veroli,Veroli", :latitude => "41.6824", :longitude => "13.41774").save
City.new(:country_id => "112", :name => "Vercelli", :aliases => "Verceil,Vercellae,Vercelli,Verchelli,VercÃ¨lli,vu~erucherri,ÐÐµÑÑÐµÐ»Ð»Ð¸,ã´ã§ã«ãã§ããª,Vercelli", :latitude => "45.32306", :longitude => "8.41533").save
City.new(:country_id => "112", :name => "Ventimiglia", :aliases => "Ventimiglia,Ventimil'ja,Vintimille,vu~entimiria,ÐÐµÐ½ÑÐ¸Ð¼Ð¸Ð»ÑÑ,ã´ã§ã³ãã£ããªã¢,Ventimiglia", :latitude => "43.78956", :longitude => "7.60872").save
City.new(:country_id => "112", :name => "Venice", :aliases => "Benatky,Benetia,Benetke,Benezia,BenÃ¡tky,Feneyjar,V'nise,Velence,Venecia,Venecia - Venezia,Venecija,Venecio,Venedeg,Venedig,Venedik,Venediku,Venesia,Venetia,Venetie,Venetik,VenetiÃ«,Venetsia,Veneza,Venezia,Venezsia,VeneÅ£ia,Venice,Venies,Venise,Venizia,VenÃ¨cia,VenÃ¨sia,Vignesie,Vinezzia,Wenecja,albndqyt,benechia,benisu,venetsia,vu~enetsu~ia,vu~enisu,wei ni si,wnyz,wnzyh,ÎÎµÎ½ÎµÏÎ¯Î±,ÐÐµÐ½ÐµÑÐ¸Ñ,ÐÐµÐ½ÐµÑÐ¸ÑÐ°,ÐÐµÐ½ÐµÑÑÑ,ÕÕ¥Õ¶Õ¥Õ¿Õ«Õ¯,×× ×¦××,Ø§ÙØ¨ÙØ¯ÙÙØ©,ÙÙÛØ²,ÛÛÙÙØªØ³ÙÙÛ,áááááªáá,ããã¹,ã´ã§ãã¹,ã´ã§ããã£ã¢,å¨å°¼æ¯,ë² ë¤ì¹ì,Venice", :latitude => "45.43861", :longitude => "12.32667").save
City.new(:country_id => "112", :name => "Venaria Reale", :aliases => "Venaria,Venaria Reale,ã´ã§ããªã¼ã¢ã»ã¬ã¢ã¼ã¬,Venaria Reale", :latitude => "45.12385", :longitude => "7.63542").save
City.new(:country_id => "112", :name => "Velletri", :aliases => "Velitrae,Velletri,vu~erretori,ã´ã§ãã¬ããª,Velletri", :latitude => "41.66922", :longitude => "12.77929").save
City.new(:country_id => "112", :name => "Vasto", :aliases => "Istonio,Vasto,ÐÐ°ÑÑÐ¾,Vasto", :latitude => "42.12434", :longitude => "14.70592").save
City.new(:country_id => "112", :name => "Varese", :aliases => "Baretium,Vareis,Varese,Vareze,VarÃ¨is,VarÃ¨se,vu~areze,wa lei ze,ÐÐ°ÑÐµÐ·Ðµ,ã´ã¡ã¬ã¼ã¼,ç¦é·æ¾¤,Varese", :latitude => "45.82908", :longitude => "8.82193").save
City.new(:country_id => "112", :name => "Valenzano", :aliases => "Valenzano,Valenzano", :latitude => "41.04533", :longitude => "16.88509").save
City.new(:country_id => "112", :name => "Valenza", :aliases => "Valensa,Valenza,ÐÐ°Ð»ÐµÐ½ÑÐ°,Valenza", :latitude => "45.01406", :longitude => "8.64144").save
City.new(:country_id => "112", :name => "Valdagno", :aliases => "Valdagno,Valdagno", :latitude => "45.6483", :longitude => "11.30639").save
City.new(:country_id => "112", :name => "Urbino", :aliases => "Urbin,Urbino,Urbinu,Urvinum Mataurense,urubino,Ð£ÑÐ±Ð¸Ð½Ð¾,×××¨××× ×,ã¦ã«ãã¼ã,Urbino", :latitude => "43.72621", :longitude => "12.63633").save
City.new(:country_id => "112", :name => "Umbertide", :aliases => "Umbertide,Umbertide", :latitude => "43.30555", :longitude => "12.33655").save
City.new(:country_id => "112", :name => "Udine", :aliases => "Udin,Udine,Ð£Ð´Ð¸Ð½Ðµ,Udine", :latitude => "46.06194", :longitude => "13.24222").save
City.new(:country_id => "112", :name => "Triggiano", :aliases => "Triggiano,Triggiano", :latitude => "41.06673", :longitude => "16.92599").save
City.new(:country_id => "112", :name => "Trieste", :aliases => "Tergeste,Terst,Triest,Triestas,Trieste,Triesti,Triesto,Trieszt,TriÃ«st,Trst,de li ya si te,teulieseute,toriesute,tri'esta,tryysty,Ð¢ÑÐ¸ÐµÑÑ,Ð¢ÑÑÑ,××¨×××¡××,ØªØ±ÙÙØ³ØªÙ,à¤à¥à¤°à¤¿à¤à¤¸à¥à¤,ããªã¨ã¹ã,çééæ¯ç¹,í¸ë¦¬ìì¤í,Trieste", :latitude => "45.64861", :longitude => "13.78").save
City.new(:country_id => "112", :name => "Trezzano sul Naviglio", :aliases => "Trezzano sul Naviglio,ãã¬ããã¡ã¼ãã»ã¹ã«ã»ãã´ã£ã¼ãªãª,Trezzano sul Naviglio", :latitude => "45.42307", :longitude => "9.06644").save
City.new(:country_id => "112", :name => "Treviso", :aliases => "Tarvisium,Trevise,Treviso,Trevixo,Trevizo,TrÃ©vise,torevu~izo,trwwyzw,Ð¢ÑÐµÐ²Ð¸Ð·Ð¾,××¨×××××,ãã¬ã´ã£ã¼ã¾,Treviso", :latitude => "45.66667", :longitude => "12.245").save
City.new(:country_id => "112", :name => "Treviglio", :aliases => "Treviglio,Trevil'o,Trevilio,torevu~irio,Ð¢ÑÐµÐ²Ð¸Ð»ÑÐ¾,ãã¬ã´ã£ã¼ãªãª,Treviglio", :latitude => "45.52378", :longitude => "9.58946").save
City.new(:country_id => "112", :name => "Trento", :aliases => "Trehnta,Trent,Trent/o,Trente,Trento,Trident,Tridentum,Trient,Trydent,TrÃ©nto,torento,Ð¢ÑÐµÐ½ÑÐ¾,Ð¢ÑÑÐ½ÑÐ°,ãã¬ã³ã,Trento", :latitude => "46.06787", :longitude => "11.12108").save
City.new(:country_id => "112", :name => "Trecate", :aliases => "Trecate,Trecate", :latitude => "45.43477", :longitude => "8.73684").save
City.new(:country_id => "112", :name => "Trani", :aliases => "Trani,Turenum,torani,Ð¢ÑÐ°Ð½Ð¸,ãã©ã¼ã,Trani", :latitude => "41.27273", :longitude => "16.41537").save
City.new(:country_id => "112", :name => "Tradate", :aliases => "Tradate,Tradate", :latitude => "45.71097", :longitude => "8.90764").save
City.new(:country_id => "112", :name => "Tortona", :aliases => "Tortona,Ð¢Ð¾ÑÑÐ¾Ð½Ð°,Tortona", :latitude => "44.89784", :longitude => "8.86374").save
City.new(:country_id => "112", :name => "Torre Maggiore", :aliases => ",Torremaggiore", :latitude => "41.69074", :longitude => "15.29634").save
City.new(:country_id => "112", :name => "Torre del Greco", :aliases => "Torre d''o Grieco,Torre del Greco,Torre-del'-Greko,Ð¢Ð¾ÑÑÐµ-Ð´ÐµÐ»Ñ-ÐÑÐµÐºÐ¾,ããã¬ã»ãã«ã»ã°ã¬ã¼ã³,Torre del Greco", :latitude => "40.78392", :longitude => "14.3708").save
City.new(:country_id => "112", :name => "Torre Annunziata", :aliases => "Torre Annunziata,Torre Nunziata,Torre-Annunciata,Ð¢Ð¾ÑÑÐµ-ÐÐ½Ð½ÑÐ½ÑÐ¸Ð°ÑÐ°,ããã¬ã»ã¢ã³ãã³ãã£ã¢ã¼ã¿,Torre Annunziata", :latitude => "40.74971", :longitude => "14.46464").save
City.new(:country_id => "112", :name => "Torino", :aliases => "Julia Augusta Taurinorum,Taurasia,Taurinum,Tori,Torin,Torino,Torinu,TorÃ­,Turen,Turijn,Turim,Turin,Turin - Torino,Turina,Turinas,Turino,Turyn,TurÃ©n,TurÃ­n,TurÃ­n - Torino,TurÄ«na,TÃ³rÃ­nÃ³,dou ling,tolino,torino,twryn,twrynw,Ð¢Ð¾ÑÐ¸Ð½Ð¾,Ð¢ÑÑÐ¸Ð½,Ð¢ÑÑÑÐ½,Ð¢ÑÑÑÐ½,Ô¹Õ¸ÖÖÕ«Õ¶,×××¨×× ×,ØªÙØ±ÙÙÙ,ØªÙØ±ÛÙ,à¤à¥à¤°à¥à¤¨à¥,à¤¤à¥à¤°à¤¿à¤¨à¥,á¢á£á ááá,ããªã,é½é,í ë¦¬ë¸,Torino", :latitude => "45.07049", :longitude => "7.68682").save
City.new(:country_id => "112", :name => "Tolentino", :aliases => "Tolentino,Tolentino", :latitude => "43.21255", :longitude => "13.29008").save
City.new(:country_id => "112", :name => "Todi", :aliases => "Todi,Todi", :latitude => "42.77994", :longitude => "12.40456").save
City.new(:country_id => "112", :name => "Tivoli", :aliases => "Tibur,Tivoli,tivu~ori,tybwly,Ð¢Ð¸Ð²Ð¾Ð»Ð¸,××××××,ãã£ã´ã©ãª,Tivoli", :latitude => "41.96092", :longitude => "12.79888").save
City.new(:country_id => "112", :name => "Thiene", :aliases => "T'ene,Thiene,Ð¢ÑÐµÐ½Ðµ,Thiene", :latitude => "45.7088", :longitude => "11.47959").save
City.new(:country_id => "112", :name => "Terzigno", :aliases => "Terzigno,terutsu~inyo,ãã«ãã£ã¼ãã§,Terzigno", :latitude => "40.81221", :longitude => "14.49644").save
City.new(:country_id => "112", :name => "Terracina", :aliases => "Terrachina,Terracina,terrachina,Ð¢ÐµÑÑÐ°ÑÐ¸Ð½Ð°,ããã©ãã¼ã,Terracina", :latitude => "41.28967", :longitude => "13.24127").save
City.new(:country_id => "112", :name => "Terni", :aliases => "Interamna,Terni,teruni,Ð¢ÐµÑÐ½Ð¸,ãã«ã,Terni", :latitude => "42.56713", :longitude => "12.64987").save
City.new(:country_id => "112", :name => "Termoli", :aliases => "Termoli,Ð¢ÐµÑÐ¼Ð¾Ð»Ð¸,Termoli", :latitude => "41.98884", :longitude => "14.98953").save
City.new(:country_id => "112", :name => "Terlizzi", :aliases => "Terlicci,Terlizzi,Ð¢ÐµÑÐ»Ð¸ÑÑÐ¸,Terlizzi", :latitude => "41.13113", :longitude => "16.54528").save
City.new(:country_id => "112", :name => "Teramo", :aliases => "Interamnium,Teramo,TÃ©ramo,teramo,Ð¢ÐµÑÐ°Ð¼Ð¾,ãã¼ã©ã¢,Teramo", :latitude => "42.66123", :longitude => "13.69901").save
City.new(:country_id => "112", :name => "Tarquinia", :aliases => "Tarkvinii,Tarquinia,TarquÃ­nia,tarukuinia,Ð¢Ð°ÑÐºÐ²Ð¸Ð½Ð¸Ð¸,ã¿ã«ã¯ã¤ã¼ãã¢,Tarquinia", :latitude => "42.25419", :longitude => "11.75657").save
City.new(:country_id => "112", :name => "Taranto", :aliases => "Taranto,Tarde,Tarent,Tarente,Tarento,Tarento - Taranto,Tarentum,TÃ rent,taranto,tarantw,Ð¢Ð°ÑÐ°Ð½ÑÐ¾,ØªØ§Ø±Ø§ÙØªÙ,á¢áá ááá¢á,ã¿ã¼ã©ã³ã,Taranto", :latitude => "40.47611", :longitude => "17.22972").save
City.new(:country_id => "112", :name => "Suzzara", :aliases => ",Suzzara", :latitude => "44.99187", :longitude => "10.74309").save
City.new(:country_id => "112", :name => "Sulmona", :aliases => "Salmona,Sulmo,Sulmona,Ð¡ÑÐ»Ð¼Ð¾Ð½Ð°,Sulmona", :latitude => "42.04793", :longitude => "13.92911").save
City.new(:country_id => "112", :name => "Squinzano", :aliases => "Squinzano,Squinzano", :latitude => "40.43653", :longitude => "18.04182").save
City.new(:country_id => "112", :name => "Spoltore", :aliases => "Spoltore,Spoltore", :latitude => "42.45344", :longitude => "14.14101").save
City.new(:country_id => "112", :name => "Spoleto", :aliases => "Spolete,Spoletium,Spoleto,SpolÃ¨te,suporeto,Ð¡Ð¿Ð¾Ð»ÐµÑÐ¾,ã¹ãã¬ã¼ã,Spoleto", :latitude => "42.74484", :longitude => "12.73737").save
City.new(:country_id => "112", :name => "Sorrento", :aliases => "Sorrent,Sorrente,Sorrento,Surriento,sorento,swrntw,Ð¡Ð¾ÑÑÐµÐ½ÑÐ¾,×¡××¨× ××,à¤¸à¥à¤°à¥à¤¨à¥à¤à¥,ã½ã¬ã³ã,Sorrento", :latitude => "40.62601", :longitude => "14.37441").save
City.new(:country_id => "112", :name => "Sora", :aliases => "Sora,sora,Ð¡Ð¾ÑÐ°,á¡áá á,Sora", :latitude => "41.71572", :longitude => "13.6141").save
City.new(:country_id => "112", :name => "Sondrio", :aliases => "Sondri,Sondrio,Sundrium,sang zhi ao,sondorio,sundrium,Ð¡Ð¾Ð½Ð´ÑÐ¸Ð¾,ã½ã³ããªãª,æ¡æ²»å¥§,Sondrio", :latitude => "46.169", :longitude => "9.86915").save
City.new(:country_id => "112", :name => "Somma Vesuviana", :aliases => "Somma,Somma Vesuviana,ã½ã³ãã»ã´ã§ãºã´ã£ã¢ã¼ã,Somma Vesuviana", :latitude => "40.87161", :longitude => "14.43613").save
City.new(:country_id => "112", :name => "Somma Lombardo", :aliases => "Somma,Somma Lombardo,ã½ã³ãã»ã­ã³ãã«ã,Somma Lombardo", :latitude => "45.68297", :longitude => "8.70873").save
City.new(:country_id => "112", :name => "Signa", :aliases => "Signa,Signa", :latitude => "43.79235", :longitude => "11.09792").save
City.new(:country_id => "112", :name => "Siena", :aliases => "Saena Iulia,Saena Julia,Sena,Sien-a,Siena,Sienne,Sieno,SÃ©na,shiena,siyena,syynh,Î£Î¹Î­Î½Î±,Ð¡Ð¸ÐµÐ½Ð°,Ð¡ÑÐµÐ½Ð°,×¡××× ×,à¤¸à¤¿à¤¯à¥à¤¨à¤¾,ã·ã¨ã¼ã,Siena", :latitude => "43.32004", :longitude => "11.33283").save
City.new(:country_id => "112", :name => "Sezze", :aliases => "Sezze,settsu~e,ã»ããã§,Sezze", :latitude => "41.50331", :longitude => "13.0641").save
City.new(:country_id => "112", :name => "Seveso", :aliases => "Seveso,sevu~ezo,ã»ã¼ã´ã§ã¾,Seveso", :latitude => "45.66013", :longitude => "9.16028").save
City.new(:country_id => "112", :name => "Settimo Torinese", :aliases => "Seto,Settimo,Settimo Torinese,ã»ããã£ã¢ã»ããªãã¼ã¼,Settimo Torinese", :latitude => "45.14025", :longitude => "7.76802").save
City.new(:country_id => "112", :name => "Sestri Levante", :aliases => "Sestri Levante,Sestri Levante", :latitude => "44.27317", :longitude => "9.39683").save
City.new(:country_id => "112", :name => "Sesto San Giovanni", :aliases => "Sesto,Sesto San Giovanni,ã»ã¹ãã»ãµã³ã»ã¸ã§ã´ã¡ã³ã,Sesto San Giovanni", :latitude => "45.53449", :longitude => "9.23401").save
City.new(:country_id => "112", :name => "Sesto Fiorentino", :aliases => "Sesto,Sesto Fiorentino,Sesto Fiorentino", :latitude => "43.83455", :longitude => "11.19522").save
City.new(:country_id => "112", :name => "Sessa Aurunca", :aliases => "Sessa Aurunca,Suessa,Sessa Aurunca", :latitude => "41.24082", :longitude => "13.93282").save
City.new(:country_id => "112", :name => "Seriate", :aliases => "Seriate,Ð¡ÐµÑÐ¸Ð°ÑÐµ,Seriate", :latitude => "45.68338", :longitude => "9.72286").save
City.new(:country_id => "112", :name => "Seregno", :aliases => "Seregn,Seregno,SerÃ¨gn,serenyo,ã»ã¬ã¼ãã§,Seregno", :latitude => "45.65238", :longitude => "9.20034").save
City.new(:country_id => "112", :name => "Senigallia", :aliases => "Senigallia,Senigallija,senigarria,Ð¡ÐµÐ½Ð¸Ð³Ð°Ð»Ð»Ð¸Ñ,ã»ãã¬ããªã¢,Senigallia", :latitude => "43.70926", :longitude => "13.21667").save
City.new(:country_id => "112", :name => "Senago", :aliases => ",Senago", :latitude => "45.57627", :longitude => "9.12454").save
City.new(:country_id => "112", :name => "Selvazzano Dentro", :aliases => "Selvazzano Dentro,Selvazzano Dentro", :latitude => "45.39139", :longitude => "11.80051").save
City.new(:country_id => "112", :name => "Segrate", :aliases => "Segrate,segurate,ã»ã°ã©ã¼ã,Segrate", :latitude => "45.49624", :longitude => "9.29323").save
City.new(:country_id => "112", :name => "Scorze", :aliases => "Scorze,ScorzÃ¨,sukorutsu~e,ã¹ã³ã«ãã§,ScorzÃ¨", :latitude => "45.57361", :longitude => "12.10611").save
City.new(:country_id => "112", :name => "Schio", :aliases => "Schio,Skio,Ð¡ÐºÐ¸Ð¾,Schio", :latitude => "45.7124", :longitude => "11.35739").save
City.new(:country_id => "112", :name => "Scandicci", :aliases => "Scadicci,Scandicci,Skandichchi,Ð¡ÐºÐ°Ð½Ð´Ð¸ÑÑÐ¸,Scandicci", :latitude => "43.76605", :longitude => "11.15472").save
City.new(:country_id => "112", :name => "Scandiano", :aliases => "Scandiano,Scandiano", :latitude => "44.59646", :longitude => "10.6907").save
City.new(:country_id => "112", :name => "Scafati", :aliases => "Scafati,Scafati", :latitude => "40.75281", :longitude => "14.53384").save
City.new(:country_id => "112", :name => "Savona", :aliases => "Sann-a,Saona,Savo,Savo Oppidum Alpinum,Savon-a,Savona,Savone,savu~ona,Ð¡Ð°Ð²Ð¾Ð½Ð°,ãµã´ã©ã¼ã,Savona", :latitude => "44.30905", :longitude => "8.47715").save
City.new(:country_id => "112", :name => "Savigliano", :aliases => "Savian,Savigliano,Savigliano", :latitude => "44.64404", :longitude => "7.65593").save
City.new(:country_id => "112", :name => "Sava", :aliases => "Sava,Sava", :latitude => "40.40342", :longitude => "17.55841").save
City.new(:country_id => "112", :name => "Sassuolo", :aliases => "Sassuolo,Ð¡Ð°ÑÑÑÐ¾Ð»Ð¾,Sassuolo", :latitude => "44.55086", :longitude => "10.7847").save
City.new(:country_id => "112", :name => "Sassari", :aliases => "Sassari,Sasser,SÃ sser,Tatari,Tathari,Tattari,TÃ thari,sasary,sassari,Ð¡Ð°ÑÑÐ°ÑÐ¸,Ø³Ø§Ø³Ø§Ø±Ù,ãµããµãª,Sassari", :latitude => "40.72722", :longitude => "8.56028").save
City.new(:country_id => "112", :name => "Sarzana", :aliases => "Sarzana,Sarzana", :latitude => "44.11145", :longitude => "9.95859").save
City.new(:country_id => "112", :name => "Saronno", :aliases => "Saronno,Saronno", :latitude => "45.62787", :longitude => "9.03464").save
City.new(:country_id => "112", :name => "Sarno", :aliases => "Sarno,Ð¡Ð°ÑÐ½Ð¾,Sarno", :latitude => "40.81081", :longitude => "14.61984").save
City.new(:country_id => "112", :name => "San Vito dei Normanni", :aliases => "San Vito de' Normanni,San Vito dei Normanni", :latitude => "40.65733", :longitude => "17.70721").save
City.new(:country_id => "112", :name => "Santeramo in Colle", :aliases => "Santeramo in Colle,Santeramo in Colle", :latitude => "40.79303", :longitude => "16.75529").save
City.new(:country_id => "112", :name => "Sant'Elpidio a Mare", :aliases => "San Elpido a Mare,Sant'Elpidio a Mare,Sant'Elpidio a Mare", :latitude => "43.22986", :longitude => "13.68608").save
City.new(:country_id => "112", :name => "Sant'Arcangelo di Romagna", :aliases => "Santarcangelo,Santarcangelo di Romagna,Santarcangelo di Romagna", :latitude => "44.07083", :longitude => "12.43583").save
City.new(:country_id => "112", :name => "Sant'Antonio Abate", :aliases => "Sant'Antonio Abate,ãµã³ã¿ã³ãã¼ããªã»ã¢ãã¼ã,Sant'Antonio Abate", :latitude => "40.72371", :longitude => "14.54654").save
City.new(:country_id => "112", :name => "Sant'Antimo", :aliases => "Sant'Antimo,santantimo,ãµã³ã¿ã³ãã£ã¢,Sant'Antimo", :latitude => "40.94571", :longitude => "14.23143").save
City.new(:country_id => "112", :name => "Sant'Anastasia", :aliases => "Sant'Anastasia,santanasutajia,ãµã³ã¿ãã¹ã¿ã¸ã¼ã¢,Sant'Anastasia", :latitude => "40.86691", :longitude => "14.40483").save
City.new(:country_id => "112", :name => "Santa Maria Capua Vetere", :aliases => "Santa Maria Capua Vetere,Santa Maria Capua Vetere", :latitude => "41.08021", :longitude => "14.25653").save
City.new(:country_id => "112", :name => "San Severo", :aliases => "San Severo,ãµã³ã»ã»ã´ã§ã¼ã­,San Severo", :latitude => "41.68974", :longitude => "15.37604").save
City.new(:country_id => "112", :name => "Sansepolcro", :aliases => "Sansepolcro,Sansepolcro", :latitude => "43.57465", :longitude => "12.14304").save
City.new(:country_id => "112", :name => "San Salvo", :aliases => "San Salvo,San Salvo", :latitude => "42.04334", :longitude => "14.72722").save
City.new(:country_id => "112", :name => "San Remo", :aliases => "San Remo,San-Remo,Sanremo,Sanremu,Villa Matutiae,sanremo,sn rmw,Ð¡Ð°Ð½ Ð ÐµÐ¼Ð¾,Ð¡Ð°Ð½-Ð ÐµÐ¼Ð¾,Ð¡Ð°Ð½ÑÐµÐ¼Ð¾,×¡× ×¨××,ãµã³ã¬ã¼ã¢,San Remo", :latitude => "43.81725", :longitude => "7.7772").save
City.new(:country_id => "112", :name => "San Pietro Vernotico", :aliases => "San Pietro Vernotico,San Pietro Vernotico", :latitude => "40.48528", :longitude => "17.99972").save
City.new(:country_id => "112", :name => "Sannicandro Garganico", :aliases => ",San Nicandro Garganico", :latitude => "41.83844", :longitude => "15.56535").save
City.new(:country_id => "112", :name => "San Miniato", :aliases => "San Miniato,San Miniato Basso,San Miniatu,ãµã³ã»ããã¢ã¼ã,San Miniato", :latitude => "43.68994", :longitude => "10.81741").save
City.new(:country_id => "112", :name => "San Mauro Torinese", :aliases => "San Mauro Torinese,San Mo,San MÃ²,ãµã³ã»ãã¦ã­ã»ããªãã¼ã¼,San Mauro Torinese", :latitude => "45.10585", :longitude => "7.75452").save
City.new(:country_id => "112", :name => "San Marco in Lamis", :aliases => "San Marco in Lamis,San Marco in Lamis", :latitude => "41.71314", :longitude => "15.63985").save
City.new(:country_id => "112", :name => "San Lazzaro di Savena", :aliases => "San Lazzaro di Savena,San Lazzaro di Savena", :latitude => "44.46777", :longitude => "11.41401").save
City.new(:country_id => "112", :name => "San Giuseppe Vesuviano", :aliases => "San Giuseppe,San Giuseppe Vesuviano,ãµã³ã»ã¸ã¥ã¼ããã»ã´ã§ãºã´ã£ã¢ã¼ã,San Giuseppe Vesuviano", :latitude => "40.82981", :longitude => "14.50444").save
City.new(:country_id => "112", :name => "San Giuliano Terme", :aliases => "Bagni San Giuliano,Bagni di Pisa,Bagni di San Giuliano,San Giuliano Terme,San Giuliano Terme", :latitude => "43.76164", :longitude => "10.4404").save
City.new(:country_id => "112", :name => "San Giuliano Milanese", :aliases => "San Giuliano,San Giuliano Milanese,ãµã³ã»ã¸ã¥ãªã¢ã¼ãã»ãã©ãã¼ã¼,San Giuliano Milanese", :latitude => "45.39574", :longitude => "9.28757").save
City.new(:country_id => "112", :name => "San Giovanni Valdarno", :aliases => "S. Giovanni Valdarno,San Giovanni,San Giovanni V.no,San Giovanni Valdarno,ãµã³ã»ã¸ã§ã´ã¡ã³ãã»ã´ã¡ã«ãã«ã,San Giovanni Valdarno", :latitude => "43.56667", :longitude => "11.53333").save
City.new(:country_id => "112", :name => "San Giovanni Rotondo", :aliases => "Giovanni Rotondo,San Giovanni Rotondo,San Giovanni Rotondo", :latitude => "41.70494", :longitude => "15.71905").save
City.new(:country_id => "112", :name => "San Giovanni Lupatoto", :aliases => "Lupatoto,San Giovanni Lupatoto,San Giovanni Lupatoto", :latitude => "45.38789", :longitude => "11.03799").save
City.new(:country_id => "112", :name => "San Giovanni in Persiceto", :aliases => "Persiceto,San Giovanni in Persiceto,San Giovanni in Persiceto", :latitude => "44.63997", :longitude => "11.18411").save
City.new(:country_id => "112", :name => "San Giorgio Ionico", :aliases => "San Giorgio Ionico,San Giorgio Jonico,San Giorgio sotto Taranto,San Giorgio Ionico", :latitude => "40.45662", :longitude => "17.3787").save
City.new(:country_id => "112", :name => "San Giorgio a Cremano", :aliases => "San Giorgio a Cremano,ãµã³ã»ã¸ã§ã«ã¸ã§ã»ã¢ã»ã¯ã¬ãã¼ã,San Giorgio a Cremano", :latitude => "40.83071", :longitude => "14.33763").save
City.new(:country_id => "112", :name => "San Donato Milanese", :aliases => "San Donato Milanese,ãµã³ã»ããã¼ãã»ãã©ãã¼ã¼,San Donato Milanese", :latitude => "45.4199", :longitude => "9.26628").save
City.new(:country_id => "112", :name => "San Dona di Piave", :aliases => "San Dona di Piave,San DonÃ  di Piave,ãµã³ã»ããã»ãã£ã»ãã¢ã¼ã´ã§,San DonÃ  di Piave", :latitude => "45.63167", :longitude => "12.56944").save
City.new(:country_id => "112", :name => "San Casciano in Val di Pesa", :aliases => "San Casciano Val di Pesa,San Casciano in Val di Pesa,San Casciano in Val di Pesa", :latitude => "43.65905", :longitude => "11.18952").save
City.new(:country_id => "112", :name => "San Bonifacio", :aliases => "Sambonifacio,San Bonifacio,San Bonifacio", :latitude => "45.39689", :longitude => "11.2844").save
City.new(:country_id => "112", :name => "San Benedetto del Tronto", :aliases => "San Benedetto del Tronto,San Benedetto del Tronto", :latitude => "42.94562", :longitude => "13.88157").save
City.new(:country_id => "112", :name => "Samarate", :aliases => "Samarate,Samarate", :latitude => "45.62537", :longitude => "8.78344").save
City.new(:country_id => "112", :name => "Saluzzo", :aliases => ",Saluzzo", :latitude => "44.64644", :longitude => "7.48623").save
City.new(:country_id => "112", :name => "Salsomaggiore Terme", :aliases => "Salsomaggiore,Salsomaggiore Terme,Salsomaggiore Terme", :latitude => "44.81476", :longitude => "9.97958").save
City.new(:country_id => "112", :name => "Salerno", :aliases => "Salernas,Salerne,Salerno,Salernu,Salernum,Salierno,salyrnw,sareruno,Ð¡Ð°Ð»ÐµÑÐ½Ð¾,Ø³Ø§ÙÙØ±ÙÙ,ãµã¬ã«ã,Salerno", :latitude => "40.67797", :longitude => "14.76599").save
City.new(:country_id => "112", :name => "Sacile", :aliases => "Sacil,Sacile,SacÃ®l,Sacile", :latitude => "45.95528", :longitude => "12.50194").save
City.new(:country_id => "112", :name => "Sabaudia", :aliases => "Sabaudia,sabaudia,ãµãã¦ãã£ã¢,Sabaudia", :latitude => "41.30025", :longitude => "13.02815").save
City.new(:country_id => "112", :name => "Ruvo di Puglia", :aliases => "Ruvo di Puglia,Ruvo di Puglia", :latitude => "41.11363", :longitude => "16.48778").save
City.new(:country_id => "112", :name => "Rutigliano", :aliases => "Rutigliano,Rutigliano", :latitude => "41.01113", :longitude => "17.00549").save
City.new(:country_id => "112", :name => "Rozzano", :aliases => "Rozzano,rottsu~ano,ã­ããã¡ã¼ã,Rozzano", :latitude => "45.38187", :longitude => "9.16055").save
City.new(:country_id => "112", :name => "Rovigo", :aliases => "Rodigium,Rovigo,rovu~igo,Ð Ð¾Ð²Ð¸Ð³Ð¾,ã­ã´ã£ã¼ã´,Rovigo", :latitude => "45.07998", :longitude => "11.79301").save
City.new(:country_id => "112", :name => "Rovereto", :aliases => "Rovereto,rovu~ereto,Ð Ð¾Ð²ÐµÑÐµÑÐ¾,ã­ã´ã§ã¬ã¼ã,Rovereto", :latitude => "45.8896", :longitude => "11.03868").save
City.new(:country_id => "112", :name => "Rosignano Marittimo", :aliases => "Rosignano Marittimo,ã­ã¸ãã£ã¼ãã»ããªããã£ã¢,Rosignano Marittimo", :latitude => "43.40793", :longitude => "10.47291").save
City.new(:country_id => "112", :name => "Roseto degli Abruzzi", :aliases => "Rosburgo,Roseto degli Abruzzi,Roseto degli Abruzzi", :latitude => "42.66635", :longitude => "14.0227").save
City.new(:country_id => "112", :name => "Romano di Lombardia", :aliases => "Romano di Lombardia,Romano di Lombardia", :latitude => "45.52458", :longitude => "9.74836").save
City.new(:country_id => "112", :name => "Roma", :aliases => "An Roimh,An RÃ²imh,An RÃ³imh,Erroma,Hrom,Lungsod ng Roma,Mji wa Roma,ROM,Ramma,Rhufain,Rim,Rim',Roeme,Rom,Roma,Rome,Romma,Romo,RomÃ«,Rooma,Roum,Rym,Rzym,RÃ¥mma,RÃ­m,RÃ³m,RÃ³ma,Urbs,loma,luo ma shi,rm,rom,roma,romi,rwm,rwma,rym,ÅÃ­m,Î¡ÏÎ¼Î·,Ð Ð¸Ð¼,Ð Ð¸Ð¼Ñ,Ð ÑÐ¼,ÕÕ¼Õ¸Õ´,×¨×××,Ø±Ù,Ø±ÙÙ,Ø±ÙÙØ§,Ø±ÙÙ,ÜªÜÜ¡Ü,à¤°à¥à¤®,à¤°à¥à¤®à¤¾,à¹à¸£à¸¡,á ááá,á®á,ã­ã¼ã,ç½é©¬å¸,ë¡ë§,Roma", :latitude => "41.89474", :longitude => "12.4839").save
City.new(:country_id => "112", :name => "Rivoli", :aliases => "Rivoli,Rivoli Torinese,rivu~ori,Ð Ð¸Ð²Ð¾Ð»Ð¸,ãªã¼ã´ã©ãª,Rivoli", :latitude => "45.07155", :longitude => "7.52622").save
City.new(:country_id => "112", :name => "Rivalta di Torino", :aliases => "Arvauta,ArvÃ uta,Rivalta di Torino,ãªã´ã¡ã«ã¿ã»ãã£ã»ããªã¼ã,Rivalta di Torino", :latitude => "45.03404", :longitude => "7.51842").save
City.new(:country_id => "112", :name => "Rimini", :aliases => "Ariminum,Remin,Rimini,RÃ¨min,RÃ­mini,rimini,rymyny,Ð Ð¸Ð¼Ð¸Ð½Ð¸,Ð ÑÐ¼ÑÐ½Ñ,Ø±ÙÙÙÙÙ,ãªãã,Rimini", :latitude => "44.06333", :longitude => "12.58083").save
City.new(:country_id => "112", :name => "Rieti", :aliases => "Rieti,rieti,Ð Ð¸ÐµÑÐ¸,ãªã¨ã¼ãã£,Rieti", :latitude => "42.40723", :longitude => "12.85918").save
City.new(:country_id => "112", :name => "Riccione Marina", :aliases => "Riccione,Riccione", :latitude => "43.99942", :longitude => "12.65689").save
City.new(:country_id => "112", :name => "Rho", :aliases => "Rho,Ro,ro,Ð Ð¾,ã­ã¼,Rho", :latitude => "45.53087", :longitude => "9.04014").save
City.new(:country_id => "112", :name => "Reggio nell'Emilia", :aliases => "Redzho-Ehmilija,Reggio Emilia,Reggio nell'Emilia,Ð ÐµÐ´Ð¶Ð¾-Ð­Ð¼Ð¸Ð»Ð¸Ñ,Reggio nell'Emilia", :latitude => "44.69825", :longitude => "10.63125").save
City.new(:country_id => "112", :name => "Recanati", :aliases => "Recanati,Rekanati,Ð ÐµÐºÐ°Ð½Ð°ÑÐ¸,Recanati", :latitude => "43.40386", :longitude => "13.55978").save
City.new(:country_id => "112", :name => "Ravenna", :aliases => "Ravena,Ravenna,Ravenne,Rawenna,RÃ¡vena,la wen na,ravenna,ravu~en'na,rwwnh,Ð Ð°Ð²ÐµÐ½Ð°,Ð Ð°Ð²ÐµÐ½Ð½Ð°,×¨××× ×,à¤°à¤µà¥à¤¨à¥à¤¨à¤¾,ã©ã´ã§ã³ã,ææç´,Ravenna", :latitude => "44.4175", :longitude => "12.20111").save
City.new(:country_id => "112", :name => "Rapallo", :aliases => "Rapallo,raparro,Ð Ð°Ð¿Ð°Ð»Ð»Ð¾,ã©ããã­,Rapallo", :latitude => "44.3496", :longitude => "9.22796").save
City.new(:country_id => "112", :name => "Quarrata", :aliases => ",Quarrata", :latitude => "43.84985", :longitude => "10.98072").save
City.new(:country_id => "112", :name => "Qualiano", :aliases => "Qualiano,kuariano,ã¯ã¢ãªã¢ã¼ã,Qualiano", :latitude => "40.92261", :longitude => "14.15013").save
City.new(:country_id => "112", :name => "Putignano", :aliases => "Putignano,Putin'jano,ÐÑÑÐ¸Ð½ÑÑÐ½Ð¾,Putignano", :latitude => "40.85183", :longitude => "17.12129").save
City.new(:country_id => "112", :name => "Prato", :aliases => "Prato,Pratu,Pre,PrÃ¨,bratw,pu la tuo,purato,ÐÑÐ°ÑÐ¾,Ø¨Ø±Ø§ØªÙ,ãã©ã¼ã,æ®ææ,Prato", :latitude => "43.88425", :longitude => "11.09092").save
City.new(:country_id => "112", :name => "Pozzuoli", :aliases => "Pocuoli,Pouzzoles,Pozzuoli,Puteoli,Puzzuolo,pottsuori,ÐÐ¾ÑÑÐ¾Ð»Ð¸,ããããªãª,ããããªã¼ãª,Pozzuoli", :latitude => "40.83196", :longitude => "14.11001").save
City.new(:country_id => "112", :name => "Potenza", :aliases => "Oppido Lucano,Potentia,Potenza,Putenza,potentsu~a,ããã³ãã¡,Potenza", :latitude => "40.64432", :longitude => "15.80857").save
City.new(:country_id => "112", :name => "Porto Torres", :aliases => "Porto Torres,Porto-Torres,ÐÐ¾ÑÑÐ¾-Ð¢Ð¾ÑÑÐµÑ,Porto Torres", :latitude => "40.835", :longitude => "8.39722").save
City.new(:country_id => "112", :name => "Porto Sant'Elpidio", :aliases => "Porto Sant'Elpidio,Porto Sant'Elpidio a Mare,Porto Sant'Elpidio", :latitude => "43.25826", :longitude => "13.75829").save
City.new(:country_id => "112", :name => "Porto San Giorgio", :aliases => "Porto San Giorgio,Porto San Giorgio", :latitude => "43.18266", :longitude => "13.79339").save
City.new(:country_id => "112", :name => "Portogruaro", :aliases => "Portogruaro,Puart,porutoguruaro,ãã«ãã°ã«ã¢ã¼ã­,Portogruaro", :latitude => "45.77528", :longitude => "12.83861").save
City.new(:country_id => "112", :name => "Civitanova Marche", :aliases => "Civitanova Marche,Porto Civitanova,Civitanova Marche", :latitude => "43.30696", :longitude => "13.72058").save
City.new(:country_id => "112", :name => "Portici", :aliases => "Portichi,Portici,Puortece,bwrtysh,porutichi,ÐÐ¾ÑÑÐ¸ÑÐ¸,Ø¨ÙØ±ØªÙØ´,ãã«ãã£ã,Portici", :latitude => "40.81563", :longitude => "14.33716").save
City.new(:country_id => "112", :name => "Pordenone", :aliases => "Pordenon,Pordenone,Portus Naonis,porudenone,ÐÐ¾ÑÐ´ÐµÐ½Ð¾Ð½Ðµ,ãã«ããã¼ã,Pordenone", :latitude => "45.96389", :longitude => "12.6575").save
City.new(:country_id => "112", :name => "Pontedera", :aliases => "Pontedera,Pontedera", :latitude => "43.66164", :longitude => "10.63171").save
City.new(:country_id => "112", :name => "Pontecagnano", :aliases => "Pontekan'jano,ÐÐ¾Ð½ÑÐµÐºÐ°Ð½ÑÑÐ½Ð¾,Pontecagnano Faiano", :latitude => "40.64251", :longitude => "14.87345").save
City.new(:country_id => "112", :name => "Pontassieve", :aliases => "Pontass,Pontassieve,Pontassieve", :latitude => "43.77365", :longitude => "11.42823").save
City.new(:country_id => "112", :name => "Pompei", :aliases => "Pompei,Pompeya,Valle di Pompei,ÐÐ¾Ð¼Ð¿ÐµÐ¸,Pompei", :latitude => "40.74611", :longitude => "14.49734").save
City.new(:country_id => "112", :name => "Pomigliano d'Arco", :aliases => "Pomigliano,Pomigliano d'Arco,ãããªã¢ã¼ãã»ãã«ã³,Pomigliano d'Arco", :latitude => "40.90791", :longitude => "14.38623").save
City.new(:country_id => "112", :name => "Pomezia", :aliases => "Pomezia,pometsu~ia,ãã¡ã¼ãã£ã¢,Pomezia", :latitude => "41.66701", :longitude => "12.50518").save
City.new(:country_id => "112", :name => "Polignano a Mare", :aliases => "Polignano,Polignano a Mare,Polignano a Mare", :latitude => "40.99593", :longitude => "17.21589").save
City.new(:country_id => "112", :name => "Policoro", :aliases => "Policoro,Policoro", :latitude => "40.21151", :longitude => "16.67259").save
City.new(:country_id => "112", :name => "Poggiomarino", :aliases => "Poggiomarino,pojjomarino,ããã¸ã§ããªã¼ã,Poggiomarino", :latitude => "40.80311", :longitude => "14.53904").save
City.new(:country_id => "112", :name => "Poggibonsi", :aliases => "Podzhibonsi,Poggibonsi,pojjibonshi,ÐÐ¾Ð´Ð¶Ð¸Ð±Ð¾Ð½ÑÐ¸,ããã¸ãã³ã·,Poggibonsi", :latitude => "43.47244", :longitude => "11.14562").save
City.new(:country_id => "112", :name => "Pistoia", :aliases => "Pistoia,Pistoja,Pistojja,Pistola,Pistoria,PistÃ²ja,pisutoia,ÐÐ¸ÑÑÐ¾Ð¹Ñ,ãã¹ãã¤ã¢,Pistoia", :latitude => "43.92125", :longitude => "10.92361").save
City.new(:country_id => "112", :name => "Pisticci", :aliases => "Pesticium,Pisticci,Pisticci", :latitude => "40.39062", :longitude => "16.55679").save
City.new(:country_id => "112", :name => "Pisa", :aliases => "Pisa,Pisae,Pise,Piza,Pizo,PÃ­sa,bi sa,byza,pisa,pyzh,ÐÐ¸Ð·Ð°,×¤×××,Ø¨ÙØ²Ø§,à¤ªà¥à¤¸à¤¾,ããµ,æ¯è¨,Pisa", :latitude => "43.71553", :longitude => "10.39659").save
City.new(:country_id => "112", :name => "Piove di Sacco", :aliases => "Piove di Sacco,Piove di Sacco", :latitude => "45.2975", :longitude => "12.04278").save
City.new(:country_id => "112", :name => "Piossasco", :aliases => "Piossasch,Piossasco,Piossasco", :latitude => "44.99054", :longitude => "7.46372").save
City.new(:country_id => "112", :name => "Piombino", :aliases => "P'ombino,Piombino,pionbino,ÐÑÐ¾Ð¼Ð±Ð¸Ð½Ð¾,ããªã³ãã¼ã,Piombino", :latitude => "42.93482", :longitude => "10.52212").save
City.new(:country_id => "112", :name => "Pioltello", :aliases => "Pioltello,pioruterro,ããªã«ããã­,Pioltello", :latitude => "45.50502", :longitude => "9.33151").save
City.new(:country_id => "112", :name => "Pinocchio di Ancona", :aliases => "Pinocchio,Pinocchio di Ancona,Pinokkio-di-Ankona,ÐÐ¸Ð½Ð¾ÐºÐºÐ¸Ð¾-Ð´Ð¸-ÐÐ½ÐºÐ¾Ð½Ð°,Pinocchio di Ancona", :latitude => "43.58333", :longitude => "13.5").save
City.new(:country_id => "112", :name => "Pinerolo", :aliases => "Penarol,PeÃ±arol,Pignerol,Pinareul,Pinerolo,pineroro,ÐÐ¸Ð½ÐµÑÐ¾Ð»Ð¾,ããã­ã¼ã­,Pinerolo", :latitude => "44.88333", :longitude => "7.35").save
City.new(:country_id => "112", :name => "Pietrasanta", :aliases => "Pietrasanta,pietorasanta,ÐÐ¸ÐµÑÑÐ°ÑÐ°Ð½ÑÐ°,ãã¨ãã©ãµã³ã¿,Pietrasanta", :latitude => "43.95224", :longitude => "10.2248").save
City.new(:country_id => "112", :name => "Pianoro", :aliases => "Pianoro,Pianoro", :latitude => "44.39296", :longitude => "11.34231").save
City.new(:country_id => "112", :name => "Piacenza", :aliases => "P'jachehnca,P'jachenca,Piacenza,Piaseinsa,Piasensa,PiasÃ«insa,Placencia,Placentia,PlacÃªncia,Plaisance,Plasencia,pi ya qin cha,piachentsu~a,pyachnza,Ð'ÑÑÑÐ½ÑÐ°,ÐÑÑÑÐµÐ½ÑÐ°,Ù¾ÛØ§ÚÙØ²Ø§,ãã¢ãã§ã³ãã¡,ç®äºç´å¯,Piacenza", :latitude => "45.04676", :longitude => "9.69937").save
City.new(:country_id => "112", :name => "Pescia", :aliases => "Pescia,Pesha,Pesia,pesha,Î Î­ÏÎ¹Î±,ÐÐµÑÐ°,ãã¼ã·ã£,Pescia", :latitude => "43.89705", :longitude => "10.69041").save
City.new(:country_id => "112", :name => "Peschiera", :aliases => ",Peschiera Borromeo", :latitude => "45.4308", :longitude => "9.3087").save
City.new(:country_id => "112", :name => "Pescara", :aliases => "Pescara,Peskara,byskara,pesukara,ÐÐµÑÐºÐ°ÑÐ°,Ø¨ÙØ³ÙØ§Ø±Ø§,ãã¹ã«ã¼ã©,Pescara", :latitude => "42.46024", :longitude => "14.21021").save
City.new(:country_id => "112", :name => "Pesaro", :aliases => "Pesaro,Pesaru,Pezaro,Pisaurum,PÃ¨saru,pezaro,ÐÐµÐ·Ð°ÑÐ¾,ãã¼ã¶ã­,Pesaro", :latitude => "43.90357", :longitude => "12.89026").save
City.new(:country_id => "112", :name => "Perugia", :aliases => "Perosa,Perouse,Perudzha,Perugia,Perusa,Perusia,PÃ©rouse,byrwdja,pei lu jia,peruja,prwg'h,ÐÐµÑÑÐ´Ð¶Ð°,ÐÐµÑÑÑÐ°,×¤×¨××'×,Ø¨ÙØ±ÙØ¯Ø¬Ø§,ãã«ã¼ã¸ã£,ä½©é²è´¾,Perugia", :latitude => "43.09674", :longitude => "12.38286").save
City.new(:country_id => "112", :name => "Pergine Valsugana", :aliases => "Pergine,Pergine Valsugana,Perigine Valsugana,ãã«ã¸ã¼ãã»ã´ã¡ã«ã¹ã¬ã¼ã,Pergine Valsugana", :latitude => "46.065", :longitude => "11.23798").save
City.new(:country_id => "112", :name => "Pavullo nel Frignano", :aliases => "Paullo nel Frignano,Pavullo,Pavullo nel Frignano,pavulo nel frinjano,ÐÐ°Ð²ÑÐ»Ð¾ Ð½ÐµÐ» Ð¤ÑÐ¸Ð½ÑÐ½Ð¾,ãã´ãã­ã»ãã«ã»ããªãã£ã¼ã,Pavullo nel Frignano", :latitude => "44.33146", :longitude => "10.835").save
City.new(:country_id => "112", :name => "Pavia", :aliases => "Papia,Pavia,Pavie,Pavija,Pavio,PavÃ¬a,PavÃ­a,Pawia,Ticinum,pa wei ya,pavu~ia,ÐÐ°Ð²Ð¸Ñ,ãã´ã£ã¢,å¸ç¶­äº,Pavia", :latitude => "45.18446", :longitude => "9.16145").save
City.new(:country_id => "112", :name => "Parma", :aliases => "Parma,Parme,Perma,PÃ¨rma,barma,parma,paruma,ÐÐ°ÑÐ¼Ð°,×¤××¨××,Ø¨Ø§Ø±ÙØ§,Ù¾Ø§Ø±ÙØ§,ãã«ã,Parma", :latitude => "44.80266", :longitude => "10.32898").save
City.new(:country_id => "112", :name => "Parabiago", :aliases => "Parabiago,parabiago,ãã©ãã¢ã¼ã´,Parabiago", :latitude => "45.55497", :longitude => "8.94564").save
City.new(:country_id => "112", :name => "Palo del Colle", :aliases => "Palo del Colle,Palo-del'-Kolle,ÐÐ°Ð»Ð¾-Ð´ÐµÐ»Ñ-ÐÐ¾Ð»Ð»Ðµ,Palo del Colle", :latitude => "41.05753", :longitude => "16.70078").save
City.new(:country_id => "112", :name => "Pallazzolo sull'Oglio", :aliases => "Palazzolo,Palazzolo sull'Oglio,Palazzolo sull'Oglio", :latitude => "45.60368", :longitude => "9.89716").save
City.new(:country_id => "112", :name => "Palestrina", :aliases => "Palestrina,Praeneste,paresutorina,ÐÐ°Ð»ÐµÑÑÑÐ¸Ð½Ð°,ãã¬ã¹ããªã¼ã,Palestrina", :latitude => "41.83552", :longitude => "12.88899").save
City.new(:country_id => "112", :name => "Palagiano", :aliases => "Palagiano,Palagiano", :latitude => "40.57889", :longitude => "17.03861").save
City.new(:country_id => "112", :name => "Pagani", :aliases => "Pagani,pagani,ãã¬ã¼ã,Pagani", :latitude => "40.75151", :longitude => "14.61334").save
City.new(:country_id => "112", :name => "Paese", :aliases => "Paese,Paese", :latitude => "45.67417", :longitude => "12.16389").save
City.new(:country_id => "112", :name => "Padova", :aliases => "Padoa,Padoue,Padova,Padovo,Padua,Paduja,Padwa,Patavium,PÃ dua,PÃ¡dua,badwfa,pa duo wa,padoba,padovu~a,ÐÐ°Ð´Ð¾Ð²Ð°,ÐÐ°Ð´ÑÐ°,ÐÐ°Ð´ÑÑ,×¤×××××,Ø¨Ø§Ø¯ÙÙØ§,áááá£á,ããã´ã¡,å¸å¤ç¦,íëë°,Padova", :latitude => "45.41519", :longitude => "11.88181").save
City.new(:country_id => "112", :name => "Paderno Dugnano", :aliases => "Paderno Dugnano,ããã«ãã»ãã¥ãã£ã¼ã,Paderno Dugnano", :latitude => "45.56899", :longitude => "9.16483").save
City.new(:country_id => "112", :name => "Ottaviano", :aliases => ",Ottaviano", :latitude => "40.84981", :longitude => "14.49014").save
City.new(:country_id => "112", :name => "Ostuni", :aliases => "Ostuni,ÐÑÑÑÐ½Ð¸,Ostuni", :latitude => "40.72763", :longitude => "17.57641").save
City.new(:country_id => "112", :name => "Osimo", :aliases => "Osimo,ojimo,ÐÑÐ¸Ð¼Ð¾,ãªã¼ã¸ã¢,Osimo", :latitude => "43.48276", :longitude => "13.48748").save
City.new(:country_id => "112", :name => "Orvieto", :aliases => "Orvieto,oruvu~ieto,ÐÑÐ²Ð¸ÐµÑÐ¾,ãªã«ã´ã£ã¨ã¼ã,Orvieto", :latitude => "42.71953", :longitude => "12.11156").save
City.new(:country_id => "112", :name => "Ortona", :aliases => "Ortona,Ortona a Mare,ÐÑÑÐ¾Ð½Ð°,Ortona", :latitude => "42.34964", :longitude => "14.40391").save
City.new(:country_id => "112", :name => "Orta Nova", :aliases => "Orta Nova,Orta Nova", :latitude => "41.32993", :longitude => "15.71066").save
City.new(:country_id => "112", :name => "Oria", :aliases => ",Oria", :latitude => "40.49733", :longitude => "17.64131").save
City.new(:country_id => "112", :name => "Orbassano", :aliases => "Orbassan,Orbassano,orubassano,ÐÑÐ±Ð°ÑÑÐ°Ð½Ð¾,ãªã«ãããµã¼ã,Orbassano", :latitude => "45.00384", :longitude => "7.53992").save
City.new(:country_id => "112", :name => "Omegna", :aliases => "Omegna,omenja,omenya,ÐÐ¼ÐµÐ½Ñ,ãªã¡ã¼ãã£,Omegna", :latitude => "45.87977", :longitude => "8.40802").save
City.new(:country_id => "112", :name => "Olbia", :aliases => "Ol'bija,Olbia,Tarranoa,TarranÃ³a,Terranoa,TerranÃ²a,ÐÐ»ÑÐ±Ð¸Ñ,Olbia", :latitude => "40.92137", :longitude => "9.48563").save
City.new(:country_id => "112", :name => "Oderzo", :aliases => "Oderzo,Oderzo", :latitude => "45.78", :longitude => "12.48806").save
City.new(:country_id => "112", :name => "Nuoro", :aliases => "Nugoro,Nuoro,NÃ¹goro,nuoro,ÐÑÐ¾ÑÐ¾,ããªã­,Nuoro", :latitude => "40.32106", :longitude => "9.32973").save
City.new(:country_id => "112", :name => "Novi Ligure", :aliases => "Novi Ligure,Novi-Ligure,ÐÐ¾Ð²Ð¸-ÐÐ¸Ð³ÑÑÐµ,ãã¼ã´ã£ã»ãªã¼ã°ã¬,Novi Ligure", :latitude => "44.76085", :longitude => "8.78955").save
City.new(:country_id => "112", :name => "Novate Milanese", :aliases => "Novate Milanese,ãã´ã¡ã¼ãã»ãã©ãã¼ã¼,Novate Milanese", :latitude => "45.53097", :longitude => "9.13474").save
City.new(:country_id => "112", :name => "Novara", :aliases => "Novara,Novare,Novaria,Nuara,Nuvara,novu~ara,ÐÐ¾Ð²Ð°ÑÐ°,ãã´ã¡ã¼ã©,Novara", :latitude => "45.44056", :longitude => "8.61684").save
City.new(:country_id => "112", :name => "Nova Milanese", :aliases => "Nova Milanese,ãã¼ã´ã¡ã»ãã©ãã¼ã¼,Nova Milanese", :latitude => "45.59037", :longitude => "9.19954").save
City.new(:country_id => "112", :name => "Nola", :aliases => "Nola,nora,ãã¼ã©,Nola", :latitude => "40.92201", :longitude => "14.53294").save
City.new(:country_id => "112", :name => "Noicattaro", :aliases => "Noicattaro,Noicattaro", :latitude => "41.03383", :longitude => "16.98959").save
City.new(:country_id => "112", :name => "Noci", :aliases => "Noci,nochi,ãã¼ã,Noci", :latitude => "40.79073", :longitude => "17.1317").save
City.new(:country_id => "112", :name => "Nocera Superiore", :aliases => "Nocera Superiore,Nocera Superiore", :latitude => "40.74211", :longitude => "14.67294").save
City.new(:country_id => "112", :name => "Nocera Inferiore", :aliases => "Nocera,Nocera Inferiore,ããã§ã¼ã©ã»ã¤ã³ãã§ãªãªã¼ã¬,Nocera Inferiore", :latitude => "40.75221", :longitude => "14.64014").save
City.new(:country_id => "112", :name => "Nichelino", :aliases => "El Niclin,Nichelino,Nikelino,nikerino,Ãl Niclin,ÐÐ¸ÐºÐµÐ»Ð¸Ð½Ð¾,ãã±ãªã¼ã,Nichelino", :latitude => "44.99404", :longitude => "7.64182").save
City.new(:country_id => "112", :name => "Nettuno", :aliases => "Nettuno,netto~uno,ãããã¥ã¼ã,Nettuno", :latitude => "41.45907", :longitude => "12.66037").save
City.new(:country_id => "112", :name => "Nerviano", :aliases => "Nerviano,neruvu~iano,ãã«ã´ã£ã¢ã¼ã,Nerviano", :latitude => "45.55667", :longitude => "8.97774").save
City.new(:country_id => "112", :name => "Negrar", :aliases => "Negar,Negrar,Negrar", :latitude => "45.52879", :longitude => "10.93798").save
City.new(:country_id => "112", :name => "Narni", :aliases => "Narni,naruni,ãã«ã,Narni", :latitude => "42.51713", :longitude => "12.52307").save
City.new(:country_id => "112", :name => "Nardo", :aliases => "Nardo,NardÃ²,narudo,ãã«ã,NardÃ²", :latitude => "40.17512", :longitude => "18.02972").save
City.new(:country_id => "112", :name => "Napoli", :aliases => "Napapopolopi,Napels,Naples,Napoles,Napoles - Napoli,Napoli,Napolo,Napols,Napoly,Napul,Napule,Napuli,Napulj,NapÃ³lÃ­,Neapel,Neapelj,Neapol,Neapol',Neapole,Neapolis,Noapels,NÃ pols,NÃ puli,NÃ¡poles,NÃ¡poles - Napoli,NÃ¡pols,NÃ¡poly,na bu lei si,nabwly,napl,napoli,napolli,napori,ÐÐ°Ð¿ÑÑ,ÐÐµÐ°Ð¿Ð¾Ð»,ÐÐµÐ°Ð¿Ð¾Ð»Ñ,ÕÕ¥Õ¡ÕºÕ¸Õ¬,× ××¤×××,ÙØ§Ø¨ÙÙÙ,ÙØ§Ù¾Ù,à¤¨à¤¾à¤ªà¥à¤²à¤¿,ááááááá,ãããª,é£ä¸åæ¯,ëí´ë¦¬,Napoli", :latitude => "40.83333", :longitude => "14.25").save
City.new(:country_id => "112", :name => "Mugnano di Napoli", :aliases => "Mugnano 'e Napule,Mugnano di Napoli,ã ãã£ã¼ãã»ãã£ã»ãã¼ããª,Mugnano di Napoli", :latitude => "40.91131", :longitude => "14.20513").save
City.new(:country_id => "112", :name => "Muggio", :aliases => "Muggio,MuggiÃ²,mujjo,ã ãã¸ã§,MuggiÃ²", :latitude => "45.58837", :longitude => "9.22625").save
City.new(:country_id => "112", :name => "Mottola", :aliases => "Mottola,Mottola", :latitude => "40.63528", :longitude => "17.03528").save
City.new(:country_id => "112", :name => "Monza", :aliases => "Modicia,Monca,Monsa,Monza,Munscia,meng zha,mnza,montsu~a,mwnzh,ÐÐ¾Ð½ÑÐ°,××× ×¦×,ÙÙØ²Ø§,ã¢ã³ãã¡,èæ,Monza", :latitude => "45.58248", :longitude => "9.27485").save
City.new(:country_id => "112", :name => "Montichiari", :aliases => "Montichiari,montikiari,ã¢ã³ãã£ã­ã¢ã¼ãª,Montichiari", :latitude => "45.41518", :longitude => "10.39068").save
City.new(:country_id => "112", :name => "Montevarchi", :aliases => "Montevarchi,Montevarki,ÐÐ¾Ð½ÑÐµÐ²Ð°ÑÐºÐ¸,Montevarchi", :latitude => "43.52765", :longitude => "11.56893").save
City.new(:country_id => "112", :name => "Montesilvano", :aliases => "Montesilvano,Montezil'vano,ÐÐ¾Ð½ÑÐµÐ·Ð¸Ð»ÑÐ²Ð°Ð½Ð¾,Montesilvano", :latitude => "42.50394", :longitude => "14.138").save
City.new(:country_id => "112", :name => "Monterotondo", :aliases => "Crustumerium,Monterotondo,monterotondo,ÐÐ¾Ð½ÑÐµÑÐ¾ÑÐ¾Ð½Ð´Ð¾,ã¢ã³ãã­ãã³ã,Monterotondo", :latitude => "42.05252", :longitude => "12.61868").save
City.new(:country_id => "112", :name => "Montemurlo", :aliases => "Montemurlo,montemururo,ã¢ã³ãã ã«ã­,Montemurlo", :latitude => "43.92165", :longitude => "11.03112").save
City.new(:country_id => "112", :name => "Montecchio Maggiore", :aliases => "Montecchio Maggiore,Montecchio Maggiore", :latitude => "45.50369", :longitude => "11.412").save
City.new(:country_id => "112", :name => "Montecatini Terme", :aliases => "Montecatini Terme,Montecatini-Terme,ã¢ã³ãã«ãã£ã¼ãã»ãã«ã¡,Montecatini-Terme", :latitude => "43.88355", :longitude => "10.77361").save
City.new(:country_id => "112", :name => "Montebelluna", :aliases => "Montebelluna,ÐÐ¾Ð½ÑÐµÐ±ÐµÐ»Ð»ÑÐ½Ð°,Montebelluna", :latitude => "45.77528", :longitude => "12.03889").save
City.new(:country_id => "112", :name => "Monsummano", :aliases => "Monsumanno,Monsumanno Terme,Monsummano Terme,Monsummano Terme", :latitude => "43.87035", :longitude => "10.81231").save
City.new(:country_id => "112", :name => "Monselice", :aliases => "Monselice,Monselice", :latitude => "45.24239", :longitude => "11.74901").save
City.new(:country_id => "112", :name => "Monopoli", :aliases => "Monopoli,monopori,ÐÐ¾Ð½Ð¾Ð¿Ð¾Ð»Ð¸,ã¢ãã¼ããª,Monopoli", :latitude => "40.95593", :longitude => "17.2896").save
City.new(:country_id => "112", :name => "Monfalcone", :aliases => "Monfal'kone,Monfalcon,Monfalcone,monfarukone,ÐÐ¾Ð½ÑÐ°Ð»ÑÐºÐ¾Ð½Ðµ,ã¢ã³ãã¡ã«ã³ã¼ã,Monfalcone", :latitude => "45.80722", :longitude => "13.53417").save
City.new(:country_id => "112", :name => "Mondragone", :aliases => "Mondragone,Mundragone,Mondragone", :latitude => "41.11411", :longitude => "13.89352").save
City.new(:country_id => "112", :name => "Mondovi", :aliases => "El Mondvi,Mondovi,MondovÃ¬,mondovu~i,Ãl MondvÃ¬,ÐÐ¾Ð½Ð´Ð¾Ð²Ð¸,ã¢ã³ãã´ã£,MondovÃ¬", :latitude => "44.39603", :longitude => "7.81764").save
City.new(:country_id => "112", :name => "Moncalieri", :aliases => "Moncale,Moncalieri,MoncalÃ©,monkarieri,ã¢ã³ã«ãªã¨ã¼ãª,Moncalieri", :latitude => "44.99625", :longitude => "7.69032").save
City.new(:country_id => "112", :name => "Molfetta", :aliases => "Mol'fetta,Molfetta,ÐÐ¾Ð»ÑÑÐµÑÑÐ°,Molfetta", :latitude => "41.20023", :longitude => "16.59748").save
City.new(:country_id => "112", :name => "Mola di Bari", :aliases => "Mola di Bari,Mola di Bari", :latitude => "41.06094", :longitude => "17.08729").save
City.new(:country_id => "112", :name => "Mogliano Veneto", :aliases => "Mogliano,Mogliano Veneto,ã¢ãªã¢ã¼ãã»ã´ã§ã¼ãã,Mogliano Veneto", :latitude => "45.565", :longitude => "12.235").save
City.new(:country_id => "112", :name => "Modugno", :aliases => "Modugno,Modun'o,ÐÐ¾Ð´ÑÐ½ÑÐ¾,Modugno", :latitude => "41.09743", :longitude => "16.77798").save
City.new(:country_id => "112", :name => "Modena", :aliases => "Modena,Modene,Modna,ModÃ¨ne,Mutina,MÃ²dena,MÃ²dna,MÃ³dena,modena,mwdyna,ÐÐ¾Ð´ÐµÐ½Ð°,ÙÙØ¯ÙÙØ§,ã¢ãã,Modena", :latitude => "44.64783", :longitude => "10.92539").save
City.new(:country_id => "112", :name => "Mirano", :aliases => "Mirano,mirano,ÐÐ¸ÑÐ°Ð½Ð¾,ãã©ã¼ã,Mirano", :latitude => "45.49444", :longitude => "12.10472").save
City.new(:country_id => "112", :name => "Mirandola", :aliases => "Mirandola,ÐÐ¸ÑÐ°Ð½Ð´Ð¾Ð»Ð°,Mirandola", :latitude => "44.88677", :longitude => "11.0662").save
City.new(:country_id => "112", :name => "Mira", :aliases => "Mira,mira,ÐÐ¸ÑÐ°,ãã¼ã©,Mira", :latitude => "45.43", :longitude => "12.11972").save
City.new(:country_id => "112", :name => "Minturno", :aliases => "Minturno,minto~uruno,ãã³ãã¥ã«ã,Minturno", :latitude => "41.25761", :longitude => "13.72371").save
City.new(:country_id => "112", :name => "Milano", :aliases => "Lungsod ng Milano,MIL,Mailand,Mediolan,Mediolanum,Mila,Milaan,Milan,Milana,Milanas,Milano,Milanu,Milao,MilÃ ,MilÃ¡n,MilÃ¡no,MilÃ¡nÃ³,MilÃ£o,MilÄna,MÃ­lanÃ³,mi lan,milan,milani,millano,mirano,mylan,mylanw,ÐÐ¸Ð»Ð°Ð½,ÐÐ¸Ð»Ð°Ð½Ð¾,ÐÑÐ»Ð°Ð½,××××× ×,ÙÙÙØ§Ù,ÙÙÙØ§ÙÙ,à®®à®¿à®²à®©à¯,à¸¡à¸´à¸¥à¸²à¸,áááááá,ãã©ã,ç±³è­,ë°ë¼ë¸,Milano", :latitude => "45.46427", :longitude => "9.18951").save
City.new(:country_id => "112", :name => "Mestre", :aliases => "Mestre,ÐÐµÑÑÑÐµ,Mestre", :latitude => "45.49028", :longitude => "12.2425").save
City.new(:country_id => "112", :name => "Mesagne", :aliases => "Mesagne,Mesagne", :latitude => "40.55883", :longitude => "17.80831").save
City.new(:country_id => "112", :name => "Mercato San Severino", :aliases => "Mercato San Severino,San Severino Rota,Mercato San Severino", :latitude => "40.78121", :longitude => "14.75694").save
City.new(:country_id => "112", :name => "Merano", :aliases => "Meran,Merano,Merona,merano,ÐÐµÑÐ°Ð½Ð¾,ã¡ã©ã¼ã,Merano", :latitude => "46.66817", :longitude => "11.15953").save
City.new(:country_id => "112", :name => "Mentana", :aliases => "Mentana,mentana,ã¡ã³ã¿ã¼ã,Mentana", :latitude => "42.03492", :longitude => "12.64238").save
City.new(:country_id => "112", :name => "Melzo", :aliases => "Melzo,merutsu~o,ã¡ã«ãã©,Melzo", :latitude => "45.50127", :longitude => "9.42525").save
City.new(:country_id => "112", :name => "Melito di Napoli", :aliases => "Melito 'e Napule,Melito di Napoli,ã¡ãªã¼ãã»ãã£ã»ãã¼ããª,Melito di Napoli", :latitude => "40.92051", :longitude => "14.23003").save
City.new(:country_id => "112", :name => "Melfi", :aliases => "Melfi,Melphi,ÎÎ­Î»ÏÎ¹,Melfi", :latitude => "40.99652", :longitude => "15.65136").save
City.new(:country_id => "112", :name => "Melegnano", :aliases => "Marignano,Melegnano,merenyano,ã¡ã¬ãã£ã¼ã,Melegnano", :latitude => "45.35877", :longitude => "9.32395").save
City.new(:country_id => "112", :name => "Meda", :aliases => "Med,Meda,meda,ÐÐµÐ´,ã¡ã¼ã,Meda", :latitude => "45.65818", :longitude => "9.15974").save
City.new(:country_id => "112", :name => "Matera", :aliases => "Matera,Materia,matera,ÐÐ°ÑÐµÑÐ°,ããã¼ã©,Matera", :latitude => "40.66852", :longitude => "16.60158").save
City.new(:country_id => "112", :name => "Massarosa", :aliases => "Massarosa,Massarose,ÐÐ°ÑÑÐ°ÑÐ¾ÑÐµ,Massarosa", :latitude => "43.86764", :longitude => "10.3397").save
City.new(:country_id => "112", :name => "Massafra", :aliases => "Massafra,Massafra", :latitude => "40.59194", :longitude => "17.11528").save
City.new(:country_id => "112", :name => "Massa", :aliases => "Massa,massa,ÐÐ°ÑÑÐ°,ãããµ,Massa", :latitude => "44.02204", :longitude => "10.11409").save
City.new(:country_id => "112", :name => "Martina Franca", :aliases => "Martina Franca,Martina Franca", :latitude => "40.70313", :longitude => "17.3339").save
City.new(:country_id => "112", :name => "Martellago", :aliases => "Martellago,maruterrago,ãã«ããã©ã¼ã´,Martellago", :latitude => "45.5475", :longitude => "12.15").save
City.new(:country_id => "112", :name => "Marsciano", :aliases => "Marsciano,Marsciano", :latitude => "42.90594", :longitude => "12.33586").save
City.new(:country_id => "112", :name => "Marino", :aliases => "Castromenio,Marino,marino,ÐÐ°ÑÐ¸Ð½Ð¾,ããªã¼ã,Marino", :latitude => "41.76242", :longitude => "12.64438").save
City.new(:country_id => "112", :name => "Marina di Carrara", :aliases => ",Marina di Carrara", :latitude => "44.03837", :longitude => "10.04142").save
City.new(:country_id => "112", :name => "Marigliano", :aliases => "Marigliano,Maril'jano,maririano,ÐÐ°ÑÐ¸Ð»ÑÑÐ½Ð¾,ããªãªã¢ã¼ã,Marigliano", :latitude => "40.92631", :longitude => "14.45813").save
City.new(:country_id => "112", :name => "Mariano Comense", :aliases => "Marian,Mariano,Mariano Comense,MariÃ n,Mariano Comense", :latitude => "45.69208", :longitude => "9.17974").save
City.new(:country_id => "112", :name => "Marcianise", :aliases => "Marchanize,Marcianise,ÐÐ°ÑÑÐ°Ð½Ð¸Ð·Ðµ,Marcianise", :latitude => "41.03221", :longitude => "14.30093").save
City.new(:country_id => "112", :name => "Marano di Napoli", :aliases => "Marano,Marano 'e Napule,Marano di Napoli,ãã©ã¼ãã»ãã£ã»ãã¼ããª,Marano di Napoli", :latitude => "40.89761", :longitude => "14.19053").save
City.new(:country_id => "112", :name => "Maranello", :aliases => "Maranello,Maranelo,maranerro,ÐÐ°ÑÐ°Ð½ÐµÐ»Ð»Ð¾,ÐÐ°ÑÐ°Ð½ÐµÐ»Ð¾,ãã©ããã­,Maranello", :latitude => "44.52476", :longitude => "10.8655").save
City.new(:country_id => "112", :name => "Mantova", :aliases => "Mantoue,Mantova,Mantua,Mantuja,ÐÐ°Ð½ÑÑÑ,Mantova", :latitude => "45.16031", :longitude => "10.79784").save
City.new(:country_id => "112", :name => "Manfredonia", :aliases => "Manfredonia,Manfredonija,ManfredÃ²nia,manfuredonia,ÐÐ°Ð½ÑÑÐµÐ´Ð¾Ð½Ð¸Ñ,ãã³ãã¬ãã¼ãã¢,Manfredonia", :latitude => "41.62594", :longitude => "15.90936").save
City.new(:country_id => "112", :name => "Manduria", :aliases => "Manduria,Mandurija,ÐÐ°Ð½Ð´ÑÑÐ¸Ñ,Manduria", :latitude => "40.40182", :longitude => "17.63351").save
City.new(:country_id => "112", :name => "Malnate", :aliases => "Malnate,marunate,ãã«ãã¼ã,Malnate", :latitude => "45.79078", :longitude => "8.88193").save
City.new(:country_id => "112", :name => "Maglie", :aliases => "Maddhie,Maglie,marie,ããªã¨,Maglie", :latitude => "40.11842", :longitude => "18.29893").save
City.new(:country_id => "112", :name => "Magenta", :aliases => "Castra Maxentia,Magenta,ma zhen ta,majenta,ãã¸ã§ã³ã¿,é©¬çå¡,Magenta", :latitude => "45.46457", :longitude => "8.88264").save
City.new(:country_id => "112", :name => "Maddaloni", :aliases => "Maddaloni,ÐÐ°Ð´Ð´Ð°Ð»Ð¾Ð½Ð¸,Maddaloni", :latitude => "41.04001", :longitude => "14.37683").save
City.new(:country_id => "112", :name => "Macerata", :aliases => "Macerata,Macherata,macherata,mz'rth,ÐÐ°ÑÐµÑÐ°ÑÐ°,××¦'×¨××,ããã§ã©ã¼ã¿,Macerata", :latitude => "43.29816", :longitude => "13.44108").save
City.new(:country_id => "112", :name => "Lugo", :aliases => "Lugo,rugo,ÐÑÐ³Ð¾,ã«ã¼ã´,Lugo", :latitude => "44.42707", :longitude => "11.90763").save
City.new(:country_id => "112", :name => "Lucera", :aliases => "Lucera,Luchera,lutseriumi,ÐÑÑÐµÑÐ°,áá£áªáá áá£áá,Lucera", :latitude => "41.50823", :longitude => "15.33505").save
City.new(:country_id => "112", :name => "Lucca", :aliases => "Locca,Luca,Lucca,Lucques,Luka,Lukka,lu ka,rukka,ÐÑÐºÐ°,ÐÑÐºÐºÐ°,ã«ãã«,å¢å¡,Lucca", :latitude => "43.84357", :longitude => "10.50585").save
City.new(:country_id => "112", :name => "Lodi", :aliases => "Laus Pompeia,Lod,Lodi,LÃ²d,rodi,ÐÐ¾Ð´Ð¸,ã­ã¼ãã£,Lodi", :latitude => "45.31357", :longitude => "9.50286").save
City.new(:country_id => "112", :name => "Livorno", :aliases => "Labro,Leghorn,Levuorno,Liborno,Liorna,Livorn,Livornas,Livorno,Livornu,Livourne,lybwrnw,lyfwrnw,rivu~oruno,ÎÎ¹Î²ÏÏÎ½Î¿,ÐÐ¸Ð²Ð¾ÑÐ½Ð¾,×××××¨× ×,ÙÙÙÙØ±ÙÙ,ãªã´ã©ã«ã,Livorno", :latitude => "43.54264", :longitude => "10.316").save
City.new(:country_id => "112", :name => "Lissone", :aliases => "Lissone,Lissun,LissÃºn,rissone,ÐÐ¸ÑÑÐ¾Ð½Ðµ,ãªãã½ã¼ã,Lissone", :latitude => "45.61236", :longitude => "9.23985").save
City.new(:country_id => "112", :name => "Limbiate", :aliases => "Limb'jate,Limbiate,rinbiate,ÐÐ¸Ð¼Ð±ÑÑÑÐµ,ãªã³ãã¢ã¼ã,Limbiate", :latitude => "45.59677", :longitude => "9.12904").save
City.new(:country_id => "112", :name => "Lido di Roma", :aliases => "Lido di Ostia,Lido-di-Ostija,Lido-di-Roma,Ostia Lido,ÐÐ¸Ð´Ð¾-Ð´Ð¸-ÐÑÑÐ¸Ñ,ÐÐ¸Ð´Ð¾-Ð´Ð¸-Ð Ð¾Ð¼Ð°,Lido di Roma", :latitude => "41.73212", :longitude => "12.27654").save
City.new(:country_id => "112", :name => "Legnano", :aliases => "Legnano,Len'jano,renyano,ÐÐµÐ½ÑÑÐ½Ð¾,ã¬ãã£ã¼ã,Legnano", :latitude => "45.59597", :longitude => "8.90784").save
City.new(:country_id => "112", :name => "Legnago", :aliases => "Legnago,Len'jago,ÐÐµÐ½ÑÑÐ³Ð¾,Legnago", :latitude => "45.18318", :longitude => "11.3091").save
City.new(:country_id => "112", :name => "Lecco", :aliases => "Lecco,Lech,Lekko,Leucum,rekko,ÐÐµÐºÐºÐ¾,ã¬ãã³,Lecco", :latitude => "45.85317", :longitude => "9.39005").save
City.new(:country_id => "112", :name => "Lecce", :aliases => "Lecce,Lecci,Lece,Lechche,Leche,Luppiu,Rudiae,lai qie,retche,ÐÐµÑÐµ,ÐÐµÑÑÐµ,ÐÐµÑÐµ,ã¬ããã§,èå,Lecce", :latitude => "40.35703", :longitude => "18.17202").save
City.new(:country_id => "112", :name => "Latina", :aliases => "Latina,Littoria,ratina,ÐÐ°ÑÐ¸Ð½Ð°,ã©ãã£ã¼ã,Latina", :latitude => "41.46614", :longitude => "12.9043").save
City.new(:country_id => "112", :name => "Latiano", :aliases => "Latiano,Latiano", :latitude => "40.55293", :longitude => "17.72051").save
City.new(:country_id => "112", :name => "Lastra a Signa", :aliases => "Lastra a Signa,Lastra a Signa", :latitude => "43.77135", :longitude => "11.10282").save
City.new(:country_id => "112", :name => "La Spezia", :aliases => "La Specija,La Spezia,Specija,Spedia,Speza,Spezia,ÐÐ° Ð¡Ð¿ÐµÑÐ¸ÑÐ°,Ð¡Ð¿ÐµÑÐ¸Ñ,ã©ã»ã¹ããã£ã¢,La Spezia", :latitude => "44.11054", :longitude => "9.84339").save
City.new(:country_id => "112", :name => "L'Aquila", :aliases => "Aquila,Aquila degli Abruzzi,L'Akvila,L'Aquila,LâAquila,rakuira,Ãquila,ÐâÐÐºÐ²Ð¸Ð»Ð°,ã©ã¯ã¤ã©,LâAquila", :latitude => "42.35055", :longitude => "13.39954").save
City.new(:country_id => "112", :name => "Lanciano", :aliases => "Lanchano,Lanciano,ÐÐ°Ð½ÑÐ°Ð½Ð¾,Lanciano", :latitude => "42.21674", :longitude => "14.38822").save
City.new(:country_id => "112", :name => "Laives - Leifers", :aliases => "Laives,Leifers,raivu~esu,ã©ã¤ã´ã§ã¹,Laives - Leifers", :latitude => "46.42679", :longitude => "11.33841").save
City.new(:country_id => "112", :name => "Lainate", :aliases => "Lainate,rainate,ã©ã¤ãã¼ã,Lainate", :latitude => "45.57176", :longitude => "9.02681").save
City.new(:country_id => "112", :name => "Ladispoli", :aliases => "Ladispoli,radisupori,ÐÐ°Ð´Ð¸ÑÐ¿Ð¾Ð»Ð¸,ã©ãã£ã¹ããª,Ladispoli", :latitude => "41.95372", :longitude => "12.07347").save
City.new(:country_id => "112", :name => "Ivrea", :aliases => "Eporedia,Ivrea,Ivree,Ivreja,IvrÃ¨ja,IvrÃ©e,ivurea,ÐÐ²ÑÐµÐ°,ã¤ã´ã¬ã¼ã¢,Ivrea", :latitude => "45.45806", :longitude => "7.87192").save
City.new(:country_id => "112", :name => "Isernia", :aliases => "Isernia,IsÃ©rnia,Izernija,izerunia,ÐÐ·ÐµÑÐ½Ð¸Ñ,ã¤ã¼ã«ãã¢,Isernia", :latitude => "41.60022", :longitude => "14.23822").save
City.new(:country_id => "112", :name => "Ischia Porto", :aliases => ",Ischia Porto", :latitude => "40.73333", :longitude => "13.95").save
City.new(:country_id => "112", :name => "Ischia", :aliases => "Bagni,Bagno,Bagno d'Ischia,Iscla,Isk'ja,Porto d'Ischia,Villa Bagni,ÐÑÐºÑÑ,Ischia", :latitude => "40.73523", :longitude => "13.94813").save
City.new(:country_id => "112", :name => "Imperia", :aliases => "Imperia,Imperija,ImpÃ©ria,inperia,ÐÐ¼Ð¿ÐµÑÐ¸Ñ,ã¤ã³ããªã¢,Imperia", :latitude => "43.8875", :longitude => "8.03083").save
City.new(:country_id => "112", :name => "Imola", :aliases => "Forum Cornelii,Imola,Iommla,imora,Ãmola,ÐÐ¼Ð¾Ð»Ð°,ã¤ã¼ã¢ã©,Imola", :latitude => "44.35227", :longitude => "11.71582").save
City.new(:country_id => "112", :name => "Iesolo", :aliases => "Capazuccherina,Cavazuccherina,Jesolo,Jezolo,Lido di Ezolo,Lido di Jesolo,i~ezoro,ÐÐµÐ·Ð¾Ð»Ð¾,ÐÐ¸Ð´Ð¾ Ð´Ð¸ ÐÐ·Ð¾Ð»Ð¾,ã¤ã§ã¼ã¾ã­,Iesolo", :latitude => "45.53311", :longitude => "12.64475").save
City.new(:country_id => "112", :name => "Jesi", :aliases => "Aesis,Dzhezi,Jesi,Jezi,i~eji,ÐÐ¶ÐµÐ·Ð¸,ÐÐµÐ·Ð¸,ã¤ã§ã¼ã¸,Jesi", :latitude => "43.52142", :longitude => "13.24368").save
City.new(:country_id => "112", :name => "Guidonia", :aliases => ",Guidonia", :latitude => "42.01667", :longitude => "12.75").save
City.new(:country_id => "112", :name => "Gubbio", :aliases => "Gubbio,gubbio,gwbyw,ÐÑÐ±Ð±Ð¸Ð¾,×××××,ã°ãããª,Gubbio", :latitude => "43.35445", :longitude => "12.57246").save
City.new(:country_id => "112", :name => "Gualdo Tadino", :aliases => "Gualdo Tadino,Gualdo Tadino", :latitude => "43.23165", :longitude => "12.78096").save
City.new(:country_id => "112", :name => "Grumo Nevano", :aliases => "Grumo Nevano,Grumo Nevano", :latitude => "40.93591", :longitude => "14.25983").save
City.new(:country_id => "112", :name => "Grugliasco", :aliases => "Grugliasco,Grujasch,gururiasuko,ã°ã«ãªã¢ã¹ã³,Grugliasco", :latitude => "45.06805", :longitude => "7.57762").save
City.new(:country_id => "112", :name => "Grottaglie", :aliases => "Grottaglie,Grottal'e,ÐÑÐ¾ÑÑÐ°Ð»ÑÐµ,Grottaglie", :latitude => "40.53923", :longitude => "17.4337").save
City.new(:country_id => "112", :name => "Grottaferrata", :aliases => "Ferentino,FerÃ¨ntino,Grottaferrata,gurottaferrata,ã°ã­ãã¿ãã§ãã©ã¼ã¿,Grottaferrata", :latitude => "41.78362", :longitude => "12.67568").save
City.new(:country_id => "112", :name => "Grosseto", :aliases => "Grosseto,ÐÑÐ¾ÑÑÐµÑÐ¾,Grosseto", :latitude => "42.77142", :longitude => "11.10794").save
City.new(:country_id => "112", :name => "Gravina in Puglia", :aliases => "Gravina in Puglia,Gravina in Puglia", :latitude => "40.81972", :longitude => "16.42278").save
City.new(:country_id => "112", :name => "Gragnano", :aliases => "Gragnano,Gran'jano,guranyano,ÐÑÐ°Ð½ÑÑÐ½Ð¾,ã°ã©ãã£ã¼ã,Gragnano", :latitude => "40.69561", :longitude => "14.51234").save
City.new(:country_id => "112", :name => "Gorizia", :aliases => "Goerz,Gorica,Goricija,Gorizia,Gorycja,Gurize,Gurizze,GÃ¶rz,goritsu~ia,ÐÐ¾ÑÐ¸ÑÐ¸Ñ,ã´ãªãã£ã¢,Gorizia", :latitude => "45.94088", :longitude => "13.62167").save
City.new(:country_id => "112", :name => "Gorgonzola", :aliases => "Gorgonzola,gorugonzora,ã´ã«ã´ã³ã¾ã¼ã©,Gorgonzola", :latitude => "45.53157", :longitude => "9.40465").save
City.new(:country_id => "112", :name => "Giussano", :aliases => "Giuessan,Giussano,GiÃ¼ssÃ n,Gluxianum,jussano,ã¸ã¥ããµã¼ã,Giussano", :latitude => "45.69408", :longitude => "9.21124").save
City.new(:country_id => "112", :name => "Giulianova", :aliases => "Giulianova,Giulianova", :latitude => "42.76115", :longitude => "13.9537").save
City.new(:country_id => "112", :name => "Giugliano in Campania", :aliases => "Giuglian,Giugliano in Campania,GiugliÃ n,ã¸ã¥ãªã¢ã¼ãã»ã¤ã³ã»ã«ã³ãã¼ãã¢,Giugliano in Campania", :latitude => "40.92741", :longitude => "14.19103").save
City.new(:country_id => "112", :name => "Giovinazzo", :aliases => "Dzhovinacco,Giovinazzo,ÐÐ¶Ð¾Ð²Ð¸Ð½Ð°ÑÑÐ¾,Giovinazzo", :latitude => "41.18643", :longitude => "16.66738").save
City.new(:country_id => "112", :name => "Gioia del Colle", :aliases => "Dzhoja-del'-Kolle,Gioia del Colle,Gioja del Colle,ÐÐ¶Ð¾Ñ-Ð´ÐµÐ»Ñ-ÐÐ¾Ð»Ð»Ðµ,Gioia del Colle", :latitude => "40.79673", :longitude => "16.92359").save
City.new(:country_id => "112", :name => "Ginosa", :aliases => "Ginosa,Ginosa", :latitude => "40.58012", :longitude => "16.75609").save
City.new(:country_id => "112", :name => "Ghedi", :aliases => "Gedi,Ghedi,gedi,ÐÐµÐ´Ð¸,ã²ã¼ãã£,Ghedi", :latitude => "45.40108", :longitude => "10.27927").save
City.new(:country_id => "112", :name => "Genzano di Roma", :aliases => "Dzhencano-di-Roma,Genzano,Genzano di Roma,ÐÐ¶ÐµÐ½ÑÐ°Ð½Ð¾-Ð´Ð¸-Ð Ð¾Ð¼Ð°,ã¸ã§ã³ãã¡ã¼ãã»ãã£ã»ã­ã¼ã,Genzano di Roma", :latitude => "41.70132", :longitude => "12.69178").save
City.new(:country_id => "112", :name => "Genova", :aliases => "Cenova,Dzenova,DÅ¾enova,Genes,Genoa,Genova,Genovo,Genua,Genuja,GenÃ¨s,GenÃºa,GÃ¨nova,GÃ©nova,GÃªnes,Janov,Xenova - Genova,XÃ©nova - Genova,Zena,genua,jeno'a,jenoba,jenovu~a,jnwa,jnwt,re na ya,Äenovo,ÐÐµÐ½Ð¾Ð²Ð°,ÐÐµÐ½ÑÐ°,ÐÐµÐ½ÑÑ,×× ×××,Ø¬ÙÙØ§,Ø¬ÙÙØ©,à¤à¥à¤¨à¥à¤,áááá£á,ã¸ã§ãã´ã¡,ç­é£äº,ì ë¸ë°,Genova", :latitude => "44.40632", :longitude => "8.93386").save
City.new(:country_id => "112", :name => "Garbagnate Milanese", :aliases => "Garbagnate Milanese,ã¬ã«ããã£ã¼ãã»ãã©ãã¼ã¼,Garbagnate Milanese", :latitude => "45.57647", :longitude => "9.07174").save
City.new(:country_id => "112", :name => "Gallipoli", :aliases => "Gallipoli,Kaddhipuli,ÐÐ°Ð»Ð»Ð¸Ð¿Ð¾Ð»Ð¸,Gallipoli", :latitude => "40.05556", :longitude => "17.97639").save
City.new(:country_id => "112", :name => "Gallarate", :aliases => "Gallarate,ÐÐ°Ð»Ð»Ð°ÑÐ°ÑÐµ,Gallarate", :latitude => "45.66019", :longitude => "8.79164").save
City.new(:country_id => "112", :name => "Galatone", :aliases => "Galatone,Galatone", :latitude => "40.14292", :longitude => "18.07042").save
City.new(:country_id => "112", :name => "Galatina", :aliases => "Aspedro,Galatina,Galatina", :latitude => "40.17402", :longitude => "18.16822").save
City.new(:country_id => "112", :name => "Gaeta", :aliases => "Gaeta,Gaete,Gaieta,GaÃ¨te,gaeta,ÐÐ°ÐµÑÐ°,ã¬ã¨ã¼ã¿,Gaeta", :latitude => "41.21408", :longitude => "13.57082").save
City.new(:country_id => "112", :name => "Fucecchio", :aliases => "Fucecchio,Fuchekkio,Ð¤ÑÑÐµÐºÐºÐ¸Ð¾,Fucecchio", :latitude => "43.72784", :longitude => "10.81011").save
City.new(:country_id => "112", :name => "Frosinone", :aliases => "Fresulone,Frosinone,Frozinone,furojinone,Ð¤ÑÐ¾Ð·Ð¸Ð½Ð¾Ð½Ðµ,ãã­ã¸ãã¼ã,Frosinone", :latitude => "41.64002", :longitude => "13.3401").save
City.new(:country_id => "112", :name => "Frattaminore", :aliases => "Frattaminore,furattaminore,ãã©ãã¿ããã¼ã¬,Frattaminore", :latitude => "40.95551", :longitude => "14.27273").save
City.new(:country_id => "112", :name => "Frattamaggiore", :aliases => "Frattamadzhore,Frattamaggiore,furattamajjore,Ð¤ÑÐ°ÑÑÐ°Ð¼Ð°Ð´Ð¶Ð¾ÑÐµ,ãã©ãã¿ããã¸ã§ã¼ã¬,Frattamaggiore", :latitude => "40.93931", :longitude => "14.27403").save
City.new(:country_id => "112", :name => "Frascati", :aliases => "Frascati,furasukati,ãã©ã¹ã«ã¼ãã£,Frascati", :latitude => "41.81632", :longitude => "12.66868").save
City.new(:country_id => "112", :name => "Francavilla Fontana", :aliases => "Francavilla Fontana,Francavilla Fontana", :latitude => "40.53063", :longitude => "17.58521").save
City.new(:country_id => "112", :name => "Francavilla al Mare", :aliases => "Francavilla al Mare,Francavilla al Mare", :latitude => "42.42064", :longitude => "14.28701").save
City.new(:country_id => "112", :name => "Fossano", :aliases => "Fossan,Fossano,Fossano", :latitude => "44.54894", :longitude => "7.72013").save
City.new(:country_id => "112", :name => "Formigine", :aliases => "Formigine,Furmezen,FurmÃ¨Å¼en,forumijine,ãã©ã«ãã¼ã¸ã,Formigine", :latitude => "44.57296", :longitude => "10.847").save
City.new(:country_id => "112", :name => "Formia", :aliases => "Formia,forumia,ãã©ã«ãã¢,Formia", :latitude => "41.25626", :longitude => "13.60588").save
City.new(:country_id => "112", :name => "Forli", :aliases => "Forli,ForlÃ¬,Forum Livii,foruri,Ð¤Ð¾ÑÐ»Ð¸,ãã©ã«ãª,ForlÃ¬", :latitude => "44.22361", :longitude => "12.05278").save
City.new(:country_id => "112", :name => "Fondi", :aliases => "Fonda,Fondi,fondi,pwndy,Ð¤Ð¾Ð½Ð´Ð°,×¤×× ××,ãã©ã³ãã£,Fondi", :latitude => "41.35411", :longitude => "13.43131").save
City.new(:country_id => "112", :name => "Follonica", :aliases => "Follonica,Follonica", :latitude => "42.92633", :longitude => "10.76162").save
City.new(:country_id => "112", :name => "Foligno", :aliases => "Foligno,Folin'o,forinyo,Ð¤Ð¾Ð»Ð¸Ð½ÑÐ¾,ãã©ãªã¼ãã§,Foligno", :latitude => "42.94404", :longitude => "12.70107").save
City.new(:country_id => "112", :name => "Foggia", :aliases => "Fodzha,Foggia,Fovea,byrwdja,fojja,fwdja,Ð¤Ð¾Ð´Ð¶Ð°,Ø¨ÙØ±ÙØ¯Ø¬Ø§,ÙÙØ¯Ø¬Ø§,ãã©ãã¸ã£,Foggia", :latitude => "41.46093", :longitude => "15.54925").save
City.new(:country_id => "112", :name => "Fiumicino", :aliases => "F'jumichino,Fiumicino,fiumichino,Ð¤ÑÑÐ¼Ð¸ÑÐ¸Ð½Ð¾,ãã£ã¦ããã¼ã,Fiumicino", :latitude => "41.76747", :longitude => "12.22907").save
City.new(:country_id => "112", :name => "Florence", :aliases => "Firence,Firenze,Florence,Florencia,Florencija,Florens,Florentia,Florenz,FlorÃ¨ncia,FlÃ³rens,Ð¤Ð»Ð¾ÑÐµÐ½ÑÐ¸Ñ,Florence", :latitude => "43.76667", :longitude => "11.25").save
City.new(:country_id => "112", :name => "Fiorano Modenese", :aliases => "Fiorano Modenese,ãã£ãªã©ã¼ãã»ã¢ããã¼ã¼,Fiorano Modenese", :latitude => "44.53596", :longitude => "10.8218").save
City.new(:country_id => "112", :name => "Finale Emilia", :aliases => "Finale Emilia,Finale nell'Emilia,Finale Emilia", :latitude => "44.83457", :longitude => "11.2939").save
City.new(:country_id => "112", :name => "Figline Valdarno", :aliases => "Figline Valdarno,Figline Valdarno", :latitude => "43.61955", :longitude => "11.46933").save
City.new(:country_id => "112", :name => "Fidenza", :aliases => "Fidency,Fidenza,San Donnino,Ð¤Ð¸Ð´ÐµÐ½ÑÑ,Fidenza", :latitude => "44.86396", :longitude => "10.06668").save
City.new(:country_id => "112", :name => "Ferrara", :aliases => "Ferrara,Ferrare,Ð¤ÐµÑÑÐ°ÑÐ°,Ferrara", :latitude => "44.82678", :longitude => "11.62071").save
City.new(:country_id => "112", :name => "Fermo", :aliases => "Fermo,Firmum Picenum,ferumo,Ð¤ÐµÑÐ¼Ð¾,ãã§ã«ã¢,Fermo", :latitude => "43.16466", :longitude => "13.72329").save
City.new(:country_id => "112", :name => "Ferentino", :aliases => "Ferentino,Ð¤ÐµÑÐµÐ½ÑÐ¸Ð½Ð¾,Ferentino", :latitude => "41.69532", :longitude => "13.2564").save
City.new(:country_id => "112", :name => "Feltre", :aliases => "Feltre,Feltre", :latitude => "46.02351", :longitude => "11.907").save
City.new(:country_id => "112", :name => "Fasano", :aliases => "Fasano,Fazano,Ð¤Ð°Ð·Ð°Ð½Ð¾,Fasano", :latitude => "40.83443", :longitude => "17.3584").save
City.new(:country_id => "112", :name => "Fano", :aliases => "Fano,Fanu,Fanum Fortunae,Ð¤Ð°Ð½Ð¾,Fano", :latitude => "43.82036", :longitude => "13.01206").save
City.new(:country_id => "112", :name => "Falconara Marittima", :aliases => "Falconara Alta,Falconara Marittima,ãã¡ã«ã³ãã¼ã©ã»ããªããã£ã,Falconara Marittima", :latitude => "43.62326", :longitude => "13.40307").save
City.new(:country_id => "112", :name => "Faenza", :aliases => "Faenca,Faenza,faentsu~a,ãã¡ã¨ã³ãã¡,Faenza", :latitude => "44.2857", :longitude => "11.88334").save
City.new(:country_id => "112", :name => "Fabriano", :aliases => "Fabriano,Fabrianum,faburiano,Ð¤Ð°Ð±ÑÐ¸Ð°Ð½Ð¾,ãã¡ããªã¢ã¼ã,Fabriano", :latitude => "43.34065", :longitude => "12.90726").save
City.new(:country_id => "112", :name => "Este", :aliases => "Este,esute,ÐÑÑÐµ,ã¨ã¹ã,Este", :latitude => "45.22289", :longitude => "11.65871").save
City.new(:country_id => "112", :name => "Ercolano", :aliases => "Ercolano,Gerkulanum,Resina,ÐÐµÑÐºÑÐ»Ð°Ð½ÑÐ¼,Ercolano", :latitude => "40.80631", :longitude => "14.36093").save
City.new(:country_id => "112", :name => "Erba", :aliases => "Erba,Herba,Incino,eruba,ã¨ã«ã,Erba", :latitude => "45.80958", :longitude => "9.23124").save
City.new(:country_id => "112", :name => "Empoli", :aliases => "Empoli,enpori,ÐÐ¼Ð¿Ð¾Ð»Ð¸,ã¨ã³ããª,Empoli", :latitude => "43.71754", :longitude => "10.94142").save
City.new(:country_id => "112", :name => "Eboli", :aliases => ",Eboli", :latitude => "40.61421", :longitude => "15.05785").save
City.new(:country_id => "112", :name => "Domodossola", :aliases => "Domodossola,domodossora,ãã¢ããã½ã©,Domodossola", :latitude => "46.1165", :longitude => "8.29313").save
City.new(:country_id => "112", :name => "Desio", :aliases => "Dees,Desio,Dezio,dejio,ÐÐµÐ·Ð¸Ð¾,ãã¼ã¸ãª,Desio", :latitude => "45.62018", :longitude => "9.20424").save
City.new(:country_id => "112", :name => "Desenzano del Garda", :aliases => "Desenzano,Desenzano del Garda,Desenzano sul Lago,ãã¼ã³ãã¡ã¼ãã»ãã«ã»ã¬ã«ã,Desenzano del Garda", :latitude => "45.46798", :longitude => "10.53398").save
City.new(:country_id => "112", :name => "Dalmine", :aliases => "Dal'mine,Dalmine,ÐÐ°Ð»ÑÐ¼Ð¸Ð½Ðµ,Dalmine", :latitude => "45.64928", :longitude => "9.60395").save
City.new(:country_id => "112", :name => "Cusano Milanino", :aliases => "Cusano Milanino,ã¯ã¶ã¼ãã»ãã©ãã¼ã,Cusano Milanino", :latitude => "45.55307", :longitude => "9.18344").save
City.new(:country_id => "112", :name => "Cuneo", :aliases => "Coni,Kuneo,ÐÑÐ½ÐµÐ¾,Cuneo", :latitude => "44.39733", :longitude => "7.54453").save
City.new(:country_id => "112", :name => "Cremona", :aliases => "Cremon-a,Cremona,Cremone,CrÃ©mone,Kremona,ke lei mo na,keulemona,kuremona,ÐÑÐµÐ¼Ð¾Ð½Ð°,ã¯ã¬ã¢ã,åé·è«ç´,í¬ë ëª¨ë,Cremona", :latitude => "45.13617", :longitude => "10.02797").save
City.new(:country_id => "112", :name => "Crema", :aliases => "Crema,Krema,kurema,ÐÑÐµÐ¼Ð°,ã¯ã¬ã¼ã,Crema", :latitude => "45.35877", :longitude => "9.66826").save
City.new(:country_id => "112", :name => "Cossato", :aliases => "Cossato,Cossato", :latitude => "45.57386", :longitude => "8.18172").save
City.new(:country_id => "112", :name => "Cortona", :aliases => "Cortona,Cortone,Kortona,ÐÐ¾ÑÑÐ¾Ð½Ð°,Cortona", :latitude => "43.27467", :longitude => "11.98533").save
City.new(:country_id => "112", :name => "Corsico", :aliases => "Corsico,Korsiko,korushiko,ÐÐ¾ÑÑÐ¸ÐºÐ¾,ã³ã«ã·ã³,Corsico", :latitude => "45.43099", :longitude => "9.11093").save
City.new(:country_id => "112", :name => "Correggio", :aliases => "Coreggio,Correggio,Koredzho,korrejjo,ÐÐ¾ÑÐµÐ´Ð¶Ð¾,ã³ãã¬ãã¸ã§,Correggio", :latitude => "44.76977", :longitude => "10.7823").save
City.new(:country_id => "112", :name => "Cornaredo", :aliases => "Cornaredo,korunaredo,ã³ã«ãã¬ã¼ã,Cornaredo", :latitude => "45.49697", :longitude => "9.02614").save
City.new(:country_id => "112", :name => "Cormano", :aliases => "Cormano,korumano,ã³ã«ãã¼ã,Cormano", :latitude => "45.53957", :longitude => "9.17094").save
City.new(:country_id => "112", :name => "Cordenons", :aliases => "Cordenona,Cordenons,Cordenons", :latitude => "45.98972", :longitude => "12.70194").save
City.new(:country_id => "112", :name => "Corciano", :aliases => "Corciano,Corciano", :latitude => "43.12904", :longitude => "12.28736").save
City.new(:country_id => "112", :name => "Corato", :aliases => "Corato,Korato,ÐÐ¾ÑÐ°ÑÐ¾,Corato", :latitude => "41.14553", :longitude => "16.41387").save
City.new(:country_id => "112", :name => "Copparo", :aliases => "Copparo,Copparo", :latitude => "44.89298", :longitude => "11.82492").save
City.new(:country_id => "112", :name => "Copertino", :aliases => "Copertino,Cupertinu,Copertino", :latitude => "40.27152", :longitude => "18.05652").save
City.new(:country_id => "112", :name => "Conversano", :aliases => "Conversano,Konversano,ÐÐ¾Ð½Ð²ÐµÑÑÐ°Ð½Ð¾,Conversano", :latitude => "40.96623", :longitude => "17.11479").save
City.new(:country_id => "112", :name => "Conegliano", :aliases => "Conegliano,Konel'jano,koneriano,ÐÐ¾Ð½ÐµÐ»ÑÑÐ½Ð¾,ã³ããªã¢ã¼ã,Conegliano", :latitude => "45.89056", :longitude => "12.2925").save
City.new(:country_id => "112", :name => "Como", :aliases => "Com,Come,Como,CÃ²m,CÃ´me,Komo,Novum Comum,ke mo,komo,ÐÐ¾Ð¼Ð¾,ã³ã¢,ç§è«,Como", :latitude => "45.80998", :longitude => "9.08744").save
City.new(:country_id => "112", :name => "Comacchio", :aliases => "Comacchio,Comacchio", :latitude => "44.6975", :longitude => "12.18583").save
City.new(:country_id => "112", :name => "Cologno Monzese", :aliases => "Cologno,Cologno Monzese", :latitude => "45.53004", :longitude => "9.27795").save
City.new(:country_id => "112", :name => "Colle Salvetti", :aliases => ",Collesalvetti", :latitude => "43.58884", :longitude => "10.47481").save
City.new(:country_id => "112", :name => "Collegno", :aliases => "Colegn,Collegno,Kollen'o,korrenyo,ÐÐ¾Ð»Ð»ÐµÐ½ÑÐ¾,ã³ãã¬ã¼ãã§,Collegno", :latitude => "45.07755", :longitude => "7.57242").save
City.new(:country_id => "112", :name => "Colleferro", :aliases => "Colleferro,Kolleferro,korreferro,ÐÐ¾Ð»Ð»ÐµÑÐµÑÑÐ¾,ã³ãã¬ãã§ãã­,Colleferro", :latitude => "41.72622", :longitude => "13.00359").save
City.new(:country_id => "112", :name => "Colle di Val d'Elsa", :aliases => "Colle Val d'Elsa,Colle di Val d'Elsa,ã³ãã¬ã»ãã£ã»ã´ã¡ã«ã»ãã«ã¶,Colle di Val d'Elsa", :latitude => "43.41514", :longitude => "11.13142").save
City.new(:country_id => "112", :name => "Civitavecchia", :aliases => "Chivitavekk'ja,Civitavecchia,chivu~itavu~ekkia,Ð§Ð¸Ð²Ð¸ÑÐ°Ð²ÐµÐºÐºÑÑ,ãã´ã£ã¿ã´ã§ãã­ã¢,Civitavecchia", :latitude => "42.09325", :longitude => "11.79674").save
City.new(:country_id => "112", :name => "Civita Castellana", :aliases => "Civita Castellana,ãã¼ã´ã£ã¿ã»ã«ã¹ããã©ã¼ã,Civita Castellana", :latitude => "42.29523", :longitude => "12.40917").save
City.new(:country_id => "112", :name => "Citta di Castello", :aliases => "Chita di Kastelo,Citta di Castello,Citti Di Castello,CittÃ  di Castello,Tifernum Tiberinum,Ð§Ð¸ÑÐ° Ð´Ð¸ ÐÐ°ÑÑÐµÐ»Ð¾,ããã¿ã»ãã£ã»ã«ã¹ããã­,CittÃ  di Castello", :latitude => "43.46905", :longitude => "12.23045").save
City.new(:country_id => "112", :name => "Cittadella", :aliases => "Cittadella,Cittadella", :latitude => "45.65", :longitude => "11.7842").save
City.new(:country_id => "112", :name => "Cisterna di Latina", :aliases => "Cisterna,Cisterna di Latina", :latitude => "41.5908", :longitude => "12.82808").save
City.new(:country_id => "112", :name => "Cirie", :aliases => "Cirie,CiriÃ¨,CiriÃ©,chirie,cirie,ciriÃ¨,ããªã¨,CiriÃ¨", :latitude => "45.23505", :longitude => "7.59882").save
City.new(:country_id => "112", :name => "Cinisello Balsamo", :aliases => "Cinisello,Cinisello Balsamo,ããã¼ãã­ã»ãã«ãµã¢,Cinisello Balsamo", :latitude => "45.55707", :longitude => "9.22185").save
City.new(:country_id => "112", :name => "Ciampino", :aliases => "Champino,Ciampino,chanpino,Ð§Ð°Ð¼Ð¿Ð¸Ð½Ð¾,ãã£ã³ãã¼ã,Ciampino", :latitude => "41.80162", :longitude => "12.60658").save
City.new(:country_id => "112", :name => "Chivasso", :aliases => "Chivasso,Civass,Clavassium,Kivasso,kivu~asso,ÐÐ¸Ð²Ð°ÑÑÐ¾,ã­ã´ã¡ãã½,Chivasso", :latitude => "45.18935", :longitude => "7.88722").save
City.new(:country_id => "112", :name => "Chioggia", :aliases => "Chioggia,kiojja,ã­ãªãã¸ã£,Chioggia", :latitude => "45.22556", :longitude => "12.28889").save
City.new(:country_id => "112", :name => "Chieti", :aliases => "Chieta,Chieti,K'eti,Teate,kieti,ÐÑÐµÑÐ¸,ã­ã¨ã¼ãã£,Chieti", :latitude => "42.36094", :longitude => "14.13801").save
City.new(:country_id => "112", :name => "Chieri", :aliases => "Cher,Chieri,kieri,ã­ã¨ã¼ãª,Chieri", :latitude => "45.01395", :longitude => "7.82233").save
City.new(:country_id => "112", :name => "Chiavari", :aliases => "Chiavari,Ciaevai,CiÃ¤vai,Kiavari,ÐÐ¸Ð°Ð²Ð°ÑÐ¸,Chiavari", :latitude => "44.31771", :longitude => "9.32241").save
City.new(:country_id => "112", :name => "Chiari", :aliases => "Chiari,Clarium,kiari,ã­ã¢ã¼ãª,Chiari", :latitude => "45.53588", :longitude => "9.93036").save
City.new(:country_id => "112", :name => "Cesenatico", :aliases => "Cesenatico,Chezenatiko,chezenatiko,Ð§ÐµÐ·ÐµÐ½Ð°ÑÐ¸ÐºÐ¾,ãã§ã¼ãã¼ãã£ã³,Cesenatico", :latitude => "44.19987", :longitude => "12.3991").save
City.new(:country_id => "112", :name => "Cesena", :aliases => "Caesena,Cesena,Cesene,Chezena,CÃ©sÃ¨ne,Zisena,ZisÃ¨na,chezena,Ð§ÐµÐ·ÐµÐ½Ð°,ãã§ã¼ã¼ã,Cesena", :latitude => "44.1391", :longitude => "12.24315").save
City.new(:country_id => "112", :name => "Cesano Maderno", :aliases => "Cesano,Cesano Maderno,ãã§ã¶ã¼ãã»ããã«ã,Cesano Maderno", :latitude => "45.63038", :longitude => "9.15224").save
City.new(:country_id => "112", :name => "Cervia", :aliases => "Cervia,Chervia,cheruvu~ia,Ð§ÐµÑÐ²Ð¸Ð°,ãã§ã«ã´ã£ã¢,Cervia", :latitude => "44.26204", :longitude => "12.34812").save
City.new(:country_id => "112", :name => "Cerveteri", :aliases => "Caere,Cerveleri,Cerveteri,Cherveteri,cheruvu~eteri,Ð§ÐµÑÐ²ÐµÑÐµÑÐ¸,ãã§ã«ã´ã§ã¼ããª,Cerveteri", :latitude => "41.99262", :longitude => "12.09237").save
City.new(:country_id => "112", :name => "Certaldo", :aliases => "Certaldo,Certaldo", :latitude => "43.54704", :longitude => "11.04022").save
City.new(:country_id => "112", :name => "Cernusco sul Naviglio", :aliases => "Cernusco,Cernusco sul Naviglio,ãã§ã«ãã¹ã³ã»ã¹ã«ã»ãã´ã£ã¼ãªãª,Cernusco sul Naviglio", :latitude => "45.52716", :longitude => "9.3334").save
City.new(:country_id => "112", :name => "Cerignola", :aliases => "Corignola,Cerignola", :latitude => "41.26403", :longitude => "15.90046").save
City.new(:country_id => "112", :name => "Cerea", :aliases => "Cerea,Cerea", :latitude => "45.19208", :longitude => "11.2103").save
City.new(:country_id => "112", :name => "Cercola", :aliases => "Cercola,cherukora,ãã§ã«ã³ã©,Cercola", :latitude => "40.85661", :longitude => "14.35773").save
City.new(:country_id => "112", :name => "Cento", :aliases => "Cento,chento,ãã§ã³ã,Cento", :latitude => "44.72597", :longitude => "11.28821").save
City.new(:country_id => "112", :name => "Ceglie Messapico", :aliases => "Ceglie Messapica,CÃ©glie MessÃ¡pica,ãã§ã¼ãªã¨ã»ã¡ããµãã¼ã«,Ceglie Messapica", :latitude => "40.64393", :longitude => "17.5155").save
City.new(:country_id => "112", :name => "Cecina", :aliases => "Cecina,Chechina,chechina,Ð§ÐµÑÐ¸Ð½Ð°,ãã§ã¼ãã,Cecina", :latitude => "43.31283", :longitude => "10.52401").save
City.new(:country_id => "112", :name => "Ceccano", :aliases => "Ceccano,Chekkano,Ð§ÐµÐºÐºÐ°Ð½Ð¾,Ceccano", :latitude => "41.56772", :longitude => "13.3333").save
City.new(:country_id => "112", :name => "Cavarzere", :aliases => "Cavarzere,kavu~arutsu~ere,ã«ã´ã¡ã«ãã§ã¬,Cavarzere", :latitude => "45.13556", :longitude => "12.08167").save
City.new(:country_id => "112", :name => "Cava de' Tirreni", :aliases => "Cava,Cava de' Tirreni,Cava de'Tirreni,Cava dei Tirreni,Cava de' Tirreni", :latitude => "40.70091", :longitude => "14.70564").save
City.new(:country_id => "112", :name => "Cattolica", :aliases => "Cattolica,kattorika,ã«ããã¼ãªã«,Cattolica", :latitude => "43.95747", :longitude => "12.73755").save
City.new(:country_id => "112", :name => "Castiglione delle Stiviere", :aliases => "Castiglione delle Stiviere,ã«ã¹ãã£ãªãªã¼ãã»ããã¬ã»ã¹ãã£ã´ã£ã¨ã¼ã¬,Castiglione delle Stiviere", :latitude => "45.39058", :longitude => "10.48528").save
City.new(:country_id => "112", :name => "Castel Volturno", :aliases => "Castel Volturno,Castel Volturno", :latitude => "41.03353", :longitude => "13.94217").save
City.new(:country_id => "112", :name => "Castel San Pietro Terme", :aliases => "Castel San Pietro Terme,Castel San Pietro dell'Emilia,Castel San Pietro Terme", :latitude => "44.39857", :longitude => "11.58482").save
City.new(:country_id => "112", :name => "Castel Maggiore", :aliases => "Castel Maggiore,Kastel Madzhore,ÐÐ°ÑÑÐµÐ» ÐÐ°Ð´Ð¶Ð¾ÑÐµ,Castel Maggiore", :latitude => "44.57707", :longitude => "11.36071").save
City.new(:country_id => "112", :name => "Castellaneta", :aliases => "Castellaneta,Castellaneta", :latitude => "40.62722", :longitude => "16.93689").save
City.new(:country_id => "112", :name => "Castellana Grotte", :aliases => "Castellana,Castellana Grotte,ã«ã¹ããã©ã¼ãã»ã°ã­ãã,Castellana Grotte", :latitude => "40.88643", :longitude => "17.1655").save
City.new(:country_id => "112", :name => "Castellammare di Stabia", :aliases => "Castellammare,Castellammare di Stabia,Estabia,EstÃ bia,Kastelamare di Stabija,Stabia,Stabiae,Stabie,ÐÐ°ÑÑÐµÐ»Ð°Ð¼Ð°ÑÐµ Ð´Ð¸ Ð¡ÑÐ°Ð±Ð¸ÑÐ°,Castellammare di Stabia", :latitude => "40.71551", :longitude => "14.48914").save
City.new(:country_id => "112", :name => "Castelfranco Veneto", :aliases => "Castelfranco Veneto,Castelfranco Veneto", :latitude => "45.6761", :longitude => "11.926").save
City.new(:country_id => "112", :name => "Castelfranco Emilia", :aliases => "Castelfranco Emilia,Castelfranco d'Emilia,Castelfranco dell'Emilia,Castelfranco Emilia", :latitude => "44.59577", :longitude => "11.052").save
City.new(:country_id => "112", :name => "Castelfiorentino", :aliases => "Castelfiorentino,Castelfiorentino", :latitude => "43.61004", :longitude => "10.96922").save
City.new(:country_id => "112", :name => "Castelfidardo", :aliases => ",Castelfidardo", :latitude => "43.46316", :longitude => "13.54518").save
City.new(:country_id => "112", :name => "Cassino", :aliases => "Cassino,Kassino,kasshino,ÐÐ°ÑÑÐ¸Ð½Ð¾,ã«ãã·ã¼ã,Cassino", :latitude => "41.48762", :longitude => "13.83151").save
City.new(:country_id => "112", :name => "Cassano d'Adda", :aliases => "Cassano d'Adda,Kasano d'Ada,ÐÐ°ÑÐ°Ð½Ð¾ Ð´'ÐÐ´Ð°,ã«ããµã¼ãã»ããã,Cassano d'Adda", :latitude => "45.52358", :longitude => "9.51395").save
City.new(:country_id => "112", :name => "Casoria", :aliases => "Casoria,kazoria,ã«ã¾ã¼ãªã¢,Casoria", :latitude => "40.90664", :longitude => "14.29587").save
City.new(:country_id => "112", :name => "Caserta", :aliases => "Caserta,Caserte,Kazerta,kazeruta,ÐÐ°Ð·ÐµÑÑÐ°,ã«ã¼ã«ã¿,Caserta", :latitude => "41.08322", :longitude => "14.33493").save
City.new(:country_id => "112", :name => "Caselle Torinese", :aliases => "Caseli,Caselle,Caselle Torinese,ã«ã¼ãã¬ã»ããªãã¼ã¼,Caselle Torinese", :latitude => "45.17785", :longitude => "7.64262").save
City.new(:country_id => "112", :name => "Cascina", :aliases => "Cascina,Cascina", :latitude => "43.67914", :longitude => "10.49941").save
City.new(:country_id => "112", :name => "Casamassima", :aliases => "Casamassima,Cassamassima,Casamassima", :latitude => "40.95713", :longitude => "16.92039").save
City.new(:country_id => "112", :name => "Casalnuovo di Napoli", :aliases => "Casalnuovo,Casalnuovo di Napoli,ã«ã¶ã«ããªã¼ã´ã©ã»ãã£ã»ããã¼ãª,Casalnuovo di Napoli", :latitude => "40.90921", :longitude => "14.34573").save
City.new(:country_id => "112", :name => "Casale Monferrato", :aliases => "Casal,Casale,Casale Monferrato,Casale Monferrato", :latitude => "45.13336", :longitude => "8.45714").save
City.new(:country_id => "112", :name => "Casalecchio di Reno", :aliases => "Casalacc',Casalecchio di Reno,CasalÃ ccâ,Casalecchio di Reno", :latitude => "44.47557", :longitude => "11.27591").save
City.new(:country_id => "112", :name => "Casal di Principe", :aliases => "Casal di Principe,Casal di Principe", :latitude => "41.01141", :longitude => "14.12482").save
City.new(:country_id => "112", :name => "Carrara", :aliases => "Apuania,Carara,Carrara,Carrare,Karrara,karrara,ÐÐ°ÑÑÐ°ÑÐ°,ã«ãã©ã¼ã©,Carrara", :latitude => "44.06294", :longitude => "10.06069").save
City.new(:country_id => "112", :name => "Carpi", :aliases => "Carpi,Cherp,ChÃ¨rp,Karpi,karupi,ÐÐ°ÑÐ¿Ð¸,ã«ã«ã,Carpi", :latitude => "44.78237", :longitude => "10.8777").save
City.new(:country_id => "112", :name => "Carmagnola", :aliases => "Carmagnola,Carmagnole,CarmagnÃ²la,Karman'ola,karumanyora,ÐÐ°ÑÐ¼Ð°Ð½ÑÐ¾Ð»Ð°,ã«ã«ããã§ã¼ã©,Carmagnola", :latitude => "44.84704", :longitude => "7.71803").save
City.new(:country_id => "112", :name => "Cardito", :aliases => "Cardito,karudito,ã«ã«ãã£ã¼ã,Cardito", :latitude => "40.94201", :longitude => "14.29943").save
City.new(:country_id => "112", :name => "Carate Brianza", :aliases => "Carate,Carate Brianza,ã«ã©ã¼ãã»ããªã¢ã³ãã¡,Carate Brianza", :latitude => "45.67368", :longitude => "9.23594").save
City.new(:country_id => "112", :name => "Capua", :aliases => "Capoue,Capua,CÃ pua,CÃ¡pua,kapua,×§×¤×××,áááá£á,ã«ãã¢,Capua", :latitude => "41.09971", :longitude => "14.22013").save
City.new(:country_id => "112", :name => "Capannori", :aliases => "Capannori,Kapannori,ÐÐ°Ð¿Ð°Ð½Ð½Ð¾ÑÐ¸,Capannori", :latitude => "43.87474", :longitude => "10.5728").save
City.new(:country_id => "112", :name => "Capaccio", :aliases => "Capaccio,Capaccio-Paestum,Capaccio", :latitude => "40.42441", :longitude => "15.08085").save
City.new(:country_id => "112", :name => "Cantu", :aliases => ",CantÃ¹", :latitude => "45.72938", :longitude => "9.14054").save
City.new(:country_id => "112", :name => "Canosa di Puglia", :aliases => "Canosa de Pulla,Canosa di Puglia,Canosa di Puglia", :latitude => "41.21963", :longitude => "16.06747").save
City.new(:country_id => "112", :name => "Campobasso", :aliases => "Campobass,Campobasso,Campubbassu,Campus Bassus,Kampobasso,kanpobasso,ÐÐ°Ð¼Ð¿Ð¾Ð±Ð°ÑÑÐ¾,ã«ã³ãããã½,Campobasso", :latitude => "41.56003", :longitude => "14.66753").save
City.new(:country_id => "112", :name => "Campi Bisenzio", :aliases => "Campi Bisenzio,Campo Bisenzio,Campo BisÃ©nzio,ã«ã³ãã»ãã¼ã³ãã£ãª,Campi Bisenzio", :latitude => "43.82455", :longitude => "11.13242").save
City.new(:country_id => "112", :name => "Campagna", :aliases => "Campagna,kanpanya,ã«ã³ãã¼ãã£,Campagna", :latitude => "40.66531", :longitude => "15.10585").save
City.new(:country_id => "112", :name => "Camaiore", :aliases => "Camaiore,Kamajore,ÐÐ°Ð¼Ð°Ð¹Ð¾ÑÐµ,Camaiore", :latitude => "43.90974", :longitude => "10.2419").save
City.new(:country_id => "112", :name => "Calenzano", :aliases => "Calenzano,Calenzano", :latitude => "43.85595", :longitude => "11.16272").save
City.new(:country_id => "112", :name => "Caivano", :aliases => "Caivano,Kajvano,kaivu~ano,ÐÐ°Ð¹Ð²Ð°Ð½Ð¾,ã«ã¤ã´ã¡ã¼ã,Caivano", :latitude => "40.95711", :longitude => "14.31023").save
City.new(:country_id => "112", :name => "Busto Arsizio", :aliases => "Ansizio,Busto Arsizio,Bustum Arsitium,bu si tuo-a xi qi ao,å¸æ¯æ-é¿è¥¿é½å¥§,Busto Arsizio", :latitude => "45.61128", :longitude => "8.84914").save
City.new(:country_id => "112", :name => "Bussolengo", :aliases => "Bussolengo,Bussolengo", :latitude => "45.46919", :longitude => "10.85058").save
City.new(:country_id => "112", :name => "Budrio", :aliases => "Budrio,Budrio", :latitude => "44.53707", :longitude => "11.53362").save
City.new(:country_id => "112", :name => "Brusciano", :aliases => "Brusciano,burushano,ãã«ã·ã£ã¼ã,Brusciano", :latitude => "40.92321", :longitude => "14.42393").save
City.new(:country_id => "112", :name => "Brugherio", :aliases => "Brugerio,Brugherio,burugerio,ÐÑÑÐ³ÐµÑÐ¸Ð¾,ãã«ã²ã¼ãªãª,Brugherio", :latitude => "45.55301", :longitude => "9.29907").save
City.new(:country_id => "112", :name => "Brindisi", :aliases => "Brindisi,Brindizi,Brinnese,Brundisium,BrÃ¬ndisi,brindisi,burindiji,ÐÑÐ¸Ð½Ð´Ð¸Ð·Ð¸,à¤¬à¥à¤°à¤¿à¤à¤¡à¤¿à¤¸à¤¿,ããªã³ãã£ã¸,Brindisi", :latitude => "40.62773", :longitude => "17.93682").save
City.new(:country_id => "112", :name => "Bresso", :aliases => "Bresso,buresso,ÐÑÐµÑÑÐ¾,ãã¬ãã½,Bresso", :latitude => "45.53792", :longitude => "9.18921").save
City.new(:country_id => "112", :name => "Bressanone", :aliases => "Bressanone,Brixen,Brixino,buressanone,ÐÑÐµÑÑÐ°Ð½Ð¾Ð½Ðµ,ãã¬ããµãã¼ã,Bressanone - Brixen", :latitude => "46.71503", :longitude => "11.65598").save
City.new(:country_id => "112", :name => "Brescia", :aliases => "Brescia,Bresha,Breshija,Bresia,Bressia,Brixia,BrÃ©scia,bryshya,bu lei xi ya,bureshia,ÐÑÐµÑÐ°,ÐÑÐµÑÐ¸Ñ,Ø¨Ø±ÙØ´ÙØ§,ãã¬ã·ã¢,å¸é·è¥¿äº,Brescia", :latitude => "45.52478", :longitude => "10.22727").save
City.new(:country_id => "112", :name => "Bracciano", :aliases => "Bracciano,Brachchano,buratchano,ÐÑÐ°ÑÑÐ°Ð½Ð¾,ãã©ããã£ã¼ã,Bracciano", :latitude => "42.10306", :longitude => "12.17543").save
City.new(:country_id => "112", :name => "Bra", :aliases => "Bra,bura,ÐÑÐ°,ãã©,Bra", :latitude => "44.70304", :longitude => "7.85563").save
City.new(:country_id => "112", :name => "Boscoreale", :aliases => "Boscoreale,Boskoreale,bosukoreare,ÐÐ¾ÑÐºÐ¾ÑÐµÐ°Ð»Ðµ,ãã¹ã³ã¬ã¢ã¼ã¬,Boscoreale", :latitude => "40.77561", :longitude => "14.49944").save
City.new(:country_id => "112", :name => "Borgo San Lorenzo", :aliases => "Borgo San Lorenzo,Borgo San Lorenzo", :latitude => "43.95535", :longitude => "11.38352").save
City.new(:country_id => "112", :name => "Borgomanero", :aliases => "Borgomanero,Borgomanero", :latitude => "45.70237", :longitude => "8.45813").save
City.new(:country_id => "112", :name => "Bondeno", :aliases => "Bondeno,Bondeno", :latitude => "44.88618", :longitude => "11.41081").save
City.new(:country_id => "112", :name => "Bolzano - Bozen", :aliases => "Bal'cana,Bauzanum,Bocen,Bocenas,Boceno,Bol'cano,Bolcano,BolcÄno,Bolzan,Bolzano,Bolzanu,BolzÃ¡n,Botzen,Bozen,Bozen-Bolzano,Bozn,Bulsaun,Buzzanu,Mpoltzano,bo er cha nuo,borutsu~ano,bwlznw,ÎÏÎ¿Î»ÏÎ¶Î¬Î½Î¿,ÐÐ°Ð»ÑÑÐ°Ð½Ð°,ÐÐ¾Ð»ÑÐ°Ð½Ð¾,ÐÐ¾Ð»ÑÑÐ°Ð½Ð¾,ÐÐ¾ÑÐµÐ½,××××¦× ×,ãã«ãã¡ã¼ã,æ³¢å°æ¥è¯º,Bolzano - Bozen", :latitude => "46.49272", :longitude => "11.33358").save
City.new(:country_id => "112", :name => "Bologna", :aliases => "Baljon'ja,Bologna,Bologne,Bolon'ja,Bolona,Bolonha,Bolonia,Bolonija,Bolonja,Bolonjo,Bolonya,BoloÅa,BoloÅa,Bononia,Bulaggna,Bulogna,BulÃ¥ggna,bo luo ni ya,bollonya,boronya,bwlwnya,bwlwnyh,ÐÐ°Ð»ÑÐ½ÑÑ,ÐÐ¾Ð»Ð¾Ð½ÑÑ,ÐÐ¾Ð»Ð¾Ð½Ñ,ÐÐ¾Ð»Ð¾ÑÐ°,××××× ××,Ø¨ÙÙÙÙÙØ§,ãã­ã¼ãã£,åæ´å°¼äº,ë³¼ë¡ë,Bologna", :latitude => "44.49381", :longitude => "11.33875").save
City.new(:country_id => "112", :name => "Bollate", :aliases => "Bollate,borrate,ããã©ã¼ã,Bollate", :latitude => "45.54647", :longitude => "9.12054").save
City.new(:country_id => "112", :name => "Bitonto", :aliases => "Bitonto,bitonto,ããã³ã,Bitonto", :latitude => "41.11083", :longitude => "16.68938").save
City.new(:country_id => "112", :name => "Bisceglie", :aliases => "Bisceglie,Bishell'e,bisherie,ÐÐ¸ÑÐµÐ»Ð»ÑÐµ,ãã·ã§ã¼ãªã¨,Bisceglie", :latitude => "41.24203", :longitude => "16.50438").save
City.new(:country_id => "112", :name => "Biella", :aliases => "B'ella,Biella,Bugella,bierra,ÐÑÐµÐ»Ð»Ð°,ãã¨ãã©,Biella", :latitude => "45.55986", :longitude => "8.05002").save
City.new(:country_id => "112", :name => "Bergamo", :aliases => "Bergam,Bergame,Bergamo,Berghem,Bergomum,BÃ¨rgam,BÃ¨rghem,BÃ©rgamo,BÃ©rghem,bei er jia mo,bergamo,berugamo,byrghamw,ÐÐµÑÐ³Ð°Ð¼Ð¾,Ø¨ÙØ±ØºØ§ÙÙ,à¤¬à¥à¤°à¥à¤à¤®à¥,ãã«ã¬ã¢,è´å°å è«,Bergamo", :latitude => "45.69798", :longitude => "9.66895").save
City.new(:country_id => "112", :name => "Benevento", :aliases => "Benevent,Benevento,Beneventum,Beneviento,Benewent,BÃ©nÃ©vent,benevu~ento,ÐÐµÐ½ÐµÐ²ÐµÐ½ÑÐ¾,áááááááá¢á,ããã´ã§ã³ã,Benevento", :latitude => "41.12952", :longitude => "14.78614").save
City.new(:country_id => "112", :name => "Belluno", :aliases => "Bellune,Belluno,Bellunum,Belun,berruno,ÐÐµÐ»Ð»ÑÐ½Ð¾,ããã«ã¼ã,Belluno", :latitude => "46.145", :longitude => "12.22139").save
City.new(:country_id => "112", :name => "Beinasco", :aliases => "Beinasch,Beinasco,beinasuko,ãã¤ãã¹ã³,Beinasco", :latitude => "45.02314", :longitude => "7.58392").save
City.new(:country_id => "112", :name => "Battipaglia", :aliases => "Battipaglia,Battipaglia", :latitude => "40.61091", :longitude => "14.98515").save
City.new(:country_id => "112", :name => "Bastia", :aliases => ",Bastia Umbra", :latitude => "43.06794", :longitude => "12.54556").save
City.new(:country_id => "112", :name => "Bassano del Grappa", :aliases => "Bassano,Bassano del Grappa", :latitude => "45.7676", :longitude => "11.7357").save
City.new(:country_id => "112", :name => "Baronissi", :aliases => "Baronissi,Baronissi", :latitude => "40.74771", :longitude => "14.77084").save
City.new(:country_id => "112", :name => "Barletta", :aliases => "Barletta,baruretta,ÐÐ°ÑÐ»ÐµÑÑÐ°,ãã«ã¬ãã¿,Barletta", :latitude => "41.31183", :longitude => "16.29077").save
City.new(:country_id => "112", :name => "Bari", :aliases => "Bari,Baris,Barium,Bary,Mpari,ba li,bali,bari,bary,ÎÏÎ¬ÏÎ¹,ÎÏÎ±ÏÎ¹,ÐÐ°ÑÐ¸,ÐÐ°ÑÑ,×××¨×,Ø¨Ø§Ø±Ù,Ø¨Ø§Ø±Û,à¤¬à¤°à¤¿,à¤¬à¤¾à¤°à¥,à¦¬à¦¾à¦°à¦¿,ááá á,ãã¼ãª,å·´é,ë°ë¦¬,Bari", :latitude => "41.11773", :longitude => "16.85118").save
City.new(:country_id => "112", :name => "Bareggio", :aliases => "Bareggio,barejjo,ãã¬ãã¸ã§,Bareggio", :latitude => "45.47506", :longitude => "8.9978").save
City.new(:country_id => "112", :name => "Bagnoli", :aliases => "Ban'oli,ÐÐ°Ð½ÑÐ¾Ð»Ð¸,Bagnoli", :latitude => "40.81322", :longitude => "14.16807").save
City.new(:country_id => "112", :name => "Bagno a Ripoli", :aliases => "Bagno a Ripoli,ãã¼ãã§ã»ã¢ã»ãªã¼ããª,Bagno a Ripoli", :latitude => "43.75115", :longitude => "11.32252").save
City.new(:country_id => "112", :name => "Bagnacavallo", :aliases => "Bagnacavallo,banyakavu~arro,ããã£ã«ã´ã¡ãã­,Bagnacavallo", :latitude => "44.41247", :longitude => "11.97713").save
City.new(:country_id => "112", :name => "Bacoli", :aliases => "Bacoli,Bauli,bakori,ãã¼ã³ãª,Bacoli", :latitude => "40.79926", :longitude => "14.07846").save
City.new(:country_id => "112", :name => "Avezzano", :aliases => "Aveccano,Avezzano,ÐÐ²ÐµÑÑÐ°Ð½Ð¾,Avezzano", :latitude => "42.04023", :longitude => "13.4388").save
City.new(:country_id => "112", :name => "Aversa", :aliases => "Aversa,Averza,avu~erusa,ÐÐ²ÐµÑÑÐ°,ã¢ã´ã§ã«ãµ,Aversa", :latitude => "40.97321", :longitude => "14.20493").save
City.new(:country_id => "112", :name => "Avellino", :aliases => "Abellinum,Avellino,avu~errino,ÐÐ²ÐµÐ»Ð»Ð¸Ð½Ð¾,ã¢ã´ã§ããªã¼ã,Avellino", :latitude => "40.91442", :longitude => "14.78874").save
City.new(:country_id => "112", :name => "Asti", :aliases => "Ast,Asti,Hasta Pompeia,asuti,ÐÑÑÐ¸,ã¢ã¹ãã£,Asti", :latitude => "44.89795", :longitude => "8.20684").save
City.new(:country_id => "112", :name => "Assisi", :aliases => "Asis,Asis - Assisi,Asisium,Asizi,Asizo,Assis,Assise,Assisi,Assizi,Asyz,AsyÅ¼,AsÃ­s,AsÃ­s - Assisi,asshiji,ÐÑÐ¸Ð·Ð¸,ÐÑÑÐ¸Ð·Ð¸,××¡×××,ã¢ãã·ã¸,Assisi", :latitude => "43.06914", :longitude => "12.61646").save
City.new(:country_id => "112", :name => "Ascoli Piceno", :aliases => "Ascoli,Ascoli Piceno,Askoli Picheno,Askoli-Picheno,ÐÑÐºÐ¾Ð»Ð¸ ÐÐ¸ÑÐµÐ½Ð¾,ÐÑÐºÐ¾Ð»Ð¸-ÐÐ¸ÑÐµÐ½Ð¾,ã¢ã¹ã³ãªã»ããã§ã¼ã,Ascoli Piceno", :latitude => "42.85483", :longitude => "13.5749").save
City.new(:country_id => "112", :name => "Arzignano", :aliases => "Arcin'jano,Arzignano,ÐÑÑÐ¸Ð½ÑÑÐ½Ð¾,Arzignano", :latitude => "45.51929", :longitude => "11.33859").save
City.new(:country_id => "112", :name => "Arzano", :aliases => "Arzano,arutsu~ano,ã¢ã«ãã¡ã¼ã,Arzano", :latitude => "40.91441", :longitude => "14.26713").save
City.new(:country_id => "112", :name => "Ariccia", :aliases => "Ariccia,Aricia,aritcha,ã¢ãªããã£,Ariccia", :latitude => "41.72012", :longitude => "12.67588").save
City.new(:country_id => "112", :name => "Ariano Irpino", :aliases => "Ariano Irpino,Ariano di Puglia,Ariano Irpino", :latitude => "41.14892", :longitude => "15.08334").save
City.new(:country_id => "112", :name => "Argenta", :aliases => "Argenta,arujenta,ÐÑÐ³ÐµÐ½ÑÐ°,ã¢ã«ã¸ã§ã³ã¿,Argenta", :latitude => "44.61237", :longitude => "11.83562").save
City.new(:country_id => "112", :name => "Arezzo", :aliases => "Arecco,ÐÑÐµÑÑÐ¾,Arezzo", :latitude => "43.46139", :longitude => "11.87691").save
City.new(:country_id => "112", :name => "Arese", :aliases => "Arese,areze,ã¢ã¬ã¼ã¼,Arese", :latitude => "45.55227", :longitude => "9.07654").save
City.new(:country_id => "112", :name => "Ardea", :aliases => "Ardea,arudea,ã¢ã«ãã¼ã¢,Ardea", :latitude => "41.6123", :longitude => "12.51433").save
City.new(:country_id => "112", :name => "Arcore", :aliases => "Arcore,Arculi,arukore,ã¢ã«ã³ã¬,Arcore", :latitude => "45.62668", :longitude => "9.32555").save
City.new(:country_id => "112", :name => "Aprilia", :aliases => "Aprilia,apuriria,ã¢ããªã¼ãªã¢,Aprilia", :latitude => "41.58951", :longitude => "12.65009").save
City.new(:country_id => "112", :name => "Aosta", :aliases => "Aosta,Aoste,Aouta,AoÃ»ta,Augusta Praetoria,aoseuta,aosuta,ÐÐ¾ÑÑÐ°,××××¡××,ã¢ãªã¹ã¿,ìì¤ì¤í,Aosta", :latitude => "45.73736", :longitude => "7.3166").save
City.new(:country_id => "112", :name => "Anzio", :aliases => "Ancio,Antium,Anzio,antsu~io,ÐÐ½ÑÐ¸Ð¾,ÐÐ½ÑÑÐ¾,ã¢ã³ãã£ãª,Anzio", :latitude => "41.44749", :longitude => "12.62707").save
City.new(:country_id => "112", :name => "Angri", :aliases => "Angri,Angri", :latitude => "40.74271", :longitude => "14.57144").save
City.new(:country_id => "112", :name => "Andria", :aliases => "Andria,Andrija,andoria,ÐÐ½Ð´ÑÐ¸Ñ,ã¢ã³ããªã¢,Andria", :latitude => "41.23063", :longitude => "16.29087").save
City.new(:country_id => "112", :name => "Ancona", :aliases => "Ancona,Ancone,Anconn-a,AncÃ´ne,Ankona,an ke na,ankona,ÐÐ½ÐºÐ¾Ð½Ð°,ã¢ã³ã³ã¼ã,å®ç§çº³,Ancona", :latitude => "43.59816", :longitude => "13.51008").save
City.new(:country_id => "112", :name => "Anagni", :aliases => "Anagni,Anagnia,Anagni", :latitude => "41.74472", :longitude => "13.15269").save
City.new(:country_id => "112", :name => "Altamura", :aliases => "Altamura,arutamura,ÐÐ»ÑÐ°Ð¼ÑÑÐ°,ã¢ã«ã¿ã ã¼ã©,Altamura", :latitude => "40.82923", :longitude => "16.55368").save
City.new(:country_id => "112", :name => "Alpignano", :aliases => "Alpignan,Alpignano,arupinyano,ã¢ã«ããã£ã¼ã,Alpignano", :latitude => "45.10195", :longitude => "7.52662").save
City.new(:country_id => "112", :name => "Alghero", :aliases => "Alghero,Alguer,Alguer - Alghero,Alguero,Alighera,L'Alguer,arugero,l'Alguer,ã¢ã«ã²ã¼ã­,Alghero", :latitude => "40.55889", :longitude => "8.31806").save
City.new(:country_id => "112", :name => "Alessandria", :aliases => "Alesandrija,Alessandria,Alessandrija,Alexandria,Alexandrie,Lissandria,aressandoria,aressandoria xian,ÐÐ»ÐµÑÐ°Ð½Ð´ÑÐ¸Ñ,ÐÐ»ÐµÑÑÐ°Ð½Ð´ÑÐ¸Ñ,ÐÐ»ÐµÑÑÐ°Ð½Ð´ÑÑÑ,ã¢ã¬ããµã³ããªã¢,ã¢ã¬ããµã³ããªã¢ç,Alessandria", :latitude => "44.91245", :longitude => "8.61894").save
City.new(:country_id => "112", :name => "Albino", :aliases => "Albino,arubino,ÐÐ»Ð±Ð¸Ð½Ð¾,ã¢ã«ãã¼ã,Albino", :latitude => "45.76378", :longitude => "9.79636").save
City.new(:country_id => "112", :name => "Albignasego", :aliases => "Albignasego,Albignasego", :latitude => "45.34749", :longitude => "11.86721").save
City.new(:country_id => "112", :name => "Albenga", :aliases => "Albemga,Albenga,Arbenga,Albenga", :latitude => "44.04997", :longitude => "8.21829").save
City.new(:country_id => "112", :name => "Albano Laziale", :aliases => "Albano,Albano Laziale,ã¢ã«ãã¼ãã»ã©ãã£ã¢ã¼ã¬,Albano Laziale", :latitude => "41.72873", :longitude => "12.6608").save
City.new(:country_id => "112", :name => "Alba", :aliases => "Al'bom,Alba,aruba,ÐÐ»ÑÐ±Ð¾Ð¼,ã¢ã«ã,Alba", :latitude => "44.6999", :longitude => "8.0347").save
City.new(:country_id => "112", :name => "Alatri", :aliases => "Alatri,ÐÐ»Ð°ÑÑÐ¸,Alatri", :latitude => "41.73062", :longitude => "13.3402").save
City.new(:country_id => "112", :name => "Agropoli", :aliases => "Agropoli,Agruopulo,Agropoli", :latitude => "40.3469", :longitude => "14.99655").save
City.new(:country_id => "112", :name => "Afragola", :aliases => "Afragola,Afravola,afuragora,ÐÑÑÐ°Ð³Ð¾Ð»Ð°,ã¢ãã©ã´ã¼ã©,Afragola", :latitude => "40.92601", :longitude => "14.31083").save
City.new(:country_id => "112", :name => "Adria", :aliases => "Adria,Adrija,ÐÐ´ÑÐ¸Ñ,Adria", :latitude => "45.05639", :longitude => "12.05778").save
City.new(:country_id => "112", :name => "Adelfia", :aliases => "Adelfia,aderufia,ã¢ãã«ãã£ã¢,Adelfia", :latitude => "41.00423", :longitude => "16.87169").save
City.new(:country_id => "112", :name => "Acqui Terme", :aliases => "Acqui,Acqui Citta,Acqui CittÃ ,Acqui Terme,Aich,Ãich,ã¢ãã¯ã¤ã»ãã«ã¡,Acqui Terme", :latitude => "44.67514", :longitude => "8.46755").save
City.new(:country_id => "112", :name => "Acquaviva delle Fonti", :aliases => "Acquaviva delle Fonti,ã¢ãã¯ã¢ã´ã£ã¼ã´ã¡ã»ããã¬ã»ãã©ã³ãã£,Acquaviva delle Fonti", :latitude => "40.89783", :longitude => "16.84249").save
City.new(:country_id => "112", :name => "Acerra", :aliases => "Acerra,Acerrae,acherra,ã¢ãã§ãã©,Acerra", :latitude => "40.95071", :longitude => "14.37623").save
City.new(:country_id => "112", :name => "Abbiategrasso", :aliases => "Abbiategrasso,Albiatum,abbiategurasso,ÐÐ±Ð±Ð¸Ð°ÑÐµÐ³ÑÐ°ÑÑÐ¾,ã¢ããã¢ãã°ã©ãã½,Abbiategrasso", :latitude => "45.39821", :longitude => "8.91678").save
City.new(:country_id => "112", :name => "Abano Terme", :aliases => "Abano,Abano Terme,Abano-Terme,ÐÐ±Ð°Ð½Ð¾ Ð¢ÐµÑÐ¼Ðµ,ÐÐ±Ð°Ð½Ð¾-Ð¢ÐµÑÐ¼Ðµ,ã¢ã¼ããã»ãã«ã¡,Abano Terme", :latitude => "45.36099", :longitude => "11.79141").save
City.new(:country_id => "112", :name => "Spinea", :aliases => "Spinea,supinea,ã¹ããã¼ã¢,Spinea", :latitude => "45.49306", :longitude => "12.16056").save
City.new(:country_id => "112", :name => "Verbania", :aliases => ",Verbania", :latitude => "45.92136", :longitude => "8.55183").save
City.new(:country_id => "112", :name => "Pieve Emanuele", :aliases => ",Pieve Emanuele", :latitude => "45.35052", :longitude => "9.20268").save
City.new(:country_id => "112", :name => "Lumezzane", :aliases => ",Lumezzane", :latitude => "45.64788", :longitude => "10.26487").save
City.new(:country_id => "112", :name => "Buccinasco", :aliases => ",Buccinasco", :latitude => "45.41617", :longitude => "9.10784").save
City.new(:country_id => "112", :name => "Guidonia Montecelio", :aliases => ",Guidonia Montecelio", :latitude => "41.99362", :longitude => "12.72238").save
City.new(:country_id => "112", :name => "Lamezia Terme", :aliases => ",Lamezia Terme", :latitude => "38.96589", :longitude => "16.3092").save
City.new(:country_id => "112", :name => "Cassano Magnago", :aliases => ",Cassano Magnago", :latitude => "45.66972", :longitude => "8.81996").save
City.new(:country_id => "112", :name => "Settimo Milanese", :aliases => ",Settimo Milanese", :latitude => "45.47771", :longitude => "9.05574").save
City.new(:country_id => "112", :name => "San Felice a Cancello", :aliases => ",San Felice a Cancello", :latitude => "41.00581", :longitude => "14.45583").save
City.new(:country_id => "112", :name => "San Nicola la Strada", :aliases => ",San Nicola la Strada", :latitude => "41.05181", :longitude => "14.33133").save
City.new(:country_id => "112", :name => "Quarto", :aliases => "Kvarto,ÐÐ²Ð°ÑÑÐ¾,Quarto", :latitude => "40.87681", :longitude => "14.13943").save
City.new(:country_id => "112", :name => "Tremestieri Etneo", :aliases => ",Tremestieri Etneo", :latitude => "37.58125", :longitude => "15.07089").save
City.new(:country_id => "112", :name => "Casavatore", :aliases => ",Casavatore", :latitude => "40.89921", :longitude => "14.27663").save
City.new(:country_id => "112", :name => "Volla", :aliases => ",Volla", :latitude => "40.87841", :longitude => "14.34293").save
City.new(:country_id => "112", :name => "Gravina di Catania", :aliases => ",Gravina di Catania", :latitude => "37.55555", :longitude => "15.06299").save
City.new(:country_id => "112", :name => "Cesano Boscone", :aliases => "Boscone,Cesano Boscone", :latitude => "45.44207", :longitude => "9.09445").save
City.new(:country_id => "112", :name => "Fonte Nuova", :aliases => ",Fonte Nuova", :latitude => "42.00167", :longitude => "12.62194").save
