City.new(:country_id => "114", :name => "Spanish Town", :aliases => "Saint Jago de la Vega,Spanis Taunas,Spanish Town,SpaniÅ¡ Taunas,sbanysh tawn,Ø³Ø¨Ø§ÙÙØ´ ØªØ§ÙÙ,ã¹ãããã·ã¥ã»ã¿ã¦ã³,Spanish Town", :latitude => "17.98333", :longitude => "-76.95").save
City.new(:country_id => "114", :name => "Portmore", :aliases => "Portmore,Portmore", :latitude => "17.97024", :longitude => "-76.86722").save
City.new(:country_id => "114", :name => "Old Harbour", :aliases => "Old Harbor,Old Harbour,Old Harbour", :latitude => "17.93333", :longitude => "-77.11667").save
City.new(:country_id => "114", :name => "New Kingston", :aliases => ",New Kingston", :latitude => "18.00747", :longitude => "-76.78319").save
City.new(:country_id => "114", :name => "Montego Bay", :aliases => "Mantica Bahia,Montego,Montego Bay,Montego Bejus,Montego BÄjus,Montego-Bej,ÐÐ¾Ð½ÑÐµÐ³Ð¾-ÐÐµÐ¹,ã¢ã³ãã´ã»ãã¤,Montego Bay", :latitude => "18.46667", :longitude => "-77.91667").save
City.new(:country_id => "114", :name => "May Pen", :aliases => ",May Pen", :latitude => "17.96667", :longitude => "-77.23333").save
City.new(:country_id => "114", :name => "Mandeville", :aliases => "Mandevil',Mandeville,ÐÐ°Ð½Ð´ÐµÐ²Ð¸Ð»Ñ,Mandeville", :latitude => "18.03333", :longitude => "-77.5").save
City.new(:country_id => "114", :name => "Linstead", :aliases => ",Linstead", :latitude => "18.13683", :longitude => "-77.03171").save
City.new(:country_id => "114", :name => "Kingston", :aliases => "Kin'nkston,Kingston,ÎÎ¯Î½Î³ÎºÏÏÎ¿Î½,ÐÐ¸Ð½Ð³ÑÑÐ¾Ð½,Kingston", :latitude => "17.99702", :longitude => "-76.79358").save
City.new(:country_id => "114", :name => "Half Way Tree", :aliases => ",Half Way Tree", :latitude => "18", :longitude => "-76.8").save
