City.new(:country_id => "151", :name => "Capitol Hill", :aliases => ",Capitol Hill", :latitude => "15.21083", :longitude => "145.75056").save
