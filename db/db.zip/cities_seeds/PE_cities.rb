City.new(:country_id => "176", :name => "Yurimaguas", :aliases => "Jurimaguas,Yurimaguas,Yurimahuas,Ð®ÑÐ¸Ð¼Ð°Ð³ÑÐ°Ñ,Yurimaguas", :latitude => "-5.9", :longitude => "-76.08333").save
City.new(:country_id => "176", :name => "Viru", :aliases => ",VirÃº", :latitude => "-8.41667", :longitude => "-78.75").save
City.new(:country_id => "176", :name => "Uchiza", :aliases => "Uchisa,Uchiza,Uchiza", :latitude => "-8.45917", :longitude => "-76.46333").save
City.new(:country_id => "176", :name => "Tumbes", :aliases => "Tumbes,Tumbez,Tumpiurbo,Tunpis,Ð¢ÑÐ¼Ð±ÐµÑ,Tumbes", :latitude => "-3.56667", :longitude => "-80.44139").save
City.new(:country_id => "176", :name => "Trujillo", :aliases => "Trujillo,Trukhil'o,Ð¢ÑÑÑÐ¸Ð»ÑÐ¾,Trujillo", :latitude => "-8.11599", :longitude => "-79.02998").save
City.new(:country_id => "176", :name => "Tocache Nuevo", :aliases => "San Juan de Tocache,Tocache,Tocache Nuevo,Tocache Nuevo", :latitude => "-8.18417", :longitude => "-76.5125").save
City.new(:country_id => "176", :name => "Tingo Maria", :aliases => "Leoncio Prado,Tingo Maria,Tingo MarÃ­a,Tingo MarÃ­a", :latitude => "-9.28951", :longitude => "-76.00876").save
City.new(:country_id => "176", :name => "Tambo Grande", :aliases => ",Tambo Grande", :latitude => "-4.92694", :longitude => "-80.34472").save
City.new(:country_id => "176", :name => "Talara", :aliases => "Puerto Talara,Talara,Ð¢Ð°Ð»Ð°ÑÐ°,Talara", :latitude => "-4.57722", :longitude => "-81.27194").save
City.new(:country_id => "176", :name => "Sullana", :aliases => "Sul'jana,Sullana,Ð¡ÑÐ»ÑÑÐ½Ð°,Sullana", :latitude => "-4.90389", :longitude => "-80.68528").save
City.new(:country_id => "176", :name => "Sechura", :aliases => "Sechura,Sechura", :latitude => "-5.55694", :longitude => "-80.82222").save
City.new(:country_id => "176", :name => "Santiago de Cao", :aliases => ",Santiago de Cao", :latitude => "-7.95889", :longitude => "-79.23917").save
City.new(:country_id => "176", :name => "San Pedro de Lloc", :aliases => "San Pedro,San Pedro de Lloc,San Pedro de Lloc", :latitude => "-7.43278", :longitude => "-79.50583").save
City.new(:country_id => "176", :name => "Zana", :aliases => "Sana,SaÃ±a,Zana,ZaÃ±a,ÐÐ°Ð½Ð°,ZaÃ±a", :latitude => "-6.92222", :longitude => "-79.58417").save
City.new(:country_id => "176", :name => "Rioja", :aliases => ",Rioja", :latitude => "-6.05861", :longitude => "-77.165").save
City.new(:country_id => "176", :name => "Querecotillo", :aliases => ",Querecotillo", :latitude => "-4.83778", :longitude => "-80.64556").save
City.new(:country_id => "176", :name => "Pucallpa", :aliases => "Callaria,Pucallpa,Pucalpa,Pukal'pa,Pulcalla,pu lan er pa,pukaruba,ÐÑÐºÐ°Ð»ÑÐ¿Ð°,ãã«ã«ã,æ®å°å°å¸,Pucallpa", :latitude => "-8.37915", :longitude => "-74.55387").save
City.new(:country_id => "176", :name => "Piura", :aliases => "Piura,PiÅ­ra,ÐÐ¸ÑÑÐ°,Piura", :latitude => "-5.2", :longitude => "-80.63333").save
City.new(:country_id => "176", :name => "Pimentel", :aliases => ",Pimentel", :latitude => "-6.83667", :longitude => "-79.93417").save
City.new(:country_id => "176", :name => "Picsi", :aliases => "Picsi,Piksi,Pisci,Pixi,ÐÐ¸ÐºÑÐ¸,Picsi", :latitude => "-6.71778", :longitude => "-79.76972").save
City.new(:country_id => "176", :name => "Paita", :aliases => "Paita,ÐÐ°Ð¸ÑÐ°,Paita", :latitude => "-5.08917", :longitude => "-81.11444").save
City.new(:country_id => "176", :name => "Paijan", :aliases => ",PaijÃ¡n", :latitude => "-7.73333", :longitude => "-79.30222").save
City.new(:country_id => "176", :name => "Pacasmayo", :aliases => "Pacasmayo,Puerto de Pacasmayo,Pacasmayo", :latitude => "-7.40056", :longitude => "-79.57139").save
City.new(:country_id => "176", :name => "Moyobamba", :aliases => "Moiobamba,Mojobamba,Moyobamba,ÐÐ¾Ð¹Ð¾Ð±Ð°Ð¼Ð±Ð°,Moyobamba", :latitude => "-6.05", :longitude => "-76.96667").save
City.new(:country_id => "176", :name => "Monsefu", :aliases => ",MonsefÃº", :latitude => "-6.87806", :longitude => "-79.87222").save
City.new(:country_id => "176", :name => "Moche", :aliases => ",Moche", :latitude => "-8.17111", :longitude => "-79.00917").save
City.new(:country_id => "176", :name => "Marcavelica", :aliases => "Marcavelica,Marcavelica Hacienda,Marcavelica", :latitude => "-4.87778", :longitude => "-80.70528").save
City.new(:country_id => "176", :name => "La Union", :aliases => ",La UniÃ³n", :latitude => "-5.4", :longitude => "-80.75").save
City.new(:country_id => "176", :name => "Laredo", :aliases => "Laredo,Laredo Hacienda,ÐÐ°ÑÐµÐ´Ð¾,Laredo", :latitude => "-8.1", :longitude => "-78.95").save
City.new(:country_id => "176", :name => "La Peca", :aliases => "La Peca,La Peca Nueva,La Peca", :latitude => "-5.61111", :longitude => "-78.435").save
City.new(:country_id => "176", :name => "Lambayeque", :aliases => "Lambajeke,Lambayeque,ÐÐ°Ð¼Ð±Ð°Ð¹ÐµÐºÐµ,Lambayeque", :latitude => "-6.70111", :longitude => "-79.90611").save
City.new(:country_id => "176", :name => "Juanjui", :aliases => ",JuanjuÃ­", :latitude => "-7.17785", :longitude => "-76.73135").save
City.new(:country_id => "176", :name => "Jaen", :aliases => "Jaen,JaÃ©n,Khaehn,Ð¥Ð°ÑÐ½,JaÃ©n", :latitude => "-5.70806", :longitude => "-78.80472").save
City.new(:country_id => "176", :name => "Iquitos", :aliases => "Ikitos,Ikitosas,Iquitos,Iquitum,ÐÐºÐ¸ÑÐ¾Ñ,×××§××××¡,Iquitos", :latitude => "-3.74806", :longitude => "-73.24722").save
City.new(:country_id => "176", :name => "Huaraz", :aliases => "Huaras,Huaraz,Uaras,Waras,Ð£Ð°ÑÐ°Ñ,Huaraz", :latitude => "-9.53333", :longitude => "-77.53333").save
City.new(:country_id => "176", :name => "Huanuco", :aliases => "Huanuco,Huanucum,HuÃ¡nuco,Uanuko,Wanuku,Å¬anuko,Ð£Ð°Ð½ÑÐºÐ¾,HuÃ¡nuco", :latitude => "-9.9329", :longitude => "-76.24153").save
City.new(:country_id => "176", :name => "Huamachuco", :aliases => ",Huamachuco", :latitude => "-7.8", :longitude => "-78.06667").save
City.new(:country_id => "176", :name => "Guadalupe", :aliases => ",Guadalupe", :latitude => "-7.25", :longitude => "-79.48333").save
City.new(:country_id => "176", :name => "Ferrenafe", :aliases => "Ferrenafe,FerreÃ±afe,Terrenafe,TerreÃ±afe,FerreÃ±afe", :latitude => "-6.63889", :longitude => "-79.78889").save
City.new(:country_id => "176", :name => "Coishco", :aliases => "Coisco,Coishco,Coshco,Coishco", :latitude => "-9.02306", :longitude => "-78.61556").save
City.new(:country_id => "176", :name => "Chulucanas", :aliases => "Chulucana,Chulucanas,Chulukanasa,Ð§ÑÐ»ÑÐºÐ°Ð½Ð°ÑÐ°,Chulucanas", :latitude => "-5.0925", :longitude => "-80.1625").save
City.new(:country_id => "176", :name => "Chongoyape", :aliases => ",Chongoyape", :latitude => "-6.64056", :longitude => "-79.38917").save
City.new(:country_id => "176", :name => "Chocope", :aliases => ",Chocope", :latitude => "-7.79139", :longitude => "-79.22167").save
City.new(:country_id => "176", :name => "Chimbote", :aliases => "Chimbote,Ð§Ð¸Ð¼Ð±Ð¾ÑÐµ,Chimbote", :latitude => "-9.08528", :longitude => "-78.57833").save
City.new(:country_id => "176", :name => "Chiclayo", :aliases => "Chiclayo,Chiklajo,Chiklayu,Ciclaium,Ciklajas,Äiklajas,Ð§Ð¸ÐºÐ»Ð°Ð¹Ð¾,Chiclayo", :latitude => "-6.77361", :longitude => "-79.84167").save
City.new(:country_id => "176", :name => "Chepen", :aliases => ",ChepÃ©n", :latitude => "-7.21667", :longitude => "-79.45").save
City.new(:country_id => "176", :name => "Chachapoyas", :aliases => "Chachapoias,Chachapoyas,Chachapuyas,Chachapoyas", :latitude => "-6.23169", :longitude => "-77.86903").save
City.new(:country_id => "176", :name => "Catacaos", :aliases => "Catacaos,Catacaos", :latitude => "-5.26667", :longitude => "-80.68333").save
City.new(:country_id => "176", :name => "Cajamarca", :aliases => "Cajamarca,Caxamarca,Kachamarka,Kakhamarka,Kasamarko,KaÅamarko,Qasha Marka,Qashamarka,ÐÐ°ÑÐ°Ð¼Ð°ÑÐºÐ°,Cajamarca", :latitude => "-7.16378", :longitude => "-78.50027").save
City.new(:country_id => "176", :name => "Bellavista", :aliases => ",Bellavista", :latitude => "-7.05614", :longitude => "-76.5911").save
City.new(:country_id => "176", :name => "Bagua Grande", :aliases => ",Bagua Grande", :latitude => "-5.75611", :longitude => "-78.44111").save
City.new(:country_id => "176", :name => "La Breita", :aliases => "La Brea,La Breita,La Breita", :latitude => "-4.26083", :longitude => "-80.8875").save
City.new(:country_id => "176", :name => "Zarumilla", :aliases => ",Zarumilla", :latitude => "-3.50306", :longitude => "-80.27306").save
City.new(:country_id => "176", :name => "Yunguyo", :aliases => ",Yunguyo", :latitude => "-16.25", :longitude => "-69.08333").save
City.new(:country_id => "176", :name => "Yanacancha", :aliases => "Yanacancha,Yanacocha,Yanacancha", :latitude => "-10.24111", :longitude => "-76.64556").save
City.new(:country_id => "176", :name => "Tarma", :aliases => "Tarma,Ð¢Ð°ÑÐ¼Ð°,Tarma", :latitude => "-11.41972", :longitude => "-75.69083").save
City.new(:country_id => "176", :name => "Tambopata", :aliases => ",Tambopata", :latitude => "-12.73333", :longitude => "-69.18333").save
City.new(:country_id => "176", :name => "Tacna", :aliases => "Tacna,Takna,Taqna,Ð¢Ð°ÐºÐ½Ð°,Tacna", :latitude => "-18.00556", :longitude => "-70.24833").save
City.new(:country_id => "176", :name => "Sicuani", :aliases => ",Sicuani", :latitude => "-14.26944", :longitude => "-71.22611").save
City.new(:country_id => "176", :name => "Satipo", :aliases => "San Francisco de Satipo,Satipo,Satipo", :latitude => "-11.25222", :longitude => "-74.63861").save
City.new(:country_id => "176", :name => "San Vicente de Canete", :aliases => "Canete,CaÃ±ete,Pueblo Nuevo,San Vicente de Canete,San Vicente de CaÃ±ete,San Vicente de CaÃ±ete", :latitude => "-13.07512", :longitude => "-76.38352").save
City.new(:country_id => "176", :name => "Santa Ana", :aliases => ",Santa Ana", :latitude => "-12.86667", :longitude => "-72.71667").save
City.new(:country_id => "176", :name => "San Isidro", :aliases => ",San Isidro", :latitude => "-12.11667", :longitude => "-77.05").save
City.new(:country_id => "176", :name => "San Clemente", :aliases => ",San Clemente", :latitude => "-13.66667", :longitude => "-76.15").save
City.new(:country_id => "176", :name => "Puno", :aliases => "Punas,Puno,Punum,puno,ÐÑÐ½Ð¾,ãã¼ã,Puno", :latitude => "-15.83333", :longitude => "-70.03333").save
City.new(:country_id => "176", :name => "Puerto Maldonado", :aliases => "Maldonado,Portus Maldonatus,Puehrto-Mal'donado,Puerto Maldonado,puerutomarudonado,ÐÑÑÑÑÐ¾-ÐÐ°Ð»ÑÐ´Ð¾Ð½Ð°Ð´Ð¾,ãã¨ã«ããã«ããã,Puerto Maldonado", :latitude => "-12.6", :longitude => "-69.18333").save
City.new(:country_id => "176", :name => "Pisco", :aliases => "Pisco,Pisko,ÐÐ¸ÑÐºÐ¾,Pisco", :latitude => "-13.7", :longitude => "-76.21667").save
City.new(:country_id => "176", :name => "Paramonga", :aliases => "Hacienda Paramonga,Paramonga,Paramonga Hacienda,Parmonga,ÐÐ°ÑÐ°Ð¼Ð¾Ð½Ð³Ð°,Paramonga", :latitude => "-10.66667", :longitude => "-77.83333").save
City.new(:country_id => "176", :name => "Nuevo Imperial", :aliases => ",Nuevo Imperial", :latitude => "-13.07541", :longitude => "-76.31719").save
City.new(:country_id => "176", :name => "Nazca", :aliases => "Nasca,Naska,Nazca,Placa de Nazca,Plaskowyz Nazca,Provincia de Nazca,PÅaskowyÅ¼ Nazca,ÐÐ°ÑÐºÐ°,Nazca", :latitude => "-14.83333", :longitude => "-74.95").save
City.new(:country_id => "176", :name => "Moquegua", :aliases => "Mokegua,Moquegua,ÐÐ¾ÐºÐµÐ³ÑÐ°,Moquegua", :latitude => "-17.19556", :longitude => "-70.93528").save
City.new(:country_id => "176", :name => "Mollendo", :aliases => "Mol'endo,Mollendo,ÐÐ¾Ð»ÑÐµÐ½Ð´Ð¾,Mollendo", :latitude => "-17.02306", :longitude => "-72.01472").save
City.new(:country_id => "176", :name => "Minas de Marcona", :aliases => "Marcona,Mina Marcona,Minas de Marcona,Minas de Marcona", :latitude => "-15.21194", :longitude => "-75.11028").save
City.new(:country_id => "176", :name => "Mala", :aliases => ",Mala", :latitude => "-12.65806", :longitude => "-76.63083").save
City.new(:country_id => "176", :name => "Lima", :aliases => "Lima,Limo,LÃ­ma,li ma,lima,lyma,lymh,rima,ÎÎ¯Î¼Î±,ÐÐ¸Ð¼Ð°,ÐÑÐ¼Ð°,××××,ÙÙÙØ§,ÙÛÙØ§,à¸¥à¸´à¸¡à¸²,áá,ãªã,å©é¦¬,ë¦¬ë§,Lima", :latitude => "-12.04318", :longitude => "-77.02824").save
City.new(:country_id => "176", :name => "La Oroya", :aliases => "La Oroya,La-Oroja,Oroya,ÐÐ°-ÐÑÐ¾Ð¹Ð°,La Oroya", :latitude => "-11.51893", :longitude => "-75.89935").save
City.new(:country_id => "176", :name => "Junin", :aliases => ",JunÃ­n", :latitude => "-11.15889", :longitude => "-75.99306").save
City.new(:country_id => "176", :name => "Juliaca", :aliases => "Juliaca,Juliaca", :latitude => "-15.5", :longitude => "-70.13333").save
City.new(:country_id => "176", :name => "Jauja", :aliases => "Jauja,Khaukha,Ð¥Ð°ÑÑÐ°,Jauja", :latitude => "-11.77584", :longitude => "-75.49656").save
City.new(:country_id => "176", :name => "Imperial", :aliases => ",Imperial", :latitude => "-13.05927", :longitude => "-76.35269").save
City.new(:country_id => "176", :name => "Ilo", :aliases => "Ilo,New Ilo,Pacocha,ÐÐ»Ð¾,Ilo", :latitude => "-17.63944", :longitude => "-71.3375").save
City.new(:country_id => "176", :name => "Ilave", :aliases => "Ilave,Ylave,Ilave", :latitude => "-16.08333", :longitude => "-69.66667").save
City.new(:country_id => "176", :name => "Ica", :aliases => "Ica,Ika,ÐÐºÐ°,Ica", :latitude => "-14.06528", :longitude => "-75.73083").save
City.new(:country_id => "176", :name => "Huaura", :aliases => ",Huaura", :latitude => "-11.07", :longitude => "-77.59944").save
City.new(:country_id => "176", :name => "Huarmey", :aliases => "Huarmei,Huarmey,Puerto de Huarmey,Huarmey", :latitude => "-10.06806", :longitude => "-78.15222").save
City.new(:country_id => "176", :name => "Huaral", :aliases => ",Huaral", :latitude => "-11.495", :longitude => "-77.20778").save
City.new(:country_id => "176", :name => "Huanta", :aliases => ",Huanta", :latitude => "-12.93333", :longitude => "-74.25").save
City.new(:country_id => "176", :name => "Huancayo", :aliases => "Huancaium,Huancaya,Huancayo,Uankajo,Wankayu,Ð£Ð°Ð½ÐºÐ°Ð¹Ð¾,Huancayo", :latitude => "-12.06667", :longitude => "-75.23333").save
City.new(:country_id => "176", :name => "Huancavelica", :aliases => "Huancavelica,Uankavelika,Wankawillka,Ð£Ð°Ð½ÐºÐ°Ð²ÐµÐ»Ð¸ÐºÐ°,Huancavelica", :latitude => "-12.76667", :longitude => "-74.98333").save
City.new(:country_id => "176", :name => "Hualmay", :aliases => ",Hualmay", :latitude => "-11.09639", :longitude => "-77.61389").save
City.new(:country_id => "176", :name => "Huacho", :aliases => "Huacho,Uacho,Ð£Ð°ÑÐ¾,Huacho", :latitude => "-11.10667", :longitude => "-77.605").save
City.new(:country_id => "176", :name => "Cusco", :aliases => "Ciudad del Cuzco,Cusco,Cuscum,Cuzco,Kuskas,Kusko,Qusqu,ku si ke,kuseuko,kusuko,kwzkw,qwsqw,ÐÑÑÐºÐ¾,×§××¡×§×,ÙÙØ²ÙÙ,Ú©ÙØ²Ú©Ù,ã¯ã¹ã³,åº«æ¯ç§,ì¿ ì¤ì½,Cusco", :latitude => "-13.51833", :longitude => "-71.97806").save
City.new(:country_id => "176", :name => "Chosica", :aliases => "Chosica,Nueva Chosica,Chosica", :latitude => "-11.94306", :longitude => "-76.70944").save
City.new(:country_id => "176", :name => "Chincha Alta", :aliases => "Chincha Alta,Chincha Alta", :latitude => "-13.40985", :longitude => "-76.13235").save
City.new(:country_id => "176", :name => "Chaupimarca", :aliases => ",Chaupimarca", :latitude => "-10.43333", :longitude => "-76.53333").save
City.new(:country_id => "176", :name => "Chancay", :aliases => ",Chancay", :latitude => "-11.57139", :longitude => "-77.26722").save
City.new(:country_id => "176", :name => "Cerro de Pasco", :aliases => "Cerro de Pasco,Collis Pasca,Serro-de-Pasko,Ð¡ÐµÑÑÐ¾-Ð´Ðµ-ÐÐ°ÑÐºÐ¾,Cerro de Pasco", :latitude => "-10.68333", :longitude => "-76.26667").save
City.new(:country_id => "176", :name => "Camana", :aliases => "Camana,CamanÃ¡,CamanÃ¡", :latitude => "-16.62278", :longitude => "-72.71111").save
City.new(:country_id => "176", :name => "Callao", :aliases => "Callao,El Callao,Kaljao,Kallao,Kallaw,Regio de Callao,RegiÃ³ de Callao,ka ya e,kayao,ÐÐ°Ð»ÑÐ¾,ã«ã¤ãª,å¡äºä¿,Callao", :latitude => "-12.06667", :longitude => "-77.15").save
City.new(:country_id => "176", :name => "Barranca", :aliases => ",Barranca", :latitude => "-10.75", :longitude => "-77.76667").save
City.new(:country_id => "176", :name => "Ayaviri", :aliases => ",Ayaviri", :latitude => "-14.88639", :longitude => "-70.58889").save
City.new(:country_id => "176", :name => "Ayacucho", :aliases => "Ajakucho,Ayacucho,Wamanqa,ÐÑÐºÑÑÐ¾,Ayacucho", :latitude => "-13.15833", :longitude => "-74.22389").save
City.new(:country_id => "176", :name => "Arequipa", :aliases => "Arekipa,Arekipo,Arequipa,Arikipa,Ariqipa,arekipa,ÐÑÐµÐºÐ¸Ð¿Ð°,××¨×§××¤×,ã¢ã¬ã­ã,Arequipa", :latitude => "-16.39889", :longitude => "-71.535").save
City.new(:country_id => "176", :name => "Andahuaylas", :aliases => "Andahuailas,Andahuavlas,Andahuaylas,Andahuaylas", :latitude => "-13.65556", :longitude => "-73.38722").save
City.new(:country_id => "176", :name => "Abancay", :aliases => "Abancai,Abancaius,Abancay,Abankaj,Abankay,Awankay,a ban kai,ÐÐ±Ð°Ð½ÐºÐ°Ð¹,é¿ç­å¯,Abancay", :latitude => "-13.63389", :longitude => "-72.88139").save
City.new(:country_id => "176", :name => "La Rinconada", :aliases => ",La Rinconada", :latitude => "-14.63126", :longitude => "-69.44638").save
