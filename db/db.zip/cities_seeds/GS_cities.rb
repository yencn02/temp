City.new(:country_id => "92", :name => "Grytviken", :aliases => "Grjutviken,Grytviken,ÐÑÑÑÐ²Ð¸ÐºÐµÐ½,Grytviken", :latitude => "-54.28111", :longitude => "-36.5092").save
