City.new(:country_id => "177", :name => "Punaauia", :aliases => "Punaauia,Punaavia,Punaauia", :latitude => "-17.63333", :longitude => "-149.6").save
City.new(:country_id => "177", :name => "Papeete", :aliases => "Pape'ete,Papeehte,Papeete,PapeetÄ,Papeiti,Papete,Papeâete,Papiete,Papiti,Vaiete,papete,papiete,ÐÐ°Ð¿ÐµÐµÑÐµ,ÐÐ°Ð¿ÐµÑÐµ,ÐÐ°Ð¿ÐµÑÑÐµ,ããã¼ã,íí¼ìí,Papeete", :latitude => "-17.53333", :longitude => "-149.56667").save
City.new(:country_id => "177", :name => "Faaa", :aliases => "Faaa,Torea,Faaa", :latitude => "-17.55", :longitude => "-149.6").save
