City.new(:country_id => "235", :name => "Nukus", :aliases => "Nukus,Nukusas,nukuseu,nukusu,nwkws,ÐÑÐºÑÑ,ÙÙÚ©ÙØ³,ãã¯ã¹,ëì¿ ì¤,Nukus", :latitude => "42.45306", :longitude => "59.61028").save
City.new(:country_id => "235", :name => "Khujayli", :aliases => "Khodzheili,Khodzhejli,Khodzheyli,Khojeili,Khujayli,KhÅ­jayli,Ð¥Ð¾Ð´Ð¶ÐµÐ¹Ð»Ð¸,KhÅ­jayli", :latitude => "42.40472", :longitude => "59.45167").save
City.new(:country_id => "235", :name => "Chimboy", :aliases => "Chimbai,Chimbay,Chimboj,Chimboy,Ð§Ð¸Ð¼Ð±Ð¾Ð¹,Chimboy", :latitude => "42.93583", :longitude => "59.77528").save
City.new(:country_id => "235", :name => "Oltinkul", :aliases => "Altynkul',Altynkulâ,Oltinkul,OltinkÅ­l,OltinkÅ­l", :latitude => "43.07444", :longitude => "58.89333").save
City.new(:country_id => "235", :name => "Zomin", :aliases => "Saamin,Zaamin,Zomin,ÐÐ¾Ð¼Ð¸Ð½,Zomin", :latitude => "39.96056", :longitude => "68.39583").save
City.new(:country_id => "235", :name => "Urgut", :aliases => "Urgut,Ð£ÑÐ³ÑÑ,Urgut", :latitude => "39.40222", :longitude => "67.24306").save
City.new(:country_id => "235", :name => "Tirmiz", :aliases => "Termez,Termiz,Tirmiz,tai er mei zi,trmdh,trmz,Ð¢ÐµÑÐ¼ÐµÐ·,××¨××,ØªØ±ÙØ°,ØªØ±ÙØ²,æ³°å°æ¢å¹,Tirmiz", :latitude => "37.22417", :longitude => "67.27833").save
City.new(:country_id => "235", :name => "Sho'rchi", :aliases => "Chourtchi,Dzhalair,Kul'-Tepe,Kulâ-Tepe,Sho'rchi,Shoârchi,Shurchi,ShÅ­rchi,Shoârchi", :latitude => "37.99944", :longitude => "67.7875").save
City.new(:country_id => "235", :name => "Shahrisabz", :aliases => "Schachrissjabs,Shahri-i-Sabz,Shahrisabz,Shakhrisabz,Shakhrisabzs,Shakhrisyabz,Ð¨Ð°ÑÑÐ¸ÑÐ°Ð±Ð·,Shahrisabz", :latitude => "39.05778", :longitude => "66.83417").save
City.new(:country_id => "235", :name => "Samarqand", :aliases => "Samarcanda,Samarcande,Samarkand,Samarkanda,Samarkandas,Samarkando,Samarqand,Semerkand,sa ma er han,samaleukanteu,samarukando,smrqnd,Ð¡Ð°Ð¼Ð°ÑÐºÐ°Ð½Ð´,×¡××¨×§× ×,Ø³ÙØ±ÙÙØ¯,Ø³ÛÙÛØ±ÙÛÙØ¯,ãµãã«ã«ã³ã,æé¦¬ç¾ç½,æé©¬å°ç½,ì¬ë§ë¥´ì¹¸í¸,Samarqand", :latitude => "39.65417", :longitude => "66.95972").save
City.new(:country_id => "235", :name => "Qarshi", :aliases => "Bek Budi,Karaki,Karshi,Karsi,Qarshi,Qarsi,QarÅ¡i,nkhshb,ÐÐ°ÑÑÐ¸,ÐÐ°ÑÑÑ,ÙØ®Ø´Ø¨,Qarshi", :latitude => "38.86667", :longitude => "65.8").save
City.new(:country_id => "235", :name => "Muborak", :aliases => "Maburek,Mubarek,Muborak,ÐÑÐ±Ð¾ÑÐ°Ðº,Muborak", :latitude => "39.25528", :longitude => "65.15278").save
City.new(:country_id => "235", :name => "Kitob", :aliases => "Kitab,Kitob,ÐÐ¸ÑÐ¾Ð±,Kitob", :latitude => "39.11806", :longitude => "66.87556").save
City.new(:country_id => "235", :name => "Kattaqo'rg'on", :aliases => "Kattakurgan,Kattaqo'rg'on,Kattaqoârgâon,Kattaqurghon,KattaqÅ­rghon,Kattaqoârgâon", :latitude => "39.89889", :longitude => "66.25611").save
City.new(:country_id => "235", :name => "Koson", :aliases => "Kasan,Kassan,Koson,ÐÐ¾ÑÐ¾Ð½,Koson", :latitude => "39.0375", :longitude => "65.585").save
City.new(:country_id => "235", :name => "Karakul'", :aliases => "Kara Kal,Karakul',Karakulâ,Qorakul,QorakÅ­l,ÐÐ°ÑÐ°ÐºÑÐ»Ñ,Karakulâ", :latitude => "39.53333", :longitude => "63.83333").save
City.new(:country_id => "235", :name => "Qamashi", :aliases => "Kamashi,Kamyshi,Qamashi", :latitude => "38.82417", :longitude => "66.46083").save
City.new(:country_id => "235", :name => "Kogon", :aliases => "Kagan,Kogon,Novaya Bukhara,ÐÐ°Ð³Ð°Ð½,Kogon", :latitude => "39.72278", :longitude => "64.55167").save
City.new(:country_id => "235", :name => "G'uzor", :aliases => "G'uzor,Ghuzor,Gusar,Guzar,Gâuzor,Gâuzor", :latitude => "38.62083", :longitude => "66.24806").save
City.new(:country_id => "235", :name => "Galaosiyo", :aliases => "Galaasiya,Galaassiya,Galaosiyo,Gallya-Asiya,Gallya-Assiya,Galaosiyo", :latitude => "39.85778", :longitude => "64.44833").save
City.new(:country_id => "235", :name => "Juma", :aliases => "Dzhuma,Juma,Juma", :latitude => "39.71611", :longitude => "66.66417").save
City.new(:country_id => "235", :name => "Denov", :aliases => "Dehnan,Denan,Denau,Denov,Denow,Deynau,ÐÐµÐ½Ð¾Ð²,Denov", :latitude => "38.26667", :longitude => "67.9").save
City.new(:country_id => "235", :name => "Chiroqchi", :aliases => "Chirakchi,Chirakchya,Chiroqchi,Chiroqchi", :latitude => "39.03361", :longitude => "66.57222").save
City.new(:country_id => "235", :name => "Chelak", :aliases => "Chelak,Chelek,Payaryk,Chelak", :latitude => "39.92028", :longitude => "66.86111").save
City.new(:country_id => "235", :name => "Bulung'ur", :aliases => "Bulung'ur,Bulunghur,Bulungâur,Krasnogvardeiskoye,Krasnogvardeysk,Krasnogvardeyskaya,Krasnogvardeyskoye,Krasnogvardskiy,Rostovtsevo,Bulungâur", :latitude => "39.76472", :longitude => "67.27139").save
City.new(:country_id => "235", :name => "Buxoro", :aliases => "Alt-Buchara,Bokhara,Boukhara,Bucara,Buchara,Buhara,Bujara,Bukhara,BukharÃ ,Bukhoro,Buxoro,Staraya Bukhara,bkhara,bkhary,bu ha la,buhala,buhara,bukhara,bwkrh,ÐÑÑÐ°ÑÐ°,ÐÑÑÐ¾ÑÐ¾,××××¨×,Ø¨Ø®Ø§Ø±Ø§,Ø¨Ø®Ø§Ø±Ù,à¤¬à¥à¤à¤¾à¤°à¤¾,áá£á®áá á,ããã©,å¸åæ,ë¶íë¼,Buxoro", :latitude => "39.77472", :longitude => "64.42861").save
City.new(:country_id => "235", :name => "Beshkent", :aliases => "Beshkent,Bish-Kent,ÐÐµÑÐºÐµÐ½Ñ,Beshkent", :latitude => "38.82139", :longitude => "65.65306").save
City.new(:country_id => "235", :name => "Boysun", :aliases => "Baisuk,Baisun,Baysun,Bojsun,Boysun,ÐÐ¾Ð¹ÑÑÐ½,Boysun", :latitude => "38.20611", :longitude => "67.19861").save
City.new(:country_id => "235", :name => "Oqtosh", :aliases => "Aktash,Oqtosh,Oqtosh", :latitude => "39.92139", :longitude => "65.92528").save
City.new(:country_id => "235", :name => "Zarafshon", :aliases => "Sugrali,Sugraly,Zarafshan,Zarafshon,ÐÐ°ÑÐ°ÑÑÐ°Ð½,Zarafshon", :latitude => "41.57917", :longitude => "64.2075").save
City.new(:country_id => "235", :name => "Zafar", :aliases => "Almazar,Olmazor,Vrevskiy,Zafar,ÐÐ°ÑÐ°Ñ,Zafar", :latitude => "40.98333", :longitude => "68.9").save
City.new(:country_id => "235", :name => "Yaypan", :aliases => "Bazar-Yaypan,Jajpan,Yaipan,Yaypan,Ð¯Ð¹Ð¿Ð°Ð½,Yaypan", :latitude => "40.37583", :longitude => "70.81556").save
City.new(:country_id => "235", :name => "Yangiyul", :aliases => "Jangijul',Kaunchi,Ð¯Ð½Ð³Ð¸ÑÐ»Ñ,YangiyÅ­l", :latitude => "41.11202", :longitude => "69.0471").save
City.new(:country_id => "235", :name => "Yangiyer", :aliases => "Jangier,Ungi-Yere,Yangier,Yangiyer,Ð¯Ð½Ð³Ð¸ÐµÑ,Yangiyer", :latitude => "40.275", :longitude => "68.8225").save
City.new(:country_id => "235", :name => "Yangirabod", :aliases => "Yangirabad,Yangirabod,Yangirabod", :latitude => "40.03", :longitude => "65.96083").save
City.new(:country_id => "235", :name => "Yangiqo`rg`on", :aliases => "Yangikurgan,Yangiqo`rg`on,Yangiqoârgâon,Yangiqurghon,YangiqÅ­rghon,Yangiqoârgâon", :latitude => "41.18722", :longitude => "71.73333").save
City.new(:country_id => "235", :name => "Yangiobod", :aliases => "Jangiabad,Yangiabad,Ð¯Ð½Ð³Ð¸Ð°Ð±Ð°Ð´,Yangiobod", :latitude => "41.11919", :longitude => "70.09406").save
City.new(:country_id => "235", :name => "Wobkent", :aliases => "Vabkend,Vabkent,Wobkent,Wobkent", :latitude => "40.03028", :longitude => "64.515").save
City.new(:country_id => "235", :name => "Uychi", :aliases => "Uichi,Ujchi,Uychi,Ð£Ð¹ÑÐ¸,Uychi", :latitude => "41.08073", :longitude => "71.92331").save
City.new(:country_id => "235", :name => "Urganch", :aliases => "Novo-Urgench,Ourguentch,Urganch,Urgench,Urgentj,Yrgench,uleugenchi,urugenchi,Ð£ÑÐ³ÐµÐ½Ñ,ã¦ã«ã²ã³ã,ì°ë¥´ê²ì¹,Urganch", :latitude => "41.55", :longitude => "60.63333").save
City.new(:country_id => "235", :name => "Dashtobod", :aliases => "Dashtobod,Ul'yanovo,Ulâyanovo,Dashtobod", :latitude => "40.12694", :longitude => "68.49444").save
City.new(:country_id => "235", :name => "Uchqurghon", :aliases => "Uchkurgan,Uchqurghon,UchqÅ­rghon,UchqÅ­rghon", :latitude => "41.11816", :longitude => "72.0985").save
City.new(:country_id => "235", :name => "Tuytepa", :aliases => "Toi-Tjube,Toi-Tyube,Tojtepa,Toy-Tyube,Toytepa,Tuytepa,TÅ­ytepa,Ð¢Ð¾Ð¹ÑÐµÐ¿Ð°,TÅ­ytepa", :latitude => "41.0321", :longitude => "69.36253").save
City.new(:country_id => "235", :name => "Turagurghon", :aliases => "Turagurghon,Turakurgan,Tyurya-Kurgan,TÅ­ragÅ­rghon,TÅ­ragÅ­rghon", :latitude => "40.99984", :longitude => "71.51162").save
City.new(:country_id => "235", :name => "Toshloq", :aliases => "Tashlak,Toshloq,Toshloq", :latitude => "40.47722", :longitude => "71.76778").save
City.new(:country_id => "235", :name => "Tashkent", :aliases => "Ta.kent,Tachkent,Taschkent,Tashken,Tashkend,Tashkent,Tasjkent,Taskende,Taskent,Taskentas,Taskento,Taszkent,TaÅkento,TaÅkent,TaÅ¡kent,TaÅ¡kentas,Toshkand,Toshkent,Toshkent shahri,ta shen gan,tashknd,tashukento,tasyukenteu,thach khen t,tshqnd,tsqnt,Î¤Î±ÏÎºÎ­Î½Î´Î·,Ð¢Ð°ÑÐºÐµÐ½,Ð¢Ð°ÑÐºÐµÐ½Ñ,Ð¢Ð¾ÑÐºÐ°Ð½Ð´,××©×§× ×,ØªØ§Ø´ÙÛÙØª,ØªØ§Ø´Ú©ÙØ¯,Ø·Ø´ÙÙØ¯,à¸à¸²à¸à¹à¸à¸à¸à¹,á¢áá¨áááá¢á,á³á½á¬ááµ,ã¿ã·ã¥ã±ã³ã,å¡ä»å¹²,íìì¼í¸,Tashkent", :latitude => "41.26465", :longitude => "69.21627").save
City.new(:country_id => "235", :name => "Toshbuloq", :aliases => "Tashbulak,Toshbuloq,Toshbuloq", :latitude => "40.92436", :longitude => "71.56636").save
City.new(:country_id => "235", :name => "Sirdaryo", :aliases => "Sidare,Sirdaryo,Ssyr-Darja,Syr-Dar'inskiy,Syr-Darjinskaja,Syr-Darâinskiy,Syr-Novorossiyskiy,Syr-Novorossliski,Syrdar'inskaja,Syrdar'ya,Syrdarâya,Ð¡ÑÑÐ´Ð°ÑÑÐ¸Ð½ÑÐºÐ°Ñ,Sirdaryo", :latitude => "40.84361", :longitude => "68.66167").save
City.new(:country_id => "235", :name => "Showot", :aliases => "Shakh-abad,Shavat,Shovot,Showot,Showot", :latitude => "41.65583", :longitude => "60.3025").save
City.new(:country_id => "235", :name => "Shofirkon", :aliases => "Baumana,Khodzha-arif,Shafirkan,Shafrikan,Shafrikent,Shofirkon,Shofirkon", :latitude => "40.12", :longitude => "64.50139").save
City.new(:country_id => "235", :name => "Salor", :aliases => "Chirchik,Salar,Salor,Salor", :latitude => "41.37222", :longitude => "69.38167").save
City.new(:country_id => "235", :name => "Qushkupir", :aliases => "Kosh Kunir,Koshkupyr,Qushkupir,QÅ­shkÅ­pir,QÅ­shkÅ­pir", :latitude => "41.535", :longitude => "60.34556").save
City.new(:country_id => "235", :name => "Qo`qon", :aliases => "Kokand,Kokandas,Qo'qon,Qo`qon,Qoâqon,Quqon,QÅ­qon,kokando,kokanteu,ÐÐ¾ÐºÐ°Ð½Ð´,ã³ã¼ã«ã³ã,ì½ì¹¸í¸,Qoâqon", :latitude => "40.52861", :longitude => "70.9425").save
City.new(:country_id => "235", :name => "Piskent", :aliases => "Piskent,Pskent,Piskent", :latitude => "40.89722", :longitude => "69.35056").save
City.new(:country_id => "235", :name => "Payshanba", :aliases => "Pajshanba,Payshanba,Payshmba,ÐÐ°Ð¹ÑÐ°Ð½Ð±Ð°,Payshanba", :latitude => "40.00778", :longitude => "66.23694").save
City.new(:country_id => "235", :name => "Parkent", :aliases => ",Parkent", :latitude => "41.29444", :longitude => "69.67639").save
City.new(:country_id => "235", :name => "Pop", :aliases => "Pap,Pop,ÐÐ¾Ð¿,Pop", :latitude => "40.87361", :longitude => "71.10889").save
City.new(:country_id => "235", :name => "Paxtakor", :aliases => "Pakhtakor,Paxtakor,Paxtakor", :latitude => "40.31528", :longitude => "67.95444").save
City.new(:country_id => "235", :name => "Olmaliq", :aliases => "Almalyk,AÅmaÅyk,Olmaliq,ÐÐ»Ð¼Ð°Ð»ÑÐº,Olmaliq", :latitude => "40.84472", :longitude => "69.59833").save
City.new(:country_id => "235", :name => "Ohangaron", :aliases => "Akhangaran,Akhangaron,Kurama,Ohangaron,Okhangaron,Ohangaron", :latitude => "40.90639", :longitude => "69.63833").save
City.new(:country_id => "235", :name => "Nurota", :aliases => "Nurata,Nurota,ÐÑÑÐ¾ÑÐ°,Nurota", :latitude => "40.56139", :longitude => "65.68861").save
City.new(:country_id => "235", :name => "Novyy Turtkul'", :aliases => ",Novyy Turtkulâ", :latitude => "41.55", :longitude => "61.01667").save
City.new(:country_id => "235", :name => "Navoiy", :aliases => "Kermene,Kermine,Nava,Navoi,Navoiy,Navoy,NavoÃ¯,Nawoiy,Nazoy,ÐÐ°Ð²Ð¾Ð¸,Navoiy", :latitude => "40.08444", :longitude => "65.37917").save
City.new(:country_id => "235", :name => "Namangan", :aliases => "Namangan,ÐÐ°Ð¼Ð°Ð½Ð³Ð°Ð½,Namangan", :latitude => "40.9983", :longitude => "71.67257").save
City.new(:country_id => "235", :name => "Marg`ilon", :aliases => "Marg`ilon,Margelan,Marghilon,Margilan,Margâilon,ÐÐ°ÑÐ³Ð¸Ð»Ð°Ð½,Margâilon", :latitude => "40.47111", :longitude => "71.72472").save
City.new(:country_id => "235", :name => "Manghit", :aliases => "Manga,Manghit,Mangit,Mangyt,Manghit", :latitude => "42.11556", :longitude => "60.05972").save
City.new(:country_id => "235", :name => "Asaka", :aliases => "Asaka,Assake,Leninsk,Zelensk,ÐÑÐ°ÐºÐ°,Asaka", :latitude => "40.64139", :longitude => "72.23722").save
City.new(:country_id => "235", :name => "Quvasoy", :aliases => "Kubasay,Kuvasa,Kuvasay,Kuwassai,Quvasoy,Quwasoy,Quvasoy", :latitude => "40.30222", :longitude => "71.97444").save
City.new(:country_id => "235", :name => "Qurghontepa", :aliases => "Kurgan Tyube,Kurgan-Tepe,Kurgantepa,Kyzyl-Tepa,Qurghontepa,QÅ­rghontepa,QÅ­rghontepa", :latitude => "40.72667", :longitude => "72.75917").save
City.new(:country_id => "235", :name => "Kirgili", :aliases => ",Kirgili", :latitude => "40.43583", :longitude => "71.76722").save
City.new(:country_id => "235", :name => "Qibray", :aliases => "Kibrai,Kibray,Qibray,Qibray", :latitude => "41.38972", :longitude => "69.465").save
City.new(:country_id => "235", :name => "Khujaobod", :aliases => "Khodzhaabad,Khodzhavat,Khodzhiabad,Khoji-Abad,Khujaobod,KhÅ­jaobod,KhÅ­jaobod", :latitude => "40.66944", :longitude => "72.55972").save
City.new(:country_id => "235", :name => "Khiwa", :aliases => "Chiva,Chiwa,Hiva,Horezm,Jiva,Khiva,KhivÃ ,Khiwa,Khorezm,Xiva,khwarzm,khywa,khywh,Ä¤iva,Ð¥Ð¸Ð²Ð°,Ø®ÙØ§Ø±Ø²Ù,Ø®ÛÙØ§,Ø®ÛÙÙ,Khiwa", :latitude => "41.37833", :longitude => "60.36389").save
City.new(:country_id => "235", :name => "Haqqulobod", :aliases => "Haqqulobod,Khakkulabad,Khakulabad,Naron,Naryn,Haqqulobod", :latitude => "40.91667", :longitude => "72.11667").save
City.new(:country_id => "235", :name => "Kosonsoy", :aliases => "Kasansay,Kassan-Sai,Kassansay,Kosonsoy,Kosonsoy", :latitude => "41.25611", :longitude => "71.55083").save
City.new(:country_id => "235", :name => "Jizzax", :aliases => "Dishsak,Djizak,Dzhizak,Jizak,Jizzakh,Jizzax,jyzk,ÐÐ¶Ð¸Ð·Ð°Ðº,Ø¬ÛØ²Ú©,Jizzax", :latitude => "40.11583", :longitude => "67.84222").save
City.new(:country_id => "235", :name => "Iskandar", :aliases => "Iskandar,Iskander,ÐÑÐºÐ°Ð½Ð´Ð°Ñ,Iskandar", :latitude => "41.55389", :longitude => "69.70083").save
City.new(:country_id => "235", :name => "Hazorasp", :aliases => "Hazorasp,Khazarasp,Hazorasp", :latitude => "41.31944", :longitude => "61.07417").save
City.new(:country_id => "235", :name => "Gurlan", :aliases => "Gurlan,Gurlek,Gurlen,ÐÑÑÐ»Ð°Ð½,Gurlan", :latitude => "41.84472", :longitude => "60.39194").save
City.new(:country_id => "235", :name => "Guliston", :aliases => "Golodnaya Step',Golodnaya Stepâ,Gulistan,Guliston,Mirzachul',Mirzachulâ,ÐÑÐ»Ð¸ÑÑÐ°Ð½,Guliston", :latitude => "40.48972", :longitude => "68.78417").save
City.new(:country_id => "235", :name => "Ghijduwon", :aliases => "Akmal'-Abad,Akmalâ-Abad,Ghijduwon,Gidzhduvan,Gizhduvan,Gydzh-Duvan,Gydzha-Dovan,Ghijduwon", :latitude => "40.1", :longitude => "64.68333").save
City.new(:country_id => "235", :name => "G'azalkent", :aliases => "G`azalkent,Gazalkent,Ghazalkent,Gâazalkent,ÐÐ°Ð·Ð°Ð»ÐºÐµÐ½Ñ,Gâazalkent", :latitude => "41.55806", :longitude => "69.77083").save
City.new(:country_id => "235", :name => "Gagarin", :aliases => "Erjar,Gagarin,Yerzhar,ÐÐ°Ð³Ð°ÑÐ¸Ð½,Gagarin", :latitude => "40.66194", :longitude => "68.17222").save
City.new(:country_id => "235", :name => "Farg`ona", :aliases => "Farghona,Fergana,Novyy Margelan,Skobelev,Skobelevo,Ð¤ÐµÑÐ³Ð°Ð½Ð°,Farg`ona", :latitude => "40.38421", :longitude => "71.78432").save
City.new(:country_id => "235", :name => "Dustlik", :aliases => ",DÅ­stlik", :latitude => "40.52472", :longitude => "68.03583").save
City.new(:country_id => "235", :name => "Chust Shahri", :aliases => "Chust,Chust Shahri,Tschust,Ð§ÑÑÑ,Chust Shahri", :latitude => "41.00127", :longitude => "71.22575").save
City.new(:country_id => "235", :name => "Chirchiq", :aliases => "Chirchik,Chirchiq,Tschirtschik,Ð§Ð¸ÑÑÐ¸Ðº,Chirchiq", :latitude => "41.46889", :longitude => "69.58222").save
City.new(:country_id => "235", :name => "Chinoz", :aliases => "Chinaz,Chinoz,Cinaz,Tschin,Ð§Ð¸Ð½Ð¾Ð·,Chinoz", :latitude => "40.93639", :longitude => "68.76972").save
City.new(:country_id => "235", :name => "Chortoq", :aliases => "Chartak,Chertak,Chortoq,Chortoq", :latitude => "41.06656", :longitude => "71.85527").save
City.new(:country_id => "235", :name => "Buka", :aliases => ",BÅ­ka", :latitude => "40.81083", :longitude => "69.19861").save
City.new(:country_id => "235", :name => "Beshariq", :aliases => "Beshariq,Besharyk,Besharykskogo,Imeni Kirova,Kirovo,Kirowo,ÐÐµÑÐ°ÑÑÐºÑÐºÐ¾Ð³Ð¾,Beshariq", :latitude => "40.43583", :longitude => "70.61028").save
City.new(:country_id => "235", :name => "Beruniy", :aliases => "Beruni,Berunij,Beruniy,Biruni,Biruniy,Shabbaz,Shchabbaz,Sheikh Abaz Vali,ÐÐµÑÑÐ½Ð¸Ð¹,Beruniy", :latitude => "41.69111", :longitude => "60.7525").save
City.new(:country_id => "235", :name => "Bektemir", :aliases => "Bektemir,Kolkhoz Imeni Akhunbabayeva,ÐÐµÐºÑÐµÐ¼Ð¸Ñ,Bektemir", :latitude => "41.20972", :longitude => "69.33417").save
City.new(:country_id => "235", :name => "Bekobod", :aliases => "Bagevat,Begovat,Begowat,Bekabad,Bekobod,Bigovat,BÃ¯govat,Bekobod", :latitude => "40.22083", :longitude => "69.26972").save
City.new(:country_id => "235", :name => "Angren", :aliases => "Angren,Angrenshakhtstroy,Turk,Turn,ÐÐ½Ð³ÑÐµÐ½,Angren", :latitude => "41.01667", :longitude => "70.14361").save
City.new(:country_id => "235", :name => "Andijon", :aliases => "Andican,Andidzhan,Andijan,Andijon,AndijÃ¡n,Andisjan,Andizan,Andizhan,Andizhan - Andijon,Andizjan,AndiÅ¼an,AndiÅ¾an,an ji yan,andijan,ztnjan,ÐÐ½Ð´Ð¸Ð¶Ð°Ð½,Ø¸Ø©ÙØ¬Ø§Ù,ã¢ã³ãã£ã¸ã£ã³,å®éå»¶,ìëì,Andijon", :latitude => "40.78306", :longitude => "72.34389").save
City.new(:country_id => "235", :name => "Oltiariq", :aliases => "Altyaryk,Oltiariq,Oltiariq", :latitude => "40.39194", :longitude => "71.47417").save
City.new(:country_id => "235", :name => "Quva", :aliases => "Kuva,Quva,Quwa,ÐÑÐ²Ð°,Quva", :latitude => "40.52361", :longitude => "72.06167").save
