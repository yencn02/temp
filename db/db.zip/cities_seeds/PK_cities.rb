City.new(:country_id => "180", :name => "Chuhar Jamali", :aliases => ",Chuhar JamÄli", :latitude => "24.38889", :longitude => "67.99306").save
City.new(:country_id => "180", :name => "Rawala Kot", :aliases => "Rawala Kot,Rawalkote,Rawlakot,RÄwala Kot,RÄwala Kot", :latitude => "33.85785", :longitude => "73.76093").save
City.new(:country_id => "180", :name => "Pir jo Goth", :aliases => "Pir Goth,Pir jo Goth,PÄ«r jo Goth,PÄ«r jo Goth", :latitude => "27.59102", :longitude => "68.61786").save
City.new(:country_id => "180", :name => "Khairpur", :aliases => "Khaipur,Khairpur,Khairpur Mirs,Khairpur MÄ«rs,Khajrpura,Ð¥Ð°Ð¹ÑÐ¿ÑÑÐ°,Khairpur", :latitude => "27.53333", :longitude => "68.76667").save
City.new(:country_id => "180", :name => "Zhob", :aliases => "Apozai,Fort Sandeman,Fort Sanderman,Zhob,Zhob", :latitude => "31.34111", :longitude => "69.44806").save
City.new(:country_id => "180", :name => "Zaida", :aliases => "Zaida,Zaida", :latitude => "34.06028", :longitude => "72.46778").save
City.new(:country_id => "180", :name => "Zahir Pir", :aliases => ",ZÄhir PÄ«r", :latitude => "28.81137", :longitude => "70.52172").save
City.new(:country_id => "180", :name => "Zafarwal", :aliases => "Zafarwal,ZafarwÄl,Zaffarwal,ZafarwÄl", :latitude => "32.34631", :longitude => "74.89987").save
City.new(:country_id => "180", :name => "Yazman Mandi", :aliases => "Rohotwali,RohotwÄli,Yazman,Yazman Mandi,YazmÄn,YazmÄn Mandi,YazmÄn Mandi", :latitude => "29.12374", :longitude => "71.74436").save
City.new(:country_id => "180", :name => "Wazirabad", :aliases => ",WazÄ«rÄbÄd", :latitude => "32.44465", :longitude => "74.116").save
City.new(:country_id => "180", :name => "Warburton", :aliases => "Uorberton,Warburton,Ð£Ð¾ÑÐ±ÐµÑÑÐ¾Ð½,Warburton", :latitude => "31.55", :longitude => "73.83333").save
City.new(:country_id => "180", :name => "Warah", :aliases => ",WÄrÄh", :latitude => "27.45", :longitude => "67.8").save
City.new(:country_id => "180", :name => "Vihari", :aliases => "Vehari,Vihari,VihÄri,VihÄri", :latitude => "30.03333", :longitude => "72.35").save
City.new(:country_id => "180", :name => "Utmanzai", :aliases => "Utmanzai,UtmÄnzai,Uttamanza,Uttmanzai,UtmÄnzai", :latitude => "34.18583", :longitude => "71.76333").save
City.new(:country_id => "180", :name => "Uthal", :aliases => "Utal,Uthal,Uthal", :latitude => "25.80722", :longitude => "66.62194").save
City.new(:country_id => "180", :name => "Usta Muhammad", :aliases => "Ushda,Usta,Usta Muhammad,Usta Muhammad", :latitude => "28.17943", :longitude => "68.04454").save
City.new(:country_id => "180", :name => "Umarkot", :aliases => ",Umarkot", :latitude => "25.36667", :longitude => "69.73333").save
City.new(:country_id => "180", :name => "Ubauro", :aliases => ",Ubauro", :latitude => "28.16667", :longitude => "69.73333").save
City.new(:country_id => "180", :name => "Turbat", :aliases => ",Turbat", :latitude => "26.003", :longitude => "63.0434").save
City.new(:country_id => "180", :name => "Topi", :aliases => "Topi,Ð¢Ð¾Ð¿Ð¸,Topi", :latitude => "34.06889", :longitude => "72.62444").save
City.new(:country_id => "180", :name => "Toba Tek Singh", :aliases => "Toba Tek Singh,Toba Tek Singh", :latitude => "30.97459", :longitude => "72.48266").save
City.new(:country_id => "180", :name => "Thul", :aliases => "Thul,Thul Sind,Thul", :latitude => "28.24185", :longitude => "68.7776").save
City.new(:country_id => "180", :name => "Thatta", :aliases => "Tatta,Thatta,Thatta", :latitude => "24.74745", :longitude => "67.92353").save
City.new(:country_id => "180", :name => "Tharu Shah", :aliases => ",ThÄru ShÄh", :latitude => "26.94423", :longitude => "68.11602").save
City.new(:country_id => "180", :name => "Taunsa", :aliases => ",Taunsa", :latitude => "30.70484", :longitude => "70.65051").save
City.new(:country_id => "180", :name => "Tank", :aliases => ",TÄnk", :latitude => "32.22168", :longitude => "70.37928").save
City.new(:country_id => "180", :name => "Tangi", :aliases => "Tangi,Tangi", :latitude => "34.30056", :longitude => "71.65361").save
City.new(:country_id => "180", :name => "Tando Muhammad Khan", :aliases => "Tando Mohammad Khan,Tando Muhammad Khan,Tando Muhammad KhÄn,Tando Muhammad KhÄn", :latitude => "25.13333", :longitude => "68.53333").save
City.new(:country_id => "180", :name => "Tando Jam", :aliases => ",Tando JÄm", :latitude => "25.42718", :longitude => "68.53619").save
City.new(:country_id => "180", :name => "Tando Allahyar", :aliases => "Tando Alahyar,Tando Allahyar,Tando AllÄhyÄr,Tando AllÄhyÄr", :latitude => "25.46263", :longitude => "68.71923").save
City.new(:country_id => "180", :name => "Tando Adam", :aliases => ",Tando Ädam", :latitude => "25.76667", :longitude => "68.66667").save
City.new(:country_id => "180", :name => "Tandlianwala", :aliases => ",TÄndliÄnwÄla", :latitude => "31.03333", :longitude => "73.13333").save
City.new(:country_id => "180", :name => "Talhar", :aliases => ",TalhÄr", :latitude => "24.88333", :longitude => "68.81667").save
City.new(:country_id => "180", :name => "Talamba", :aliases => "Talamba,Tolamba,Tulamba Town,Talamba", :latitude => "30.52708", :longitude => "72.24011").save
City.new(:country_id => "180", :name => "Talagang", :aliases => ",Talagang", :latitude => "32.92973", :longitude => "72.41583").save
City.new(:country_id => "180", :name => "Tal", :aliases => "Tal,Tal',Thal,TÄl,Ð¢Ð°Ð»Ñ,TÄl", :latitude => "35.4867", :longitude => "72.2343").save
City.new(:country_id => "180", :name => "Swabi", :aliases => "Swabi,SwÄbi,SwÄbi", :latitude => "34.12", :longitude => "72.47222").save
City.new(:country_id => "180", :name => "Sukkur", :aliases => "Sukkur,Ð¡ÑÐºÐºÑÑ,Sukkur", :latitude => "27.7", :longitude => "68.86667").save
City.new(:country_id => "180", :name => "Sukheke Mandi", :aliases => ",Sukheke Mandi", :latitude => "31.86388", :longitude => "73.51122").save
City.new(:country_id => "180", :name => "Sodhra", :aliases => "Sodhra,Sodlira,Sohdra Town,Sodhra", :latitude => "32.46162", :longitude => "74.18234").save
City.new(:country_id => "180", :name => "Sita Road", :aliases => ",SÄ«ta Road", :latitude => "27.03333", :longitude => "67.85").save
City.new(:country_id => "180", :name => "Sinjhoro", :aliases => "Sinjhoro,Sinjihoro,Sinjhoro", :latitude => "26.03333", :longitude => "68.8").save
City.new(:country_id => "180", :name => "Sillanwali", :aliases => "Sillanwali,SillÄnwÄli,SillÄnwÄli", :latitude => "31.82917", :longitude => "72.53944").save
City.new(:country_id => "180", :name => "Sibi", :aliases => "Ibis,Sibi,Ð¡Ð¸Ð±Ð¸,Sibi", :latitude => "29.5448", :longitude => "67.8764").save
City.new(:country_id => "180", :name => "Sialkot", :aliases => "Sialkot,SiÄlkot,Ð¡Ð¸Ð°Ð»ÐºÐ¾Ñ,SiÄlkot", :latitude => "32.5101", :longitude => "74.54313").save
City.new(:country_id => "180", :name => "Shujaabad", :aliases => "Shujaabad,Shujabad,ShujÄÄbÄd,ShujÄÄbÄd", :latitude => "29.87967", :longitude => "71.29313").save
City.new(:country_id => "180", :name => "Shorko", :aliases => "Shorko,Shorkot,Shorko", :latitude => "31.90991", :longitude => "70.87741").save
City.new(:country_id => "180", :name => "Shikarpur", :aliases => ",ShikÄrpur", :latitude => "27.95706", :longitude => "68.63789").save
City.new(:country_id => "180", :name => "Sheikhupura", :aliases => "Qila Sheikhupura,Sheikhupura,Shekhupura,ShekhÅ«pura,Sheikhupura", :latitude => "31.71306", :longitude => "73.97833").save
City.new(:country_id => "180", :name => "Sharqpur", :aliases => "Sharakpur,Shargpur,Sharqpur,Sharqpur", :latitude => "31.46333", :longitude => "74.1").save
City.new(:country_id => "180", :name => "Shakargarr", :aliases => ",Shakargarr", :latitude => "32.26232", :longitude => "75.16682").save
City.new(:country_id => "180", :name => "Shahr Sultan", :aliases => ",Shahr SultÄn", :latitude => "29.57646", :longitude => "71.02116").save
City.new(:country_id => "180", :name => "Shahpur Chakar", :aliases => "Shahpur Chaka,Shahpur Chakar,Shahpur Chaker,ShÄhpur Chaka,ShÄhpur ChÄkar,ShÄhpur ChÄkar", :latitude => "26.15497", :longitude => "68.65093").save
City.new(:country_id => "180", :name => "Shahdadpur", :aliases => ",ShÄhdÄdpur", :latitude => "25.93333", :longitude => "68.61667").save
City.new(:country_id => "180", :name => "Shahdadkot", :aliases => "Shahdadkot,Shahdadpur,ShÄhdÄdkot,ShÄhdÄdpur,ShÄhdÄdkot", :latitude => "27.84771", :longitude => "67.9055").save
City.new(:country_id => "180", :name => "Shabqadar", :aliases => "Shabgadar Fort,Shabkadar,Shabqadar,Shapqadar,Shabqadar", :latitude => "34.21528", :longitude => "71.55528").save
City.new(:country_id => "180", :name => "Sehwan", :aliases => "Sehwan,SehwÄn,SehwÄn", :latitude => "26.43333", :longitude => "67.86667").save
City.new(:country_id => "180", :name => "Sargodha", :aliases => "Sargodha,Sargodkha,Ð¡Ð°ÑÐ³Ð¾Ð´ÑÐ°,Sargodha", :latitude => "32.08361", :longitude => "72.67111").save
City.new(:country_id => "180", :name => "Sarai Sidhu", :aliases => ",SarÄi Sidhu", :latitude => "30.59489", :longitude => "71.96977").save
City.new(:country_id => "180", :name => "Sarai Naurang", :aliases => "Naurang Sarai,Naurang SarÄi,Sarai Naurang,SarÄi Naurang,SarÄi Naurang", :latitude => "32.82591", :longitude => "70.78136").save
City.new(:country_id => "180", :name => "Sarai Alamgir", :aliases => "Sarai Alamgir,SarÄi ÄlamgÄ«r,SarÄi ÄlamgÄ«r", :latitude => "32.90122", :longitude => "73.75591").save
City.new(:country_id => "180", :name => "Sangla", :aliases => "Sangla,Sangla Hill,SÄngla,SÄngla", :latitude => "31.71667", :longitude => "73.38333").save
City.new(:country_id => "180", :name => "Sanghar", :aliases => "Sangar,Sanghar,SÄnghar,SÄnghar", :latitude => "26.03333", :longitude => "68.95").save
City.new(:country_id => "180", :name => "Sambrial", :aliases => "Sambrial,SambriÄl,SambriÄl", :latitude => "32.47455", :longitude => "74.35209").save
City.new(:country_id => "180", :name => "Sakrand", :aliases => "Sakrand,Sakrano,Sakrand", :latitude => "26.13839", :longitude => "68.27361").save
City.new(:country_id => "180", :name => "Sahiwal", :aliases => "Sahiwal,Sakhivale,Sohiwal,SÄhÄ«wÄl,SÅhiwÄl,Ð¡Ð°ÑÐ¸Ð²Ð°Ð»Ðµ,SÄhÄ«wÄl", :latitude => "31.97306", :longitude => "72.32556").save
City.new(:country_id => "180", :name => "Montgomery", :aliases => "Montgomery,Sahiwal,Sakhivale,SÄhÄ«wÄl,Ð¡Ð°ÑÐ¸Ð²Ð°Ð»Ðµ,Montgomery", :latitude => "30.66667", :longitude => "73.1").save
City.new(:country_id => "180", :name => "Sadiqabad", :aliases => "Sadikabad,Sadiqabad,SÄdikÄbÄd,SÄdiqÄbÄd,SÄdiqÄbÄd", :latitude => "28.3", :longitude => "70.13333").save
City.new(:country_id => "180", :name => "Rohri", :aliases => "Lohri,Rohri,Rohri", :latitude => "27.68333", :longitude => "68.9").save
City.new(:country_id => "180", :name => "Renala Khurd", :aliases => "Renala,Renala Khurd,RenÄla,RenÄla Khurd,RenÄla Khurd", :latitude => "30.88333", :longitude => "73.6").save
City.new(:country_id => "180", :name => "Rawalpindi", :aliases => "Ralalpindi,Ravalpindi,Ravalpindis,Rawalpindi,RÄwalpindi,la wa er pin di,lawalpindi,rawarupindi,rawlpndy,Ð Ð°Ð²Ð°Ð»Ð¿Ð¸Ð½Ð´Ð¸,Ø±Ø§ÙÙÙ¾ÙØ¯Û,Ø±Ø§ÙÙÙ¾ÙÚÛ,ã©ã¯ã«ãã³ãã£,æç¦å°åç¬¬,ë¼ìíë,RÄwalpindi", :latitude => "33.6007", :longitude => "73.0679").save
City.new(:country_id => "180", :name => "Ratodero", :aliases => "Dero,Rato,Ratodero,Ratodero", :latitude => "27.80296", :longitude => "68.28708").save
City.new(:country_id => "180", :name => "Ranipur", :aliases => "Ranipur,Raripur,RÄnÄ«pur,RÄnÄ«pur", :latitude => "27.29024", :longitude => "68.50592").save
City.new(:country_id => "180", :name => "Rajanpur", :aliases => ",RÄjanpur", :latitude => "29.10351", :longitude => "70.32504").save
City.new(:country_id => "180", :name => "Raja Jang", :aliases => "Baja Jang,Raja Jang,RÄja Jang,RÄja Jang", :latitude => "31.22083", :longitude => "74.25194").save
City.new(:country_id => "180", :name => "Raiwind", :aliases => "Raiwind,RÄiwind,RÄiwind", :latitude => "31.25444", :longitude => "74.21778").save
City.new(:country_id => "180", :name => "Radhan", :aliases => ",RÄdhan", :latitude => "27.18333", :longitude => "67.95").save
City.new(:country_id => "180", :name => "Quetta", :aliases => "Kotah,Kvetta,Kwatah,Kweta,Quetta,Shal,Shalkot,ShÄl,ShÄlkot,kuetta,kui da,kweta,kwyth,ÐÐ²ÐµÑÑÐ°,Ú©ÙÛØªÙ,ã¯ã¨ãã¿,å¥é,íí,Quetta", :latitude => "30.18722", :longitude => "67.0125").save
City.new(:country_id => "180", :name => "Kambar", :aliases => "Kambar,Qambar,ÐÐ°Ð¼Ð±Ð°Ñ,Kambar", :latitude => "27.58676", :longitude => "68.00103").save
City.new(:country_id => "180", :name => "Qadirpur Ran", :aliases => ",QÄdirpur RÄn", :latitude => "30.29238", :longitude => "71.67117").save
City.new(:country_id => "180", :name => "Pishin", :aliases => "Pishin,pshy,ÐÐ¸ÑÐ¸Ð½,Ù¾Ø´Û,Pishin", :latitude => "30.58028", :longitude => "66.99611").save
City.new(:country_id => "180", :name => "Pir Mahal", :aliases => ",PÄ«r Mahal", :latitude => "30.76667", :longitude => "72.43333").save
City.new(:country_id => "180", :name => "Pindi Gheb", :aliases => ",Pindi Gheb", :latitude => "33.24024", :longitude => "72.26609").save
City.new(:country_id => "180", :name => "Pindi Bhattian", :aliases => "Pindi Battian,Pindi Bhatian,Pindi Bhattian,Pindi BhattiÄn,Pindi BhattiÄn", :latitude => "31.89781", :longitude => "73.27302").save
City.new(:country_id => "180", :name => "Pind Dadan Khan", :aliases => "Pind Dadan Khan,Pind DÄdan KhÄn,Pindi Dadan Khan,Pind DÄdan KhÄn", :latitude => "32.58789", :longitude => "73.04564").save
City.new(:country_id => "180", :name => "Phalia", :aliases => "Phalia,PhÄlia,PhÄlia", :latitude => "32.42973", :longitude => "73.57745").save
City.new(:country_id => "180", :name => "Peshawar", :aliases => "Pesabar,Pesavaras,Peschawar,Peshavar,Peshawar,PeshÄwar,Pesjawar,Peszawar,PeÅ¡avaras,bai sha wa,pesavara,peshawaru,pesyawaleu,pshawr,pyshawr,Î ÎµÏÎ±Î²Î¬Ï,ÐÐµÑÐ°Ð²Ð°Ñ,Ù¾Ø´Ø§ÙØ±,Ù¾ÛØ´Ø§ÙØ±,à¤ªà¥à¤¶à¤¾à¤µà¤°,ãã·ã£ã¼ã¯ã«,ç½æ²ç¦,íì¤ìë¥´,PeshÄwar", :latitude => "34.00837", :longitude => "71.58018").save
City.new(:country_id => "180", :name => "Pattoki", :aliases => "Mandi Pattoki,Pattoki,Pattoki", :latitude => "31.01667", :longitude => "73.85").save
City.new(:country_id => "180", :name => "Pasrur", :aliases => "Pasrur,PasrÅ«r,Pasur,PasÅ«r,PasrÅ«r", :latitude => "32.26413", :longitude => "74.66342").save
City.new(:country_id => "180", :name => "Pasni", :aliases => "Pansi,Pasni,ÐÐ°ÑÐ½Ð¸,Pasni", :latitude => "25.2625", :longitude => "63.4675").save
City.new(:country_id => "180", :name => "Pano Aqil", :aliases => "Pano Akil,Pano Aqil,PÄno Äqil,PÄno Äqil", :latitude => "27.85875", :longitude => "69.10969").save
City.new(:country_id => "180", :name => "Pakpattan", :aliases => "Pakpattan,PÄkpattan,PÄkpattan", :latitude => "30.35", :longitude => "73.4").save
City.new(:country_id => "180", :name => "Paharpur", :aliases => ",PahÄrpur", :latitude => "32.10384", :longitude => "70.97235").save
City.new(:country_id => "180", :name => "Pad Idan", :aliases => ",Pad Äªdan", :latitude => "26.77475", :longitude => "68.30197").save
City.new(:country_id => "180", :name => "Pabbi", :aliases => "Pabbi,Pabbi", :latitude => "34.01056", :longitude => "71.79889").save
City.new(:country_id => "180", :name => "Okara", :aliases => "Okara,OkÄra,ÐÐºÐ°ÑÐ°,OkÄra", :latitude => "30.80806", :longitude => "73.44583").save
City.new(:country_id => "180", :name => "Nushki", :aliases => ",Nushki", :latitude => "29.55", :longitude => "66.01667").save
City.new(:country_id => "180", :name => "Nawabshah", :aliases => "Nawabshah,NawÄbshÄh,NawÄbshÄh", :latitude => "26.25289", :longitude => "68.41052").save
City.new(:country_id => "180", :name => "Naushahro Firoz", :aliases => "Naushahro,Naushahro Firoz,Naushahro FÄ«roz,Naushahro Piroz,Naushahro FÄ«roz", :latitude => "26.84238", :longitude => "68.12298").save
City.new(:country_id => "180", :name => "Naushahra Virkan", :aliases => "Naushahra Virkan,Naushahra Virkhan,Naushahra VirkÄn,Naushehra Werkan,Naushera Virkhan,Naushahra VirkÄn", :latitude => "31.96098", :longitude => "73.97309").save
City.new(:country_id => "180", :name => "Naudero", :aliases => "Naudero,Naundero,Naudero", :latitude => "27.66477", :longitude => "68.36217").save
City.new(:country_id => "180", :name => "Nasirabad", :aliases => ",NasÄ«rÄbÄd", :latitude => "27.38333", :longitude => "67.91667").save
City.new(:country_id => "180", :name => "Narowal", :aliases => ",NÄrowÄl", :latitude => "32.1", :longitude => "74.88333").save
City.new(:country_id => "180", :name => "Narang", :aliases => "Narang,NÄrang,ÐÐ°ÑÐ°Ð½Ð³,NÄrang", :latitude => "31.9132", :longitude => "74.51756").save
City.new(:country_id => "180", :name => "Naukot", :aliases => "Naokot,Naukot,Nawakot,Naukot", :latitude => "24.857", :longitude => "69.40337").save
City.new(:country_id => "180", :name => "Nankana Sahib", :aliases => "Nanakana Sahib,Nankana Municipality,Nankana Sahib,NankÄna SÄhib,NankÄna SÄhib", :latitude => "31.4475", :longitude => "73.69722").save
City.new(:country_id => "180", :name => "Muzaffargarh", :aliases => "Muzaffargar,Muzaffargarh,ÐÑÐ·Ð°ÑÑÐ°ÑÐ³Ð°Ñ,Muzaffargarh", :latitude => "30.07537", :longitude => "71.19213").save
City.new(:country_id => "180", :name => "Muzaffarabad", :aliases => "Musaffarabad,MusaffarÄbÄd,Muzafarabad,Muzaffarabad,MuzaffarÄbÄd,ÐÑÐ·Ð°ÑÐ°ÑÐ°Ð±Ð°Ð´,MuzaffarÄbÄd", :latitude => "34.37", :longitude => "73.47111").save
City.new(:country_id => "180", :name => "Mustafabad", :aliases => ",MustafÄbÄd", :latitude => "30.89222", :longitude => "73.49889").save
City.new(:country_id => "180", :name => "Murree", :aliases => "Murree,Murree", :latitude => "33.9049", :longitude => "73.3925").save
City.new(:country_id => "180", :name => "Muridke", :aliases => ",MurÄ«dke", :latitude => "31.8025", :longitude => "74.26167").save
City.new(:country_id => "180", :name => "Multan", :aliases => "Multan,Multanas,MultÄn,mu er tan,murutan,ÐÑÐ»ÑÐ°Ð½,ã ã«ã¿ã¼ã³,æ¨ç¾å¦,MultÄn", :latitude => "30.19556", :longitude => "71.47528").save
City.new(:country_id => "180", :name => "Moro", :aliases => ",Moro", :latitude => "26.66459", :longitude => "68.00156").save
City.new(:country_id => "180", :name => "Mithi", :aliases => "Mithi,Mitti,Mithi", :latitude => "24.73183", :longitude => "69.79811").save
City.new(:country_id => "180", :name => "Mitha Tiwana", :aliases => ",Mitha TiwÄna", :latitude => "32.24861", :longitude => "72.11083").save
City.new(:country_id => "180", :name => "Mirpur Mathelo", :aliases => "Mirpur,Mirpur Mathelo,MÄ«rpur,MÄ«rpur MÄthelo,MÄ«rpur MÄthelo", :latitude => "28.03333", :longitude => "69.55").save
City.new(:country_id => "180", :name => "Mirpur Khas", :aliases => "Mirpur Khas,MÄ«rpur KhÄs,MÄ«rpur KhÄs", :latitude => "25.5251", :longitude => "69.0159").save
City.new(:country_id => "180", :name => "Mingaora", :aliases => "Mingaora,Mingora,MingÄora,MingÄora", :latitude => "34.775", :longitude => "72.3622").save
City.new(:country_id => "180", :name => "Minchinabad", :aliases => "Manchinabad,Minchinabad,MinchinÄbÄd,MinchinÄbÄd", :latitude => "30.16667", :longitude => "73.56667").save
City.new(:country_id => "180", :name => "Mianwali", :aliases => ",MiÄnwÄli", :latitude => "32.5741", :longitude => "71.52639").save
City.new(:country_id => "180", :name => "Mian Channun", :aliases => "Mian Channu,Mian Channun,MiÄn ChannÅ«n,MiÄn ChannÅ«n", :latitude => "30.45", :longitude => "72.36667").save
City.new(:country_id => "180", :name => "Mehrabpur", :aliases => "Mahrabpur,Mehrabpur,MehrÄbpur,MehrÄbpur", :latitude => "28.10973", :longitude => "68.0264").save
City.new(:country_id => "180", :name => "Mehar", :aliases => ",Mehar", :latitude => "27.18333", :longitude => "67.81667").save
City.new(:country_id => "180", :name => "Matli", :aliases => ",MÄtli", :latitude => "25.04312", :longitude => "68.65568").save
City.new(:country_id => "180", :name => "Matiari", :aliases => "Matari,Matiari,MatiÄri,MatiÄri", :latitude => "25.59609", :longitude => "68.44666").save
City.new(:country_id => "180", :name => "Mastung", :aliases => ",Mastung", :latitude => "29.79936", :longitude => "66.84505").save
City.new(:country_id => "180", :name => "Mardan", :aliases => "Mardan,MardÄn,ÐÐ°ÑÐ´Ð°Ð½,MardÄn", :latitude => "34.19833", :longitude => "72.04583").save
City.new(:country_id => "180", :name => "Mansehra", :aliases => "Mansehra,Mansekhra,MÄnsehra,ÐÐ°Ð½ÑÐµÑÑÐ°,MÄnsehra", :latitude => "34.33333", :longitude => "73.2").save
City.new(:country_id => "180", :name => "Mangla", :aliases => ",Mangla", :latitude => "31.89306", :longitude => "72.38167").save
City.new(:country_id => "180", :name => "Mandi Bahauddin", :aliases => "Bahauddin,Mandi Bahauddin,Mandi BahÄuddÄ«n,Mandi BahÄuddÄ«n", :latitude => "32.58339", :longitude => "73.48432").save
City.new(:country_id => "180", :name => "Mananwala", :aliases => ",MÄnÄnwÄla", :latitude => "31.58417", :longitude => "73.68778").save
City.new(:country_id => "180", :name => "Mamu Kanjan", :aliases => ",MÄmu KÄnjan", :latitude => "30.83333", :longitude => "72.8").save
City.new(:country_id => "180", :name => "Malakwal", :aliases => "Malakwal,MalakwÄl,MalakwÄl", :latitude => "32.55362", :longitude => "73.21234").save
City.new(:country_id => "180", :name => "Mailsi", :aliases => ",Mailsi", :latitude => "29.80028", :longitude => "72.17583").save
City.new(:country_id => "180", :name => "Mach", :aliases => "Mach,Mach", :latitude => "29.8639", :longitude => "67.3293").save
City.new(:country_id => "180", :name => "Loralai", :aliases => "Loraiar,Loralai,Loralai", :latitude => "30.37082", :longitude => "68.5998").save
City.new(:country_id => "180", :name => "Lodhran", :aliases => "Lodhran,LodhrÄn,LodhrÄn", :latitude => "29.54051", :longitude => "71.63357").save
City.new(:country_id => "180", :name => "Leiah", :aliases => "Leiah,Lelah,Lerah,Leiah", :latitude => "30.96128", :longitude => "70.93904").save
City.new(:country_id => "180", :name => "Larkana", :aliases => "Larkana,Larkane,LÄrkÄna,ÐÐ°ÑÐºÐ°Ð½Ðµ,LÄrkÄna", :latitude => "27.55", :longitude => "68.21667").save
City.new(:country_id => "180", :name => "Lalian", :aliases => "Lalian,LÄliÄn,LÄliÄn", :latitude => "31.8225", :longitude => "72.79722").save
City.new(:country_id => "180", :name => "Lala Musa", :aliases => ",LÄla MÅ«sa", :latitude => "32.69894", :longitude => "73.95896").save
City.new(:country_id => "180", :name => "Lakki Marwat", :aliases => "Laki-Marwat,Lakki,Lakki Marwat,Lakki Marwat", :latitude => "32.60795", :longitude => "70.91142").save
City.new(:country_id => "180", :name => "Lahore", :aliases => "Lahaur,Lahor,Lahoras,Lahore,Lakhor,LÃ¢hore,LÄhaur,la he er,lahaura,laholeu,lahora,lahori,lahwr,rahoru,ÐÐ°ÑÐ¾Ñ,×××××¨,ÙØ§ÙÙØ±,ÙØ§Ú¾ÙØ±,ÙØ§ÛÙØ±,à¤²à¤¾à¤¹à¥à¤°,à¤²à¤¾à¤¹à¥à¤°,àª²àª¾àª¹à«àª°,ááá°áá á,ã©ãã¼ã«,ã©ã¼ãã¼ã«,æåå°,æåç¾,ë¼í¸ë¥´,Lahore", :latitude => "31.54972", :longitude => "74.34361").save
City.new(:country_id => "180", :name => "Ladhewala Waraich", :aliases => ",LadhewÄla WarÄich", :latitude => "32.15656", :longitude => "74.11701").save
City.new(:country_id => "180", :name => "Lachi", :aliases => ",LÄchi", :latitude => "33.38325", :longitude => "71.33858").save
City.new(:country_id => "180", :name => "Kunri", :aliases => ",Kunri", :latitude => "25.18333", :longitude => "69.56667").save
City.new(:country_id => "180", :name => "Kunjah", :aliases => ",KunjÄh", :latitude => "32.52848", :longitude => "73.97368").save
City.new(:country_id => "180", :name => "Kundian", :aliases => "Kundian,Kundian Pacca,KundiÄn,KundiÄn", :latitude => "32.45731", :longitude => "71.47956").save
City.new(:country_id => "180", :name => "Kulachi", :aliases => ",KulÄchi", :latitude => "31.92861", :longitude => "70.45917").save
City.new(:country_id => "180", :name => "Kot Samaba", :aliases => ",Kot SamÄba", :latitude => "28.5522", :longitude => "70.46837").save
City.new(:country_id => "180", :name => "Kotri", :aliases => "Koti,Kotri,Kotri", :latitude => "25.3652", :longitude => "68.3152").save
City.new(:country_id => "180", :name => "Kot Radha Kishan", :aliases => ",Kot RÄdha Kishan", :latitude => "31.1725", :longitude => "74.09972").save
City.new(:country_id => "180", :name => "Kot Mumin", :aliases => "Kot Mamin,Kot Mumin,Kot MÅ«min,Kot-Moman,Kot MÅ«min", :latitude => "32.18954", :longitude => "73.02798").save
City.new(:country_id => "180", :name => "Kot Malik", :aliases => ",Kot Malik", :latitude => "30.19583", :longitude => "66.9975").save
City.new(:country_id => "180", :name => "Kotli Loharan", :aliases => ",Kotli LohÄrÄn", :latitude => "32.5883", :longitude => "74.49321").save
City.new(:country_id => "180", :name => "Kotli", :aliases => ",Kotli", :latitude => "33.51667", :longitude => "73.91667").save
City.new(:country_id => "180", :name => "Kot Ghulam Muhammad", :aliases => ",Kot GhulÄm Muhammad", :latitude => "32.33298", :longitude => "74.54798").save
City.new(:country_id => "180", :name => "Kot Diji", :aliases => "Diji,Kot Diji,Kot Diji", :latitude => "27.34272", :longitude => "68.70834").save
City.new(:country_id => "180", :name => "Kot Addu", :aliases => "Kot Addu,Kot-Adu,Kot Addu", :latitude => "30.4692", :longitude => "70.96714").save
City.new(:country_id => "180", :name => "Kohat", :aliases => "Kohat,KohÄt,Kokhat,ÐÐ¾ÑÐ°Ñ,KohÄt", :latitude => "33.58694", :longitude => "71.44222").save
City.new(:country_id => "180", :name => "Khushab", :aliases => "Khushab,Khushah,KhushÄb,KhushÄb", :latitude => "32.29667", :longitude => "72.3525").save
City.new(:country_id => "180", :name => "Khurrianwala", :aliases => "Khurianwala,Khurrianwala,KhurriÄnwÄla,Kurrianwala,KhurriÄnwÄla", :latitude => "31.50056", :longitude => "73.26667").save
City.new(:country_id => "180", :name => "Khipro", :aliases => ",Khipro", :latitude => "25.83333", :longitude => "69.36667").save
City.new(:country_id => "180", :name => "Khewra", :aliases => ",Khewra", :latitude => "32.64793", :longitude => "73.01058").save
City.new(:country_id => "180", :name => "Kharian", :aliases => ",KhÄriÄn", :latitude => "32.81493", :longitude => "73.86359").save
City.new(:country_id => "180", :name => "Kharan", :aliases => "Kharan,Kharan Kalat,Kharon Kalat,KhÄrÄn,KhÄrÄn KalÄt,KhÄrÄn", :latitude => "28.58333", :longitude => "65.41667").save
City.new(:country_id => "180", :name => "Khanpur", :aliases => ",KhÄnpur", :latitude => "28.65", :longitude => "70.65").save
City.new(:country_id => "180", :name => "Khanpur", :aliases => "Khanpoor,Khanpur,KhÄnpur,KhÄnpur", :latitude => "27.84358", :longitude => "69.41373").save
City.new(:country_id => "180", :name => "Khangarh", :aliases => ",KhÄngarh", :latitude => "29.9173", :longitude => "71.16184").save
City.new(:country_id => "180", :name => "Khangah Dogran", :aliases => "Khanga Dogran,Khangah Dogran,Khangah-Dogra,Khangan Dogran,Khanqah Dogran,KhÄngÄh DogrÄn,KhÄngÄn DogrÄn,KhÄnqÄh DogrÄn,KhÄngÄh DogrÄn", :latitude => "31.83167", :longitude => "73.62306").save
City.new(:country_id => "180", :name => "Khalabat", :aliases => ",KhalÄbat", :latitude => "34.06", :longitude => "72.88944").save
City.new(:country_id => "180", :name => "Khairpur Nathan Shah", :aliases => "Khairpur,Khairpur Nathan Shah,Khairpur Nathan ShÄh,Khairpur Nathoshah,Khairpur Nathan ShÄh", :latitude => "27.1", :longitude => "67.73333").save
City.new(:country_id => "180", :name => "Khairpur", :aliases => ",Khairpur", :latitude => "29.58111", :longitude => "72.23639").save
City.new(:country_id => "180", :name => "Khairpur", :aliases => "Khairpur,Khairpur Daherki,Khajrpura,Ð¥Ð°Ð¹ÑÐ¿ÑÑÐ°,Khairpur", :latitude => "28.05", :longitude => "69.7").save
City.new(:country_id => "180", :name => "Kasur", :aliases => "Kansur,KansÅ«r,Kasur,KasÅ«r,ÐÐ°ÑÑÑ,KasÅ«r", :latitude => "31.11556", :longitude => "74.44667").save
City.new(:country_id => "180", :name => "Kashmor", :aliases => "Kashmor,Kashmore,Kashmor", :latitude => "28.43333", :longitude => "69.58333").save
City.new(:country_id => "180", :name => "Karor", :aliases => "Haror,Karor,Karor Lal Isa,Karor", :latitude => "31.22741", :longitude => "70.94923").save
City.new(:country_id => "180", :name => "Karachi", :aliases => "Carachi,Karachi,Karachi - krachy,Karachi - ÙØ±Ø§ÚÙ,Karaci,Karacio,Karacis,Karaczi,Karanchi,Karatschi,KaraÃ§i,KaraÄio,KaraÄi,KaraÄis,KarÃ¡Äi,KarÃ¢chi,KarÄchi,Kurrachee,Kurrachi,ka la qi,kalachi,karachi,karaci,ke la chi,krachy,kratshy,pechs,ÐÐ°ÑÐ°ÑÐ¸,×§×¨××¦'×,ÙØ±Ø§ØªØ´Ù,Ú©Ø±Ø§ÚÛ,ÚªØ±Ø§ÚÙ,à¤à¤°à¤¾à¤à¥,à½à¼à½¢à¼à½à½²,ã«ã©ã,ã«ã©ã¼ãã¼,å¡æå¥,åæè©,ì¹´ë¼ì¹,Karachi", :latitude => "24.9056", :longitude => "67.0822").save
City.new(:country_id => "180", :name => "Kanganpur", :aliases => ",Kanganpur", :latitude => "30.76667", :longitude => "74.13333").save
City.new(:country_id => "180", :name => "Kandiaro", :aliases => "Kandiaro,KandiÄro,KandiÄro", :latitude => "27.06259", :longitude => "68.21016").save
City.new(:country_id => "180", :name => "Kandhkot", :aliases => ",Kandhkot", :latitude => "28.23333", :longitude => "69.18333").save
City.new(:country_id => "180", :name => "Kamra", :aliases => "Kamara,Kamra,KÄmra,KÄmra", :latitude => "33.74734", :longitude => "73.51107").save
City.new(:country_id => "180", :name => "Kamoke", :aliases => "Kamoke,Kamoki,KÄmoke,KÄmoki,Kamoke", :latitude => "31.97444", :longitude => "74.22444").save
City.new(:country_id => "180", :name => "Kamir", :aliases => ",KamÄ«r", :latitude => "30.43333", :longitude => "73.05").save
City.new(:country_id => "180", :name => "Kamar Mushani", :aliases => "Kamar Mushani,Kamar MushÄni,Kamar MushÄni", :latitude => "32.84389", :longitude => "71.36694").save
City.new(:country_id => "180", :name => "Kamalia", :aliases => ",KamÄlia", :latitude => "30.73333", :longitude => "72.65").save
City.new(:country_id => "180", :name => "Kalur Kot", :aliases => "Kallur Kot Town,Kalur Kot,KalÅ«r Kot,KalÅ«r Kot", :latitude => "32.15639", :longitude => "71.25944").save
City.new(:country_id => "180", :name => "Kallar Kahar", :aliases => "Kalar Kahar,Kallar Kahar,Kallar KahÄr,Kallar KahÄr", :latitude => "32.78333", :longitude => "72.7").save
City.new(:country_id => "180", :name => "Kaleke Mandi", :aliases => "Kaleke Mandi,KÄleke Mandi,Mandi Kaleke,KÄleke Mandi", :latitude => "31.97718", :longitude => "73.60259").save
City.new(:country_id => "180", :name => "Kalat", :aliases => "Kalat,KalÄt,Kelat,Khelat,ÐÐ°Ð»Ð°Ñ,KalÄt", :latitude => "29.03333", :longitude => "66.58333").save
City.new(:country_id => "180", :name => "Kalabagh", :aliases => "Kalabagh,KÄlÄbÄgh,KÄlÄbÄgh", :latitude => "32.965", :longitude => "71.55697").save
City.new(:country_id => "180", :name => "Kahuta", :aliases => "Kahuta,KahÅ«ta,Kakhute,ÐÐ°ÑÑÑÐµ,KahÅ«ta", :latitude => "33.59355", :longitude => "73.38647").save
City.new(:country_id => "180", :name => "Kohror Pakka", :aliases => "Kahror,Kehror Pakka Town,Kharor,Kohror Pakka,Kohror Pakka", :latitude => "29.62382", :longitude => "71.91673").save
City.new(:country_id => "180", :name => "Kahna", :aliases => "Kahna,Kahna Nau,Khana,KhÄna,KÄhna,KÄhna", :latitude => "31.36917", :longitude => "74.36528").save
City.new(:country_id => "180", :name => "Kabirwala", :aliases => ",KabÄ«rwÄla", :latitude => "30.4043", :longitude => "71.86657").save
City.new(:country_id => "180", :name => "Johi", :aliases => ",Johi", :latitude => "26.68333", :longitude => "67.61667").save
City.new(:country_id => "180", :name => "Jiwani", :aliases => "Jinwri,Jiunri,Jiwani,Jiyuni,JÄ«nwri,JÄ«wani,JÄ«wani", :latitude => "25.04992", :longitude => "61.7468").save
City.new(:country_id => "180", :name => "Jhumra", :aliases => "Chak Jhumra,Chak Jumra,Jhumra,Jhumra", :latitude => "31.56781", :longitude => "73.18347").save
City.new(:country_id => "180", :name => "Jhol", :aliases => ",Jhol", :latitude => "25.95507", :longitude => "68.88821").save
City.new(:country_id => "180", :name => "Jhelum", :aliases => "Dzhelam,Jhelum,ÐÐ¶ÐµÐ»Ð°Ð¼,Jhelum", :latitude => "32.93313", :longitude => "73.72637").save
City.new(:country_id => "180", :name => "Jhawarian", :aliases => ",JhawÄriÄn", :latitude => "32.36139", :longitude => "72.62278").save
City.new(:country_id => "180", :name => "Jhang Sadr", :aliases => "Jhang Marghiana,Jhang MarghiÄnÄ,Jhang Sadar,Jhang Sadr,Jhang-Maghiana,Jhang-MaghiÄna,Maghiana,MaghiÄna,Jhang Sadr", :latitude => "31.27396", :longitude => "72.31604").save
City.new(:country_id => "180", :name => "Jauharabad", :aliases => "Jauharabad,JauharÄbÄd,Joharabad,JauharÄbÄd", :latitude => "32.28417", :longitude => "72.27861").save
City.new(:country_id => "180", :name => "Jatoi Shimali", :aliases => "Jatoi Shimali,Jatoi ShimÄli,Jatoi Shumali,Jatoi ShimÄli", :latitude => "29.51654", :longitude => "70.85032").save
City.new(:country_id => "180", :name => "Jaranwala", :aliases => ",JarÄnwÄla", :latitude => "31.33333", :longitude => "73.43333").save
City.new(:country_id => "180", :name => "Jand", :aliases => ",Jand", :latitude => "33.42889", :longitude => "72.02").save
City.new(:country_id => "180", :name => "Jampur", :aliases => ",JÄmpur", :latitude => "29.64414", :longitude => "70.59544").save
City.new(:country_id => "180", :name => "Jalalpur Pirwala", :aliases => "Jalalpur,Jalalpur Pirwala,JalÄlpur PÄ«rwÄla,JalÄlpur PÄ«rwÄla", :latitude => "29.50687", :longitude => "71.21917").save
City.new(:country_id => "180", :name => "Jalalpur", :aliases => "Jalalpur,Jalalpur Jattan,JalÄlpur,JalÄlpur", :latitude => "32.64068", :longitude => "74.21612").save
City.new(:country_id => "180", :name => "Jahanian Shah", :aliases => ",JahÄniÄn ShÄh", :latitude => "31.80528", :longitude => "72.27722").save
City.new(:country_id => "180", :name => "Jacobabad", :aliases => "Jacobabad,Jacobadad,JacobÄbÄd,JacobÄdad,JacobÄbÄd", :latitude => "28.28673", :longitude => "68.43316").save
City.new(:country_id => "180", :name => "Islamabad", :aliases => "Islamabad,Islamabade,Islamahbad,Islamampant,IslÄmÄbÄd,ÎÏÎ»Î±Î¼Î±Î¼ÏÎ¬Î½Ï,ÐÑÐ»Ð°Ð¼Ð°Ð±Ð°Ð´,IslÄmÄbÄd", :latitude => "33.72148", :longitude => "73.04329").save
City.new(:country_id => "180", :name => "Hyderabad", :aliases => "Haidarabad,Hyderabad,HyderÄbÄd,Khajdarabad,haidarabada,Ð¥Ð°Ð¹Ð´Ð°ÑÐ°Ð±Ð°Ð´,Ø­ÙØ¯Ø±Ø¢Ø¨Ø§Ø¯ Ø³ÙÚ,à¤¹à¥à¤¦à¤°à¤¾à¤¬à¤¾à¤¦,HyderÄbÄd", :latitude => "25.3823", :longitude => "68.3699").save
City.new(:country_id => "180", :name => "Hujra", :aliases => ",Hujra", :latitude => "30.73333", :longitude => "73.81667").save
City.new(:country_id => "180", :name => "Hingorja", :aliases => ",Hingorja", :latitude => "27.21168", :longitude => "68.41577").save
City.new(:country_id => "180", :name => "Hazro", :aliases => ",Hazro", :latitude => "33.90972", :longitude => "72.49278").save
City.new(:country_id => "180", :name => "Havelian", :aliases => "Havelian,HaveliÄn,HaveliÄn", :latitude => "34.05368", :longitude => "73.15644").save
City.new(:country_id => "180", :name => "Haveli", :aliases => ",Haveli", :latitude => "30.45", :longitude => "73.7").save
City.new(:country_id => "180", :name => "Hasilpur", :aliases => "Hasilpur,Hasipur,HÄsilpur,HÄsipur,HÄsilpur", :latitude => "29.71222", :longitude => "72.55528").save
City.new(:country_id => "180", :name => "Hasan Abdal", :aliases => ",Hasan AbdÄl", :latitude => "30.43333", :longitude => "72.7").save
City.new(:country_id => "180", :name => "Haru Zbad", :aliases => "Badruwala Mandi,BadruwÄla Mandi,Haroonabad Municipality,Haru Zbad,Harunabad,HÄrÅ«nÄbÄd,Haru Zbad", :latitude => "29.61333", :longitude => "73.13889").save
City.new(:country_id => "180", :name => "Harnoli", :aliases => "Haranoli,Harnoli,Harnoli", :latitude => "32.27917", :longitude => "71.55389").save
City.new(:country_id => "180", :name => "Haripur", :aliases => "Haripur,HarÄ«pur,Kharipur,Ð¥Ð°ÑÐ¸Ð¿ÑÑ,HarÄ«pur", :latitude => "33.99997", :longitude => "72.93409").save
City.new(:country_id => "180", :name => "Hangu", :aliases => ",Hangu", :latitude => "33.52861", :longitude => "71.05833").save
City.new(:country_id => "180", :name => "Hala", :aliases => "Hala,Halu,HÄla,Khala,Ð¥Ð°Ð»Ð°,HÄla", :latitude => "25.81308", :longitude => "68.42273").save
City.new(:country_id => "180", :name => "Hafizabad", :aliases => ",HÄfizÄbÄd", :latitude => "32.06786", :longitude => "73.68545").save
City.new(:country_id => "180", :name => "Hadali", :aliases => ",HadÄli", :latitude => "32.64132", :longitude => "74.56904").save
City.new(:country_id => "180", :name => "Gwadar", :aliases => "Gvadar,Gwadar,Gwadur,GwÄdar,gwadr,jwadr,ÐÐ²Ð°Ð´Ð°Ñ,Ø¬ÙØ§Ø¯Ø±,Ú¯ÙØ§Ø¯Ø±,GwÄdar", :latitude => "25.12163", :longitude => "62.32541").save
City.new(:country_id => "180", :name => "Gujrat", :aliases => "Gudzharat,Gujrat,GujrÄt,gjrat,ÐÑÐ´Ð¶Ð°ÑÐ°Ñ,Ú¯Ø¬Ø±Ø§Øª,GujrÄt", :latitude => "32.57276", :longitude => "74.08959").save
City.new(:country_id => "180", :name => "Gujranwala", :aliases => "Gajranvala,Gujranwala,GujrÄnwÄla,ÐÐ°Ð¹ÑÐ°Ð½Ð²Ð°Ð»Ð°,Ú¯ÙØ¬Ø±Ø§ÙÙØ§ÙÛ,GujrÄnwÄla", :latitude => "32.16167", :longitude => "74.18831").save
City.new(:country_id => "180", :name => "Gujar Khan", :aliases => ",GÅ«jar KhÄn", :latitude => "33.25355", :longitude => "73.30419").save
City.new(:country_id => "180", :name => "Gojra", :aliases => ",Gojra", :latitude => "31.14874", :longitude => "72.68656").save
City.new(:country_id => "180", :name => "Ghotki", :aliases => "Ghotki,Gotki,Ghotki", :latitude => "28.00604", :longitude => "69.31608").save
City.new(:country_id => "180", :name => "Ghauspur", :aliases => "Ghauspur,Ghouspur,Ghauspur", :latitude => "28.13762", :longitude => "69.08316").save
City.new(:country_id => "180", :name => "Gharo", :aliases => "Garho,Gharo,GhÄro,GhÄro", :latitude => "24.74241", :longitude => "67.58565").save
City.new(:country_id => "180", :name => "Garh Maharaja", :aliases => ",Garh MahÄrÄja", :latitude => "30.83388", :longitude => "71.90529").save
City.new(:country_id => "180", :name => "Gambat", :aliases => "Gambat,Gampat,Gumbad,Gambat", :latitude => "27.35145", :longitude => "68.52051").save
City.new(:country_id => "180", :name => "Fort Abbas", :aliases => "Abbas,Fort Abbas,Fort AbbÄs,Mandi,Fort AbbÄs", :latitude => "29.1925", :longitude => "72.85361").save
City.new(:country_id => "180", :name => "Fazalpur", :aliases => ",Fazalpur", :latitude => "32.18333", :longitude => "75.06667").save
City.new(:country_id => "180", :name => "Chak Two Hundred Forty-Nine TDA", :aliases => "Chak Two Hundred Forty-Nine TDA,Fatehpur,Chak Two Hundred Forty-Nine TDA", :latitude => "31.17959", :longitude => "71.20946").save
City.new(:country_id => "180", :name => "Faruka", :aliases => "Farooka,Faruka,Faruka", :latitude => "31.88833", :longitude => "72.41083").save
City.new(:country_id => "180", :name => "Faqirwali", :aliases => "Fagirwali,FagÄ«rwÄli,Faqirwala,Faqirwali,FaqÄ«rwÄla,FaqÄ«rwÄli,FaqÄ«rwÄli", :latitude => "29.46944", :longitude => "73.03111").save
City.new(:country_id => "180", :name => "Faisalabad", :aliases => "Faisalabad,FaisalÄbÄd,Feisalabada,Feisalabadas,Fejsalabade,Lyallpur,Shah Faisalabad,faisarabado,fysl abad,Ð¤ÐµÐ¹ÑÐ°Ð»Ð°Ð±Ð°Ð´Ðµ,ÙÙØµÙ Ø¢Ø¨Ø§Ø¯,ÙÛØµÙ Ø¢Ø¨Ø§Ø¯,ãã¡ã¤ãµã©ãã¼ã,ãã¡ã¤ãµã©ã¼ãã¼ã,FaisalÄbÄd", :latitude => "31.41667", :longitude => "73.08333").save
City.new(:country_id => "180", :name => "Eminabad", :aliases => "Eminabad,EminÄbÄd,EminÄbÄd", :latitude => "32.04361", :longitude => "74.262").save
City.new(:country_id => "180", :name => "Dunyapur", :aliases => ",DunyÄpur", :latitude => "29.7995", :longitude => "71.71958").save
City.new(:country_id => "180", :name => "Dunga Bunga", :aliases => ",Dunga Bunga", :latitude => "29.75", :longitude => "73.25").save
City.new(:country_id => "180", :name => "Dullewala", :aliases => "Dull-wali,Dullewala,Dullewali,DullewÄla,Dulliwala,DullewÄla", :latitude => "31.83587", :longitude => "71.43625").save
City.new(:country_id => "180", :name => "Dir", :aliases => "Dir,DÄ«r,DÄ«r", :latitude => "35.20583", :longitude => "71.87556").save
City.new(:country_id => "180", :name => "Dipalpur", :aliases => "Dipalpur,DÄ«pÄlpur,DÄ«pÄlpur", :latitude => "30.66667", :longitude => "73.65").save
City.new(:country_id => "180", :name => "Dinga", :aliases => ",Dinga", :latitude => "32.63976", :longitude => "73.72202").save
City.new(:country_id => "180", :name => "Dijkot", :aliases => ",Dijkot", :latitude => "31.21667", :longitude => "72.98333").save
City.new(:country_id => "180", :name => "Digri", :aliases => ",Digri", :latitude => "25.16667", :longitude => "69.11667").save
City.new(:country_id => "180", :name => "Dhoro Naro", :aliases => ",Dhoro NÄro", :latitude => "25.5", :longitude => "69.56667").save
City.new(:country_id => "180", :name => "Dhanot", :aliases => ",Dhanot", :latitude => "29.57991", :longitude => "71.75213").save
City.new(:country_id => "180", :name => "Dera Ismail Khan", :aliases => "Dera Ismail Khan,Dera IsmÄÄ«l KhÄn,Dera IsmÄÄ«l KhÄn", :latitude => "31.83269", :longitude => "70.9024").save
City.new(:country_id => "180", :name => "Dera Ghazi Khan", :aliases => "Dera Ghazi Khan,Dera Ghoz Khan,Dera GhÄzi KhÄn,Deri-Ghazi Khan,Dera GhÄzi KhÄn", :latitude => "30.05614", :longitude => "70.63477").save
City.new(:country_id => "180", :name => "Dera Bugti", :aliases => "Dera Bagti,Dera Bugti,Dera Bugti", :latitude => "29.03069", :longitude => "69.15099").save
City.new(:country_id => "180", :name => "Daur", :aliases => ",Daur", :latitude => "26.45834", :longitude => "68.31915").save
City.new(:country_id => "180", :name => "Daud Khel", :aliases => ",DÄÅ«d Khel", :latitude => "32.87498", :longitude => "71.57012").save
City.new(:country_id => "180", :name => "Daska", :aliases => ",Daska", :latitude => "32.32426", :longitude => "74.34974").save
City.new(:country_id => "180", :name => "Darya Khan", :aliases => "Darva Khan,Darva KhÄn,Darya Khan,Darya Khan Daggar,Darya KhÄn,Darya KhÄn", :latitude => "31.79123", :longitude => "71.10394").save
City.new(:country_id => "180", :name => "Dajal", :aliases => ",DÄjal", :latitude => "29.55767", :longitude => "70.37615").save
City.new(:country_id => "180", :name => "Dadu", :aliases => ",DÄdu", :latitude => "26.73333", :longitude => "67.78333").save
City.new(:country_id => "180", :name => "Dadhar", :aliases => "Dadhar,Dhadar,DÄdhar,DÄdhar", :latitude => "29.4816", :longitude => "67.6494").save
City.new(:country_id => "180", :name => "Chunian", :aliases => "Chunian,ChÅ«niÄn,ChÅ«niÄn", :latitude => "30.96667", :longitude => "73.98333").save
City.new(:country_id => "180", :name => "Chuhar Kana", :aliases => "Chuchar-kana Mandi,Chuhar Kana,Chuhar Kand,ChÅ«har KÄna,ChÅ«har KÄnd,ChÅ«har KÄna", :latitude => "31.75", :longitude => "73.8").save
City.new(:country_id => "180", :name => "Chor", :aliases => "Chhor,Chhor Purano,Chor,Chor", :latitude => "25.51667", :longitude => "69.76667").save
City.new(:country_id => "180", :name => "Choa Saidan Shah", :aliases => "Choa Saidan Shah,Choa SaidÄn ShÄh,Saidan Shah,SaidÄn ShÄh,Saiyidan Shah,SaiyidÄn ShÄh,Choa SaidÄn ShÄh", :latitude => "32.72006", :longitude => "72.98486").save
City.new(:country_id => "180", :name => "Chishtian Mandi", :aliases => "Chishtian Mandi,ChishtiÄn Mandi,Chistian,ChishtiÄn Mandi", :latitude => "29.8", :longitude => "72.86667").save
City.new(:country_id => "180", :name => "Chiniot", :aliases => "Chaniot,Chiniot,Chinot,Ð§Ð¸Ð½Ð¸Ð¾Ñ,Chiniot", :latitude => "31.72", :longitude => "72.97889").save
City.new(:country_id => "180", :name => "Chichawatni", :aliases => "Chichawatni,ChÄ«chÄwatni,ChÄ«chÄwatni", :latitude => "30.53333", :longitude => "72.7").save
City.new(:country_id => "180", :name => "Chawinda", :aliases => ",Chawinda", :latitude => "32.34692", :longitude => "74.70612").save
City.new(:country_id => "180", :name => "Charsadda", :aliases => "Charsadda,ChÄrsadda,ChÄrsadda", :latitude => "34.14528", :longitude => "71.73139").save
City.new(:country_id => "180", :name => "Chaman", :aliases => ",Chaman", :latitude => "30.91694", :longitude => "66.45972").save
City.new(:country_id => "180", :name => "Chakwal", :aliases => "Chakwal,ChakwÄl,ChakwÄl", :latitude => "32.93333", :longitude => "72.86667").save
City.new(:country_id => "180", :name => "Chak Azam Saffo", :aliases => "Chak Azam Saffo,Chak Azam Saho,Chak Azam Sahu,Chak Äzam Saffo,Chak Äzam Saffo", :latitude => "30.75", :longitude => "73.03333").save
City.new(:country_id => "180", :name => "Burewala", :aliases => ",BÅ«rewÄla", :latitude => "30.16667", :longitude => "72.65").save
City.new(:country_id => "180", :name => "Bhopalwala", :aliases => ",BhopÄlwÄla", :latitude => "32.42888", :longitude => "74.3633").save
City.new(:country_id => "180", :name => "Bhit Shah", :aliases => "Bhit Shah,Bhit ShÄh,Bhit ShÄh", :latitude => "25.80437", :longitude => "68.49265").save
City.new(:country_id => "180", :name => "Bhimbar", :aliases => "Bhimbar,Bhimber,Bhimbar", :latitude => "32.97568", :longitude => "74.07926").save
City.new(:country_id => "180", :name => "Bhera", :aliases => "Bhera,Bwera,Bhera", :latitude => "32.48318", :longitude => "72.9097").save
City.new(:country_id => "180", :name => "Bhawana", :aliases => "Bawana,Bhawana,BhawÄna,Bhowana,BhawÄna", :latitude => "31.56918", :longitude => "72.64899").save
City.new(:country_id => "180", :name => "Bhan", :aliases => ",BhÄn", :latitude => "26.55", :longitude => "67.71667").save
City.new(:country_id => "180", :name => "Bhalwal", :aliases => ",BhalwÄl", :latitude => "32.27204", :longitude => "72.90425").save
City.new(:country_id => "180", :name => "Bhakkar", :aliases => "Bhakkar,Bhakkar", :latitude => "31.62525", :longitude => "71.06574").save
City.new(:country_id => "180", :name => "Bhai Pheru", :aliases => "Bhai Pheru,Bhar Pheru,BhÄi Pheru,Mian-ki-Maur,MiÄn-ki-Maur,Phool Nagar,BhÄi Pheru", :latitude => "31.2", :longitude => "73.95").save
City.new(:country_id => "180", :name => "Bela", :aliases => "Armabel,Armail,Armel,Beila,Bela,Kambakia,Karabel,Las Bela,ÐÐµÐ»Ð°,Bela", :latitude => "26.2271", :longitude => "66.3111").save
City.new(:country_id => "180", :name => "Bat Khela", :aliases => "Bat Khela,Batkhel,Bat Khela", :latitude => "34.61667", :longitude => "71.97139").save
City.new(:country_id => "180", :name => "Basirpur", :aliases => ",BasÄ«rpur", :latitude => "30.58333", :longitude => "73.83333").save
City.new(:country_id => "180", :name => "Bannu", :aliases => ",Bannu", :latitude => "32.98991", :longitude => "70.60672").save
City.new(:country_id => "180", :name => "Bahawalpur", :aliases => "Bahawalpur,BahÄwalpur,Bakhavalpura,ÐÐ°ÑÐ°Ð²Ð°Ð»Ð¿ÑÑÐ°,BahÄwalpur", :latitude => "29.4", :longitude => "71.68333").save
City.new(:country_id => "180", :name => "Bahawalnagar", :aliases => "Bahawalnagar,Bahawalpur,Bahawatnagar,BahawÃ¢lpur,BahÄwalnagar,Ø¨ÛØ§ÙÙÙ¾ÙØ±,BahÄwalnagar", :latitude => "29.98333", :longitude => "73.26667").save
City.new(:country_id => "180", :name => "Badin", :aliases => ",BadÄ«n", :latitude => "24.65", :longitude => "68.83333").save
City.new(:country_id => "180", :name => "Baddomalhi", :aliases => ",Baddomalhi", :latitude => "31.99283", :longitude => "74.66834").save
City.new(:country_id => "180", :name => "Attock City", :aliases => "Attock City,Campbellpore,Campbellpur,Attock City", :latitude => "33.77222", :longitude => "72.36833").save
City.new(:country_id => "180", :name => "Arifwala", :aliases => "Arifwala,ÄrifwÄla,ÄrifwÄla", :latitude => "30.28333", :longitude => "73.06667").save
City.new(:country_id => "180", :name => "Amangarh", :aliases => "Amangarh,Amangarh", :latitude => "34.00583", :longitude => "71.93").save
City.new(:country_id => "180", :name => "Alipur", :aliases => ",AlÄ«pur", :latitude => "29.38464", :longitude => "70.91157").save
City.new(:country_id => "180", :name => "Akora", :aliases => "Akora,Akora Khattak,Akora KhÄttak,ÐÐºÐ¾ÑÐ°,Akora", :latitude => "34.00361", :longitude => "72.12611").save
City.new(:country_id => "180", :name => "Ahmadpur East", :aliases => "Ahmadpur,Ahmadpur East,Ahmedpur East,Ahmedpur East Municipality,Ahmadpur East", :latitude => "29.14462", :longitude => "71.26084").save
City.new(:country_id => "180", :name => "Bahawalnagar", :aliases => "Bahawalnagar,BahÄwalnagar,BahÄwalnagar", :latitude => "30.55083", :longitude => "73.39083").save
City.new(:country_id => "180", :name => "Nowshera Cantonment", :aliases => ",Nowshera Cantonment", :latitude => "33.99667", :longitude => "72.01306").save
City.new(:country_id => "180", :name => "Ahmadpur Sial", :aliases => ",Ahmadpur SiÄl", :latitude => "30.67519", :longitude => "71.74905").save
City.new(:country_id => "180", :name => "New Badah", :aliases => ",New BÄdÄh", :latitude => "27.34167", :longitude => "68.03194").save
City.new(:country_id => "180", :name => "Tando Ghulam Ali", :aliases => ",Tando GhulÄm Ali", :latitude => "25.13056", :longitude => "68.86667").save
City.new(:country_id => "180", :name => "Setharja Old", :aliases => ",SethÄrja Old", :latitude => "27.21427", :longitude => "68.46868").save
City.new(:country_id => "180", :name => "Risalpur", :aliases => "Risalpur,RisÄlpur,RisÄlpur", :latitude => "34.06333", :longitude => "71.99361").save
City.new(:country_id => "180", :name => "Malakwal City", :aliases => ",Malakwal City", :latitude => "32.55492", :longitude => "73.2122").save
