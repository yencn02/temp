City.new(:country_id => "190", :name => "Saint-Pierre", :aliases => "Saint-Pierre,Sent-P'er,Ð¡ÐµÐ½Ñ-ÐÑÐµÑ,Saint-Pierre", :latitude => "-21.31667", :longitude => "55.48333").save
City.new(:country_id => "190", :name => "Saint-Paul", :aliases => "Saint-Paul,Saint-Paul", :latitude => "-21", :longitude => "55.26667").save
City.new(:country_id => "190", :name => "Saint-Louis", :aliases => "Saint-Louis,Sen-Lui,Ð¡ÐµÐ½-ÐÑÐ¸,Saint-Louis", :latitude => "-21.26667", :longitude => "55.41667").save
City.new(:country_id => "190", :name => "Saint-Leu", :aliases => "Saint-Leu,Sankt-Leu,Ð¡Ð°Ð½ÐºÑ-ÐÐµÑ,Saint-Leu", :latitude => "-21.15", :longitude => "55.28333").save
City.new(:country_id => "190", :name => "Saint-Joseph", :aliases => "Saint-Joseph,Sent-Dzhozef,Ð¡ÐµÐ½Ñ-ÐÐ¶Ð¾Ð·ÐµÑ,Saint-Joseph", :latitude => "-21.36667", :longitude => "55.61667").save
City.new(:country_id => "190", :name => "Sainte-Suzanne", :aliases => "Sainte-Suzanne,Sainte-Suzanne", :latitude => "-20.9", :longitude => "55.61667").save
City.new(:country_id => "190", :name => "Sainte-Marie", :aliases => "Sainte-Marie,Sent-Mari,Ð¡ÐµÐ½Ñ-ÐÐ°ÑÐ¸,Sainte-Marie", :latitude => "-20.88333", :longitude => "55.55").save
City.new(:country_id => "190", :name => "Saint-Denis", :aliases => "Saint-Denis,Saint-Denis de la Reunion,Saint-Denis de la RÃ©union,Sen-Deni,St. Denis,snt dnys,Ð¡ÐµÐ½-ÐÐµÐ½Ð¸,×¡× × ×× ××¡,ãµã³ã»ãã¥ã,Saint-Denis", :latitude => "-20.88231", :longitude => "55.4504").save
City.new(:country_id => "190", :name => "Saint-Benoit", :aliases => "Saint-Benoit,Saint-BenoÃ®t,Sankt-Benua,Ð¡Ð°Ð½ÐºÑ-ÐÐµÐ½ÑÐ°,Saint-BenoÃ®t", :latitude => "-21.03333", :longitude => "55.71667").save
City.new(:country_id => "190", :name => "Saint-Andre", :aliases => "Saint-Andre,Saint-AndrÃ©,Sankt-Andre,Ð¡Ð°Ð½ÐºÑ-ÐÐ½Ð´ÑÐµ,Saint-AndrÃ©", :latitude => "-20.95", :longitude => "55.65").save
City.new(:country_id => "190", :name => "Le Tampon", :aliases => "Le Tampon,Tampon,Village du Tampon,Le Tampon", :latitude => "-21.26667", :longitude => "55.51667").save
City.new(:country_id => "190", :name => "Le Port", :aliases => "La Point-aux-galets,Le Port,Le Port des Galets,Port,Port de la Pointe des Galets,Port des Galets,Le Port", :latitude => "-20.91667", :longitude => "55.3").save
City.new(:country_id => "190", :name => "La Possession", :aliases => "La Possession,Possession,La Possession", :latitude => "-20.91667", :longitude => "55.33333").save
