City.new(:country_id => "171", :name => "Government Offices", :aliases => ",Government Offices", :latitude => "-0.54756", :longitude => "166.91729").save
