City.new(:country_id => "134", :name => "Quthing", :aliases => "Cguting,Moyeni,Quthing,Ð¦Ð³ÑÑÐ¸Ð½Ð³,Quthing", :latitude => "-30.40001", :longitude => "27.70027").save
City.new(:country_id => "134", :name => "Qacha's Nek", :aliases => "Qacha's Neck,Qacha's Nek,Qacha's Nek Residency,Qachas Nek Camp,Qachasnek Camp,Qachaâs Neck,Qachaâs Nek,Qachaâs Nek Residency,Qachaâs Nek", :latitude => "-30.11537", :longitude => "28.68936").save
City.new(:country_id => "134", :name => "Mohale's Hoek", :aliases => "Mohale's Hoek,Mohaleâs Hoek,Mohaleâs Hoek", :latitude => "-30.15137", :longitude => "27.47691").save
City.new(:country_id => "134", :name => "Maseru", :aliases => "Maserou,Maseru,ma sai lu,ma se ru,maselu,maseru,masrw,masyrw,msrw,ÎÎ±ÏÎµÏÎ¿Ï,ÐÐ°ÑÐµÑÑ,××¡×¨×,ÙØ§Ø³Ø±Ù,ÙØ§Ø³ÙØ±Ù,à¸¡à¸²à¹à¸à¸£à¸¹,áá´á©,ãã»ã«,é©¬å¡å¢,ë§ì¸ë£¨,Maseru", :latitude => "-29.31667", :longitude => "27.48333").save
City.new(:country_id => "134", :name => "Maputsoe", :aliases => ",Maputsoe", :latitude => "-28.88333", :longitude => "27.9").save
City.new(:country_id => "134", :name => "Mafeteng", :aliases => "Mafeteng,Mafeteng", :latitude => "-29.823", :longitude => "27.23744").save
City.new(:country_id => "134", :name => "Leribe", :aliases => "Hlotse,Leribe,ÐÐµÑÐ¸Ð±Ðµ,Leribe", :latitude => "-28.87185", :longitude => "28.04501").save
City.new(:country_id => "134", :name => "Butha-Buthe", :aliases => "Buta-Buteh,Butha-Buthe,ÐÑÑÐ°-ÐÑÑÑ,Butha-Buthe", :latitude => "-28.76659", :longitude => "28.24936").save
