City.new(:country_id => "59", :name => "Viborg", :aliases => "Viborg,Wibergis,ÐÐ¸Ð±Ð¾ÑÐ³,Viborg", :latitude => "56.45319", :longitude => "9.40201").save
City.new(:country_id => "59", :name => "Vejle", :aliases => "Vajle,Vejle,ÐÐ°Ð¹Ð»Ðµ,Vejle", :latitude => "55.70927", :longitude => "9.5357").save
City.new(:country_id => "59", :name => "Taastrup", :aliases => "Taastrup,Tastrup,TÃ¥strup,Ð¢Ð°Ð°ÑÑÑÑÐ¿,Taastrup", :latitude => "55.65173", :longitude => "12.29216").save
City.new(:country_id => "59", :name => "Svendborg", :aliases => "Svenborg,Svendborg,Svennborge,Ð¡Ð²ÐµÐ½Ð½Ð±Ð¾ÑÐ³Ðµ,Svendborg", :latitude => "55.05982", :longitude => "10.60677").save
City.new(:country_id => "59", :name => "Stenlose", :aliases => ",StenlÃ¸se", :latitude => "55.76828", :longitude => "12.19723").save
City.new(:country_id => "59", :name => "Sonderborg", :aliases => "Sjonnenborg,Sonderborg,Sonderburg,Synneborre,SÃ¸nderborg,Ð¡ÑÐ½Ð½ÐµÐ½Ð±Ð¾ÑÐ³,SÃ¸nderborg", :latitude => "54.90926", :longitude => "9.80737").save
City.new(:country_id => "59", :name => "Slagelse", :aliases => "Slagel'se,Slagelse,Ð¡Ð»Ð°Ð³ÐµÐ»ÑÑÐµ,Slagelse", :latitude => "55.40276", :longitude => "11.35459").save
City.new(:country_id => "59", :name => "Skive", :aliases => "Skive,Ð¡ÐºÐ¸Ð²Ðµ,Skive", :latitude => "56.56667", :longitude => "9.03333").save
City.new(:country_id => "59", :name => "Silkeborg", :aliases => "Sil'keborg,Silkeborg,Ð¡Ð¸Ð»ÑÐºÐµÐ±Ð¾ÑÐ³,Silkeborg", :latitude => "56.1697", :longitude => "9.54508").save
City.new(:country_id => "59", :name => "Roskilde", :aliases => "Hroarskelda,HrÃ³arskelda,Roskilde,Roskille,luo si ji lei,rosukire,Ð Ð¾ÑÐºÐ¸Ð»Ð»Ðµ,ã­ã¹ã­ã¬,ç½æ¯åºå,Roskilde", :latitude => "55.64152", :longitude => "12.08035").save
City.new(:country_id => "59", :name => "Rodovre", :aliases => "Rodovre,RÃ¸dovre,RÃ¸dovre", :latitude => "55.68062", :longitude => "12.45373").save
City.new(:country_id => "59", :name => "Ringsted", :aliases => "Ringsted,Ð Ð¸Ð½Ð³ÑÑÐµÐ´,Ringsted", :latitude => "55.4426", :longitude => "11.79011").save
City.new(:country_id => "59", :name => "Randers", :aliases => "Randers,Ð Ð°Ð½Ð´ÐµÑÑ,Randers", :latitude => "56.46667", :longitude => "10.05").save
City.new(:country_id => "59", :name => "Odense", :aliases => "Odense,Odenze,awdnsh,odense,ou deng sai,ÐÐ´ÐµÐ½Ð·Ðµ,ÐÐ´ÐµÐ½ÑÐµ,×××× ××,Ø£ÙØ¯ÙØ³Ù,ãªã¼ãã³ã»,æ¬§ç»å¡,ì¤ë´ì¸,Odense", :latitude => "55.39594", :longitude => "10.38831").save
City.new(:country_id => "59", :name => "Nykobing Falster", :aliases => "Nykjobing,NykÃ¸bing Falster", :latitude => "54.76906", :longitude => "11.87425").save
City.new(:country_id => "59", :name => "Nyborg", :aliases => "Nyborg,Nyborg", :latitude => "55.31274", :longitude => "10.78964").save
City.new(:country_id => "59", :name => "Naestved", :aliases => "Nestved,ÐÐµÑÑÐ²ÐµÐ´,NÃ¦stved", :latitude => "55.22992", :longitude => "11.76092").save
City.new(:country_id => "59", :name => "Lillerod", :aliases => ",LillerÃ¸d", :latitude => "55.87496", :longitude => "12.34579").save
City.new(:country_id => "59", :name => "Korsor", :aliases => "Korsor,KorsÃ¸r,KorsÃ¸r", :latitude => "55.32993", :longitude => "11.13857").save
City.new(:country_id => "59", :name => "Koge", :aliases => "Kege,Kjoge,Koge,KÃ¸ge,kyuge,ÐÐµÐ³Ðµ,ã­ã¥ã¼ã²,KÃ¸ge", :latitude => "55.45802", :longitude => "12.18214").save
City.new(:country_id => "59", :name => "Copenhagen", :aliases => "Cobanhavan,Copenaga,Copenaghen,Copenaguen,Copenhaga,Copenhagen,Copenhague,Copenhaguen,Copenhaguen - Kobenhavn,Copenhaguen - KÃ¸benhavn,CÃ³banhÃ¡van,Hafnia,Kapehngagen,Kaupmannahoefn,KaupmannahÃ¶fn,Keypmannahavn,Kjobenhavn,Kjopenhamn,KjÃ¸penhamn,Kobenhamman,Kobenhaven,Kobenhavn,Kodan,KodaÅ,Koebenhavn,Koeoepenhamina,Koepenhamn,Kopenage,Kopenchage,Kopengagen,Kopenhaagen,Kopenhag,Kopenhaga,Kopenhage,Kopenhagen,Kopenhagena,Kopenhago,KopenhÄgena,Kopenkhagen,Koppenhaga,KoppenhÃ¡ga,KÃ²penhaga,KÃ¶benhavn,KÃ¶penhamn,KÃ¶Ã¶penhamina,KÃ¸benhavn,KÃ¸benhÃ¡mman,ge ben ha gen,khopenheken,kopanahagana,kopenahagena,kopenahegena,kopenhagen,kwbnhaghn,kwpnhgn,qwpnhgn,ÎÎ¿ÏÎµÎ³ÏÎ¬Î³Î·,ÐÐ°Ð¿ÑÐ½Ð³Ð°Ð³ÐµÐ½,ÐÐ¾Ð¿ÐµÐ½Ð³Ð°Ð³ÐµÐ½,ÐÐ¾Ð¿ÐµÐ½ÑÐ°Ð³ÐµÐ½,Ô¿Õ¸ÕºÕ¥Õ¶Õ°Õ¡Õ£Õ¥Õ¶,×§××¤× ××××,×§××¤× ×××,ÙÙØ¨ÙÙØ§ØºÙ,ÙÙÙ¾ÛÙÚ¾Ø§Ú¯ÛÙ,ÜÜÜ¦Ü¢ÜÜÜ¢,à¤à¥à¤ªà¤¨à¤¹à¤¾à¤à¤¨,à¦à§à¦ªà§à¦¨à¦¹à¦¾à¦à§à¦¨,à¦à§à¦ªà§à¦¨à¦¹à§à¦à§à¦¨,à¹à¸à¹à¸à¸à¹à¸®à¹à¸à¸,à½à½ à½¼à¼à½à½ºà½à¼à½§à¼à½à½ºà½,áááááá°ááááá,á®ááááá,á®áááá,ã³ãã³ãã¼ã²ã³,å¥æ¬åæ ¹,ì½ííê²,Copenhagen", :latitude => "55.67594", :longitude => "12.56553").save
City.new(:country_id => "59", :name => "Kolding", :aliases => "Kolding,Koldingo,Kolinga,ÐÐ¾Ð»Ð´Ð¸Ð½Ð³,Kolding", :latitude => "55.4904", :longitude => "9.47216").save
City.new(:country_id => "59", :name => "Kalundborg", :aliases => "Kallundborg,Kalundborg,Kalundborg", :latitude => "55.67954", :longitude => "11.08864").save
City.new(:country_id => "59", :name => "Ishoj", :aliases => "Ishoj,IshÃ¸j,IshÃ¸j", :latitude => "55.61543", :longitude => "12.35182").save
City.new(:country_id => "59", :name => "Hvidovre", :aliases => "Hvidovre,Khvidovre,Ð¥Ð²Ð¸Ð´Ð¾Ð²ÑÐµ,Hvidovre", :latitude => "55.65719", :longitude => "12.47364").save
City.new(:country_id => "59", :name => "Horsens", :aliases => "Horsens,Khorsens,huo er sen si,Ð¥Ð¾ÑÑÐµÐ½Ñ,éå°æ£®æ¯,Horsens", :latitude => "55.86066", :longitude => "9.85034").save
City.new(:country_id => "59", :name => "Horsholm", :aliases => "Horsholm,HÃ¸rsholm,Kherskhol'm,Ð¥ÐµÑÑÑÐ¾Ð»ÑÐ¼,HÃ¸rsholm", :latitude => "55.88333", :longitude => "12.5").save
City.new(:country_id => "59", :name => "Holstebro", :aliases => "Holstebro,Khol'stebro,Ð¥Ð¾Ð»ÑÑÑÐµÐ±ÑÐ¾,Holstebro", :latitude => "56.36009", :longitude => "8.61607").save
City.new(:country_id => "59", :name => "Holbaek", :aliases => "Holbaek,HolbÃ¦k,Hollbaek,HollbÃ¦k,Khol'bek,Ð¥Ð¾Ð»ÑÐ±ÐµÐº,HolbÃ¦k", :latitude => "55.71667", :longitude => "11.71667").save
City.new(:country_id => "59", :name => "Hjorring", :aliases => "Hjoerring,Hjorring,HjÃ¶rring,HjÃ¸rring,HjÃ¸rring", :latitude => "57.46417", :longitude => "9.98229").save
City.new(:country_id => "59", :name => "Hillerod", :aliases => "Hillerod,HillerÃ¸d,Khillerod,hylrwd,Ð¥Ð¸Ð»Ð»ÐµÑÐ¾Ð´,××××¨××,HillerÃ¸d", :latitude => "55.92667", :longitude => "12.31091").save
City.new(:country_id => "59", :name => "Herning", :aliases => "Herning,Kherning,Ð¥ÐµÑÐ½Ð¸Ð½Ð³,Herning", :latitude => "56.13932", :longitude => "8.97378").save
City.new(:country_id => "59", :name => "Helsingor", :aliases => "Elseneur,Elsinor,Elsinore,Helsingor,HelsingÃ¸r,Khel'singjor,Ð¥ÐµÐ»ÑÑÐ¸Ð½Ð³ÑÑ,HelsingÃ¸r", :latitude => "56.03606", :longitude => "12.6136").save
City.new(:country_id => "59", :name => "Haderslev", :aliases => "Hadersleben,Haderslev,Haderslevo,Khaderslev,Ð¥Ð°Ð´ÐµÑÑÐ»ÐµÐ²,Haderslev", :latitude => "55.25377", :longitude => "9.48982").save
City.new(:country_id => "59", :name => "Greve", :aliases => ",Greve", :latitude => "55.58333", :longitude => "12.3").save
City.new(:country_id => "59", :name => "Glostrup", :aliases => "Glostrup,Glostrup", :latitude => "55.66667", :longitude => "12.4").save
City.new(:country_id => "59", :name => "Frederikshavn", :aliases => "Fladstrand,Frederikskhavn,Ð¤ÑÐµÐ´ÐµÑÐ¸ÐºÑÑÐ°Ð²Ð½,Frederikshavn", :latitude => "57.44073", :longitude => "10.53661").save
City.new(:country_id => "59", :name => "Frederiksberg", :aliases => "Frederiksberg,Ð¤ÑÐµÐ´ÐµÑÐ¸ÐºÑÐ±ÐµÑÐ³,Frederiksberg", :latitude => "55.67938", :longitude => "12.53463").save
City.new(:country_id => "59", :name => "Fredericia", :aliases => "Fredericia,Frederisija,Ð¤ÑÐµÐ´ÐµÑÐ¸ÑÐ¸Ñ,Fredericia", :latitude => "55.56568", :longitude => "9.75257").save
City.new(:country_id => "59", :name => "Farum", :aliases => "Farum,Ð¤Ð°ÑÑÐ¼,Farum", :latitude => "55.80858", :longitude => "12.36066").save
City.new(:country_id => "59", :name => "Esbjerg", :aliases => "Ehsberg,Esbjaerg,Esbjerg,Esbjerga,EsbjÃ¦rg,Ð­ÑÐ±ÐµÑÐ³,Esbjerg", :latitude => "55.46667", :longitude => "8.45").save
City.new(:country_id => "59", :name => "Charlottenlund", :aliases => ",Charlottenlund", :latitude => "55.75", :longitude => "12.58333").save
City.new(:country_id => "59", :name => "Birkerod", :aliases => "Birkerod,BirkerÃ¸d,BirkerÃ¸d", :latitude => "55.84759", :longitude => "12.42791").save
City.new(:country_id => "59", :name => "Ballerup", :aliases => "Balleru,Ballerup,Ballerup", :latitude => "55.73165", :longitude => "12.36328").save
City.new(:country_id => "59", :name => "Arhus", :aliases => "Aarhus,Aarhusium,Arhus,Arhuzo,Arkhus,Arosar,Orhusa,OrhÅ«sa,Orkhus,ao hu si,ofusu,ÃrÃ³sar,Ãrhus,ÐÑÑÑÑ,ÐÑÑÑÑ,×××¨×××¡,ãªã¼ãã¹,å¥¥è¡æ¯,Ãrhus", :latitude => "56.15674", :longitude => "10.21076").save
City.new(:country_id => "59", :name => "Aalborg", :aliases => "Aalborg,Alaborg,Alborg,Ol'borg,Olborg,Olborga,orubo,Ãlaborg,Ãlborg,ÐÐ»Ð±Ð¾ÑÐ³,ÐÐ»ÑÐ±Ð¾ÑÐ³,ãªã¼ã«ãã¼,Aalborg", :latitude => "57.048", :longitude => "9.9187").save
City.new(:country_id => "59", :name => "Albertslund", :aliases => "Al'bertslunn,Albertslund,Gmina Albertslund,ÐÐ»ÑÐ±ÐµÑÑÑÐ»ÑÐ½Ð½,Albertslund", :latitude => "55.65691", :longitude => "12.36381").save
City.new(:country_id => "59", :name => "Aabenraa", :aliases => "Aabenraa,Abenra,AbenrÃ¡,Abrenra,Apenrade,ÃbenrÃ¥,ÃbrenrÃ¥,Aabenraa", :latitude => "55.04434", :longitude => "9.41741").save
