City.new(:country_id => "50", :name => "Zipaquira", :aliases => "Zipaquira,ZipaquirÃ¡,ZipaquirÃ¡", :latitude => "5.02833", :longitude => "-74.00583").save
City.new(:country_id => "50", :name => "Zarzal", :aliases => "Zarzal,Zarzal", :latitude => "4.39833", :longitude => "-76.07722").save
City.new(:country_id => "50", :name => "Zaragoza", :aliases => "Zaragoza,Zaragoza", :latitude => "7.49417", :longitude => "-74.87111").save
City.new(:country_id => "50", :name => "Yumbo", :aliases => ",Yumbo", :latitude => "3.585", :longitude => "-76.49583").save
City.new(:country_id => "50", :name => "Yopal", :aliases => "El Yopal,Jopal',Marroquin,MarroquÃ­n,Yopal,ÐÐ¾Ð¿Ð°Ð»Ñ,Yopal", :latitude => "5.33944", :longitude => "-72.39417").save
City.new(:country_id => "50", :name => "Yarumal", :aliases => ",Yarumal", :latitude => "6.96472", :longitude => "-75.42028").save
City.new(:country_id => "50", :name => "Viterbo", :aliases => "Viterbo,Viterbo", :latitude => "5.06361", :longitude => "-75.87528").save
City.new(:country_id => "50", :name => "Villeta", :aliases => ",Villeta", :latitude => "5.01472", :longitude => "-74.47472").save
City.new(:country_id => "50", :name => "Villavicencio", :aliases => "Cantarrana,Caserio Villavicencio,Viljavisensijas,Viljavisensio,Villavicencio,ÐÐ¸Ð»ÑÐ²Ð¸ÑÐµÐ½ÑÐ¸Ð¾,Villavicencio", :latitude => "4.142", :longitude => "-73.62664").save
City.new(:country_id => "50", :name => "Villa del Rosario", :aliases => "Rosario,Vil'ja-del'-Rosario,Villa Rosario,Villa del Rosario,ÐÐ¸Ð»ÑÑ-Ð´ÐµÐ»Ñ-Ð Ð¾ÑÐ°ÑÐ¸Ð¾,Villa del Rosario", :latitude => "7.83389", :longitude => "-72.47417").save
City.new(:country_id => "50", :name => "Villanueva", :aliases => ",Villanueva", :latitude => "10.60528", :longitude => "-72.98").save
City.new(:country_id => "50", :name => "Villanueva", :aliases => ",Villanueva", :latitude => "5.28333", :longitude => "-71.96667").save
City.new(:country_id => "50", :name => "Villamaria", :aliases => ",VillamarÃ­a", :latitude => "5.04778", :longitude => "-75.51556").save
City.new(:country_id => "50", :name => "Valledupar", :aliases => "Valedupar,Valjeduparas,Valledupar,twrbw,ÐÐ°Ð»ÐµÐ´ÑÐ¿Ð°Ñ,ØªÙØ±Ø¨Ù,Valledupar", :latitude => "10.47694", :longitude => "-73.25056").save
City.new(:country_id => "50", :name => "Urrao", :aliases => "Urrao,Urrao", :latitude => "6.31972", :longitude => "-76.13833").save
City.new(:country_id => "50", :name => "Ubate", :aliases => "Ubate,UbatÃ©,UbatÃ©", :latitude => "5.31222", :longitude => "-73.81917").save
City.new(:country_id => "50", :name => "Turbo", :aliases => "Turbo,Turbo", :latitude => "8.09368", :longitude => "-76.72691").save
City.new(:country_id => "50", :name => "Turbaco", :aliases => ",Turbaco", :latitude => "10.32944", :longitude => "-75.41137").save
City.new(:country_id => "50", :name => "Tuquerres", :aliases => "Tuquerres,TÃºquerres,TÃºquerres", :latitude => "1.09234", :longitude => "-77.62085").save
City.new(:country_id => "50", :name => "Tunja", :aliases => "Tunja,Tunja", :latitude => "5.53528", :longitude => "-73.36778").save
City.new(:country_id => "50", :name => "Tumaco", :aliases => "Tucano,Tumaco,Tumako,Ð¢ÑÐ¼Ð°ÐºÐ¾,Tumaco", :latitude => "1.79861", :longitude => "-78.81556").save
City.new(:country_id => "50", :name => "Tulua", :aliases => "Tulua,TuluÃ¡,Ð¢ÑÐ»ÑÐ°,TuluÃ¡", :latitude => "4.08667", :longitude => "-76.2").save
City.new(:country_id => "50", :name => "Tolu", :aliases => "Tol,Tolu,TolÃº,Ð¢Ð¾Ð»,TolÃº", :latitude => "9.52392", :longitude => "-75.58139").save
City.new(:country_id => "50", :name => "Tierralta", :aliases => "Los Bongos,T'erral'ta,Tierra Alta,Tierralta,Ð¢ÑÐµÑÑÐ°Ð»ÑÑÐ°,Tierralta", :latitude => "8.17361", :longitude => "-76.05917").save
City.new(:country_id => "50", :name => "Tame", :aliases => "Tam,Tame,Ð¢Ð°Ð¼,Tame", :latitude => "6.461", :longitude => "-71.73004").save
City.new(:country_id => "50", :name => "Sucre", :aliases => "Boca de Granada,Sucre,Sukre,Ð¡ÑÐºÑÐµ,Sucre", :latitude => "8.81389", :longitude => "-74.72528").save
City.new(:country_id => "50", :name => "Sonson", :aliases => "Sonson,SonsÃ³n,SonsÃ³n", :latitude => "5.71222", :longitude => "-75.31389").save
City.new(:country_id => "50", :name => "Soledad", :aliases => ",Soledad", :latitude => "10.91722", :longitude => "-74.76667").save
City.new(:country_id => "50", :name => "Sogamoso", :aliases => "Sogamoso,Ð¡Ð¾Ð³Ð°Ð¼Ð¾ÑÐ¾,Sogamoso", :latitude => "5.72056", :longitude => "-72.92972").save
City.new(:country_id => "50", :name => "Socorro", :aliases => ",Socorro", :latitude => "6.46972", :longitude => "-73.26167").save
City.new(:country_id => "50", :name => "Soacha", :aliases => "Soacha,Soachu,Ð¡Ð¾Ð°ÑÑ,Soacha", :latitude => "4.58722", :longitude => "-74.22139").save
City.new(:country_id => "50", :name => "Sincelejo", :aliases => "Cincelejo,Sincelejo,Sinselekho,Ð¡Ð¸Ð½ÑÐµÐ»ÐµÑÐ¾,Sincelejo", :latitude => "9.30472", :longitude => "-75.39778").save
City.new(:country_id => "50", :name => "Since", :aliases => "Since,SincÃ©,SincÃ©", :latitude => "9.24694", :longitude => "-75.15083").save
City.new(:country_id => "50", :name => "Sibate", :aliases => "Sibate,SibatÃ©,SibatÃ©", :latitude => "4.49139", :longitude => "-74.26056").save
City.new(:country_id => "50", :name => "Sevilla", :aliases => ",Sevilla", :latitude => "4.26889", :longitude => "-75.93611").save
City.new(:country_id => "50", :name => "Segovia", :aliases => ",Segovia", :latitude => "7.08333", :longitude => "-74.70361").save
City.new(:country_id => "50", :name => "Santuario", :aliases => ",Santuario", :latitude => "6.13833", :longitude => "-75.26417").save
City.new(:country_id => "50", :name => "Santo Tomas", :aliases => ",Santo TomÃ¡s", :latitude => "10.76111", :longitude => "-74.75").save
City.new(:country_id => "50", :name => "Santa Rosa de Cabal", :aliases => "Santa Rosa,Santa Rosa Cabal,Santa Rosa de Cabal,Santa-Rosa-de-Kabal',Ð¡Ð°Ð½ÑÐ°-Ð Ð¾ÑÐ°-Ð´Ðµ-ÐÐ°Ð±Ð°Ð»Ñ,Santa Rosa de Cabal", :latitude => "4.86806", :longitude => "-75.62139").save
City.new(:country_id => "50", :name => "Santander de Quilichao", :aliases => "Quilichao,Santander,Santander de Quilichao,Santander de Quilichao", :latitude => "3.01306", :longitude => "-76.48667").save
City.new(:country_id => "50", :name => "Santa Marta", :aliases => "Santa Marta,santa marta,snth mrth,Ð¡Ð°Ð½ÑÐ° ÐÐ°ÑÑÐ°,×¡× ×× ××¨×ª×,Ø³Ø§ÙØªØ§ ÙØ§Ø±ØªØ§,Santa Marta", :latitude => "11.24722", :longitude => "-74.20167").save
City.new(:country_id => "50", :name => "Santa Lucia", :aliases => "Corregimiento Santa Lucia,Santa Lucia,Santa LucÃ­a,Santa LucÃ­a", :latitude => "10.3242", :longitude => "-74.96017").save
City.new(:country_id => "50", :name => "San Onofre", :aliases => "San Onofre,San Onofre", :latitude => "9.73586", :longitude => "-75.52626").save
City.new(:country_id => "50", :name => "San Martin", :aliases => ",San MartÃ­n", :latitude => "3.69637", :longitude => "-73.69958").save
City.new(:country_id => "50", :name => "San Marcos", :aliases => ",San Marcos", :latitude => "8.66111", :longitude => "-75.13472").save
City.new(:country_id => "50", :name => "San Juan Nepomuceno", :aliases => "San Juan,San Juan Nepomuceno,San Juan Nepomuceno", :latitude => "9.95156", :longitude => "-75.08198").save
City.new(:country_id => "50", :name => "San Juan del Cesar", :aliases => "San Juan de Cesar,San Juan de CÃ©sar,San Juan del Cesar,San Juan del Cesar", :latitude => "10.77361", :longitude => "-73.00833").save
City.new(:country_id => "50", :name => "San Jacinto", :aliases => ",San Jacinto", :latitude => "9.82767", :longitude => "-75.1217").save
City.new(:country_id => "50", :name => "San Gil", :aliases => "San Gil,San Gil", :latitude => "6.55944", :longitude => "-73.13611").save
City.new(:country_id => "50", :name => "San Carlos", :aliases => ",San Carlos", :latitude => "8.80056", :longitude => "-75.70222").save
City.new(:country_id => "50", :name => "San Carlos", :aliases => ",San Carlos", :latitude => "7.83333", :longitude => "-74.76667").save
City.new(:country_id => "50", :name => "San Benito Abad", :aliases => "San Benito Abab,San Benito Abad,Tocasman,TocasmÃ¡n,San Benito Abad", :latitude => "8.93167", :longitude => "-75.03083").save
City.new(:country_id => "50", :name => "San Andres", :aliases => "San Andres,San AndrÃ©s,San AndrÃ©s", :latitude => "12.58472", :longitude => "-81.70056").save
City.new(:country_id => "50", :name => "Sampues", :aliases => "Sampues,SampuÃ©s,SampuÃ©s", :latitude => "9.18361", :longitude => "-75.38167").save
City.new(:country_id => "50", :name => "Salamina", :aliases => ",Salamina", :latitude => "5.40833", :longitude => "-75.49").save
City.new(:country_id => "50", :name => "Sahagun", :aliases => "Sahagun,SahagÃºn,SahagÃºn", :latitude => "8.94944", :longitude => "-75.44778").save
City.new(:country_id => "50", :name => "Sabaneta", :aliases => "Sabaneta,Sabanetas,Ð¡Ð°Ð±Ð°Ð½ÐµÑÐ°,Sabaneta", :latitude => "6.15", :longitude => "-75.6").save
City.new(:country_id => "50", :name => "Sabanalarga", :aliases => "Sabanalarga,Sabanalargo,Sabanalarga", :latitude => "10.62962", :longitude => "-74.92063").save
City.new(:country_id => "50", :name => "Sabanagrande", :aliases => ",Sabanagrande", :latitude => "10.79115", :longitude => "-74.76059").save
City.new(:country_id => "50", :name => "Roldanillo", :aliases => "Roldanillo,Roldanillo", :latitude => "4.41472", :longitude => "-76.15472").save
City.new(:country_id => "50", :name => "Riosucio", :aliases => "Riosucio,Ruiosucio,Riosucio", :latitude => "5.42444", :longitude => "-75.70583").save
City.new(:country_id => "50", :name => "Rionegro", :aliases => "Rionegro,Rionegro", :latitude => "6.15528", :longitude => "-75.38889").save
City.new(:country_id => "50", :name => "Riohacha", :aliases => "Riochacha,Riohacha,RÃ­ohacha,RÃ­ohacha", :latitude => "11.54444", :longitude => "-72.90722").save
City.new(:country_id => "50", :name => "Repelon", :aliases => ",RepelÃ³n", :latitude => "10.49194", :longitude => "-75.12917").save
City.new(:country_id => "50", :name => "Quimbaya", :aliases => ",Quimbaya", :latitude => "4.62306", :longitude => "-75.76278").save
City.new(:country_id => "50", :name => "Quibdo", :aliases => "Kibdo,Quibdo,QuibdÃ³,ÐÐ¸Ð±Ð´Ð¾,QuibdÃ³", :latitude => "5.69472", :longitude => "-76.66111").save
City.new(:country_id => "50", :name => "Puerto Tejada", :aliases => ",Puerto Tejada", :latitude => "3.23361", :longitude => "-76.41944").save
City.new(:country_id => "50", :name => "Puerto Santander", :aliases => "Puerto Santander,Santander,Puerto Santander", :latitude => "8.36361", :longitude => "-72.4075").save
City.new(:country_id => "50", :name => "Puerto Lopez", :aliases => ",Puerto LÃ³pez", :latitude => "4.08451", :longitude => "-72.95597").save
City.new(:country_id => "50", :name => "Puerto Colombia", :aliases => ",Puerto Colombia", :latitude => "10.98778", :longitude => "-74.95472").save
City.new(:country_id => "50", :name => "Puerto Boyaca", :aliases => ",Puerto BoyacÃ¡", :latitude => "5.97806", :longitude => "-74.58972").save
City.new(:country_id => "50", :name => "Puerto Berrio", :aliases => ",Puerto BerrÃ­o", :latitude => "6.49444", :longitude => "-74.40667").save
City.new(:country_id => "50", :name => "Puerto Asis", :aliases => "Puehrto-Asis,Puerto Asis,Puerto AsÃ­s,ÐÑÑÑÑÐ¾-ÐÑÐ¸Ñ,Puerto AsÃ­s", :latitude => "0.49911", :longitude => "-76.49968").save
City.new(:country_id => "50", :name => "Pradera", :aliases => ",Pradera", :latitude => "3.42111", :longitude => "-76.24472").save
City.new(:country_id => "50", :name => "Popayan", :aliases => ",PopayÃ¡n", :latitude => "2.43823", :longitude => "-76.61316").save
City.new(:country_id => "50", :name => "Planeta Rica", :aliases => "Planeta Rica,Planeta-Riki,ÐÐ»Ð°Ð½ÐµÑÐ°-Ð Ð¸ÐºÐ¸,Planeta Rica", :latitude => "8.41472", :longitude => "-75.58833").save
City.new(:country_id => "50", :name => "Pivijay", :aliases => "Pivijay,Pivijay", :latitude => "10.46667", :longitude => "-74.62056").save
City.new(:country_id => "50", :name => "Pitalito", :aliases => "Pitalito,Pitalito", :latitude => "1.84966", :longitude => "-76.04785").save
City.new(:country_id => "50", :name => "Piedecuesta", :aliases => ",Piedecuesta", :latitude => "6.98944", :longitude => "-73.05361").save
City.new(:country_id => "50", :name => "Pereira", :aliases => "Cartago Viejo,Pereira,Perejra,ÐÐµÑÐµÐ¹ÑÐ°,Pereira", :latitude => "4.81333", :longitude => "-75.69611").save
City.new(:country_id => "50", :name => "Patia", :aliases => ",PatÃ­a", :latitude => "2.06895", :longitude => "-77.05273").save
City.new(:country_id => "50", :name => "Pasto", :aliases => "Pastas,Pasto,San Juan de Pasto,ÐÐ°ÑÑÐ¾,Pasto", :latitude => "1.21361", :longitude => "-77.28111").save
City.new(:country_id => "50", :name => "Pamplona", :aliases => "Pamplona,ÐÐ°Ð¼Ð¿Ð»Ð¾Ð½Ð°,Pamplona", :latitude => "7.37806", :longitude => "-72.6525").save
City.new(:country_id => "50", :name => "Palmira", :aliases => ",Palmira", :latitude => "3.53944", :longitude => "-76.30361").save
City.new(:country_id => "50", :name => "Palmar de Varela", :aliases => "Palma de Varela,Palmar,Palmar de Varela,Palmer,Palmar de Varela", :latitude => "10.74667", :longitude => "-74.75556").save
City.new(:country_id => "50", :name => "Belalcazar", :aliases => "Belalcazar,Belalcazer,BelalcÃ¡zar,BelalcÃ¡zer,Paez,PÃ¡ez,Belalcazar", :latitude => "2.65472", :longitude => "-75.99278").save
City.new(:country_id => "50", :name => "Pacho", :aliases => "Pacho,Pacho", :latitude => "5.13278", :longitude => "-74.16194").save
City.new(:country_id => "50", :name => "Ocana", :aliases => "Ocana,OcaÃ±a,Okan'ja,ÐÐºÐ°Ð½ÑÑ,OcaÃ±a", :latitude => "8.23639", :longitude => "-73.35778").save
City.new(:country_id => "50", :name => "Neiva", :aliases => "Neiva,Nejva,ÐÐµÐ¹Ð²Ð°,Neiva", :latitude => "2.9273", :longitude => "-75.28188").save
City.new(:country_id => "50", :name => "Mosquera", :aliases => ",Mosquera", :latitude => "4.70778", :longitude => "-74.23278").save
City.new(:country_id => "50", :name => "Morales", :aliases => "Corregimiento Morales,Morales,Morales", :latitude => "8.31333", :longitude => "-73.87194").save
City.new(:country_id => "50", :name => "Monteria", :aliases => "Monteria,Monterija,MonterÃ­a,San Jeronimo de Buenavista,San JerÃ³nimo de Buenavista,ÐÐ¾Ð½ÑÐµÑÐ¸Ñ,MonterÃ­a", :latitude => "8.7575", :longitude => "-75.89").save
City.new(:country_id => "50", :name => "Montenegro", :aliases => ",Montenegro", :latitude => "4.56639", :longitude => "-75.75111").save
City.new(:country_id => "50", :name => "Montelibano", :aliases => ",MontelÃ­bano", :latitude => "7.98288", :longitude => "-75.42293").save
City.new(:country_id => "50", :name => "Mompos", :aliases => "Mompos,MompÃ³s,MompÃ³s", :latitude => "9.24194", :longitude => "-74.42667").save
City.new(:country_id => "50", :name => "Mocoa", :aliases => "Mocoa,Mocoa", :latitude => "1.152", :longitude => "-76.64967").save
City.new(:country_id => "50", :name => "Melgar", :aliases => "Mel'gar,Melgar,ÐÐµÐ»ÑÐ³Ð°Ñ,Melgar", :latitude => "4.20722", :longitude => "-74.64556").save
City.new(:country_id => "50", :name => "Medellin", :aliases => "Medelin,Medeljinas,Medellin,MedellÃ­n,mederin,ÐÐµÐ´ÐµÐ»Ð¸Ð½,ã¡ããªã³,MedellÃ­n", :latitude => "6.29139", :longitude => "-75.53611").save
City.new(:country_id => "50", :name => "Mariquita", :aliases => ",Mariquita", :latitude => "5.19889", :longitude => "-74.89295").save
City.new(:country_id => "50", :name => "Marinilla", :aliases => ",Marinilla", :latitude => "6.17667", :longitude => "-75.33917").save
City.new(:country_id => "50", :name => "Maria la Baja", :aliases => ",MarÃ­a la Baja", :latitude => "9.9832", :longitude => "-75.30155").save
City.new(:country_id => "50", :name => "Manzanares", :aliases => ",Manzanares", :latitude => "5.32472", :longitude => "-75.15694").save
City.new(:country_id => "50", :name => "Manizales", :aliases => "Manisales,Manisalesas,Manizales,ÐÐ°Ð½Ð¸ÑÐ°Ð»ÐµÑ,Manizales", :latitude => "5.07", :longitude => "-75.52056").save
City.new(:country_id => "50", :name => "Malambo", :aliases => ",Malambo", :latitude => "10.85889", :longitude => "-74.77306").save
City.new(:country_id => "50", :name => "Malaga", :aliases => ",MÃ¡laga", :latitude => "6.70222", :longitude => "-72.73611").save
City.new(:country_id => "50", :name => "Maicao", :aliases => ",Maicao", :latitude => "11.38417", :longitude => "-72.24417").save
City.new(:country_id => "50", :name => "Magangue", :aliases => "Magangue,MaganguÃ©,Manague,Mangue,MaganguÃ©", :latitude => "9.24139", :longitude => "-74.75333").save
City.new(:country_id => "50", :name => "Madrid", :aliases => "Madrid,Serrezuela,ÐÐ°Ð´ÑÐ¸Ð´,Madrid", :latitude => "4.73444", :longitude => "-74.26833").save
City.new(:country_id => "50", :name => "Los Patios", :aliases => "Los Patios,Los Patios", :latitude => "7.83833", :longitude => "-72.51333").save
City.new(:country_id => "50", :name => "Lorica", :aliases => ",Lorica", :latitude => "9.23167", :longitude => "-75.81972").save
City.new(:country_id => "50", :name => "Libano", :aliases => ",LÃ­bano", :latitude => "4.92639", :longitude => "-75.0675").save
City.new(:country_id => "50", :name => "Leticia", :aliases => "Leticia,Leticija,Letisija,LetÃ­cia,LÃ©ticia,ÐÐµÑÐ¸ÑÐ¸Ñ,Leticia", :latitude => "-4.21528", :longitude => "-69.94056").save
City.new(:country_id => "50", :name => "Lerida", :aliases => ",LÃ©rida", :latitude => "4.86242", :longitude => "-74.90977").save
City.new(:country_id => "50", :name => "La Virginia", :aliases => ",La Virginia", :latitude => "4.89972", :longitude => "-75.8825").save
City.new(:country_id => "50", :name => "La Union", :aliases => "La Unicion,La Union,La UniÃ³n,Lemos,La UniÃ³n", :latitude => "4.53583", :longitude => "-76.10667").save
City.new(:country_id => "50", :name => "La Union", :aliases => ",La UniÃ³n", :latitude => "1.60639", :longitude => "-77.13389").save
City.new(:country_id => "50", :name => "La Tebaida", :aliases => "La Tebaida,Tebaida,La Tebaida", :latitude => "4.45528", :longitude => "-75.79056").save
City.new(:country_id => "50", :name => "La Plata", :aliases => ",La Plata", :latitude => "2.39167", :longitude => "-75.89167").save
City.new(:country_id => "50", :name => "La Mesa", :aliases => ",La Mesa", :latitude => "5.26667", :longitude => "-73.91667").save
City.new(:country_id => "50", :name => "La Jagua de Ibirico", :aliases => "Jagua,La Jagua,La Jagua de Ibirico,La Jagua de Ibirico", :latitude => "9.56228", :longitude => "-73.33405").save
City.new(:country_id => "50", :name => "La Estrella", :aliases => "Estrella,La Estrella,La-Ehstrel'ja,ÐÐ°-Ð­ÑÑÑÐµÐ»ÑÑ,La Estrella", :latitude => "6.16056", :longitude => "-75.64694").save
City.new(:country_id => "50", :name => "La Dorada", :aliases => "Dorada,La Dorada,La-Dorada,ÐÐ°-ÐÐ¾ÑÐ°Ð´Ð°,La Dorada", :latitude => "5.44783", :longitude => "-74.66311").save
City.new(:country_id => "50", :name => "La Ceja", :aliases => ",La Ceja", :latitude => "6.03361", :longitude => "-75.43556").save
City.new(:country_id => "50", :name => "Jamundi", :aliases => "El Rosario,Jamundi,JamundÃ­,Khamundi,Ð¥Ð°Ð¼ÑÐ½Ð´Ð¸,JamundÃ­", :latitude => "3.26389", :longitude => "-76.54444").save
City.new(:country_id => "50", :name => "Itagui", :aliases => "Itagui,ItagÃ¼Ã­,ItagÃ¼Ã­", :latitude => "6.17194", :longitude => "-75.61139").save
City.new(:country_id => "50", :name => "Ipiales", :aliases => "Ipiales,Ipiales", :latitude => "0.83028", :longitude => "-77.64444").save
City.new(:country_id => "50", :name => "Ibague", :aliases => ",IbaguÃ©", :latitude => "4.43889", :longitude => "-75.23222").save
City.new(:country_id => "50", :name => "Honda", :aliases => ",Honda", :latitude => "5.20856", :longitude => "-74.73584").save
City.new(:country_id => "50", :name => "Guacari", :aliases => "Concordia,Guacari,GuacarÃ­,GuacarÃ­", :latitude => "3.76944", :longitude => "-76.33806").save
City.new(:country_id => "50", :name => "Granada", :aliases => "Boca de Monte,Granada,Grenada,ÐÑÐµÐ½Ð°Ð´Ð°,Granada", :latitude => "3.53861", :longitude => "-73.70056").save
City.new(:country_id => "50", :name => "Giron", :aliases => "Giron,GirÃ³n,Khiron,Ð¥Ð¸ÑÐ¾Ð½,GirÃ³n", :latitude => "7.07083", :longitude => "-73.17306").save
City.new(:country_id => "50", :name => "Girardot", :aliases => "Girardot,Zhirardo,ÐÐ¸ÑÐ°ÑÐ´Ð¾,Girardot", :latitude => "4.30306", :longitude => "-74.80083").save
City.new(:country_id => "50", :name => "Garzon", :aliases => ",GarzÃ³n", :latitude => "2.19917", :longitude => "-75.64972").save
City.new(:country_id => "50", :name => "Galapa", :aliases => ",Galapa", :latitude => "10.89686", :longitude => "-74.886").save
City.new(:country_id => "50", :name => "Fusagasuga", :aliases => ",Fusagasuga", :latitude => "4.34389", :longitude => "-74.36778").save
City.new(:country_id => "50", :name => "Funza", :aliases => "Funza,Funza", :latitude => "4.71667", :longitude => "-74.21667").save
City.new(:country_id => "50", :name => "Fundacion", :aliases => ",FundaciÃ³n", :latitude => "10.52139", :longitude => "-74.18667").save
City.new(:country_id => "50", :name => "Fresno", :aliases => "Fresno,Fresno", :latitude => "5.15556", :longitude => "-75.04028").save
City.new(:country_id => "50", :name => "Fonseca", :aliases => ",Fonseca", :latitude => "10.89222", :longitude => "-72.85389").save
City.new(:country_id => "50", :name => "Floridablanca", :aliases => "Florida,Floridablanca,Floridablanca", :latitude => "7.06472", :longitude => "-73.08972").save
City.new(:country_id => "50", :name => "Florida", :aliases => "Florida,La Florida,Perodias,PerodÃ­as,Ð¤Ð»Ð¾ÑÐ¸Ð´Ð°,Florida", :latitude => "3.3275", :longitude => "-76.23861").save
City.new(:country_id => "50", :name => "Florencia", :aliases => "Florencia,Florencia", :latitude => "1.61508", :longitude => "-75.61112").save
City.new(:country_id => "50", :name => "Flandes", :aliases => ",Flandes", :latitude => "4.29028", :longitude => "-74.81861").save
City.new(:country_id => "50", :name => "Facatativa", :aliases => "Facatativa,FacatativÃ¡,FacatativÃ¡", :latitude => "4.81667", :longitude => "-74.36667").save
City.new(:country_id => "50", :name => "Espinal", :aliases => "Ehspinal',El Espinal,Espinal,Ð­ÑÐ¿Ð¸Ð½Ð°Ð»Ñ,Espinal", :latitude => "4.14924", :longitude => "-74.88429").save
City.new(:country_id => "50", :name => "Envigado", :aliases => "Envigado,Envigado", :latitude => "6.17306", :longitude => "-75.56389").save
City.new(:country_id => "50", :name => "El Reten", :aliases => "Corregimiento El Reten,El Reten,El RetÃ©n,Reten,El RetÃ©n", :latitude => "10.61667", :longitude => "-74.26667").save
City.new(:country_id => "50", :name => "El Copey", :aliases => "Copei,Corregimiento El Copey,El Copey,El Copey", :latitude => "10.15031", :longitude => "-73.9614").save
City.new(:country_id => "50", :name => "El Charco", :aliases => "Charco,El Charco,El Charco", :latitude => "2.47611", :longitude => "-78.11694").save
City.new(:country_id => "50", :name => "El Cerrito", :aliases => "Cerrito,El Cerrito,El Cerrito", :latitude => "3.68806", :longitude => "-76.31667").save
City.new(:country_id => "50", :name => "El Carmen de Bolivar", :aliases => "Carmen,El Carmen,El Carmen de Bolivar,El Carmen de BolÃ­var,Karmen-de-Bolivar,ÐÐ°ÑÐ¼ÐµÐ½-Ð´Ðµ-ÐÐ¾Ð»Ð¸Ð²Ð°Ñ,El Carmen de BolÃ­var", :latitude => "9.7174", :longitude => "-75.12023").save
City.new(:country_id => "50", :name => "El Banco", :aliases => "Banco,Ehl'-Banka,El Banco,Ð­Ð»Ñ-ÐÐ°Ð½ÐºÐ°,El Banco", :latitude => "9.00114", :longitude => "-73.97581").save
City.new(:country_id => "50", :name => "El Bagre", :aliases => ",El Bagre", :latitude => "7.59417", :longitude => "-74.81194").save
City.new(:country_id => "50", :name => "Duitama", :aliases => "Duitama,Duitama", :latitude => "5.82694", :longitude => "-73.02028").save
City.new(:country_id => "50", :name => "Dos Quebradas", :aliases => ",Dos Quebradas", :latitude => "4.83472", :longitude => "-75.6725").save
City.new(:country_id => "50", :name => "Curumani", :aliases => "Corregimiento Curumani,Corregimiento CurumanÃ­,Curumani,CurumanÃ­,Kurumani,ÐÑÑÑÐ¼Ð°Ð½Ð¸,CurumanÃ­", :latitude => "9.19992", :longitude => "-73.54274").save
City.new(:country_id => "50", :name => "Cucuta", :aliases => "Cucuta,CÃºcuta,Kukuta,San Jose de Cucuta,San Jose de Guacimal,San JosÃ© de CÃ¹cuta,San JosÃ© de Guacimal,kukuta,ÐÑÐºÑÑÐ°,ã¯ã¯ã¿,CÃºcuta", :latitude => "7.88333", :longitude => "-72.50528").save
City.new(:country_id => "50", :name => "Corozal", :aliases => ",Corozal", :latitude => "9.31778", :longitude => "-75.29583").save
City.new(:country_id => "50", :name => "Corinto", :aliases => ",Corinto", :latitude => "3.17778", :longitude => "-76.26222").save
City.new(:country_id => "50", :name => "Copacabana", :aliases => "Copacabana,Kopakabana,ÐÐ¾Ð¿Ð°ÐºÐ°Ð±Ð°Ð½Ð°,Copacabana", :latitude => "6.34889", :longitude => "-75.51306").save
City.new(:country_id => "50", :name => "Circasia", :aliases => "Circacia,Circasia,Circasia", :latitude => "4.61889", :longitude => "-75.63583").save
City.new(:country_id => "50", :name => "Cienaga de Oro", :aliases => "Cienaga de Oro,CiÃ©naga de Oro,CiÃ©naga de Oro", :latitude => "8.87806", :longitude => "-75.62417").save
City.new(:country_id => "50", :name => "Cienaga", :aliases => "Cienaga,CiÃ©naga,San Juan de Cienaga,San Juan de CiÃ©naga,Sienaga,Ð¡Ð¸ÐµÐ½Ð°Ð³Ð°,CiÃ©naga", :latitude => "11.00944", :longitude => "-74.25417").save
City.new(:country_id => "50", :name => "Chiriguana", :aliases => "Chiriguana,ChiriguanÃ¡,ChiriguanÃ¡", :latitude => "9.36238", :longitude => "-73.60314").save
City.new(:country_id => "50", :name => "Chiquinquira", :aliases => ",ChiquinquirÃ¡", :latitude => "5.61889", :longitude => "-73.82").save
City.new(:country_id => "50", :name => "Chinu", :aliases => ",ChinÃº", :latitude => "9.10861", :longitude => "-75.39972").save
City.new(:country_id => "50", :name => "Chinchina", :aliases => "Chinchina,Chinchiny,ChinchinÃ¡,Ð§Ð¸Ð½ÑÐ¸Ð½Ñ,ChinchinÃ¡", :latitude => "4.9825", :longitude => "-75.60361").save
City.new(:country_id => "50", :name => "Chimichagua", :aliases => "Chimichagua,Chimicragua,Chimichagua", :latitude => "9.25778", :longitude => "-73.81228").save
City.new(:country_id => "50", :name => "Chigorodo", :aliases => "Chigorodo,ChigorodÃ³,ChigorodÃ³", :latitude => "7.66638", :longitude => "-76.68106").save
City.new(:country_id => "50", :name => "Chia", :aliases => ",ChÃ­a", :latitude => "4.86667", :longitude => "-74.06667").save
City.new(:country_id => "50", :name => "Chaparral", :aliases => ",Chaparral", :latitude => "3.72315", :longitude => "-75.48316").save
City.new(:country_id => "50", :name => "Cerete", :aliases => "Cerete,CeretÃ©,CeretÃ©", :latitude => "8.88556", :longitude => "-75.79667").save
City.new(:country_id => "50", :name => "Caucasia", :aliases => "Canafistola,Caucasia,CaÃ±afÃ­stola,Kavkaz,ÐÐ°Ð²ÐºÐ°Ð·,Caucasia", :latitude => "7.98694", :longitude => "-75.19722").save
City.new(:country_id => "50", :name => "Cartago", :aliases => ",Cartago", :latitude => "4.74639", :longitude => "-75.91167").save
City.new(:country_id => "50", :name => "Cartagena", :aliases => "Cartagena,Cartagena das Indias,Cartagena das Ãndias,Cartagena de Indias,Cartaxena de Indias - Cartagena de Indias,Carthagene,CarthagÃ¨ne,Kartachena,Kartageno,Kartakhena,ka ta he na,karutahena,ÐÐ°ÑÑÐ°ÑÐµÐ½Ð°,ã«ã«ã¿ãã,å¡å¡èµ«çº³,Cartagena", :latitude => "10.39972", :longitude => "-75.51444").save
City.new(:country_id => "50", :name => "Carmen de Viboral", :aliases => "Carmen Viboral,Carmen de Viboral,Carmen de Viboral", :latitude => "6.085", :longitude => "-75.33861").save
City.new(:country_id => "50", :name => "Candelaria", :aliases => ",Candelaria", :latitude => "3.41306", :longitude => "-76.35111").save
City.new(:country_id => "50", :name => "Campo de la Cruz", :aliases => "Campo de la Cruz,Kampo-de-la-Krus,Puerto Real de la Cruz,ÐÐ°Ð¼Ð¿Ð¾-Ð´Ðµ-Ð»Ð°-ÐÑÑÑ,Campo de la Cruz", :latitude => "10.37808", :longitude => "-74.88356").save
City.new(:country_id => "50", :name => "Campoalegre", :aliases => "Campoalegre,Kampoalegre,Sevilla,ÐÐ°Ð¼Ð¿Ð¾Ð°Ð»ÐµÐ³ÑÐµ,Campoalegre", :latitude => "2.68778", :longitude => "-75.32806").save
City.new(:country_id => "50", :name => "Cali", :aliases => "Cali,CÃ¡li,Kali,Kalis,Santiago de Cali,ka li,kari,ÐÐ°Ð»Ð¸,ã«ãª,å¡å©,Cali", :latitude => "3.43722", :longitude => "-76.5225").save
City.new(:country_id => "50", :name => "Caldas", :aliases => "Caldas,Kal'das,ÐÐ°Ð»ÑÐ´Ð°Ñ,Caldas", :latitude => "6.09", :longitude => "-75.6375").save
City.new(:country_id => "50", :name => "Calarca", :aliases => "Calarca,CalarcÃ¡,CalarcÃ¡", :latitude => "4.5325", :longitude => "-75.64361").save
City.new(:country_id => "50", :name => "Cajica", :aliases => "Cajica,CajicÃ¡,CajicÃ¡", :latitude => "4.91667", :longitude => "-74.03333").save
City.new(:country_id => "50", :name => "Caicedonia", :aliases => "Caicedonia,Caicedonia", :latitude => "4.3375", :longitude => "-75.83222").save
City.new(:country_id => "50", :name => "Buga", :aliases => "Buga,ÐÑÐ³Ð°,Buga", :latitude => "3.90222", :longitude => "-76.30278").save
City.new(:country_id => "50", :name => "Buenaventura", :aliases => "Buenaventura,ÐÑÐµÐ½Ð°Ð²ÐµÐ½ÑÑÑÐ°,Buenaventura", :latitude => "3.89333", :longitude => "-77.06972").save
City.new(:country_id => "50", :name => "Buenaventura", :aliases => ",Buenaventura", :latitude => "3.58333", :longitude => "-77").save
City.new(:country_id => "50", :name => "Bucaramanga", :aliases => "Bucaramanga,Bukaramanga,bukaramanga,ÐÑÐºÐ°ÑÐ°Ð¼Ð°Ð½Ð³Ð°,ãã«ã©ãã³ã¬,Bucaramanga", :latitude => "7.12972", :longitude => "-73.12583").save
City.new(:country_id => "50", :name => "Bogota", :aliases => "Bogota,Bogoto,BogotÃ ,BogotÃ¡,Boqota,BÃ³gÃ³ta,Gorad Bagata,Mponkota,Santa-Fe-de-Bogota,Santafe de Bogota,Santafe de BogotÃ¡,SantafÃ© de BogotÃ¡,Wukuta,beageatta,bo ge da,bogota,bokota,bwghwta,bwgwta,bwgwth,bwjwta,pokotta,ÎÏÎ¿Î³ÎºÎ¿ÏÎ¬,ÐÐ¾Ð³Ð¾ÑÐ°,ÐÐ¾ÒÐ¾ÑÐ°,ÐÐ¾ÑÐ°Ð´ ÐÐ°Ð³Ð°ÑÐ°,Ð¡Ð°Ð½ÑÐ°-Ð¤Ðµ-Ð´Ðµ-ÐÐ¾Ð³Ð¾ÑÐ°,Ô²Õ¸Õ£Õ¸Õ¿Õ¡,××××××,××××××,Ø¨ÙØ¬ÙØªØ§,Ø¨ÙØºÙØªØ§,Ø¨ÙÚ¯ÙØªØ§,Ø¨Ú¯ÙÙ¹Ø§,à¤¬à¥à¤à¥à¤à¤¾,à¤¬à¥à¤à¥à¤¤à¤¾,à¦¬à§à¦à§à¦¤à¦¾,à®ªà¯à®à¯à®à¯à®à®¾,à²¬à³à²à³à²,à´¬àµà´àµà´àµà´,à¹à¸à¹à¸à¸à¸²,à½à½¼à¼à½à½¼à¼à½,ááááá¢á,á¦áá³,áá¸áááá»ááá¼áá¼áá¶,ãã´ã¿,æ³¢å¥å¤§,ë³´ê³ í,BogotÃ¡", :latitude => "4.60971", :longitude => "-74.08175").save
City.new(:country_id => "50", :name => "Bello", :aliases => "Bella,Bello,ÐÐµÐ»Ð»Ð°,Bello", :latitude => "6.33889", :longitude => "-75.56222").save
City.new(:country_id => "50", :name => "Belen de Umbria", :aliases => "Belen,Belen de Umbria,BelÃ©n,BelÃ©n de UmbrÃ­a,Mocatan,MocatÃ¡n,BelÃ©n de UmbrÃ­a", :latitude => "5.20361", :longitude => "-75.87056").save
City.new(:country_id => "50", :name => "Barranquilla", :aliases => "Barankila,Barankilija,Barankilja,Barrancas de San Nicolas,Barrancas de San NicolÃ¡s,Barrankil'ja,Barranquilla,Gorad Barankil'ja,ba lan ji ya,balangkiya,barankiya,barankwyla,brnqyyh,ÐÐ°ÑÐ°Ð½ÐºÐ¸Ð»Ñ,ÐÐ°ÑÐ°Ð½ÐºÐ¸ÑÐ°,ÐÐ°ÑÑÐ°Ð½ÐºÐ¸Ð»ÑÑ,ÐÐ°ÑÑÐ°Ð½ÐºÑÐ»ÑÑ,ÐÐ¾ÑÐ°Ð´ ÐÐ°ÑÐ°Ð½ÐºÑÐ»ÑÑ,××¨× ×§×××,Ø¨Ø§Ø±Ø§ÙÙÙÙÙØ§,ãã©ã³ã­ã¤,å·´å°åºäº,ë°ëí¤ì¼,Barranquilla", :latitude => "10.96389", :longitude => "-74.79639").save
City.new(:country_id => "50", :name => "Barrancas", :aliases => ",Barrancas", :latitude => "10.95889", :longitude => "-72.79083").save
City.new(:country_id => "50", :name => "Barrancabermeja", :aliases => "Barrancabermeja,Barrankabermekha,ÐÐ°ÑÑÐ°Ð½ÐºÐ°Ð±ÐµÑÐ¼ÐµÑÐ°,Barrancabermeja", :latitude => "7.06528", :longitude => "-73.85472").save
City.new(:country_id => "50", :name => "Barbosa", :aliases => "Barbosa,Barboza,ÐÐ°ÑÐ±Ð¾Ð·Ð°,Barbosa", :latitude => "6.43861", :longitude => "-75.33306").save
City.new(:country_id => "50", :name => "Barbosa", :aliases => "Barbosa,Barboza,ÐÐ°ÑÐ±Ð¾Ð·Ð°,Barbosa", :latitude => "5.9325", :longitude => "-73.62111").save
City.new(:country_id => "50", :name => "Baranoa", :aliases => ",Baranoa", :latitude => "10.79408", :longitude => "-74.9164").save
City.new(:country_id => "50", :name => "Ayapel", :aliases => "Ayapel,Ayapel", :latitude => "8.31583", :longitude => "-75.14556").save
City.new(:country_id => "50", :name => "Armenia", :aliases => "Armenia,Armenia", :latitude => "4.53389", :longitude => "-75.68111").save
City.new(:country_id => "50", :name => "Arjona", :aliases => ",Arjona", :latitude => "10.25444", :longitude => "-75.34389").save
City.new(:country_id => "50", :name => "Ariguani", :aliases => ",AriguanÃ­", :latitude => "10.25", :longitude => "-74").save
City.new(:country_id => "50", :name => "Arauca", :aliases => "Arauca,Arauka,ÐÑÐ°ÑÐºÐ°,Arauca", :latitude => "7.08471", :longitude => "-70.75908").save
City.new(:country_id => "50", :name => "Aracataca", :aliases => "Aracataca,Aracataca", :latitude => "10.59278", :longitude => "-74.19056").save
City.new(:country_id => "50", :name => "Apartado", :aliases => ",ApartadÃ³", :latitude => "7.88299", :longitude => "-76.62587").save
City.new(:country_id => "50", :name => "Anserma", :aliases => "Anserma,Anserma", :latitude => "5.33278", :longitude => "-75.79111").save
City.new(:country_id => "50", :name => "Los Andes", :aliases => "Andes,Los Andes,Los Andes", :latitude => "5.6561", :longitude => "-75.87877").save
City.new(:country_id => "50", :name => "Andalucia", :aliases => ",AndalucÃ­a", :latitude => "4.17417", :longitude => "-76.17028").save
City.new(:country_id => "50", :name => "Aguazul", :aliases => "Agua Azul,Aguazul,Aguazul", :latitude => "5.17306", :longitude => "-72.55472").save
City.new(:country_id => "50", :name => "Aguadas", :aliases => "Aguadas,Aguadas", :latitude => "5.61472", :longitude => "-75.45972").save
City.new(:country_id => "50", :name => "Aguachica", :aliases => "Aguachica,Aguachika,Aquachia,AquachÃ­a,ÐÐ³ÑÐ°ÑÐ¸ÐºÐ°,Aguachica", :latitude => "8.3125", :longitude => "-73.62694").save
City.new(:country_id => "50", :name => "Acacias", :aliases => "Acacias,AcacÃ­as,AcacÃ­as", :latitude => "3.98695", :longitude => "-73.75797").save
City.new(:country_id => "50", :name => "Morales", :aliases => ",Morales", :latitude => "2.75362", :longitude => "-76.6271").save
City.new(:country_id => "50", :name => "Carepa", :aliases => "Carepa,Carepa", :latitude => "7.75849", :longitude => "-76.65254").save
City.new(:country_id => "50", :name => "Ciudad Bolivar", :aliases => "Ciudad Bolivar,Ciudad BolÃ­var,Ciudad BolÃ­var", :latitude => "5.85389", :longitude => "-76.02528").save
City.new(:country_id => "50", :name => "Agustin Codazzi", :aliases => ",AgustÃ­n Codazzi", :latitude => "10.03409", :longitude => "-73.23611").save
City.new(:country_id => "50", :name => "Plato", :aliases => ",Plato", :latitude => "9.79029", :longitude => "-74.78244").save
City.new(:country_id => "50", :name => "San Jose del Guaviare", :aliases => "San Jose del Guaviare,San JosÃ© del Guaviare,San JosÃ© del Guaviare", :latitude => "2.56833", :longitude => "-72.64167").save
