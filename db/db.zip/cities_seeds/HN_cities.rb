City.new(:country_id => "99", :name => "Puerto Cortez", :aliases => "Port Cortez,Puehrto-Kortes,Puerto Caballo,Puerto Cortez,ÐÑÑÑÑÐ¾-ÐÐ¾ÑÑÐµÑ,Puerto Cortez", :latitude => "15.83333", :longitude => "-87.95").save
City.new(:country_id => "99", :name => "Yoro", :aliases => ",Yoro", :latitude => "15.13333", :longitude => "-87.13333").save
City.new(:country_id => "99", :name => "Villanueva", :aliases => ",Villanueva", :latitude => "15.31667", :longitude => "-88").save
City.new(:country_id => "99", :name => "Tocoa", :aliases => "Tocoa,Tokoa,Ð¢Ð¾ÐºÐ¾Ð°,Tocoa", :latitude => "15.68333", :longitude => "-86").save
City.new(:country_id => "99", :name => "Tela", :aliases => "Tela,Tela", :latitude => "15.78333", :longitude => "-87.45").save
City.new(:country_id => "99", :name => "Tegucigalpa", :aliases => "Tegucigalpa,Tegucigalpo,Tegucigucigalpa,Tegusigal'pa,Tegusigalpa,Teguzigalpa,Tenkousinkalpa,de gu si jia ba,tegushigarupa,tegusigalpa,tekusikalpa,tgwsygalpa,tgwsyglph,Î¤ÎµÎ³ÎºÎ¿ÏÏÎ¹Î³ÎºÎ¬Î»ÏÎ±,Ð¢ÐµÐ³ÑÑÐ¸Ð³Ð°Ð»Ð¿Ð°,Ð¢ÐµÐ³ÑÑÐ¸Ð³Ð°Ð»ÑÐ¿Ð°,Ð¢ÐµÐ³ÑÑÑÐ³Ð°Ð»ÑÐ¿Ð°,××××¡××××¤×,ØªÚ¯ÙØ³ÛÚ¯Ø§ÙÙ¾Ø§,à¹à¸à¸à¸¹à¸à¸´à¸à¸±à¸¥à¸à¸²,á´áá²ááá,ãã°ã·ã¬ã«ã,å¾·å¤æ¯å å·´,íêµ¬ìê°í,Tegucigalpa", :latitude => "14.0818", :longitude => "-87.20681").save
City.new(:country_id => "99", :name => "Siguatepeque", :aliases => ",Siguatepeque", :latitude => "14.6", :longitude => "-87.83333").save
City.new(:country_id => "99", :name => "Santa Rosa de Copan", :aliases => "Santa Rosa,Santa Rosa Copan,Santa Rosa CopÃ¡n,Santa Rosa de Copan,Santa Rosa de CopÃ¡n,Santa-Rosa-de-Kopan,Ð¡Ð°Ð½ÑÐ°-Ð Ð¾ÑÐ°-Ð´Ðµ-ÐÐ¾Ð¿Ð°Ð½,Santa Rosa de CopÃ¡n", :latitude => "14.76667", :longitude => "-88.78333").save
City.new(:country_id => "99", :name => "Santa Barbara", :aliases => ",Santa BÃ¡rbara", :latitude => "14.91667", :longitude => "-88.23333").save
City.new(:country_id => "99", :name => "San Pedro Sula", :aliases => "San Pedro,San Pedro Sula,San Pedro Sula", :latitude => "15.5", :longitude => "-88.03333").save
City.new(:country_id => "99", :name => "San Lorenzo", :aliases => ",San Lorenzo", :latitude => "13.42417", :longitude => "-87.44722").save
City.new(:country_id => "99", :name => "Potrerillos", :aliases => "Porterillas,Potrerillos,Potrerillos", :latitude => "15.23333", :longitude => "-87.96667").save
City.new(:country_id => "99", :name => "Olanchito", :aliases => "Olanchita,Olanchito,ÐÐ»Ð°Ð½ÑÐ¸ÑÐ¾,Olanchito", :latitude => "15.5", :longitude => "-86.56667").save
City.new(:country_id => "99", :name => "La Paz", :aliases => ",La Paz", :latitude => "14.31667", :longitude => "-87.68333").save
City.new(:country_id => "99", :name => "La Lima", :aliases => "La Lima,La-Lima,Lima Vieja,ÐÐ°-ÐÐ¸Ð¼Ð°,La Lima", :latitude => "15.43333", :longitude => "-87.91667").save
City.new(:country_id => "99", :name => "La Ceiba", :aliases => "Ceiba,La Ceiba,La-Sejba,ÐÐ°-Ð¡ÐµÐ¹Ð±Ð°,La Ceiba", :latitude => "15.78333", :longitude => "-86.8").save
City.new(:country_id => "99", :name => "Juticalpa", :aliases => ",Juticalpa", :latitude => "14.65", :longitude => "-86.2").save
City.new(:country_id => "99", :name => "El Progreso", :aliases => "Ehl'-Progreso,El Progreso,El Progress,Progreso,Ð­Ð»Ñ-ÐÑÐ¾Ð³ÑÐµÑÐ¾,El Progreso", :latitude => "15.4", :longitude => "-87.8").save
City.new(:country_id => "99", :name => "El Paraiso", :aliases => ",El ParaÃ­so", :latitude => "13.86667", :longitude => "-86.55").save
City.new(:country_id => "99", :name => "Danli", :aliases => ",DanlÃ­", :latitude => "14.03333", :longitude => "-86.58333").save
City.new(:country_id => "99", :name => "Comayagua", :aliases => "Comayagua,Comayagua", :latitude => "14.45", :longitude => "-87.63333").save
City.new(:country_id => "99", :name => "Cofradia", :aliases => ",CofradÃ­a", :latitude => "15.4", :longitude => "-88.15").save
City.new(:country_id => "99", :name => "Ciudad Choluteca", :aliases => "Chollolteca,Choluteca,Ciudad Choluteca,Ciudad Choluteca", :latitude => "13.30028", :longitude => "-87.19083").save
City.new(:country_id => "99", :name => "Choloma", :aliases => ",Choloma", :latitude => "15.61444", :longitude => "-87.95302").save
