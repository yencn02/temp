City.new(:country_id => "225", :name => "Zara", :aliases => "Kocgiri,KoÃ§giri,Zara,Zara", :latitude => "39.89778", :longitude => "37.75833").save
City.new(:country_id => "225", :name => "Yuksekova", :aliases => "Dize,Yuksekova,Yusekova,YÃ¼ksekova,YÃ¼sekova,YÃ¼ksekova", :latitude => "37.57362", :longitude => "44.28716").save
City.new(:country_id => "225", :name => "Yozgat", :aliases => "Saralus,Yozgad,Yozgat,Yuzgat,Yozgat", :latitude => "39.82", :longitude => "34.80444").save
City.new(:country_id => "225", :name => "Yesilli", :aliases => "Rismil,RiÅmil,Yesilli,YeÅilli,YeÅilli", :latitude => "37.3405", :longitude => "40.82558").save
City.new(:country_id => "225", :name => "Erzin", :aliases => "Ehrzin,Erzin,Yesilkent,YeÅilkent,Ð­ÑÐ·Ð¸Ð½,Erzin", :latitude => "36.95589", :longitude => "36.2").save
City.new(:country_id => "225", :name => "Yerkoy", :aliases => ",YerkÃ¶y", :latitude => "39.63806", :longitude => "34.46722").save
City.new(:country_id => "225", :name => "Didim", :aliases => "Didim,Didimy,Yenihisar,Yoran,ÐÐ¸Ð´Ð¸Ð¼Ñ,Didim", :latitude => "37.37556", :longitude => "27.26778").save
City.new(:country_id => "225", :name => "Yatagan", :aliases => "Ahikoy,AhikÃ¶y,Yatagan,YataÄan,YataÄan", :latitude => "37.34026", :longitude => "28.14279").save
City.new(:country_id => "225", :name => "Yalvac", :aliases => "Jalvach,Yalvac,YalvaÃ§,Ð¯Ð»Ð²Ð°Ñ,YalvaÃ§", :latitude => "38.29556", :longitude => "31.17778").save
City.new(:country_id => "225", :name => "Yahyali", :aliases => "Gazibenli,Jakh'jaly,Yahyali,YahyalÄ±,Ð¯ÑÑÑÐ»Ñ,YahyalÄ±", :latitude => "38.10228", :longitude => "35.35704").save
City.new(:country_id => "225", :name => "Viransehir", :aliases => "Antoninopolis,Veeranshahr,Viransehir,Viranshekhire,ViranÅehir,Wiranschehir,ÐÐ¸ÑÐ°Ð½ÑÐµÑÐ¸ÑÐµ,ViranÅehir", :latitude => "37.23528", :longitude => "39.76306").save
City.new(:country_id => "225", :name => "Varto", :aliases => "Gumgum,GÃ¼mgÃ¼m,Varto,Varto", :latitude => "39.17321", :longitude => "41.45593").save
City.new(:country_id => "225", :name => "Van", :aliases => "Thospia,Urartu,Van,Wan,ÐÐ°Ð½,Van", :latitude => "38.49239", :longitude => "43.38311").save
City.new(:country_id => "225", :name => "Cimin", :aliases => "Cimin,Uzumlu,ÃzÃ¼mlÃ¼,Cimin", :latitude => "39.71011", :longitude => "39.70213").save
City.new(:country_id => "225", :name => "Usak", :aliases => "Flaviopolis,Ouchak,Temenothyrae,Usak,Uschak,Ushak,Ushaq,UÅak,Ð£ÑÐ°Ðº,UÅak", :latitude => "38.67351", :longitude => "29.4058").save
City.new(:country_id => "225", :name => "Urla", :aliases => "Urla,Vourlah Skala,Ð£ÑÐ»Ð°,Urla", :latitude => "38.32292", :longitude => "26.76403").save
City.new(:country_id => "225", :name => "Urgub", :aliases => "Urgub,Urgup,ÃrgÃ¼p,Urgub", :latitude => "38.6296", :longitude => "34.91198").save
City.new(:country_id => "225", :name => "Sanliurfa", :aliases => "Antiocheia,Edesa,Edessa,Ehdessa,Orfa,Ourfa,Sanliurfa,Urfa,Urfeh,ÅanlÄ±urfa,ÎÎ½ÏÎ¹ÏÏÎµÎ¹Î±,Ð­Ð´ÐµÑÑÐ°,ÅanlÄ±urfa", :latitude => "37.16708", :longitude => "38.79392").save
City.new(:country_id => "225", :name => "Turgutlu", :aliases => "Caesarea Trocetta,Cassaba,Kasaba,Turgutlu,Turgutlu", :latitude => "38.49533", :longitude => "27.6997").save
City.new(:country_id => "225", :name => "Tunceli", :aliases => "Kalan,Mameki,Mamiki,Tunceli,Tundzheli,Ð¢ÑÐ½Ð´Ð¶ÐµÐ»Ð¸,Tunceli", :latitude => "39.10829", :longitude => "39.54711").save
City.new(:country_id => "225", :name => "Torbali", :aliases => "Tepekoey,TepekÃ¶y,Torbali,Torbaly,TorbalÄ±,Ð¢Ð¾ÑÐ±Ð°Ð»Ñ,TorbalÄ±", :latitude => "38.1519", :longitude => "27.36223").save
City.new(:country_id => "225", :name => "Tire", :aliases => "Arcadiopolis,Teira,TeÄ±ra,Theda,Thireh,Tira,Tire,tyrh,ØªÛØ±Ù,Tire", :latitude => "38.08877", :longitude => "27.73508").save
City.new(:country_id => "225", :name => "Tekirova", :aliases => "Celcikli,Celtikli,Phaselis,Tekirova,Tekrova,TekrÃ³va,Ãeltikli,Ð¢ÐµÐºÐ¸ÑÐ¾Ð²Ð°,Tekirova", :latitude => "36.5017", :longitude => "30.52723").save
City.new(:country_id => "225", :name => "Tavsanli", :aliases => "Taushanli,Tavsanli,TavÅanlÄ±,TavÅanlÄ±", :latitude => "39.54237", :longitude => "29.49866").save
City.new(:country_id => "225", :name => "Tatvan", :aliases => "Tatvan,Ð¢Ð°ÑÐ²Ð°Ð½,Tatvan", :latitude => "38.50667", :longitude => "42.28167").save
City.new(:country_id => "225", :name => "Tarsus", :aliases => "Antiochia ad Cydnum,Tars,Tarse,Tarso,Tarsos,Tarsous,Tarsus,da shu,taleusoseu,tarususu,Î¤Î±ÏÏÏÏ,Ð¢Ð°ÑÑ,ã¿ã«ã¹ã¹,å¤§æ¸,íë¥´ìì¤,Tarsus", :latitude => "36.91876", :longitude => "34.8784").save
City.new(:country_id => "225", :name => "Talas", :aliases => "Tafas,Talas,Ð¢Ð°Ð»Ð°Ñ,Talas", :latitude => "38.6908", :longitude => "35.5538").save
City.new(:country_id => "225", :name => "Susurluk", :aliases => "Firt,FÄ±rt,Susigirlik,Susughirli,Susugurlu,Susurluk,SusÄ±ÄÄ±rlÄ±k,Susurluk", :latitude => "39.91361", :longitude => "28.15778").save
City.new(:country_id => "225", :name => "Suruc", :aliases => "Suruc,Suruch,SuruÃ§,Syuryuch,Ð¡ÑÑÑÑ,SuruÃ§", :latitude => "36.97614", :longitude => "38.42495").save
City.new(:country_id => "225", :name => "Sorgun", :aliases => "Buyukkohne,BÃ¼yÃ¼kkÃ¶hne,Kohne,KÃ¶hne,Sorgun,Sorgune,Yesilova,YeÅilova,Ð¡Ð¾ÑÐ³ÑÐ½Ðµ,Sorgun", :latitude => "39.81012", :longitude => "35.18596").save
City.new(:country_id => "225", :name => "Soma", :aliases => "Germe,Soma,Somy,Ð¡Ð¾Ð¼Ñ,Soma", :latitude => "39.18554", :longitude => "27.60945").save
City.new(:country_id => "225", :name => "Solhan", :aliases => "Boglan,BoÄlan,Buglan,Solhan,Solhan", :latitude => "38.96338", :longitude => "41.02931").save
City.new(:country_id => "225", :name => "Sokia", :aliases => "Sok,Soke,Sokia,SÃ¶ke,Ð¡Ð¾Ðº,Sokia", :latitude => "37.7482", :longitude => "27.40614").save
City.new(:country_id => "225", :name => "Siverek", :aliases => "Severek,Siverek,Sivereke,Suverek,Ð¡Ð¸Ð²ÐµÑÐµÐºÐµ,Siverek", :latitude => "37.75502", :longitude => "39.31667").save
City.new(:country_id => "225", :name => "Sivas", :aliases => "Megalopolis,Sebastia,Sevas,Sivas,Siwas,su~ivu~asu,Ð¡Ð¸Ð²Ð°Ñ,ã¹ã£ã´ã¡ã¹,Sivas", :latitude => "39.74833", :longitude => "37.01611").save
City.new(:country_id => "225", :name => "Sirnak", :aliases => "Shirnak,Sirnak,ÅÄ±rnak,Ð¨Ð¸ÑÐ½Ð°Ðº,ÅÄ±rnak", :latitude => "37.52278", :longitude => "42.45944").save
City.new(:country_id => "225", :name => "Simav", :aliases => "Simav,Synaus,Simav", :latitude => "39.0882", :longitude => "28.97767").save
City.new(:country_id => "225", :name => "Silvan", :aliases => "Miyafarkin,Sil'van,Silvan,Ð¡Ð¸Ð»ÑÐ²Ð°Ð½,Silvan", :latitude => "38.14194", :longitude => "41.00806").save
City.new(:country_id => "225", :name => "Silopi", :aliases => "Girgimac,GirgimaÃ§,Girikamo,Girikoma,Sil'opi,Silopi,Ð¡Ð¸Ð»Ð¾Ð¿Ð¸,Silopi", :latitude => "37.24972", :longitude => "42.46944").save
City.new(:country_id => "225", :name => "Silifke", :aliases => "Selefke,Selefkeh,Seleucia,Silifke,Ð¡Ð¸Ð»Ð¸ÑÐºÐµ,Silifke", :latitude => "36.37778", :longitude => "33.93444").save
City.new(:country_id => "225", :name => "Siirt", :aliases => "Sairt,Siirt,Sirt,SÃ®rt,Ð¡Ð¸Ð¸ÑÑ,Ø³Ø¹Ø±Ø¯,Siirt", :latitude => "37.93262", :longitude => "41.94025").save
City.new(:country_id => "225", :name => "Seydisehir", :aliases => "Seydisehir,SeydiÅehir,SeydiÅehir", :latitude => "37.42202", :longitude => "31.84539").save
City.new(:country_id => "225", :name => "Serik", :aliases => "Kokes,Koles,Kukes,KÃ¼kes,Serik,Ð¡ÐµÑÐ¸Ðº,Serik", :latitude => "36.91694", :longitude => "31.09889").save
City.new(:country_id => "225", :name => "Sereflikochisar", :aliases => "Kochisar,KoÃ§hisar,Serefli,Sereflikochisar,Åerefli,ÅereflikoÃ§hisar,ÅereflikoÃ§hisar", :latitude => "38.93925", :longitude => "33.5386").save
City.new(:country_id => "225", :name => "Senirkent", :aliases => "Senikent,Senirkent,Senirkent", :latitude => "38.10444", :longitude => "30.54861").save
City.new(:country_id => "225", :name => "Semdinli", :aliases => "Navsar,NavÅar,Semdinli,Semdinni,Åemdinli,Åemdinni,Åemdinli", :latitude => "37.30514", :longitude => "44.5742").save
City.new(:country_id => "225", :name => "Selcuk", :aliases => "Ayasoluk,Ephesus,Sel'chuk,Selcuk,SelÃ§uk,Ð¡ÐµÐ»ÑÑÑÐº,SelÃ§uk", :latitude => "37.95137", :longitude => "27.36849").save
City.new(:country_id => "225", :name => "Seferihisar", :aliases => "Seferihisar,Seferihisar", :latitude => "38.19686", :longitude => "26.83902").save
City.new(:country_id => "225", :name => "Sarkisla", :aliases => "Sarkisla,Tonus,ÅarkÄ±Åla,ÅarkÄ±Åla", :latitude => "39.35186", :longitude => "36.40976").save
City.new(:country_id => "225", :name => "Sarkikaraagac", :aliases => "Dogukaraagac,DoÄukaraaÄaÃ§,Karaagac,KaraaÄaÃ§,Sarkikaraagac,ÅarkÃ®karaaÄaÃ§,ÅarkÃ®karaaÄaÃ§", :latitude => "38.07944", :longitude => "31.36639").save
City.new(:country_id => "225", :name => "Saraykoy", :aliases => "Saraykoy,SaraykÃ¶y,Seraikeui,SaraykÃ¶y", :latitude => "37.92448", :longitude => "28.92516").save
City.new(:country_id => "225", :name => "Sandikli", :aliases => "Sandikli,Sandykly,SandÄ±klÄ±,Ð¡Ð°Ð½Ð´Ð¸ÐºÐ»Ð¸,SandÄ±klÄ±", :latitude => "38.46472", :longitude => "30.26946").save
City.new(:country_id => "225", :name => "Salihli", :aliases => ",Salihli", :latitude => "38.48258", :longitude => "28.14774").save
City.new(:country_id => "225", :name => "Reyhanli", :aliases => "Airandji,Airanndji,Airinge,Ayranci,AÃ¯randji,Rehaniye,Rejkhanly,Reyhaniye,Reyhanli,ReyhanlÄ±,`Ayranj,Ð ÐµÐ¹ÑÐ°Ð½Ð»Ñ,âAyranj,ReyhanlÄ±", :latitude => "36.26917", :longitude => "36.56722").save
City.new(:country_id => "225", :name => "Polatli", :aliases => "Polath,Polatli,PolatlÄ±,PolatlÄ±", :latitude => "39.57716", :longitude => "32.14132").save
City.new(:country_id => "225", :name => "Pazarcik", :aliases => "Pazarcik,PazarcÄ±k,Pazardzhik,ÐÐ°Ð·Ð°ÑÐ´Ð¶Ð¸Ðº,PazarcÄ±k", :latitude => "37.48685", :longitude => "37.29961").save
City.new(:country_id => "225", :name => "Patnos", :aliases => "Patnos,Patnos", :latitude => "39.23361", :longitude => "42.86344").save
City.new(:country_id => "225", :name => "Pasinler", :aliases => "Hasankale,Pasinler,Pasinler", :latitude => "39.98031", :longitude => "41.67635").save
City.new(:country_id => "225", :name => "Osmaniye", :aliases => "Cebelibereket,Gebelibereket,Osmanie,Osmaniye,ÐÑÐ¼Ð°Ð½Ð¸Ðµ,Osmaniye", :latitude => "37.07417", :longitude => "36.24778").save
City.new(:country_id => "225", :name => "Ortakoy", :aliases => ",OrtakÃ¶y", :latitude => "38.73611", :longitude => "34.04028").save
City.new(:country_id => "225", :name => "Ortaca", :aliases => ",Ortaca", :latitude => "36.82944", :longitude => "28.77083").save
City.new(:country_id => "225", :name => "Hypaepa", :aliases => "Eudemish,Hypaepa,Odemis,ÃdemiÅ,Hypaepa", :latitude => "38.2278", :longitude => "27.96955").save
City.new(:country_id => "225", :name => "Nusaybin", :aliases => "Antiocheia,Nasabina,Nisibin,Nisibis,Nissibine,Nusaybin,Nuseybin,Nuzajbin,ÎÎ½ÏÎ¹ÏÏÎµÎ¹Î±,ÐÑÐ·Ð°Ð¹Ð±Ð¸Ð½,Nusaybin", :latitude => "37.0778", :longitude => "41.2178").save
City.new(:country_id => "225", :name => "Nizip", :aliases => "Nezip,Nizip,Nizipe,ÐÐ¸Ð·Ð¸Ð¿Ðµ,Nizip", :latitude => "37.00972", :longitude => "37.79417").save
City.new(:country_id => "225", :name => "Nigde", :aliases => "Nigdah,Nigde,Nigdeh,NiÄde,ÐÐ¸Ð³Ð´Ðµ,NiÄde", :latitude => "37.96583", :longitude => "34.67935").save
City.new(:country_id => "225", :name => "Nevsehir", :aliases => "Muskara,MuÅkara,Nevsehir,Nevshehr,Nevshekhir,NevÅehir,ÐÐµÐ²ÑÐµÑÐ¸Ñ,NevÅehir", :latitude => "38.625", :longitude => "34.71222").save
City.new(:country_id => "225", :name => "Nazilli", :aliases => "Nasly,Nazilli,Pazarkoy,PazarkÃ¶y,Nazilli", :latitude => "37.91631", :longitude => "28.32225").save
City.new(:country_id => "225", :name => "Mut", :aliases => ",Mut", :latitude => "36.64639", :longitude => "33.4375").save
City.new(:country_id => "225", :name => "Mus", :aliases => "Mus,Mush,MuÅ,ÐÑÑ,MuÅ", :latitude => "38.74525", :longitude => "41.50693").save
City.new(:country_id => "225", :name => "Mugla", :aliases => "Mentese,Menteshe,Mobolla,Mughla,Mughlah,Mugla,MuÄla,ÐÑÐ³Ð»Ð°,MuÄla", :latitude => "37.21807", :longitude => "28.3665").save
City.new(:country_id => "225", :name => "Mucur", :aliases => "Mucur,Mucur", :latitude => "39.06147", :longitude => "34.38286").save
City.new(:country_id => "225", :name => "Milas", :aliases => "Milas,Mylasa,ÐÐ¸Ð»Ð°Ñ,Milas", :latitude => "37.31639", :longitude => "27.78389").save
City.new(:country_id => "225", :name => "Midyat", :aliases => "Estil,Medeat,Mid'jat,Midyad,Midyat,Mityat,ÐÐ¸Ð´ÑÑÑ,Midyat", :latitude => "37.4247", :longitude => "41.33934").save
City.new(:country_id => "225", :name => "Mercin", :aliases => "Icel,Mersin,Mersina,Mersine,Merson,Mersyna,MersÃ®n,Zephyrium,Ä°Ã§el,ÎÎµÏÏÎ¯Î½Î·,ÐÐµÑÑÐ¸Ð½,Mercin", :latitude => "36.79526", :longitude => "34.61792").save
City.new(:country_id => "225", :name => "Menemen", :aliases => "Menemen,Temnos,ÐÐµÐ½ÐµÐ¼ÐµÐ½,Menemen", :latitude => "38.60754", :longitude => "27.06938").save
City.new(:country_id => "225", :name => "Marmaris", :aliases => "Mararis,Marmarice,Marmaris,Physcus,marmaris,marmarys,ÐÐ°ÑÐ¼Ð°ÑÐ¸Ñ,××¨×××¨××¡,ÙØ§Ø±ÙØ§Ø±ÙØ³,Marmaris", :latitude => "36.855", :longitude => "28.27417").save
City.new(:country_id => "225", :name => "Mardin", :aliases => "Marde,Mardin,Merdin,MÃªrdin,MÃªrdÃ®n,marudin,ÐÐ°ÑÐ´Ð¸Ð½,ãã«ãã£ã³,Mardin", :latitude => "37.31309", :longitude => "40.74357").save
City.new(:country_id => "225", :name => "Manisa", :aliases => "Magnesia,Magnesia ad Sipylum,Magnesia am Sipylos,Magnisiyah,MagnÄsÄ±a,Mahnisa,Manisa,Manissa,Sarouhan,Saruhan,ÐÐ°Ð½Ð¸ÑÐ°,Manisa", :latitude => "38.61202", :longitude => "27.42646").save
City.new(:country_id => "225", :name => "Manavgat", :aliases => "Manavgat,ÐÐ°Ð½Ð°Ð²Ð³Ð°Ñ,Manavgat", :latitude => "36.78667", :longitude => "31.44306").save
City.new(:country_id => "225", :name => "Malazgirt", :aliases => "Kale,Malazgirt,Malazkirt,MalÃ¢zkirt,Malazgirt", :latitude => "39.14265", :longitude => "42.54008").save
City.new(:country_id => "225", :name => "Malatya", :aliases => "Malat'ja,Malatia,Malatiyah,Malatya,Meleti,MeletÃ®,Melitene,ÐÐ°Ð»Ð°ÑÑÑ,Malatya", :latitude => "38.35018", :longitude => "38.31667").save
City.new(:country_id => "225", :name => "Lice", :aliases => "Lice,Lijje,Lice", :latitude => "38.45917", :longitude => "40.6475").save
City.new(:country_id => "225", :name => "Kutahya", :aliases => "Cotiaeum,Cotyaeum,Kjutakh'ja,Kuetahya,Kutahiyah,Kutahya,Kutaia,Kutaya,KÃ¼tahya,ÐÑÑÐ°ÑÑÑ,KÃ¼tahya", :latitude => "39.42417", :longitude => "29.98333").save
City.new(:country_id => "225", :name => "Kusadasi", :aliases => "Efes,Kusadasi,Kush Adasi,Kush AdasÄ±,Kushadassi,Kushadasy,KuÅadasÄ±,Marathesium,Nea Ephesus,Scalanuova,Skala Nuova,Skalanova,kushadas',kushadasi,ÐÑÑÐ°Ð´Ð°ÑÐ¸,ÐÑÑÐ°Ð´Ð°ÑÑ,ÐÑÑÐ°Ð´Ð°ÑÑ,KuÅadasÄ±", :latitude => "37.85562", :longitude => "27.2566").save
City.new(:country_id => "225", :name => "Kurtalan", :aliases => "Kurtalan,Misirdic,Misric,MÄ±srÄ±Ã§,Kurtalan", :latitude => "37.92717", :longitude => "41.70282").save
City.new(:country_id => "225", :name => "Kumluca", :aliases => ",Kumluca", :latitude => "36.36667", :longitude => "30.3").save
City.new(:country_id => "225", :name => "Kulu", :aliases => ",Kulu", :latitude => "39.09514", :longitude => "33.07989").save
City.new(:country_id => "225", :name => "Kulp", :aliases => "Kulp,Kulp", :latitude => "38.49722", :longitude => "41.01222").save
City.new(:country_id => "225", :name => "Kula", :aliases => "Kovla,Kul,Kula,Opsicium,ÐÑÐ»,Kula", :latitude => "38.54726", :longitude => "28.64976").save
City.new(:country_id => "225", :name => "Kozluk", :aliases => "Kozluk,Kozluk", :latitude => "38.19383", :longitude => "41.48853").save
City.new(:country_id => "225", :name => "Kozan", :aliases => "Flaviopolis,Kozan,Sis,Kozan", :latitude => "37.45517", :longitude => "35.81573").save
City.new(:country_id => "225", :name => "Kovancilar", :aliases => "Kovancilar,KovancÄ±lar,KovancÄ±lar", :latitude => "38.72139", :longitude => "39.86806").save
City.new(:country_id => "225", :name => "Korkuteli", :aliases => "Istanos,Korkudeli,Korkuteli,Ä°stanos,ÐÐ¾ÑÐºÑÑÐµÐ»Ð¸,Korkuteli", :latitude => "37.08306", :longitude => "30.20417").save
City.new(:country_id => "225", :name => "Konya", :aliases => "Conia,Iconio,Iconium,Ikonio,Ikoniow,Kon'ja,Konia,Konieh,Konija,Konjao,Konya,Kuniyah,Qonia,kon'ya,qwnyh,qwnyt,ÎÎºÏÎ½Î¹Î¿,ÐÐ¾Ð½Ð¸Ñ,ÐÐ¾Ð½ÑÑ,×§×× ××,ÙÙÙÙØ©,ÙÙÙÛÙ,ã³ã³ã¤,Konya", :latitude => "37.86556", :longitude => "32.4825").save
City.new(:country_id => "225", :name => "Kiziltepe", :aliases => "Kochisar,Kochkhisar,KoÃ§hisar,Kyzyltepe,ÐÑÐ·ÑÐ»ÑÐµÐ¿Ðµ,KÄ±zÄ±ltepe", :latitude => "37.19333", :longitude => "40.585").save
City.new(:country_id => "225", :name => "Serinhisar", :aliases => "Kizilhisar,KÄ±zÄ±lhisar,Serinhisar,Serinhisar", :latitude => "37.58104", :longitude => "29.26639").save
City.new(:country_id => "225", :name => "Kirsehir", :aliases => "Justinianopolis,Kirsehir,Kirshahr,Kirshehr,Kyrshekhir,KÄ±rÅehir,Mocissus,Mokissus,ÐÑÑÑÐµÑÐ¸Ñ,KÄ±rÅehir", :latitude => "39.14583", :longitude => "34.16389").save
City.new(:country_id => "225", :name => "Kirkagac", :aliases => "Kirkagac,KÄ±rkaÄaÃ§,Nacrasa,KÄ±rkaÄaÃ§", :latitude => "39.10638", :longitude => "27.66925").save
City.new(:country_id => "225", :name => "Kirikkale", :aliases => "Kirikkale,Kyrykkale,KÄ±rÄ±kkale,ÐÑÑÑÐºÐºÐ°Ð»Ðµ,KÄ±rÄ±kkale", :latitude => "39.84528", :longitude => "33.50639").save
City.new(:country_id => "225", :name => "Kirikhan", :aliases => ",KÄ±rÄ±khan", :latitude => "36.49939", :longitude => "36.35755").save
City.new(:country_id => "225", :name => "Kilis", :aliases => "Ciliza,Kilis,ÐÐ¸Ð»Ð¸Ñ,Kilis", :latitude => "36.71611", :longitude => "37.115").save
City.new(:country_id => "225", :name => "Keskin", :aliases => "Denek,Denekmadeni,Keskin,Maden,ÐÐµÑÐºÐ¸Ð½,Keskin", :latitude => "39.67306", :longitude => "33.61361").save
City.new(:country_id => "225", :name => "Kemer", :aliases => "Eskikoy,EskikÃ¶y,Kemer,ÐÐµÐ¼ÐµÑ,Kemer", :latitude => "36.59778", :longitude => "30.56056").save
City.new(:country_id => "225", :name => "Kemalpasa", :aliases => "Kemal'pasha,Kemalpasa,KemalpaÅa,Nif,Nymphaeum,ÐÐµÐ¼Ð°Ð»ÑÐ¿Ð°ÑÐ°,KemalpaÅa", :latitude => "38.42621", :longitude => "27.41731").save
City.new(:country_id => "225", :name => "Kayseri", :aliases => "Caesarea,Casarea,Cearee,Cesarea in Cappadocia,Cesaree,CÃ©arÃ©e,CÃ©sarÃ©e,Eusebeia,Kaisaria,Kaisarie,Kaisarije,Kaizarie,Kajseri,Kayseri,KaÄ«zarie,Mazaca,Qaisariye,kaiseri,ÐÐ°Ð¹ÑÐµÑÐ¸,ã«ã¤ã»ãª,Kayseri", :latitude => "38.73222", :longitude => "35.48528").save
City.new(:country_id => "225", :name => "Karapinar", :aliases => "Karapinar,KarapÄ±nar,Sultaniye,KarapÄ±nar", :latitude => "37.71697", :longitude => "33.54323").save
City.new(:country_id => "225", :name => "Karaman", :aliases => "Ak Yokus,Ak YokuÅ,Darende,Karaman,Laranda,ÐÐ°ÑÐ°Ð¼Ð°Ð½,Karaman", :latitude => "37.18111", :longitude => "33.215").save
City.new(:country_id => "225", :name => "Agri", :aliases => "Agiri,AgirÃ®,Agr',Agri,AÄrÄ±,Karakilise,Karakose,KarakÃ¶se,Provinsi Agri,Provinsi AÄrÄ±,a lei sheng,ÐÐ³ÑÑ,é¿åç,AÄrÄ±", :latitude => "39.71944", :longitude => "43.05139").save
City.new(:country_id => "225", :name => "Karakocan", :aliases => "Karakocan,Karakodzhana,KarakoÃ§an,Tepe,Tepekoy,TepekÃ¶y,ÐÐ°ÑÐ°ÐºÐ¾Ð´Ð¶Ð°Ð½Ð°,KarakoÃ§an", :latitude => "38.95583", :longitude => "40.03861").save
City.new(:country_id => "225", :name => "Karacoban", :aliases => ",KaraÃ§oban", :latitude => "39.34919", :longitude => "42.11239").save
City.new(:country_id => "225", :name => "Kaman", :aliases => "Kaman,Keman,ÐÐ°Ð¼Ð°Ð½,Kaman", :latitude => "39.3575", :longitude => "33.72389").save
City.new(:country_id => "225", :name => "Kahta", :aliases => "Kahta,Kakhta,Kolik,Koluk,KÃ¢hta,KÃ¶lÃ¼k,ÐÐ°ÑÑÐ°,KÃ¢hta", :latitude => "37.78552", :longitude => "38.6237").save
City.new(:country_id => "225", :name => "Kahramanmaras", :aliases => "Caesarea Germanicia,Germanicea Marqasi,Gurgum,Kahramanmaras,KahramanmaraÅ,Kakhramanmarash,Maraache,Marache,Maras,Marasch,Marash,Marasion,MaraÅ,Meres,ÐÐ°ÑÑÐ°Ð¼Ð°Ð½Ð¼Ð°ÑÐ°Ñ,KahramanmaraÅ", :latitude => "37.5847", :longitude => "36.9264").save
City.new(:country_id => "225", :name => "Kadirli", :aliases => "Kadirli,Karszulkadriye,KarszÃ¼lkadriye,Kadirli", :latitude => "37.37389", :longitude => "36.09611").save
City.new(:country_id => "225", :name => "Kadinhani", :aliases => "Kadinhani,KadÄ±nhanÄ±,Saideli,Saiteli,syd ayly,Ø³ÛØ¯ Ø§ÛÙÛ,KadÄ±nhanÄ±", :latitude => "38.23972", :longitude => "32.21139").save
City.new(:country_id => "225", :name => "Izmir", :aliases => "Azmir,Esmirna,IZM,Ismir,Izmir,Izmira,Izmiras,Izmiro,Smirne,Smyrna,Smyrne,Yazmir,azmyr,izmiri,izumiru,yi zi mi er,Ä°zmir,Î£Î¼ÏÏÎ½Î·,ÐÐ·Ð¼Ð¸Ñ,××××××¨,Ø¥Ø²ÙÙØ±,ááááá á,ã¤ãºãã«,ä¼å¹å¯å°,Ä°zmir", :latitude => "38.41273", :longitude => "27.13838").save
City.new(:country_id => "225", :name => "Isparta", :aliases => "Baris,Hamid,Hamid-Abad,Hamitabat,Isbarta,Isparta,Ispartah,Izbarta,Izparta,Sparta,Sparte,SpartÄ,Ä°zparta,ÐÑÐ¿Ð°ÑÑÐ°,Isparta", :latitude => "37.76444", :longitude => "30.55222").save
City.new(:country_id => "225", :name => "Iskenderun", :aliases => "Alejandreta,Aleksandretta,Alessandretta,Alexandretta,Alexandrette,Alexandria ad Issum,Iskandariyah,Iskanderun,Iskenderon,Iskenderun,Myriandrus,askndrwn,Ä°skenderon,Ä°skenderun,ÐÑÐºÐµÐ½Ð´ÐµÑÑÐ½,Ø§Ø³Ú©ÙØ¯Ø±ÙÙ,Ä°skenderun", :latitude => "36.58718", :longitude => "36.17347").save
City.new(:country_id => "225", :name => "Incirliova", :aliases => "Incirliova,Karahisar,Karapinar,KarapÄ±nar,Ä°ncirliova,Ä°ncirliova", :latitude => "37.85222", :longitude => "27.72361").save
City.new(:country_id => "225", :name => "Imamoglu", :aliases => ",Ä°mamoÄlu", :latitude => "37.26506", :longitude => "35.65717").save
City.new(:country_id => "225", :name => "Ilgin", :aliases => "Ilgin,IlgÄ±n,Tyriaeum,IlgÄ±n", :latitude => "38.27917", :longitude => "31.91389").save
City.new(:country_id => "225", :name => "Igdir", :aliases => "Idir,Igdir,IÄdÄ±r,ÐÐ³Ð´Ð¸Ñ,IÄdÄ±r", :latitude => "39.92371", :longitude => "44.045").save
City.new(:country_id => "225", :name => "Idil", :aliases => "Hazak,Hezek,Hezex,Idil,Idil',Khazak,Ä°dil,ÐÐ´Ð¸Ð»Ñ,Ä°dil", :latitude => "37.34114", :longitude => "41.8895").save
City.new(:country_id => "225", :name => "Hizan", :aliases => ",Hizan", :latitude => "38.22572", :longitude => "42.42776").save
City.new(:country_id => "225", :name => "Hinis", :aliases => ",HÄ±nÄ±s", :latitude => "39.3606", :longitude => "41.70222").save
City.new(:country_id => "225", :name => "Hilvan", :aliases => "Hilvan,Karacorun,Karacurum,Karacurun,KaraÃ§Ã¼run,Hilvan", :latitude => "37.58686", :longitude => "38.95505").save
City.new(:country_id => "225", :name => "Hadim", :aliases => "Hadim,HadÄ±m,Khadim,Yukari Hadim,YukarÄ± HadÄ±m,Ð¥Ð°Ð´Ð¸Ð¼,HadÄ±m", :latitude => "36.99304", :longitude => "32.45459").save
City.new(:country_id => "225", :name => "Hacilar", :aliases => ",HacÄ±lar", :latitude => "38.64631", :longitude => "35.44937").save
City.new(:country_id => "225", :name => "Guroymak", :aliases => "Cukur,Goroymak,Guroymak,GÃ¶roymak,GÃ¼roymak,Norsin,NorÅin,Ãukur,GÃ¼roymak", :latitude => "38.57739", :longitude => "42.02811").save
City.new(:country_id => "225", :name => "Golbasi", :aliases => ",GÃ¶lbaÅÄ±", :latitude => "37.78361", :longitude => "37.63667").save
City.new(:country_id => "225", :name => "Goksun", :aliases => "Goksun,GÃ¶ksun,GÃ¶ksun", :latitude => "38.02096", :longitude => "36.4973").save
City.new(:country_id => "225", :name => "Genc", :aliases => "Darahini,Genc,Genk,GenÃ§,ÐÐµÐ½Ðº,GenÃ§", :latitude => "38.75071", :longitude => "40.56035").save
City.new(:country_id => "225", :name => "Gemerek", :aliases => ",Gemerek", :latitude => "39.18342", :longitude => "36.07189").save
City.new(:country_id => "225", :name => "Gediz", :aliases => "Cadi,Gedis,Gediz,ÐÐµÐ´Ð¸Ð·,Gediz", :latitude => "39.04167", :longitude => "29.41").save
City.new(:country_id => "225", :name => "Gazipasa", :aliases => "Gazipasa,GazipaÅa,Pazarci,Pazarcik,PazarcÄ±,PazarcÄ±k,Pazarli,PazarlÄ±,Selinti,Silinti,Trajanopolis,GazipaÅa", :latitude => "36.27875", :longitude => "32.29595").save
City.new(:country_id => "225", :name => "Gaziantep", :aliases => "Aintab,Antep,Ayintap,AyÄ±ntap,Dilok,DÃ®lok,Gazi-Ayintap,Gaziantep,gazu~iantepu,ÐÐ°Ð·Ð¸Ð°Ð½ÑÐµÐ¿,ØºØ§Ø²Û Ø¹ÛÙØªØ§Ø¨,ã¬ãºã£ã¢ã³ãã,Gaziantep", :latitude => "37.05944", :longitude => "37.3825").save
City.new(:country_id => "225", :name => "Foca", :aliases => "Eski Foca,Eski Foja,Eski Foka,Eski FoÃ§a,Foca,Focha,Foja,Fokia,Fouges,Foujes,FoÃ§a,Karaca Foka,Karafoca,KarafoÃ§a,Palaies Phokes,Phocaea,FoÃ§a", :latitude => "38.6703", :longitude => "26.75656").save
City.new(:country_id => "225", :name => "Fethiye", :aliases => "Fethieh,Fethiye,Fethy,Fetiye,Fetkhie,Makri,Makry,Telmessus,Ð¤ÐµÑÑÐ¸Ðµ,Fethiye", :latitude => "36.62167", :longitude => "29.11639").save
City.new(:country_id => "225", :name => "Ezine", :aliases => ",Ezine", :latitude => "39.78561", :longitude => "26.34083").save
City.new(:country_id => "225", :name => "Eskisehir", :aliases => "Dorylaeum,DorylÃ¤um,Ehskishekhir,Eski Shahr,Eski Shehir,Eski shehr,Eski-chehir,Eski-chÃ©hir,Eskischehir,Ð­ÑÐºÐ¸ÑÐµÑÐ¸Ñ,EskiÅehir", :latitude => "39.77667", :longitude => "30.52056").save
City.new(:country_id => "225", :name => "Erzurum", :aliases => "Ard-ar-Rum,Arzan-ar-Rum,Carana,Ehrzurum,Erserum,Erzeroum,Erzerum,Erzirom,Erzirum,Erzurum,ErzÃ©roum,Kalikala,Karin,Theodosiopolis,Ð­ÑÐ·ÑÑÑÐ¼,Erzurum", :latitude => "39.90861", :longitude => "41.27694").save
City.new(:country_id => "225", :name => "Erzincan", :aliases => "Arzanjan,Aziris,Ehrzindzhan,Ersindjan,Ersingan,Ersingjan,Erzincam,Erzincan,Erzindjan,Erzingan,Erzinjan,Yerznka,arznjan,eruzu~injan,Ð­ÑÐ·Ð¸Ð½Ð´Ð¶Ð°Ð½,Ø§Ø±Ø²ÙØ¬Ø§Ù,ã¨ã«ãºã£ã³ã¸ã£ã³,Erzincan", :latitude => "39.75222", :longitude => "39.49278").save
City.new(:country_id => "225", :name => "Ermenek", :aliases => "Ermenak,Ermenek,Germanicopolis,Ermenek", :latitude => "36.65007", :longitude => "32.87661").save
City.new(:country_id => "225", :name => "Ergani", :aliases => "Arghana,Ehgrani,Ergani,Erganiosmaniye,Osmaniye,Ð­Ð³ÑÐ°Ð½Ð¸,Ergani", :latitude => "38.26533", :longitude => "39.76212").save
City.new(:country_id => "225", :name => "Eregli", :aliases => "Cybistra,Ehregli,Erakleia,Eregli,EreÄli,Heraclea,Heraclea Minoa,Heraclee,Heracleia Minoa,HÃ©raclÃ©e,Konyaereglisi,KonyaereÄlisi,ÎÏÎ¬ÎºÎ»ÎµÎ¹Î±,Ð­ÑÐµÐ³Ð»Ð¸,EreÄli", :latitude => "37.51333", :longitude => "34.04672").save
City.new(:country_id => "225", :name => "Erdemli", :aliases => ",Erdemli", :latitude => "36.60498", :longitude => "34.30836").save
City.new(:country_id => "225", :name => "Ercis", :aliases => "Arcis,Ercis,ErciÅ,ErciÅ", :latitude => "39.02869", :longitude => "43.35864").save
City.new(:country_id => "225", :name => "Emirdag", :aliases => "Aziziye,Emirdag,EmirdaÄ,EmirdaÄ", :latitude => "39.01972", :longitude => "31.15").save
City.new(:country_id => "225", :name => "Emet", :aliases => "Ehmet,Emet,Ð­Ð¼ÐµÑ,Emet", :latitude => "39.343", :longitude => "29.25847").save
City.new(:country_id => "225", :name => "Elmali", :aliases => "Elmali,ElmalÄ±,ElmalÄ±", :latitude => "36.73583", :longitude => "29.91775").save
City.new(:country_id => "225", :name => "Elmadag", :aliases => "Asiyozgat,AsÄ±yozgat,Elmadag,Elmadagi,ElmadaÄÄ±,Kucukyozgat,KÃ¼Ã§Ã¼kyozgat,Elmadag", :latitude => "39.92083", :longitude => "33.23083").save
City.new(:country_id => "225", :name => "Eleskirt", :aliases => "Eleskirt,EleÅkirt,Toprakkale,Zeydekan,Zeydikan,ZeydikÃ¢n,Zidikan,ZidikÃ¢n,EleÅkirt", :latitude => "39.80333", :longitude => "42.67361").save
City.new(:country_id => "225", :name => "Elbistan", :aliases => "Ehl'bistan,Elbistan,albstan,Ð­Ð»ÑÐ±Ð¸ÑÑÐ°Ð½,Ø§ÙØ¨Ø³ØªØ§Ù,Elbistan", :latitude => "38.20591", :longitude => "37.1983").save
City.new(:country_id => "225", :name => "Elazig", :aliases => "Elazig,Elaziz,ElaziÄ,ElazÄ±Ä,Eljaz'g,ElÃ¢zÄ±z,Mezra,Mezreh,ÐÐ»ÑÐ·ÑÐ³,ElazÄ±Ä", :latitude => "38.67431", :longitude => "39.22321").save
City.new(:country_id => "225", :name => "Egirdir", :aliases => "Egirdir,Egridir,EÄirdir,Prostanna,EÄirdir", :latitude => "37.87462", :longitude => "30.85042").save
City.new(:country_id => "225", :name => "Edremit", :aliases => "Adramyti,Adramyttium,Edremid,Edremit,Ehdremit,Ð­Ð´ÑÐµÐ¼Ð¸Ñ,Edremit", :latitude => "39.59611", :longitude => "27.02444").save
City.new(:country_id => "225", :name => "Dursunbey", :aliases => "Balat,Dursunbey,Dursunbey", :latitude => "39.58596", :longitude => "28.62568").save
City.new(:country_id => "225", :name => "Dortyol", :aliases => ",DÃ¶rtyol", :latitude => "36.86158", :longitude => "36.22885").save
City.new(:country_id => "225", :name => "Dogubayazit", :aliases => "Baiazid,Bajaset,Bajasid,Bajesid,Bayazid,Bayazit,Bayezid,Bazid,BazÃ®d,BaÄ«azid,Beyazit,BeyazÄ±t,Beyzit,BeyzÄ±t,Dogu Beyazidi,Dogubajazit,Dogubayazid,Dogubayazidi,Dogubayazit,Dogubeyazit,DoÄu Beyazidi,DoÄubayazidi,DoÄubayazÄ±d,DoÄubayazÄ±t,DoÄubeyazÄ±t,Karakose,KarakÃ¶se,dghw bayzyd,ÐÐ¾Ð³ÑÐ±Ð°ÑÐ·Ð¸Ñ,Ø¯ØºÙ Ø¨Ø§ÛØ²ÛØ¯,DoÄubayazÄ±t", :latitude => "39.54694", :longitude => "44.08417").save
City.new(:country_id => "225", :name => "Diyarbakir", :aliases => "Amed,Amida,Diarbakir,Diarbekir,Diarbekr,Diari-Bekir,Diari-BÃ©kir,Dijarbakiro,Dijarbakyr,Dikranakerd,Diyarbakir,DiyarbakÄ±r,Diyarbekir,Diyaribakir,Diyaribekir,DiyarÄ±bakÄ±r,DiyarÄ±bekir,diyarubakuru,dyar bkr,dyarbkr,ÐÐ¸Ð°ÑÐ±ÐµÐºÐ¸Ñ,ÐÐ¸ÑÑÐ±Ð°ÐºÑÑ,××××¨××§××¨,Ø¯ÙØ§Ø± Ø¨ÙØ±,Ø¯ÛØ§Ø±Ø¨Ú©Ø±,ãã£ã¤ã«ãã¯ã«,DiyarbakÄ±r", :latitude => "37.91583", :longitude => "40.21889").save
City.new(:country_id => "225", :name => "Diyadin", :aliases => "Didayin,Diyadin,Diyadin", :latitude => "39.54056", :longitude => "43.67135").save
City.new(:country_id => "225", :name => "Dinar", :aliases => "Apamea Cibotus,Celaenae,Dinar,Dineir,Geyiklar,ÐÐ¸Ð½Ð°Ñ,Dinar", :latitude => "38.065", :longitude => "30.16557").save
City.new(:country_id => "225", :name => "Develi", :aliases => "Develi,Everek,Evrek,Develi", :latitude => "38.39056", :longitude => "35.49222").save
City.new(:country_id => "225", :name => "Denizli", :aliases => "Denisli,Denislu,DenislÃ¼,Denizli,Denizlu,ÐÐµÐ½Ð¸Ð·Ð»Ð¸,Denizli", :latitude => "37.77417", :longitude => "29.0875").save
City.new(:country_id => "225", :name => "Demirci", :aliases => ",Demirci", :latitude => "39.04607", :longitude => "28.65889").save
City.new(:country_id => "225", :name => "Dargecit", :aliases => "Dargechit,Dargecit,DargeÃ§it,Deregecit,DeregeÃ§it,Kerboran,Kerburan,Kerburun,ÐÐ°ÑÐ³ÐµÑÐ¸Ñ,DargeÃ§it", :latitude => "37.54545", :longitude => "41.71966").save
City.new(:country_id => "225", :name => "Darende", :aliases => "Darende,Yarpus,ÐÐ°ÑÐµÐ½Ð´Ðµ,Darende", :latitude => "38.54583", :longitude => "37.50583").save
City.new(:country_id => "225", :name => "Cumra", :aliases => ",Ãumra", :latitude => "37.57317", :longitude => "32.77885").save
City.new(:country_id => "225", :name => "Cumaovasi", :aliases => "Cumaovasi,CumaovasÄ±,Menderes,ÐÐµÐ½Ð´ÐµÑÐµÑ,CumaovasÄ±", :latitude => "38.24963", :longitude => "27.13429").save
City.new(:country_id => "225", :name => "Hakkari", :aliases => "Colemerik,Hakari,Hakkari,HakÃ¢ri,Julamerk,Khakkari,ÃÃ¶lemerik,Ð¥Ð°ÐºÐºÐ°ÑÐ¸,Hakkari", :latitude => "37.57444", :longitude => "43.74083").save
City.new(:country_id => "225", :name => "Cizre", :aliases => "Beit Zabde,Bezabde,Dzhizre,Jazirhe-a-ibn-a Omar,Jesiret ibn Omar,JesÄ±ret ibn Omar,ÐÐ¶Ð¸Ð·ÑÐµ,Cizre", :latitude => "37.32722", :longitude => "42.19028").save
City.new(:country_id => "225", :name => "Cine", :aliases => "Cine,Hanakpinar,HanakpÄ±nar,Ãine,Ãine", :latitude => "37.61167", :longitude => "28.06139").save
City.new(:country_id => "225", :name => "Ceylanpinar", :aliases => "Cylanpinar,Dzheylanpynar,Raselain,Rass-el-Ain,Rass-el-AÃ¯n,Resulayn,ResÃ¼layn,CeylanpÄ±nar", :latitude => "36.84722", :longitude => "40.05").save
City.new(:country_id => "225", :name => "Ceyhan", :aliases => "Ceyhan,Dzhejkhan,Hamidiye,Jehan,jyhan,ÐÐ¶ÐµÐ¹ÑÐ°Ð½,Ø¬ÙÙØ§Ù,Ceyhan", :latitude => "37.02472", :longitude => "35.8175").save
City.new(:country_id => "225", :name => "Cesme", :aliases => "Cesme,Cheshme,Chesme,Chesnie,Cissus,CÄ±ssus,ÃeÅme,Ð§ÐµÑÐ¼Ðµ,ÃeÅme", :latitude => "38.32278", :longitude => "26.30639").save
City.new(:country_id => "225", :name => "Cermik", :aliases => "Cemik,Cermik,Ãemik,Ãermik,Ãermik", :latitude => "38.13613", :longitude => "39.44929").save
City.new(:country_id => "225", :name => "Cay", :aliases => "Cay,Kej,Ãay,ÐÐµÐ¹,Ãay", :latitude => "38.59167", :longitude => "31.02861").save
City.new(:country_id => "225", :name => "Caglayancerit", :aliases => "Buyuk Cerbit,Buyuk Cerit,BÃ¼yÃ¼k Cerbit,BÃ¼yÃ¼k Cerit,Caglayancerit,Cagliyan Cerit,ÃaÄlayancerit,ÃaÄlÄ±yan Ãerit,ÃaÄlayancerit", :latitude => "37.74959", :longitude => "37.29622").save
City.new(:country_id => "225", :name => "Burhaniye", :aliases => "Burhaniye,Kemer,Burhaniye", :latitude => "39.50041", :longitude => "26.97269").save
City.new(:country_id => "225", :name => "Burdur", :aliases => "Bourdour,Buldur,Burdur,Polydorion,ÐÑÑÐ´ÑÑ,Burdur", :latitude => "37.72028", :longitude => "30.29083").save
City.new(:country_id => "225", :name => "Bulanik", :aliases => ",BulanÄ±k", :latitude => "39.09292", :longitude => "42.27031").save
City.new(:country_id => "225", :name => "Bucak", :aliases => "Bucak,Budzhak,ÐÑÐ´Ð¶Ð°Ðº,Bucak", :latitude => "37.45917", :longitude => "30.595").save
City.new(:country_id => "225", :name => "Bozyazi", :aliases => ",BozyazÄ±", :latitude => "36.1082", :longitude => "32.96113").save
City.new(:country_id => "225", :name => "Bozuyuk", :aliases => "Bozoyuk,Bozuyuk,BozÃ¶yÃ¼k,BozÃ¼yÃ¼k,BozÃ¼yÃ¼k", :latitude => "39.90778", :longitude => "30.03667").save
City.new(:country_id => "225", :name => "Bozova", :aliases => "Bozova,Hovenk,Huvek,HÃ¶venk,HÃ¼vek,ÐÐ¾Ð·Ð¾Ð²Ð°,Bozova", :latitude => "37.3625", :longitude => "38.52667").save
City.new(:country_id => "225", :name => "Bor", :aliases => "Bor,ÐÐ¾Ñ,Bor", :latitude => "37.89056", :longitude => "34.55889").save
City.new(:country_id => "225", :name => "Bolvadin", :aliases => "Bolvadin,Bolvadin", :latitude => "38.71111", :longitude => "31.04861").save
City.new(:country_id => "225", :name => "Bodrum", :aliases => "Bodrum,Bodurum,Budrum,Halicarnassus,Petronium,bodorumu,bwdrwm,ÐÐ¾Ð´ÑÑÐ¼,××××¨××,ããã«ã ,Bodrum", :latitude => "37.03833", :longitude => "27.42917").save
City.new(:country_id => "225", :name => "Bismil", :aliases => "Bismil,Bismil", :latitude => "37.84861", :longitude => "40.66583").save
City.new(:country_id => "225", :name => "Birecik", :aliases => "Apamea,Birecik,Biredzhik,Birejik,Birijik,ÐÐ¸ÑÐµÐ´Ð¶Ð¸Ðº,Birecik", :latitude => "37.02944", :longitude => "37.99028").save
City.new(:country_id => "225", :name => "Bingol", :aliases => "Badlis,Bingol,BingÃ¶l,Capakcur,Cevlik,ÃapakÃ§ur,Ãevlik,ÐÐ¸Ð½Ð³Ð¾Ð»,BingÃ¶l", :latitude => "38.88472", :longitude => "40.49389").save
City.new(:country_id => "225", :name => "Bigadic", :aliases => "Bigadic,BigadiÃ§,BigadiÃ§", :latitude => "39.3925", :longitude => "28.13111").save
City.new(:country_id => "225", :name => "Beysehir", :aliases => "Bejshekhir,Beysehir,BeyÅehir,bkshhry,ÐÐµÐ¹ÑÐµÑÐ¸Ñ,Ø¨Ú©Ø´ÙØ±Û,BeyÅehir", :latitude => "37.67639", :longitude => "31.72611").save
City.new(:country_id => "225", :name => "Besni", :aliases => "Bahisni,Behisni,Besni,Besni", :latitude => "37.69278", :longitude => "37.86111").save
City.new(:country_id => "225", :name => "Bergama", :aliases => "Bergama,Pergame,Pergamo,Pergamon,Pergamos,Pergamum,PÃ©rgamo,bie jia mo,brgama,pa jia ma,perugamon,prgamwn,prgmwn,ÐÐµÑÐ³Ð°Ð¼Ð°,ÐÐµÑÐ³Ð°Ð¼Ð¾Ð½,×¤×¨××××,Ø¨Ø±Ú¯Ø§ÙØ§,Ù¾Ø±Ú¯Ø§ÙÙÙ,ãã«ã¬ã¢ã³,å¥è¿¦æ©,å¸å é©¬,Bergama", :latitude => "39.12074", :longitude => "27.18052").save
City.new(:country_id => "225", :name => "Belen", :aliases => "Beilan,Belen,Beylan,Bilan,ÐÐµÐ»ÐµÐ½,Belen", :latitude => "36.48911", :longitude => "36.22331").save
City.new(:country_id => "225", :name => "Belek", :aliases => "Belek,Belekoy,BelekÃ¶y,Besyigit,BeÅyiÄit,ÐÐµÐ»ÐµÐº,Belek", :latitude => "36.86278", :longitude => "31.05556").save
City.new(:country_id => "225", :name => "Bayindir", :aliases => "Baindir,Bajindyr,Bayindir,BayÄ±ndÄ±r,ÐÐ°Ð¹Ð¸Ð½Ð´ÑÑ,BayÄ±ndÄ±r", :latitude => "38.21741", :longitude => "27.64744").save
City.new(:country_id => "225", :name => "Batman", :aliases => "Batman,Iloh,Iluh,ÐÐ°ÑÐ¼Ð°Ð½,Batman", :latitude => "37.88738", :longitude => "41.13221").save
City.new(:country_id => "225", :name => "Baskil", :aliases => ",Baskil", :latitude => "38.56791", :longitude => "38.82382").save
City.new(:country_id => "225", :name => "Banaz", :aliases => "Banaz,Islamkoy,Ä°slamkÃ¶y,Banaz", :latitude => "38.73707", :longitude => "29.75194").save
City.new(:country_id => "225", :name => "Balikesir", :aliases => "Achyraus,Adrianoutherai,AdrianouthÄrai,Bali-Kessir,Balikesir,Balikesr,Balikesri,Balukisu,Balykesir,BalÄ±kesir,Belikesir,Belikiser,Hadrianutherae,Karassi,ÐÐ°Ð»ÑÐºÐµÑÐ¸Ñ,BalÄ±kesir", :latitude => "39.64917", :longitude => "27.88611").save
City.new(:country_id => "225", :name => "Bahce", :aliases => "Bahce,BahÃ§e,Bulanik,Bulanikbahce,BulanÄ±k,BulanÄ±kbahÃ§e,BahÃ§e", :latitude => "37.19724", :longitude => "36.57658").save
City.new(:country_id => "225", :name => "Ayvalik", :aliases => "Aivali,Ajvalyk,Ayvalik,AyvalÄ±k,Cisthene,Kydoniai,aywalq,ÐÐ¹Ð²Ð°Ð»ÑÐº,Ø§ÛÙØ§ÙÙ,AyvalÄ±k", :latitude => "39.31905", :longitude => "26.6954").save
City.new(:country_id => "225", :name => "Aydin", :aliases => "Aidin,Aidinion,Ajdyn,Aydin,AydÄ±n,AÃ¯din,AÃ¯dÃ­nion,Gusel Hissar,Guzel Hissar,GÃ¼sel Hissar,GÃ¼zel Hissar,Tralleis,Tralles,Tralli,ÐÐ¹Ð´ÑÐ½,AydÄ±n", :latitude => "37.84501", :longitude => "27.83963").save
City.new(:country_id => "225", :name => "Askale", :aliases => ",AÅkale", :latitude => "39.92083", :longitude => "40.695").save
City.new(:country_id => "225", :name => "Antalya", :aliases => "Adalia,Antal'ja,Antalia,Antalija,Antaliyah,Antalya,Antayla,AntÃ¡lia,Attaleia,Attalia,Olbia,Satalia,an ta li ya,antaruya,ÎÏÏÎ¬Î»ÎµÎ¹Î±,ÐÐ½ÑÐ°Ð»Ð¸Ñ,ÐÐ½ÑÐ°Ð»ÑÑ,×× ××××,ã¢ã³ã¿ã«ã¤,å®å¡å©äº,Antalya", :latitude => "36.9125", :longitude => "30.68972").save
City.new(:country_id => "225", :name => "Antioch", :aliases => "Antakija,Antakiya,Antakiyyah,Antakya,Antioch,Antiocheia,Antiochia,Antiochia am Orontes,Antiochia di Siria,Antiochia vid Orontes,Antiochie,AntiochiÃ«,Antiohija,Antiokheia,Antiokhija,Antiokia,Antioquia,AntioquÃ­a,AntÄkiyyah,AntÄ±och,Hatay,an tiao ke,antakyt,antiokeia,ntakyt,ÎÎ½ÏÎ¹ÏÏÎµÎ¹Î±,ÐÐ½ÑÐ°ÐºÐ¸Ñ,ÐÐ½ÑÐ¸Ð¾ÑÐ¸Ñ,ÐÐ½ÑÐ¸Ð¾ÑÐ¸ÑÐ°,×× ××××××,Ø£ÙØ·Ø§ÙÙØ©,ÙØªØ§ÙÙÙØ©,ã¢ã³ãã£ãªã±ã¤ã¢,å®æ¡å,Antioch", :latitude => "36.20655", :longitude => "36.15722").save
City.new(:country_id => "225", :name => "Ankara", :aliases => "Ancara,Ancara - Ankara,Ancyra,Angora,Anguriyah,Ankara,Ankaro,Ankura,Ankyra,Enguri,EngÃ¼ri,Enqere,an ka la,angkala,ankara,anqrt,astan ankara,ÎÎ³ÎºÏÏÎ±,ÐÐ½ÐºÐ°ÑÐ°,Ô±Õ¶Õ¯Õ¡ÖÕ¡,×× ×§×¨×,Ø£ÙÙØ±Ø©,Ø¦ÛÙÙÛØ±Û,Ø§Ø³ØªØ§Ù Ø¢ÙÚ©Ø§Ø±Ø§,Ø§ÙÙØ±Û,ÜÜ¢Ü©ÜªÜ,à¤à¤à¤à¤¾à¤°à¤¾,ááááá á,ã¢ã³ã«ã©,å®å¡æ,ìì¹´ë¼,Ankara", :latitude => "39.91987", :longitude => "32.85427").save
City.new(:country_id => "225", :name => "Anamur", :aliases => "Anamur,Anemurium,ÐÐ½Ð°Ð¼ÑÑ,Anamur", :latitude => "36.07833", :longitude => "32.83417").save
City.new(:country_id => "225", :name => "Aliaga", :aliases => "Aliaga,Aliagaciftligi,AliaÄa,AliaÄaÃ§iftliÄi,ÐÐ»Ð¸Ð°Ð³Ð°,AliaÄa", :latitude => "38.79975", :longitude => "26.97203").save
City.new(:country_id => "225", :name => "Alasehir", :aliases => "Ala Shehr,Alachehir,Alachehr,Alaschehir,Alasehir,Alashehir,Alashekhir,AlaÅehir,Alesehir,AleÅehir,Filadelfeia,Philadelphia,arashehiru,ÐÐ»Ð°ÑÐµÑÐ¸Ñ,ã¢ã©ã·ã§ãã«,AlaÅehir", :latitude => "38.35083", :longitude => "28.51718").save
City.new(:country_id => "225", :name => "Alanya", :aliases => "Alaia,Alaiye,Alan'ja,Alanija,Alanya,Alaya,AlÃ¢iye,Coracesium,ÐÐ»Ð°Ð½Ð¸Ñ,ÐÐ»Ð°Ð½ÑÑ,××× ××,Alanya", :latitude => "36.55132", :longitude => "31.9975").save
City.new(:country_id => "225", :name => "Aksehir", :aliases => "Ak Shehr,Aksehir,AkÅehir,Philomelium,AkÅehir", :latitude => "38.3575", :longitude => "31.41639").save
City.new(:country_id => "225", :name => "Aksaray", :aliases => "Aksaraj,Aksaray,ÐÐºÑÐ°ÑÐ°Ð¹,Aksaray", :latitude => "38.37255", :longitude => "34.02537").save
City.new(:country_id => "225", :name => "Akhisar", :aliases => "Akhisar,Akhissar,Akkhisar,Aq Hisar,Axari,Azarion,Thyatira,ÐÐºÑÐ¸ÑÐ°Ñ,Akhisar", :latitude => "38.91852", :longitude => "27.84006").save
City.new(:country_id => "225", :name => "Akdagmadeni", :aliases => "Adagmadeni,AdaÄmadenÄ±,Akdagmadeni,AkdaÄmadeni,AkdaÄmadeni", :latitude => "39.66028", :longitude => "35.88361").save
City.new(:country_id => "225", :name => "Akcakale", :aliases => "Akcakale,Akcekale,Akchakale,AkÃ§akale,AkÃ§akale", :latitude => "36.71111", :longitude => "38.9475").save
City.new(:country_id => "225", :name => "Ahlat", :aliases => "Ahlat,Akhlat,Erkizan,ÐÑÐ»Ð°Ñ,Ahlat", :latitude => "38.75178", :longitude => "42.48135").save
City.new(:country_id => "225", :name => "Afyonkarahisar", :aliases => "Acroenus,AcroÃ«nus,Af'onkarakhisar,Afion - Afyon,Afion Karahissar,Afioun-Kara-Hissar,Afium Kara Hissar,Afium Karahisar,Afiun Karahissar,Afiun Qarahisar,Afiun-Carahissar,Afyon,Afyonkarahisar,AfÄ±on Karahissar,Kara Hissar Sahib,Karahisarisahip,KarahÄ±sarÄ±sahÄ±p,ÐÑÑÐ¾Ð½ÐºÐ°ÑÐ°ÑÐ¸ÑÐ°Ñ,Ø§ÙÛÙÙâ ÙØ±Ù Ø­ØµØ§Ø±Û,ÙØ±Ù âØ­ØµØ§Ø± Ø³Ø§Ø­Ø¨,Afyonkarahisar", :latitude => "38.75667", :longitude => "30.54333").save
City.new(:country_id => "225", :name => "Afsin", :aliases => "Afsin,AfÅin,Efsus,Yarpus,Yarpuz,AfÅin", :latitude => "38.24769", :longitude => "36.91399").save
City.new(:country_id => "225", :name => "Adiyaman", :aliases => "Adiaman,Adityman,Adiyaman,Adiyaman Province,Adiyamanska provincie,Adyjaman,AdÄ±yaman,AdÄ±yaman Province,AdÄ±yamanskÃ¡ provincie,Carbanum,Hisnumansur,Husnimansur,Husnumansur,HÃ¼snÃ¼mansur,Perre,Pordonnium,Provincia de Adiyaman,Provinsi Adiyaman,Provinsi AdÄ±yaman,Semsur,SemsÃ»r,a de ya man sheng,adyaman,ÐÐ´ÑÑÐ¼Ð°Ð½,××××××,Ø¢Ø¯ÛØ§ÙØ§Ù,é¿å¾·äºæ¼ç,AdÄ±yaman", :latitude => "37.76441", :longitude => "38.27629").save
City.new(:country_id => "225", :name => "Adilcevaz", :aliases => "Adeljivaz,Adilcevaz,Adildzhevaz,ÐÐ´Ð¸Ð»Ð´Ð¶ÐµÐ²Ð°Ð·,Ø¹Ø§Ø¯Ø§ÙØ¬ÙØ§Ø²,Ø¹Ø§Ø¯ÙØ¬ÙØ§Ø²,Adilcevaz", :latitude => "38.80389", :longitude => "42.73422").save
City.new(:country_id => "225", :name => "Adana", :aliases => "Adana,Adhanah,Antiocheia,adana,adnt,ÎÎ´Î±Î½Î±,ÎÎ´Î±Î½Î±,ÎÎ½ÏÎ¹ÏÏÎµÎ¹Î±,ÐÐ´Ð°Ð½Ð°,Ô±Õ¤Õ¡Õ¶Õ¡,Ø£Ø¶ÙØ©,ã¢ãã,Adana", :latitude => "37.00167", :longitude => "35.32889").save
City.new(:country_id => "225", :name => "Denizciler", :aliases => ",Denizciler", :latitude => "36.64951", :longitude => "36.22956").save
City.new(:country_id => "225", :name => "Batikent", :aliases => "Batikent,BatÄ±kent,Batikent", :latitude => "39.96833", :longitude => "32.73083").save
City.new(:country_id => "225", :name => "Dalaman", :aliases => "Dalaman,Dalaman", :latitude => "36.76591", :longitude => "28.8028").save
City.new(:country_id => "225", :name => "Zonguldak", :aliases => "Sandaraca,Songuldak,Sungul,Zonguldak,Zonguldaq,Zoungouldagh,Zunguldak,ÐÐ¾Ð½Ð³ÑÐ»Ð´Ð°Ðº,Zonguldak", :latitude => "41.45139", :longitude => "31.79305").save
City.new(:country_id => "225", :name => "Zile", :aliases => "Zil,Zile,ÐÐ¸Ð»,Zile", :latitude => "40.30306", :longitude => "35.88639").save
City.new(:country_id => "225", :name => "Zeytinburnu", :aliases => ",Zeytinburnu", :latitude => "40.99441", :longitude => "28.90417").save
City.new(:country_id => "225", :name => "Yomra", :aliases => "Dirona,Yomra,Yomra", :latitude => "40.95411", :longitude => "39.86405").save
City.new(:country_id => "225", :name => "Yenisehir", :aliases => ",YeniÅehir", :latitude => "40.26444", :longitude => "29.65306").save
City.new(:country_id => "225", :name => "Korfez", :aliases => "Korfez,KÃ¶rfez,Yaremdji,Yarimca,YarÄ±mca,KÃ¶rfez", :latitude => "40.77667", :longitude => "29.72972").save
City.new(:country_id => "225", :name => "Yalova", :aliases => "Jalova,Pythiae Thermae,Yalova,Yaluva,Ð¯Ð»Ð¾Ð²Ð°,Yalova", :latitude => "40.65502", :longitude => "29.27693").save
City.new(:country_id => "225", :name => "Yakuplu", :aliases => "Tarakatya,Yakuplu", :latitude => "40.98894", :longitude => "28.67582").save
City.new(:country_id => "225", :name => "Vezirkopru", :aliases => "Koeprue,KÃ¶prÃ¼,Vezirkeprju,Vezirkopru,VezirkÃ¶prÃ¼,kpry,kwpry,ÐÐµÐ·Ð¸ÑÐºÐµÐ¿ÑÑ,Ú©ÙÙ¾Ø±Û,Ú©Ù¾Ø±Û,VezirkÃ¶prÃ¼", :latitude => "41.14361", :longitude => "35.45472").save
City.new(:country_id => "225", :name => "Vakfikebir", :aliases => ",VakfÄ±kebir", :latitude => "41.04583", :longitude => "39.27639").save
City.new(:country_id => "225", :name => "Uzun Keupru", :aliases => "Ivanski,Uzun Keupru,Uzunkeprju,Uzunkopru,UzunkÃ¶prÃ¼,Ð£Ð·ÑÐ½ÐºÐµÐ¿ÑÑ,Uzun Keupru", :latitude => "41.26598", :longitude => "26.6885").save
City.new(:country_id => "225", :name => "Unieh", :aliases => "Oenoe,Onieh,Un'e,Unia,Unie,Unieh,Unye,Ãnia,Ãnye,Ð£Ð½ÑÐµ,Unieh", :latitude => "41.13139", :longitude => "37.2825").save
City.new(:country_id => "225", :name => "Umraniye", :aliases => ",Umraniye", :latitude => "41.01643", :longitude => "29.12476").save
City.new(:country_id => "225", :name => "Turhal", :aliases => "TURKHAL,Turhal,Ð¢Ð£Ð Ð¥ÐÐ,Turhal", :latitude => "40.3875", :longitude => "36.08111").save
City.new(:country_id => "225", :name => "Trabzon", :aliases => "Atrabazandah,TRABZON,Tarabazandah,Tirabson,Tirabzon,Trabzon,Trapezonte,Trapezounta,Trapezund,Trapezunt,Trapezus,Trapisonda,Trebisonda,Trebizond,Trebizonda,Trebizonde,TrÃ©bizonde,torabuzon,trbzwn,Î¤ÏÎ±ÏÎµÎ¶Î¿ÏÎ½ÏÎ±,Ð¢Ð ÐÐÐÐÐ,Ð¢ÑÐ°Ð±Ð·Ð¾Ð½,××¨××××,á¢á áááááá,ãã©ãã¾ã³,Trabzon", :latitude => "41.005", :longitude => "39.72694").save
City.new(:country_id => "225", :name => "Tosya", :aliases => "Docea,Tosja,Tosya,Ð¢Ð¾ÑÑ,Tosya", :latitude => "41.02818", :longitude => "34.02242").save
City.new(:country_id => "225", :name => "Tokat", :aliases => "Dazimon,Provincia de Tokat,TOKAT,Tokat,Tokat Province,Tokatiaen,TokatiÃ¤n,Tokatska provincie,TokatskÃ¡ provincie,Toqat,Tukat,Ð¢ÐÐÐÐ¢,Tokat", :latitude => "40.31389", :longitude => "36.55444").save
City.new(:country_id => "225", :name => "Tirebolu", :aliases => "TIREBOLU,Tarablus,Tereboli,Tireboli,Tirebolu,Trebolu,Tripolis,Ð¢ÐÐ ÐÐÐÐÐ£,Tirebolu", :latitude => "41.00694", :longitude => "38.81389").save
City.new(:country_id => "225", :name => "Terme", :aliases => "TERME,Terme,Ð¢ÐÐ ÐÐ,Terme", :latitude => "41.20917", :longitude => "36.97389").save
City.new(:country_id => "225", :name => "Tepecik", :aliases => "Playa,Tepecik,Tepecik", :latitude => "41.02931", :longitude => "28.54978").save
City.new(:country_id => "225", :name => "Tekkekoy", :aliases => "Tekke,Tekkekej,Tekkekoey,Tekkekoy,TekkekÃ¶y,Ð¢ÐµÐºÐºÐµÐºÐµÐ¹,TekkekÃ¶y", :latitude => "41.21167", :longitude => "36.46").save
City.new(:country_id => "225", :name => "Tekirdag", :aliases => "Bisanthe,Rhaedestus,Rodoscuk,Rodosto,RodostÃ³,RodosÃ§uk,Tekfur Dagh,Tekfurdag,TekfurdaÄ,Tekirdag,TekirdaÄ,Tektur Dagh,Ð Ð¾Ð´Ð¾ÑÑÐ¾,Ð¢ÐµÐºÐ¸ÑÐ´Ð°Ð³,TekirdaÄ", :latitude => "40.97801", :longitude => "27.50852").save
City.new(:country_id => "225", :name => "Tasova", :aliases => "TASHOVA,Tasova,TaÅova,Yemisenbuku,YemiÅenbÃ¼kÃ¼,Ð¢ÐÐ¨ÐÐÐ,TaÅova", :latitude => "40.75972", :longitude => "36.3225").save
City.new(:country_id => "225", :name => "Taskopru", :aliases => ",TaÅkÃ¶prÃ¼", :latitude => "41.51389", :longitude => "34.21472").save
City.new(:country_id => "225", :name => "Susehri", :aliases => "Endires,Endiryas,SUSHEKHRI,Susehiri,Susehri,SuÅehiri,SuÅehri,Ð¡Ð£Ð¨ÐÐ¥Ð Ð,SuÅehri", :latitude => "40.16444", :longitude => "38.08667").save
City.new(:country_id => "225", :name => "Surmene", :aliases => "Hamurgan,HamurgÃ¢n,Homurgan,Humurgan,HumurgÃ¢n,Kamurghia,SJURMENE,Suermene,Surmene,SÃ¼rmene,Ð¡Ð®Ð ÐÐÐÐ,SÃ¼rmene", :latitude => "40.91258", :longitude => "40.11676").save
City.new(:country_id => "225", :name => "Sungurlu", :aliases => "Sungurlu,Ð¡ÑÐ½Ð³ÑÑÐ»Ñ,Sungurlu", :latitude => "40.1675", :longitude => "34.37389").save
City.new(:country_id => "225", :name => "Suluova", :aliases => "Suluca,Suluova,Suluova", :latitude => "40.83128", :longitude => "35.64788").save
City.new(:country_id => "225", :name => "Sisli", :aliases => "Sisli,ÅiÅli,ÅiÅli", :latitude => "41.06046", :longitude => "28.98717").save
City.new(:country_id => "225", :name => "Sinop", :aliases => "Sanub,Sinob,Sinop,Sinope,Sinub,SÄ±nob,shinope,synwp,Î£Î¹Î½ÏÏÎ·,Ð¡Ð¸Ð½Ð¾Ð¿,×¡×× ××¤,ã·ãã,Sinop", :latitude => "42.03087", :longitude => "35.17124").save
City.new(:country_id => "225", :name => "Silivri", :aliases => "Selymbria,Siliviri,Silivri,slwry,slywry,Ø³ÙÙØ±Û,Ø³ÙÛÙØ±Û,Silivri", :latitude => "41.08022", :longitude => "28.22605").save
City.new(:country_id => "225", :name => "Sebinkarahisar", :aliases => "Colonia,Karahisar-i Sarki,Karahisar-Ä± Åarki,SHEBINKARAKHISAR,Sarki Karahissar,Sebinkarahisar,qrh hsar shrqy,Åarki Karahissar,Åebinkarahisar,Ð¨ÐÐÐÐÐÐÐ ÐÐ¥ÐÐ¡ÐÐ ,ÙØ±Ù Ø­ØµØ§Ø± Ø´Ø±ÙÛ,Åebinkarahisar", :latitude => "40.28833", :longitude => "38.42361").save
City.new(:country_id => "225", :name => "Sarikamis", :aliases => "SARYKAMYSH,Sarikamis,SarÄ±kamÄ±Å,Ð¡ÐÐ Ð«ÐÐÐÐ«Ð¨,SarÄ±kamÄ±Å", :latitude => "40.33806", :longitude => "42.57306").save
City.new(:country_id => "225", :name => "Sapanca", :aliases => "Mudanya,Sabanca,Sapanca,Sapanca", :latitude => "40.69141", :longitude => "30.26738").save
City.new(:country_id => "225", :name => "Samsun", :aliases => "Amisus,Djanik,Janik,SAMSUN,Sampsounta,Sams,Samsoun,Samsun,samusun,smswn,Î£Î±Î¼ÏÎ¿ÏÎ½ÏÎ±,Ð¡ÐÐÐ¡Ð£Ð,Ð¡Ð°Ð¼ÑÑÐ½,×¡××¡××,ãµã ã¹ã³,Samsun", :latitude => "41.28667", :longitude => "36.33").save
City.new(:country_id => "225", :name => "Safranbolu", :aliases => "Safranbolu,Zafranboli,sprnbwlw,Ð¡Ð°ÑÑÐ°Ð½Ð±Ð¾Ð»Ñ,×¡×¤×¨× ××××,Safranbolu", :latitude => "41.25083", :longitude => "32.69417").save
City.new(:country_id => "225", :name => "Rize", :aliases => "Bechirias,Corum,Provinsi Rize,RIZE,Rhizus,Rize,Rizeh,Rizenska provincie,RizenskÃ¡ provincie,rize,Ãorum,Ð ÐÐÐ,á ááá,Rize", :latitude => "41.02083", :longitude => "40.52194").save
City.new(:country_id => "225", :name => "Osmaneli", :aliases => "Lefke,Osmaneli,Osmaneli", :latitude => "40.35722", :longitude => "30.01417").save
City.new(:country_id => "225", :name => "Osmancik", :aliases => "Osmancik,OsmancÄ±k,Pimolisa,OsmancÄ±k", :latitude => "40.97139", :longitude => "34.79806").save
City.new(:country_id => "225", :name => "Orhangazi", :aliases => "Orhangazi,Pazarkoy,PazarkÃ¶y,Orhangazi", :latitude => "40.48917", :longitude => "29.30889").save
City.new(:country_id => "225", :name => "Ordu", :aliases => "Cotyora,ORDU,Ordu,ÐÐ ÐÐ£,Ordu", :latitude => "40.98472", :longitude => "37.87889").save
City.new(:country_id => "225", :name => "Oltu", :aliases => "OLTU,Olti,Oltu,Olty,ÐÐÐ¢Ð£,Oltu", :latitude => "40.54983", :longitude => "42.00126").save
City.new(:country_id => "225", :name => "Of", :aliases => "OF,Of,Off,Ophius,Solakli,SolaklÄ±,Sulakli,SulaklÄ±,ÐÐ¤,Of", :latitude => "40.94458", :longitude => "40.26746").save
City.new(:country_id => "225", :name => "Niksar", :aliases => "Cabeira,Diospolis,NIKSAR,Neocaesarea,Niksar,Sebaste,ÐÐÐÐ¡ÐÐ ,Niksar", :latitude => "40.59167", :longitude => "36.95167").save
City.new(:country_id => "225", :name => "Nallihan", :aliases => "Nallihan,NallÄ±han,NallÄ±han", :latitude => "40.18593", :longitude => "31.35179").save
City.new(:country_id => "225", :name => "Mudanya", :aliases => "Montagnae,Mudan'i,Mudania,Mudanya,Myrlea Apamea,ÐÑÐ´Ð°Ð½ÑÐ¸,Mudanya", :latitude => "40.37528", :longitude => "28.88222").save
City.new(:country_id => "225", :name => "Mimarsinan", :aliases => "Kalikratya,Mimarsinan,ÐÐ¸Ð¼Ð°ÑÑÐ¸Ð½Ð°Ð½,Mimarsinan", :latitude => "41.00315", :longitude => "28.53768").save
City.new(:country_id => "225", :name => "Merzifon", :aliases => "Marsivan,Merzifon,Phazemon,ÐÐµÑÐ·Ð¸ÑÐ¾Ð½,Merzifon", :latitude => "40.87333", :longitude => "35.46306").save
City.new(:country_id => "225", :name => "Maltepe", :aliases => ",Maltepe", :latitude => "40.93567", :longitude => "29.15507").save
City.new(:country_id => "225", :name => "Malkara", :aliases => "Malkara,Megalohora,Migalogora,ÐÐ°Ð»ÐºÐ°ÑÐ°,Malkara", :latitude => "40.89", :longitude => "26.90111").save
City.new(:country_id => "225", :name => "Luleburgaz", :aliases => "Arcadiopolis,Bergula,Ljuleburgas,Ljuleburgaz,Lueleburgaz,Lule Burgas,Luleburgaz,LÃ¼leburgaz,ÐÑÐ»ÐµÐ±ÑÑÐ³Ð°Ð·,ÐÑÐ»ÐµÐ±ÑÑÐ³Ð°Ñ,Luleburgaz", :latitude => "41.40385", :longitude => "27.35918").save
City.new(:country_id => "225", :name => "Kumru", :aliases => "KUMRU,Karacali,KaracalÄ±,Kumru,ÐÐ£ÐÐ Ð£,Kumru", :latitude => "40.87444", :longitude => "37.26389").save
City.new(:country_id => "225", :name => "Korgan", :aliases => "KORGAN,Korgan,ÐÐÐ ÐÐÐ,Korgan", :latitude => "40.82472", :longitude => "37.34667").save
City.new(:country_id => "225", :name => "Kocaali", :aliases => "Kocaali,Kocali,KocalÄ±,Yukari Kocaali,YukarÄ± Kocaali,Kocaali", :latitude => "41.05336", :longitude => "30.85278").save
City.new(:country_id => "225", :name => "Kizilcahamam", :aliases => "Kizicahamam,Kizilcahamam,KÄ±zÄ±cahamam,KÄ±zÄ±lcahamam,Yabanabat,KÄ±zÄ±lcahamam", :latitude => "40.46972", :longitude => "32.65056").save
City.new(:country_id => "225", :name => "Kirklareli", :aliases => "Kirk Kilise,Kirk Kilisse,Kirk-Kilissa,Kirklareli,KÄ±rklareli,Lozen,Lozengrad,Saranta Ekklesiai,Saranta EkklÄsiai,ÎÎ¹ÏÎºÎ»Î±ÏÎµÎ»Î¯,ÐÐ¾Ð·ÐµÐ½Ð³ÑÐ°Ð´,KÄ±rklareli", :latitude => "41.73508", :longitude => "27.22521").save
City.new(:country_id => "225", :name => "Kestel", :aliases => ",Kestel", :latitude => "40.19828", :longitude => "29.21237").save
City.new(:country_id => "225", :name => "Kesan", :aliases => "Kesan,Keshan,KeÅan,ÐÐµÑÐ°Ð½,KeÅan", :latitude => "40.85583", :longitude => "26.63028").save
City.new(:country_id => "225", :name => "Kelkit", :aliases => "Ciftlik,KEL'KIT,Kelkit,klkyt,Ãiftlik,ÐÐÐÐ¬ÐÐÐ¢,Ú©ÙÚ©ÛØª,Kelkit", :latitude => "40.12978", :longitude => "39.43607").save
City.new(:country_id => "225", :name => "Kazan", :aliases => ",Kazan", :latitude => "40.23167", :longitude => "32.68389").save
City.new(:country_id => "225", :name => "Kavakli", :aliases => "Fetekoy,FetekÃ¶y,Kavakli,Kavakly,KavaklÄ±,ÐÐ°Ð²Ð°ÐºÐ»Ñ,KavaklÄ±", :latitude => "41.09258", :longitude => "28.33172").save
City.new(:country_id => "225", :name => "Kastamonu", :aliases => "Castamon,Castamoni,Castamuni,Kastambul,Kastamonu,Kastamouni,Kastamuni,Kastamuniyah,Qastamuni,ÐÐ°ÑÑÐ°Ð¼Ð¾Ð½Ñ,Kastamonu", :latitude => "41.37805", :longitude => "33.77528").save
City.new(:country_id => "225", :name => "Kars", :aliases => "Cars,KARS,Kapc,Kars,Qars,Qers,Vanand,karusu,qars,ÐÐÐ Ð¡,ÐÐ°ÑÑ,ÙØ§Ø±Øµ,á§áá á¡á,ã«ã«ã¹,Kars", :latitude => "40.60199", :longitude => "43.09495").save
City.new(:country_id => "225", :name => "Karasu", :aliases => "Aksu,Karasu,ÐÐ°ÑÐ°ÑÑ,Karasu", :latitude => "41.07096", :longitude => "30.78543").save
City.new(:country_id => "225", :name => "Karamursel", :aliases => "Karamursel,Karamusal,KaramÃ¼rsel,KaramÃ¼rsel", :latitude => "40.69144", :longitude => "29.61568").save
City.new(:country_id => "225", :name => "Karacabey", :aliases => "Karacabey,Karadzhabej,Mihalic,MihaliÃ§,Miletopolis,Muhalich,ÐÐ°ÑÐ°Ð´Ð¶Ð°Ð±ÐµÐ¹,Karacabey", :latitude => "40.21525", :longitude => "28.40378").save
City.new(:country_id => "225", :name => "Karabuk", :aliases => "Karabuek,Karabuek Province,Karabuk,KarabÃ¼k,KarabÃ¼k Province,Provincia de Karabuek,Provincia de KarabÃ¼k,Provinsi Karabuek,Provinsi KarabÃ¼k,ka la bi ke sheng,å¡ææ¯åç,KarabÃ¼k", :latitude => "41.20488", :longitude => "32.62768").save
City.new(:country_id => "225", :name => "Kagizman", :aliases => "KAGYZMAN,Kagizman,KaÄÄ±zman,ÐÐÐÐ«ÐÐÐÐ,KaÄÄ±zman", :latitude => "40.15669", :longitude => "43.13424").save
City.new(:country_id => "225", :name => "Iznik", :aliases => "Isnik,Iznik,Nicaea,Nicea,Nicee,NicÃ©e,Nikaia,izuniku,nikaia,Ä°znik,ÐÐ·Ð½Ð¸Ðº,ã¤ãºãã¯,ãã«ã¤ã¢,Ä°znik", :latitude => "40.42861", :longitude => "29.72111").save
City.new(:country_id => "225", :name => "Izmit", :aliases => "Astacus,Cocaeli,Ismid,Ismit,Isnimid,Izmid,Izmit,Kocaeli,Kodja-Eli,Kodzhaehli,Koja-Ili,Nicomedia,Nikomedeia,izumitto,yi zi mi te,Ä°zmit,ÐÐ¾Ð´Ð¶Ð°ÑÐ»Ð¸,ã¤ãºããã,ä¼å¹å¯ç¹,Ä°zmit", :latitude => "40.76694", :longitude => "29.91694").save
City.new(:country_id => "225", :name => "Istanbul", :aliases => "Bizanc,BizÃ¡nc,Byzance,Byzantio,Byzantion,Byzantium,Byzanz,Constantinoble,Constantinopla,Constantinople,Constantinopoli,Constantinopolis,Costantinopoli,Estambul,Istamboul,Istambul,IstambuÅ,Istampoul,Istanbul,IstanbÃºl,Isztambul,Konstantinapoly,Konstantinopel,Konstantinopolo,Konstantinoupole,Konstantinoupoli,Konstantinoupolis,KonstantinÃ¡poly,Kustantiniyah,Micklagard,MicklagÃ¥rd,Mikligardur,MikligarÃ°ur,Stamboul,Stambul,StambuÅ,Tsarigrad,Vizantija,Vyzantio,bijantion,byuzantion,byzntywn,isutanburu,yi si tan bu er,Ä°stanbul,ÎÏÎ¶Î¬Î½ÏÎ¹Î¿,ÎÏÎ¶Î±Î½ÏÎ¹Î¿,ÎÏÏÎ±Î¼ÏÎ¿ÏÎ»,ÎÏÏÎ±Î¼ÏÎ¿ÏÎ»,ÎÏÎ½ÏÏÎ±Î½ÏÎ¹Î½Î¿ÏÏÎ¿Î»Î·,ÎÏÎ½ÏÏÎ±Î½ÏÎ¹Î½Î¿ÏÏÎ¿Î»Î·,ÐÐ¸Ð·Ð°Ð½ÑÐ¸ÑÐ°,ÐÑÑÐ°Ð½Ð±ÑÐ»,Ð¡ÑÐ°Ð¼Ð±ÑÐ»,×××× ××××,ã¤ã¹ã¿ã³ãã¼ã«,ãã¥ã¶ã³ãã£ãªã³,ä¼æ¯å¦å¸å°,ë¹ìí°ì¨,Ä°stanbul", :latitude => "41.01384", :longitude => "28.94966").save
City.new(:country_id => "225", :name => "Iskilip", :aliases => "Andrapa,Iskelib,Iskilip,Neapolis,Neoclaudiopolis,Ä°skilip,Ä°skilip", :latitude => "40.73528", :longitude => "34.47389").save
City.new(:country_id => "225", :name => "Inegeul", :aliases => "Inegeul,Inegoel,Inegol,Ä°negÃ¶l,Inegeul", :latitude => "40.07806", :longitude => "29.51333").save
City.new(:country_id => "225", :name => "Horasan", :aliases => "Horasan,KHORASAN,Ð¥ÐÐ ÐÐ¡ÐÐ,Horasan", :latitude => "40.04583", :longitude => "42.17278").save
City.new(:country_id => "225", :name => "Hopa", :aliases => "Apsarus,Hopa,KHOPA,Khoppa,Ð¥ÐÐÐ,Hopa", :latitude => "41.40597", :longitude => "41.43787").save
City.new(:country_id => "225", :name => "Hendek", :aliases => "Hendek,Khandak,Hendek", :latitude => "40.79944", :longitude => "30.74806").save
City.new(:country_id => "225", :name => "Hayrabolu", :aliases => "Hayrabolu,Hayrabolu", :latitude => "41.21311", :longitude => "27.10688").save
City.new(:country_id => "225", :name => "Havza", :aliases => "Havza,Khavza,Thermae Phazemonitarum,Ð¥Ð°Ð²Ð·Ð°,Havza", :latitude => "40.97056", :longitude => "35.66222").save
City.new(:country_id => "225", :name => "Gursu", :aliases => ",GÃ¼rsu", :latitude => "40.21876", :longitude => "29.19487").save
City.new(:country_id => "225", :name => "Gurpinar", :aliases => "Anarsa,AnarÅa,Gjurpynar,Gurpinar,GÃ¼rpÄ±nar,ÐÑÑÐ¿ÑÐ½Ð°Ñ,GÃ¼rpÄ±nar", :latitude => "40.99028", :longitude => "28.61528").save
City.new(:country_id => "225", :name => "Gurgentepe", :aliases => "Akmescit,Gurgentepe,GÃ¼rgentepe,GÃ¼rgentepe", :latitude => "40.78833", :longitude => "37.60167").save
City.new(:country_id => "225", :name => "Gumushkhane", :aliases => "GJUMJUSHANE,Guemueshane,Gumusane,Gumushane,Gumushkhane,GÃ¼mÃ¼Åane,GÃ¼mÃ¼Åhane,ÐÐ®ÐÐ®Ð¨ÐÐÐ,Gumushkhane", :latitude => "40.46028", :longitude => "39.48139").save
City.new(:country_id => "225", :name => "Gorele", :aliases => "Elehu,Elevi,GERELE,Goerele,Gorele,Gurele,GÃ¶rele,GÃ¼rele,Philocalia,ÐÐÐ ÐÐÐ,GÃ¶rele", :latitude => "41.03083", :longitude => "39.00306").save
City.new(:country_id => "225", :name => "Gonen", :aliases => "Gonan,Gonen,GÃ¶nan,GÃ¶nen,ÐÐ¾Ð½ÐµÐ½,GÃ¶nen", :latitude => "40.1049", :longitude => "27.65399").save
City.new(:country_id => "225", :name => "Geulzuk", :aliases => "Geulzuk,Golcuk,GÃ¶lcÃ¼k,Geulzuk", :latitude => "40.71667", :longitude => "29.82861").save
City.new(:country_id => "225", :name => "Giresun", :aliases => "Cerasus,Choerades,GIRESUN,Gireson,Giresun,Kerasounta,Kerassunde,Kerasunda,Kerasunt,Kiresun,Pharnacia,ÎÎµÏÎ±ÏÎ¿ÏÎ½ÏÎ±,ÐÐÐ ÐÐ¡Ð£Ð,Giresun", :latitude => "40.91698", :longitude => "38.38741").save
City.new(:country_id => "225", :name => "Geyve", :aliases => "Geiveh,Geyve,Tottaeum,kywh,Ú©ÛÙÙ,Geyve", :latitude => "40.5075", :longitude => "30.2925").save
City.new(:country_id => "225", :name => "Gerede", :aliases => "Crateia Flaviopolis,Gerede,Geredeh,ÐÐµÑÐµÐ´Ðµ,Gerede", :latitude => "40.80083", :longitude => "32.19694").save
City.new(:country_id => "225", :name => "Gemlik", :aliases => "Cius,Gemlik,Kios,Kiye,ÐÐµÐ¼Ð»Ð¸Ðº,Gemlik", :latitude => "40.43094", :longitude => "29.15969").save
City.new(:country_id => "225", :name => "Gelibolu", :aliases => "Callipolis,Gallipoli,Gelibolu,Guelibolou,GuÃ©libolou,Kallipolis,ÐÐµÐ»Ð¸Ð±Ð¾Ð»Ñ,Gelibolu", :latitude => "40.41028", :longitude => "26.67083").save
City.new(:country_id => "225", :name => "Gebze", :aliases => "Gebze,Guebze,kkbwzh,ÐÐµÐ±Ð·Ðµ,Ú©Ú©Ø¨ÙØ²Ù,Gebze", :latitude => "40.80276", :longitude => "29.43068").save
City.new(:country_id => "225", :name => "Ferizli", :aliases => "Ferizli,Ferizli", :latitude => "40.94082", :longitude => "30.48583").save
City.new(:country_id => "225", :name => "Fatsa", :aliases => "FATSA,Fatisa,Fatsa,Fatseh,Fatza,Phadisana,PhadÄ±sana,Polemonium,Side,Ð¤ÐÐ¢Ð¡Ð,Fatsa", :latitude => "41.02778", :longitude => "37.50139").save
City.new(:country_id => "225", :name => "Esenyurt", :aliases => "Eksinoz,EkÅinoz,Esenyurt,Eskiyuz,EskiyÃ¼z,Esenyurt", :latitude => "41.03333", :longitude => "28.67528").save
City.new(:country_id => "225", :name => "Esenler", :aliases => "Litros,Esenler", :latitude => "41.0435", :longitude => "28.87619").save
City.new(:country_id => "225", :name => "Eregli", :aliases => "Bender Erekli,Bender-Eregli,Bender-EreÄli,Ehregli,Eregli,Erekli,EreÄli,Ergeli,Heraclea Pontica,Heraklea,Karadenizereglisi,KaradenizereÄlisi,Ð­ÑÐµÐ³Ð»Ð¸,EreÄli", :latitude => "41.28262", :longitude => "31.41806").save
City.new(:country_id => "225", :name => "Erdek", :aliases => "Artace,Artaki,Erdek,Erdeku,ardk,Ø§Ø±Ø¯Ú©,Erdek", :latitude => "40.3996", :longitude => "27.79348").save
City.new(:country_id => "225", :name => "Erbaa", :aliases => "EHRBA,Erbaa,Herek,Ð­Ð ÐÐ,Erbaa", :latitude => "40.66889", :longitude => "36.5675").save
City.new(:country_id => "225", :name => "Edirne", :aliases => "Adrianopel,Adrianople,Adrianopol,Adrianopoli,Adrianopolis,Adrianoupolis,AdrianÃ²polis,Adrinople,Drinapoly,DrinÃ¡poly,Ederne,EdernÃ©,Edirne,Ehdirne,Hadrianople,Hadrianopolis,Odrin,adrnt,edirune,ÆdirnÉ,ÐÐ´ÑÐ¸Ð½,Ð­Ð´Ð¸ÑÐ½Ðµ,Ø£Ø¯Ø±ÙØ©,ã¨ãã£ã«ã,Edirne", :latitude => "41.67719", :longitude => "26.55597").save
City.new(:country_id => "225", :name => "Duzce", :aliases => "Dusje,Duzce,Duzdje,DÃ¼zce,DÃ¼zce", :latitude => "40.83889", :longitude => "31.16389").save
City.new(:country_id => "225", :name => "Devrek", :aliases => "Devrek,Hamidiye,Devrek", :latitude => "41.21917", :longitude => "31.95583").save
City.new(:country_id => "225", :name => "Cubuk", :aliases => ",Ãubuk", :latitude => "40.23861", :longitude => "33.03222").save
City.new(:country_id => "225", :name => "Corum", :aliases => "Chorum,Corum,Euchaita,Ãorum,Ð§Ð¾ÑÑÐ¼,Ãorum", :latitude => "40.54889", :longitude => "34.95333").save
City.new(:country_id => "225", :name => "Corlu", :aliases => "Chorlu,Corlu,Tzirallum,Tzurullum,Ãorlu,Ãorlu", :latitude => "41.15917", :longitude => "27.8").save
City.new(:country_id => "225", :name => "Cerkezkoy", :aliases => "Cerkeskoy,Cerkezkoey,Cerkezkoy,Hayrabolu,ÃerkeskÃ¶y,ÃerkezkÃ¶y,ÃerkezkÃ¶y", :latitude => "41.285", :longitude => "28.00028").save
City.new(:country_id => "225", :name => "Cerkes", :aliases => "Cerkes,Cherkes,Cherkesh,Mecidiye,ÃerkeÅ,ÃerkeÅ", :latitude => "40.81164", :longitude => "32.89358").save
City.new(:country_id => "225", :name => "Cayeli", :aliases => "Caybasi,Cayeli,Mapavri,MapavrÄ±,ÃaybaÅÄ±,Ãayeli,Ãayeli", :latitude => "41.09228", :longitude => "40.72924").save
City.new(:country_id => "225", :name => "Caycuma", :aliases => "Caycuma,Ãaycuma,Ãaycuma", :latitude => "41.42639", :longitude => "32.07556").save
City.new(:country_id => "225", :name => "Catalca", :aliases => "Catalca,Chataldja,Chatalja,Tchataldja,Tschataldja,Ãatalca,Ãatalca", :latitude => "41.14324", :longitude => "28.46154").save
City.new(:country_id => "225", :name => "Carsamba", :aliases => "CHARSHAMBA,Carsamba,Carsampa,Carsanba,Charshambah,Charshembe,Themiscyra,ÃarÅamba,ÃarÅanba,Ð§ÐÐ Ð¨ÐÐÐÐ,ÃarÅamba", :latitude => "41.19889", :longitude => "36.72194").save
City.new(:country_id => "225", :name => "Khanjarah", :aliases => "Cankiri,Changra,Changri,Chankiri,Chankyry,Gangra Germanicopolis,Ghanjarah,Kangiri,KangÄ±rÄ±,Khanjarah,knghry,ÃankÄ±rÄ±,Ð§Ð°Ð½ÐºÑÑÑ,Ú©ÙØºØ±Û,Khanjarah", :latitude => "40.59995", :longitude => "33.6153").save
City.new(:country_id => "225", :name => "Canakkale", :aliases => "Abydus,Canakkale,Chanak,Chanakkale,Chanaq,Dardanelles,Kale-Sultanie,Tsanakkale,qia na ka lai sheng,z'nqlh,Ãanakkale,Î¤ÏÎ±Î½Î¬ÎºÎºÎ±Î»Îµ,Ð§Ð°Ð½Ð°ÐºÐºÐ°Ð»Ðµ,×¦'× ×§××,æ°çº³å¡è±ç,Ãanakkale", :latitude => "40.14556", :longitude => "26.40639").save
City.new(:country_id => "225", :name => "Can", :aliases => "Can,Pazarkoy,Ãan,Ãan", :latitude => "40.03328", :longitude => "27.05236").save
City.new(:country_id => "225", :name => "Bursa", :aliases => "Boursa,Brossa,Broussa,Brousse,Brusa,Brussa,Bursa,Prousa,bu er sa,burusa,bwrsh,bwrst,Î ÏÎ¿ÏÏÎ±,ÐÑÑÑÐ°,×××¨×¡×,Ø¨ÙØ±ØµØ©,ãã«ãµ,å¸å°è¨,Bursa", :latitude => "40.19167", :longitude => "29.06111").save
City.new(:country_id => "225", :name => "Bulancak", :aliases => "Akkoy,AkkÃ¶y,BULANDZHAK,Bulancak,Bulancik,Pulandjak,ÐÐ£ÐÐÐÐÐÐÐ,Bulancak", :latitude => "40.93717", :longitude => "38.22907").save
City.new(:country_id => "225", :name => "Boyabat", :aliases => "Boyabat,Boyabat", :latitude => "41.46889", :longitude => "34.76667").save
City.new(:country_id => "225", :name => "Bolu", :aliases => "Boli,Bolu,Claudiopolis,ÐÐ¾Ð»Ñ,Bolu", :latitude => "40.73583", :longitude => "31.60611").save
City.new(:country_id => "225", :name => "Bilecik", :aliases => "Agrilium,Belocome,Bilecik,Biledzhik,Bilejik,ÐÐ¸Ð»ÐµÐ´Ð¶Ð¸Ðº,Bilecik", :latitude => "40.14192", :longitude => "29.97932").save
City.new(:country_id => "225", :name => "Biga", :aliases => "Big,Biga,ÐÐ¸Ð³,Biga", :latitude => "40.22806", :longitude => "27.24222").save
City.new(:country_id => "225", :name => "Beypazari", :aliases => "Baibazar,Beypazari,BeypazarÄ±,Petobriga,BeypazarÄ±", :latitude => "40.1675", :longitude => "31.92111").save
City.new(:country_id => "225", :name => "Besikduzu", :aliases => "Besikduzu,BeÅikdÃ¼zÃ¼,Sarli,ÅarlÄ±,BeÅikdÃ¼zÃ¼", :latitude => "41.05199", :longitude => "39.22844").save
City.new(:country_id => "225", :name => "Bayburt", :aliases => "BAJBURT,Baberd,Baiburt,Bayburt,Bayburt Province,Bayburtiaen,BayburtiÃ¤n,Bayburtska provincie,BayburtskÃ¡ provincie,Provincia de Bayburt,Provinsi Bayburt,ba yi bu er te sheng,baybwrt,ÐÐÐÐÐ£Ð Ð¢,Ô²Õ¡Õ¢Õ¥ÖÕ¤,Ø¨Ø§ÛØ¨ÙØ±Øª,å·´ä¼å¸å°ç¹ç,Bayburt", :latitude => "40.25889", :longitude => "40.22778").save
City.new(:country_id => "225", :name => "Bartin", :aliases => "Bartan,Bartheni,Bartin,BartÄ±n,Parthenium,ÐÐ°ÑÑÐ¸Ð½,BartÄ±n", :latitude => "41.63583", :longitude => "32.3375").save
City.new(:country_id => "225", :name => "Bandirma", :aliases => "Banderma,Bandirma,Bandyrma,BandÄ±rma,Panderma,Panormos,Panormus,ÐÐ°Ð½Ð´ÑÑÐ¼Ð°,BandÄ±rma", :latitude => "40.35222", :longitude => "27.97667").save
City.new(:country_id => "225", :name => "Bagcilar", :aliases => "Bagcilar,BaÄcÄ±lar,Cifitburgaz,Ciftburgaz,Ãiftburgaz,ÃÄ±fÄ±tburgaz,BaÄcÄ±lar", :latitude => "41.03903", :longitude => "28.85671").save
City.new(:country_id => "225", :name => "Bafra", :aliases => "Bafra,Paura,ÐÐ°ÑÑÐ°,Bafra", :latitude => "41.56778", :longitude => "35.90694").save
City.new(:country_id => "225", :name => "Babaeski", :aliases => "Babaatik,Babaeski,Babaiatik,Babaeski", :latitude => "41.4325", :longitude => "27.09306").save
City.new(:country_id => "225", :name => "Artvin", :aliases => "ARTVIN,Artivin,Artvin,Artwin,ÐÐ Ð¢ÐÐÐ,Artvin", :latitude => "41.18222", :longitude => "41.81944").save
City.new(:country_id => "225", :name => "Arsin", :aliases => "Arseni Zir,Arsin,Asagi Arsin,AÅaÄÄ± Arsin,Arsin", :latitude => "40.94958", :longitude => "39.92756").save
City.new(:country_id => "225", :name => "Arhavi", :aliases => "Arhavi,Musazade,ÐÑÑÐ°Ð·Ð°Ð´Ðµ,Arhavi", :latitude => "41.34917", :longitude => "41.30694").save
City.new(:country_id => "225", :name => "Ardesen", :aliases => "ARDESHEN,Ardasen,ArdaÅen,Ardesen,ArdeÅen,Ardisin,ArdiÅin,ÐÐ ÐÐÐ¨ÐÐ,ArdeÅen", :latitude => "41.19111", :longitude => "40.9875").save
City.new(:country_id => "225", :name => "Ardahan", :aliases => "ARDAGAN,Ardagan,Ardahan,Ardakhan,Erdexan,ErdÃªxan,ÐÐ ÐÐÐÐÐ,Ô±ÖÕ¤Õ¡Õ°Õ¡Õ¶,××¨××××,Ardahan", :latitude => "41.10871", :longitude => "42.70222").save
City.new(:country_id => "225", :name => "Arakli", :aliases => "Arakli,Arakli Carsusu,Araklicarsisi,AraklÄ±,AraklÄ± ÃarÅusu,AraklÄ±Ã§arÅÄ±sÄ±,Iraklia,Surmene,SÃ¼rmene,AraklÄ±", :latitude => "40.93854", :longitude => "40.05842").save
City.new(:country_id => "225", :name => "Amasya", :aliases => "Amas'ja,Amaseia,Amasia,Amasiyah,Amasya,AmÃ sia,a ma xi ya,ÎÎ¼Î¬ÏÎµÎ¹Î±,ÐÐ¼Ð°ÑÑÑ,×××¡××,é¿é¦¬è¥¿äº,Amasya", :latitude => "40.65333", :longitude => "35.83306").save
City.new(:country_id => "225", :name => "Alapli", :aliases => "Alapli,AlaplÄ±,Yukaridogancilar,Yukaridogncilar,YukarÄ±doÄancÄ±lar,YukarÄ±doÄncÄ±lar,AlaplÄ±", :latitude => "41.1694", :longitude => "31.37917").save
City.new(:country_id => "225", :name => "Alaca", :aliases => "Alaca,Huseyinabat,Huseyinbat,Huseynabat,HÃ¼seyinabat,HÃ¼seyinbat,HÃ¼seynabat,Alaca", :latitude => "40.16833", :longitude => "34.8425").save
City.new(:country_id => "225", :name => "Akyazi", :aliases => "Akyaz,Akyazi,AkyazÄ±,AkyazÄ±", :latitude => "40.685", :longitude => "30.62222").save
City.new(:country_id => "225", :name => "Akcakoca", :aliases => "Akcakoca,Akcasehir,Akche Shehr,Akcheh,AkÃ§akoca,AkÃ§aÅehir,Dia,Diospolis,AkÃ§akoca", :latitude => "41.08288", :longitude => "31.11274").save
City.new(:country_id => "225", :name => "Akcaabat", :aliases => "AKCHAABAD,Akcaabat,AkÃ§aabat,Hermonassus,Hermyse,Platana,Polatane,Polathane,Pulathane,ÐÐÐ§ÐÐÐÐÐ,AkÃ§aabat", :latitude => "41.0212", :longitude => "39.57146").save
City.new(:country_id => "225", :name => "Adapazari", :aliases => "Ada Bazar,Adapazari,AdapazarÄ±,Sakar'ja,Ð¡Ð°ÐºÐ°ÑÑÑ,AdapazarÄ±", :latitude => "40.78056", :longitude => "30.40333").save
City.new(:country_id => "225", :name => "Espiye", :aliases => ",Espiye", :latitude => "40.94794", :longitude => "38.71148").save
City.new(:country_id => "225", :name => "merter keresteciler", :aliases => ",merter keresteciler", :latitude => "41.01295", :longitude => "28.88593").save
City.new(:country_id => "225", :name => "guengoeren merter", :aliases => "Merter,gÃ¼ngÃ¶ren merter", :latitude => "41.00711", :longitude => "28.88795").save
City.new(:country_id => "225", :name => "Sarigerme", :aliases => "Sarigerme,Ð¡Ð°ÑÐ¸Ð³ÐµÑÐ¼Ðµ,Sarigerme", :latitude => "36.71549", :longitude => "28.70436").save
City.new(:country_id => "225", :name => "Atasehir", :aliases => ",AtaÅehir", :latitude => "40.9833", :longitude => "29.1167").save
City.new(:country_id => "225", :name => "Basaksehir", :aliases => ",BaÅakÅehir", :latitude => "41.09307", :longitude => "28.80203").save
City.new(:country_id => "225", :name => "Beylikduezue", :aliases => ",BeylikdÃ¼zÃ¼", :latitude => "40.982", :longitude => "28.6399").save
City.new(:country_id => "225", :name => "Bueyuekcekmece", :aliases => ",BÃ¼yÃ¼kÃ§ekmece", :latitude => "41.02072", :longitude => "28.58502").save
City.new(:country_id => "225", :name => "Cankaya", :aliases => ",Ãankaya", :latitude => "39.9179", :longitude => "32.86268").save
City.new(:country_id => "225", :name => "Bahcelievler", :aliases => ",BahÃ§elievler", :latitude => "41.00231", :longitude => "28.8598").save
City.new(:country_id => "225", :name => "Sultangazi", :aliases => ",Sultangazi", :latitude => "41.10652", :longitude => "28.86847").save
City.new(:country_id => "225", :name => "Sultanbeyli", :aliases => ",Sultanbeyli", :latitude => "40.96072", :longitude => "29.27067").save
City.new(:country_id => "225", :name => "Sancaktepe", :aliases => ",Sancaktepe", :latitude => "41.00244", :longitude => "29.23187").save
City.new(:country_id => "225", :name => "Karabaglar", :aliases => ",KarabaÄlar", :latitude => "38.37396", :longitude => "27.1352").save
