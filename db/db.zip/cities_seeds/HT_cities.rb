City.new(:country_id => "101", :name => "Verrettes", :aliases => "Les Verettes,Les Verrettes,Verrettes", :latitude => "19.05", :longitude => "-72.46667").save
City.new(:country_id => "101", :name => "Thomazeau", :aliases => ",Thomazeau", :latitude => "18.65194", :longitude => "-72.09472").save
City.new(:country_id => "101", :name => "Saint-Raphael", :aliases => ",Saint-RaphaÃ«l", :latitude => "19.43333", :longitude => "-72.2").save
City.new(:country_id => "101", :name => "Saint-Marc", :aliases => "Saint-Marc,Sen-Mark,Ð¡ÐµÐ½-ÐÐ°ÑÐº,Saint-Marc", :latitude => "19.10819", :longitude => "-72.69379").save
City.new(:country_id => "101", :name => "Port-au-Prince", :aliases => "Port o Prens,Port o Prensas,Port-au-Prince,Port-o-Prens,Porto Prens,Portofprensa,Potoprens,Puerto Principe,Puerto PrÃ­ncipe,PÃ²toprens,Ville de Port-au-Prince,poleutopeulaengseu,porutopuransu,pwrt aw prns,tai zi gang,Î Î¿ÏÏ-Î¿-Î ÏÎµÎ½Ï,ÐÐ¾ÑÑ Ð¾ ÐÑÐµÐ½Ñ,ÐÐ¾ÑÑ-Ð¾-ÐÑÐµÐ½Ñ,ÐÐ¾ÑÑÐ¾ ÐÑÐµÐ½Ñ,×¤××¨× ×× ×¤×¨×× ×¡,×¤××¨×-××-×¤×¨× ×¡,Ù¾ÙØ±Øª Ø§Ù Ù¾Ø±ÙØ³,ááá á¢-á-áá ááá¡á,áá­á¶ááªááµ,ãã«ãã¼ãã©ã³ã¹,å¤ªå­æ¸¯,í¬ë¥´í íë­ì¤,Port-au-Prince", :latitude => "18.53917", :longitude => "-72.335").save
City.new(:country_id => "101", :name => "Petit Goave", :aliases => "Petit Goave,Petit GoÃ¢ve,Ville de Petit Goave,Ville de Petit GoÃ¢ve,Petit GoÃ¢ve", :latitude => "18.43139", :longitude => "-72.86694").save
City.new(:country_id => "101", :name => "Petionville", :aliases => "Petionville,PÃ©tionville,Ville de Petion-Ville,Ville de PÃ©tion-Ville,PÃ©tionville", :latitude => "18.5125", :longitude => "-72.28528").save
City.new(:country_id => "101", :name => "Miragoane", :aliases => ",MiragoÃ¢ne", :latitude => "18.44232", :longitude => "-73.08758").save
City.new(:country_id => "101", :name => "Limbe", :aliases => "Le Limbe,Limbe,LimbÃ©,Ville de Limbe,Ville de LimbÃ©,ÐÐ¸Ð¼Ð±Ðµ,LimbÃ©", :latitude => "19.7", :longitude => "-72.4").save
City.new(:country_id => "101", :name => "Leogane", :aliases => "Leogane,LÃ©ogÃ¢ne,Ville de Leogane,Ville de LÃ©ogane,Yaguana,LÃ©ogÃ¢ne", :latitude => "18.51083", :longitude => "-72.63389").save
City.new(:country_id => "101", :name => "Kenscoff", :aliases => "Kenscoff,Kenskoff,Kenscoff", :latitude => "18.45056", :longitude => "-72.28694").save
City.new(:country_id => "101", :name => "Jeremie", :aliases => "Zheremi,ÐÐµÑÐµÐ¼Ð¸,JÃ©rÃ©mie", :latitude => "18.65", :longitude => "-74.11667").save
City.new(:country_id => "101", :name => "Jacmel", :aliases => "Jacmel,Jakmel,JakmÃ¨l,Zhakmele,ÐÐ°ÐºÐ¼ÐµÐ»Ðµ,×'××§××,Jacmel", :latitude => "18.23417", :longitude => "-72.53472").save
City.new(:country_id => "101", :name => "Hinche", :aliases => "Hinche,Hinche", :latitude => "19.15", :longitude => "-72.01667").save
City.new(:country_id => "101", :name => "Gressier", :aliases => ",Gressier", :latitude => "18.55", :longitude => "-72.51667").save
City.new(:country_id => "101", :name => "Grand Goave", :aliases => "Grand Goave,Grand GoÃ¢ve,Grande Goave,Grand GoÃ¢ve", :latitude => "18.42889", :longitude => "-72.77056").save
City.new(:country_id => "101", :name => "Gonaives", :aliases => "Gonaiv,Gonaives,GonaÃ¯ves,Les Gonaives,Les GonaÃ¯ves,Ville des Gonaives,ÐÐ¾Ð½Ð°Ð¸Ð²,GonaÃ¯ves", :latitude => "19.45", :longitude => "-72.68333").save
City.new(:country_id => "101", :name => "Fond Parisien", :aliases => ",Fond Parisien", :latitude => "18.50583", :longitude => "-71.97667").save
City.new(:country_id => "101", :name => "Desarmes", :aliases => ",DÃ©sarmes", :latitude => "18.99167", :longitude => "-72.38889").save
City.new(:country_id => "101", :name => "Delmas 73", :aliases => ",Delmas 73", :latitude => "18.54472", :longitude => "-72.30278").save
City.new(:country_id => "101", :name => "Croix des Bouquets", :aliases => ",Croix des Bouquets", :latitude => "18.575", :longitude => "-72.225").save
City.new(:country_id => "101", :name => "Les Cayes", :aliases => "Aux Cayes,Cayes,Les Cayes,Ville des Cayes,Les Cayes", :latitude => "18.2", :longitude => "-73.75").save
City.new(:country_id => "101", :name => "Carrefour", :aliases => ",Carrefour", :latitude => "18.54114", :longitude => "-72.39922").save
City.new(:country_id => "101", :name => "Cap-Haitien", :aliases => "Cap Haitien,Cap-Francais,Cap-FranÃ§ais,Cap-Haitien,Cap-HaÃ¯tien,Cape Haitien,Cape Haytien,Guarico,GuÃ¡rico,Kap Ayisyen,Kap-Ait'ene,Le Cap,Ville du Cap-Haitien,ÐÐ°Ð¿-ÐÐ¸ÑÑÐµÐ½Ðµ,Cap-HaÃ¯tien", :latitude => "19.75778", :longitude => "-72.20417").save
City.new(:country_id => "101", :name => "Ti Port-de-Paix", :aliases => ",Ti Port-de-Paix", :latitude => "19.93333", :longitude => "-72.83333").save
