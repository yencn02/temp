City.new(:country_id => "93", :name => "Zacapa", :aliases => "Sakapa,Zacapa,Ð¡Ð°ÐºÐ°Ð¿Ð°,Zacapa", :latitude => "14.96667", :longitude => "-89.53333").save
City.new(:country_id => "93", :name => "Villa Nueva", :aliases => "Vil'ja-Nuehva,Villa Nueva,ÐÐ¸Ð»ÑÑ-ÐÑÑÐ²Ð°,Villa Nueva", :latitude => "14.52694", :longitude => "-90.5875").save
City.new(:country_id => "93", :name => "Villa Canales", :aliases => "Villa Anales,Villa Canales,Villa Canales", :latitude => "14.48139", :longitude => "-90.53167").save
City.new(:country_id => "93", :name => "Totonicapan", :aliases => "Totonicapan,TotonicapÃ¡n,Totonikapan,Ð¢Ð¾ÑÐ¾Ð½Ð¸ÐºÐ°Ð¿Ð°Ð½,TotonicapÃ¡n", :latitude => "14.91667", :longitude => "-91.36667").save
City.new(:country_id => "93", :name => "Tecpan Guatemala", :aliases => "Tecpam,Tecpan,Tecpan Guatemala,TecpÃ¡n,TecpÃ¡n Guatemala,TecpÃ¡n Guatemala", :latitude => "14.76694", :longitude => "-90.99417").save
City.new(:country_id => "93", :name => "Sumpango", :aliases => "Sumpango,Sumpango", :latitude => "14.64639", :longitude => "-90.73389").save
City.new(:country_id => "93", :name => "Solola", :aliases => "Solola,SololÃ¡,Ð¡Ð¾Ð»Ð¾Ð»Ð°,SololÃ¡", :latitude => "14.76667", :longitude => "-91.18333").save
City.new(:country_id => "93", :name => "Santiago Sacatepequez", :aliases => "Santiago,Santiago Sacatepequez,Santiago SacatepÃ©quez,Santiago SacatepÃ©quez", :latitude => "14.63528", :longitude => "-90.67639").save
City.new(:country_id => "93", :name => "Santiago Atitlan", :aliases => "Atitlan,AtitlÃ¡n,Santiago,Santiago AtitlÃ¡n", :latitude => "14.63823", :longitude => "-91.22901").save
City.new(:country_id => "93", :name => "Santa Maria de Jesus", :aliases => "Santa Maria,Santa Maria de Jesus,Santa MarÃ­a,Santa MarÃ­a de JesÃºs,Santa MarÃ­a de JesÃºs", :latitude => "14.51833", :longitude => "-90.72667").save
City.new(:country_id => "93", :name => "Santa Lucia Cotzumalguapa", :aliases => "Santa Lucia,Santa Lucia Cotzumalguapa,Santa LucÃ­a,Santa LucÃ­a Cotzumalguapa,Santa LucÃ­a Cotzumalguapa", :latitude => "14.33333", :longitude => "-91.01667").save
City.new(:country_id => "93", :name => "Santa Cruz del Quiche", :aliases => "Santa Cruz del Quiche,Santa Cruz del QuichÃ©,Santa-Krus-del'-Kiche,Ð¡Ð°Ð½ÑÐ°-ÐÑÑÑ-Ð´ÐµÐ»Ñ-ÐÐ¸ÑÐµ,Santa Cruz del QuichÃ©", :latitude => "15.03056", :longitude => "-91.14889").save
City.new(:country_id => "93", :name => "Santa Catarina Pinula", :aliases => "Santa Catarina Pinula,Santa Catarina Pinula", :latitude => "14.56889", :longitude => "-90.49528").save
City.new(:country_id => "93", :name => "San Pedro Sacatepequez", :aliases => "San Pedra,San Pedro,San Pedro Sacatepequez,San Pedro SacatepÃ©quez,San Pedro SacatepÃ©quez", :latitude => "14.96667", :longitude => "-91.76667").save
City.new(:country_id => "93", :name => "San Pedro Ayampuc", :aliases => ",San Pedro Ayampuc", :latitude => "14.78667", :longitude => "-90.45111").save
City.new(:country_id => "93", :name => "San Pablo Jocopilas", :aliases => "San Pablo,San Pablo Jocopilas,San Pablo Jocopilas", :latitude => "14.58333", :longitude => "-91.45").save
City.new(:country_id => "93", :name => "San Marcos", :aliases => "La Union,San Marcos,San Marcos La Union,San Marcos", :latitude => "14.96667", :longitude => "-91.8").save
City.new(:country_id => "93", :name => "San Lucas Sacatepequez", :aliases => "San Lucas,San Lucas Sacatepequez,San Lucas SacatepÃ©quez,San Lucas SacatepÃ©quez", :latitude => "14.60972", :longitude => "-90.65694").save
City.new(:country_id => "93", :name => "San Juan Sacatepequez", :aliases => ",San Juan SacatepÃ©quez", :latitude => "14.71889", :longitude => "-90.64417").save
City.new(:country_id => "93", :name => "San Jose Pinula", :aliases => ",San JosÃ© Pinula", :latitude => "14.54611", :longitude => "-90.41139").save
City.new(:country_id => "93", :name => "San Francisco El Alto", :aliases => "San Francisco,San Francisco El Alto,San Francisco El Alto", :latitude => "14.95", :longitude => "-91.45").save
City.new(:country_id => "93", :name => "San Cristobal Verapaz", :aliases => "San Cristobal,San Cristobal Verapaz,San CristÃ³bal,San CristÃ³bal Verapaz,San CristÃ³bal Verapaz", :latitude => "15.38333", :longitude => "-90.4").save
City.new(:country_id => "93", :name => "San Benito", :aliases => ",San Benito", :latitude => "16.91667", :longitude => "-89.9").save
City.new(:country_id => "93", :name => "Sanarate", :aliases => ",Sanarate", :latitude => "14.795", :longitude => "-90.19222").save
City.new(:country_id => "93", :name => "San Andres Itzapa", :aliases => "Itzapa,San Andres Itzapa,San AndrÃ©s Itzapa,San AndrÃ©s Itzapa", :latitude => "14.62", :longitude => "-90.84417").save
City.new(:country_id => "93", :name => "Retalhuleu", :aliases => "Retalhuleo,Retalhuleu,Retalhuley,Retaluleu,Ð ÐµÑÐ°Ð»ÑÐ»ÐµÑ,Retalhuleu", :latitude => "14.53333", :longitude => "-91.68333").save
City.new(:country_id => "93", :name => "Quetzaltenango", :aliases => "Kecaltenangas,Kesal'tenango,Quetzaltenango,Quexaltenango,Quezaltenango,ketsu~arutenango,ÐÐµÑÐ°Ð»ÑÑÐµÐ½Ð°Ð½Ð³Ð¾,ã±ãã¡ã«ããã³ã´,Quetzaltenango", :latitude => "14.83333", :longitude => "-91.51667").save
City.new(:country_id => "93", :name => "Puerto San Jose", :aliases => "Puerto San Jose,Puerto San JosÃ©,Puerto de San Jose,Puerto de San JosÃ©,San Jose,San Jose de Guatemala,San JosÃ©,San JosÃ© de Guatemala,Puerto San JosÃ©", :latitude => "13.92556", :longitude => "-90.82444").save
City.new(:country_id => "93", :name => "Puerto Barrios", :aliases => "Puehrto-Barrios,Puerto Barrios,ÐÑÑÑÑÐ¾-ÐÐ°ÑÑÐ¸Ð¾Ñ,Puerto Barrios", :latitude => "15.71667", :longitude => "-88.6").save
City.new(:country_id => "93", :name => "Pueblo Nuevo Tiquisate", :aliases => "Pueblo Nuevo,Pueblo Nuevo Tiquisate,Tequisate,Tiquisate,Tiquizate,Pueblo Nuevo Tiquisate", :latitude => "14.28333", :longitude => "-91.36667").save
City.new(:country_id => "93", :name => "Poptun", :aliases => "Poctum,Poctun,PoctÃºn,Poptun,PoptÃºn,Santa Barbara,Santa BÃ¡rbara,PoptÃºn", :latitude => "16.33111", :longitude => "-89.41694").save
City.new(:country_id => "93", :name => "Petapa", :aliases => "Petapa,San Miguel Petapa,Petapa", :latitude => "14.50278", :longitude => "-90.55167").save
City.new(:country_id => "93", :name => "Patzun", :aliases => "Patzun,PatzÃºn,PatzÃºn", :latitude => "14.68333", :longitude => "-91.01667").save
City.new(:country_id => "93", :name => "Patzicia", :aliases => ",PatzicÃ­a", :latitude => "14.63167", :longitude => "-90.92694").save
City.new(:country_id => "93", :name => "Panzos", :aliases => "Panzos,PanzÃ³s,PanzÃ³s", :latitude => "15.4", :longitude => "-89.66667").save
City.new(:country_id => "93", :name => "Palin", :aliases => ",PalÃ­n", :latitude => "14.40556", :longitude => "-90.69833").save
City.new(:country_id => "93", :name => "Palencia", :aliases => ",Palencia", :latitude => "14.66472", :longitude => "-90.35861").save
City.new(:country_id => "93", :name => "Ostuncalco", :aliases => "Ostuncalco,San Juan Ostuncalco,Ostuncalco", :latitude => "14.86667", :longitude => "-91.61667").save
City.new(:country_id => "93", :name => "Nuevo San Carlos", :aliases => ",Nuevo San Carlos", :latitude => "14.6", :longitude => "-91.7").save
City.new(:country_id => "93", :name => "Nebaj", :aliases => ",Nebaj", :latitude => "15.40583", :longitude => "-91.14611").save
City.new(:country_id => "93", :name => "Nahuala", :aliases => "Nahuala,NahualÃ¡,NahualÃ¡", :latitude => "14.85", :longitude => "-91.31667").save
City.new(:country_id => "93", :name => "Morales", :aliases => ",Morales", :latitude => "15.48333", :longitude => "-88.81667").save
City.new(:country_id => "93", :name => "Momostenango", :aliases => ",Momostenango", :latitude => "15.04361", :longitude => "-91.40861").save
City.new(:country_id => "93", :name => "Mixco", :aliases => "Mishko,Mixco,ÐÐ¸ÑÐºÐ¾,Mixco", :latitude => "14.63333", :longitude => "-90.60639").save
City.new(:country_id => "93", :name => "Mazatenango", :aliases => "Masatenango,Mazatenango,ÐÐ°ÑÐ°ÑÐµÐ½Ð°Ð½Ð³Ð¾,Mazatenango", :latitude => "14.53333", :longitude => "-91.5").save
City.new(:country_id => "93", :name => "La Gomera", :aliases => ",La Gomera", :latitude => "14.08333", :longitude => "-91.05").save
City.new(:country_id => "93", :name => "La Esperanza", :aliases => "Esperanza,La Esperanza,La Esperanza", :latitude => "14.86667", :longitude => "-91.56667").save
City.new(:country_id => "93", :name => "Jutiapa", :aliases => "Juliapa,Jutiapa,Khutiapa,Ð¥ÑÑÐ¸Ð°Ð¿Ð°,Jutiapa", :latitude => "14.28333", :longitude => "-89.9").save
City.new(:country_id => "93", :name => "Jocotenango", :aliases => "Jocotenango,Jocotenango", :latitude => "14.58194", :longitude => "-90.74361").save
City.new(:country_id => "93", :name => "Jalapa", :aliases => "Jalapa,Khalapa,Ð¥Ð°Ð»Ð°Ð¿Ð°,Jalapa", :latitude => "14.63333", :longitude => "-89.98333").save
City.new(:country_id => "93", :name => "Jacaltenango", :aliases => "Jacaltenango,Khakal'tenango,Ð¥Ð°ÐºÐ°Ð»ÑÑÐµÐ½Ð°Ð½Ð³Ð¾,Jacaltenango", :latitude => "15.66667", :longitude => "-91.73333").save
City.new(:country_id => "93", :name => "Huehuetenango", :aliases => ",Huehuetenango", :latitude => "15.31972", :longitude => "-91.47083").save
City.new(:country_id => "93", :name => "Gualan", :aliases => "Guala,Gualan,GualÃ¡n,GualÃ¡n", :latitude => "15.13333", :longitude => "-89.36667").save
City.new(:country_id => "93", :name => "Fraijanes", :aliases => ",Fraijanes", :latitude => "14.46528", :longitude => "-90.44083").save
City.new(:country_id => "93", :name => "Flores", :aliases => "Flores,Flores Peten,Flores PetÃ©n,Ð¤Ð»Ð¾ÑÐµÑ,Flores", :latitude => "16.93333", :longitude => "-89.88333").save
City.new(:country_id => "93", :name => "Esquipulas", :aliases => ",Esquipulas", :latitude => "14.56667", :longitude => "-89.35").save
City.new(:country_id => "93", :name => "Escuintla", :aliases => "Ehskuintla,Escuintla,Esquintla,esuku~intora,Ð­ÑÐºÑÐ¸Ð½ÑÐ»Ð°,ã¨ã¹ã¯ã£ã³ãã©,Escuintla", :latitude => "14.305", :longitude => "-90.785").save
City.new(:country_id => "93", :name => "El Tejar", :aliases => "El Tejar,Tejar,El Tejar", :latitude => "14.64778", :longitude => "-90.79278").save
City.new(:country_id => "93", :name => "El Palmar", :aliases => "El Palmar,Palmar,El Palmar", :latitude => "14.65", :longitude => "-91.58333").save
City.new(:country_id => "93", :name => "El Estor", :aliases => "El Estor,El Estor", :latitude => "15.53333", :longitude => "-89.35").save
City.new(:country_id => "93", :name => "Cuilapa", :aliases => "Cuajiniquilapa,Cuilapa,Cuilapa", :latitude => "14.27639", :longitude => "-90.30028").save
City.new(:country_id => "93", :name => "Comitancillo", :aliases => "Comitacillo,Comitancillo,Comitancillo", :latitude => "15.08333", :longitude => "-91.71667").save
City.new(:country_id => "93", :name => "Comalapa", :aliases => ",Comalapa", :latitude => "14.74111", :longitude => "-90.8875").save
City.new(:country_id => "93", :name => "Colomba", :aliases => ",Colomba", :latitude => "14.71667", :longitude => "-91.73333").save
City.new(:country_id => "93", :name => "Coban", :aliases => "Coban,CobÃ¡n,CobÃ¡n", :latitude => "15.48333", :longitude => "-90.36667").save
City.new(:country_id => "93", :name => "Coatepeque", :aliases => ",Coatepeque", :latitude => "14.7", :longitude => "-91.86667").save
City.new(:country_id => "93", :name => "Ciudad Vieja", :aliases => ",Ciudad Vieja", :latitude => "14.52639", :longitude => "-90.75972").save
City.new(:country_id => "93", :name => "Guatemala City", :aliases => "Cidade da Guatemala,Citta del Guatemala,CittÃ  del Guatemala,Ciudad Guatemala,Ciudad de Guatemala,Ciutat de Guatemala,Guate,Guatemala,Guatemala City,Guatemala Hiria,Guatemala by,Guatemala la Nueva,Guatemala-Stadt,Guatemala-Urbo,Guatemala-stad,Gvatemala,Gvatemalurbo,Gwatemala,New Guatemala,Nueva Guatemala,Nueva Guatemala de la Asuncion,Nueva Guatemala de la AsunciÃ³n,Pole tes Gouatemalas,Santiago de Guatimala,Santiago de los Caballeros de Guatemala la Nueva,gua de ma la shi,guatemarashiti,gwatemalla si,kawtemalasiti,mdynt ghwatymala,shhr gwatmala,Î ÏÎ»Î· ÏÎ·Ï ÎÎ¿ÏÎ±ÏÎµÎ¼Î¬Î»Î±Ï,ÐÐ²Ð°ÑÐµÐ¼Ð°Ð»Ð°,××××××× ×¡×××,×××××××× ×¡×××,Ø´ÙØ± Ú¯ÙØ§ØªÙØ§ÙØ§,ÙØ¯ÙÙØ© ØºÙØ§ØªÙÙØ§ÙØ§,à¸à¸±à¸§à¹à¸à¸¡à¸²à¸¥à¸²à¸à¸´à¸à¸µ,ã°ã¢ããã©ã·ãã£,çå°é¦¬æå¸,ê³¼íë§ë¼ ì,Guatemala City", :latitude => "14.64072", :longitude => "-90.51327").save
City.new(:country_id => "93", :name => "Chisec", :aliases => ",Chisec", :latitude => "15.81667", :longitude => "-90.28333").save
City.new(:country_id => "93", :name => "Chiquimula", :aliases => "Chikimula,Chiquimula,Ciudad Procer,Ciudad PrÃ³cer,La Perla de Oriente,Ð§Ð¸ÐºÐ¸Ð¼ÑÐ»Ð°,Chiquimula", :latitude => "14.8", :longitude => "-89.55").save
City.new(:country_id => "93", :name => "Chinautla", :aliases => "Chignautla,Chinautla,Santa Cruz de Chinautla,Chinautla", :latitude => "14.70833", :longitude => "-90.49944").save
City.new(:country_id => "93", :name => "Chimaltenango", :aliases => "Chimal'tenango,Chimaltenango,Santa Ana Chimaltenango,Ð§Ð¸Ð¼Ð°Ð»ÑÑÐµÐ½Ð°Ð½Ð³Ð¾,Chimaltenango", :latitude => "14.66861", :longitude => "-90.81667").save
City.new(:country_id => "93", :name => "Chichicastenango", :aliases => "Chichicastenango,Chichikastenango,Santo Tomas Chichicastenango,Santo TomÃ¡s Chichicastenango,Ð§Ð¸ÑÐ¸ÐºÐ°ÑÑÐµÐ½Ð°Ð½Ð³Ð¾,Chichicastenango", :latitude => "14.93333", :longitude => "-91.11667").save
City.new(:country_id => "93", :name => "Chicacao", :aliases => ",Chicacao", :latitude => "14.53333", :longitude => "-91.31667").save
City.new(:country_id => "93", :name => "Cantel", :aliases => ",Cantel", :latitude => "14.81667", :longitude => "-91.45").save
City.new(:country_id => "93", :name => "Barberena", :aliases => "Barbarena,Barberena,Barberena", :latitude => "14.30944", :longitude => "-90.36111").save
City.new(:country_id => "93", :name => "Asuncion Mita", :aliases => "Asuncion,Asuncion Mita,AsunciÃ³n Mita,Mita,AsunciÃ³n Mita", :latitude => "14.33083", :longitude => "-89.71083").save
City.new(:country_id => "93", :name => "Antigua Guatemala", :aliases => "Antigua,Antigua Guatemala,Antigua-Gvatemala,Muy Noble y Muy Leal Ciudad de Santiago de los Caballeros,Santiago de los Caballeros de Guatemala,The Most Noble and Most Loyal City of Santiago of the Knights of Goathemala,an de gua,ÐÐ½ÑÐ¸Ð³ÑÐ°-ÐÐ²Ð°ÑÐµÐ¼Ð°Ð»Ð°,×× ×××××× ×××××××,å®å°ç,Antigua Guatemala", :latitude => "14.56111", :longitude => "-90.73444").save
City.new(:country_id => "93", :name => "Amatitlan", :aliases => "Amatitlan,AmatitlÃ¡n,San Juan Amatitlan,San Juan AmatitlÃ¡n,AmatitlÃ¡n", :latitude => "14.4875", :longitude => "-90.61528").save
City.new(:country_id => "93", :name => "Alotenango", :aliases => "Alotenango,San Juan Alotenango,Alotenango", :latitude => "14.48028", :longitude => "-90.8075").save
