City.new(:country_id => "207", :name => "Ziguinchor", :aliases => "Zighinkor,Ziginshor,Zigiunchor,Ziguinchor,Zinguinhor,jiganshoru,ÐÐ¸Ð³Ð¸Ð½ÑÐ¾Ñ,ã¸ã¬ã³ã·ã§ã¼ã«,Ziguinchor", :latitude => "12.58333", :longitude => "-16.27194").save
City.new(:country_id => "207", :name => "Velingara", :aliases => "Velingara,VÃ©lingara,VÃ©lingara", :latitude => "13.15", :longitude => "-14.11667").save
City.new(:country_id => "207", :name => "Tiebo", :aliases => ",TiÃ©bo", :latitude => "14.63333", :longitude => "-16.23333").save
City.new(:country_id => "207", :name => "Thies Nones", :aliases => ",ThiÃ¨s Nones", :latitude => "14.78333", :longitude => "-16.96667").save
City.new(:country_id => "207", :name => "Sedhiou", :aliases => "Sedhiou,Sedhiu,SÃ©dhiou,SÃ©dhiou", :latitude => "12.70806", :longitude => "-15.55694").save
City.new(:country_id => "207", :name => "Saint-Louis", :aliases => "Ndar,Saint-Louis,SanLuis,Sen-Lui,St-Louis,Ð¡ÐµÐ½-ÐÑÐ¸,Saint-Louis", :latitude => "16.01793", :longitude => "-16.48962").save
City.new(:country_id => "207", :name => "Richard-Toll", :aliases => "Richard-Toll,Richard-Toll", :latitude => "16.4625", :longitude => "-15.70083").save
City.new(:country_id => "207", :name => "Pout", :aliases => "Pout,Put,Pout", :latitude => "14.77389", :longitude => "-17.06028").save
City.new(:country_id => "207", :name => "Pourham", :aliases => "Poukham,Pourham,Pourham", :latitude => "14.35", :longitude => "-16.41667").save
City.new(:country_id => "207", :name => "Pikine", :aliases => "Pikin,Pikine,ÐÐ¸ÐºÐ¸Ð½,Pikine", :latitude => "14.75", :longitude => "-17.4").save
City.new(:country_id => "207", :name => "Nioro du Rip", :aliases => "Nioro,Nioro du Rip,Nioro-du Pup,Nioro du Rip", :latitude => "13.75", :longitude => "-15.8").save
City.new(:country_id => "207", :name => "Nguekokh", :aliases => "Nguekoh,Nguekohe,Nguekokh,Nguekorh,NguÃ©koh,NguÃ©kohe,NguÃ©kokh,NguÃ©korh,NguÃ©kokh", :latitude => "14.51278", :longitude => "-17.005").save
City.new(:country_id => "207", :name => "Ndibene Dahra", :aliases => ",NdibÃ¨ne Dahra", :latitude => "15.3338", :longitude => "-15.4766").save
City.new(:country_id => "207", :name => "Mekhe", :aliases => "Mecke,Meckhe,MeckhÃ©,MeckÃ©,Meke,Mekhe,Mekke,MekkÃ©,MÃ©khÃ©,MÃ©kÃ©,MÃ©khÃ©", :latitude => "15.1097", :longitude => "-16.6218").save
City.new(:country_id => "207", :name => "Mbake", :aliases => "Mbacke,MbackÃ©,MbakÃ©", :latitude => "14.79032", :longitude => "-15.90803").save
City.new(:country_id => "207", :name => "Kolda", :aliases => "Kolda,ÐÐ¾Ð»Ð´Ð°,Kolda", :latitude => "12.88333", :longitude => "-14.95").save
City.new(:country_id => "207", :name => "Kedougou", :aliases => "Kedougou,KÃ©dougou,KÃ©dougou", :latitude => "12.5579", :longitude => "-12.1743").save
City.new(:country_id => "207", :name => "Kayar", :aliases => "Cayar,Kayar,Kayar", :latitude => "14.91917", :longitude => "-17.12111").save
City.new(:country_id => "207", :name => "Joal-Fadiout", :aliases => "Fadiout,Fadiouth,Joal,Joal-Fadiout,Joal-Fadiout", :latitude => "14.16667", :longitude => "-16.83333").save
City.new(:country_id => "207", :name => "Guinguineo", :aliases => ",GuinguinÃ©o", :latitude => "14.26667", :longitude => "-15.95").save
City.new(:country_id => "207", :name => "Grand Dakar", :aliases => "Grand Dakar,Grand Dakar Bope,Grand Dakar", :latitude => "14.70889", :longitude => "-17.45528").save
City.new(:country_id => "207", :name => "Dara", :aliases => "Dahra,Dar,ÐÐ°Ñ,Dara", :latitude => "15.34844", :longitude => "-15.47993").save
City.new(:country_id => "207", :name => "Dakar", :aliases => "Dacar,Dakar,Ntakar,ÎÏÎ±ÎºÎ¬Ï,ÐÐ°ÐºÐ°Ñ,Dakar", :latitude => "14.6937", :longitude => "-17.44406").save
City.new(:country_id => "207", :name => "Bignona", :aliases => "Bignona,Pagnona,Bignona", :latitude => "12.81028", :longitude => "-16.22639").save
