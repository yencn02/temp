City.new(:country_id => "78", :name => "Tchibanga", :aliases => ",Tchibanga", :latitude => "-2.85", :longitude => "11.03333").save
City.new(:country_id => "78", :name => "Port-Gentil", :aliases => "Port Gentil,Port Zhantil,Port-Gentil,ÐÐ¾ÑÑ ÐÐ°Ð½ÑÐ¸Ð»,Port-Gentil", :latitude => "-0.71667", :longitude => "8.78333").save
City.new(:country_id => "78", :name => "Oyem", :aliases => ",Oyem", :latitude => "1.5983", :longitude => "11.57537").save
City.new(:country_id => "78", :name => "Mouila", :aliases => ",Mouila", :latitude => "-1.8635", :longitude => "11.05995").save
City.new(:country_id => "78", :name => "Moanda", :aliases => "Moanda,Mouanda,Mouenda,Moanda", :latitude => "-1.56542", :longitude => "13.18937").save
City.new(:country_id => "78", :name => "Libreville", :aliases => "Librevil,Librevil',Librevilis,Libreville,Liburvil,Limprebil,li bo wei er,libeuleubil,lybrwwyl,lybrwyl,ÎÎ¹Î¼ÏÏÎµÎ²Î¯Î»,ÐÐ¸Ð±ÑÐµÐ²Ð¸Ð»Ñ,ÐÐ¸Ð±ÑÑÐ²Ð¸Ð»,Ô¼Õ«Õ¢ÖÖÕ«Õ¬,××××¨××××,ÙÛØ¨Ø±ÙÛÙ,áá¥á¨áªá,å©ä¼¯ç»´å°,ë¦¬ë¸ë¥´ë¹,Libreville", :latitude => "0.38333", :longitude => "9.45").save
City.new(:country_id => "78", :name => "Lambarene", :aliases => "Lambarene,LambarÃ©nÃ©,ÐÐ°Ð¼Ð±Ð°ÑÐµÐ½Ðµ,LambarÃ©nÃ©", :latitude => "-0.7", :longitude => "10.21667").save
City.new(:country_id => "78", :name => "Koulamoutou", :aliases => "Koula Moubou,Koula Mouta,Koulamotou,Koulamoutou,Kulamutu,ÐÑÐ»Ð°Ð¼ÑÑÑ,Koulamoutou", :latitude => "-1.13032", :longitude => "12.47359").save
City.new(:country_id => "78", :name => "Franceville", :aliases => "Franceville,Fransvil,Ð¤ÑÐ°Ð½ÑÐ²Ð¸Ð»,Franceville", :latitude => "-1.63333", :longitude => "13.58357").save
