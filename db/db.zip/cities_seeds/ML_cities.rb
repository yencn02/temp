City.new(:country_id => "147", :name => "Yorosso", :aliases => "Joroso,Yorosso,ÐÐ¾ÑÐ¾ÑÐ¾,Yorosso", :latitude => "12.3536", :longitude => "-4.7761").save
City.new(:country_id => "147", :name => "Tombouctou", :aliases => "Timboctu,TimboctÃº,Timboektoe,Timbouctou,Timbuctoo,Timbuctu,TimbuctÃº,Timbuktu,TimbuktÃº,Tombouctou,Tombuctu,TombuctÃº,Tombutu,mdynt tmbktw,ting ba ke tu,tonbukuto~u,tymbwktw,tymbwqtw,Ð¢Ð¸Ð¼Ð±ÑÐºÑÑ,Ð¢ÑÐ¼Ð±ÑÐºÑÑ,××××××§××,ØªÛÙØ¨ÙÚ©ØªÙ,ÙØ¯ÙÙØ© ØªÙØ¨ÙØªÙ,ãã³ãã¯ãã¥,å»·å·´åå¾,Tombouctou", :latitude => "16.77348", :longitude => "-3.00742").save
City.new(:country_id => "147", :name => "Sikasso", :aliases => "Sikaso,Sikasso,Ð¡Ð¸ÐºÐ°ÑÐ¾,Sikasso", :latitude => "11.3135", :longitude => "-5.6697").save
City.new(:country_id => "147", :name => "Segou", :aliases => "Segi,Segou,SÃ©gou,Ð¡ÐµÐ³Ð¸,SÃ©gou", :latitude => "13.4317", :longitude => "-6.2157").save
City.new(:country_id => "147", :name => "San", :aliases => "San,San", :latitude => "13.30335", :longitude => "-4.89562").save
City.new(:country_id => "147", :name => "Mopti", :aliases => "Mopti,moputi,ÐÐ¾Ð¿ÑÐ¸,ã¢ããã£,Mopti", :latitude => "14.49302", :longitude => "-4.1942").save
City.new(:country_id => "147", :name => "Markala", :aliases => ",Markala", :latitude => "13.7021", :longitude => "-6.0659").save
City.new(:country_id => "147", :name => "Koutiala", :aliases => "Koutiala,Kutiala,ÐÑÑÐ¸Ð°Ð»Ð°,Koutiala", :latitude => "12.39173", :longitude => "-5.46421").save
City.new(:country_id => "147", :name => "Koulikoro", :aliases => "Koulikoro,Koulikoro-Liberte,Koulikoro-LibertÃ©,Kulikoro,kurikoro,ÐÑÐ»Ð¸ÐºÐ¾ÑÐ¾,ã¯ãªã³ã­,Koulikoro", :latitude => "12.86273", :longitude => "-7.55985").save
City.new(:country_id => "147", :name => "Kolokani", :aliases => "Kokolani,Kolokani,ÐÐ¾Ð»Ð¾ÐºÐ°Ð½Ð¸,Kolokani", :latitude => "13.5728", :longitude => "-8.0339").save
City.new(:country_id => "147", :name => "Kayes Ndi", :aliases => ",Kayes Ndi", :latitude => "14.4586", :longitude => "-11.4352").save
City.new(:country_id => "147", :name => "Kayes", :aliases => "Kajesas,Kayes,Kayes", :latitude => "14.4417", :longitude => "-11.4341").save
City.new(:country_id => "147", :name => "Kati", :aliases => "Kati,Kati Ville,ÐÐ°ÑÐ¸,Kati", :latitude => "12.74409", :longitude => "-8.07257").save
City.new(:country_id => "147", :name => "Kangaba", :aliases => "Kaba,Kangaba,Kangara,ÐÐ°Ð½Ð³Ð°Ð±Ð°,Kangaba", :latitude => "11.93333", :longitude => "-8.41667").save
City.new(:country_id => "147", :name => "Gao", :aliases => ",Gao", :latitude => "16.27167", :longitude => "-0.04472").save
City.new(:country_id => "147", :name => "Djenne", :aliases => "Djenne,DjennÃ©,DjÃ©nnÃ©,dzhene,jnh,ÐÐ¶ÐµÐ½Ðµ,Ø¬ÙÙ,DjÃ©nnÃ©", :latitude => "13.90608", :longitude => "-4.55332").save
City.new(:country_id => "147", :name => "Bougouni", :aliases => "Bougoum,Bougouni,Buguni,Bougouni", :latitude => "11.41699", :longitude => "-7.47899").save
City.new(:country_id => "147", :name => "Banamba", :aliases => ",Banamba", :latitude => "13.55", :longitude => "-7.45").save
City.new(:country_id => "147", :name => "Bamako", :aliases => "Bamaco - Bamako,Bamakas,Bamako,Bamaku,BamakÃ³,BamakÉ,Bammaco,Bammako,Mpamako,ba ma ke,bamako,bamakw,bmqw,ÎÏÎ±Î¼Î¬ÎºÎ¿,ÐÐ°Ð¼Ð°ÐºÐ¾,Ô²Õ¡Õ´Õ¡Õ¯Õ¸,×××§×,Ø¨Ø§ÙØ§ÙÙ,Ø¨Ø§ÙØ§Ú©Ù,á£áá®,ããã³,å·´é¦¬ç§,ë°ë§ì½,Bamako", :latitude => "12.65", :longitude => "-8").save
City.new(:country_id => "147", :name => "Bafoulabe", :aliases => "Bafoulabe,BafoulabÃ©,Bafulabe,BafoulabÃ©", :latitude => "13.8065", :longitude => "-10.8321").save
