City.new(:country_id => "160", :name => "Kuah", :aliases => "Kuah,Kuan,Kwah,Langkawi,Kuah", :latitude => "6.32649", :longitude => "99.8432").save
City.new(:country_id => "160", :name => "Jerantut", :aliases => "Jerantut,Jerantut", :latitude => "3.93333", :longitude => "102.36667").save
City.new(:country_id => "160", :name => "Raub", :aliases => ",Raub", :latitude => "3.8", :longitude => "101.86667").save
City.new(:country_id => "160", :name => "Batu Pahat", :aliases => "Bandar Penggaram,Batu Pahat,Distrik Batu Pahat,Batu Pahat", :latitude => "1.85", :longitude => "102.93333").save
City.new(:country_id => "160", :name => "Parit Raja", :aliases => "Parit Raja,Parit Raja", :latitude => "1.86667", :longitude => "103.11667").save
City.new(:country_id => "160", :name => "Pekan Nanas", :aliases => "Pekan Nanas,Pekan Nenas,Pekan Nanas", :latitude => "1.51667", :longitude => "103.51667").save
City.new(:country_id => "160", :name => "Pontian Kecil", :aliases => "Pontian,Pontian Kechil,Pontian Kecil,Pontian Kecil", :latitude => "1.48333", :longitude => "103.38333").save
City.new(:country_id => "160", :name => "Kampung Pasir Gudang Baru", :aliases => "Kampung Pasir Gudang,Kampung Pasir Gudang Baru,Kampung Pasir Gudang Baru", :latitude => "1.4726", :longitude => "103.878").save
City.new(:country_id => "160", :name => "Kota Tinggi", :aliases => "Kota Tinggi,Kota Tuiggi,Kota Tinggi", :latitude => "1.7381", :longitude => "103.8999").save
City.new(:country_id => "160", :name => "Senai", :aliases => "Senai,Ð¡ÐµÐ½Ð°Ð¸,Senai", :latitude => "1.6", :longitude => "103.65").save
City.new(:country_id => "160", :name => "Kulai", :aliases => "Kulai,Kuli,Kulai", :latitude => "1.6561", :longitude => "103.6032").save
City.new(:country_id => "160", :name => "Sekudai", :aliases => "Kampong Skudai,Kangkar Skudai,Scudai,Sekudai,Skudai,Sekudai", :latitude => "1.53333", :longitude => "103.66667").save
City.new(:country_id => "160", :name => "Johor Bahru", :aliases => "Baru,Bharu,Jahore Bahru,Johor,Johor Baharu,Johor Bahru,Johore,Johore Bahru,Johore Baru,Johore Bharu,dzhokhor-bakhru,johorubaru,jwhwr bahrw,xin shan,ÐÐ¶Ð¾ÑÐ¾Ñ-ÐÐ°ÑÑÑ,Ø¬ÙÙÙØ± Ø¨Ø§ÙØ±Ù,ã¸ã§ãã¼ã«ãã«,æ°å±±,Johor Bahru", :latitude => "1.4655", :longitude => "103.7578").save
City.new(:country_id => "160", :name => "Kluang", :aliases => "Keluang,Kluang,Kluang", :latitude => "2.0251", :longitude => "103.3328").save
City.new(:country_id => "160", :name => "Yong Peng", :aliases => "Yong Peng,Yong Peng", :latitude => "2.01667", :longitude => "103.06667").save
City.new(:country_id => "160", :name => "Mersing", :aliases => "Mersing,Mersing", :latitude => "2.43333", :longitude => "103.83333").save
City.new(:country_id => "160", :name => "Segamat", :aliases => "Segamat,Segamat", :latitude => "2.5148", :longitude => "102.8158").save
City.new(:country_id => "160", :name => "Tangkak", :aliases => "Tangkah,Tangkak,Tangkak", :latitude => "2.26667", :longitude => "102.55").save
City.new(:country_id => "160", :name => "Muar", :aliases => "Bandar Maharani,Muar,ma po,ÐÑÐ°Ñ,éº»å¡,Muar", :latitude => "2.03333", :longitude => "102.56667").save
City.new(:country_id => "160", :name => "Bakri", :aliases => "Bakri,Bukit Bakri,ÐÐ°ÐºÑÐ¸,Bakri", :latitude => "2.05", :longitude => "102.66667").save
City.new(:country_id => "160", :name => "Labis", :aliases => "Labis,Labis", :latitude => "2.38333", :longitude => "103.03333").save
City.new(:country_id => "160", :name => "Kuala Selangor", :aliases => "Kuala Selangor,Kuala-Selangor,Selangor,ÐÑÐ°Ð»Ð°-Ð¡ÐµÐ»Ð°Ð½Ð³Ð¾Ñ,Kuala Selangor", :latitude => "3.35", :longitude => "101.25").save
City.new(:country_id => "160", :name => "Batang Berjuntai", :aliases => "Batang Berjuntai,Betang Berjuntai,Batang Berjuntai", :latitude => "3.38333", :longitude => "101.41667").save
City.new(:country_id => "160", :name => "Batu Arang", :aliases => "Arang,Batu Arang,Batu Arang", :latitude => "3.31667", :longitude => "101.46667").save
City.new(:country_id => "160", :name => "Shah Alam", :aliases => "Shah Alam,Shakh-Alam,Ð¨Ð°Ñ-ÐÐ»Ð°Ð¼,Shah Alam", :latitude => "3.08507", :longitude => "101.53281").save
City.new(:country_id => "160", :name => "Klang", :aliases => "Kelang,Klang,Klang", :latitude => "3.03333", :longitude => "101.45").save
City.new(:country_id => "160", :name => "Cukai", :aliases => "Chukai,Chukei,Cukai,Mokuan,Telor Mokuan,Cukai", :latitude => "4.25", :longitude => "103.41667").save
City.new(:country_id => "160", :name => "Kuala Lipis", :aliases => ",Kuala Lipis", :latitude => "4.18333", :longitude => "102.05").save
City.new(:country_id => "160", :name => "Papar", :aliases => "Papar,Papar", :latitude => "5.73333", :longitude => "115.93333").save
City.new(:country_id => "160", :name => "Kota Kinabalu", :aliases => "Jesselton,Kinabalu,Kota Kinabalu,Kota-Kinabalu,kotakinabaru,kwta kynabalw,ya bi,ÐÐ¾ÑÐ°-ÐÐ¸Ð½Ð°Ð±Ð°Ð»Ñ,Ú©ÙØªØ§ Ú©ÛÙØ§Ø¨Ø§ÙÙ,ã³ã¿ã­ããã«,äºåº,Kota Kinabalu", :latitude => "5.98333", :longitude => "116.06667").save
City.new(:country_id => "160", :name => "Donggongon", :aliases => ",Donggongon", :latitude => "5.90702", :longitude => "116.10146").save
City.new(:country_id => "160", :name => "Putatan", :aliases => "Kampong Putatan,Putatan Station,Putatan", :latitude => "5.9258", :longitude => "116.06094").save
City.new(:country_id => "160", :name => "Kinarut", :aliases => "Kinarut,Kinarut Station,Kinarut", :latitude => "5.81667", :longitude => "116.05").save
City.new(:country_id => "160", :name => "Ranau", :aliases => "Ranau,Ranau", :latitude => "5.96667", :longitude => "116.68333").save
City.new(:country_id => "160", :name => "Semporna", :aliases => "Selangor,Semporna,Semporna Settlement,Sempurna,Simporan,Simporna,Ð¡ÐµÐ»Ð°Ð½Ð³Ð¾Ñ,Semporna", :latitude => "4.48178", :longitude => "118.61118").save
City.new(:country_id => "160", :name => "Victoria", :aliases => "Labuan,Victoria,Victoria Town,Viktorija,ÐÐ¸ÐºÑÐ¾ÑÐ¸Ñ,Victoria", :latitude => "5.27667", :longitude => "115.24167").save
City.new(:country_id => "160", :name => "Beaufort", :aliases => "Beaufort,Beaufort", :latitude => "5.3473", :longitude => "115.7455").save
City.new(:country_id => "160", :name => "Lahad Datu", :aliases => "Lahad Datu,Lahad Datu Town,Lahad Datu", :latitude => "5.0268", :longitude => "118.327").save
City.new(:country_id => "160", :name => "Sandakan", :aliases => "Elopura,Samdakan,Sandakan,Sandakan Town,sandakan,shan da gen,Ð¡Ð°Ð½Ð´Ð°ÐºÐ°Ð½,ãµã³ãã«ã³,å±±ææ ¹,Sandakan", :latitude => "5.8402", :longitude => "118.1179").save
City.new(:country_id => "160", :name => "Keningau", :aliases => "Kaningow,Kengingan,Keningau,Keningau", :latitude => "5.3378", :longitude => "116.1602").save
City.new(:country_id => "160", :name => "Tawau", :aliases => "Tawao,Tawau,Tawau", :latitude => "4.25", :longitude => "117.9").save
City.new(:country_id => "160", :name => "Paka", :aliases => "Kampong Paka,Packa,Pak,Paka,ÐÐ°Ðº,Paka", :latitude => "4.6374", :longitude => "103.4368").save
City.new(:country_id => "160", :name => "Kertih", :aliases => "Kerteh,Kertih,Kuala Kerteh,Kertih", :latitude => "4.5141", :longitude => "103.4483").save
City.new(:country_id => "160", :name => "Kulim", :aliases => "Kulim,Kulim", :latitude => "5.36499", :longitude => "100.56177").save
City.new(:country_id => "160", :name => "Bagan Serai", :aliases => "Bagan Serai,Bagan Serai", :latitude => "5.0108", :longitude => "100.54101").save
City.new(:country_id => "160", :name => "Bedong", :aliases => "Bedong,Bedung,Bedong", :latitude => "5.72744", :longitude => "100.50876").save
City.new(:country_id => "160", :name => "Simpang Empat", :aliases => "Semanggol,Simpang Ampat,Simpang Empat,Simpang Empat", :latitude => "4.95", :longitude => "100.63333").save
City.new(:country_id => "160", :name => "Taiping", :aliases => "Bandar Taiping,Taipeng,Taiping,Tajpin,tai ping,Ð¢Ð°Ð¹Ð¿Ð¸Ð½,å¤ªå¹³,Taiping", :latitude => "4.85", :longitude => "100.73333").save
City.new(:country_id => "160", :name => "Kuala Kangsar", :aliases => "Kangsar,Kuala Kangsa,Kuala Kangsar,Kuala Kangsar", :latitude => "4.76667", :longitude => "100.93333").save
City.new(:country_id => "160", :name => "Ipoh", :aliases => "Ipo,Ipoh,ipo,yi bao,ÐÐ¿Ð¾,ã¤ãã¼,æ¡ä¿,Ipoh", :latitude => "4.5841", :longitude => "101.0829").save
City.new(:country_id => "160", :name => "Gua Musang", :aliases => "Gua Musang,Gua Musang", :latitude => "4.8823", :longitude => "101.9644").save
City.new(:country_id => "160", :name => "Kuala Terengganu", :aliases => "Bandar Kuala Terengganu,Kuala Terengganu,Kuala Trengganu,Trengganu,Tringano,Tringganu,Kuala Terengganu", :latitude => "5.3302", :longitude => "103.1408").save
City.new(:country_id => "160", :name => "Marang", :aliases => "Kuala Marang,Kualla Merang,Marang,ÐÐ°ÑÐ°Ð½Ð³,Marang", :latitude => "5.2056", :longitude => "103.2059").save
City.new(:country_id => "160", :name => "Tampin", :aliases => ",Tampin", :latitude => "2.46667", :longitude => "102.23333").save
City.new(:country_id => "160", :name => "Alur Gajah", :aliases => "Alor Gajah,Alor Gajeh,Alur Gajah,Alur Gajah", :latitude => "2.38333", :longitude => "102.21667").save
City.new(:country_id => "160", :name => "Air Keruh", :aliases => "Air Keruh,Ayer Keroh,Air Keruh", :latitude => "2.26667", :longitude => "102.28333").save
City.new(:country_id => "160", :name => "Sungai Udang", :aliases => "Sungai Udang,Sungai Udang", :latitude => "2.26667", :longitude => "102.15").save
City.new(:country_id => "160", :name => "Melaka", :aliases => "Malaca,Malacca,Malacca Town,Malaka,Malakka,Melaka,ma liu jia,marakka,ÐÐ°Ð»Ð°ÐºÐºÐ°,ãã©ãã«,é©¬å­ç²,Melaka", :latitude => "2.19694", :longitude => "102.24806").save
City.new(:country_id => "160", :name => "Banting", :aliases => ",Banting", :latitude => "2.81667", :longitude => "101.5").save
City.new(:country_id => "160", :name => "Jenjarum", :aliases => "Jenjarom,Jenjarum,Jenjarum", :latitude => "2.88333", :longitude => "101.5").save
City.new(:country_id => "160", :name => "Semenyih", :aliases => "Semenyeh,Semenyih,Semenyih", :latitude => "2.95", :longitude => "101.85").save
City.new(:country_id => "160", :name => "Seremban", :aliases => "Seremban,Ð¡ÐµÑÐµÐ¼Ð±Ð°Ð½,Seremban", :latitude => "2.71667", :longitude => "101.93333").save
City.new(:country_id => "160", :name => "Port Dickson", :aliases => "Arang Arang Anchorage,Arang-Arang,Port Dickson,Port Dickson", :latitude => "2.51667", :longitude => "101.8").save
City.new(:country_id => "160", :name => "Bahau", :aliases => "Bahau,Bahau", :latitude => "2.81667", :longitude => "102.41667").save
City.new(:country_id => "160", :name => "Kuala Pilah", :aliases => "Kuala Lipis,Kuala Pilah,Kuala Pilah", :latitude => "2.73333", :longitude => "102.25").save
City.new(:country_id => "160", :name => "Pekan", :aliases => "Pekan,ÐÐµÐºÐ°Ð½,Pekan", :latitude => "3.4836", :longitude => "103.3996").save
City.new(:country_id => "160", :name => "Mentekab", :aliases => "Mentakab,Mentekab,Mentekab", :latitude => "3.48333", :longitude => "102.35").save
City.new(:country_id => "160", :name => "Temerluh", :aliases => "Temerloh,Temerluh,Temerluh", :latitude => "3.45", :longitude => "102.41667").save
City.new(:country_id => "160", :name => "Butterworth", :aliases => "Butterworth,Butterworth", :latitude => "5.3991", :longitude => "100.36382").save
City.new(:country_id => "160", :name => "Perai", :aliases => "Perai,Prai,Perai", :latitude => "5.38333", :longitude => "100.38333").save
City.new(:country_id => "160", :name => "Bukit Mertajam", :aliases => "Bukit Mertajam,Bukit Mertajam", :latitude => "5.36301", :longitude => "100.4667").save
City.new(:country_id => "160", :name => "Nibong Tebal", :aliases => "Nibong Tebal,Nibong Tepal,Nibung Tebal,Nibong Tebal", :latitude => "5.16586", :longitude => "100.47793").save
City.new(:country_id => "160", :name => "Parit Buntar", :aliases => "Parit Buntar,Parit Buntar", :latitude => "5.12671", :longitude => "100.49316").save
City.new(:country_id => "160", :name => "Tasek Glugor", :aliases => "Tasek Gelugor,Tasek Gelugur,Tasek Glugor,Tasek Glugor", :latitude => "5.48032", :longitude => "100.49849").save
City.new(:country_id => "160", :name => "George Town", :aliases => "Dzhordzhtaun,George Town,Georgetown,Penang,Pinang,Pinang George Town,jojitaun,qiao zhi shi,ÐÐ¶Ð¾ÑÐ´Ð¶ÑÐ°ÑÐ½,ã¸ã§ã¼ã¸ã¿ã¦ã³,å¬æ²»å¸,George Town", :latitude => "5.41123", :longitude => "100.33543").save
City.new(:country_id => "160", :name => "Serendah", :aliases => "Serendah,Serendah", :latitude => "3.36667", :longitude => "101.61667").save
City.new(:country_id => "160", :name => "Rawang", :aliases => ",Rawang", :latitude => "3.31667", :longitude => "101.58333").save
City.new(:country_id => "160", :name => "Petaling Jaya", :aliases => "Petaling Jaya,Petaling-Dzhaja,ptalyng jaya,ÐÐµÑÐ°Ð»Ð¸Ð½Ð³-ÐÐ¶Ð°Ñ,Ù¾ØªØ§ÙÛÙÚ¯ Ø¬Ø§ÛØ§,Petaling Jaya", :latitude => "3.10726", :longitude => "101.60671").save
City.new(:country_id => "160", :name => "Kuala Lumpur", :aliases => "Kouala Loumpour,Kuala Lumpor,Kuala Lumpur,Kuala-Lumpur,Kualalumpura,KualalumpÅ«ra,Kvala Lumpuras,Kvala LumpÅ«ras,ji long po,kawlalampexr,ku'alalamapura,ku'alalampura,kuallalumpuleu,kuararunpuru,ÎÎ¿ÏÎ¬Î»Î± ÎÎ¿ÏÎ¼ÏÎ¿ÏÏ,ÐÑÐ°Ð»Ð° ÐÑÐ¼Ð¿ÑÑ,ÐÑÐ°Ð»Ð°-ÐÑÐ¼Ð¿ÑÑ,×§×××× ××××¤××¨,ÙÛØ¦Ø§ÙØ§-ÙÛÙÙ¾ÛØ±,à¤à¥à¤à¤²à¤¾à¤²à¤®à¥à¤ªà¥à¤°,à¤à¥à¤à¤²à¤¾à¤²à¤¾à¤®à¤ªà¥à¤°,à¸à¸±à¸§à¸¥à¸²à¸¥à¸±à¸¡à¹à¸à¸­à¸£à¹,áá£ááá-áá£ááá£á á,á©áá áááá­,ã¯ã¢ã©ã«ã³ãã¼ã«,åéå¡,ì¿ ìë¼ë£¸í¸ë¥´,Kuala Lumpur", :latitude => "3.1412", :longitude => "101.68653").save
City.new(:country_id => "160", :name => "Sabak Bernam", :aliases => "Sabah,Sabak,Sabak Bernam,Sobak Bernam,Sabak Bernam", :latitude => "3.7698", :longitude => "100.9879").save
City.new(:country_id => "160", :name => "Sungai Besar", :aliases => "Kampong Sungei Besar,Sungai Besar,Sungai Besar", :latitude => "3.6746", :longitude => "100.9867").save
City.new(:country_id => "160", :name => "Kuantan", :aliases => "Kuala Kuantan,Kuala Kuatan,Kuantan,ÐÑÐ°Ð½ÑÐ°Ð½,Kuantan", :latitude => "3.8077", :longitude => "103.326").save
City.new(:country_id => "160", :name => "Batu Gajah", :aliases => "Batu Gaah,Batu Gajah,Batu Gajah", :latitude => "4.46916", :longitude => "101.04107").save
City.new(:country_id => "160", :name => "Kampar", :aliases => "Kampar,Kampar", :latitude => "4.3", :longitude => "101.15").save
City.new(:country_id => "160", :name => "Tapah Road", :aliases => "Tapah Road,Tapah Road", :latitude => "4.16667", :longitude => "101.2").save
City.new(:country_id => "160", :name => "Bidur", :aliases => "Bidor,Bidur,Bidur", :latitude => "4.11667", :longitude => "101.28333").save
City.new(:country_id => "160", :name => "Lumut", :aliases => "Lumut,Lumut", :latitude => "4.23333", :longitude => "100.63333").save
City.new(:country_id => "160", :name => "Teluk Intan", :aliases => "Telok Anson,Teluk Anson,Teluk Intan,an shun,å®é¡º,Teluk Intan", :latitude => "4.03333", :longitude => "101.01667").save
City.new(:country_id => "160", :name => "Gurun", :aliases => "Gurun,Kampung Gurun,Gurun", :latitude => "5.81717", :longitude => "100.47381").save
City.new(:country_id => "160", :name => "Sungai Petani", :aliases => "Sungai Patani,Sungai Petani,Sungei Patani,Sungai Petani", :latitude => "5.647", :longitude => "100.48772").save
City.new(:country_id => "160", :name => "Kepala Batas", :aliases => "Kapala Batas,Kepala Batas,Kepala Batas", :latitude => "5.51707", :longitude => "100.4265").save
City.new(:country_id => "160", :name => "Tanah Merah", :aliases => "Tanah Merah,Tanah Merak,Tanah Merah", :latitude => "5.8", :longitude => "102.15").save
City.new(:country_id => "160", :name => "Kuching", :aliases => "Kuching,Kucingas,KuÄingas,gu jin,kuchin,ÐÑÑÐ¸Ð½Ð³,ã¯ãã³,å¤æ,Kuching", :latitude => "1.55", :longitude => "110.33333").save
City.new(:country_id => "160", :name => "Simanggang", :aliases => "Bandar Sri Aman,Simanggang,Simmangang,Simmanggang,Sri Aman,Simanggang", :latitude => "1.24722", :longitude => "111.45278").save
City.new(:country_id => "160", :name => "Sarikei", :aliases => "Sarikei,Seriki,Siriki,Sarikei", :latitude => "2.11667", :longitude => "111.51667").save
City.new(:country_id => "160", :name => "Sibu", :aliases => "Fort Brooke,Siboe,Sibu,Ð¡Ð¸Ð±Ñ,Sibu", :latitude => "2.3", :longitude => "111.81667").save
City.new(:country_id => "160", :name => "Kangar", :aliases => "Kangar,Perlis,Poelit,Polit,ÐÐ°Ð½Ð³Ð°Ñ,Kangar", :latitude => "6.4414", :longitude => "100.19862").save
City.new(:country_id => "160", :name => "Jitra", :aliases => "Jitra,Jitra", :latitude => "6.26812", :longitude => "100.42167").save
City.new(:country_id => "160", :name => "Kuala Kedah", :aliases => ",Kuala Kedah", :latitude => "6.1", :longitude => "100.3").save
City.new(:country_id => "160", :name => "Alor Setar", :aliases => "Alor Setar,Alor Star,Alostar,Alur Setar,Saiburu,Thai,alwr star,arosuta,ya luo shi da,Ø§ÙÙØ± Ø³ØªØ§Ø±,ã¢ã­ã¼ã¹ã¿ã¼,äºç¾å£«æ,Alor Setar", :latitude => "6.12104", :longitude => "100.36014").save
City.new(:country_id => "160", :name => "Pasir Mas", :aliases => "Pasir Mas,Pasir Mas", :latitude => "6.04934", :longitude => "102.13987").save
City.new(:country_id => "160", :name => "Kota Bharu", :aliases => "Khota Baharu,Khota Bahru,Kota Baharu,Kota Bahru,Kota Bharu,Kota Bharu", :latitude => "6.13328", :longitude => "102.2386").save
City.new(:country_id => "160", :name => "Kudat", :aliases => "Kudat,Kudat", :latitude => "6.8837", :longitude => "116.8477").save
City.new(:country_id => "160", :name => "Kapit", :aliases => "Kapit,Kapit Fort,Kapit", :latitude => "2.01667", :longitude => "112.93333").save
City.new(:country_id => "160", :name => "Bintulu", :aliases => "Bintulu,ÐÐ¸Ð½ÑÑÐ»Ñ,Bintulu", :latitude => "3.16667", :longitude => "113.03333").save
City.new(:country_id => "160", :name => "Limbang", :aliases => ",Limbang", :latitude => "4.75", :longitude => "115").save
City.new(:country_id => "160", :name => "Miri", :aliases => "Miri,Miri", :latitude => "4.38333", :longitude => "113.98333").save
City.new(:country_id => "160", :name => "Ulu Tiram", :aliases => "Ulu Tiram,Ulu Tiram Village,Ulu Tiram", :latitude => "1.6", :longitude => "103.81667").save
City.new(:country_id => "160", :name => "Tanjung Tokong", :aliases => "Tanjong Tokong,Tanjung Tokong,Tanjung Tokong", :latitude => "5.46061", :longitude => "100.30742").save
City.new(:country_id => "160", :name => "Tanjung Sepat", :aliases => "Kampong Tanjong Sepat,Tanjong Sepat,Tanjung Sepat,Tanjung Sepat", :latitude => "2.6579", :longitude => "101.5629").save
City.new(:country_id => "160", :name => "Permatang Kuching", :aliases => "Permatang Kuching,Permatang Kuching", :latitude => "5.46339", :longitude => "100.38144").save
City.new(:country_id => "160", :name => "Peringat", :aliases => ",Peringat", :latitude => "6.03333", :longitude => "102.28333").save
City.new(:country_id => "160", :name => "Pengkalan Kundang", :aliases => ",Pengkalan Kundang", :latitude => "3.28333", :longitude => "101.51667").save
City.new(:country_id => "160", :name => "Pantai Remis", :aliases => "Kampong Pantai Remis,Pantai Remis,Pantei Remis,Pantai Remis", :latitude => "4.45", :longitude => "100.63333").save
City.new(:country_id => "160", :name => "Kuang", :aliases => "Kuang,ÐÑÐ°Ð½Ð³,Kuang", :latitude => "3.25", :longitude => "101.55").save
City.new(:country_id => "160", :name => "Kelebang Besar", :aliases => "Kelebang Besar,Klebang Besar,Kelebang Besar", :latitude => "2.21667", :longitude => "102.2").save
City.new(:country_id => "160", :name => "Kampung Tanjung Karang", :aliases => "Kampung Tanjung Karang,Tanjong Karang,Kampung Tanjung Karang", :latitude => "3.4242", :longitude => "101.1849").save
City.new(:country_id => "160", :name => "Kampung Sungai Ara", :aliases => "Kampong Sungai Ara,Kampung Sungai Ara,Sungei Ara,Kampung Sungai Ara", :latitude => "5.32699", :longitude => "100.27348").save
City.new(:country_id => "160", :name => "Kampung Simpang Renggam", :aliases => "Kampong Simpang Rengam,Kampung Simpang Renggam,Kampung Simpang Renggam", :latitude => "1.8278", :longitude => "103.3").save
City.new(:country_id => "160", :name => "Kampong Pangkal Kalong", :aliases => ",Kampong Pangkal Kalong", :latitude => "5.91667", :longitude => "102.21667").save
City.new(:country_id => "160", :name => "Kampong Masjid Tanah", :aliases => ",Kampong Masjid Tanah", :latitude => "2.35", :longitude => "102.11667").save
City.new(:country_id => "160", :name => "Kampong Kadok", :aliases => ",Kampong Kadok", :latitude => "6", :longitude => "102.25").save
City.new(:country_id => "160", :name => "Kampong Dungun", :aliases => "Kampong Dungan,Kampong Dungun,Kampong Dungun", :latitude => "3.21667", :longitude => "101.31667").save
City.new(:country_id => "160", :name => "Kampong Bukit Baru", :aliases => ",Kampong Bukit Baru", :latitude => "2.21667", :longitude => "102.28333").save
City.new(:country_id => "160", :name => "Kampung Baru Subang", :aliases => ",Kampung Baru Subang", :latitude => "3.15", :longitude => "101.53333").save
City.new(:country_id => "160", :name => "Kampong Baharu Nilai", :aliases => "Kampong Baharu Nilai,Kampong Bahru Nilai,Kampong Nilai,Nilai,Kampong Baharu Nilai", :latitude => "2.81667", :longitude => "101.8").save
City.new(:country_id => "160", :name => "Kampong Baharu Balakong", :aliases => ",Kampong Baharu Balakong", :latitude => "3.03333", :longitude => "101.75").save
City.new(:country_id => "160", :name => "Kampong Ayer Molek", :aliases => ",Kampong Ayer Molek", :latitude => "2.21667", :longitude => "102.33333").save
City.new(:country_id => "160", :name => "Bukit Rambai", :aliases => ",Bukit Rambai", :latitude => "2.25", :longitude => "102.18333").save
City.new(:country_id => "160", :name => "Bentong Town", :aliases => ",Bentong Town", :latitude => "3.51667", :longitude => "101.9").save
City.new(:country_id => "160", :name => "Batu Berendam", :aliases => "Batu Berendam,Batu Berendam", :latitude => "2.25", :longitude => "102.25").save
City.new(:country_id => "160", :name => "Putrajaya", :aliases => ",Putrajaya", :latitude => "2.93527", :longitude => "101.69112").save
City.new(:country_id => "160", :name => "Bandar Labuan", :aliases => ",Bandar Labuan", :latitude => "5.28883", :longitude => "115.26924").save
