City.new(:country_id => "145", :name => "Majuro", :aliases => "Madzhuro,Majur,Majuro,Mazouro,ÎÎ±Î¶Î¿ÏÏÎ¿,ÐÐ°Ð´Ð¶ÑÑÐ¾,Majuro", :latitude => "7.08971", :longitude => "171.38027").save
