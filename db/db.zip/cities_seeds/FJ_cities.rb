City.new(:country_id => "72", :name => "Suva", :aliases => "Souba,Suva,Suva City,Suwa,su wa,suba,subha,swbh,swfa,swwa,Î£Î¿ÏÎ²Î±,Ð¡ÑÐ²Ð°,×¡×××,Ø³ÙÙØ§,Ø³ÙÙØ§,à¦¸à§à¦­à¦¾,á±á«,ã¹ã,èç¦,ìë°,Suva", :latitude => "-18.14161", :longitude => "178.44149").save
City.new(:country_id => "72", :name => "Nadi", :aliases => "Nadi,Nandi,ÐÐ°Ð½Ð´Ð¸,Nadi", :latitude => "-17.8", :longitude => "177.41667").save
City.new(:country_id => "72", :name => "Lambasa", :aliases => "Labasa,Lambasa,Lambasa Mill,Lambase,Lambassa,Lambasa", :latitude => "-16.41667", :longitude => "179.38333").save
