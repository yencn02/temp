City.new(:country_id => "167", :name => "Tipitapa", :aliases => "Tipitapa,Ð¢Ð¸Ð¿Ð¸ÑÐ°Ð¿Ð°,Tipitapa", :latitude => "12.19732", :longitude => "-86.09706").save
City.new(:country_id => "167", :name => "Somoto", :aliases => "Somoto,Somoto", :latitude => "13.48082", :longitude => "-86.58208").save
City.new(:country_id => "167", :name => "Somotillo", :aliases => "Poyas,Somotillo,Somotillo", :latitude => "13.04328", :longitude => "-86.90645").save
City.new(:country_id => "167", :name => "Siuna", :aliases => "Siuna,Suina,Siuna", :latitude => "13.73333", :longitude => "-84.76667").save
City.new(:country_id => "167", :name => "San Rafael del Sur", :aliases => "San Rafael,San Rafael del Sur,San Rafael del Sur", :latitude => "11.84854", :longitude => "-86.43839").save
City.new(:country_id => "167", :name => "San Marcos", :aliases => ",San Marcos", :latitude => "11.90949", :longitude => "-86.20351").save
City.new(:country_id => "167", :name => "Rivas", :aliases => "Nicaragua,Rivas,Villa of Nicaragua,Ð Ð¸Ð²Ð°Ñ,Rivas", :latitude => "11.43333", :longitude => "-85.83333").save
City.new(:country_id => "167", :name => "Rio Blanco", :aliases => "Rio Blanco,RÃ­o Blanco,RÃ­o Blanco", :latitude => "12.93333", :longitude => "-85.21667").save
City.new(:country_id => "167", :name => "Rama", :aliases => "Ciudad Rama,Rama,Ramy,Ð Ð°Ð¼Ñ,Rama", :latitude => "12.15965", :longitude => "-84.21952").save
City.new(:country_id => "167", :name => "Puerto Cabezas", :aliases => "Bilwi,Bragman's Bluff,Bragmanâs Bluff,Puehrto-Kabesas,Puerto Cabezas,ÐÑÑÑÑÐ¾-ÐÐ°Ð±ÐµÑÐ°Ñ,Puerto Cabezas", :latitude => "14.03507", :longitude => "-83.38882").save
City.new(:country_id => "167", :name => "Ocotal", :aliases => "Ocotal,Okotal',ÐÐºÐ¾ÑÐ°Ð»Ñ,Ocotal", :latitude => "13.63208", :longitude => "-86.47516").save
City.new(:country_id => "167", :name => "Nueva Guinea", :aliases => "Colonia Nueva Guinea,Nueva Guinea,Nueva Guinea", :latitude => "11.68333", :longitude => "-84.45").save
City.new(:country_id => "167", :name => "Nandaime", :aliases => ",Nandaime", :latitude => "11.75696", :longitude => "-86.05286").save
City.new(:country_id => "167", :name => "Nagarote", :aliases => "Nagarote,Nagorote,Nagarote", :latitude => "12.26593", :longitude => "-86.56474").save
City.new(:country_id => "167", :name => "Matagalpa", :aliases => "Matagal'pa,Matagalpa,ÐÐ°ÑÐ°Ð³Ð°Ð»ÑÐ¿Ð°,Matagalpa", :latitude => "12.91667", :longitude => "-85.91667").save
City.new(:country_id => "167", :name => "Masaya", :aliases => "Masaja,Masaya,ÐÐ°ÑÐ°Ñ,Masaya", :latitude => "11.97444", :longitude => "-86.09417").save
City.new(:country_id => "167", :name => "Masatepe", :aliases => "Masatepe,Masatepe", :latitude => "11.9184", :longitude => "-86.14467").save
City.new(:country_id => "167", :name => "Managua", :aliases => "Managua,Managva,Managvo,Manankoua,ManÃ¡gua,ma na gua,managhwa,managua,managwa,manakaw,ÎÎ±Î½Î¬Î³ÎºÎ¿ÏÎ±,ÐÐ°Ð½Ð°Ð³Ð²Ð°,ÐÐ°Ð½Ð°Ð³ÑÐ°,×× ××××,ÙØ§ÙØ§ØºÙØ§,ÙØ§ÙØ§Ú¯ÙØ¢,à¸¡à¸²à¸à¸²à¸à¸±à¸§,ááá,ããã°ã¢,é¦¬æ¿ç,ë§ëê³¼,Managua", :latitude => "12.13282", :longitude => "-86.2504").save
City.new(:country_id => "167", :name => "Leon", :aliases => "Leon,LeÃ³n,××××,LeÃ³n", :latitude => "12.43787", :longitude => "-86.87804").save
City.new(:country_id => "167", :name => "La Paz Centro", :aliases => "La Paz,La Paz Central,La Paz Centro,Paz Central,La Paz Centro", :latitude => "12.34", :longitude => "-86.67528").save
City.new(:country_id => "167", :name => "Juigalpa", :aliases => "Juigalpa,Juigalpa", :latitude => "12.08333", :longitude => "-85.4").save
City.new(:country_id => "167", :name => "Jinotepe", :aliases => "Jinotepe,Jinotepe", :latitude => "11.84962", :longitude => "-86.19903").save
City.new(:country_id => "167", :name => "Jinotega", :aliases => "Jinotega,Khinotega,Ð¥Ð¸Ð½Ð¾ÑÐµÐ³Ð°,Jinotega", :latitude => "13.09171", :longitude => "-86.00177").save
City.new(:country_id => "167", :name => "Jalapa", :aliases => "Jalapa,Khalapa,Ð¥Ð°Ð»Ð°Ð¿Ð°,Jalapa", :latitude => "13.92222", :longitude => "-86.12346").save
City.new(:country_id => "167", :name => "Granada", :aliases => "Granada,Granado,Grenada,ÐÑÐµÐ½Ð°Ð´Ð°,Granada", :latitude => "11.93144", :longitude => "-85.95772").save
City.new(:country_id => "167", :name => "Esteli", :aliases => "Ehsteli,Esteli,EstelÃ­,Ð­ÑÑÐµÐ»Ð¸,EstelÃ­", :latitude => "13.09185", :longitude => "-86.35384").save
City.new(:country_id => "167", :name => "El Viejo", :aliases => "Ehl'-V'ekho,El Viejo,Viejo,Ð­Ð»Ñ-ÐÑÐµÑÐ¾,El Viejo", :latitude => "12.6633", :longitude => "-87.16722").save
City.new(:country_id => "167", :name => "El Crucero", :aliases => "Crucero,El Cirucero,El Crucero,El Crucero", :latitude => "11.99008", :longitude => "-86.30954").save
City.new(:country_id => "167", :name => "Diriamba", :aliases => "Diriamba,Diriambo,Diriamba", :latitude => "11.85842", :longitude => "-86.23878").save
City.new(:country_id => "167", :name => "Corinto", :aliases => "Corinto,Corinto", :latitude => "12.48199", :longitude => "-87.17336").save
City.new(:country_id => "167", :name => "Chinandega", :aliases => "Chinandega,Chinandege,Ð§Ð¸Ð½Ð°Ð½Ð´ÐµÐ³Ðµ,Chinandega", :latitude => "12.62937", :longitude => "-87.13105").save
City.new(:country_id => "167", :name => "Chichigalpa", :aliases => "Chichigalpa,Chichigalpa", :latitude => "12.57758", :longitude => "-87.02705").save
City.new(:country_id => "167", :name => "Camoapa", :aliases => "Camaopa,Camoapa,Camoapa", :latitude => "12.38333", :longitude => "-85.51667").save
City.new(:country_id => "167", :name => "Boaco", :aliases => "Boaco,Boaco", :latitude => "12.46667", :longitude => "-85.66667").save
City.new(:country_id => "167", :name => "Bluefields", :aliases => "Blewfield,Bluefields,Blufildse,ÐÐ»ÑÑÐ¸Ð»Ð´ÑÐµ,Bluefields", :latitude => "12.01366", :longitude => "-83.76353").save
City.new(:country_id => "167", :name => "Ciudad Sandino", :aliases => ",Ciudad Sandino", :latitude => "12.15889", :longitude => "-86.34417").save
