City.new(:country_id => "187", :name => "Ngerulmud", :aliases => ",Ngerulmud", :latitude => "7.50043", :longitude => "134.62355").save
