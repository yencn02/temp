City.new(:country_id => "217", :name => "Vogan", :aliases => "Voga,Vogan,Woga,Wogan,ÐÐ¾Ð³Ð°Ð½,Vogan", :latitude => "6.33333", :longitude => "1.53333").save
City.new(:country_id => "217", :name => "Tsevie", :aliases => "Tsevie,Tsevye,TsÃ©viÃ©,TsÃ©vyÃ©,Tzevie,TsÃ©viÃ©", :latitude => "6.42611", :longitude => "1.21333").save
City.new(:country_id => "217", :name => "Tchamba", :aliases => "Kouboni,Kuboni,Tchamba,Tchamba", :latitude => "9.03333", :longitude => "1.41667").save
City.new(:country_id => "217", :name => "Sotouboua", :aliases => "Sotouboua,Sotouboua", :latitude => "8.56667", :longitude => "0.98333").save
City.new(:country_id => "217", :name => "Sokode", :aliases => "Sokode,SokodÃ©,suo ke de,Ð¡Ð¾ÐºÐ¾Ð´Ðµ,ç´¢ç§å¾·,SokodÃ©", :latitude => "8.98333", :longitude => "1.13333").save
City.new(:country_id => "217", :name => "Notse", :aliases => "Notse,NotsÃ©,Nouatja,Nuatia,Nuatja,Nuatya,NotsÃ©", :latitude => "6.95", :longitude => "1.16667").save
City.new(:country_id => "217", :name => "Niamtougou", :aliases => "Niamtougou,Niamtugu,Niamtuu,Njamtuu,NjamtÅ«u,Nyamtouhou,ÐÐ¸Ð°Ð¼ÑÑÐ³Ñ,Niamtougou", :latitude => "9.76806", :longitude => "1.10528").save
City.new(:country_id => "217", :name => "Sansanne-Mango", :aliases => "Mango,N'Zara,Nsara,NâZara,Sansane-Mangu,Sansanne-Mango,SansannÃ©-Mango,Sanssane-Mango,SanssanÃ©-Mango,SansannÃ©-Mango", :latitude => "10.35917", :longitude => "0.47083").save
City.new(:country_id => "217", :name => "Lome", :aliases => "Lome,LomÃ©,LomÄ,lome,luo mei,lwmh,lwmy,rome,ÎÎ¿Î¼Î­,ÐÐ¾Ð¼Ðµ,××××,ÙÙÙÙ,ÙÙÙÙ,áá,ã­ã¡,æ´ç¾,ë¡ë©,LomÃ©", :latitude => "6.13748", :longitude => "1.21227").save
City.new(:country_id => "217", :name => "Kpalime", :aliases => "Agome-Palime,AgomÃ©-PalimÃ©,Kpalime,KpalimÃ©,Palime,PalimÃ©,pa li mei,å¸å©æ¢,KpalimÃ©", :latitude => "6.9", :longitude => "0.63333").save
City.new(:country_id => "217", :name => "Kara", :aliases => "Kara,Lama,Lama-Kara,ÐÐ°ÑÐ°,Kara", :latitude => "9.55111", :longitude => "1.18611").save
City.new(:country_id => "217", :name => "Dapaong", :aliases => "Dapango,Dapaong,Dapaonge,Dapong,da pang,ÐÐ°Ð¿Ð°Ð¾Ð½Ð³Ðµ,è¾¾åº,Dapaong", :latitude => "10.86389", :longitude => "0.205").save
City.new(:country_id => "217", :name => "Bassar", :aliases => "Basar,Bassar,Bassari,ba sa,ÐÐ°ÑÐ°Ñ,å·´è¨,Bassar", :latitude => "9.25", :longitude => "0.78333").save
City.new(:country_id => "217", :name => "Bafilo", :aliases => "Bafilo,ÐÐ°ÑÐ¸Ð»Ð¾,Bafilo", :latitude => "9.35", :longitude => "1.26667").save
City.new(:country_id => "217", :name => "Badou", :aliases => "Bad,Badou,Badu,BÄdu,ÐÐ°Ð´,Badou", :latitude => "7.58333", :longitude => "0.6").save
City.new(:country_id => "217", :name => "Atakpame", :aliases => ",AtakpamÃ©", :latitude => "7.53333", :longitude => "1.13333").save
City.new(:country_id => "217", :name => "Aneho", :aliases => "Anecho,Aneho,Anekho,Anerho,AnÃ©cho,AnÃ©ho,Klein-Popo,Little Popo,Petit Popo,AnÃ©ho", :latitude => "6.23333", :longitude => "1.6").save
