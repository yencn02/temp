City.new(:country_id => "87", :name => "Sukuta", :aliases => "Dembadu,Sabiji,Sukuta,Sukuto,Sukutta,Sukuta", :latitude => "13.41033", :longitude => "-16.70815").save
City.new(:country_id => "87", :name => "Lamin", :aliases => ",Lamin", :latitude => "13.35222", :longitude => "-16.43389").save
City.new(:country_id => "87", :name => "Farafenni", :aliases => "Farafenni,Farafenni", :latitude => "13.56667", :longitude => "-15.6").save
City.new(:country_id => "87", :name => "Brikama", :aliases => "Brikama,Brikame,ÐÑÐ¸ÐºÐ°Ð¼Ðµ,Brikama", :latitude => "13.27136", :longitude => "-16.64944").save
City.new(:country_id => "87", :name => "Banjul", :aliases => "Bandzul,Bandzulis,BandÅ¼ul,BandÅ¾ulis,Banjul,Banjulo,Banzhul,BanÄµulo,Bathurst,Mpanzoul,ban zhu er,banjul,banjuru,banjwl,bng'wl,ÎÏÎ±Î½Î¶Î¿ÏÎ»,ÐÐ°Ð½Ð¶ÑÐ»,ÐÐ°Ð½ÑÑÐ»,Ô²Õ¡Õ¶Õ»Õ¸ÖÕ¬,×× ×'××,Ø¨Ø§ÙØ¬ÙÙ,á£ááá,ãã³ã¸ã¥ã¼ã«,ç­ç å°,ç­ç ç¾,ë°ì¤,Banjul", :latitude => "13.45274", :longitude => "-16.57803").save
City.new(:country_id => "87", :name => "Bakau", :aliases => "Bakau,Bakau", :latitude => "13.47806", :longitude => "-16.68194").save
