City.new(:country_id => "40", :name => "West Island", :aliases => ",West Island", :latitude => "-12.15681", :longitude => "96.82251").save
