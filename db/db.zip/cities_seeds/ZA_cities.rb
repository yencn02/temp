City.new(:country_id => "247", :name => "Roodepoort", :aliases => "Roodepoort,Roodeport-Maraisburg,Roodepoort", :latitude => "-26.1625", :longitude => "27.8725").save
City.new(:country_id => "247", :name => "Zeerust", :aliases => "Zeerust,Zeerust", :latitude => "-25.53333", :longitude => "26.08333").save
City.new(:country_id => "247", :name => "Wolmaransstad", :aliases => "Wolmaransstad,Wolmaranstad,Wolmaransstad", :latitude => "-27.2", :longitude => "25.96667").save
City.new(:country_id => "247", :name => "White River", :aliases => "White River,Witrivier,White River", :latitude => "-25.31667", :longitude => "31.01667").save
City.new(:country_id => "247", :name => "Witbank", :aliases => ",Witbank", :latitude => "-25.86667", :longitude => "29.23333").save
City.new(:country_id => "247", :name => "Westonaria", :aliases => "Vestonarija,Westonaria,ÐÐµÑÑÐ¾Ð½Ð°ÑÐ¸Ñ,Westonaria", :latitude => "-26.31667", :longitude => "27.65").save
City.new(:country_id => "247", :name => "Wesselsbron", :aliases => "Wesselsbron,Wesselsbron", :latitude => "-27.85", :longitude => "26.36667").save
City.new(:country_id => "247", :name => "Welkom", :aliases => "Welkom,Welkom", :latitude => "-27.98333", :longitude => "26.73333").save
City.new(:country_id => "247", :name => "Warrenton", :aliases => "Warrenton,Warrenton", :latitude => "-28.11667", :longitude => "24.85").save
City.new(:country_id => "247", :name => "Warmbaths", :aliases => "Warmbad,Warmbaths,Warmbaths", :latitude => "-24.88333", :longitude => "28.28333").save
City.new(:country_id => "247", :name => "Vryheid", :aliases => "Vryheid,Vryheid", :latitude => "-27.76667", :longitude => "30.8").save
City.new(:country_id => "247", :name => "Vryburg", :aliases => "Frejburga,Vryburg,Ð¤ÑÐµÐ¹Ð±ÑÑÐ³Ð°,Vryburg", :latitude => "-26.95", :longitude => "24.73333").save
City.new(:country_id => "247", :name => "Volksrust", :aliases => "Volkrust,Volksrust,Volksrust", :latitude => "-27.36667", :longitude => "29.88333").save
City.new(:country_id => "247", :name => "Virginia", :aliases => "Virdzhinija,Virginia,ÐÐ¸ÑÐ´Ð¶Ð¸Ð½Ð¸Ñ,Virginia", :latitude => "-28.11667", :longitude => "26.9").save
City.new(:country_id => "247", :name => "Viljoenskroon", :aliases => "Viljoenskroon,Viljoenskroon", :latitude => "-27.21667", :longitude => "26.95").save
City.new(:country_id => "247", :name => "Vereeniging", :aliases => "Ferinikhing,Vereeniging,Ð¤ÐµÑÐ¸Ð½Ð¸ÑÐ¸Ð½Ð³,Vereeniging", :latitude => "-26.66667", :longitude => "27.93333").save
City.new(:country_id => "247", :name => "Vanderbijlpark", :aliases => "Vanderbijlpark,Vanderbijlpark", :latitude => "-26.7", :longitude => "27.81667").save
City.new(:country_id => "247", :name => "Upington", :aliases => "Upington,Upington", :latitude => "-28.45", :longitude => "21.25").save
City.new(:country_id => "247", :name => "Umtata", :aliases => "Umtata,Ð£Ð¼ÑÐ°ÑÐ°,Umtata", :latitude => "-31.58333", :longitude => "28.78333").save
City.new(:country_id => "247", :name => "Umkomaas", :aliases => "Umkomaas,Umkomaas", :latitude => "-30.2", :longitude => "30.8").save
City.new(:country_id => "247", :name => "Ulundi", :aliases => "Ulundi,Ð£Ð»ÑÐ½Ð´Ð¸,Ulundi", :latitude => "-28.33333", :longitude => "31.41667").save
City.new(:country_id => "247", :name => "Uitenhage", :aliases => "Uitenhage,Uitenhage", :latitude => "-33.76528", :longitude => "25.40222").save
City.new(:country_id => "247", :name => "Tzaneen", :aliases => "Tzaneen,Tzaneen", :latitude => "-23.83333", :longitude => "30.16667").save
City.new(:country_id => "247", :name => "Thohoyandou", :aliases => "Thohoyandou,Thohoyandou", :latitude => "-22.95", :longitude => "30.48333").save
City.new(:country_id => "247", :name => "Theunissen", :aliases => "Tenissen,Theunissen,Ð¢ÐµÐ½Ð¸ÑÑÐµÐ½,Theunissen", :latitude => "-28.4", :longitude => "26.71667").save
City.new(:country_id => "247", :name => "Thaba Nchu", :aliases => "Thaba Nchu,Thabantsjoe,Thaba Nchu", :latitude => "-29.21667", :longitude => "26.83333").save
City.new(:country_id => "247", :name => "Tembisa", :aliases => ",Tembisa", :latitude => "-25.99889", :longitude => "28.22694").save
City.new(:country_id => "247", :name => "Stutterheim", :aliases => "Stutterheim,Stutterheim", :latitude => "-32.56667", :longitude => "27.41667").save
City.new(:country_id => "247", :name => "Stilfontein", :aliases => ",Stilfontein", :latitude => "-26.85", :longitude => "26.78333").save
City.new(:country_id => "247", :name => "Stanger", :aliases => "KwaDukuza,Stanger,Stanger Station,Stanger", :latitude => "-29.33333", :longitude => "31.3").save
City.new(:country_id => "247", :name => "Standerton", :aliases => "Standerston,Standerton,Standerton", :latitude => "-26.95", :longitude => "29.25").save
City.new(:country_id => "247", :name => "Springs", :aliases => "Springs,Springs", :latitude => "-26.25", :longitude => "28.4").save
City.new(:country_id => "247", :name => "Soweto", :aliases => "Mpanzaville,Souehto,Sovetas,Soweto,swwtw,Ð¡Ð¾ÑÑÑÐ¾,×¡××××,Soweto", :latitude => "-26.26667", :longitude => "27.86667").save
City.new(:country_id => "247", :name => "Somerset East", :aliases => "Somerset East,Somerset-Oos,Somerset East", :latitude => "-32.71667", :longitude => "25.58333").save
City.new(:country_id => "247", :name => "Siyabuswa", :aliases => "Siyabuswa,Siyabuswa", :latitude => "-25.11667", :longitude => "29.05").save
City.new(:country_id => "247", :name => "Senekal", :aliases => "Senekal,Senekal", :latitude => "-28.31667", :longitude => "27.6").save
City.new(:country_id => "247", :name => "Secunda", :aliases => "Secunda,Sekunda,Ð¡ÐµÐºÑÐ½Ð´Ð°,Secunda", :latitude => "-26.55", :longitude => "29.16667").save
City.new(:country_id => "247", :name => "Scottburgh", :aliases => "Scottburg,Scottburgh,Scottsburgh,Scottburgh", :latitude => "-30.28333", :longitude => "30.75").save
City.new(:country_id => "247", :name => "Schweizer-Reineke", :aliases => "Schweizer-Reineke,Schweizer-Reneke,Schweizer-Reineke", :latitude => "-27.18333", :longitude => "25.33333").save
City.new(:country_id => "247", :name => "Sasolburg", :aliases => "Sasolburg,Sasolburg", :latitude => "-26.81358", :longitude => "27.81695").save
City.new(:country_id => "247", :name => "Rustenburg", :aliases => "Rustenburg,Ð ÑÑÑÐµÐ½Ð±ÑÑÐ³,Rustenburg", :latitude => "-25.66667", :longitude => "27.25").save
City.new(:country_id => "247", :name => "Richmond", :aliases => ",Richmond", :latitude => "-29.86667", :longitude => "30.26667").save
City.new(:country_id => "247", :name => "Richards Bay", :aliases => "Richards Bay,Richardsbaai,Richards Bay", :latitude => "-28.8", :longitude => "32.1").save
City.new(:country_id => "247", :name => "Reitz", :aliases => "Reitz,Reitz", :latitude => "-27.8", :longitude => "28.43333").save
City.new(:country_id => "247", :name => "Randfontein", :aliases => ",Randfontein", :latitude => "-26.1844", :longitude => "27.70203").save
City.new(:country_id => "247", :name => "Queenstown", :aliases => "Kvinstaun,Queenstown,ÐÐ²Ð¸Ð½ÑÑÐ°ÑÐ½,Queenstown", :latitude => "-31.9", :longitude => "26.88333").save
City.new(:country_id => "247", :name => "Queensdale", :aliases => ",Queensdale", :latitude => "-31.86667", :longitude => "26.98333").save
City.new(:country_id => "247", :name => "Pretoria", :aliases => "Cvaneo,Pretoria,Pretoria/Pole tou Akroteriou,Pretorija,PretÃ²ria,PretÃ³ria,Pta,Tshwane,brytwrya,peulitolia,phri thx reiy,prtwryh,puretoria,Ävaneo,Î ÏÎµÏÏÏÎ¹Î±/Î ÏÎ»Î· ÏÎ¿Ï ÎÎºÏÏÏÎ·ÏÎ¯Î¿Ï,ÐÑÐµÑÐ¾ÑÐ¸Ñ,ÐÑÐµÑÐ¾ÑÐ¸ÑÐ°,×¤×¨×××¨××,Ø¨Ø±ÙØªÙØ±ÙØ§,Ù¾Ø±ÛØªÙØ±ÙÙÛ,à¸à¸£à¸´à¸à¸­à¹à¸£à¸µà¸¢,ááªá¶áªá«,ãã¬ããªã¢,íë¦¬í ë¦¬ì,Pretoria", :latitude => "-25.74486", :longitude => "28.18783").save
City.new(:country_id => "247", :name => "Potgietersrus", :aliases => "Potgietersrus,Potgietersrust,Potgitersrus,ÐÐ¾ÑÐ³Ð¸ÑÐµÑÑÑÑÑ,Potgietersrus", :latitude => "-24.18333", :longitude => "29.01667").save
City.new(:country_id => "247", :name => "Potchefstroom", :aliases => "Pochefstrum,Potchefstroom,ÐÐ¾ÑÐµÑÑÑÑÑÐ¼,Potchefstroom", :latitude => "-26.71667", :longitude => "27.1").save
City.new(:country_id => "247", :name => "Port Shepstone", :aliases => "Port Shepstone,Port Shepstone", :latitude => "-30.75", :longitude => "30.45").save
City.new(:country_id => "247", :name => "Port Elizabeth", :aliases => "Port Elizabet,Port Elizabetas,Port Elizabeth,ÐÐ¾ÑÑ ÐÐ»Ð¸Ð·Ð°Ð±ÐµÑ,Port Elizabeth", :latitude => "-33.96667", :longitude => "25.58333").save
City.new(:country_id => "247", :name => "Port Alfred", :aliases => "Kowie,Port Alfred,The Kowie,Port Alfred", :latitude => "-33.6", :longitude => "26.9").save
City.new(:country_id => "247", :name => "Plettenberg Bay", :aliases => "Formosa,Plettenberg,Plettenberg Bay,Plettenbergbaai,Plettenberg Bay", :latitude => "-34.05", :longitude => "23.36667").save
City.new(:country_id => "247", :name => "Piet Retief", :aliases => "Piet Retief,Piet Retief", :latitude => "-27", :longitude => "30.8").save
City.new(:country_id => "247", :name => "Polokwane", :aliases => "Pietersburg,Polokvane,PolokvanÄ,Polokwane,ÐÐ¾Ð»Ð¾ÐºÐ²Ð°Ð½Ðµ,Polokwane", :latitude => "-23.9", :longitude => "29.45").save
City.new(:country_id => "247", :name => "Pietermaritzburg", :aliases => "Maritzburg,Pietermaritsburg,Pietermaritzburg,Pitermaricburg,Pitermaricburgas,ÐÐ¸ÑÐµÑÐ¼Ð°ÑÐ¸ÑÐ±ÑÑÐ³,Pietermaritzburg", :latitude => "-29.61667", :longitude => "30.38333").save
City.new(:country_id => "247", :name => "Phuthaditjhaba", :aliases => "Phutaditjhaba,Phuthaditjhaba,Phuthaditjhaba", :latitude => "-28.53333", :longitude => "28.81667").save
City.new(:country_id => "247", :name => "Phalaborwa", :aliases => "Palabora,Palaborva,Phalaborwa,ÐÐ°Ð»Ð°Ð±Ð¾ÑÐ²Ð°,Phalaborwa", :latitude => "-23.95", :longitude => "31.11667").save
City.new(:country_id => "247", :name => "Parys", :aliases => "Paris,Parys,ÐÐ°ÑÐ¸Ñ,Parys", :latitude => "-26.9", :longitude => "27.45").save
City.new(:country_id => "247", :name => "Pampierstad", :aliases => "Pampierstad,Pampierstat,Pampierstad", :latitude => "-27.78333", :longitude => "24.68333").save
City.new(:country_id => "247", :name => "Oudtshoorn", :aliases => "Oudtshoorn,Oudtshoorn", :latitude => "-33.59067", :longitude => "22.2014").save
City.new(:country_id => "247", :name => "Orkney", :aliases => "Eastleigh,Orknejskie,Orkney,ÐÑÐºÐ½ÐµÐ¹ÑÐºÐ¸Ðµ,Orkney", :latitude => "-26.98333", :longitude => "26.66667").save
City.new(:country_id => "247", :name => "Nylstroom", :aliases => "Nylstroom,Nylstroom", :latitude => "-24.7", :longitude => "28.4").save
City.new(:country_id => "247", :name => "Nkowakowa", :aliases => ",Nkowakowa", :latitude => "-23.88333", :longitude => "30.28333").save
City.new(:country_id => "247", :name => "Nigel", :aliases => "Najdzhel,Nigel,ÐÐ°Ð¹Ð´Ð¶ÐµÐ»,Nigel", :latitude => "-26.41667", :longitude => "28.46667").save
City.new(:country_id => "247", :name => "Newcastle", :aliases => "Newcastle,Newcastle", :latitude => "-27.75", :longitude => "29.93333").save
City.new(:country_id => "247", :name => "Nelspruit", :aliases => "Nelspruit,Nelsprutas,nerusupuroito,ÐÐµÐ»ÑÐ¿ÑÑÐ¸Ñ,ãã«ã¹ãã­ã¤ã,Nelspruit", :latitude => "-25.46667", :longitude => "30.96667").save
City.new(:country_id => "247", :name => "Mpumalanga", :aliases => ",Mpumalanga", :latitude => "-29.81667", :longitude => "30.61667").save
City.new(:country_id => "247", :name => "Mpophomeni", :aliases => ",Mpophomeni", :latitude => "-29.56667", :longitude => "30.2").save
City.new(:country_id => "247", :name => "Mondlo", :aliases => ",Mondlo", :latitude => "-27.98333", :longitude => "30.71667").save
City.new(:country_id => "247", :name => "Mmabatho", :aliases => "Mabatho,Mbabatho,Mmabatho,Mmabatho", :latitude => "-25.85", :longitude => "25.63333").save
City.new(:country_id => "247", :name => "Middelburg", :aliases => ",Middelburg", :latitude => "-31.48333", :longitude => "25.01667").save
City.new(:country_id => "247", :name => "Middelburg", :aliases => "Middelberg,Middelburg,Middelburg", :latitude => "-25.78333", :longitude => "29.46667").save
City.new(:country_id => "247", :name => "Messina", :aliases => ",Messina", :latitude => "-22.35", :longitude => "30.05").save
City.new(:country_id => "247", :name => "Margate", :aliases => "Berkleys,Margate,Margate No. 4,Margate", :latitude => "-30.85", :longitude => "30.36667").save
City.new(:country_id => "247", :name => "Mabopane", :aliases => ",Mabopane", :latitude => "-25.50722", :longitude => "28.1075").save
City.new(:country_id => "247", :name => "Lydenburg", :aliases => "Lydenburg,Lydenburg", :latitude => "-25.1", :longitude => "30.45").save
City.new(:country_id => "247", :name => "Louis Trichardt", :aliases => "Louis Trichardt,Louis Trichardt", :latitude => "-23.05", :longitude => "29.9").save
City.new(:country_id => "247", :name => "Lichtenburg", :aliases => "Lichtenburg,Likhtenburge,ÐÐ¸ÑÑÐµÐ½Ð±ÑÑÐ³Ðµ,Lichtenburg", :latitude => "-26.15", :longitude => "26.16667").save
City.new(:country_id => "247", :name => "Lebowakgomo", :aliases => "Lebowakgomo,Lebowakgomo", :latitude => "-24.2", :longitude => "29.5").save
City.new(:country_id => "247", :name => "Lady Frere", :aliases => ",Lady Frere", :latitude => "-31.7", :longitude => "27.23333").save
City.new(:country_id => "247", :name => "Ladybrand", :aliases => "Ladybrand,Ladybrand", :latitude => "-29.2", :longitude => "27.45").save
City.new(:country_id => "247", :name => "Kutloanong", :aliases => ",Kutloanong", :latitude => "-27.83333", :longitude => "26.75").save
City.new(:country_id => "247", :name => "Kruisfontein", :aliases => ",Kruisfontein", :latitude => "-34", :longitude => "24.73333").save
City.new(:country_id => "247", :name => "Krugersdorp", :aliases => "Krjugersdorpa,Krugersdorp,Krugersdorpas,ÐÑÑÐ³ÐµÑÑÐ´Ð¾ÑÐ¿Ð°,Krugersdorp", :latitude => "-26.1", :longitude => "27.76667").save
City.new(:country_id => "247", :name => "Kroonstad", :aliases => "Kroonstad,Kroonstad", :latitude => "-27.65", :longitude => "27.23333").save
City.new(:country_id => "247", :name => "Kriel", :aliases => ",Kriel", :latitude => "-26.26667", :longitude => "29.23333").save
City.new(:country_id => "247", :name => "Komatipoort", :aliases => "Komatipoort,Komatipoort", :latitude => "-25.43333", :longitude => "31.93333").save
City.new(:country_id => "247", :name => "Kokstad", :aliases => ",Kokstad", :latitude => "-30.55", :longitude => "29.41667").save
City.new(:country_id => "247", :name => "Knysna", :aliases => "De Nysna,Knysna,Knysna", :latitude => "-34.03627", :longitude => "23.04713").save
City.new(:country_id => "247", :name => "Klerksdorp", :aliases => "Klerksdorp,ÐÐ»ÐµÑÐºÑÐ´Ð¾ÑÐ¿,Klerksdorp", :latitude => "-26.86667", :longitude => "26.66667").save
City.new(:country_id => "247", :name => "Kimberley", :aliases => "Kimberley,Kimberli,Kimberlis,kimbeolli,ÐÐ¸Ð¼Ð±ÐµÑÐ»Ð¸,í´ë²ë¦¬,Kimberley", :latitude => "-28.73333", :longitude => "24.76667").save
City.new(:country_id => "247", :name => "Johannesburg", :aliases => "EGoli,IGoli,Jo'anna,Joanesburgo,Joburg,Johanesburgas,Johanesburgo,Johannesarborg,Johannesbourg,Johannesburg,Johannesburgo,Jokhanesburg,Jokhanezburg,Jokhannesburg,JÂ·ohanesbÃ´rg,JÃ³hannesarborg,jwhansbrgh,yohaneseubeogeu,yohanesuburugu,yue han nei si bao,ywhnsbwrg,zhwhansbwrg,ÐÐ¾ÑÐ°Ð½ÐµÐ·Ð±ÑÑÐ³,ÐÐ¾ÑÐ°Ð½ÐµÑÐ±ÑÑÐ³,ÐÐ¾ÑÐ°Ð½ÐµÑÐ±ÑÑÐ³,ÐÐ¾ÑÐ°Ð½Ð½ÐµÑÐ±ÑÑÐ³,×××× ×¡×××¨×,Ø¬ÙÙØ§ÙØ³Ø¨Ø±Øº,ÙÙÚ¾Ø§ÙÙÛØ³Ø¨ÛØ±Ú¯,ÚÙÙØ§ÙØ³Ø¨ÙØ±Ú¯,ã¨ããã¹ãã«ã°,çº¦ç¿°åæ¯å ¡,ìíë¤ì¤ë²ê·¸,Johannesburg", :latitude => "-26.20227", :longitude => "28.04363").save
City.new(:country_id => "247", :name => "Howick", :aliases => "Howick,Howick", :latitude => "-29.46667", :longitude => "30.23333").save
City.new(:country_id => "247", :name => "Hennenman", :aliases => "Hennenman,Hennenman", :latitude => "-27.96667", :longitude => "27.03333").save
City.new(:country_id => "247", :name => "Hendrina", :aliases => ",Hendrina", :latitude => "-26.15", :longitude => "29.71667").save
City.new(:country_id => "247", :name => "Heilbron", :aliases => ",Heilbron", :latitude => "-27.28333", :longitude => "27.96667").save
City.new(:country_id => "247", :name => "Heidelberg", :aliases => "Gejdel'berg,Heidelberg,Heidelburg,ÐÐµÐ¹Ð´ÐµÐ»ÑÐ±ÐµÑÐ³,Heidelberg", :latitude => "-26.5", :longitude => "28.35").save
City.new(:country_id => "247", :name => "Harrismith", :aliases => "Harrismith,Harrismith", :latitude => "-28.28333", :longitude => "29.13333").save
City.new(:country_id => "247", :name => "Grahamstown", :aliases => "Grahamstad,Grahamstown,Grahamstown", :latitude => "-33.3", :longitude => "26.53333").save
City.new(:country_id => "247", :name => "Graaff-Reinet", :aliases => "Graaf Reinet,Graaff Reinet,Graaff-Reinet,Graaff-Reinet", :latitude => "-32.25215", :longitude => "24.53075").save
City.new(:country_id => "247", :name => "Giyani", :aliases => "Giyane,Giyani,Giyani", :latitude => "-23.31667", :longitude => "30.71667").save
City.new(:country_id => "247", :name => "George", :aliases => "Dzhordzh,George,ÐÐ¶Ð¾ÑÐ´Ð¶,George", :latitude => "-33.96667", :longitude => "22.45").save
City.new(:country_id => "247", :name => "Ga-Rankuwa", :aliases => ",Ga-Rankuwa", :latitude => "-25.61667", :longitude => "27.98333").save
City.new(:country_id => "247", :name => "Frankfort", :aliases => ",Frankfort", :latitude => "-27.26667", :longitude => "28.48333").save
City.new(:country_id => "247", :name => "Fort Beaufort", :aliases => "Fort Beaufort,Fort Beaufort", :latitude => "-32.78333", :longitude => "26.63333").save
City.new(:country_id => "247", :name => "Fochville", :aliases => "Fochville,Fochville", :latitude => "-26.48333", :longitude => "27.5").save
City.new(:country_id => "247", :name => "eSikhawini", :aliases => "Esikhawini Township,eSikhawini,eSikhawini", :latitude => "-28.88333", :longitude => "31.9").save
City.new(:country_id => "247", :name => "Ermelo", :aliases => "Ehrmelo,Ermelo,Ð­ÑÐ¼ÐµÐ»Ð¾,Ermelo", :latitude => "-26.53333", :longitude => "29.98333").save
City.new(:country_id => "247", :name => "Empangeni", :aliases => "Empangeni,Empangeni", :latitude => "-28.75", :longitude => "31.9").save
City.new(:country_id => "247", :name => "eMbalenhle", :aliases => ",eMbalenhle", :latitude => "-26.53333", :longitude => "29.06667").save
City.new(:country_id => "247", :name => "Ellisras", :aliases => ",Ellisras", :latitude => "-23.66667", :longitude => "27.73333").save
City.new(:country_id => "247", :name => "East London", :aliases => "Buffalo City,East London,Oos Londen,Oost-Londen,Yst Londonas,East London", :latitude => "-33.01529", :longitude => "27.91162").save
City.new(:country_id => "247", :name => "Durban", :aliases => "Durban,Durbanas,IThekwini,Port Natal,daban,de ban,ÐÑÑÐ±Ð°Ð½,ÚØ±Ø¨Ù,ãã¼ãã³,å¾·ç­,Durban", :latitude => "-29.85", :longitude => "31.01667").save
City.new(:country_id => "247", :name => "Dundee", :aliases => "Dandi,Dundee,ÐÐ°Ð½Ð´Ð¸,Dundee", :latitude => "-28.16667", :longitude => "30.23333").save
City.new(:country_id => "247", :name => "Duiwelskloof", :aliases => "Duivelskloof,Duiwelskloof,Duweiskloof,Duiwelskloof", :latitude => "-23.7", :longitude => "30.13333").save
City.new(:country_id => "247", :name => "Driefontein", :aliases => ",Driefontein", :latitude => "-27.01667", :longitude => "30.45").save
City.new(:country_id => "247", :name => "Delmas", :aliases => "Del'mas,Delmas,ÐÐµÐ»ÑÐ¼Ð°Ñ,Delmas", :latitude => "-26.15", :longitude => "28.68333").save
City.new(:country_id => "247", :name => "De Aar", :aliases => "De Aar,De Aar", :latitude => "-30.65", :longitude => "24.01667").save
City.new(:country_id => "247", :name => "Cullinan", :aliases => "Cullinan,Kullinan,ÐÑÐ»Ð»Ð¸Ð½Ð°Ð½,Cullinan", :latitude => "-25.67556", :longitude => "28.52222").save
City.new(:country_id => "247", :name => "Cradock", :aliases => "Cradock,Cradock", :latitude => "-32.18333", :longitude => "25.61667").save
City.new(:country_id => "247", :name => "Christiana", :aliases => ",Christiana", :latitude => "-27.91667", :longitude => "25.16667").save
City.new(:country_id => "247", :name => "Carletonville", :aliases => "Carletonville,Carletonville", :latitude => "-26.36667", :longitude => "27.4").save
City.new(:country_id => "247", :name => "Butterworth", :aliases => "Battervorta,Butterworth,Gcuwa,ÐÐ°ÑÑÐµÑÐ²Ð¾ÑÑÐ°,Butterworth", :latitude => "-32.33333", :longitude => "28.15").save
City.new(:country_id => "247", :name => "Bronkhorstspruit", :aliases => "Bronkhorstspruit,Erasmus,Bronkhorstspruit", :latitude => "-25.80833", :longitude => "28.74056").save
City.new(:country_id => "247", :name => "Brits", :aliases => "Britancy,Brits,ÐÑÐ¸ÑÐ°Ð½ÑÑ,Brits", :latitude => "-25.63333", :longitude => "27.78333").save
City.new(:country_id => "247", :name => "Brakpan", :aliases => "Brakpan,Brakpan", :latitude => "-26.23333", :longitude => "28.36667").save
City.new(:country_id => "247", :name => "Botshabelo", :aliases => ",Botshabelo", :latitude => "-29.23333", :longitude => "26.73333").save
City.new(:country_id => "247", :name => "Bothaville", :aliases => "Botavill',Bothaville,ÐÐ¾ÑÐ°Ð²Ð¸Ð»Ð»Ñ,Bothaville", :latitude => "-27.36667", :longitude => "26.61667").save
City.new(:country_id => "247", :name => "Boksburg", :aliases => "Boksburg,Boksburg", :latitude => "-26.21667", :longitude => "28.25").save
City.new(:country_id => "247", :name => "Bloemhof", :aliases => ",Bloemhof", :latitude => "-27.65", :longitude => "25.6").save
City.new(:country_id => "247", :name => "Bloemfontein", :aliases => "Bloemfontein,Blumfonteinas,Blumfontejn,Mploumphontein,blwmpwntyyn,bu long fang dan,burumufonten,ÎÏÎ»Î¿ÏÎ¼ÏÎ¿Î½ÏÎ­Î¹Î½,ÐÐ»ÑÐ¼ÑÐ¾Ð½ÑÐµÐ¹Ð½,ÐÐ»ÑÐ¼ÑÐ¾Ð½ÑÐµÑÐ½,×××××¤×× ××××,ãã«ã¼ã ãã©ã³ãã¼ã³,å¸éæ¹ä¸¹,Bloemfontein", :latitude => "-29.13333", :longitude => "26.2").save
City.new(:country_id => "247", :name => "Bhisho", :aliases => "Bhisho,Bisho,Biso,BiÅ¡o,ÐÐ¸ÑÐ¾,Bhisho", :latitude => "-32.86667", :longitude => "27.43333").save
City.new(:country_id => "247", :name => "Bethlehem", :aliases => "Bethlehem,Vifleem,ÐÐ¸ÑÐ»ÐµÐµÐ¼,Bethlehem", :latitude => "-28.23333", :longitude => "28.3").save
City.new(:country_id => "247", :name => "Bethal", :aliases => ",Bethal", :latitude => "-26.45", :longitude => "29.46667").save
City.new(:country_id => "247", :name => "Benoni", :aliases => "Benoni,Benoni", :latitude => "-26.18333", :longitude => "28.31667").save
City.new(:country_id => "247", :name => "Beaufort West", :aliases => "Beaufort West,Beaufort-Wes,Beaufort West", :latitude => "-32.35", :longitude => "22.58333").save
City.new(:country_id => "247", :name => "Barberton", :aliases => "Barberton,Barberton", :latitude => "-25.78333", :longitude => "31.05").save
City.new(:country_id => "247", :name => "Ballitoville", :aliases => ",Ballitoville", :latitude => "-29.55", :longitude => "31.2").save
City.new(:country_id => "247", :name => "Balfour", :aliases => "Bal'fur,Balfour,ÐÐ°Ð»ÑÑÑÑ,Balfour", :latitude => "-26.65", :longitude => "28.58333").save
City.new(:country_id => "247", :name => "Allanridge", :aliases => "Allanridge,Allanridge", :latitude => "-27.75", :longitude => "26.66667").save
City.new(:country_id => "247", :name => "Aliwal North", :aliases => "Aliwal North,Aliwal-Noord,Aliwal North", :latitude => "-30.7", :longitude => "26.7").save
City.new(:country_id => "247", :name => "Ekangala", :aliases => ",Ekangala", :latitude => "-25.69444", :longitude => "28.74833").save
City.new(:country_id => "247", :name => "Midrand", :aliases => "Midrand,ÐÐ¸Ð´ÑÐ°Ð½Ð´,Midrand", :latitude => "-25.96361", :longitude => "28.13778").save
City.new(:country_id => "247", :name => "Centurion", :aliases => "Centurion,Verwoerdburg,centurion,Ð¦ÐµÐ½ÑÑÑÐ¸Ð¾Ð½,Centurion", :latitude => "-25.87444", :longitude => "28.17056").save
City.new(:country_id => "247", :name => "Worcester", :aliases => "Vuster,Worcester,ÐÑÑÑÐµÑ,Worcester", :latitude => "-33.65", :longitude => "19.43333").save
City.new(:country_id => "247", :name => "Stellenbosch", :aliases => "Stellenbos,Stellenbosch,Ð¡ÑÐµÐ»Ð»ÐµÐ½Ð±Ð¾Ñ,Stellenbosch", :latitude => "-33.93333", :longitude => "18.85").save
City.new(:country_id => "247", :name => "Saldanha", :aliases => "Hoedjes Bay,Hoedjesbaai,Hoetjes Bay,Saldana,Saldanha,Ð¡Ð°Ð»Ð´Ð°Ð½Ð°,Saldanha", :latitude => "-33.01667", :longitude => "17.95").save
City.new(:country_id => "247", :name => "Noorder-Paarl", :aliases => ",Noorder-Paarl", :latitude => "-33.71667", :longitude => "18.96667").save
City.new(:country_id => "247", :name => "Malmesbury", :aliases => ",Malmesbury", :latitude => "-33.4608", :longitude => "18.72714").save
City.new(:country_id => "247", :name => "Hermanus", :aliases => "Hermanus,Mpumalanga,ÐÐ¿ÑÐ¼Ð°Ð»Ð°Ð½Ð³Ð°,Hermanus", :latitude => "-34.41667", :longitude => "19.23333").save
City.new(:country_id => "247", :name => "Grabouw", :aliases => "Grabouw,Grabouw", :latitude => "-34.15", :longitude => "19.01667").save
City.new(:country_id => "247", :name => "Ceres", :aliases => "Cerera,Ceres,Ð¦ÐµÑÐµÑÐ°,Ceres", :latitude => "-33.36667", :longitude => "19.31667").save
City.new(:country_id => "247", :name => "Cape Town", :aliases => "Cape Town,Cidade do Cabo,Cidade do Cabo - Cape Town,Citta del Capo,CittÃ  del Capo,Ciuda del Cabu,Ciudad del Cabo,CiudÃ¡ del Cabu,Ciutat del Cap,El Cabo,Fokvaros,FokvÃ¡ros,Hoefdaborg,HÃ¶fÃ°aborg,IKapa,Kaapstad,Kaburbo,Kapkaupunki,Kaplinn,Kapske Mesto,KapskÃ© Mesto,KapskÃ© MÄsto,Kapstad,Kapstaden,Kapstadt,Kapsztad,Keiptauna,Keiptaunas,Kejptaun,Le Cap,Lo Cap,Lurmutur Hiria,LÃ© Cap,Tref y Penrhyn,iKapa,kai pu dun,keipeutaun,keputaun,kyb tawn,ÐÐµÐ¹Ð¿ÑÐ°ÑÐ½,ÐÐµÑÐ¿ÑÐ°ÑÐ½,×§×××¤××××,ÙØ§Ù¾ÛØªÙÛÙ,ÙÙØ¨ ØªØ§ÙÙ,ã±ã¼ãã¿ã¦ã³,éæ®æ¦,ì¼ì´ííì´,Cape Town", :latitude => "-33.91667", :longitude => "18.41667").save
City.new(:country_id => "247", :name => "Atlantis", :aliases => "Atlantida,Atlantis,ÐÑÐ»Ð°Ð½ÑÐ¸Ð´Ð°,Atlantis", :latitude => "-33.56667", :longitude => "18.48333").save
