City.new(:country_id => "28", :name => "Gustavia", :aliases => "Gustaf,Guthavia,Gustavia", :latitude => "17.89618", :longitude => "-62.84978").save
