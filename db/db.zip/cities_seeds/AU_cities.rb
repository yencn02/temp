City.new(:country_id => "15", :name => "Whyalla", :aliases => "Whyalla,Whyalla", :latitude => "-33.03333", :longitude => "137.58333").save
City.new(:country_id => "15", :name => "Roebourne", :aliases => "Roebourne,Roebourne", :latitude => "-20.78333", :longitude => "117.13333").save
City.new(:country_id => "15", :name => "Perth", :aliases => "Peairt,Pert,Pertas,Perth,Perth City,Perthia,Purt,byrth,pasu,pert,po si,prt,prt',ÐÐµÑÑ,ÐÑÑÑ,×¤×¨×ª',Ø¨ÙØ±Ø«,Ù¾Ø±Øª,à®ªà¯à®°à¯à®¤à¯,ãã¼ã¹,çæ¯,Perth", :latitude => "-31.93333", :longitude => "115.83333").save
City.new(:country_id => "15", :name => "Murray Bridge", :aliases => "Murray Bridge,Murrej Bridzh,ÐÑÑÑÐµÐ¹ ÐÑÐ¸Ð´Ð¶,Murray Bridge", :latitude => "-35.11667", :longitude => "139.26667").save
City.new(:country_id => "15", :name => "Mount Isa", :aliases => "Mont Isa,Mount Isa,Mt Isa,Mt. Isa,Mount Isa", :latitude => "-20.73333", :longitude => "139.5").save
City.new(:country_id => "15", :name => "Morphett Vale", :aliases => ",Morphett Vale", :latitude => "-35.13333", :longitude => "138.51667").save
City.new(:country_id => "15", :name => "Mandurah", :aliases => "Mandujura,Mandurah,ÐÐ°Ð½Ð´ÑÑÑÐ°,Mandurah", :latitude => "-32.55", :longitude => "115.7").save
City.new(:country_id => "15", :name => "Kwinana", :aliases => "Kwinana,Kwinana", :latitude => "-32.25", :longitude => "115.76667").save
City.new(:country_id => "15", :name => "Kalgoorlie", :aliases => "Kalgoorlie,Kalgoorlie-Boulder,Kalgurli,ÐÐ°Ð»Ð³ÑÑÐ»Ð¸,Kalgoorlie", :latitude => "-30.75", :longitude => "121.46667").save
City.new(:country_id => "15", :name => "Gosnells", :aliases => "Gosnells,Gosnells", :latitude => "-32.08333", :longitude => "116").save
City.new(:country_id => "15", :name => "Geraldton", :aliases => "Dzheraldton,Geraldton,ÐÐ¶ÐµÑÐ°Ð»Ð´ÑÐ¾Ð½,Geraldton", :latitude => "-28.76667", :longitude => "114.6").save
City.new(:country_id => "15", :name => "Gawler", :aliases => "Gawler,Gawler", :latitude => "-34.6", :longitude => "138.73333").save
City.new(:country_id => "15", :name => "Darwin", :aliases => "Darvin,Darvino,Darwin,Palmerston,Port Darwin,da er wen gang,dau~in,drwwyn,tarvin,ÐÐ°ÑÐ²Ð¸Ð½,××¨××××,à®à®¾à®°à¯à®µà®¿à®©à¯,ãã¼ã¦ã£ã³,è¾¾å°ææ¸¯,Darwin", :latitude => "-12.46113", :longitude => "130.84185").save
City.new(:country_id => "15", :name => "Bunbury", :aliases => "Banberi,Bunbury,ÐÐ°Ð½Ð±ÐµÑÐ¸,Bunbury", :latitude => "-33.33333", :longitude => "115.63333").save
City.new(:country_id => "15", :name => "Alice Springs", :aliases => "Alice Springs,Alice Springs Region,Alis-Springs,Springs,Stuart,ai li si quan,arisusupuringusu,ÐÐ»Ð¸Ñ-Ð¡Ð¿ÑÐ¸Ð½Ð³Ñ,ã¢ãªã¹ã¹ããªã³ã°ã¹,æéºæ¯æ³,Alice Springs", :latitude => "-23.7", :longitude => "133.88333").save
City.new(:country_id => "15", :name => "Albany", :aliases => "Albany,Olbani,ÐÐ»Ð±Ð°Ð½Ð¸,Albany", :latitude => "-35.01694", :longitude => "117.89167").save
City.new(:country_id => "15", :name => "Adelaide", :aliases => "Adelaida,Adelaidae,Adelaide,AdelaidÄ,Adelajda,Adelajdo,Adelayde,AdelaÃ¯da,Adelejd,Adelhaidis,AdelÃ ida,AdÃ©laydÃ©,AdÃ©laÃ¯de,Edelaid,Gorad Adehlaida,Tarndanya,Tarndarnya,a de lai de,adelaida,aderedo,adiled,adlayd,adylyd,aedaleda,aedeulleideu,atileyit,edileda,ÎÎ´ÎµÎ»Î±ÎÎ´Î±,ÐÐ´ÐµÐ»Ð°Ð¸Ð´Ã¦,ÐÐ´ÐµÐ»Ð°Ð¸Ð´Ð°,ÐÐ´ÐµÐ»Ð°ÑÐ´Ð°,ÐÐ´ÐµÐ»ÐµÐ¹Ð´,ÐÐ´ÐµÐ»ÐµÑÐ´,ÐÐ¾ÑÐ°Ð´ ÐÐ´ÑÐ»Ð°ÑÐ´Ð°,Ô±Õ¤Õ¥Õ¬Õ¡Õ«Õ¤Õ¡,××××××,Ø¢Ø¯ÙØ§ÛØ¯,Ø£Ø¯ÙÙÙØ¯,Ø§ÛÚÛÙÛÚ,à¤à¥à¤¡à¤²à¥à¤¡,à¤à¤¡à¤¿à¤²à¥à¤¡,à®à®à®¿à®²à¯à®¯à®¿à®à¯,à²à²¡à²¿à²²à³à²¡à³,à¹à¸­à¸à¸´à¹à¸¥à¸,áááááááá,ã¢ãã¬ã¼ã,é¿å¾·æ¥å¾,é¿å¾·è±å¾·,ì ë¤ë ì´ë,Adelaide", :latitude => "-34.93333", :longitude => "138.6").save
City.new(:country_id => "15", :name => "Wodonga", :aliases => "Wodonga,Wodonga", :latitude => "-36.11667", :longitude => "146.88333").save
City.new(:country_id => "15", :name => "Warrnambool", :aliases => "Warrnambool,Warrnambool", :latitude => "-38.38333", :longitude => "142.48333").save
City.new(:country_id => "15", :name => "Wagga Wagga", :aliases => "Uogga Uogga,Wagga,Wagga Wagga,Ð£Ð¾Ð³Ð³Ð° Ð£Ð¾Ð³Ð³Ð°,Wagga Wagga", :latitude => "-35.11667", :longitude => "147.36667").save
City.new(:country_id => "15", :name => "Traralgon", :aliases => "Traralgon,Traralgon", :latitude => "-38.18333", :longitude => "146.53333").save
City.new(:country_id => "15", :name => "Townsville", :aliases => "Townsville,taunzuvu~iru,ã¿ã¦ã³ãºã´ã£ã«,Townsville", :latitude => "-19.25", :longitude => "146.8").save
City.new(:country_id => "15", :name => "Torquay", :aliases => ",Torquay", :latitude => "-25.28333", :longitude => "152.86667").save
City.new(:country_id => "15", :name => "Toowoomba", :aliases => "Toowoomba,Tuvumba,Ð¢ÑÐ²ÑÐ¼Ð±Ð°,Toowoomba", :latitude => "-27.55", :longitude => "151.96667").save
City.new(:country_id => "15", :name => "Taree", :aliases => "Taree,Tari,Ð¢Ð°ÑÐ¸,Taree", :latitude => "-31.9", :longitude => "152.46667").save
City.new(:country_id => "15", :name => "Tamworth", :aliases => "Tamuort,Tamworth,Ð¢Ð°Ð¼ÑÐ¾ÑÑ,Tamworth", :latitude => "-31.1", :longitude => "150.93333").save
City.new(:country_id => "15", :name => "Sydney", :aliases => "Sanctus Dionysius,Sanctus Dyonisius,Sidnej,Sidneja,Sidnejo,Sidnejus,Sidney,Sidni,SidnÄjus,Syd,Sydney,Sydney City,SÃ­dney,citni,shidoni,sidani,sideuni,sidniy,sydny,xi ni,Ð¡Ð¸Ð´Ð½ÐµÐ¹,Ð¡Ð¸Ð´Ð½ÐµÑ,Ð¡Ð¸Ð´Ð½Ð¸,Ð¡ÑÐ´Ð½ÐµÐ¹,×¡××× ×,Ø³ÙØ¯ÙÛÙ,Ø³ÙØ¯ÙÙ,Ø³ÛØ¯ÙÛ,à¤¸à¤¿à¤¡à¤¨à¥,à®à®¿à®à¯à®©à®¿,à¸à¸´à¸à¸à¸µà¸¢à¹,à½¦à½²à½à¼à½à½²à½¦,ã·ããã¼,æå°¼,ìëë,Sydney", :latitude => "-33.86785", :longitude => "151.20732").save
City.new(:country_id => "15", :name => "Surfers Paradise", :aliases => "Sjorfers Paradajz,Surfers Paradise,Ð¡ÑÑÑÐµÑÑ ÐÐ°ÑÐ°Ð´Ð°Ð¹Ð·,Surfers Paradise", :latitude => "-28.00274", :longitude => "153.42999").save
City.new(:country_id => "15", :name => "Sunnybank", :aliases => ",Sunnybank", :latitude => "-27.58333", :longitude => "153.05").save
City.new(:country_id => "15", :name => "Sunbury", :aliases => "Sunbury,Sunbury", :latitude => "-37.58333", :longitude => "144.73333").save
City.new(:country_id => "15", :name => "Port Stephens", :aliases => "Port Stephen,Port Stephens", :latitude => "-32.6966", :longitude => "152.06348").save
City.new(:country_id => "15", :name => "Southport", :aliases => "Southport,Southport", :latitude => "-27.96667", :longitude => "153.4").save
City.new(:country_id => "15", :name => "South Grafton", :aliases => ",South Grafton", :latitude => "-29.7", :longitude => "152.95").save
City.new(:country_id => "15", :name => "Shepparton", :aliases => "Shepparton,Ð¨ÐµÐ¿Ð¿Ð°ÑÑÐ¾Ð½,Shepparton", :latitude => "-36.38333", :longitude => "145.4").save
City.new(:country_id => "15", :name => "Rockhampton", :aliases => "Rockhampton,Rokkhempton,Ð Ð¾ÐºÑÐµÐ¼Ð¿ÑÐ¾Ð½,Rockhampton", :latitude => "-23.38333", :longitude => "150.5").save
City.new(:country_id => "15", :name => "Queanbeyan", :aliases => "Kuinbejan,Queanbeyan,ÐÑÐ¸Ð½Ð±ÐµÑÐ½,Queanbeyan", :latitude => "-35.35", :longitude => "149.23333").save
City.new(:country_id => "15", :name => "Quakers Hill", :aliases => ",Quakers Hill", :latitude => "-33.73333", :longitude => "150.88333").save
City.new(:country_id => "15", :name => "Port Macquarie", :aliases => "Port Macquarie,Port Makkuori,ÐÐ¾ÑÑ ÐÐ°ÐºÐºÑÐ¾ÑÐ¸,Port Macquarie", :latitude => "-31.43333", :longitude => "152.91667").save
City.new(:country_id => "15", :name => "Orange", :aliases => "Orandzh,Orange,ÐÑÐ°Ð½Ð´Ð¶,Orange", :latitude => "-33.28333", :longitude => "149.1").save
City.new(:country_id => "15", :name => "Nowra", :aliases => "Novra,Nowra,ÐÐ¾Ð²ÑÐ°,Nowra", :latitude => "-34.88333", :longitude => "150.6").save
City.new(:country_id => "15", :name => "Newcastle", :aliases => "N'jukasl,Newcastle,Novkastelo,niu ka si er,nyukassuru,ÐÑÑÐºÐ°ÑÐ»,ãã¥ã¼ã«ãã¹ã«,çº½å¡æ¯å°,Newcastle", :latitude => "-32.92715", :longitude => "151.77647").save
City.new(:country_id => "15", :name => "Nerang", :aliases => "Nerang,Nerang", :latitude => "-27.98333", :longitude => "153.33333").save
City.new(:country_id => "15", :name => "Mount Gambier", :aliases => "Gambier Town,Maunt Gambier,Mont Gambier,Mount Gambier,Mt Gambier,Mt. Gambier,ÐÐ°ÑÐ½Ñ ÐÐ°Ð¼Ð±Ð¸ÐµÑ,Mount Gambier", :latitude => "-37.83333", :longitude => "140.76667").save
City.new(:country_id => "15", :name => "Mosman", :aliases => "Mosman,Mosman", :latitude => "-33.82778", :longitude => "151.23333").save
City.new(:country_id => "15", :name => "Mornington", :aliases => "Mornington,ÐÐ¾ÑÐ½Ð¸Ð½Ð³ÑÐ¾Ð½,Mornington", :latitude => "-38.21667", :longitude => "145.03333").save
City.new(:country_id => "15", :name => "Mooloolaba", :aliases => "Alexandra-Mooloolaba,Mooloolaba,Mululaba,ÐÑÐ»ÑÐ»Ð°Ð±Ð°,Mooloolaba", :latitude => "-26.68333", :longitude => "153.11667").save
City.new(:country_id => "15", :name => "Mildura", :aliases => "Mild'jura,Mildura,ÐÐ¸Ð»Ð´ÑÑÑÐ°,Mildura", :latitude => "-34.2", :longitude => "142.15").save
City.new(:country_id => "15", :name => "Melton", :aliases => "Melton,ÐÐµÐ»ÑÐ¾Ð½,Melton", :latitude => "-37.68333", :longitude => "144.58333").save
City.new(:country_id => "15", :name => "Melbourne", :aliases => "Mel'burn,Melbourne,Melbourne City,Melbournum,Melburn,Melburna,Melburnas,Melburno,mel beirn,melaborna,melbeoleun,melporn,meruborun,mlbwrn,mo er ben,ÐÐµÐ»Ð±ÑÑÐ½,ÐÐµÐ»Ð±ÑÑÐ½,ÐÐµÐ»ÑÐ±ÑÑÐ½,×××××¨×,ÙÙØ¨ÙØ±Ù,ÙÛÙØ¨ÛØ±Ù,à¤®à¥à¤²à¤¬à¥à¤°à¥à¤¨,à®®à¯à®²à¯à®ªà¯à®°à¯à®©à¯,à¹à¸¡à¸¥à¹à¸à¸´à¸£à¹à¸,à½à½ºà½¢à¼à½à½´à½,ã¡ã«ãã«ã³,å¢¨å°æ¬,ë©ë²ë¥¸,Melbourne", :latitude => "-37.814", :longitude => "144.96332").save
City.new(:country_id => "15", :name => "Maryborough", :aliases => "Maryborough,Maryborough", :latitude => "-25.53333", :longitude => "152.7").save
City.new(:country_id => "15", :name => "Marrickville", :aliases => ",Marrickville", :latitude => "-33.91667", :longitude => "151.16667").save
City.new(:country_id => "15", :name => "Maroubra", :aliases => "Maroubra,Maroubra", :latitude => "-33.95", :longitude => "151.23333").save
City.new(:country_id => "15", :name => "Mackay", :aliases => "Mackay,Makej,ÐÐ°ÐºÐµÐ¹,Mackay", :latitude => "-21.15", :longitude => "149.2").save
City.new(:country_id => "15", :name => "Liverpool", :aliases => ",Liverpool", :latitude => "-33.9", :longitude => "150.93333").save
City.new(:country_id => "15", :name => "Lismore", :aliases => "Lizmor,ÐÐ¸Ð·Ð¼Ð¾Ñ,Lismore", :latitude => "-28.81354", :longitude => "153.2773").save
City.new(:country_id => "15", :name => "Launceston", :aliases => "Launceston,Launcestown,Lonseston,Patersonia,ÐÐ¾Ð½ÑÐµÑÑÐ¾Ð½,Launceston", :latitude => "-41.45", :longitude => "147.16667").save
City.new(:country_id => "15", :name => "Katoomba", :aliases => "Katoomba,Katoomba", :latitude => "-33.7", :longitude => "150.3").save
City.new(:country_id => "15", :name => "Hornsby", :aliases => ",Hornsby", :latitude => "-33.70244", :longitude => "151.09931").save
City.new(:country_id => "15", :name => "Hobart", :aliases => "Hobart,Hobart Town,Hobart", :latitude => "-42.87936", :longitude => "147.32941").save
City.new(:country_id => "15", :name => "Griffith", :aliases => "Griffith,Griffith", :latitude => "-34.28333", :longitude => "146.03333").save
City.new(:country_id => "15", :name => "Greensborough", :aliases => ",Greensborough", :latitude => "-37.70462", :longitude => "145.10302").save
City.new(:country_id => "15", :name => "Granville", :aliases => "Granville,Granville Junction,Granville", :latitude => "-33.83333", :longitude => "151.01667").save
City.new(:country_id => "15", :name => "Goulburn", :aliases => "Goulburn,Gulbern,ÐÑÐ»Ð±ÐµÑÐ½,Goulburn", :latitude => "-34.75", :longitude => "149.71667").save
City.new(:country_id => "15", :name => "Gold Coast", :aliases => "Costa Dorada,Gold,Gold Coast,Gold Koust,gorudokosuto,huang jin hai an,ÐÐ¾Ð»Ð´ ÐÐ¾ÑÑÑ,ã´ã¼ã«ãã³ã¼ã¹ã,ã´ã¼ã«ãã»ã³ã¼ã¹ã,é»éæµ·å²¸,é»éæµ·å²¸,Gold Coast", :latitude => "-28", :longitude => "153.43333").save
City.new(:country_id => "15", :name => "Gladstone", :aliases => "Gladstone,Glehdston,ÐÐ»ÑÐ´ÑÑÐ¾Ð½,Gladstone", :latitude => "-23.85", :longitude => "151.25").save
City.new(:country_id => "15", :name => "Geelong West", :aliases => "Geelong West,Geelong West", :latitude => "-38.13333", :longitude => "144.35").save
City.new(:country_id => "15", :name => "Geelong", :aliases => "Dzhilong,Geelong,ÐÐ¶Ð¸Ð»Ð¾Ð½Ð³,Geelong", :latitude => "-38.14711", :longitude => "144.36069").save
City.new(:country_id => "15", :name => "Frankston East", :aliases => "Frankston East,Frenkston,Ð¤ÑÐµÐ½ÐºÑÑÐ¾Ð½,Frankston East", :latitude => "-38.13333", :longitude => "145.13333").save
City.new(:country_id => "15", :name => "Forster", :aliases => "Forster,Forster", :latitude => "-32.16667", :longitude => "152.51667").save
City.new(:country_id => "15", :name => "Epping", :aliases => ",Epping", :latitude => "-33.77271", :longitude => "151.08184").save
City.new(:country_id => "15", :name => "Engadine", :aliases => "Engadine,Engadine", :latitude => "-34.06667", :longitude => "151.01667").save
City.new(:country_id => "15", :name => "Echuca", :aliases => "Echuca,Echuca", :latitude => "-36.13333", :longitude => "144.75").save
City.new(:country_id => "15", :name => "Earlwood", :aliases => "Earlwood,Earlwood", :latitude => "-33.95", :longitude => "151.1").save
City.new(:country_id => "15", :name => "Dubbo", :aliases => "Dabbo,Dubbo,ÐÐ°Ð±Ð±Ð¾,Dubbo", :latitude => "-32.25", :longitude => "148.61667").save
City.new(:country_id => "15", :name => "Devonport", :aliases => "Devenport,Devonport,ÐÐµÐ²Ð¾Ð½Ð¿Ð¾ÑÑ,Devonport", :latitude => "-41.16667", :longitude => "146.35").save
City.new(:country_id => "15", :name => "Deception Bay", :aliases => "Deception Bay,Deception Bay", :latitude => "-27.2", :longitude => "153.03333").save
City.new(:country_id => "15", :name => "Cronulla", :aliases => "Cronulla,Cronulla Beach,Gunnamatta,Cronulla", :latitude => "-34.05", :longitude => "151.15").save
City.new(:country_id => "15", :name => "Cranbourne", :aliases => "Cranbourne,Cranbourne", :latitude => "-38.1", :longitude => "145.28333").save
City.new(:country_id => "15", :name => "Craigieburn", :aliases => "Craigieburn,Craigieburn", :latitude => "-37.6", :longitude => "144.95").save
City.new(:country_id => "15", :name => "Coffs Harbour", :aliases => "Coffs Harbour,Kofs-Kharbor,ÐÐ¾ÑÑ-Ð¥Ð°ÑÐ±Ð¾Ñ,Coffs Harbour", :latitude => "-30.3", :longitude => "153.13333").save
City.new(:country_id => "15", :name => "Wollongong", :aliases => "City of Greater Wollongong,Vullongong,Wollongong,wo long gang,ÐÑÐ»Ð»Ð¾Ð½Ð³Ð¾Ð½Ð³,å§é¾å²,Wollongong", :latitude => "-34.43333", :longitude => "150.88333").save
City.new(:country_id => "15", :name => "Cessnock", :aliases => "Cessnock,Sesnok,Ð¡ÐµÑÐ½Ð¾Ðº,Cessnock", :latitude => "-32.83333", :longitude => "151.35").save
City.new(:country_id => "15", :name => "Castle Hill", :aliases => "Castle Hill,Castle Hill", :latitude => "-33.73333", :longitude => "151").save
City.new(:country_id => "15", :name => "Carlingford", :aliases => ",Carlingford", :latitude => "-33.78269", :longitude => "151.04888").save
City.new(:country_id => "15", :name => "Caringbah", :aliases => ",Caringbah", :latitude => "-34.05", :longitude => "151.13333").save
City.new(:country_id => "15", :name => "Canberra", :aliases => "Camberra,Canberra,Gorad Kanbera,Kamberra,Kambra,Kampera,Kanapera,Kanbera,Kanbero,Kanberra,Kanberrae,KanbÃ©rra,KÄnapera,kaenbeola,kainabara,kan pei la,kanbra,kanpara,kenabera,kyanabera,kyanbera,kynbra,qnbrh,ÎÎ±Î¼ÏÎ­ÏÎ±,ÐÐ¾ÑÐ°Ð´ ÐÐ°Ð½Ð±ÐµÑÐ°,ÐÐ°Ð½Ð±ÐµÑÐ°,ÐÐ°Ð½Ð±ÐµÑÑÃ¦,ÐÐ°Ð½Ð±ÐµÑÑÐ°,ÐÐ°Ð½Ð±ÑÌÑÐ°,Ô¿Õ¡Õ¶Õ¢Õ¥Õ¼Õ¡,×§×× ××¢×¨×,×§× ××¨×,ÙØ§ÙØ¨Ø±Ø§,Ú©Ø§ÙØ¨Ø±Ø§,Ú©ÛÙØ¨Ø±Ø§,à¤à¥à¤¨à¤¬à¥à¤°à¤¾,à¤à¥à¤¨à¤¬à¤°à¤¾,à¦à§à¦¯à¦¾à¦¨à¦¬à§à¦°à¦¾,à®à®¾à®©à¯à®ªà®°à®¾,à¹à¸à¸à¹à¸à¸­à¸£à¹à¸£à¸²,à½à½à¼à½à½ºà¼à½¢à¼,áááááá á,á«áá á«,ã­ã£ã³ãã©,åå¹æ,å ªå¹æ,ìºë²ë¼,Canberra", :latitude => "-35.28346", :longitude => "149.12807").save
City.new(:country_id => "15", :name => "Caloundra", :aliases => "Caloundra,Kalundra,ÐÐ°Ð»ÑÐ½Ð´ÑÐ°,Caloundra", :latitude => "-26.8", :longitude => "153.13333").save
City.new(:country_id => "15", :name => "Cairns", :aliases => "Cairns,Kerns,kai en si,keanzu,ÐÐµÑÐ½Ñ,ã±ã¢ã³ãº,å±æ©æ¯,Cairns", :latitude => "-16.91667", :longitude => "145.76667").save
City.new(:country_id => "15", :name => "Caboolture", :aliases => "Caboolture,Caboolture", :latitude => "-27.08333", :longitude => "152.95").save
City.new(:country_id => "15", :name => "Burnie", :aliases => "Burnie,Burnie", :latitude => "-41.06667", :longitude => "145.91667").save
City.new(:country_id => "15", :name => "Bundaberg", :aliases => "Bandaberg,Bundaberg,ÐÐ°Ð½Ð´Ð°Ð±ÐµÑÐ³,Bundaberg", :latitude => "-24.85", :longitude => "152.35").save
City.new(:country_id => "15", :name => "Buderim", :aliases => "Buderim,Buderim", :latitude => "-26.68333", :longitude => "153.05").save
City.new(:country_id => "15", :name => "Brunswick", :aliases => "Brunswick,Brunswick", :latitude => "-37.76667", :longitude => "144.96667").save
City.new(:country_id => "15", :name => "Broken Hill", :aliases => "Broken Hill,Broken-Khill,Willyama,burokunhiru,ÐÑÐ¾ÐºÐµÐ½-Ð¥Ð¸Ð»Ð»,ãã­ã¼ã¯ã³ãã«,Broken Hill", :latitude => "-31.95", :longitude => "141.43333").save
City.new(:country_id => "15", :name => "Brisbane", :aliases => "Brisbane,Brisbane City,Brisbano,Brisben,Brisbenas,Brizbejn,beulijeubeon,brisben,brysban,bryzbyn,bryzbyyn,bu li si ban,burisuben,pirispen,ÐÑÐ¸Ð·Ð±ÐµÐ¹Ð½,ÐÑÐ¸ÑÐ±ÐµÐ½,××¨××××××,Ø¨Ø±ÙØ³Ø¨Ø§Ù,Ø¨Ø±ÙØ²Ø¨ÙÙ,Ø¨Ø±ÛØ²Ø¨ÛÙ,à®ªà®¿à®±à®¿à®¸à¯à®ªà¯à®©à¯,à¸à¸£à¸´à¸ªà¹à¸à¸,ããªã¹ãã³,å¸éæ¯ç­,ë¸ë¦¬ì¦ë²,Brisbane", :latitude => "-27.46794", :longitude => "153.02809").save
City.new(:country_id => "15", :name => "Blacktown", :aliases => "Blacktown,Blacktown", :latitude => "-33.76667", :longitude => "150.91667").save
City.new(:country_id => "15", :name => "Bendigo", :aliases => "Bendigo,bendigo,ÐÐµÐ½Ð´Ð¸Ð³Ð¾,Bendigo", :latitude => "-36.76667", :longitude => "144.28333").save
City.new(:country_id => "15", :name => "Banora Point", :aliases => ",Banora Point", :latitude => "-28.21298", :longitude => "153.53634").save
City.new(:country_id => "15", :name => "Ballarat", :aliases => "Ballaarat,Ballarat,ÐÐ°Ð»Ð»Ð°ÑÐ°Ñ,Ballarat", :latitude => "-37.56667", :longitude => "143.85").save
City.new(:country_id => "15", :name => "Armidale", :aliases => "Armidale,Armidejl,ÐÑÐ¼Ð¸Ð´ÐµÐ¹Ð»,Armidale", :latitude => "-30.51667", :longitude => "151.65").save
City.new(:country_id => "15", :name => "Albury", :aliases => "Albury,Olberi,ÐÐ»Ð±ÐµÑÐ¸,Albury", :latitude => "-36.08333", :longitude => "146.91667").save
City.new(:country_id => "15", :name => "South Brisbane", :aliases => ",South Brisbane", :latitude => "-27.48333", :longitude => "153.01667").save
City.new(:country_id => "15", :name => "Randwick", :aliases => "Randwick,Randwick", :latitude => "-33.91667", :longitude => "151.24167").save
City.new(:country_id => "15", :name => "Dee Why", :aliases => ",Dee Why", :latitude => "-33.75", :longitude => "151.3").save
City.new(:country_id => "15", :name => "Palmerston", :aliases => "Palmerston,ÐÐ°Ð»Ð¼ÐµÑÑÑÐ¾Ð½,Palmerston", :latitude => "-12.48602", :longitude => "130.9833").save
City.new(:country_id => "15", :name => "Rainbow Beach", :aliases => ",Rainbow Beach", :latitude => "-25.90432", :longitude => "153.09174").save
City.new(:country_id => "15", :name => "North Shore", :aliases => ",North Shore", :latitude => "-31.40237", :longitude => "152.90185").save
City.new(:country_id => "15", :name => "Hoppers Crossing", :aliases => ",Hoppers Crossing", :latitude => "-37.88264", :longitude => "144.7003").save
City.new(:country_id => "15", :name => "Logan City", :aliases => "Logan,Logan City,Logan City", :latitude => "-27.63917", :longitude => "153.10944").save
City.new(:country_id => "15", :name => "Carindale", :aliases => ",Carindale", :latitude => "-27.50578", :longitude => "153.10236").save
City.new(:country_id => "15", :name => "Paramatta", :aliases => ",Paramatta", :latitude => "-33.8178", :longitude => "151.00348").save
City.new(:country_id => "15", :name => "Ferntree Gully", :aliases => ",Ferntree Gully", :latitude => "-37.88461", :longitude => "145.29539").save
City.new(:country_id => "15", :name => "City of Parramatta", :aliases => "City of Parramatta,Parramatta,City of Parramatta", :latitude => "-33.81667", :longitude => "151").save
City.new(:country_id => "15", :name => "Adelaide Hills", :aliases => ",Adelaide Hills", :latitude => "-34.91118", :longitude => "138.70735").save
City.new(:country_id => "15", :name => "Canning Vale", :aliases => ",Canning Vale", :latitude => "-32.05798", :longitude => "115.91814").save
City.new(:country_id => "15", :name => "Glenmore Park", :aliases => ",Glenmore Park", :latitude => "-33.79068", :longitude => "150.6693").save
