City.new(:country_id => "214", :name => "Cockburn Town", :aliases => "Cockburn Town,Cockburn Town", :latitude => "21.46122", :longitude => "-71.14188").save
