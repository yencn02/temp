City.new(:country_id => "79", :name => "York", :aliases => "Eboracum,Efrog,Everoui,Jork,Jorvik,JÃ³rvÃ­k,York,yoku,yue ke,ywrq,ÃvÃ¨roui,ÐÐ¾ÑÐº,×××¨×§,ã¨ã¼ã¯,ç´å,York", :latitude => "53.95763", :longitude => "-1.08271").save
City.new(:country_id => "79", :name => "Yeovil", :aliases => "Jeovil',Yeovil,ÐÐµÐ¾Ð²Ð¸Ð»Ñ,Yeovil", :latitude => "50.94159", :longitude => "-2.63211").save
City.new(:country_id => "79", :name => "Wrexham", :aliases => "Wrecsam,Wrexham,Wrexham", :latitude => "53.04664", :longitude => "-2.99132").save
City.new(:country_id => "79", :name => "Worthing", :aliases => "Worthing,washingu,ã¯ã¼ã·ã³ã°,Worthing", :latitude => "50.81448", :longitude => "-0.37126").save
City.new(:country_id => "79", :name => "Worksop", :aliases => "Worksop,Worksop", :latitude => "53.30182", :longitude => "-1.12404").save
City.new(:country_id => "79", :name => "Workington", :aliases => ",Workington", :latitude => "54.6425", :longitude => "-3.54413").save
City.new(:country_id => "79", :name => "Worcester", :aliases => "Caerwrangon,Worcester,Worcester UK,vuster,ÐÑÑÑÐµÑ,Worcester", :latitude => "52.18935", :longitude => "-2.22001").save
City.new(:country_id => "79", :name => "Wombwell", :aliases => "Wombwell,Wombwell", :latitude => "53.52189", :longitude => "-1.39698").save
City.new(:country_id => "79", :name => "Wolverhampton", :aliases => "Uulvurkhjamptun,Wolverhampton,wwlbrhmptwn,Ð£ÑÐ»Ð²ÑÑÑÑÐ¼Ð¿ÑÑÐ½,×××××¨×××¤×××,Wolverhampton", :latitude => "52.58547", :longitude => "-2.12296").save
City.new(:country_id => "79", :name => "Wokingham", :aliases => "Uokingkhem,Ð£Ð¾ÐºÐ¸Ð½Ð³ÑÐµÐ¼,Wokingham", :latitude => "51.4112", :longitude => "-0.83565").save
City.new(:country_id => "79", :name => "Woking", :aliases => "Uokinge,Woking,Ð£Ð¾ÐºÐ¸Ð½Ð³Ðµ,Woking", :latitude => "51.31903", :longitude => "-0.55893").save
City.new(:country_id => "79", :name => "Witney", :aliases => "Uitni,Witney,Ð£Ð¸ÑÐ½Ð¸,Witney", :latitude => "51.7836", :longitude => "-1.4854").save
City.new(:country_id => "79", :name => "Witham", :aliases => ",Witham", :latitude => "51.80007", :longitude => "0.64038").save
City.new(:country_id => "79", :name => "Wishaw", :aliases => ",Wishaw", :latitude => "55.76667", :longitude => "-3.91667").save
City.new(:country_id => "79", :name => "Wisbech", :aliases => "Vizbich,Wisbech,ÐÐ¸Ð·Ð±Ð¸Ñ,Wisbech", :latitude => "52.66622", :longitude => "0.15938").save
City.new(:country_id => "79", :name => "Winsford", :aliases => ",Winsford", :latitude => "53.18333", :longitude => "-2.51667").save
City.new(:country_id => "79", :name => "Windsor", :aliases => "New Windsor,Vindzor,Windlesora,WindlesÅra,Windsor,u~inza,ÐÐ¸Ð½Ð´Ð·Ð¾Ñ,ã¦ã£ã³ã¶ã¼,Windsor", :latitude => "51.48333", :longitude => "-0.6").save
City.new(:country_id => "79", :name => "Winchester", :aliases => "Uinchest'r,Vincester,Vinchester,Winchester,u~inchesuta,ÐÐ¸Ð½ÑÐµÑÑÐµÑ,ÐÑÐ½ÑÐµÑÑÐµÑ,Ð£Ð¸Ð½ÑÐµÑÑÑÑ,ã¦ã£ã³ãã§ã¹ã¿ã¼,Winchester", :latitude => "51.06513", :longitude => "-1.3187").save
City.new(:country_id => "79", :name => "Wilmslow", :aliases => ",Wilmslow", :latitude => "53.32803", :longitude => "-2.23148").save
City.new(:country_id => "79", :name => "Wigston Magna", :aliases => "Wigston,Wigston Magna,Wigston Magna", :latitude => "52.58128", :longitude => "-1.09248").save
City.new(:country_id => "79", :name => "Wigan", :aliases => "Uigan,Wigan,wei gan,Ð£Ð¸Ð³Ð°Ð½,ç»´ç,Wigan", :latitude => "53.53333", :longitude => "-2.61667").save
City.new(:country_id => "79", :name => "Widnes", :aliases => "Widnes,Widnes", :latitude => "53.3618", :longitude => "-2.73406").save
City.new(:country_id => "79", :name => "Wickford", :aliases => ",Wickford", :latitude => "51.61101", :longitude => "0.52331").save
City.new(:country_id => "79", :name => "Whitstable", :aliases => "Uitstabl,Whitstable,Ð£Ð¸ÑÑÑÐ°Ð±Ð»,Whitstable", :latitude => "51.3607", :longitude => "1.0257").save
City.new(:country_id => "79", :name => "Whitley Bay", :aliases => "Whitley,Whitley Bay,Whitley Bay", :latitude => "55.03973", :longitude => "-1.44713").save
City.new(:country_id => "79", :name => "Whitehaven", :aliases => ",Whitehaven", :latitude => "54.54897", :longitude => "-3.58412").save
City.new(:country_id => "79", :name => "Whitefield", :aliases => ",Whitefield", :latitude => "53.55", :longitude => "-2.3").save
City.new(:country_id => "79", :name => "Whickham", :aliases => ",Whickham", :latitude => "54.94561", :longitude => "-1.67635").save
City.new(:country_id => "79", :name => "Weymouth", :aliases => ",Weymouth", :latitude => "50.61136", :longitude => "-2.45334").save
City.new(:country_id => "79", :name => "Weston-super-Mare", :aliases => "Uest'n sjup'r Me'r,Uestun-Sjupur-Meur,Weston super Mare,Weston-super-Mare,Ð£ÐµÑÑÑÐ½ ÑÑÐ¿ÑÑ ÐÐµÑÑ,Ð£ÐµÑÑÑÐ½-Ð¡ÑÐ¿ÑÑ-ÐÐµÑÑ,Weston-super-Mare", :latitude => "51.34603", :longitude => "-2.97665").save
City.new(:country_id => "79", :name => "Westhoughton", :aliases => "Westhoughton,Westhoughton", :latitude => "53.54899", :longitude => "-2.52464").save
City.new(:country_id => "79", :name => "West Bromwich", :aliases => "West Bromwich,West Bromwich", :latitude => "52.51868", :longitude => "-1.9945").save
City.new(:country_id => "79", :name => "West Bridgford", :aliases => "West Bridgeford,West Bridgford,West Bridgford", :latitude => "52.92979", :longitude => "-1.12537").save
City.new(:country_id => "79", :name => "Welwyn Garden City", :aliases => "Garden City,Welwyn Garden,Welwyn Garden City,Welwyn Garden City", :latitude => "51.80174", :longitude => "-0.20691").save
City.new(:country_id => "79", :name => "Wellington", :aliases => "Vellington,Wellington,ÐÐµÐ»Ð»Ð¸Ð½Ð³ÑÐ¾Ð½,Wellington", :latitude => "52.7", :longitude => "-2.51667").save
City.new(:country_id => "79", :name => "Wellingborough", :aliases => "Vellingboro,Wellingborough,ÐÐµÐ»Ð»Ð¸Ð½Ð³Ð±Ð¾ÑÐ¾,Wellingborough", :latitude => "52.30273", :longitude => "-0.69446").save
City.new(:country_id => "79", :name => "Wath upon Dearne", :aliases => "Wath,Wath upon Dearne,Wath-on-Dearne,Wath upon Dearne", :latitude => "53.50291", :longitude => "-1.3458").save
City.new(:country_id => "79", :name => "Watford", :aliases => "Uotford,Watford,wtpwrd,wwtpwrd,Ð£Ð¾ÑÑÐ¾ÑÐ´,××××¤××¨×,×××¤××¨×,Watford", :latitude => "51.65531", :longitude => "-0.39602").save
City.new(:country_id => "79", :name => "Waterlooville", :aliases => "Uoterluvil',Waterloo,Waterlooville,Ð£Ð¾ÑÐµÑÐ»ÑÐ²Ð¸Ð»Ñ,Waterlooville", :latitude => "50.88067", :longitude => "-1.0304").save
City.new(:country_id => "79", :name => "Washington", :aliases => "Vashington,Washington,Washington New Town,ÐÐ°ÑÐ¸Ð½Ð³ÑÐ¾Ð½,Washington", :latitude => "54.9", :longitude => "-1.51667").save
City.new(:country_id => "79", :name => "Warwick", :aliases => "Uorik,Warwick,Ð£Ð¾ÑÐ¸Ðº,Warwick", :latitude => "52.28333", :longitude => "-1.58333").save
City.new(:country_id => "79", :name => "Warrington", :aliases => "Uorrington,Warrington,Ð£Ð¾ÑÑÐ¸Ð½Ð³ÑÐ¾Ð½,Warrington", :latitude => "53.39254", :longitude => "-2.58024").save
City.new(:country_id => "79", :name => "Warminster", :aliases => "Warminster,Warminster", :latitude => "51.20434", :longitude => "-2.17873").save
City.new(:country_id => "79", :name => "Ware", :aliases => ",Ware", :latitude => "51.81265", :longitude => "-0.02832").save
City.new(:country_id => "79", :name => "Waltham Abbey", :aliases => "Waltham Abbey,Waltham Abbey", :latitude => "51.687", :longitude => "-0.00421").save
City.new(:country_id => "79", :name => "Walsall", :aliases => "Uolsol,Wallsall,Walsall,Ð£Ð¾Ð»ÑÐ¾Ð»,Walsall", :latitude => "52.58528", :longitude => "-1.98396").save
City.new(:country_id => "79", :name => "Wallsend", :aliases => "Uolsend,Wallsend-on-Tyne,Ð£Ð¾Ð»ÑÐµÐ½Ð´,Wallsend", :latitude => "54.99111", :longitude => "-1.53397").save
City.new(:country_id => "79", :name => "Wallasey", :aliases => "Uollasi,Wallasey,Ð£Ð¾Ð»Ð»Ð°ÑÐ¸,Wallasey", :latitude => "53.42324", :longitude => "-3.06497").save
City.new(:country_id => "79", :name => "Walkden", :aliases => "Walkden,Walkden", :latitude => "53.51667", :longitude => "-2.4").save
City.new(:country_id => "79", :name => "Wakefield", :aliases => "Wakefield,Wakefield", :latitude => "53.68331", :longitude => "-1.49768").save
City.new(:country_id => "79", :name => "Urmston", :aliases => "Urmston,Urmston", :latitude => "53.44852", :longitude => "-2.35419").save
City.new(:country_id => "79", :name => "Uckfield", :aliases => ",Uckfield", :latitude => "50.96948", :longitude => "0.09589").save
City.new(:country_id => "79", :name => "Tynemouth", :aliases => "Tynemouth,Tynemouth", :latitude => "55.01788", :longitude => "-1.42559").save
City.new(:country_id => "79", :name => "Tyldesley", :aliases => ",Tyldesley", :latitude => "53.51393", :longitude => "-2.46754").save
City.new(:country_id => "79", :name => "Truro", :aliases => "Truro,Truru,Ð¢ÑÑÑÐ¾,Truro", :latitude => "50.26526", :longitude => "-5.05436").save
City.new(:country_id => "79", :name => "Trowbridge", :aliases => "Troubridzhe,Trowbridge,Ð¢ÑÐ¾ÑÐ±ÑÐ¸Ð´Ð¶Ðµ,Trowbridge", :latitude => "51.31889", :longitude => "-2.20861").save
City.new(:country_id => "79", :name => "Totton", :aliases => ",Totton", :latitude => "50.91877", :longitude => "-1.49037").save
City.new(:country_id => "79", :name => "Torquay", :aliases => "Torcaium,Torkej,Torkvej,Torquay,toki,Ð¢Ð¾ÑÐºÐ²ÐµÐ¹,Ð¢Ð¾ÑÐºÐµÐ¹,ãã¼ã­ã¼,Torquay", :latitude => "50.46384", :longitude => "-3.51434").save
City.new(:country_id => "79", :name => "Tonbridge", :aliases => "Tonbridge,Tonbridzh,Ð¢Ð¾Ð½Ð±ÑÐ¸Ð´Ð¶,Tonbridge", :latitude => "51.19242", :longitude => "0.27532").save
City.new(:country_id => "79", :name => "Tiverton", :aliases => "Tiverton,Tiverton", :latitude => "50.9", :longitude => "-3.48333").save
City.new(:country_id => "79", :name => "Thornaby on Tees", :aliases => "Thornaby,Thornaby on Tees,Thornaby on Tees", :latitude => "54.53333", :longitude => "-1.3").save
City.new(:country_id => "79", :name => "Thetford", :aliases => "Tetford,Thetford,Ð¢ÐµÑÑÐ¾ÑÐ´,Thetford", :latitude => "52.41667", :longitude => "0.75").save
City.new(:country_id => "79", :name => "Thatcham", :aliases => "Thatcham,Thatcham", :latitude => "51.40366", :longitude => "-1.26049").save
City.new(:country_id => "79", :name => "Teignmouth", :aliases => "Teignmouth,Teignmouth", :latitude => "50.54768", :longitude => "-3.49637").save
City.new(:country_id => "79", :name => "Taunton", :aliases => "Taunton,Taunton", :latitude => "51.02111", :longitude => "-3.10472").save
City.new(:country_id => "79", :name => "Tamworth", :aliases => "Tamworth,Tamworth", :latitude => "52.63399", :longitude => "-1.69587").save
City.new(:country_id => "79", :name => "Tadley", :aliases => ",Tadley", :latitude => "51.35045", :longitude => "-1.1285").save
City.new(:country_id => "79", :name => "Swindon", :aliases => "Svindon,Swindon,suu~indon,Ð¡Ð²Ð¸Ð½Ð´Ð¾Ð½,ã¹ã¦ã£ã³ãã³,Swindon", :latitude => "51.55797", :longitude => "-1.78116").save
City.new(:country_id => "79", :name => "Swansea", :aliases => "Abertawe,Suonsi,Suonzi,Swansea,si wang xi,suu~onji,Ð¡ÑÐ¾Ð½Ð·Ð¸,Ð¡ÑÐ¾Ð½ÑÐ¸,ã¹ã¦Ã¦ã©ã³ã¸,ã¹ã¦ã©ã³ã¸,æ¯æºè¥¿,Swansea", :latitude => "51.62079", :longitude => "-3.94323").save
City.new(:country_id => "79", :name => "Swanscombe", :aliases => "Swanscombe,Swanscombe", :latitude => "51.44713", :longitude => "0.31028").save
City.new(:country_id => "79", :name => "Swadlincote", :aliases => "Swadlincote,Swadlincote", :latitude => "52.774", :longitude => "-1.55744").save
City.new(:country_id => "79", :name => "Sutton in Ashfield", :aliases => "Sutton in Ashfield,Sutton in Ashfield", :latitude => "53.12542", :longitude => "-1.26135").save
City.new(:country_id => "79", :name => "Sutton Coldfield", :aliases => "Sutton Coldfield,Sutton Coldfield", :latitude => "52.56667", :longitude => "-1.81667").save
City.new(:country_id => "79", :name => "Sutton", :aliases => "London Borough of Sutton,Sutton,Sutton keruelet,Sutton kerÃ¼let,Sutton", :latitude => "51.35", :longitude => "-0.2").save
City.new(:country_id => "79", :name => "Sunderland", :aliases => "Sanderlend,Sanderlenda,Sunderland,Ð¡Ð°Ð½Ð´ÐµÑÐ»ÐµÐ½Ð´,Sunderland", :latitude => "54.90465", :longitude => "-1.38222").save
City.new(:country_id => "79", :name => "Sunbury", :aliases => "Lower Sunbury,Sunbury,Sunbury-on-Thames,Sunbury", :latitude => "51.40606", :longitude => "-0.4137").save
City.new(:country_id => "79", :name => "Stroud", :aliases => "Straud,Stroud,Ð¡ÑÑÐ°ÑÐ´,Stroud", :latitude => "51.75", :longitude => "-2.2").save
City.new(:country_id => "79", :name => "Strood", :aliases => ",Strood", :latitude => "51.39594", :longitude => "0.49361").save
City.new(:country_id => "79", :name => "Stretford", :aliases => "Stretford,Ð¡ÑÑÐµÑÑÐ¾ÑÐ´,Stretford", :latitude => "53.45", :longitude => "-2.31667").save
City.new(:country_id => "79", :name => "Stratford-upon-Avon", :aliases => "Stratford,Stratford na Ejv'n,Stratford on Avon,Stratford-na-Ehjvone,Stratford-upon-Avon,Stratfordia super Avonam,seuteulaespeodeu eopeon eibeon,Ð¡ÑÑÐ°ÑÑÐ¾ÑÐ´ Ð½Ð° ÐÐ¹Ð²ÑÐ½,Ð¡ÑÑÐ°ÑÑÐ¾ÑÐ´-Ð½Ð°-Ð­Ð¹Ð²Ð¾Ð½Ðµ,ã¹ãã©ãããã©ã¼ãã»ã¢ãã³ã»ã¨ã¤ã´ã©ã³,ì¤í¸ë«í¼ë ì´í ìì´ë²,Stratford-upon-Avon", :latitude => "52.19166", :longitude => "-1.70734").save
City.new(:country_id => "79", :name => "Stowmarket", :aliases => ",Stowmarket", :latitude => "52.18893", :longitude => "0.99774").save
City.new(:country_id => "79", :name => "Stourbridge", :aliases => "Stourbridge,Stourbridzh,Ð¡ÑÐ¾ÑÑÐ±ÑÐ¸Ð´Ð¶,Stourbridge", :latitude => "52.45608", :longitude => "-2.14317").save
City.new(:country_id => "79", :name => "Stoke-on-Trent", :aliases => "Stok-on-Trent,Stoke,Stoke-on-Trent,Stoke-upon-Trent,The Potteries,Ð¡ÑÐ¾Ðº-Ð¾Ð½-Ð¢ÑÐµÐ½Ñ,Stoke-on-Trent", :latitude => "53.00415", :longitude => "-2.18538").save
City.new(:country_id => "79", :name => "Stockton-on-Tees", :aliases => "Stockton,Stockton on Tees,Stockton-on-Tees,Stokton-on-Tis,Ð¡ÑÐ¾ÐºÑÐ¾Ð½-Ð¾Ð½-Ð¢Ð¸Ñ,Stockton-on-Tees", :latitude => "54.56848", :longitude => "-1.3187").save
City.new(:country_id => "79", :name => "Stockport", :aliases => "Stockport,Stokport,Ð¡ÑÐ¾ÐºÐ¿Ð¾ÑÑ,Stockport", :latitude => "53.40979", :longitude => "-2.15761").save
City.new(:country_id => "79", :name => "Stirling", :aliases => "Srivling,Sruighle,Sruighlea,Sterling,Stirling,Stirlingum,astyrlyng,shi te ling,Ð¡ÑÐµÑÐ»Ð¸Ð½Ð³,Ø§Ø³ØªÛØ±ÙÛÙÚ¯,å²ç¹é,Stirling", :latitude => "56.11903", :longitude => "-3.93682").save
City.new(:country_id => "79", :name => "Stevenage", :aliases => "Stevenage,Stivenedzh,Ð¡ÑÐ¸Ð²ÐµÐ½ÐµÐ´Ð¶,Stevenage", :latitude => "51.90224", :longitude => "-0.20256").save
City.new(:country_id => "79", :name => "Staveley", :aliases => ",Staveley", :latitude => "53.26667", :longitude => "-1.35").save
City.new(:country_id => "79", :name => "Stamford", :aliases => ",Stamford", :latitude => "52.65", :longitude => "-0.48333").save
City.new(:country_id => "79", :name => "Stalybridge", :aliases => "Stalibridzh,Stalybridge,Ð¡ÑÐ°Ð»Ð¸Ð±ÑÐ¸Ð´Ð¶,Stalybridge", :latitude => "53.48414", :longitude => "-2.05908").save
City.new(:country_id => "79", :name => "Staines", :aliases => "Staines,Staines", :latitude => "51.43092", :longitude => "-0.50606").save
City.new(:country_id => "79", :name => "Stafford", :aliases => "Staefford,Stafford,StÃ¦fford,Ð¡ÑÐ°ÑÑÐ¾ÑÐ´,Stafford", :latitude => "52.80521", :longitude => "-2.11636").save
City.new(:country_id => "79", :name => "Spennymoor", :aliases => "Spennymoor,Spennymoor", :latitude => "54.6988", :longitude => "-1.60229").save
City.new(:country_id => "79", :name => "Spalding", :aliases => ",Spalding", :latitude => "52.78709", :longitude => "-0.15141").save
City.new(:country_id => "79", :name => "South Shields", :aliases => "Shields,South Shields,South Shields", :latitude => "54.99859", :longitude => "-1.4323").save
City.new(:country_id => "79", :name => "Southport", :aliases => "Southport,Southport", :latitude => "53.64779", :longitude => "-3.00648").save
City.new(:country_id => "79", :name => "South Ockendon", :aliases => "South Ockedon,South Ockendon,South Ockendon", :latitude => "51.50799", :longitude => "0.28333").save
City.new(:country_id => "79", :name => "Southend-on-Sea", :aliases => "Sautend-on-Si,Southend,Southend-on-Sea,Ð¡Ð°ÑÑÐµÐ½Ð´-Ð¾Ð½-Ð¡Ð¸,Southend-on-Sea", :latitude => "51.53782", :longitude => "0.71433").save
City.new(:country_id => "79", :name => "South Elmsall", :aliases => ",South Elmsall", :latitude => "53.59709", :longitude => "-1.28034").save
City.new(:country_id => "79", :name => "South Benfleet", :aliases => "Benfleet,South Benfleet,South Benfleet", :latitude => "51.55295", :longitude => "0.55962").save
City.new(:country_id => "79", :name => "Southampton", :aliases => "Hantonne,Sautgempton,Sautkhempt'n,Southampton,sausuhanputon,Ð¡Ð°ÑÑÐ³ÐµÐ¼Ð¿ÑÐ¾Ð½,Ð¡Ð°ÑÑÑÐµÐ¼Ð¿ÑÑÐ½,ãµã¦ã¹ãã³ããã³,Southampton", :latitude => "50.90395", :longitude => "-1.40428").save
City.new(:country_id => "79", :name => "Solihull", :aliases => "Solihull,Solihull", :latitude => "52.41426", :longitude => "-1.78094").save
City.new(:country_id => "79", :name => "Slough", :aliases => "Slau,Slough,Ð¡Ð»Ð°Ñ,Slough", :latitude => "51.50949", :longitude => "-0.59541").save
City.new(:country_id => "79", :name => "Sleaford", :aliases => "Sleaford,Sleaford", :latitude => "52.99826", :longitude => "-0.40941").save
City.new(:country_id => "79", :name => "Skelmersdale", :aliases => "Skelmersdale,Skelmersdale", :latitude => "53.55024", :longitude => "-2.77348").save
City.new(:country_id => "79", :name => "Skegness", :aliases => ",Skegness", :latitude => "53.14362", :longitude => "0.3363").save
City.new(:country_id => "79", :name => "Sittingbourne", :aliases => ",Sittingbourne", :latitude => "51.34128", :longitude => "0.73282").save
City.new(:country_id => "79", :name => "Shrewsbury", :aliases => "Amwythig,Shrewsbury,Shrjusburi,Shrusberi,Ð¨ÑÑÑÐ±ÐµÑÐ¸,Ð¨ÑÑÑÐ±ÑÑÐ¸,Shrewsbury", :latitude => "52.71009", :longitude => "-2.75208").save
City.new(:country_id => "79", :name => "Shoreham", :aliases => ",Shoreham", :latitude => "51.3334", :longitude => "0.17801").save
City.new(:country_id => "79", :name => "Shipley", :aliases => ",Shipley", :latitude => "53.83333", :longitude => "-1.76667").save
City.new(:country_id => "79", :name => "Sheffield", :aliases => "Sefilda,Sefildas,Sheffield,Sheffild,Shefild,she fei er de,shefirudo,Å efildas,Å efÄ«lda,Ð¨ÐµÑÐ¸Ð»Ð´,Ð¨ÐµÑÑÐ¸Ð»Ð´,ã·ã§ãã£ã¼ã«ã,è®¾è²å°å¾·,Sheffield", :latitude => "53.38297", :longitude => "-1.4659").save
City.new(:country_id => "79", :name => "Sevenoaks", :aliases => ",Sevenoaks", :latitude => "51.26997", :longitude => "0.19278").save
City.new(:country_id => "79", :name => "Selby", :aliases => "Selby,Selby", :latitude => "53.78333", :longitude => "-1.06667").save
City.new(:country_id => "79", :name => "Seaham", :aliases => "Seaham,Seaham Harbour,Sikhem,Ð¡Ð¸ÑÐµÐ¼,Seaham", :latitude => "54.83903", :longitude => "-1.34575").save
City.new(:country_id => "79", :name => "Seaford", :aliases => ",Seaford", :latitude => "50.77141", :longitude => "0.10268").save
City.new(:country_id => "79", :name => "Scunthorpe", :aliases => "Scunthorpe,Skantorpe,si ken suo pu,Ð¡ÐºÐ°Ð½ÑÐ¾ÑÐ¿Ðµ,æ¯è¯ç´¢æ®,Scunthorpe", :latitude => "53.57905", :longitude => "-0.65437").save
City.new(:country_id => "79", :name => "Scarborough", :aliases => "Scarborough,Skarb'ro,Ð¡ÐºÐ°ÑÐ±ÑÑÐ¾,Scarborough", :latitude => "54.27966", :longitude => "-0.40443").save
City.new(:country_id => "79", :name => "Sandown", :aliases => "Sandown,Sandown", :latitude => "50.65158", :longitude => "-1.16103").save
City.new(:country_id => "79", :name => "Sandbach", :aliases => ",Sandbach", :latitude => "53.14515", :longitude => "-2.36251").save
City.new(:country_id => "79", :name => "Salisbury", :aliases => "New Sarum,Salisbury,Solsb'ri,Solsberi,soruzuberi,swlsbry,Ð¡Ð¾Ð»ÑÐ±ÐµÑÐ¸,Ð¡Ð¾Ð»ÑÐ±ÑÑÐ¸,×¡×××¡××¨×,ã½ã¼ã«ãºããªã¼,Salisbury", :latitude => "51.06931", :longitude => "-1.79569").save
City.new(:country_id => "79", :name => "Salford", :aliases => "Salford,Salford", :latitude => "53.48771", :longitude => "-2.29042").save
City.new(:country_id => "79", :name => "Sale", :aliases => ",Sale", :latitude => "53.42519", :longitude => "-2.32443").save
City.new(:country_id => "79", :name => "Saint Neots", :aliases => "Saint Neots,St Neots,Saint Neots", :latitude => "52.21667", :longitude => "-0.26667").save
City.new(:country_id => "79", :name => "Saint Helens", :aliases => "Helens,Saint Helens,Sent-Khelens,St Helens,St. Helens,Ð¡ÐµÐ½Ñ-Ð¥ÐµÐ»ÐµÐ½Ñ,Saint Helens", :latitude => "53.45", :longitude => "-2.73333").save
City.new(:country_id => "79", :name => "Saint Austell", :aliases => "Saint Austell,St Austell,Saint Austell", :latitude => "50.33833", :longitude => "-4.76583").save
City.new(:country_id => "79", :name => "Saint Andrews", :aliases => "Saint Andrews,Sejnt Andrjus,Sent-Ehndrjus,St Andrews,St. Andrews,Ð¡ÐµÐ¹Ð½Ñ ÐÐ½Ð´ÑÑÑ,Ð¡ÐµÐ½Ñ-Ð­Ð½Ð´ÑÑÑ,ã»ã³ãã»ã¢ã³ããªã¥ã¼ã¹,Saint Andrews", :latitude => "56.33871", :longitude => "-2.79902").save
City.new(:country_id => "79", :name => "Saint Albans", :aliases => "Saint Albans,Sent-Ehlbans,Sent-Olbans,St Albans,St. Albans,Ð¡ÐµÐ½Ñ-ÐÐ»Ð±Ð°Ð½Ñ,Ð¡ÐµÐ½Ñ-Ð­Ð»Ð±Ð°Ð½Ñ,Saint Albans", :latitude => "51.75", :longitude => "-0.33333").save
City.new(:country_id => "79", :name => "Ryton", :aliases => ",Ryton", :latitude => "52.61667", :longitude => "-2.35").save
City.new(:country_id => "79", :name => "Ryde", :aliases => ",Ryde", :latitude => "50.72999", :longitude => "-1.1621").save
City.new(:country_id => "79", :name => "Rushden", :aliases => ",Rushden", :latitude => "52.29139", :longitude => "-0.59923").save
City.new(:country_id => "79", :name => "Runcorn", :aliases => "Runcorn,Runcorn", :latitude => "53.34174", :longitude => "-2.73124").save
City.new(:country_id => "79", :name => "Rugeley", :aliases => ",Rugeley", :latitude => "52.7593", :longitude => "-1.93694").save
City.new(:country_id => "79", :name => "Rugby", :aliases => ",Rugby", :latitude => "52.37092", :longitude => "-1.26417").save
City.new(:country_id => "79", :name => "Royton", :aliases => ",Royton", :latitude => "53.56507", :longitude => "-2.12267").save
City.new(:country_id => "79", :name => "Royal Tunbridge Wells", :aliases => "Royal Tunbridge Wells,Tunbridge Wells,Turnbridge Wells,Royal Tunbridge Wells", :latitude => "51.13245", :longitude => "0.26333").save
City.new(:country_id => "79", :name => "Rottingdean", :aliases => ",Rottingdean", :latitude => "50.80984", :longitude => "-0.05939").save
City.new(:country_id => "79", :name => "Rotherham", :aliases => "Roterem,Rotherdam,Rotherham,Ð Ð¾ÑÐµÑÐµÐ¼,Rotherham", :latitude => "53.43012", :longitude => "-1.35678").save
City.new(:country_id => "79", :name => "Romsey", :aliases => "Romsey,Romsey", :latitude => "50.98906", :longitude => "-1.49989").save
City.new(:country_id => "79", :name => "Rochford", :aliases => ",Rochford", :latitude => "51.58198", :longitude => "0.70673").save
City.new(:country_id => "79", :name => "Rochester", :aliases => "Rochester,Rotsester,Î¡ÏÏÏÎµÏÏÎµÏ,Ð Ð¾ÑÐµÑÑÐµÑ,Rochester", :latitude => "51.38764", :longitude => "0.50546").save
City.new(:country_id => "79", :name => "Rochdale", :aliases => "Rochdale,Rochdejl,Ð Ð¾ÑÐ´ÐµÐ¹Ð»,Rochdale", :latitude => "53.61766", :longitude => "-2.1552").save
City.new(:country_id => "79", :name => "Risca", :aliases => "Risca,Risca", :latitude => "51.60799", :longitude => "-3.10081").save
City.new(:country_id => "79", :name => "Ripon", :aliases => "Ripon,Ð Ð¸Ð¿Ð¾Ð½,Ripon", :latitude => "54.13521", :longitude => "-1.52122").save
City.new(:country_id => "79", :name => "Ripley", :aliases => ",Ripley", :latitude => "53.03333", :longitude => "-1.4").save
City.new(:country_id => "79", :name => "Rhyl", :aliases => "Rhyl,Ril,Y Rhyl,Ð Ð¸Ð»,Rhyl", :latitude => "53.31955", :longitude => "-3.48862").save
City.new(:country_id => "79", :name => "Rhondda", :aliases => "Rhondda,Y Rhondda,Rhondda", :latitude => "51.65896", :longitude => "-3.44885").save
City.new(:country_id => "79", :name => "Renfrew", :aliases => ",Renfrew", :latitude => "55.87197", :longitude => "-4.39253").save
City.new(:country_id => "79", :name => "Reigate", :aliases => "Rajgejt,Reigate,Ð Ð°Ð¹Ð³ÐµÐ¹Ñ,Reigate", :latitude => "51.23758", :longitude => "-0.2078").save
City.new(:country_id => "79", :name => "Redhill", :aliases => "Redhill,Redhill", :latitude => "51.24048", :longitude => "-0.17044").save
City.new(:country_id => "79", :name => "Redditch", :aliases => "Radditch,Redditch,reditchi,Ð ÐµÐ´Ð´Ð¸ÑÑ,ã¬ãã£ãã,Redditch", :latitude => "52.3065", :longitude => "-1.94569").save
City.new(:country_id => "79", :name => "Redcar", :aliases => ",Redcar", :latitude => "54.61657", :longitude => "-1.05999").save
City.new(:country_id => "79", :name => "Reading", :aliases => "Reading,Reding,Ð ÐµÐ´Ð¸Ð½Ð³,Reading", :latitude => "51.45625", :longitude => "-0.97113").save
City.new(:country_id => "79", :name => "Rawtenstall", :aliases => "Rawtenstall,Rawtenstall", :latitude => "53.70076", :longitude => "-2.28442").save
City.new(:country_id => "79", :name => "Rawmarsh", :aliases => ",Rawmarsh", :latitude => "53.46062", :longitude => "-1.34437").save
City.new(:country_id => "79", :name => "Ramsgate", :aliases => "Ramsgate,Ramsgejt,Ð Ð°Ð¼ÑÐ³ÐµÐ¹Ñ,Ramsgate", :latitude => "51.33576", :longitude => "1.41552").save
City.new(:country_id => "79", :name => "Ramsbottom", :aliases => ",Ramsbottom", :latitude => "53.64789", :longitude => "-2.31683").save
City.new(:country_id => "79", :name => "Radcliffe", :aliases => ",Radcliffe", :latitude => "53.55", :longitude => "-2.33333").save
City.new(:country_id => "79", :name => "Pudsey", :aliases => ",Pudsey", :latitude => "53.79538", :longitude => "-1.66134").save
City.new(:country_id => "79", :name => "Prestwick", :aliases => ",Prestwick", :latitude => "55.48333", :longitude => "-4.61667").save
City.new(:country_id => "79", :name => "Prestwich", :aliases => ",Prestwich", :latitude => "53.53333", :longitude => "-2.28333").save
City.new(:country_id => "79", :name => "Preston", :aliases => "Preston,prstwn,pu lei si dun,ÐÑÐµÑÑÐ¾Ð½,×¤×¨×¡×××,æ®é·æ¯é¡¿,Preston", :latitude => "53.76667", :longitude => "-2.71667").save
City.new(:country_id => "79", :name => "Prestatyn", :aliases => ",Prestatyn", :latitude => "53.33748", :longitude => "-3.40776").save
City.new(:country_id => "79", :name => "Prescot", :aliases => "Prescot,Prescott,Prescot", :latitude => "53.42948", :longitude => "-2.80031").save
City.new(:country_id => "79", :name => "Poulton le Fylde", :aliases => "Poulton,Poulton le Fylde,Poulton le Fylde", :latitude => "53.83333", :longitude => "-2.98333").save
City.new(:country_id => "79", :name => "Potters Bar", :aliases => "Potters Bar,Potters Bar", :latitude => "51.69353", :longitude => "-0.17835").save
City.new(:country_id => "79", :name => "Portsmouth", :aliases => "Porchemue,PorchÃ©mue,Portsmouth,Portsmut,potsumasu,pu ci mao si,ÐÐ¾ÑÑÑÐ¼ÑÑ,ãã¼ããã¹,æ´æ¬¡èæ¯,Portsmouth", :latitude => "50.79899", :longitude => "-1.09125").save
City.new(:country_id => "79", :name => "Portslade", :aliases => ",Portslade", :latitude => "50.84335", :longitude => "-0.21544").save
City.new(:country_id => "79", :name => "Portishead", :aliases => "Portishead,Portishead", :latitude => "51.48199", :longitude => "-2.76973").save
City.new(:country_id => "79", :name => "Porthcawl", :aliases => "Porthcawl,Porthcawl", :latitude => "51.47903", :longitude => "-3.70362").save
City.new(:country_id => "79", :name => "Port Glasgow", :aliases => "Port Glasgow,Port Glasgow", :latitude => "55.93464", :longitude => "-4.6895").save
City.new(:country_id => "79", :name => "Poole", :aliases => "Poole,Pul,ÐÑÐ»,Poole", :latitude => "50.71667", :longitude => "-2").save
City.new(:country_id => "79", :name => "Pontypridd", :aliases => "Pontiprite,Pontypridd,ÐÐ¾Ð½ÑÐ¸Ð¿ÑÐ¸ÑÐµ,Pontypridd", :latitude => "51.6021", :longitude => "-3.34211").save
City.new(:country_id => "79", :name => "Pont-y-pwl", :aliases => "Pont-y-pwl,Pontypool,Pont-y-pÅµl", :latitude => "51.70111", :longitude => "-3.04444").save
City.new(:country_id => "79", :name => "Pontefract", :aliases => ",Pontefract", :latitude => "53.69107", :longitude => "-1.31269").save
City.new(:country_id => "79", :name => "Polmont", :aliases => "Polmont,Polmonte,ÐÐ¾Ð»Ð¼Ð¾Ð½ÑÐµ,Polmont", :latitude => "55.9905", :longitude => "-3.70737").save
City.new(:country_id => "79", :name => "Plymouth", :aliases => "Aberplymm,Pliemue,Plimut,PliÃ©mue,Plymouth,pu li mao si,purimasu,ÐÐ»Ð¸Ð¼ÑÑ,ããªãã¹,æ®å©èæ¯,Plymouth", :latitude => "50.37153", :longitude => "-4.14305").save
City.new(:country_id => "79", :name => "Peterlee", :aliases => "Peterlee,Peterli,ÐÐµÑÐµÑÐ»Ð¸,Peterlee", :latitude => "54.76032", :longitude => "-1.33649").save
City.new(:country_id => "79", :name => "Peterhead", :aliases => ",Peterhead", :latitude => "57.50584", :longitude => "-1.79806").save
City.new(:country_id => "79", :name => "Peterborough", :aliases => "Peterborough,Peterbrough,Petersborough,Petroburgum,Piterboro,pitaboro,ÐÐ¸ÑÐµÑÐ±Ð¾ÑÐ¾,ãã¼ã¿ã¼ãã­ã¼,Peterborough", :latitude => "52.57364", :longitude => "-0.24777").save
City.new(:country_id => "79", :name => "Perth", :aliases => "P'rt,Peairt,Pert,Perth,ÐÐµÑÑ,ÐÑÑÑ,Perth", :latitude => "56.39522", :longitude => "-3.43139").save
City.new(:country_id => "79", :name => "Penzance", :aliases => "Pennsans,Penzance,Penzance", :latitude => "50.11861", :longitude => "-5.53715").save
City.new(:country_id => "79", :name => "Penicuik", :aliases => ",Penicuik", :latitude => "55.83166", :longitude => "-3.22423").save
City.new(:country_id => "79", :name => "Penarth", :aliases => ",Penarth", :latitude => "51.43942", :longitude => "-3.17609").save
City.new(:country_id => "79", :name => "Paisley", :aliases => "Pejsli,ÐÐµÐ¹ÑÐ»Ð¸,Paisley", :latitude => "55.83173", :longitude => "-4.43254").save
City.new(:country_id => "79", :name => "Paignton", :aliases => "Paignton,Pehjnton,ÐÑÐ¹Ð½ÑÐ¾Ð½,Paignton", :latitude => "50.43565", :longitude => "-3.56789").save
City.new(:country_id => "79", :name => "Oxford", :aliases => "Oksford,Oksfordas,Oksfordo,Oxford,Oxonia,Oxphorde,Rhydychen,Rysoghen,aksfwrd,ogseupeodeu,okkusufodo,ÎÎ¾ÏÏÏÎ´Î·,ÐÐºÑÑÐ¾ÑÐ´,×××§×¡×¤××¨×,Ø£ÙØ³ÙÙØ±Ø¯,ãªãã¯ã¹ãã©ã¼ã,ì¥ì¤í¼ë,Oxford", :latitude => "51.75222", :longitude => "-1.25596").save
City.new(:country_id => "79", :name => "Oswestry", :aliases => "Croesoswallt,Oswestry,Oswestry", :latitude => "52.86195", :longitude => "-3.05497").save
City.new(:country_id => "79", :name => "Ossett", :aliases => ",Ossett", :latitude => "53.67978", :longitude => "-1.58006").save
City.new(:country_id => "79", :name => "Ormskirk", :aliases => "Ormskirk,Ormskirk", :latitude => "53.56685", :longitude => "-2.88178").save
City.new(:country_id => "79", :name => "Omagh", :aliases => "An Oghmagh,An Omaigh,An Ãmaigh,Oma,ÐÐ¼Ð°,Omagh", :latitude => "54.6", :longitude => "-7.3").save
City.new(:country_id => "79", :name => "Oldham", :aliases => "Oldem,Oldham,ÐÐ»Ð´ÐµÐ¼,Oldham", :latitude => "53.54051", :longitude => "-2.1183").save
City.new(:country_id => "79", :name => "Oadby", :aliases => "Oadby,Oadby", :latitude => "52.60621", :longitude => "-1.08354").save
City.new(:country_id => "79", :name => "Nuneaton", :aliases => "Naniton,Nuneaton,ÐÐ°Ð½Ð¸ÑÐ¾Ð½,Nuneaton", :latitude => "52.52323", :longitude => "-1.46523").save
City.new(:country_id => "79", :name => "Nottingham", :aliases => "Nottigham,Nottingem,Nottingham,nottingamu,nuo ding han,nuo ding xian,nwtnghham,ÐÐ¾ÑÑÐ¸Ð½Ð³ÐµÐ¼,ÐÐ¾ÑÑÐ¸Ð½Ð³Ò³Ð°Ð¼,× ×××× ××××,ÙÙØªÙØºÙØ§Ù,ãããã£ã³ã¬ã ,è«¾å®å¸,è¯ºä¸æ±,Nottingham", :latitude => "52.9536", :longitude => "-1.15047").save
City.new(:country_id => "79", :name => "Norwich", :aliases => "Noridzh,Norwich,nwrwytsh,ÐÐ¾ÑÐ¸Ð´Ð¶,ÙÙØ±ÙÙØªØ´,Norwich", :latitude => "52.62783", :longitude => "1.29834").save
City.new(:country_id => "79", :name => "Northwich", :aliases => "Northwick,Nortvich,ÐÐ¾ÑÑÐ²Ð¸Ñ,Northwich", :latitude => "53.26138", :longitude => "-2.51225").save
City.new(:country_id => "79", :name => "North Shields", :aliases => ",North Shields", :latitude => "55.01646", :longitude => "-1.44925").save
City.new(:country_id => "79", :name => "Northampton", :aliases => "Nortgempton,Northampton,Nortkhempton,Nortkhemptun,ÐÐ¾ÑÑÐ³ÐµÐ¼Ð¿ÑÐ¾Ð½,ÐÐ¾ÑÑÑÐµÐ¼Ð¿ÑÐ¾Ð½,ÐÐ¾ÑÑÑÐµÐ¼Ð¿ÑÑÐ½,Northampton", :latitude => "52.25", :longitude => "-0.88333").save
City.new(:country_id => "79", :name => "Northallerton", :aliases => ",Northallerton", :latitude => "54.33901", :longitude => "-1.43243").save
City.new(:country_id => "79", :name => "Newtownards", :aliases => ",Newtownards", :latitude => "54.59236", :longitude => "-5.69092").save
City.new(:country_id => "79", :name => "Newtownabbey", :aliases => "N'jutonehbbej,Newtownabbey,ÐÑÑÑÐ¾Ð½ÑÐ±Ð±ÐµÐ¹,Newtownabbey", :latitude => "54.65983", :longitude => "-5.90858").save
City.new(:country_id => "79", :name => "Newton Mearns", :aliases => "Newton Mearns,Newton Mearns", :latitude => "55.77334", :longitude => "-4.33339").save
City.new(:country_id => "79", :name => "Newton-le-Willows", :aliases => ",Newton-le-Willows", :latitude => "53.45", :longitude => "-2.6").save
City.new(:country_id => "79", :name => "Newton Aycliffe", :aliases => "Newton Aycliffe,Newton Aycliffe", :latitude => "54.61842", :longitude => "-1.5719").save
City.new(:country_id => "79", :name => "Newton Abbot", :aliases => "Newton Abbot,Newton Abbot", :latitude => "50.52858", :longitude => "-3.61186").save
City.new(:country_id => "79", :name => "Newry", :aliases => "An tiur,An tÃ¯Ãºr,Iubhar Cinn Tragha,Iubhar Cinn TrÃ¡gha,N'juri,ÐÑÑÑÐ¸,Newry", :latitude => "54.17841", :longitude => "-6.33739").save
City.new(:country_id => "79", :name => "Newquay", :aliases => "Newquay,Newquay", :latitude => "50.41317", :longitude => "-5.08186").save
City.new(:country_id => "79", :name => "Newport Pagnell", :aliases => "Newport Pagnell,Newport Pagnell", :latitude => "52.08731", :longitude => "-0.72218").save
City.new(:country_id => "79", :name => "Newport", :aliases => "Casnewydd-ar-Wysg,N'juport,Newport,Novus Burgus,ÐÑÑÐ¿Ð¾ÑÑ,Newport", :latitude => "51.58774", :longitude => "-2.99835").save
City.new(:country_id => "79", :name => "Newport", :aliases => "N'juport,ÐÑÑÐ¿Ð¾ÑÑ,Newport", :latitude => "50.70146", :longitude => "-1.29124").save
City.new(:country_id => "79", :name => "Newmarket", :aliases => "Newmarket,Newmarket", :latitude => "52.24467", :longitude => "0.40418").save
City.new(:country_id => "79", :name => "Newcastle upon Tyne", :aliases => "N'jukasl,Neuchate,NeuchÃ¢tÃ©,Newcastle,Newcastle upon Tyne,Newcastle-on-Tyne,Newcastle-upon-Tyne,nywkasl,nywkasl abwn tayn,tai en he pan niu ka si er,ÐÑÑÐºÐ°ÑÐ»,× ×××§××¡×,ÙÙÙÙØ§Ø³Ù Ø£Ø¨ÙÙ ØªØ§ÙÙ,ÙÛÙÚ©Ø§Ø³Ù,ãã¥ã¼ã«ãã¹ã«ã»ã¢ãã³ã»ã¿ã¤ã³,æ³°æ©æ²³ççº½å¡æ¯å°,Newcastle upon Tyne", :latitude => "54.97328", :longitude => "-1.61396").save
City.new(:country_id => "79", :name => "Newcastle under Lyme", :aliases => "Newcastle under Lyme,Newcastle-under-Lyme,Newcastle under Lyme", :latitude => "53", :longitude => "-2.23333").save
City.new(:country_id => "79", :name => "Newbury", :aliases => "N'juberi,ÐÑÑÐ±ÐµÑÐ¸,Newbury", :latitude => "51.40033", :longitude => "-1.32059").save
City.new(:country_id => "79", :name => "Newburn", :aliases => ",Newburn", :latitude => "54.9876", :longitude => "-1.74415").save
City.new(:country_id => "79", :name => "Newark on Trent", :aliases => "Newark,Newark on Trent,Newark upon Trent,Newark on Trent", :latitude => "53.06667", :longitude => "-0.81667").save
City.new(:country_id => "79", :name => "Nelson", :aliases => "Nelson,Nelson", :latitude => "53.83333", :longitude => "-2.2").save
City.new(:country_id => "79", :name => "Neath", :aliases => "Castell Nedd,Castell-nedd,Neath,Nit,ÐÐ¸Ñ,Neath", :latitude => "51.66317", :longitude => "-3.80443").save
City.new(:country_id => "79", :name => "Nailsea", :aliases => "Nailsea,Nailsea", :latitude => "51.43239", :longitude => "-2.75847").save
City.new(:country_id => "79", :name => "Musselburgh", :aliases => ",Musselburgh", :latitude => "55.9417", :longitude => "-3.04991").save
City.new(:country_id => "79", :name => "Motherwell", :aliases => "Mazervell,ÐÐ°Ð·ÐµÑÐ²ÐµÐ»Ð»,Motherwell", :latitude => "55.78924", :longitude => "-3.99187").save
City.new(:country_id => "79", :name => "Morley", :aliases => ",Morley", :latitude => "53.74013", :longitude => "-1.59877").save
City.new(:country_id => "79", :name => "Morecambe", :aliases => "Morecambe,Morecombe,Morkam,ÐÐ¾ÑÐºÐ°Ð¼,Morecambe", :latitude => "54.06835", :longitude => "-2.86108").save
City.new(:country_id => "79", :name => "Mirfield", :aliases => ",Mirfield", :latitude => "53.67343", :longitude => "-1.69636").save
City.new(:country_id => "79", :name => "Milton Keynes", :aliases => "MK,Milton Keynes,Milton-Kins,ÐÐ¸Ð»ÑÐ¾Ð½-ÐÐ¸Ð½Ñ,Milton Keynes", :latitude => "52.04172", :longitude => "-0.75583").save
City.new(:country_id => "79", :name => "Middleton", :aliases => ",Middleton", :latitude => "53.55", :longitude => "-2.2").save
City.new(:country_id => "79", :name => "Middlesbrough", :aliases => "Middlebrough,Middlesborough,Middlesbrough,Midulsbro,mydlsbrw,ÐÐ¸Ð´ÑÐ»ÑÐ±ÑÐ¾,×××××¡××¨×,Middlesbrough", :latitude => "54.57623", :longitude => "-1.23483").save
City.new(:country_id => "79", :name => "Mexborough", :aliases => "Mexborough,Mexborough", :latitude => "53.49389", :longitude => "-1.29243").save
City.new(:country_id => "79", :name => "Merthyr Tydfil", :aliases => "M'rt'r Tidfil,Merthyr Tudful,Merthyr Tydfil,Mertir Tidfil,Mertir Tidvil,Mertyr Tydfil,ÐÐµÑÑÐ¸Ñ Ð¢Ð¸Ð´Ð²Ð¸Ð»,ÐÐµÑÑÐ¸Ñ Ð¢Ð¸Ð´ÑÐ¸Ð»,ÐÑÑÑÑÑ Ð¢Ð¸Ð´ÑÐ¸Ð»,Merthyr Tydfil", :latitude => "51.74794", :longitude => "-3.37779").save
City.new(:country_id => "79", :name => "Melton Mowbray", :aliases => "Melton Mowbray,Melton Mowbray", :latitude => "52.76588", :longitude => "-0.88693").save
City.new(:country_id => "79", :name => "Marple", :aliases => ",Marple", :latitude => "53.39452", :longitude => "-2.06292").save
City.new(:country_id => "79", :name => "Marlow", :aliases => "Great Marlow,Marlow,Marlow", :latitude => "51.56933", :longitude => "-0.77415").save
City.new(:country_id => "79", :name => "Market Harborough", :aliases => "Market Harborough,Market Harborough", :latitude => "52.4776", :longitude => "-0.92053").save
City.new(:country_id => "79", :name => "Margate", :aliases => "Margate,Margate", :latitude => "51.38132", :longitude => "1.38617").save
City.new(:country_id => "79", :name => "March", :aliases => ",March", :latitude => "52.55131", :longitude => "0.08828").save
City.new(:country_id => "79", :name => "Mansfield Woodhouse", :aliases => ",Mansfield Woodhouse", :latitude => "53.16495", :longitude => "-1.19384").save
City.new(:country_id => "79", :name => "Mansfield", :aliases => "Mansfield,Mehnsfild,ÐÑÐ½ÑÑÐ¸Ð»Ð´,Mansfield", :latitude => "53.13333", :longitude => "-1.2").save
City.new(:country_id => "79", :name => "Mangotsfield", :aliases => ",Mangotsfield", :latitude => "51.4878", :longitude => "-2.50403").save
City.new(:country_id => "79", :name => "Manchester", :aliases => "Mamucium,Manceinion,Mancesteris,Manchain,Manchester,Manchestur,ManÄesteris,man che si te,manchesuta,mantshstr,mnchstr,mnz'str,ÐÐ°Ð½ÑÐµÑÑÐµÑ,ÐÐ°Ð½ÑÐµÑÑÑÑ,×× ×¦'×¡××¨,ÙØ§ÙØªØ´Ø³ØªØ±,ÙØ§ÙÚÛØ³ØªÛØ±,ÙÙÚØ³ØªØ±,à¹à¸¡à¸à¹à¸à¸ªà¹à¸à¸­à¸£à¹,áááá©áá¡á¢áá á,ãã³ãã§ã¹ã¿ã¼,æ¼å½»æ¯ç¹,Manchester", :latitude => "53.48095", :longitude => "-2.23743").save
City.new(:country_id => "79", :name => "Maltby", :aliases => ",Maltby", :latitude => "53.41667", :longitude => "-1.2").save
City.new(:country_id => "79", :name => "Maldon", :aliases => "Malden,Maldon,Meldona,ÐÐµÐ»Ð´Ð¾Ð½Ð°,Maldon", :latitude => "51.7311", :longitude => "0.67463").save
City.new(:country_id => "79", :name => "Maidstone", :aliases => "Maidstone,Mejdston,ÐÐµÐ¹Ð´ÑÑÐ¾Ð½,Maidstone", :latitude => "51.26667", :longitude => "0.51667").save
City.new(:country_id => "79", :name => "Maidenhead", :aliases => "Maidenhead,Maidenhead", :latitude => "51.52279", :longitude => "-0.71986").save
City.new(:country_id => "79", :name => "Maesteg", :aliases => "Maesteg,Maesteg", :latitude => "51.60926", :longitude => "-3.65823").save
City.new(:country_id => "79", :name => "Macclesfield", :aliases => ",Macclesfield", :latitude => "53.26023", :longitude => "-2.12564").save
City.new(:country_id => "79", :name => "Luton", :aliases => "Luton,ÐÑÑÐ¾Ð½,Luton", :latitude => "51.87967", :longitude => "-0.41748").save
City.new(:country_id => "79", :name => "Lowestoft", :aliases => "Loustoft,Lowestoft,ÐÐ¾ÑÑÑÐ¾ÑÑ,Lowestoft", :latitude => "52.4752", :longitude => "1.75159").save
City.new(:country_id => "79", :name => "Louth", :aliases => "Laut,Louth,ÐÐ°ÑÑ,Louth", :latitude => "53.36664", :longitude => "-0.00438").save
City.new(:country_id => "79", :name => "Loughborough", :aliases => "Loughborough,Loughborough", :latitude => "52.76667", :longitude => "-1.2").save
City.new(:country_id => "79", :name => "Longfield", :aliases => ",Longfield", :latitude => "51.3969", :longitude => "0.30212").save
City.new(:country_id => "79", :name => "Long Eaton", :aliases => "Long Eaton,Long Eaton", :latitude => "52.89855", :longitude => "-1.27136").save
City.new(:country_id => "79", :name => "Londonderry County Borough", :aliases => ",Londonderry County Borough", :latitude => "54.99721", :longitude => "-7.30917").save
City.new(:country_id => "79", :name => "Derry", :aliases => "Derri,Derry,Derry / Londonderry,Derry City,Dhoire,Doire,Doire Choluim Chille,Ker Dherow,Londonderry,dry,rondonderi,ÐÐµÑÑÐ¸,××¨×,ã­ã³ãã³ããªã¼,Derry", :latitude => "54.9981", :longitude => "-7.30934").save
City.new(:country_id => "79", :name => "City of London", :aliases => ",City of London", :latitude => "51.51279", :longitude => "-0.09184").save
City.new(:country_id => "79", :name => "London", :aliases => "City,City of London,LON,Ljondan,Llundain,Londain,Londan,Londe,Londen,Londinium,Londino,London,London City,Londona,Londonas,Londoni,Londono,Londra,Londres,Londres - London,Londrez,Londyn,LondÃ½n,Lontoo,Loundres,Luan GJon,Lunden,Lundunir,LundÃºnir,Lunnainn,Lunnon,LuÃ¢n ÄÃ´n,The City,ilantan,landana,leondeon,lndn,londoni,lun dun,lwndwn,lxndxn,rondon,ÎÎ¿Î½Î´Î¯Î½Î¿,ÐÐ¾Ð½Ð´Ð°Ð½,ÐÐ¾Ð½Ð´Ð¾Ð½,ÐÑÐ½Ð´Ð°Ð½,Ô¼Õ¸Õ¶Õ¤Õ¸Õ¶,××× ×××,××× ×××,ÙÙØ¯Ù,ÙÙÙØ¯ÙÙ,Ü ÜÜ¢ÜÜÜ¢,à¤²à¤à¤¡à¤¨,à¤²à¤à¤¦à¤¨,à¦²à¦¨à§à¦¡à¦¨,àª²àªàª¡àª¨,à®à®²à®£à¯à®à®©à¯,à¸¥à¸­à¸à¸à¸­à¸,ááááááá,ááá°á,ã­ã³ãã³,ä¼¦æ¦,ë°ë,London", :latitude => "51.50853", :longitude => "-0.12574").save
City.new(:country_id => "79", :name => "Lofthouse", :aliases => ",Lofthouse", :latitude => "53.72947", :longitude => "-1.49697").save
City.new(:country_id => "79", :name => "Llanelli", :aliases => "Llanelli,Llanelly,ÐÐ»Ð°Ð½ÐµÐ»Ð»Ð¸,Llanelli", :latitude => "51.68195", :longitude => "-4.16191").save
City.new(:country_id => "79", :name => "Llandudno", :aliases => "Llandudno,Llandudno", :latitude => "53.32498", :longitude => "-3.83148").save
City.new(:country_id => "79", :name => "Livingston", :aliases => "Livingston,ÐÐ¸Ð²Ð¸Ð½Ð³ÑÑÐ¾Ð½,Livingston", :latitude => "55.90288", :longitude => "-3.52261").save
City.new(:country_id => "79", :name => "Liverpool", :aliases => "Learpholl,Lerpwl,Liberpoul,Liverpool,Liverpul,Liverpul',Liverpule,Liverpulis,LiverpÅ«le,Livurpul,Poll a' Ghruthain,li wu pu,libeopul,liwexrphul,lybrpwl,lyfrbwl,lywrpwl,rivu~apuru,ÎÎ¯Î²ÎµÏÏÎ¿ÏÎ»,ÐÐ¸Ð²ÐµÑÐ¿ÑÐ»,ÐÐ¸Ð²ÐµÑÐ¿ÑÐ»Ñ,ÐÐ¸Ð²ÑÑÐ¿ÑÐ»,××××¨×¤××,ÙÙÛÛØ±Ù¾ÛÙ,ÙÙÙØ±Ø¨ÙÙ,ÙÛÙØ±Ù¾ÙÙ,Ü ÜÜÜªÜ¦ÜÜ ,à¸¥à¸´à¹à¸§à¸­à¸£à¹à¸à¸¹à¸¥,ááááá áá£áá,ãªã´ã¡ãã¼ã«,å©ç©æµ¦,ë¦¬ë²í,Liverpool", :latitude => "53.41058", :longitude => "-2.97794").save
City.new(:country_id => "79", :name => "Littlehampton", :aliases => "Littlehampton,Littlehampton", :latitude => "50.80691", :longitude => "-0.53782").save
City.new(:country_id => "79", :name => "Litherland", :aliases => "Litherland,Litherland", :latitude => "53.46993", :longitude => "-2.99809").save
City.new(:country_id => "79", :name => "Lisburn", :aliases => "Lios na gCearrbhach,Lisbern,Lisburn,ÐÐ¸ÑÐ±ÐµÑÐ½,Lisburn", :latitude => "54.52337", :longitude => "-6.03527").save
City.new(:country_id => "79", :name => "Lincoln", :aliases => "Lincoln,Linkol'n,lingkeon,rinkan,ÐÐ¸Ð½ÐºÐ¾Ð»ÑÐ½,ãªã³ã«ã³,ë§ì»¨,Lincoln", :latitude => "53.22683", :longitude => "-0.53792").save
City.new(:country_id => "79", :name => "Lichfield", :aliases => "Letocetum,Lichfield,Lichfild,ÐÐ¸ÑÑÐ¸Ð»Ð´,Lichfield", :latitude => "52.68154", :longitude => "-1.82549").save
City.new(:country_id => "79", :name => "Leyland", :aliases => ",Leyland", :latitude => "53.69786", :longitude => "-2.68758").save
City.new(:country_id => "79", :name => "Lewes", :aliases => ",Lewes", :latitude => "50.87363", :longitude => "0.01133").save
City.new(:country_id => "79", :name => "Letchworth", :aliases => "Lechuort,Letchworth,Letchworth Garden,ÐÐµÑÑÐ¾ÑÑ,Letchworth", :latitude => "51.97944", :longitude => "-0.2284").save
City.new(:country_id => "79", :name => "Leighton Buzzard", :aliases => ",Leighton Buzzard", :latitude => "51.91722", :longitude => "-0.65802").save
City.new(:country_id => "79", :name => "Leigh", :aliases => ",Leigh", :latitude => "53.48333", :longitude => "-2.51667").save
City.new(:country_id => "79", :name => "Leicester", :aliases => "Caerlyr,CaerlÅ·r,Leicester,Leiscester,Lester,laystr,lstr,lystr,resuta,ÐÐµÑÑÐµÑ,××¡××¨,ÙØ§ÙØ³ØªØ±,ÙÙØ³ØªØ±,ã¬ã¹ã¿ã¼,Leicester", :latitude => "52.6386", :longitude => "-1.13169").save
City.new(:country_id => "79", :name => "Leek", :aliases => "Leek,Leek", :latitude => "53.10434", :longitude => "-2.02207").save
City.new(:country_id => "79", :name => "Leeds", :aliases => "Leeds,Lids,Lidsa,Lijds,Lydsas,LÄ«dsa,lyds,lydz,rizu,ÐÐ¸Ð´Ñ,ÐÐ¸Ð¹Ð´Ñ,××××¡,ÙÙØ¯Ø²,ÙÛØ¯Ø²,ãªã¼ãº,Leeds", :latitude => "53.79648", :longitude => "-1.54785").save
City.new(:country_id => "79", :name => "Leatherhead", :aliases => "Leatherhead,Leatherhead", :latitude => "51.29593", :longitude => "-0.3259").save
City.new(:country_id => "79", :name => "Leamington", :aliases => "Leamington,Leamington Spa,Limingtone,Royal Leamington Spa,ÐÐ¸Ð¼Ð¸Ð½Ð³ÑÐ¾Ð½Ðµ,Leamington", :latitude => "52.3", :longitude => "-1.53333").save
City.new(:country_id => "79", :name => "Larne", :aliases => ",Larne", :latitude => "54.85", :longitude => "-5.81667").save
City.new(:country_id => "79", :name => "Larkhall", :aliases => "Darkhall,Larkhall,Larkhall", :latitude => "55.73333", :longitude => "-3.96667").save
City.new(:country_id => "79", :name => "Lancaster", :aliases => "Lancaster,Lankaster,ÐÐ°Ð½ÐºÐ°ÑÑÐµÑ,Lancaster", :latitude => "54.06667", :longitude => "-2.83333").save
City.new(:country_id => "79", :name => "Kirkintilloch", :aliases => "Kirkintillock,Kirkintilloch", :latitude => "55.93933", :longitude => "-4.15262").save
City.new(:country_id => "79", :name => "Kirkcaldy", :aliases => "Kirkcaldy,Kirkcaudy,Kirkcaldy", :latitude => "56.10982", :longitude => "-3.16149").save
City.new(:country_id => "79", :name => "Kirkby in Ashfield", :aliases => "Kirkby,Kirkby in Ashfield,Kirkby in Ashfield", :latitude => "53.09982", :longitude => "-1.24379").save
City.new(:country_id => "79", :name => "Kirkby", :aliases => ",Kirkby", :latitude => "53.48333", :longitude => "-2.9").save
City.new(:country_id => "79", :name => "Kingswood", :aliases => "Kingsvud,Kingswood,ÐÐ¸Ð½Ð³ÑÐ²ÑÐ´,Kingswood", :latitude => "51.45278", :longitude => "-2.50833").save
City.new(:country_id => "79", :name => "Hull", :aliases => "Hull,Kingston upon Hull,Kingston-apon-Khall,Kingston-upon-Hull,he er,ÐÐ¸Ð½Ð³ÑÑÐ¾Ð½-Ð°Ð¿Ð¾Ð½-Ð¥Ð°Ð»Ð»,×××,èµ«ç¾,Hull", :latitude => "53.7446", :longitude => "-0.33525").save
City.new(:country_id => "79", :name => "King's Lynn", :aliases => "Kings Lynn,Kingslinn,Lynn,Lynn Regis,ÐÐ¸Ð½Ð³ÑÐ»Ð¸Ð½Ð½,King's Lynn", :latitude => "52.75172", :longitude => "0.39516").save
City.new(:country_id => "79", :name => "Kilwinning", :aliases => ",Kilwinning", :latitude => "55.65333", :longitude => "-4.70666").save
City.new(:country_id => "79", :name => "Kilmarnock", :aliases => "Cill Mhearnag,Cill MheÃ rnag,Kilmarnok,ÐÐ¸Ð»Ð¼Ð°ÑÐ½Ð¾Ðº,Kilmarnock", :latitude => "55.61171", :longitude => "-4.49581").save
City.new(:country_id => "79", :name => "Kidsgrove", :aliases => "Kidsgrove,Kidsgrove", :latitude => "53.08691", :longitude => "-2.23777").save
City.new(:country_id => "79", :name => "Kidlington", :aliases => "Kidlington,Kidlington", :latitude => "51.82166", :longitude => "-1.2886").save
City.new(:country_id => "79", :name => "Kidderminster", :aliases => "Kidderminster,Kidderminster", :latitude => "52.38819", :longitude => "-2.25").save
City.new(:country_id => "79", :name => "Keynsham", :aliases => "Keynsham,Keynsham", :latitude => "51.41387", :longitude => "-2.4978").save
City.new(:country_id => "79", :name => "Kettering", :aliases => "Kettering,ÐÐµÑÑÐµÑÐ¸Ð½Ð³,Kettering", :latitude => "52.39836", :longitude => "-0.72571").save
City.new(:country_id => "79", :name => "Kenilworth", :aliases => "Kenilworth,Kenilworth", :latitude => "52.34286", :longitude => "-1.58015").save
City.new(:country_id => "79", :name => "Kendal", :aliases => "Kendal,Kendall,ÐÐµÐ½Ð´Ð°Ð»,Kendal", :latitude => "54.32681", :longitude => "-2.74757").save
City.new(:country_id => "79", :name => "Kempston", :aliases => ",Kempston", :latitude => "52.11599", :longitude => "-0.50044").save
City.new(:country_id => "79", :name => "Keighley", :aliases => "Keighley,Kejli,ÐÐµÐ¹Ð»Ð¸,Keighley", :latitude => "53.86791", :longitude => "-1.90664").save
City.new(:country_id => "79", :name => "Johnstone", :aliases => "Johnstone,Johnstone", :latitude => "55.82906", :longitude => "-4.51605").save
City.new(:country_id => "79", :name => "Jarrow", :aliases => "Dzharrou,Jarrow,Jarrow-on-Tyne,ÐÐ¶Ð°ÑÑÐ¾Ñ,Jarrow", :latitude => "54.98036", :longitude => "-1.48423").save
City.new(:country_id => "79", :name => "Islington", :aliases => ",Islington", :latitude => "51.53622", :longitude => "-0.10304").save
City.new(:country_id => "79", :name => "Irvine", :aliases => ",Irvine", :latitude => "55.6194", :longitude => "-4.65508").save
City.new(:country_id => "79", :name => "Irlam", :aliases => ",Irlam", :latitude => "53.44253", :longitude => "-2.42323").save
City.new(:country_id => "79", :name => "Ipswich", :aliases => "Ipsuich,Ipswich,abswytsh,ÐÐ¿ÑÑÐ¸Ñ,Ø¥Ø¨Ø³ÙÙØªØ´,Ipswich", :latitude => "52.05917", :longitude => "1.15545").save
City.new(:country_id => "79", :name => "Inverness", :aliases => "Inbhir Nis,Innerness,Inverness,Invurnes,aynwrns,in'vu~anesu,yin wei nei si,ÐÐ½Ð²ÐµÑÐ½ÐµÑÑ,ÐÐ½Ð²ÑÑÐ½ÐµÑ,Ø§ÛÙÙØ±ÙØ³,ã¤ã³ã´ã¡ãã¹,å°å¨å§æ¯,Inverness", :latitude => "57.47908", :longitude => "-4.22398").save
City.new(:country_id => "79", :name => "Ilkeston", :aliases => "Ilkeston,Ilkeston", :latitude => "52.97055", :longitude => "-1.30951").save
City.new(:country_id => "79", :name => "Hythe", :aliases => ",Hythe", :latitude => "50.86004", :longitude => "-1.40162").save
City.new(:country_id => "79", :name => "Hyde", :aliases => ",Hyde", :latitude => "53.45131", :longitude => "-2.07943").save
City.new(:country_id => "79", :name => "Huyton", :aliases => "Huyton,Huyton with Roby,Khejton,Ð¥ÐµÐ¹ÑÐ¾Ð½,Huyton", :latitude => "53.4115", :longitude => "-2.83935").save
City.new(:country_id => "79", :name => "Huntingdon", :aliases => "Huntingdon,Huntingdon", :latitude => "52.33049", :longitude => "-0.18651").save
City.new(:country_id => "79", :name => "Huddersfield", :aliases => "Huddersfield,Khaddersfild,Ð¥Ð°Ð´Ð´ÐµÑÑÑÐ¸Ð»Ð´,Huddersfield", :latitude => "53.64904", :longitude => "-1.78416").save
City.new(:country_id => "79", :name => "Hucknall Torkard", :aliases => ",Hucknall Torkard", :latitude => "53.03333", :longitude => "-1.2").save
City.new(:country_id => "79", :name => "Hoyland Nether", :aliases => "Hoyland,Hoyland Nether,Hoyland Nether", :latitude => "53.5", :longitude => "-1.45").save
City.new(:country_id => "79", :name => "Hove", :aliases => "Hove,Khouv,Ð¥Ð¾ÑÐ²,Hove", :latitude => "50.83088", :longitude => "-0.1672").save
City.new(:country_id => "79", :name => "Houghton le Spring", :aliases => ",Houghton le Spring", :latitude => "54.84034", :longitude => "-1.46427").save
City.new(:country_id => "79", :name => "Horwich", :aliases => ",Horwich", :latitude => "53.60126", :longitude => "-2.54975").save
City.new(:country_id => "79", :name => "Horsham", :aliases => "Horsham,Khorshehm,West Horsham,Ð¥Ð¾ÑÑÑÐ¼,Horsham", :latitude => "51.06395", :longitude => "-0.32719").save
City.new(:country_id => "79", :name => "Horsforth", :aliases => ",Horsforth", :latitude => "53.83797", :longitude => "-1.64036").save
City.new(:country_id => "79", :name => "Hoddesdon", :aliases => "Hoddesdon,Khoddsdon,Ð¥Ð¾Ð´Ð´ÑÐ´Ð¾Ð½,Hoddesdon", :latitude => "51.76148", :longitude => "-0.01144").save
City.new(:country_id => "79", :name => "Hitchin", :aliases => "Hitchin,Hitchin", :latitude => "51.95314", :longitude => "-0.26519").save
City.new(:country_id => "79", :name => "Hindley", :aliases => ",Hindley", :latitude => "53.53333", :longitude => "-2.58333").save
City.new(:country_id => "79", :name => "Hinckley", :aliases => "Hinckley,Khinkli,Ð¥Ð¸Ð½ÐºÐ»Ð¸,Hinckley", :latitude => "52.5389", :longitude => "-1.37613").save
City.new(:country_id => "79", :name => "High Wycombe", :aliases => "Chepping,High Wycombe,Wycombe,High Wycombe", :latitude => "51.62907", :longitude => "-0.74934").save
City.new(:country_id => "79", :name => "High Blantyre", :aliases => "Blantyre,High Blantyre,High Blantyre", :latitude => "55.78438", :longitude => "-4.10007").save
City.new(:country_id => "79", :name => "Heswall", :aliases => ",Heswall", :latitude => "53.32733", :longitude => "-3.09648").save
City.new(:country_id => "79", :name => "Hertford", :aliases => "Khertford,Ð¥ÐµÑÑÑÐ¾ÑÐ´,Hertford", :latitude => "51.79588", :longitude => "-0.07854").save
City.new(:country_id => "79", :name => "Herne Bay", :aliases => "Herne Bay,Herne Bay", :latitude => "51.373", :longitude => "1.12857").save
City.new(:country_id => "79", :name => "Hereford", :aliases => "Henffordd,Hereford,Khereforde,Ð¥ÐµÑÐµÑÐ¾ÑÐ´Ðµ,Hereford", :latitude => "52.05684", :longitude => "-2.71482").save
City.new(:country_id => "79", :name => "Hemel Hempstead", :aliases => "Hemel,Hemel Hempstead,Hemel Hempstead", :latitude => "51.75369", :longitude => "-0.47517").save
City.new(:country_id => "79", :name => "Heanor", :aliases => ",Heanor", :latitude => "53.01372", :longitude => "-1.35383").save
City.new(:country_id => "79", :name => "Haywards Heath", :aliases => "Baywards Heath,Haywards Heath,Haywards Heath", :latitude => "50.99769", :longitude => "-0.10313").save
City.new(:country_id => "79", :name => "Haydock", :aliases => ",Haydock", :latitude => "53.46723", :longitude => "-2.68166").save
City.new(:country_id => "79", :name => "Hawarden", :aliases => "Hawarden,Khavarden,Penarlag,PenarlÃ¢g,Ð¥Ð°Ð²Ð°ÑÐ´ÐµÐ½,Hawarden", :latitude => "53.18478", :longitude => "-3.02578").save
City.new(:country_id => "79", :name => "Haverhill", :aliases => ",Haverhill", :latitude => "52.08226", :longitude => "0.43891").save
City.new(:country_id => "79", :name => "Havant", :aliases => "Havant,Khavant,Ð¥Ð°Ð²Ð°Ð½Ñ,Havant", :latitude => "50.8567", :longitude => "-0.98559").save
City.new(:country_id => "79", :name => "Hatfield", :aliases => "Bishops Hatfield,Hatfield,Hatfield", :latitude => "51.76338", :longitude => "-0.22419").save
City.new(:country_id => "79", :name => "Hastings", :aliases => "Gastings,Hastings,Khejstings,hystnghs,ÐÐ°ÑÑÐ¸Ð½Ð³Ñ,Ð¥ÐµÐ¹ÑÑÐ¸Ð½Ð³Ñ,ÙÙØ³ØªÙØºØ³,Hastings", :latitude => "50.85299", :longitude => "0.56459").save
City.new(:country_id => "79", :name => "Haslingden", :aliases => "Haslingden,Haslingden", :latitude => "53.70326", :longitude => "-2.32382").save
City.new(:country_id => "79", :name => "Harwich", :aliases => "Harwich,Harwick,Kharvich,Ð¥Ð°ÑÐ²Ð¸Ñ,Harwich", :latitude => "51.94194", :longitude => "1.28437").save
City.new(:country_id => "79", :name => "Hartlepool", :aliases => "Hartlepool,Khartlpul,Ð¥Ð°ÑÑÐ»Ð¿ÑÐ»,Hartlepool", :latitude => "54.68611", :longitude => "-1.2125").save
City.new(:country_id => "79", :name => "Harrogate", :aliases => "Harrogate,Kharrogejt,Ð¥Ð°ÑÑÐ¾Ð³ÐµÐ¹Ñ,Harrogate", :latitude => "53.99078", :longitude => "-1.5373").save
City.new(:country_id => "79", :name => "Harpenden", :aliases => ",Harpenden", :latitude => "51.81684", :longitude => "-0.35706").save
City.new(:country_id => "79", :name => "Harlow", :aliases => "Harlow,Kharlou,Ð¥Ð°ÑÐ»Ð¾Ñ,Harlow", :latitude => "51.77655", :longitude => "0.11158").save
City.new(:country_id => "79", :name => "Hamilton", :aliases => "Gamil'ton,ÐÐ°Ð¼Ð¸Ð»ÑÑÐ¾Ð½,Hamilton", :latitude => "55.76667", :longitude => "-4.03333").save
City.new(:country_id => "79", :name => "Halifax", :aliases => "Galifaks,Halifax,ÐÐ°Ð»Ð¸ÑÐ°ÐºÑ,Halifax", :latitude => "53.71667", :longitude => "-1.85").save
City.new(:country_id => "79", :name => "Halesowen", :aliases => "Halesowen,Khejlsoven,Ð¥ÐµÐ¹Ð»ÑÐ¾Ð²ÐµÐ½,Halesowen", :latitude => "52.44859", :longitude => "-2.04938").save
City.new(:country_id => "79", :name => "Hale", :aliases => ",Hale", :latitude => "51.21667", :longitude => "-0.78333").save
City.new(:country_id => "79", :name => "Hailsham", :aliases => "Hailsham,Hailsham", :latitude => "50.8622", :longitude => "0.25775").save
City.new(:country_id => "79", :name => "Guisborough", :aliases => ",Guisborough", :latitude => "54.53478", :longitude => "-1.05606").save
City.new(:country_id => "79", :name => "Guildford", :aliases => "Gilford,Guildford,Guilford,jylfwrd,ÐÐ¸Ð»ÑÐ¾ÑÐ´,Ø¬ÙÙÙÙØ±Ø¯,Guildford", :latitude => "51.23536", :longitude => "-0.57427").save
City.new(:country_id => "79", :name => "Grove", :aliases => ",Grove", :latitude => "51.60954", :longitude => "-1.42187").save
City.new(:country_id => "79", :name => "Greenock", :aliases => "Greenock,Grijnok,Grinok,ÐÑÐ¸Ð¹Ð½Ð¾Ðº,ÐÑÐ¸Ð½Ð¾Ðº,Greenock", :latitude => "55.94838", :longitude => "-4.76121").save
City.new(:country_id => "79", :name => "Great Yarmouth", :aliases => "Yarmouth,Great Yarmouth", :latitude => "52.60831", :longitude => "1.73052").save
City.new(:country_id => "79", :name => "Great Wyrley", :aliases => "Great Wyrley,Wyrley,Great Wyrley", :latitude => "52.66277", :longitude => "-2.01111").save
City.new(:country_id => "79", :name => "Great Sankey", :aliases => "Great Sankey,Sankey,Great Sankey", :latitude => "53.39234", :longitude => "-2.63994").save
City.new(:country_id => "79", :name => "Great Malvern", :aliases => "Great Malvern,Malvern,Great Malvern", :latitude => "52.11161", :longitude => "-2.32515").save
City.new(:country_id => "79", :name => "Grays", :aliases => "Grays,Grays Thurrock,Grays", :latitude => "51.47566", :longitude => "0.32521").save
City.new(:country_id => "79", :name => "Gravesend", :aliases => "Gravesend,Gravesend", :latitude => "51.44138", :longitude => "0.37371").save
City.new(:country_id => "79", :name => "Grantham", :aliases => "Grantham,Granty,ÐÑÐ°Ð½ÑÑ,Grantham", :latitude => "52.91149", :longitude => "-0.64184").save
City.new(:country_id => "79", :name => "Grangemouth", :aliases => "Grangemouth,Grangemouth", :latitude => "56.01141", :longitude => "-3.72183").save
City.new(:country_id => "79", :name => "Gosport", :aliases => "Gosport,Gosport", :latitude => "50.79509", :longitude => "-1.12902").save
City.new(:country_id => "79", :name => "Gosforth", :aliases => ",Gosforth", :latitude => "55", :longitude => "-1.61667").save
City.new(:country_id => "79", :name => "Gorseinon", :aliases => ",Gorseinon", :latitude => "51.66931", :longitude => "-4.04163").save
City.new(:country_id => "79", :name => "Goole", :aliases => ",Goole", :latitude => "53.71667", :longitude => "-0.86667").save
City.new(:country_id => "79", :name => "Golborne", :aliases => ",Golborne", :latitude => "53.47693", :longitude => "-2.59651").save
City.new(:country_id => "79", :name => "Godalming", :aliases => "Godalming,Godalminge,Goldaming,ÐÐ¾Ð´Ð°Ð»Ð¼Ð¸Ð½Ð³Ðµ,Godalming", :latitude => "51.18462", :longitude => "-0.61725").save
City.new(:country_id => "79", :name => "Gloucester", :aliases => "Caerloyw,Gloster,Gloucester,ge luo si te,ghlwshstr,gurosuta,ÐÐ»Ð¾ÑÑÐµÑ,ØºÙÙØ´Ø³ØªØ±,ã°ã­ã¹ã¿ã¼,æ ¼æ´æ¯ç¹,Gloucester", :latitude => "51.86568", :longitude => "-2.2431").save
City.new(:country_id => "79", :name => "Glossop", :aliases => "Glossop,Glossop", :latitude => "53.44325", :longitude => "-1.949").save
City.new(:country_id => "79", :name => "Glenrothes", :aliases => ",Glenrothes", :latitude => "56.19514", :longitude => "-3.17316").save
City.new(:country_id => "79", :name => "Glasgow", :aliases => "Glaschu,GlaschÃº,Glasgovia,Glasgovo,Glasgow,Glaskobe,Glazgas,Glazgo,Glazgou,Glazgov,Glazgova,Glesca,GlÄzgova,ge la si ge,geullaeseugo,glasago,glasgw,glasgwv,glazgo,gurasugo,klas kow,ÎÎ»Î±ÏÎºÏÎ²Î·,ÐÐ»Ð°Ð·Ð³Ð¾,ÐÐ»Ð°Ð·Ð³Ð¾Ð²,ÐÐ»Ð°Ð·Ð³Ð¾Ñ,××××××,Ú¯ÙØ§Ø³Ú¯Ù,Ú¯ÙØ§Ø³Ú¯ÙÛ,à¤à¥à¤²à¤¾à¤¸à¤à¥,à¸à¸¥à¸²à¸ªà¹à¸à¸§à¹,áááááá,ã°ã©ã¹ã´ã¼,æ ¼ææ¯å¥,ê¸ëì¤ê³ ,Glasgow", :latitude => "55.86515", :longitude => "-4.25763").save
City.new(:country_id => "79", :name => "Gillingham", :aliases => "Dzhillingem,Gillingham,ÐÐ¶Ð¸Ð»Ð»Ð¸Ð½Ð³ÐµÐ¼,×'×××× ××××,Gillingham", :latitude => "51.38914", :longitude => "0.54863").save
City.new(:country_id => "79", :name => "Giffnock", :aliases => "Giffneck,Giffnock", :latitude => "55.80373", :longitude => "-4.29488").save
City.new(:country_id => "79", :name => "Gelligaer", :aliases => "Gelligaer,Gelligaer", :latitude => "51.66444", :longitude => "-3.25611").save
City.new(:country_id => "79", :name => "Gateshead", :aliases => "Gateshead,Gateshead-on-Tyne,Gejtskhed,gyytshd,ÐÐµÐ¹ÑÑÑÐµÐ´,×××××¡××,Gateshead", :latitude => "54.96209", :longitude => "-1.60168").save
City.new(:country_id => "79", :name => "Garforth", :aliases => ",Garforth", :latitude => "53.79173", :longitude => "-1.38067").save
City.new(:country_id => "79", :name => "Gainsborough", :aliases => "Gainesborough,Gainsborough,Gainsborough", :latitude => "53.38333", :longitude => "-0.76667").save
City.new(:country_id => "79", :name => "Fylde", :aliases => "Borough of Fylde,Fylde,Fylde Borough,Fylde Coast,Fylde", :latitude => "53.83333", :longitude => "-2.91667").save
City.new(:country_id => "79", :name => "Frome", :aliases => "Frome,Frome", :latitude => "51.22834", :longitude => "-2.32211").save
City.new(:country_id => "79", :name => "Frinton-on-Sea", :aliases => "Frinton,Frinton-on-Sea,Frinton-on-Sea", :latitude => "51.83877", :longitude => "1.24625").save
City.new(:country_id => "79", :name => "Formby", :aliases => ",Formby", :latitude => "53.55364", :longitude => "-3.06816").save
City.new(:country_id => "79", :name => "Folkestone", :aliases => "Folkestone,Folkston,Ð¤Ð¾Ð»ÐºÑÑÐ¾Ð½,Folkestone", :latitude => "51.08333", :longitude => "1.18333").save
City.new(:country_id => "79", :name => "Fleetwood", :aliases => "Fleetwood,Fleetwood", :latitude => "53.92527", :longitude => "-3.01085").save
City.new(:country_id => "79", :name => "Fleet", :aliases => "Fleet,Fleet", :latitude => "51.28333", :longitude => "-0.83333").save
City.new(:country_id => "79", :name => "Felling", :aliases => ",Felling", :latitude => "54.95297", :longitude => "-1.57152").save
City.new(:country_id => "79", :name => "Felixstowe", :aliases => "Felixstowe,Felixstowe", :latitude => "51.96375", :longitude => "1.3511").save
City.new(:country_id => "79", :name => "Faversham", :aliases => "Faversham,Faversham", :latitude => "51.3148", :longitude => "0.88856").save
City.new(:country_id => "79", :name => "Farnworth", :aliases => "Farnworth,Farnworth", :latitude => "53.55", :longitude => "-2.4").save
City.new(:country_id => "79", :name => "Farnham", :aliases => "Farnham,Farnham", :latitude => "51.21433", :longitude => "-0.79587").save
City.new(:country_id => "79", :name => "Farnborough", :aliases => "Farnboro,Farnborough,Ð¤Ð°ÑÐ½Ð±Ð¾ÑÐ¾,Farnborough", :latitude => "51.29424", :longitude => "-0.75565").save
City.new(:country_id => "79", :name => "Fareham", :aliases => ",Fareham", :latitude => "50.85162", :longitude => "-1.17929").save
City.new(:country_id => "79", :name => "Falmouth", :aliases => "Aberfal,Falmouth,Falmut,Ð¤Ð°Ð»Ð¼ÑÑ,Falmouth", :latitude => "50.15441", :longitude => "-5.07113").save
City.new(:country_id => "79", :name => "Falkirk", :aliases => "Falkirk,Ð¤Ð°Ð»ÐºÐ¸ÑÐº,Falkirk", :latitude => "55.99917", :longitude => "-3.78713").save
City.new(:country_id => "79", :name => "Failsworth", :aliases => ",Failsworth", :latitude => "53.51667", :longitude => "-2.13333").save
City.new(:country_id => "79", :name => "Exeter", :aliases => "Ehkseter,Exeter,Exonia,Karesk,ai xi te,aksytr,ekuseta,xek se texr,xek si texr,Ð­ÐºÑÐµÑÐµÑ,Ø¥ÙØ³ÙØªØ±,à¹à¸­à¸à¹à¸à¹à¸à¸­à¸£à¹,à¹à¸­à¹à¸à¸à¸µà¹à¸à¸­à¸£à¹,ã¨ã¯ã»ã¿ã¼,è¾å¸ç¹,Exeter", :latitude => "50.7236", :longitude => "-3.52751").save
City.new(:country_id => "79", :name => "Evesham", :aliases => "Evesham,Evesham", :latitude => "52.09237", :longitude => "-1.94887").save
City.new(:country_id => "79", :name => "Esher", :aliases => "Ehsher,Esher,Ð­ÑÐµÑ,Esher", :latitude => "51.36926", :longitude => "-0.36572").save
City.new(:country_id => "79", :name => "Epsom", :aliases => "Ehpsom,Epsom,Ð­Ð¿ÑÐ¾Ð¼,Epsom", :latitude => "51.3305", :longitude => "-0.27011").save
City.new(:country_id => "79", :name => "Emsworth", :aliases => ",Emsworth", :latitude => "50.84779", :longitude => "-0.93697").save
City.new(:country_id => "79", :name => "Ellesmere Port", :aliases => "Ellesmere Port,Ellesmere Port", :latitude => "53.27875", :longitude => "-2.90134").save
City.new(:country_id => "79", :name => "Elgin", :aliases => "Ehlgin,Elgin,ÐÐ»Ð³Ð¸Ð½,Ð­Ð»Ð³Ð¸Ð½,Elgin", :latitude => "57.65", :longitude => "-3.33333").save
City.new(:country_id => "79", :name => "Egham", :aliases => "Egham,Ehgkhem,Ð­Ð³ÑÐµÐ¼,Egham", :latitude => "51.43158", :longitude => "-0.55239").save
City.new(:country_id => "79", :name => "Edinburgh", :aliases => "Caeredin,Dinedin,Dun Eideann,DÃ¹n Ãideann,DÃºn Ãideann,Edimborg,Edimbourg,Edimbourgo,Edimburg,Edimburgo,Edimburgo - Dun Eideann,Edimburgo - DÃ¹n Ãideann,Edimburgu,Edimburgum,Edinborg,Edinburg,Edinburga,Edinburgas,Edinburgh,Edinburgo,Edinburrie,Edynburg,Ehdinburg,Embra,adynbwrg,ai ding bao,edeunbeoleo,edinabara,edinbara,xedinbara,Ãdimbourg,ÎÎ´Î¹Î¼Î²Î¿ÏÏÎ³Î¿,ÐÐ´Ð¸Ð½Ð±ÑÑÐ³,Ð­Ð´Ð¸Ð½Ð±ÑÑÐ³,×××× ×××¨×,Ø¦ÛØ¯ÙÙØ¨ÛØ±Ú¯,Ø§Ø¯ÛÙØ¨ÙØ±Ú¯,à¤à¤¡à¤¿à¤¨à¤¬à¤°à¤¾,à¦à¦¡à¦¿à¦¨à¦¬à¦°à¦¾,à¹à¸­à¸à¸´à¸à¸à¸°à¸£à¸°,ã¨ãã£ã³ãã©,ç±ä¸å ¡,ìë ë²ë¬,Edinburgh", :latitude => "55.95206", :longitude => "-3.19648").save
City.new(:country_id => "79", :name => "Eccles", :aliases => ",Eccles", :latitude => "53.48333", :longitude => "-2.33333").save
City.new(:country_id => "79", :name => "Ebbw Vale", :aliases => ",Ebbw Vale", :latitude => "51.77714", :longitude => "-3.20792").save
City.new(:country_id => "79", :name => "Eastwood", :aliases => ",Eastwood", :latitude => "53", :longitude => "-1.3").save
City.new(:country_id => "79", :name => "Retford", :aliases => ",Retford", :latitude => "53.32213", :longitude => "-0.94315").save
City.new(:country_id => "79", :name => "Eastleigh", :aliases => "Eastleigh,Eastleigh", :latitude => "50.96667", :longitude => "-1.35").save
City.new(:country_id => "79", :name => "East Kilbride", :aliases => "East Kilbride,East Kilbridge,East Kilbride", :latitude => "55.76667", :longitude => "-4.16667").save
City.new(:country_id => "79", :name => "East Grinstead", :aliases => "East Grinstead,East Grinstead", :latitude => "51.12382", :longitude => "-0.0061").save
City.new(:country_id => "79", :name => "East Dereham", :aliases => "Dereham,East Dereham,East Dereham", :latitude => "52.68333", :longitude => "0.93333").save
City.new(:country_id => "79", :name => "Eastbourne", :aliases => "Eastbourne,Istborn,ÐÑÑÐ±Ð¾ÑÐ½,Eastbourne", :latitude => "50.76871", :longitude => "0.28453").save
City.new(:country_id => "79", :name => "Durham", :aliases => "Darem,Dunelm,Dunholm,Durham,DÅ«nholm,ÐÐ°ÑÐµÐ¼,à¹à¸à¸­à¹à¸£à¸¡,Durham", :latitude => "54.77676", :longitude => "-1.57566").save
City.new(:country_id => "79", :name => "Dunstable", :aliases => "Dunstable,Dunstable", :latitude => "51.886", :longitude => "-0.52099").save
City.new(:country_id => "79", :name => "Dunfermline", :aliases => "Danfermlin,Dunfermline,ÐÐ°Ð½ÑÐµÑÐ¼Ð»Ð¸Ð½,Dunfermline", :latitude => "56.07156", :longitude => "-3.45887").save
City.new(:country_id => "79", :name => "Dundee", :aliases => "Dandi,Dun Deagh,Dundee,Dundi,DÃ¹n DÃ¨agh,dandi,dandy,deng di,ÐÐ°Ð½Ð´Ð¸,ÐÑÐ½Ð´Ð¸,Ø¯Ø§ÙØ¯Û,ãã³ãã£ã¼,éè¿ª,Dundee", :latitude => "56.5", :longitude => "-2.96667").save
City.new(:country_id => "79", :name => "Dumbarton", :aliases => "Dambarton,Dumbarton,ÐÐ°Ð¼Ð±Ð°ÑÑÐ¾Ð½,Dumbarton", :latitude => "55.94433", :longitude => "-4.57061").save
City.new(:country_id => "79", :name => "Dukinfield", :aliases => ",Dukinfield", :latitude => "53.47497", :longitude => "-2.08809").save
City.new(:country_id => "79", :name => "Dudley", :aliases => "Dadli,Dudley,ÐÐ°Ð´Ð»Ð¸,Dudley", :latitude => "52.5", :longitude => "-2.08333").save
City.new(:country_id => "79", :name => "Droylsden", :aliases => "Droylesden,Droylsden,Droylsden", :latitude => "53.48005", :longitude => "-2.14543").save
City.new(:country_id => "79", :name => "Dronfield", :aliases => "Dronfield,Dronfield", :latitude => "53.30221", :longitude => "-1.47507").save
City.new(:country_id => "79", :name => "Droitwich", :aliases => ",Droitwich", :latitude => "52.26667", :longitude => "-2.15").save
City.new(:country_id => "79", :name => "Dover", :aliases => "Dofere,Douvres,Dover,Dovero,Dubris,Duvr,doba,dobeo,duo fu er,dwbr,dwfr,ÐÑÐ²Ñ,××××¨,Ø¢Ø¨ÙØ§Ø¦Û ÚÙÙØ±,Ø¯ÙÙØ±,ãã¼ãã¼,å¤ä½å°,ëë²,Dover", :latitude => "51.13333", :longitude => "1.3").save
City.new(:country_id => "79", :name => "Dorking", :aliases => "Dorking,Dorking", :latitude => "51.2329", :longitude => "-0.32942").save
City.new(:country_id => "79", :name => "Dorchester", :aliases => "Dorchester,Dornwara ceaster,Dorchester", :latitude => "50.71667", :longitude => "-2.43333").save
City.new(:country_id => "79", :name => "Doncaster", :aliases => "Doncaster,Donkaster,donkasuta,dxn khas texr,ÐÐ¾Ð½ÐºÐ°ÑÑÐµÑ,à¸à¸­à¸à¸à¸²à¸ªà¹à¸à¸­à¸£à¹,ãã³ã«ã¹ã¿ã¼,Doncaster", :latitude => "53.52327", :longitude => "-1.13691").save
City.new(:country_id => "79", :name => "Didcot", :aliases => ",Didcot", :latitude => "51.60928", :longitude => "-1.24214").save
City.new(:country_id => "79", :name => "Dewsbury", :aliases => "D'jusberi,Dewsbury,Drewsbury,ÐÑÑÑÐ±ÐµÑÐ¸,Dewsbury", :latitude => "53.69076", :longitude => "-1.62907").save
City.new(:country_id => "79", :name => "Derby", :aliases => "Derbi,Derby,dabi,dyrby,ÐÐµÑÐ±Ð¸,Ø¯ÙØ±Ø¨Ù,ãã¼ãã¼,Derby", :latitude => "52.92277", :longitude => "-1.47663").save
City.new(:country_id => "79", :name => "Denton", :aliases => ",Denton", :latitude => "53.45678", :longitude => "-2.11822").save
City.new(:country_id => "79", :name => "Daventry", :aliases => "Daventri,Daventry,ÐÐ°Ð²ÐµÐ½ÑÑÐ¸,Daventry", :latitude => "52.25688", :longitude => "-1.16066").save
City.new(:country_id => "79", :name => "Darwen", :aliases => "Darven,Darwen,ÐÐ°ÑÐ²ÐµÐ½,Darwen", :latitude => "53.69803", :longitude => "-2.46494").save
City.new(:country_id => "79", :name => "Darton", :aliases => "Darton,Darton", :latitude => "53.58705", :longitude => "-1.52676").save
City.new(:country_id => "79", :name => "Dartford", :aliases => "Dartford,Dartforde,ÐÐ°ÑÑÑÐ¾ÑÐ´Ðµ,Dartford", :latitude => "51.44352", :longitude => "0.21964").save
City.new(:country_id => "79", :name => "Darlington", :aliases => "Darlington,ÐÐ°ÑÐ»Ð¸Ð½Ð³ÑÐ¾Ð½,Darlington", :latitude => "54.52429", :longitude => "-1.55039").save
City.new(:country_id => "79", :name => "Cwmbran", :aliases => "Cwm-bran,Cwm-brÃ¢n,Cwmbran", :latitude => "51.65446", :longitude => "-3.02281").save
City.new(:country_id => "79", :name => "Cumbernauld", :aliases => ",Cumbernauld", :latitude => "55.94685", :longitude => "-3.99051").save
City.new(:country_id => "79", :name => "Crowthorne", :aliases => "Crowthorne,Crowthorne", :latitude => "51.37027", :longitude => "-0.79219").save
City.new(:country_id => "79", :name => "Crowborough", :aliases => ",Crowborough", :latitude => "51.06044", :longitude => "0.16171").save
City.new(:country_id => "79", :name => "Crewe", :aliases => "Crewe,Krju,ÐÑÑ,Crewe", :latitude => "53.09787", :longitude => "-2.44161").save
City.new(:country_id => "79", :name => "Crawley", :aliases => "Crawley,Krouli,ÐÑÐ¾ÑÐ»Ð¸,Crawley", :latitude => "51.11303", :longitude => "-0.18312").save
City.new(:country_id => "79", :name => "Cramlington", :aliases => "Cramlington,Kramlington,ÐÑÐ°Ð¼Ð»Ð¸Ð½Ð³ÑÐ¾Ð½,Cramlington", :latitude => "55.08652", :longitude => "-1.58598").save
City.new(:country_id => "79", :name => "Cowes", :aliases => "Cowes,Kaus,West Cowes,ÐÐ°ÑÑ,Cowes", :latitude => "50.76306", :longitude => "-1.29772").save
City.new(:country_id => "79", :name => "Coventry", :aliases => "Coventry,Koventri,kao wen chui,kovu~entori,kwfntry,qwbntry,ÐÐ¾Ð²ÐµÐ½ÑÑÐ¸,×§××× ××¨×,ÙÙÙÙØªØ±Ù,ã³ã´ã§ã³ããªã¼,èæå,Coventry", :latitude => "52.40656", :longitude => "-1.51217").save
City.new(:country_id => "79", :name => "Corby", :aliases => "Corby,Korbi,ÐÐ¾ÑÐ±Ð¸,Corby", :latitude => "52.49637", :longitude => "-0.68939").save
City.new(:country_id => "79", :name => "Consett", :aliases => "Consett,Consetti,Konsett,ÐÐ¾Ð½ÑÐµÑÑ,Consett", :latitude => "54.85404", :longitude => "-1.8316").save
City.new(:country_id => "79", :name => "Conisbrough", :aliases => "Conisborough,Conisbrough,Conisbrough", :latitude => "53.48188", :longitude => "-1.23214").save
City.new(:country_id => "79", :name => "Congleton", :aliases => "Konglton,ÐÐ¾Ð½Ð³Ð»ÑÐ¾Ð½,Congleton", :latitude => "53.16314", :longitude => "-2.21253").save
City.new(:country_id => "79", :name => "Colwyn Bay", :aliases => "Bae Colwyn,Colwyn Bay,Colwyn Bay", :latitude => "53.29483", :longitude => "-3.72674").save
City.new(:country_id => "79", :name => "Coleraine", :aliases => "Colepaine,Cuil Rathain,CÃºil Rathain,Kolrehjn,ÐÐ¾Ð»ÑÑÐ¹Ð½,Coleraine", :latitude => "55.13333", :longitude => "-6.66667").save
City.new(:country_id => "79", :name => "Colchester", :aliases => "Colchester,Kolchest'r,ÐÐ¾Ð»ÑÐµÑÑÑÑ,Colchester", :latitude => "51.88921", :longitude => "0.90421").save
City.new(:country_id => "79", :name => "Coity", :aliases => "Coity,Coyty,Coity", :latitude => "51.522", :longitude => "-3.55531").save
City.new(:country_id => "79", :name => "Cobham", :aliases => "Church Cobham,Cobham,Cobham", :latitude => "51.32997", :longitude => "-0.4113").save
City.new(:country_id => "79", :name => "Coalville", :aliases => "Coalville,Coalville", :latitude => "52.71667", :longitude => "-1.36667").save
City.new(:country_id => "79", :name => "Clydebank", :aliases => "Clydebank,Clydebank", :latitude => "55.90137", :longitude => "-4.4057").save
City.new(:country_id => "79", :name => "Clydach", :aliases => ",Clydach", :latitude => "51.68333", :longitude => "-3.9").save
City.new(:country_id => "79", :name => "Clitheroe", :aliases => ",Clitheroe", :latitude => "53.86667", :longitude => "-2.4").save
City.new(:country_id => "79", :name => "Clevedon", :aliases => "Clevedon,Clevedon", :latitude => "51.44057", :longitude => "-2.85745").save
City.new(:country_id => "79", :name => "Cleethorpes", :aliases => "Cleethorpes,Klitkhorps,ÐÐ»Ð¸ÑÑÐ¾ÑÐ¿Ñ,Cleethorpes", :latitude => "53.56047", :longitude => "-0.03225").save
City.new(:country_id => "79", :name => "Cleckheaton", :aliases => ",Cleckheaton", :latitude => "53.72405", :longitude => "-1.71294").save
City.new(:country_id => "79", :name => "Clacton-on-Sea", :aliases => "Clacton,Clacton-on-Sea,Clacton-on-Sea", :latitude => "51.78967", :longitude => "1.15597").save
City.new(:country_id => "79", :name => "Cirencester", :aliases => "Cicester,Cirencester,Cirencester", :latitude => "51.71708", :longitude => "-1.96825").save
City.new(:country_id => "79", :name => "Christchurch", :aliases => "Krajstcherch,ÐÑÐ°Ð¹ÑÑÑÐµÑÑ,Christchurch", :latitude => "50.73306", :longitude => "-1.77567").save
City.new(:country_id => "79", :name => "Chorley", :aliases => ",Chorley", :latitude => "53.65", :longitude => "-2.61667").save
City.new(:country_id => "79", :name => "Chipping Sodbury", :aliases => ",Chipping Sodbury", :latitude => "51.53813", :longitude => "-2.39379").save
City.new(:country_id => "79", :name => "Chippenham", :aliases => "Chippenem,Chippenham,Ð§Ð¸Ð¿Ð¿ÐµÐ½ÐµÐ¼,Chippenham", :latitude => "51.46", :longitude => "-2.12472").save
City.new(:country_id => "79", :name => "Chichester", :aliases => "Chichester,Ð§Ð¸ÑÐµÑÑÐµÑ,Chichester", :latitude => "50.83673", :longitude => "-0.78003").save
City.new(:country_id => "79", :name => "Chester-le-Street", :aliases => ",Chester-le-Street", :latitude => "54.85862", :longitude => "-1.57408").save
City.new(:country_id => "79", :name => "Chesterfield", :aliases => "Chesterfield,Chesterfield", :latitude => "53.25", :longitude => "-1.41667").save
City.new(:country_id => "79", :name => "Chester", :aliases => "Caer,Caerlleon,Chester,Chestur,Ð§ÐµÑÑÐµÑ,Ð§ÐµÑÑÑÑ,Chester", :latitude => "53.1905", :longitude => "-2.89189").save
City.new(:country_id => "79", :name => "Cheshunt", :aliases => "Cheshunt,Cheshunt", :latitude => "51.70791", :longitude => "-0.03739").save
City.new(:country_id => "79", :name => "Chesham", :aliases => "Chesham,Chesham", :latitude => "51.7", :longitude => "-0.6").save
City.new(:country_id => "79", :name => "Cheltenham", :aliases => "Cheltenham,cherutonamu,ãã§ã«ããã ,Cheltenham", :latitude => "51.9", :longitude => "-2.08333").save
City.new(:country_id => "79", :name => "Chelsea", :aliases => "Chelsea,Chelsea", :latitude => "51.48755", :longitude => "-0.16936").save
City.new(:country_id => "79", :name => "Chelmsford", :aliases => "Chelmsford,Ð§ÐµÐ»Ð¼ÑÑÐ¾ÑÐ´,Chelmsford", :latitude => "51.73575", :longitude => "0.46958").save
City.new(:country_id => "79", :name => "Cheadle Hulme", :aliases => ",Cheadle Hulme", :latitude => "53.3761", :longitude => "-2.1897").save
City.new(:country_id => "79", :name => "Chatham", :aliases => "Chatem,Chatham,Ð§Ð°ÑÐµÐ¼,Chatham", :latitude => "51.37891", :longitude => "0.52786").save
City.new(:country_id => "79", :name => "Chapletown", :aliases => ",Chapletown", :latitude => "53.46506", :longitude => "-1.47217").save
City.new(:country_id => "79", :name => "Chalfont Saint Peter", :aliases => "Chalfont Saint Peter,Chalfont Saint Peter", :latitude => "51.60885", :longitude => "-0.55618").save
City.new(:country_id => "79", :name => "Castlereagh", :aliases => ",Castlereagh", :latitude => "54.5735", :longitude => "-5.88472").save
City.new(:country_id => "79", :name => "Castleford", :aliases => ",Castleford", :latitude => "53.72587", :longitude => "-1.36256").save
City.new(:country_id => "79", :name => "Carrickfergus", :aliases => ",Carrickfergus", :latitude => "54.7158", :longitude => "-5.8058").save
City.new(:country_id => "79", :name => "Carmarthen", :aliases => "Caerfyrddin,Caermarthen,Carmarthen,Carmarthen", :latitude => "51.85552", :longitude => "-4.30535").save
City.new(:country_id => "79", :name => "Carlisle", :aliases => "Caerliwelydd,Carlisle,Cathair Luail,Karlajl,ÐÐ°ÑÐ»Ð°Ð¹Ð»,Carlisle", :latitude => "54.8951", :longitude => "-2.9382").save
City.new(:country_id => "79", :name => "Cardiff", :aliases => "Caerdydd,Cardiff,Kardiff,ÐÐ°ÑÐ´Ð¸ÑÑ,Cardiff", :latitude => "51.48", :longitude => "-3.18").save
City.new(:country_id => "79", :name => "Canterbury", :aliases => "Caergaint,Canterbury,Cantorbery,CantorbÃ©ry,Cantuaria,CantuÃ¡ria,Cantwarebyrig,Dorwitceaster,Durovernum,Durovernum Canticorum,Kantaraborg,Kenterberi,kan te bo lei,kantaberi,kantrbyry,qntrbry,ÐÐµÐ½ÑÐµÑÐ±ÐµÑÐ¸,×§× ××¨××¨×,ÙØ§ÙØªØ±Ø¨ÙØ±Ù,ã«ã³ã¿ããªã¼,å ªç¹ä¼¯é·,Canterbury", :latitude => "51.27904", :longitude => "1.07992").save
City.new(:country_id => "79", :name => "Cannock", :aliases => "Cannock,Kannok,ÐÐ°Ð½Ð½Ð¾Ðº,Cannock", :latitude => "52.69045", :longitude => "-2.03085").save
City.new(:country_id => "79", :name => "Cambridge", :aliases => "Caergrawnt,Cambridge,Cantabrigia,Grantanbrycg,Kejmbridzh,Kembridz,Kembridzas,Kembridzh,KembridÅ¾as,Kembrigo,KembriÄo,jian qiao,kambrydj,keimbeuliji,kenburijji,khem bridc,kmbryj,qyymbrydg',ÐÐµÐ¹Ð¼Ð±ÑÐ¸Ð´Ð¶,ÐÐµÐ¼Ð±ÑÐ¸Ð´Ð¶,ÐÐµÐ¼Ð±ÑÐ¸Ñ,ÐÐµÐ¼Ð±ÑÑÐ´Ð¶,×§×××××¨×××',ÙØ§ÙØ¨Ø±ÙØ¯Ø¬,Ú©ÙØ¨Ø±ÛØ¬,à¹à¸à¸¡à¸à¸£à¸´à¸à¸à¹,ã±ã³ããªãã¸,åæ©,ì¼ìë¸ë¦¬ì§,Cambridge", :latitude => "52.2", :longitude => "0.11667").save
City.new(:country_id => "79", :name => "Camberley", :aliases => "Camberley,Camberly,Kemberli,ÐÐµÐ¼Ð±ÐµÑÐ»Ð¸,Camberley", :latitude => "51.33705", :longitude => "-0.74261").save
City.new(:country_id => "79", :name => "Caerphilly", :aliases => "Caerphilly,Kerfili,ÐÐµÑÑÐ¸Ð»Ð¸,Caerphilly", :latitude => "51.57452", :longitude => "-3.218").save
City.new(:country_id => "79", :name => "Buxton", :aliases => ",Buxton", :latitude => "53.25741", :longitude => "-1.90982").save
City.new(:country_id => "79", :name => "Bushey", :aliases => "Bushey,Bushey", :latitude => "51.64316", :longitude => "-0.36053").save
City.new(:country_id => "79", :name => "Bury St Edmunds", :aliases => "Bury Saint Edmunds,Bury St,Bury St Edmunds,Bury St Edmunds", :latitude => "52.2463", :longitude => "0.71111").save
City.new(:country_id => "79", :name => "Bury", :aliases => "Bury,Bury", :latitude => "53.6", :longitude => "-2.3").save
City.new(:country_id => "79", :name => "Burton upon Trent", :aliases => "Burton upon Trent,Burton-on-Trent,Burton upon Trent", :latitude => "52.80728", :longitude => "-1.64263").save
City.new(:country_id => "79", :name => "Burntwood", :aliases => ",Burntwood", :latitude => "52.68075", :longitude => "-1.92759").save
City.new(:country_id => "79", :name => "Burnley", :aliases => "Bernli,Burnley,brnly,ÐÐµÑÐ½Ð»Ð¸,××¨× ××,Burnley", :latitude => "53.8", :longitude => "-2.23333").save
City.new(:country_id => "79", :name => "Burgess Hill", :aliases => "Burgess Hill,burgess hill, west sussex,Burgess Hill", :latitude => "50.95843", :longitude => "-0.13287").save
City.new(:country_id => "79", :name => "Buckley", :aliases => "Buckley,Buckley", :latitude => "53.16667", :longitude => "-3.08333").save
City.new(:country_id => "79", :name => "Buckhaven", :aliases => "Buckhaven,Buckhaven", :latitude => "56.17149", :longitude => "-3.03377").save
City.new(:country_id => "79", :name => "Brymbo", :aliases => "Brymbo,Brymbo", :latitude => "53.06667", :longitude => "-3.06667").save
City.new(:country_id => "79", :name => "Brownhills", :aliases => "Braunkhills,Brownhills,ÐÑÐ°ÑÐ½ÑÐ¸Ð»Ð»Ñ,Brownhills", :latitude => "52.63333", :longitude => "-1.93333").save
City.new(:country_id => "79", :name => "Broadstairs", :aliases => "Broadstairs,Broadstairs", :latitude => "51.35908", :longitude => "1.43938").save
City.new(:country_id => "79", :name => "Brixham", :aliases => "Brixham,Brixham", :latitude => "50.39431", :longitude => "-3.51585").save
City.new(:country_id => "79", :name => "Briton Ferry", :aliases => "Briton Ferry,Llansawel,Briton Ferry", :latitude => "51.63106", :longitude => "-3.81898").save
City.new(:country_id => "79", :name => "Bristol", :aliases => "BricgstoÆ¿,BricgstÅÆ¿,Briosto,BriostÃ³,Bristo,Bristol,Bristol',Bristole,Bristolis,Bristolium,Briston,Bristul,Bristullu,BristÃ³n,Bryste,beuliseuteul,bristala,brystwl,bu li si tuo er,burisutoru,ÎÏÏÎ¯ÏÏÎ¿Î»,ÐÑÐ¸ÑÑÐ¾Ð»,ÐÑÐ¸ÑÑÐ¾Ð»Ñ,ÐÑÐ¸ÑÑÑÐ»,××¨××¡×××,××¨××¡×××,Ø¨Ø±Ø³Ù¹Ù ÙÚ¯Ø±,Ø¨Ø±ÙØ³ØªÙÙ,Ø¨Ø±ÛØ³ØªÙÙ,à¤¬à¥à¤°à¤¿à¤¸à¥à¤à¤²,à²¬à³à²°à²¿à²¸à³à²à²²à³â,áá áá¡á¢ááá,ããªã¹ãã«,å¸éæ¯æå°,ë¸ë¦¬ì¤í,Bristol", :latitude => "51.45523", :longitude => "-2.59665").save
City.new(:country_id => "79", :name => "Brighton", :aliases => "Brajton,Brajtono,Brighton,bra'itana,braytwn,bryytwn,bu lai dun,buraiton,ÐÑÐ°Ð¹ÑÐ¾Ð½,××¨×××××,Ø¨Ø±Ø§ÙØªÙÙ,à¦¬à§à¦°à¦¾à¦à¦à¦¨,ãã©ã¤ãã³,å¸èµé¡¿,Brighton", :latitude => "50.82838", :longitude => "-0.13947").save
City.new(:country_id => "79", :name => "Brighouse", :aliases => ",Brighouse", :latitude => "53.70322", :longitude => "-1.78428").save
City.new(:country_id => "79", :name => "Bridlington", :aliases => ",Bridlington", :latitude => "54.08306", :longitude => "-0.19192").save
City.new(:country_id => "79", :name => "Bridgwater", :aliases => "Bridgewater,Bridgwater,Bridzhuoter,ÐÑÐ¸Ð´Ð¶ÑÐ¾ÑÐµÑ,Bridgwater", :latitude => "51.12837", :longitude => "-3.00356").save
City.new(:country_id => "79", :name => "Brentwood", :aliases => "Brentwood,Brentwood", :latitude => "51.62127", :longitude => "0.30556").save
City.new(:country_id => "79", :name => "Braintree", :aliases => "Braintree,Braintree", :latitude => "51.87819", :longitude => "0.55292").save
City.new(:country_id => "79", :name => "Bradford", :aliases => "Bradford,Brehdford,ÐÑÑÐ´ÑÐ¾ÑÐ´,Bradford", :latitude => "53.79391", :longitude => "-1.75206").save
City.new(:country_id => "79", :name => "Bracknell", :aliases => "Bracknell,Bracknell", :latitude => "51.41363", :longitude => "-0.75054").save
City.new(:country_id => "79", :name => "Bournemouth", :aliases => "Bornmut,Bournemouth,bonmasu,ÐÐ¾ÑÐ½Ð¼ÑÑ,ãã¼ã³ãã¹,Bournemouth", :latitude => "50.72048", :longitude => "-1.8795").save
City.new(:country_id => "79", :name => "Boston", :aliases => "Boston,ÐÐ¾ÑÑÐ¾Ð½,Boston", :latitude => "52.97633", :longitude => "-0.02664").save
City.new(:country_id => "79", :name => "Borehamwood", :aliases => "Borehamwood,Borehamwood", :latitude => "51.65468", :longitude => "-0.27762").save
City.new(:country_id => "79", :name => "Bootle", :aliases => "Bootle,Butl,ÐÑÑÐ»,Bootle", :latitude => "53.46667", :longitude => "-3.01667").save
City.new(:country_id => "79", :name => "Bolton", :aliases => "Bolton,ÐÐ¾Ð»ÑÐ¾Ð½,Bolton", :latitude => "53.58333", :longitude => "-2.43333").save
City.new(:country_id => "79", :name => "Bognor Regis", :aliases => "Bognor,Bognor Regis,Bognor Regis", :latitude => "50.78206", :longitude => "-0.67978").save
City.new(:country_id => "79", :name => "Blyth", :aliases => "Blit,Blyth,Blythe,ÐÐ»Ð¸Ñ,Blyth", :latitude => "55.12708", :longitude => "-1.50856").save
City.new(:country_id => "79", :name => "Bletchley", :aliases => ",Bletchley", :latitude => "51.99334", :longitude => "-0.73471").save
City.new(:country_id => "79", :name => "Blackpool", :aliases => "Blackpool,Blehkpul,Blekpulis,burakkupuru,hei tan,ÐÐ»ÑÐºÐ¿ÑÐ»,à¦¬à§à¦²à§à¦¯à¦¾à¦à§âà¦ªà§à¦²,ãã©ãã¯ãã¼ã«,é»æ½­,Blackpool", :latitude => "53.81667", :longitude => "-3.05").save
City.new(:country_id => "79", :name => "Blackburn", :aliases => "Blackburn,Blehkbern,bu lai ke ben,ÐÐ»ÑÐºÐ±ÐµÑÐ½,å¸è±åæ¬,å¸èåæ¬,Blackburn", :latitude => "53.75", :longitude => "-2.48333").save
City.new(:country_id => "79", :name => "Bishopstoke", :aliases => ",Bishopstoke", :latitude => "50.96643", :longitude => "-1.32832").save
City.new(:country_id => "79", :name => "Bishops Stortford", :aliases => "Bishop's Stortford,Bishops Stortford,Bishops Strotford,Bishops Stortford", :latitude => "51.87113", :longitude => "0.15868").save
City.new(:country_id => "79", :name => "Bishopbriggs", :aliases => ",Bishopbriggs", :latitude => "55.90669", :longitude => "-4.21869").save
City.new(:country_id => "79", :name => "Bishop Auckland", :aliases => "Bishop Auckland,Bishop-Oklend,ÐÐ¸ÑÐ¾Ð¿-ÐÐºÐ»ÐµÐ½Ð´,Bishop Auckland", :latitude => "54.65554", :longitude => "-1.67706").save
City.new(:country_id => "79", :name => "Birmingham", :aliases => "Birmin'gxam,Birmingam,Birmingamas,Birmingem,Birmingema,Birmingham,Birminghamia,Mpermincham,bamingamu,barming'hyam,barmingahama,barmingahema,barminghama,beoming-eom,birmingemi,bo ming han,bo ming han shi,brmngm,brmynghham,byrmngam,parminkam,ÎÏÎ­ÏÎ¼Î¹Î³ÏÎ±Î¼,ÐÐ¸ÑÐ¼Ð¸Ð½Ð³Ð°Ð¼,ÐÐ¸ÑÐ¼Ð¸Ð½Ð³ÐµÐ¼,ÐÑÑÐ¼ÑÐ½Ð³ÐµÐ¼,×××¨××× ××××,××¨××× ××××,Ø¨Ø±ÙÙÚ¯Ù,Ø¨Ø±ÙÙÙØºÙØ§Ù,Ø¨ÛØ±ÙÙÚ¯Ø§Ù,à¤¬à¤°à¥à¤®à¤¿à¤à¤à¤¹à¥à¤®,à¤¬à¤°à¥à¤®à¤¿à¤à¤à¤®,àª¬àª°à«àª®àª¿àªàªàª¹àª¾àª®,à®ªà®°à¯à®®à®¿à®à¯à®à®¾à®®à¯,à°¬à°°à±à°®à°¿à°à°à±âà°¹à°¾à°®à±,à²¬à²°à³à²®à²¿à²à²à³à²¹à³à²¯à²¾à²®à³,à¹à¸à¸­à¸£à¹à¸¡à¸´à¸à¹à¸®à¸¡,ááá ááááááá,ãã¼ãã³ã¬ã ,ä¼¯æç¿°,ä¼¯æç¿°å¸,ë²ë°ì,Birmingham", :latitude => "52.48142", :longitude => "-1.89983").save
City.new(:country_id => "79", :name => "Birkenhead", :aliases => "Birkenhead,Birkenkhed,Penbedw,ÐÐ¸ÑÐºÐµÐ½ÑÐµÐ´,Birkenhead", :latitude => "53.39337", :longitude => "-3.01479").save
City.new(:country_id => "79", :name => "Bingley", :aliases => ",Bingley", :latitude => "53.84861", :longitude => "-1.83857").save
City.new(:country_id => "79", :name => "Billingham", :aliases => "Billingem,Billingham,Billingham-on-Tees,ÐÐ¸Ð»Ð»Ð¸Ð½Ð³ÐµÐ¼,Billingham", :latitude => "54.60828", :longitude => "-1.29214").save
City.new(:country_id => "79", :name => "Billericay", :aliases => "Billericay,Billerikej,ÐÐ¸Ð»Ð»ÐµÑÐ¸ÐºÐµÐ¹,Billericay", :latitude => "51.62867", :longitude => "0.41963").save
City.new(:country_id => "79", :name => "Biggleswade", :aliases => ",Biggleswade", :latitude => "52.08652", :longitude => "-0.26493").save
City.new(:country_id => "79", :name => "Bideford", :aliases => "Bideford,Bideford", :latitude => "51.01787", :longitude => "-4.20458").save
City.new(:country_id => "79", :name => "Biddulph", :aliases => ",Biddulph", :latitude => "53.11724", :longitude => "-2.17584").save
City.new(:country_id => "79", :name => "Bicester", :aliases => ",Bicester", :latitude => "51.89998", :longitude => "-1.15357").save
City.new(:country_id => "79", :name => "Bexhill", :aliases => "Bexhill on Sea,Bexhill-on-Sea,Bexhill", :latitude => "50.85023", :longitude => "0.47095").save
City.new(:country_id => "79", :name => "Beverley", :aliases => "Beverley,Beverley", :latitude => "53.84587", :longitude => "-0.42332").save
City.new(:country_id => "79", :name => "Berwick-Upon-Tweed", :aliases => "Bervik-apon-Tvid,Berwick,Berwick on Tweed,Berwick-Upon-Tweed,Berwick-upon-Tweed,ÐÐµÑÐ²Ð¸Ðº-Ð°Ð¿Ð¾Ð½-Ð¢Ð²Ð¸Ð´,Berwick-Upon-Tweed", :latitude => "55.78333", :longitude => "-2").save
City.new(:country_id => "79", :name => "Bentley", :aliases => ",Bentley", :latitude => "53.53333", :longitude => "-1.15").save
City.new(:country_id => "79", :name => "Belper", :aliases => "Belper,ÐÐµÐ»Ð¿ÐµÑ,Belper", :latitude => "53.0233", :longitude => "-1.48119").save
City.new(:country_id => "79", :name => "Bellshill", :aliases => "Bellshill,Bellshill", :latitude => "55.81667", :longitude => "-4.01667").save
City.new(:country_id => "79", :name => "Belfast", :aliases => "Beal Feirste,Behlfast,Belfast,Belfast City,Belfasta,Belfasto,Belffast,BelfÄsta,Beul-Feirste,BÃ©al Feirste,Mpelphast,baelpaseuteu,bei er fa si te,belpaseuteu,berufasuto,blfast,ÎÏÎ­Î»ÏÎ±ÏÏ,ÐÐµÐ»ÑÐ°ÑÑ,ÐÑÐ»ÑÐ°ÑÑ,×××¤××¡×,Ø¨ÙÙØ§Ø³Øª,ãã«ãã¡ã¹ã,è²ç¾æ³æ¯ç¹,è´å°æ³æ¯ç¹,ë°¸íì¤í¸,ë²¨íì¤í¸,Belfast", :latitude => "54.58333", :longitude => "-5.93333").save
City.new(:country_id => "79", :name => "Bedworth", :aliases => "Bedvors,Bedworth,ÐÐµÐ´Ð²Ð¾ÑÑ,Bedworth", :latitude => "52.4791", :longitude => "-1.46909").save
City.new(:country_id => "79", :name => "Bedlington", :aliases => ",Bedlington", :latitude => "55.13061", :longitude => "-1.59319").save
City.new(:country_id => "79", :name => "Bedford", :aliases => "Bedford,ÐÐµÐ´ÑÐ¾ÑÐ´,Bedford", :latitude => "52.13459", :longitude => "-0.46632").save
City.new(:country_id => "79", :name => "Bebington", :aliases => "Bebington,Bebington and Bromborough,Bebington", :latitude => "53.35", :longitude => "-3.01667").save
City.new(:country_id => "79", :name => "Bearsden", :aliases => "Bearsden,New Kilpatrick,Bearsden", :latitude => "55.91536", :longitude => "-4.33279").save
City.new(:country_id => "79", :name => "Batley", :aliases => "Batley,Batley", :latitude => "53.70291", :longitude => "-1.6337").save
City.new(:country_id => "79", :name => "Bathgate", :aliases => "Bathgate,Bathgate", :latitude => "55.90204", :longitude => "-3.64398").save
City.new(:country_id => "79", :name => "Bath", :aliases => "Aquae Sulis,Ba,Badanceaster,Bat,Bath,BaÃ°anceaster,Caerfaddon,ba si,basu,bath,ÐÐ°Ñ,×××ª',Ø¨Ø§Ø«,ãã¼ã¹,å·´æ¯,Bath", :latitude => "51.37795", :longitude => "-2.35907").save
City.new(:country_id => "79", :name => "Basingstoke", :aliases => "Basingstoke,Basingstoke", :latitude => "51.26249", :longitude => "-1.08708").save
City.new(:country_id => "79", :name => "Basildon", :aliases => "Basildon,ÐÐ°ÑÐ¸Ð»Ð´Ð¾Ð½,Basildon", :latitude => "51.56844", :longitude => "0.45782").save
City.new(:country_id => "79", :name => "Barry", :aliases => "Barri,Barry,Y Barri,ÐÐ°ÑÑÐ¸,Barry", :latitude => "51.40667", :longitude => "-3.26944").save
City.new(:country_id => "79", :name => "Barrow in Furness", :aliases => "Barrow,Barrow in Furness,Barrow-in-Furness,Barrow in Furness", :latitude => "54.11667", :longitude => "-3.23333").save
City.new(:country_id => "79", :name => "Barrhead", :aliases => ",Barrhead", :latitude => "55.79916", :longitude => "-4.39285").save
City.new(:country_id => "79", :name => "Barnstaple", :aliases => "Barnstaple,Barnstaple", :latitude => "51.08022", :longitude => "-4.05808").save
City.new(:country_id => "79", :name => "Barnsley", :aliases => "Barnsley,Barnsli,ÐÐ°ÑÐ½ÑÐ»Ð¸,Barnsley", :latitude => "53.55", :longitude => "-1.48333").save
City.new(:country_id => "79", :name => "Bangor", :aliases => "Bangor,Beannchar,ÐÐ°Ð½Ð³Ð¾Ñ,Bangor", :latitude => "54.65338", :longitude => "-5.66895").save
City.new(:country_id => "79", :name => "Bangor", :aliases => "Bangon,Bangor,ÐÐ°Ð½Ð³Ð¾Ñ,Bangor", :latitude => "53.22647", :longitude => "-4.13459").save
City.new(:country_id => "79", :name => "Banbury", :aliases => "Banberi,Banbury,ÐÐ°Ð½Ð±ÐµÑÐ¸,Banbury", :latitude => "52.0602", :longitude => "-1.34029").save
City.new(:country_id => "79", :name => "Banbridge", :aliases => ",Banbridge", :latitude => "54.35", :longitude => "-6.28333").save
City.new(:country_id => "79", :name => "Ballymena", :aliases => "Behllimena,ÐÑÐ»Ð»Ð¸Ð¼ÐµÐ½Ð°,Ballymena", :latitude => "54.86357", :longitude => "-6.27628").save
City.new(:country_id => "79", :name => "Baildon", :aliases => ",Baildon", :latitude => "53.84711", :longitude => "-1.78785").save
City.new(:country_id => "79", :name => "Ayr", :aliases => "Ajr,Ayr,Ayr - Inbhir Air,Ayr - Inbhir Ãir,Ehjr,ÐÐ¹Ñ,Ð­Ð¹Ñ,Ayr", :latitude => "55.46273", :longitude => "-4.63393").save
City.new(:country_id => "79", :name => "Aylesbury", :aliases => "AEgeles burg,Aylesbury,Ehjlsberi,ai er si bo li,Ãgeles burg,Ð­Ð¹Ð»ÑÐ±ÐµÑÐ¸,è¾ç¾æ¯ä¼¯é,Aylesbury", :latitude => "51.81665", :longitude => "-0.81458").save
City.new(:country_id => "79", :name => "Atherton", :aliases => ",Atherton", :latitude => "53.52371", :longitude => "-2.49354").save
City.new(:country_id => "79", :name => "Ashton-under-Lyne", :aliases => "Ashton,Ashton-under-Lyne,Ehshton-ander-Lajn,Ð­ÑÑÐ¾Ð½-Ð°Ð½Ð´ÐµÑ-ÐÐ°Ð¹Ð½,Ashton-under-Lyne", :latitude => "53.48876", :longitude => "-2.0989").save
City.new(:country_id => "79", :name => "Ashton in Makerfield", :aliases => "Ashton,Ashton in Makerfield,Ashton in Makerfield", :latitude => "53.48333", :longitude => "-2.65").save
City.new(:country_id => "79", :name => "Ashford", :aliases => "Ashford,Ehshford,Ð­ÑÑÐ¾ÑÐ´,Ashford", :latitude => "51.14586", :longitude => "0.87281").save
City.new(:country_id => "79", :name => "Ascot", :aliases => "Ascot,Ascot", :latitude => "51.41082", :longitude => "-0.6748").save
City.new(:country_id => "79", :name => "Arnold", :aliases => "Arnol'd,Arnold,ÐÑÐ½Ð¾Ð»ÑÐ´,Arnold", :latitude => "53", :longitude => "-1.13333").save
City.new(:country_id => "79", :name => "Arbroath", :aliases => "Arbroath,Arbroath", :latitude => "56.56317", :longitude => "-2.58736").save
City.new(:country_id => "79", :name => "Antrim", :aliases => ",Antrim", :latitude => "54.7", :longitude => "-6.2").save
City.new(:country_id => "79", :name => "Andover", :aliases => "Andover,Andover", :latitude => "51.20828", :longitude => "-1.48246").save
City.new(:country_id => "79", :name => "Amersham", :aliases => "Amersham,ÐÐ¼ÐµÑÑÐ°Ð¼,Amersham", :latitude => "51.66667", :longitude => "-0.61667").save
City.new(:country_id => "79", :name => "Altrincham", :aliases => "Altrincham,Altrincham", :latitude => "53.38752", :longitude => "-2.34848").save
City.new(:country_id => "79", :name => "Alton", :aliases => "Alton,Alton", :latitude => "51.14931", :longitude => "-0.97469").save
City.new(:country_id => "79", :name => "Alloa", :aliases => "Alloa,Aloa,ÐÐ»Ð»Ð¾Ð°,ÐÐ»Ð¾Ð°,Alloa", :latitude => "56.11586", :longitude => "-3.78997").save
City.new(:country_id => "79", :name => "Alfreton", :aliases => "Alfreton,ÐÐ»ÑÑÐµÑÐ¾Ð½,Alfreton", :latitude => "53.0961", :longitude => "-1.38832").save
City.new(:country_id => "79", :name => "Aldridge", :aliases => "Aldridge,Aldridge", :latitude => "52.60549", :longitude => "-1.91715").save
City.new(:country_id => "79", :name => "Aldershot", :aliases => "Aldershot,Aldershot", :latitude => "51.24827", :longitude => "-0.76389").save
City.new(:country_id => "79", :name => "Airdrie", :aliases => "Airdrie,Airdrie", :latitude => "55.86602", :longitude => "-3.98025").save
City.new(:country_id => "79", :name => "Acton", :aliases => ",Acton", :latitude => "51.50901", :longitude => "-0.2762").save
City.new(:country_id => "79", :name => "Accrington", :aliases => ",Accrington", :latitude => "53.75379", :longitude => "-2.35863").save
City.new(:country_id => "79", :name => "Abingdon", :aliases => "Abingdon,Abingdon-on-Thames,ÐÐ±Ð¸Ð½Ð³Ð´Ð¾Ð½,Abingdon", :latitude => "51.67109", :longitude => "-1.28278").save
City.new(:country_id => "79", :name => "Aberystwyth", :aliases => "Aberistuit,Aberystwyth,a bo li si te wei si,ÐÐ±ÐµÑÐ¸ÑÑÑÐ¸Ñ,é¿ä¼¯éæ¯ç¹å¨æ¯,Aberystwyth", :latitude => "52.41548", :longitude => "-4.08292").save
City.new(:country_id => "79", :name => "Abergele", :aliases => ",Abergele", :latitude => "53.28436", :longitude => "-3.5822").save
City.new(:country_id => "79", :name => "Aberdeen", :aliases => "Aberdeen,Aberdin,Aberdonia,Aburdijn,Aiberdeen,Devanha,Ehberdin,Obar Dheathain,a bo ding,abadin,abrdyn,ÐÐ±ÐµÑÐ´Ð¸Ð½,ÐÐ±ÑÑÐ´Ð¸Ð¹Ð½,Ð­Ð±ÐµÑÐ´Ð¸Ð½,Ø§Ø¨Ø±Ø¯ÛÙ,ã¢ããã£ã¼ã³,é¿ä¼¯ä¸,Aberdeen", :latitude => "57.14369", :longitude => "-2.09814").save
City.new(:country_id => "79", :name => "Aberdare", :aliases => "Aberdar,Aberdare,Aberdare - Aberdar,Aberdare - AberdÃ¢r,Aberdehjr,AberdÃ¢r,ÐÐ±ÐµÑÐ´ÑÐ¹Ñ,Aberdare", :latitude => "51.71438", :longitude => "-3.44918").save
City.new(:country_id => "79", :name => "Crosby", :aliases => ",Crosby", :latitude => "53.47778", :longitude => "-3.03333").save
City.new(:country_id => "79", :name => "Blackwood", :aliases => ",Blackwood", :latitude => "51.66778", :longitude => "-3.2075").save
City.new(:country_id => "79", :name => "Neston", :aliases => ",Neston", :latitude => "51.41222", :longitude => "-2.20056").save
City.new(:country_id => "79", :name => "Camden Town", :aliases => ",Camden Town", :latitude => "51.54057", :longitude => "-0.14334").save
City.new(:country_id => "79", :name => "Telford", :aliases => "Telford,Ð¢ÐµÐ»ÑÐ¾ÑÐ´,Telford", :latitude => "52.67659", :longitude => "-2.44926").save
City.new(:country_id => "79", :name => "Craigavon", :aliases => "Craigavon,Krejgavon,ÐÑÐµÐ¹Ð³Ð°Ð²Ð¾Ð½,Craigavon", :latitude => "54.44709", :longitude => "-6.387").save
City.new(:country_id => "79", :name => "Holborn", :aliases => ",Holborn", :latitude => "51.52124", :longitude => "-0.11347").save
City.new(:country_id => "79", :name => "Camden Town", :aliases => ",Camden Town", :latitude => "51.54377", :longitude => "-0.1399").save
City.new(:country_id => "79", :name => "Bayswater", :aliases => ",Bayswater", :latitude => "51.51116", :longitude => "-0.18426").save
City.new(:country_id => "79", :name => "Bowthorpe", :aliases => ",Bowthorpe", :latitude => "52.63884", :longitude => "1.21885").save
City.new(:country_id => "79", :name => "Hedge End", :aliases => ",Hedge End", :latitude => "50.91234", :longitude => "-1.30076").save
City.new(:country_id => "79", :name => "Hale", :aliases => ",Hale", :latitude => "53.37831", :longitude => "-2.33271").save
City.new(:country_id => "79", :name => "Amersham on the Hill", :aliases => ",Amersham on the Hill", :latitude => "51.67468", :longitude => "-0.60742").save
City.new(:country_id => "79", :name => "Battersea", :aliases => ",Battersea", :latitude => "51.47475", :longitude => "-0.15547").save
City.new(:country_id => "79", :name => "Hornchurch", :aliases => ",Hornchurch", :latitude => "51.55685", :longitude => "0.21664").save
City.new(:country_id => "79", :name => "Ewell", :aliases => ",Ewell", :latitude => "51.34948", :longitude => "-0.2494").save
City.new(:country_id => "79", :name => "Becontree", :aliases => ",Becontree", :latitude => "51.5529", :longitude => "0.129").save
City.new(:country_id => "79", :name => "Dagenham", :aliases => ",Dagenham", :latitude => "51.54062", :longitude => "0.14801").save
City.new(:country_id => "79", :name => "Brixton", :aliases => ",Brixton", :latitude => "51.46593", :longitude => "-0.10652").save
City.new(:country_id => "79", :name => "Bethnal Green", :aliases => ",Bethnal Green", :latitude => "51.52718", :longitude => "-0.06109").save
City.new(:country_id => "79", :name => "Failsworth", :aliases => ",Failsworth", :latitude => "53.50484", :longitude => "-2.16568").save
City.new(:country_id => "79", :name => "Radcliffe", :aliases => ",Radcliffe", :latitude => "53.56178", :longitude => "-2.32455").save
City.new(:country_id => "79", :name => "Heywood", :aliases => "Heywood,Monkey Town,Heywood", :latitude => "53.59245", :longitude => "-2.21941").save
City.new(:country_id => "79", :name => "Longsight", :aliases => ",Longsight", :latitude => "53.45801", :longitude => "-2.20104").save
City.new(:country_id => "79", :name => "Heavitree", :aliases => ",Heavitree", :latitude => "50.72044", :longitude => "-3.49646").save
City.new(:country_id => "79", :name => "Ferndown", :aliases => ",Ferndown", :latitude => "50.80743", :longitude => "-1.89975").save
City.new(:country_id => "79", :name => "Lytham St Annes", :aliases => "Lytham St Annes,St Annes,Lytham St Annes", :latitude => "53.7426", :longitude => "-2.997").save
City.new(:country_id => "79", :name => "Hadley Wood", :aliases => ",Hadley Wood", :latitude => "51.66669", :longitude => "-0.16981").save
City.new(:country_id => "79", :name => "Chapel Allerton", :aliases => "Chapel A,Chapel Allerton,Chapel Allerton", :latitude => "53.82901", :longitude => "-1.53834").save
City.new(:country_id => "79", :name => "Blackheath", :aliases => ",Blackheath", :latitude => "51.4647", :longitude => "0.0079").save
City.new(:country_id => "79", :name => "Kempston Hardwick", :aliases => ",Kempston Hardwick", :latitude => "52.08956", :longitude => "-0.49908").save
City.new(:country_id => "79", :name => "Mendip", :aliases => ",Mendip", :latitude => "51.2372", :longitude => "-2.6266").save
City.new(:country_id => "79", :name => "Lower Earley", :aliases => ",Lower Earley", :latitude => "51.42708", :longitude => "-0.91979").save
City.new(:country_id => "79", :name => "Bassetlaw District", :aliases => "Bassetlaw,Bassetlaw District,Bassetlaw District", :latitude => "53.34914", :longitude => "-0.9785").save
City.new(:country_id => "79", :name => "Bartley Green", :aliases => ",Bartley Green", :latitude => "52.43532", :longitude => "-1.99707").save
City.new(:country_id => "79", :name => "London Borough of Harrow", :aliases => "Harrow,London Borough of Harrow,London Borough of Harrow", :latitude => "51.56667", :longitude => "-0.33333").save
