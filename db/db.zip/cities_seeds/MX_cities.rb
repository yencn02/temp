City.new(:country_id => "159", :name => "San Fernando", :aliases => ",San Fernando", :latitude => "24.85", :longitude => "-98.15").save
City.new(:country_id => "159", :name => "Zumpango de Ocampo", :aliases => "Zumpango,Zumpango de Ocampo,Zumpango-de-Okampo,ÐÑÐ¼Ð¿Ð°Ð½Ð³Ð¾-Ð´Ðµ-ÐÐºÐ°Ð¼Ð¿Ð¾,Zumpango de Ocampo", :latitude => "19.79778", :longitude => "-99.10167").save
City.new(:country_id => "159", :name => "Zumpango del Rio", :aliases => "Xumpango,Zumpango,Zumpango del Rio,Zumpango del RÃ­o,Zumpango-del'-Rio,ÐÑÐ¼Ð¿Ð°Ð½Ð³Ð¾-Ð´ÐµÐ»Ñ-Ð Ð¸Ð¾,Zumpango del RÃ­o", :latitude => "17.65", :longitude => "-99.5").save
City.new(:country_id => "159", :name => "Zacualtipan", :aliases => ",ZacualtipÃ¡n", :latitude => "20.65", :longitude => "-98.6").save
City.new(:country_id => "159", :name => "Zacatlan", :aliases => "Zacatlan,Zacatlan de las Manzanas,ZacatlÃ¡n,ZacatlÃ¡n", :latitude => "19.93333", :longitude => "-97.96667").save
City.new(:country_id => "159", :name => "Zacatepec", :aliases => ",Zacatepec", :latitude => "18.65", :longitude => "-99.2").save
City.new(:country_id => "159", :name => "Yautepec", :aliases => ",Yautepec", :latitude => "18.88188", :longitude => "-99.06715").save
City.new(:country_id => "159", :name => "Xoxocotla", :aliases => ",Xoxocotla", :latitude => "18.68333", :longitude => "-99.25").save
City.new(:country_id => "159", :name => "Xonacatlan", :aliases => "San Francisco,San Francisco Xonacatlan,San Francisco XonacatlÃ¡n,Xonacatlan,XonacatlÃ¡n,Xonacaxtlan,XonacaxtlÃ¡n,XonacatlÃ¡n", :latitude => "19.40222", :longitude => "-99.5325").save
City.new(:country_id => "159", :name => "Xochitepec", :aliases => "Xochiltepec,Xochitepec,Xochitepec", :latitude => "18.78333", :longitude => "-99.23333").save
City.new(:country_id => "159", :name => "Xochimilco", :aliases => "Xochimilco,Xochimilco", :latitude => "19.26222", :longitude => "-99.1075").save
City.new(:country_id => "159", :name => "Xicotepec de Juarez", :aliases => "Juarez Xicotepec,JuÃ¡rez Xicotepec,Villa Juarez,Villa JuÃ¡rez,Xicotepec de Juarez,Xicotepec de JuÃ¡rez,Xicotepec de JuÃ¡rez", :latitude => "20.3", :longitude => "-97.96667").save
City.new(:country_id => "159", :name => "Xico", :aliases => "Jico,Xico,Xico", :latitude => "19.41667", :longitude => "-97").save
City.new(:country_id => "159", :name => "Xico", :aliases => ",Xico", :latitude => "19.26667", :longitude => "-98.93333").save
City.new(:country_id => "159", :name => "Alvaro Obregon", :aliases => "Alvaro Obregon,Alvaro ObregÃ³n,Obergen Villa,Obrogen Villa,San Angel,Villa Obregon,Villa ObregÃ³n,Alvaro ObregÃ³n", :latitude => "19.37333", :longitude => "-99.225").save
City.new(:country_id => "159", :name => "Villahermosa", :aliases => "Vil'jaehrmosa,Villa Hermosa,Villahermosa,ÐÐ¸Ð»ÑÑÑÑÐ¼Ð¾ÑÐ°,Villahermosa", :latitude => "17.98333", :longitude => "-92.91667").save
City.new(:country_id => "159", :name => "Gustavo A. Madero", :aliases => "Guadalupe,Guadalupe Hidalgo,Gustavo A. Madero,Villa Gustavo A. Madero,Villa Madero,Villa de Guadalupe,Villa de Guadalupe Hidalgo,Gustavo A. Madero", :latitude => "19.47861", :longitude => "-99.09583").save
City.new(:country_id => "159", :name => "Villa Cuauhtemoc", :aliases => "Cuauhtemoc,CuauhtÃ©moc,Villa Cuauhtemoc,Villa CuauhtÃ©moc,Villa Cuautemoc,Villa CuauhtÃ©moc", :latitude => "19.41528", :longitude => "-99.56167").save
City.new(:country_id => "159", :name => "Veracruz", :aliases => "Heroica Veracruz,Veracruz,Veracruz Llave,Verakrus,ÐÐµÑÐ°ÐºÑÑÑ,Veracruz", :latitude => "19.2", :longitude => "-96.13333").save
City.new(:country_id => "159", :name => "Venustiano Carranza", :aliases => "San Bartolo,San Bartolome,San BartolomÃ©,Venustiano Carranza,Venustiano Carranza", :latitude => "16.35", :longitude => "-92.55").save
City.new(:country_id => "159", :name => "Valle Hermoso", :aliases => ",Valle Hermoso", :latitude => "25.66667", :longitude => "-97.83333").save
City.new(:country_id => "159", :name => "Valladolid", :aliases => ",Valladolid", :latitude => "20.68812", :longitude => "-88.19936").save
City.new(:country_id => "159", :name => "Uman", :aliases => "San Antonio Tedzidz,Uman,Uman',UmÃ¡n,Ð£Ð¼Ð°Ð½Ñ,UmÃ¡n", :latitude => "20.88333", :longitude => "-89.75").save
City.new(:country_id => "159", :name => "Tuxtla Gutierrez", :aliases => "Gutierrez,Tustla-Gut'erres,Tuxtla,Tuxtla Gtz,Tuxtla Gtz.,Tuxtla Gutierres,Tuxtla Gutierrez,Tuxtla GutiÃ©rrez,Ð¢ÑÑÑÐ»Ð°-ÐÑÑÑÐµÑÑÐµÑ,Tuxtla GutiÃ©rrez", :latitude => "16.75", :longitude => "-93.11667").save
City.new(:country_id => "159", :name => "Tuxpan de Rodriguez Cano", :aliases => "Tuxpam,Tuxpan,Tuxpan de Rodriguez Cano,Tuxpan de RodrÃ­guez Cano,TÃºxpam,Tuxpan de RodrÃ­guez Cano", :latitude => "20.95", :longitude => "-97.4").save
City.new(:country_id => "159", :name => "Tultitlan", :aliases => "Tul'titlan,Tultitla de Mariano Escobedo,Tultitlan,TultitlÃ¡ de Mariano Escobedo,TultitlÃ¡n,Ð¢ÑÐ»ÑÑÐ¸ÑÐ»Ð°Ð½,TultitlÃ¡n", :latitude => "19.64722", :longitude => "-99.17083").save
City.new(:country_id => "159", :name => "Tultepec", :aliases => "San Pedro de Tultepec,Tultepec,Tultepec", :latitude => "19.68472", :longitude => "-99.12917").save
City.new(:country_id => "159", :name => "Tulancingo", :aliases => "Tulancingo,Tulancingo de Bravo,Tulancingo", :latitude => "20.08333", :longitude => "-98.36667").save
City.new(:country_id => "159", :name => "Tula de Allende", :aliases => "El Tule,Tula,Tula de Allende,Tula-de-Al'ende,Ð¢ÑÐ»Ð°-Ð´Ðµ-ÐÐ»ÑÐµÐ½Ð´Ðµ,Tula de Allende", :latitude => "20.05", :longitude => "-99.35").save
City.new(:country_id => "159", :name => "Toluca", :aliases => "Tollohcan,Toluca,Toluca de Lerdo,Toluka,TÅllohcÄn,Ð¢Ð¾Ð»ÑÐºÐ°,Toluca", :latitude => "19.28833", :longitude => "-99.66722").save
City.new(:country_id => "159", :name => "Tlaxcalancingo", :aliases => "Tlaxcalancingo,Tlaxcalenzingo,Tlazcalancingo,Tlaxcalancingo", :latitude => "19.03333", :longitude => "-98.26667").save
City.new(:country_id => "159", :name => "Tlaquiltenango", :aliases => ",Tlaquiltenango", :latitude => "18.63333", :longitude => "-99.16667").save
City.new(:country_id => "159", :name => "Tlapa de Comonfort", :aliases => "Tlapa,Tlapa de Comonfort,Tlapa-de-Komonfort,Ð¢Ð»Ð°Ð¿Ð°-Ð´Ðµ-ÐÐ¾Ð¼Ð¾Ð½ÑÐ¾ÑÑ,Tlapa de Comonfort", :latitude => "17.55", :longitude => "-98.55").save
City.new(:country_id => "159", :name => "Tlapacoyan", :aliases => ",Tlapacoyan", :latitude => "19.96667", :longitude => "-97.21667").save
City.new(:country_id => "159", :name => "Tlalpan", :aliases => "Tlalpam,Tlalpan,Tlalpan", :latitude => "19.28333", :longitude => "-99.16667").save
City.new(:country_id => "159", :name => "Tlalnepantla", :aliases => "Tlalnepantla,Tlalnepantla de Comonfort,Tlalnepantla de Galeana,Tlalnepantla de baz,Tlanepantla de baz,Ð¢Ð»Ð°Ð»Ð½ÐµÐ¿Ð°Ð½ÑÐ»Ð°,Tlalnepantla", :latitude => "19.52694", :longitude => "-99.22167").save
City.new(:country_id => "159", :name => "Tlahuac", :aliases => ",Tlahuac", :latitude => "19.28167", :longitude => "-99.00333").save
City.new(:country_id => "159", :name => "Tizimin", :aliases => "Titzimin,Tizimin,TizimÃ­n,TizimÃ­n", :latitude => "21.15", :longitude => "-88.15").save
City.new(:country_id => "159", :name => "Tizayuca", :aliases => "Tizayuca,Tizayucan,Tizayuca", :latitude => "19.83333", :longitude => "-98.98333").save
City.new(:country_id => "159", :name => "Tixtla de Guerrero", :aliases => "Tikhtla-de-Gerrero,Tixtla,Ð¢Ð¸ÑÑÐ»Ð°-Ð´Ðµ-ÐÐµÑÑÐµÑÐ¾,Tixtla de Guerrero", :latitude => "17.56732", :longitude => "-99.39799").save
City.new(:country_id => "159", :name => "Ticul", :aliases => "Ticul,Ticul", :latitude => "20.4", :longitude => "-89.53333").save
City.new(:country_id => "159", :name => "Tianguistenco", :aliases => "San Tianguistenco,Santiago Tianguistenco,Tianguistenco,Tianguistenco de Galeana,Tianguistengo,Tianguistenco", :latitude => "19.17972", :longitude => "-99.47056").save
City.new(:country_id => "159", :name => "Tezontepec de Aldama", :aliases => "Texontepec,Tezontepec,Tezontepec Aldama,Tezontepec de Aldama,Tezontepec de Aldama", :latitude => "20.2", :longitude => "-99.26667").save
City.new(:country_id => "159", :name => "Teziutlan", :aliases => "Teziutlan,TeziutlÃ¡n,TeziutlÃ¡n", :latitude => "19.81667", :longitude => "-97.35").save
City.new(:country_id => "159", :name => "Texcoco de Mora", :aliases => "Texcoco,Texcoco de Mora,Tezcoco,tesukoko,ãã¹ã³ã³,Texcoco de Mora", :latitude => "19.51667", :longitude => "-98.88333").save
City.new(:country_id => "159", :name => "Tequixquiac", :aliases => "Santiago Tequixquiac,Tequisquiac,Tequixquiac,Tequixquiac", :latitude => "19.90806", :longitude => "-99.1475").save
City.new(:country_id => "159", :name => "Tequisquiapan", :aliases => "Tequisquiapam,Tequisquiapan,Tequisquiapan", :latitude => "20.51667", :longitude => "-99.86667").save
City.new(:country_id => "159", :name => "Cuautitlan Izcalli", :aliases => "Cuautitlan Izcalli,CuautitlÃ¡n Izcalli,Izcalli,San Francisco Tepoiaco,Tepujaco,CuautitlÃ¡n Izcalli", :latitude => "19.64694", :longitude => "-99.24667").save
City.new(:country_id => "159", :name => "Tepoztlan", :aliases => "Tepoxtlan,TepoxtlÃ¡n,Tepoztlan,TepoztlÃ¡n,TepoztlÃ¡n", :latitude => "18.98333", :longitude => "-99.1").save
City.new(:country_id => "159", :name => "Tepotzotlan", :aliases => "Tepotzotlan,TepotzotlÃ¡n,Tepozotlan,TepotzotlÃ¡n", :latitude => "19.71389", :longitude => "-99.22444").save
City.new(:country_id => "159", :name => "Tepeji de Ocampo", :aliases => "Tepeji,Tepeji de Ocampo,Tepeji del Rio,Tepeji del Rio de Ocampo,Tepeji del RÃ­o,Tepeji del RÃ­o de Ocampo,Tepexi del Rio,Tepexi del RÃ­o,Tepeji de Ocampo", :latitude => "19.90528", :longitude => "-99.34389").save
City.new(:country_id => "159", :name => "Tepeaca", :aliases => ",Tepeaca", :latitude => "18.96667", :longitude => "-97.9").save
City.new(:country_id => "159", :name => "Tepatlaxco de Hidalgo", :aliases => "Tepatlaxco,Tepetlaxco,Tepatlaxco de Hidalgo", :latitude => "19.06747", :longitude => "-97.96595").save
City.new(:country_id => "159", :name => "Teoloyucan", :aliases => ",Teoloyucan", :latitude => "19.74556", :longitude => "-99.18333").save
City.new(:country_id => "159", :name => "Tenosique de Pino Suarez", :aliases => "Tenosique,Tenosique de Pino Suarez,Tenosique de Pino SuÃ¡rez,Tenosique de Pino SuÃ¡rez", :latitude => "17.48333", :longitude => "-91.43333").save
City.new(:country_id => "159", :name => "Tenango de Arista", :aliases => "Tenango,Tenango de Arista,Tenango del Valle,Tenango de Arista", :latitude => "19.10167", :longitude => "-99.59306").save
City.new(:country_id => "159", :name => "Tenancingo de Degollado", :aliases => "Tenancingo,Tenancingo de Degollado,Tenancingo de Degollado", :latitude => "18.96667", :longitude => "-99.6").save
City.new(:country_id => "159", :name => "Temixco", :aliases => "Temisco,Temixco,Temixco", :latitude => "18.85", :longitude => "-99.23333").save
City.new(:country_id => "159", :name => "Temapache", :aliases => ",Temapache", :latitude => "21.06667", :longitude => "-97.63333").save
City.new(:country_id => "159", :name => "Teloloapan", :aliases => ",Teloloapan", :latitude => "18.35", :longitude => "-99.85").save
City.new(:country_id => "159", :name => "Tekax de Alvaro Obregon", :aliases => "Ciudad Obregon,Ciudad ObregÃ³n,Obregon,Tekax,Tekax de Alvaro Obregon,Tekax de Ãlvaro ObregÃ³n,Tekax de Ãlvaro ObregÃ³n", :latitude => "20.2", :longitude => "-89.28333").save
City.new(:country_id => "159", :name => "Tehuacan", :aliases => "Tehuacan,TehuacÃ¡n,TehuacÃ¡n", :latitude => "18.45", :longitude => "-97.38333").save
City.new(:country_id => "159", :name => "Tecamachalco", :aliases => ",Tecamachalco", :latitude => "18.88333", :longitude => "-97.73333").save
City.new(:country_id => "159", :name => "Teapa", :aliases => ",Teapa", :latitude => "17.55", :longitude => "-92.95").save
City.new(:country_id => "159", :name => "Taxco de Alarcon", :aliases => "Tasco,Tasko-de-Alarkon,Taxco,Taxco de Alarcon,Taxco de AlarcÃ³n,Ð¢Ð°ÑÐºÐ¾-Ð´Ðµ-ÐÐ»Ð°ÑÐºÐ¾Ð½,Taxco de AlarcÃ³n", :latitude => "18.55", :longitude => "-99.6").save
City.new(:country_id => "159", :name => "Tapachula", :aliases => "Tapachula,Tapachule,Ð¢Ð°Ð¿Ð°ÑÑÐ»Ðµ,Tapachula", :latitude => "14.9", :longitude => "-92.28333").save
City.new(:country_id => "159", :name => "Tantoyuca", :aliases => "Tantoyuca,carretera platon sanchez,Tantoyuca", :latitude => "21.35", :longitude => "-98.23333").save
City.new(:country_id => "159", :name => "Tampico", :aliases => "Tampico,Tampiko,tampiko,Ð¢Ð°Ð¼Ð¿Ð¸ÐºÐ¾,íí¼ì½,Tampico", :latitude => "22.21667", :longitude => "-97.85").save
City.new(:country_id => "159", :name => "Tamazunchale", :aliases => ",Tamazunchale", :latitude => "21.26667", :longitude => "-98.78333").save
City.new(:country_id => "159", :name => "Santo Domingo Tehuantepec", :aliases => "Ciudad Santo Domingo Tehuantepec,Santo Domingo,Santo Domingo Tehuantepec,Tehuantepec,Santo Domingo Tehuantepec", :latitude => "16.33333", :longitude => "-95.23333").save
City.new(:country_id => "159", :name => "Santiago Tuxtla", :aliases => "Juan de la Luz Enriquez,Juan de la Luz EnrÃ­quez,Santiago Tuxtla,Tuxtla,Tuxtla Colorada,Santiago Tuxtla", :latitude => "18.46667", :longitude => "-95.3").save
City.new(:country_id => "159", :name => "Santiago Pinotepa Nacional", :aliases => "Pinotepa Nacional,Santiago,Santiago Pinotepa Nacional,Santiago Pinotepa Nacional", :latitude => "16.31667", :longitude => "-98.01667").save
City.new(:country_id => "159", :name => "Santiago Tulantepec", :aliases => "Santiago,Santiago Tulantepec,Santiago Tulantepec", :latitude => "20.03333", :longitude => "-98.35").save
City.new(:country_id => "159", :name => "Santa Maria Moyotzingo", :aliases => "Moyatzingo,Moyotzingo,Santa Maria Moyotzingo,Santa MarÃ­a Moyotzingo,Santa MarÃ­a Moyotzingo", :latitude => "19.25", :longitude => "-98.4").save
City.new(:country_id => "159", :name => "Santa Maria Ajoloapan", :aliases => "Ajoloapan,Santa Maria,Santa Maria Ajoloapan,Santa MarÃ­a Ajoloapan,Santa MarÃ­a Ajoloapan", :latitude => "19.97861", :longitude => "-99.04722").save
City.new(:country_id => "159", :name => "Santa Cruz Xoxocotlan", :aliases => "Santa Cruz,Santa Cruz Xoxocotlan,Santa Cruz XoxocotlÃ¡n,Xoxocotlan,Santa Cruz XoxocotlÃ¡n", :latitude => "17.01667", :longitude => "-96.73333").save
City.new(:country_id => "159", :name => "Santa Cruz Tecamac", :aliases => "Santa Cruz,Santa Cruz Tecamac,Tecama,Tecamac,Santa Cruz Tecamac", :latitude => "19.73333", :longitude => "-98.96667").save
City.new(:country_id => "159", :name => "Santa Ana Chiautempan", :aliases => "Chiautempan,Santa Ana,Santa Ana Chiautempan,Santa Ana Chiautempan", :latitude => "19.31667", :longitude => "-98.18333").save
City.new(:country_id => "159", :name => "San Salvador el Seco", :aliases => "El Seco,San Salvador el Seco,San Salvador el Seco", :latitude => "19.13333", :longitude => "-97.65").save
City.new(:country_id => "159", :name => "San Salvador Atenco", :aliases => "Atenco,San Salvador Atenco,San Salvador Atenco", :latitude => "19.51667", :longitude => "-98.91667").save
City.new(:country_id => "159", :name => "San Pablo de las Salinas", :aliases => "Salinas,San Pablo,San Pablo de Salinas,San Pablo de las Salinas,San Pablo de las Salinas", :latitude => "19.66583", :longitude => "-99.09639").save
City.new(:country_id => "159", :name => "San Pablo Autopan", :aliases => "Autopan,San Pablo,San Pablo Autopan,San Pablo Autopan", :latitude => "19.35611", :longitude => "-99.6625").save
City.new(:country_id => "159", :name => "San Miguel Zinacantepec", :aliases => "San Miguel Zicantepec,San Miguel Zinacantepec,Zinacantepec,Zinacatepec,San Miguel Zinacantepec", :latitude => "19.28194", :longitude => "-99.73861").save
City.new(:country_id => "159", :name => "San Miguel Coatlinchan", :aliases => "Coatlinchan,CoatlinchÃ¡n,San Miguel,San Miguel Coatlinchan,San Miguel Coatlinchoan,San Miguel CoatlinchÃ¡n,San Miguel CoatlinchÃ¡n", :latitude => "19.45", :longitude => "-98.86667").save
City.new(:country_id => "159", :name => "San Mateo Atenco", :aliases => "Atenco,San Mateo,San Mateo Atenco,San Mateo Atenco", :latitude => "19.26167", :longitude => "-99.53528").save
City.new(:country_id => "159", :name => "San Martin Texmelucan de Labastida", :aliases => "San Martin,San Martin Texmelucan,San Martin Texmelucan de Labastida,San MartÃ­n,San MartÃ­n Texmelucan,San MartÃ­n Texmelucan de Labastida,Texmelucan,San MartÃ­n Texmelucan de Labastida", :latitude => "19.28333", :longitude => "-98.43333").save
City.new(:country_id => "159", :name => "San Luis Teolocholco", :aliases => "San Luis Teolocholco,Teolochalco,Teolocholco,San Luis Teolocholco", :latitude => "19.25", :longitude => "-98.18333").save
City.new(:country_id => "159", :name => "San Juan Teotihuacan", :aliases => "San Juan,San Juan Teotihuacan,San Juan TeotihuacÃ¡n,Teotihuacan,TeotihuacÃ¡n,San Juan TeotihuacÃ¡n", :latitude => "19.68333", :longitude => "-98.86667").save
City.new(:country_id => "159", :name => "San Juan del Rio", :aliases => "San Juan del Rio,San Juan del RÃ­o,San Juan del RÃ­o", :latitude => "20.38333", :longitude => "-100").save
City.new(:country_id => "159", :name => "San Juan Bautista Tuxtepec", :aliases => "San Juan Bautista,San Juan Bautista Tuxtepec,San Juan Bautista Tuxtla,Tuxtepec,San Juan Bautista Tuxtepec", :latitude => "18.1", :longitude => "-96.11667").save
City.new(:country_id => "159", :name => "San Francisco Acuautla", :aliases => "Acuautla,San Francisco Acuautla,San Francisco Acuautla", :latitude => "19.33333", :longitude => "-98.85").save
City.new(:country_id => "159", :name => "Sanctorum", :aliases => "Sanctorium,Sanctorum,SanctÃ³rum,SanctÃ³rum", :latitude => "19.1", :longitude => "-98.25").save
City.new(:country_id => "159", :name => "San Cristobal de Las Casas", :aliases => "Ciudad Las Casas,Ciudad de las Casas,San Cristobal,San Cristobal de Las Casas,San Cristobal de las Casas,San Cristobal las Casas,San CristÃ³bal de Las Casas,San CristÃ³bal de las Casas,San CristÃ³bal las Casas,San CristÃ³bal de Las Casas", :latitude => "16.75", :longitude => "-92.63333").save
City.new(:country_id => "159", :name => "San Andres Tuxtla", :aliases => "San Andres Tuxtla,San AndrÃ©s Tuxtla,Tuxtla,San AndrÃ©s Tuxtla", :latitude => "18.45", :longitude => "-95.21667").save
City.new(:country_id => "159", :name => "Salina Cruz", :aliases => "Salina Cruz,Salina-Krus,Ð¡Ð°Ð»Ð¸Ð½Ð°-ÐÑÑÑ,Salina Cruz", :latitude => "16.16667", :longitude => "-95.2").save
City.new(:country_id => "159", :name => "Rio Verde", :aliases => ",RÃ­o Verde", :latitude => "21.93333", :longitude => "-99.98333").save
City.new(:country_id => "159", :name => "Rio Bravo", :aliases => "El Ebano,Rio Bravo,Rio-Bravo,RÃ­o Bravo,Ð Ð¸Ð¾-ÐÑÐ°Ð²Ð¾,RÃ­o Bravo", :latitude => "25.98333", :longitude => "-98.1").save
City.new(:country_id => "159", :name => "Rio Blanco", :aliases => "Rio Blanco,Rio-Blanko,RÃ­o Blanco,Tenango de Rio Blanco,Tenango de RÃ­o Blanco,Ð Ð¸Ð¾-ÐÐ»Ð°Ð½ÐºÐ¾,RÃ­o Blanco", :latitude => "18.83333", :longitude => "-97.15").save
City.new(:country_id => "159", :name => "Reynosa", :aliases => "Reinosa,Rejnosa,Reynosa,Ð ÐµÐ¹Ð½Ð¾ÑÐ°,Reynosa", :latitude => "26.08333", :longitude => "-98.28333").save
City.new(:country_id => "159", :name => "Puerto Escondido", :aliases => "Puerto Escondido,Puerto Escondido", :latitude => "15.85", :longitude => "-97.06667").save
City.new(:country_id => "159", :name => "Puente de Ixtla", :aliases => ",Puente de Ixtla", :latitude => "18.61472", :longitude => "-99.31806").save
City.new(:country_id => "159", :name => "Puebla de Zaragoza", :aliases => "Cuetlaxcoapan,CuetlaxcÅÄpan,Heroica Puebla de Zaragoza,Puebla,Puebla de Zaragoza,Puebla de los Angeles,puebura,ÐÑÐµÐ±Ð»Ð°,×¤×××××,ãã¨ãã©,Puebla de Zaragoza", :latitude => "19.05", :longitude => "-98.2").save
City.new(:country_id => "159", :name => "Progreso de Obregon", :aliases => "Progreso,Progreso de Obregon,Progreso de ObregÃ³n,Progreso de ObregÃ³n", :latitude => "20.25", :longitude => "-99.2").save
City.new(:country_id => "159", :name => "Progreso", :aliases => "Progreso,ÐÑÐ¾Ð³ÑÐµÑÐ¾,Progreso", :latitude => "21.28333", :longitude => "-89.66667").save
City.new(:country_id => "159", :name => "Poza Rica de Hidalgo", :aliases => "Poza Rica,Poza Rica de Hidalgo", :latitude => "20.53315", :longitude => "-97.45946").save
City.new(:country_id => "159", :name => "Polanco", :aliases => "Col Polanco,Col. Polanco,Colonia Polanco,Polanco,Polanco", :latitude => "19.41667", :longitude => "-99.2").save
City.new(:country_id => "159", :name => "Playa del Carmen", :aliases => "Plaja-del'-Karmen,Playa del Carmen, Quintana Roo,ÐÐ»Ð°Ñ-Ð´ÐµÐ»Ñ-ÐÐ°ÑÐ¼ÐµÐ½,Playa del Carmen", :latitude => "20.6274", :longitude => "-87.07987").save
City.new(:country_id => "159", :name => "Pijijiapan", :aliases => "Pijijiapam,PijijiÃ¡pam,Pijijiapan", :latitude => "15.70105", :longitude => "-93.22998").save
City.new(:country_id => "159", :name => "Peto", :aliases => ",Peto", :latitude => "20.13333", :longitude => "-88.91667").save
City.new(:country_id => "159", :name => "Perote", :aliases => ",Perote", :latitude => "19.56667", :longitude => "-97.23333").save
City.new(:country_id => "159", :name => "Paraiso", :aliases => ",ParaÃ­so", :latitude => "18.4", :longitude => "-93.23333").save
City.new(:country_id => "159", :name => "Papantla de Olarte", :aliases => "Papanila,Papantla,Papantla de Olarte,Papantla de Olarte", :latitude => "20.45", :longitude => "-97.31667").save
City.new(:country_id => "159", :name => "Panuco", :aliases => ",PÃ¡nuco", :latitude => "22.05", :longitude => "-98.16667").save
City.new(:country_id => "159", :name => "Palmarito Tochapan", :aliases => "Palmarito,Palmarito Tochapan,Palmarito TochapÃ¡n,Palmarito TochapÃ¡n", :latitude => "18.9", :longitude => "-97.61667").save
City.new(:country_id => "159", :name => "Palenque", :aliases => "Palenke,PalenkÄ,Palenque,Palenque/Temp,PalenquÃ©,Ruinas de Palenque,pa lun ke,ÐÐ°Ð»ÐµÐ½ÐºÐµ,å¸ä¼¦å,Palenque", :latitude => "17.51667", :longitude => "-91.96667").save
City.new(:country_id => "159", :name => "Pachuca de Soto", :aliases => "Pachuca,Pachuca de Soto,Pachuca de Soto", :latitude => "20.11697", :longitude => "-98.73329").save
City.new(:country_id => "159", :name => "Ozumba de Alzate", :aliases => "Ozumba,Ozumba de Alzate,Ozumba de Alzate", :latitude => "19.05", :longitude => "-98.8").save
City.new(:country_id => "159", :name => "Oxkutzcab", :aliases => ",Oxkutzcab", :latitude => "20.3", :longitude => "-89.41667").save
City.new(:country_id => "159", :name => "Orizaba", :aliases => "Orisaba,Orizaba,ÐÑÐ¸ÑÐ°Ð±Ð°,Orizaba", :latitude => "18.85", :longitude => "-97.1").save
City.new(:country_id => "159", :name => "Ometepec", :aliases => ",Ometepec", :latitude => "16.68333", :longitude => "-98.41667").save
City.new(:country_id => "159", :name => "Ocozocuautla", :aliases => "Ocozocoautla,Ocozocoautla de Espinosa,Ocozocuautla,Ocozocuautla", :latitude => "16.76667", :longitude => "-93.36667").save
City.new(:country_id => "159", :name => "Ocoyoacac", :aliases => "Ocoyoacac,Ocoyoacac", :latitude => "19.27194", :longitude => "-99.45889").save
City.new(:country_id => "159", :name => "Ocosingo", :aliases => ",Ocosingo", :latitude => "17.06667", :longitude => "-92.25").save
City.new(:country_id => "159", :name => "Oaxaca de Juarez", :aliases => "Oakhaka de Khuares,Oaxaca,Oaxaca by,Oaxaca de Juarez,Oaxaca de JuÃ¡rez,Santa Maria,ÐÐ°ÑÐ°ÐºÐ° Ð´Ðµ Ð¥ÑÐ°ÑÐµÑ,Oaxaca de JuÃ¡rez", :latitude => "17.05", :longitude => "-96.71667").save
City.new(:country_id => "159", :name => "Nuevo Laredo", :aliases => "Nuehvo-Laredo,Nuevo Laredo,ÐÑÑÐ²Ð¾-ÐÐ°ÑÐµÐ´Ð¾,Nuevo Laredo", :latitude => "27.5", :longitude => "-99.51667").save
City.new(:country_id => "159", :name => "Nogales", :aliases => "Nogales,Nogales", :latitude => "18.81667", :longitude => "-97.16667").save
City.new(:country_id => "159", :name => "Nicolas Romero", :aliases => "Nicolas Romero,NicolÃ¡s Romero,Villa Nicolas Romero,Villa NicolÃ¡s Romero,NicolÃ¡s Romero", :latitude => "19.62194", :longitude => "-99.31306").save
City.new(:country_id => "159", :name => "Naucalpan de Juarez", :aliases => "Naucalpan,Naucalpan de Juarez,Naucalpan de JuÃ¡rez,Naukal'pan-de-Khuares,San Bartolo Naucalpan,ÐÐ°ÑÐºÐ°Ð»ÑÐ¿Ð°Ð½-Ð´Ðµ-Ð¥ÑÐ°ÑÐµÑ,Naucalpan de JuÃ¡rez", :latitude => "19.47851", :longitude => "-99.23963").save
City.new(:country_id => "159", :name => "Naranjos", :aliases => "Naranjas,Naranjos,Naranjos", :latitude => "21.35", :longitude => "-97.68333").save
City.new(:country_id => "159", :name => "Nanchital", :aliases => ",Nanchital", :latitude => "18.06667", :longitude => "-94.4").save
City.new(:country_id => "159", :name => "Motul de Felipe Carrillo Puerto", :aliases => "Motul,Motul de Carrillo Puerto,Motul de Felipe Carrillo Puerto,Motul de Felipe Carrillo Puerto", :latitude => "21.1", :longitude => "-89.28333").save
City.new(:country_id => "159", :name => "Motozintla de Mendoza", :aliases => "Motozintla,Motozintla de Mendoza,San Francisco Motozintla,Villa de Motozintla de Mendoza,Motozintla de Mendoza", :latitude => "15.36667", :longitude => "-92.23333").save
City.new(:country_id => "159", :name => "Montemorelos", :aliases => "Montemorelos,Montemorelos", :latitude => "25.2", :longitude => "-99.81667").save
City.new(:country_id => "159", :name => "Momoxpan", :aliases => ",Momoxpan", :latitude => "19.06667", :longitude => "-98.23333").save
City.new(:country_id => "159", :name => "Mixquiahuala", :aliases => ",Mixquiahuala", :latitude => "20.23333", :longitude => "-99.21667").save
City.new(:country_id => "159", :name => "Misantla", :aliases => ",Misantla", :latitude => "19.93333", :longitude => "-96.83333").save
City.new(:country_id => "159", :name => "Miramar", :aliases => ",Miramar", :latitude => "22.33333", :longitude => "-97.86667").save
City.new(:country_id => "159", :name => "Minatitlan", :aliases => "Minatitlan,MinatitlÃ¡n,MinatitlÃ¡n", :latitude => "17.98333", :longitude => "-94.51667").save
City.new(:country_id => "159", :name => "Milpa Alta", :aliases => ",Milpa Alta", :latitude => "19.19194", :longitude => "-99.02361").save
City.new(:country_id => "159", :name => "Miahuatlan de Porfirio Diaz", :aliases => "Miahuatlan,Miahuatlan de Porfirio Diaz,MiahuatlÃ¡n de Porfirio DÃ­az,San Andres,San Andres Miahuatlan,San AndrÃ©s,San AndrÃ©s MiahuatlÃ¡n,MiahuatlÃ¡n de Porfirio DÃ­az", :latitude => "16.33333", :longitude => "-96.6").save
City.new(:country_id => "159", :name => "Metepec", :aliases => "Metepec,Metepek,ÐÐµÑÐµÐ¿ÐµÐº,Metepec", :latitude => "19.25361", :longitude => "-99.60778").save
City.new(:country_id => "159", :name => "Merida", :aliases => "Ciudad de Merida,Ciudad de MÃ©rida,Merida,MÃ©rida,mei li da,merida,ÐÐµÑÐ¸Ð´Ð°,ã¡ãªã,æ¢éè¾¾,æ¢éé,MÃ©rida", :latitude => "20.96667", :longitude => "-89.61667").save
City.new(:country_id => "159", :name => "Matias Romero", :aliases => ",MatÃ­as Romero", :latitude => "16.88333", :longitude => "-95.03333").save
City.new(:country_id => "159", :name => "Heroica Matamoros", :aliases => "Heroica Matamoros,Matamoros,ÐÐ°ÑÐ°Ð¼Ð¾ÑÐ¾Ñ,Heroica Matamoros", :latitude => "25.88333", :longitude => "-97.5").save
City.new(:country_id => "159", :name => "Martinez de La Torre", :aliases => ",MartÃ­nez de La Torre", :latitude => "20.06667", :longitude => "-97.05").save
City.new(:country_id => "159", :name => "Mapastepec", :aliases => "Mapastepec,Mapastepec", :latitude => "15.43333", :longitude => "-92.9").save
City.new(:country_id => "159", :name => "Magdalena Contreras", :aliases => "Magdalena Contreras,Magdalena Contreras", :latitude => "19.28333", :longitude => "-99.23333").save
City.new(:country_id => "159", :name => "Macuspana", :aliases => "Macuspana,Macuspana", :latitude => "17.76667", :longitude => "-92.6").save
City.new(:country_id => "159", :name => "Los Reyes Acozac", :aliases => "Los Reyes Acozac,Los Reyes Xoloc,Reyes,Los Reyes Acozac", :latitude => "19.76667", :longitude => "-98.98333").save
City.new(:country_id => "159", :name => "Los Reyes", :aliases => "Los Reyes,Los Reyes La Paz,Reyes,Reyes la Paz,Los Reyes", :latitude => "19.35", :longitude => "-98.96667").save
City.new(:country_id => "159", :name => "Linares", :aliases => "Linares,ÐÐ¸Ð½Ð°ÑÐµÑ,Linares", :latitude => "24.85778", :longitude => "-99.56778").save
City.new(:country_id => "159", :name => "Lerma de Villada", :aliases => "Lerma,Lerma de Villada,Zerma de Villada,Lerma de Villada", :latitude => "19.285", :longitude => "-99.51556").save
City.new(:country_id => "159", :name => "Lerdo de Tejada", :aliases => ",Lerdo de Tejada", :latitude => "18.61667", :longitude => "-95.51667").save
City.new(:country_id => "159", :name => "Las Margaritas", :aliases => "Las Margaritas,Las Margaritas", :latitude => "16.31667", :longitude => "-91.98333").save
City.new(:country_id => "159", :name => "Las Choapas", :aliases => ",Las Choapas", :latitude => "17.93333", :longitude => "-94.08333").save
City.new(:country_id => "159", :name => "La Poza", :aliases => ",La Poza", :latitude => "20.11667", :longitude => "-96.96667").save
City.new(:country_id => "159", :name => "La Isla", :aliases => "Isla,La Isla,La Isla", :latitude => "18.6", :longitude => "-96.15").save
City.new(:country_id => "159", :name => "Kanasin", :aliases => "Kanacin,KanacÃ­n,Kanasin,KanasÃ­n,Kanazin,KanasÃ­n", :latitude => "20.93333", :longitude => "-89.56667").save
City.new(:country_id => "159", :name => "Juchitan de Zaragoza", :aliases => "Juchitan,Juchitan de Zaragoza,JuchitÃ¡n de Zaragoza,Khuchitan-de-Saragosa,Ð¥ÑÑÐ¸ÑÐ°Ð½-Ð´Ðµ-Ð¡Ð°ÑÐ°Ð³Ð¾ÑÐ°,JuchitÃ¡n de Zaragoza", :latitude => "16.43333", :longitude => "-95.01667").save
City.new(:country_id => "159", :name => "Jojutla de Juarez", :aliases => "Jojutla,Jojutla de Juarez,Jojutla de JuÃ¡rez,Jojutla de JuÃ¡rez", :latitude => "18.61667", :longitude => "-99.18333").save
City.new(:country_id => "159", :name => "Jiutepec", :aliases => "Jiutepec,Xiutepec,Jiutepec", :latitude => "18.86667", :longitude => "-99.18333").save
City.new(:country_id => "159", :name => "Jalpa de Mendez", :aliases => "Jalpa,Jalpa de Mendez,Jalpa de MÃ©ndez,Jalpa de MÃ©ndez", :latitude => "18.13333", :longitude => "-93.08333").save
City.new(:country_id => "159", :name => "Jalapa Enriquez", :aliases => "Jalapa,Jalapa Enriques,Jalapa Enriquez,Jalapa EnrÃ­quez,Xalapa,Xalapa de Enriquez,Xalapa de EnrÃ­quez,Jalapa EnrÃ­quez", :latitude => "19.53333", :longitude => "-96.91667").save
City.new(:country_id => "159", :name => "Izucar de Matamoros", :aliases => "Izucar,Izucar de Matamoros,IzÃºcar,IzÃºcar de Matamoros,Matamoros,Matamoros de Izucar,Matamoros de IzÃºcar,IzÃºcar de Matamoros", :latitude => "18.6", :longitude => "-98.46667").save
City.new(:country_id => "159", :name => "San Jeronimo Ixtepec", :aliases => "Ixtepec,San Geronimo Ixtepec,San JerÃ³nimo Ixtepec", :latitude => "16.57855", :longitude => "-95.10223").save
City.new(:country_id => "159", :name => "Ixtapan de la Sal", :aliases => "Ixtapan de la Sal,Ixtapan de la Sal", :latitude => "18.83333", :longitude => "-99.68333").save
City.new(:country_id => "159", :name => "Ixtapaluca", :aliases => "Ixtapaluca,Iztapaluca,Ixtapaluca", :latitude => "19.31667", :longitude => "-98.88333").save
City.new(:country_id => "159", :name => "Iztapalapa", :aliases => "Ixtapalapa,Iztaoalaoa,Iztapalapa,Iztapalapa", :latitude => "19.35111", :longitude => "-99.05194").save
City.new(:country_id => "159", :name => "Ixtaczoquitlan", :aliases => "Ixtaczoquitlan,IxtaczoquitlÃ¡n,IxtaczoquitlÃ¡n", :latitude => "18.85", :longitude => "-97.06667").save
City.new(:country_id => "159", :name => "Iztacalco", :aliases => "Delegacion de Ixtacalco,DelegaciÃ³n de Ixtacalco,Ixtacalco,Iztacalco,Iztacalco", :latitude => "19.39667", :longitude => "-99.08472").save
City.new(:country_id => "159", :name => "Ixmiquilpan", :aliases => "Iximiquilpan,Ixmiquilpan,Ixmiquilpan", :latitude => "20.48333", :longitude => "-99.23333").save
City.new(:country_id => "159", :name => "Iguala de la Independencia", :aliases => "Iguala,Iguala de la Independencia,Iguala de la Independencia", :latitude => "18.35", :longitude => "-99.53333").save
City.new(:country_id => "159", :name => "Hunucma", :aliases => ",HunucmÃ¡", :latitude => "21.01667", :longitude => "-89.86667").save
City.new(:country_id => "159", :name => "Huixtla", :aliases => ",Huixtla", :latitude => "15.15", :longitude => "-92.46667").save
City.new(:country_id => "159", :name => "Huitzuco de los Figueroa", :aliases => "Huitzuco,Huitzuco de los Figueroa,Huizuco,Huitzuco de los Figueroa", :latitude => "18.3", :longitude => "-99.35").save
City.new(:country_id => "159", :name => "Huimanguillo", :aliases => ",Huimanguillo", :latitude => "17.85", :longitude => "-93.38333").save
City.new(:country_id => "159", :name => "Huejutla de Reyes", :aliases => "Huejutla,Huejutla de Reyes,Uehkhutla-de-Rejes,Ð£ÑÑÑÑÐ»Ð°-Ð´Ðµ-Ð ÐµÐ¹ÐµÑ,Huejutla de Reyes", :latitude => "21.13333", :longitude => "-98.41667").save
City.new(:country_id => "159", :name => "Huejotzingo", :aliases => ",Huejotzingo", :latitude => "19.15", :longitude => "-98.4").save
City.new(:country_id => "159", :name => "Huauchinango", :aliases => ",Huauchinango", :latitude => "20.18333", :longitude => "-98.05").save
City.new(:country_id => "159", :name => "Huatusco de Chicuellar", :aliases => "Huatusco,Huatusco de Chicuellar,Huatusco de Chicuellar", :latitude => "19.15", :longitude => "-96.95").save
City.new(:country_id => "159", :name => "Huajuapan de Leon", :aliases => "Huajuapam,Huajuapam de Leon,Huajuapan,Huajuapan de Leon,Huajuapan de LeÃ³n,HuajuÃ¡pam,HuajuÃ¡pam de LeÃ³n,Huajuapan de LeÃ³n", :latitude => "17.8", :longitude => "-97.76667").save
City.new(:country_id => "159", :name => "Frontera", :aliases => "Alvaro Obregon,Frontera,Ponta Frontera,Puerto Alvaro Obregon,Puerto Obregon,Puerto Ãlvaro Obregon,Ãlvaro ObregÃ³n,Ð¤ÑÐ¾Ð½ÑÐµÑÐ°,Frontera", :latitude => "18.58333", :longitude => "-92.65").save
City.new(:country_id => "159", :name => "Fortin de las Flores", :aliases => "El Fortin,El FortÃ­n,Fortin,Fortin de las Flores,FortÃ­n,FortÃ­n de las Flores,FortÃ­n de las Flores", :latitude => "18.9", :longitude => "-97").save
City.new(:country_id => "159", :name => "Felipe Carrillo Puerto", :aliases => "Felipe Carillo Puerto,Felipe Carrillo Puerto,Santa Cruz de Bravo,Felipe Carrillo Puerto", :latitude => "19.58333", :longitude => "-88.05").save
City.new(:country_id => "159", :name => "Escarcega", :aliases => "Ehskarsega,Escarcega de Matamoros,Francisco Escarcega,Francisco EscÃ¡rcega,Kilometro 45,KilÃ³metro 45,Ð­ÑÐºÐ°ÑÑÐµÐ³Ð°,EscÃ¡rcega", :latitude => "18.60891", :longitude => "-90.74544").save
City.new(:country_id => "159", :name => "Emiliano Zapata", :aliases => "Emiliano Zapata,Emiliano Zapata", :latitude => "18.83333", :longitude => "-99.18333").save
City.new(:country_id => "159", :name => "Emiliano Zapata", :aliases => "Ehmiliano Sapata,Emiliano Zapata,Montecristo,Montecrito,Ð­Ð¼Ð¸Ð»Ð¸Ð°Ð½Ð¾ Ð¡Ð°Ð¿Ð°ÑÐ°,Emiliano Zapata", :latitude => "17.75", :longitude => "-91.76667").save
City.new(:country_id => "159", :name => "El Mante", :aliases => ",El Mante", :latitude => "22.73333", :longitude => "-98.96667").save
City.new(:country_id => "159", :name => "Ecatepec", :aliases => "Ecatepec,Ecatepec Morelos,Ecatepec de Morelos,Morelos,San Cristobal,San Cristobal Ecatepec,San Cristobal Ecatepec de Morelos,San CristÃ³bal,San CristÃ³bal Ecatepec,San CristÃ³bal Ecatepec de Morelos,Ecatepec", :latitude => "19.60111", :longitude => "-99.0525").save
City.new(:country_id => "159", :name => "Cunduacan", :aliases => "Conduacan,ConduacÃ¡n,Cunduacan,CunduacÃ¡n,CunduacÃ¡n", :latitude => "18.06667", :longitude => "-93.16667").save
City.new(:country_id => "159", :name => "Cuernavaca", :aliases => "Cuauhnahuac,CuauhnÄhuac,Cuernavaca,Kuehrnavaka,ÐÑÑÑÐ½Ð°Ð²Ð°ÐºÐ°,Cuernavaca", :latitude => "18.91667", :longitude => "-99.25").save
City.new(:country_id => "159", :name => "Cuautlancingo", :aliases => "Cuautlancingo,San Juan Cuautlancingo,Cuautlancingo", :latitude => "19.08333", :longitude => "-98.26667").save
City.new(:country_id => "159", :name => "Cuautla Morelos", :aliases => "Cuautla,Cuautla Morelos,Cuautla Morelos", :latitude => "18.8", :longitude => "-98.95").save
City.new(:country_id => "159", :name => "Cuautitlan", :aliases => "Cuautitlan,Cuautitlan de Romero Rubio,CuautitlÃ¡n,CuautitlÃ¡n de Romero Rubio,Kuautitlan,ÐÑÐ°ÑÑÐ¸ÑÐ»Ð°Ð½,CuautitlÃ¡n", :latitude => "19.67111", :longitude => "-99.18278").save
City.new(:country_id => "159", :name => "Cuautepec de Hinojosa", :aliases => "Cuautepec,Cuautepec de Hinojosa,Cuautepec de Hinojosa", :latitude => "20.03333", :longitude => "-98.3").save
City.new(:country_id => "159", :name => "Cuajimalpa", :aliases => "Cuajimalpa,Cuajimalpa de Morelos,Guajimalpa,Cuajimalpa", :latitude => "19.35583", :longitude => "-99.30111").save
City.new(:country_id => "159", :name => "San Miguel de Cozumel", :aliases => "Conzumel,Cozumel,San Miguel Cozumel,San Miguel de Cozumel,San Miguel de Cozumel", :latitude => "20.50833", :longitude => "-86.94583").save
City.new(:country_id => "159", :name => "Coyotepec", :aliases => ",Coyotepec", :latitude => "19.775", :longitude => "-99.20722").save
City.new(:country_id => "159", :name => "Coyoacan", :aliases => "Coyoacan,CoyoacÃ¡n,koyoakan,ã³ã¨ã¢ã«ã³,CoyoacÃ¡n", :latitude => "19.32889", :longitude => "-99.16028").save
City.new(:country_id => "159", :name => "Cosoleacaque", :aliases => ",Cosoleacaque", :latitude => "18", :longitude => "-94.61667").save
City.new(:country_id => "159", :name => "Cosamaloapan de Carpio", :aliases => "Cosamaloapan,Cosamaloapan de Carpio,Cosamaloapan de Carpio", :latitude => "18.36667", :longitude => "-95.8").save
City.new(:country_id => "159", :name => "Cordoba", :aliases => "Cordoba,CÃ³rdoba,Kordova,ÐÐ¾ÑÐ´Ð¾Ð²Ð°,CÃ³rdoba", :latitude => "18.88333", :longitude => "-96.93333").save
City.new(:country_id => "159", :name => "Contla", :aliases => "Contla,San Bernardino,San Bernardino Contla,Contla", :latitude => "19.33333", :longitude => "-98.16667").save
City.new(:country_id => "159", :name => "Comitan de Dominguez", :aliases => "Comitan,Comitan de Dominguez,ComitÃ¡n,ComitÃ¡n de DomÃ­nguez,Komitan-de-Dominges,ÐÐ¾Ð¼Ð¸ÑÐ°Ð½-Ð´Ðµ-ÐÐ¾Ð¼Ð¸Ð½Ð³ÐµÑ,ComitÃ¡n de DomÃ­nguez", :latitude => "16.25", :longitude => "-92.13333").save
City.new(:country_id => "159", :name => "Comalcalco", :aliases => "Comalcalco,Comalcalco", :latitude => "18.26667", :longitude => "-93.21667").save
City.new(:country_id => "159", :name => "Coatzintla", :aliases => "Coatzintla,Coazintla,Coatzintla", :latitude => "20.48333", :longitude => "-97.45").save
City.new(:country_id => "159", :name => "Coatzacoalcos", :aliases => "Coatzacoalcos,Koacakoalkos,Puerto Mexico,ÐÐ¾Ð°ÑÐ°ÐºÐ¾Ð°Ð»ÐºÐ¾Ñ,Coatzacoalcos", :latitude => "18.15", :longitude => "-94.41667").save
City.new(:country_id => "159", :name => "Coatepec", :aliases => ",Coatepec", :latitude => "19.45", :longitude => "-96.96667").save
City.new(:country_id => "159", :name => "Coacalco", :aliases => "Coacalco,Coacalco de Berriozabal,Coacalco de Berriozaval,Coacalco de BerriozÃ¡bal,Coacalco de BerriozÃ¡val,Coacalco", :latitude => "19.63167", :longitude => "-99.11028").save
City.new(:country_id => "159", :name => "Ciudad Victoria", :aliases => "Cd. Victoria,Ciudad Victoria,S'judad-Viktorija,Ð¡ÑÑÐ´Ð°Ð´-ÐÐ¸ÐºÑÐ¾ÑÐ¸Ñ,Ciudad Victoria", :latitude => "23.73333", :longitude => "-99.13333").save
City.new(:country_id => "159", :name => "Ciudad Valles", :aliases => "Cd Valles,Cd. Valles,Ciudad Valles,Ciudad de Valles,S'judad-Val'es,Valles,Ð¡ÑÑÐ´Ð°Ð´-ÐÐ°Ð»ÑÐµÑ,Ciudad Valles", :latitude => "21.98333", :longitude => "-99.01667").save
City.new(:country_id => "159", :name => "Ciudad Serdan", :aliases => "Chalchicomula,Ciudad Serdan,Ciudad SerdÃ¡n,Ciudad SerdÃ¡n", :latitude => "18.98333", :longitude => "-97.45").save
City.new(:country_id => "159", :name => "Ciudad Sahagun", :aliases => "Bernardino de Sahagun,Bernardino de SahagÃºn,Ciudad Bernardino de Sahagun,Ciudad Bernardino de SahagÃºn,Ciudad Fray Bernardino Sahagun,Ciudad Fray Bernardino SahagÃºn,Ciudad Sahagun,Ciudad SahagÃºn,Sahagun,SahagÃºn,Ciudad SahagÃºn", :latitude => "19.76667", :longitude => "-98.58333").save
City.new(:country_id => "159", :name => "Ciudad Nezahualcoyotl", :aliases => "Cd. Neza,Cd. Nezahualcoyotl,Cd. NezahualcÃ³yotl,Ciudad Netzahualcoyotl,Ciudad NetzahualcÃ³yotl,Ciudad Neza,Ciudad Nezahualcoyotl,Ciudad NezahualcÃ³yotl,Nesahualkojotlis,Netzahualcoyotl,NetzahualcÃ³yotl,Neza,Nezahualcoyotl,NezahualcÃ³yotl,Rancheria Netzahualcoyotl,RancherÃ­a NetzahualcÃ³yotl,Ciudad NezahualcÃ³yotl", :latitude => "19.41361", :longitude => "-99.03306").save
City.new(:country_id => "159", :name => "Ciudad Miguel Aleman", :aliases => "Ciudad Aleman,Ciudad AlemÃ¡n,Ciudad Miguel Aleman,Ciudad Miguel AlemÃ¡n,Miguel Aleman,Miguel AlemÃ¡n,Ciudad Miguel AlemÃ¡n", :latitude => "26.35", :longitude => "-99.1").save
City.new(:country_id => "159", :name => "Ciudad Mendoza", :aliases => "Camerino Z. Mendoza,Ciudad Mendoza,S'judad-Mendosa,Santa Rosa,Ð¡ÑÑÐ´Ð°Ð´-ÐÐµÐ½Ð´Ð¾ÑÐ°,Ciudad Mendoza", :latitude => "18.8", :longitude => "-97.18333").save
City.new(:country_id => "159", :name => "Ciudad Madero", :aliases => "Cd Madero,Cd. Madero,Ciudad Madero,S'judad-Madero,Villa de Cecilia,Ð¡ÑÑÐ´Ð°Ð´-ÐÐ°Ð´ÐµÑÐ¾,Ciudad Madero", :latitude => "22.26667", :longitude => "-97.83333").save
City.new(:country_id => "159", :name => "Ciudad Fernandez", :aliases => "Ciudad Fernandez,Ciudad FernÃ¡ndez,Fernandez,FernÃ¡ndez,S'judad-Fernandes,Ð¡ÑÑÐ´Ð°Ð´-Ð¤ÐµÑÐ½Ð°Ð½Ð´ÐµÑ,Ciudad FernÃ¡ndez", :latitude => "21.95", :longitude => "-100").save
City.new(:country_id => "159", :name => "Mexico City", :aliases => "Cidade de Mexico,Cidade de MÃ©xico,Cidade do Mexico,Cidade do MÃ©xico,Cita du Messicu,Citta del Messico,CittÃ  del Messico,CitÃ  dÃ» Messicu,CitÃ  dÃ» MÃ¨ssicu,Ciudad Mexico,Ciudad de Mejico,Ciudad de Mexico,Ciudad de MÃ©jico,Ciudad de MÃ©xico,Ciutat de Mexic,Ciutat de MÃ¨xic,Lungsod ng Mexico,Lungsod ng MÃ©xico,Mehiko,Mekhiko,Meksikas,Meksiko,Meksiko Siti,Meksikurbo,Meksyk,Mexico,Mexico City,Mexico D.F.,Mexico DF,Mexico Distrito Federal,Mexico by,Mexico-stad,Mexicopolis,Mexiko,Mexiko Hiria,Mexiko-Stadt,Mexikoborg,MexÃ­kÃ³borg,MÃ©xico,MÃ©xico Distrito Federal,Pole tou Mexikou,Valle de Mexico,Valle de MÃ©xico,mdynt mksykw,megsiko si,mekishikoshiti,meksiko siti,meksikositi,mkzykw,mkzykwsyty,mo xi ge cheng,mqsyqw syty,Î ÏÎ»Î· ÏÎ¿Ï ÎÎµÎ¾Î¹ÎºÎ¿Ï,ÐÐµÐºÑÐ¸ÐºÐ¾,ÐÐµÐºÑÐ¸ÐºÐ¾ Ð¡Ð¸ÑÐ¸,ÐÐµÑÐ¸ÐºÐ¾,ÐÐµÑÑÐºÐ¾,××§×¡××§× ×¡×××,ÙØ¯ÙÙØ© ÙÙØ³ÙÙÙ,ÙÚ©Ø²ÛÚ©Ù,ÙÚ©Ø²ÛÚ©ÙØ³ÛØªÛ,ÙÛÙØ³ÙÙØ§ Ø´ÛÚ¾ÙØ±Ù,à¤®à¥à¤à¥à¤¸à¤¿à¤à¥ à¤¸à¤¿à¤à¥,à¹à¸¡à¹à¸à¸à¸´à¹à¸à¸à¸´à¸à¸µ,ááá®ááá,ã¡ã­ã·ã³ã·ãã£,å¢¨è¥¿å¥å,ë©ìì½ ì,Mexico City", :latitude => "19.42847", :longitude => "-99.12766").save
City.new(:country_id => "159", :name => "Ciudad del Carmen", :aliases => "Carmen,Cd Carmen,Cd del Carmen,Cd. Carmen,Cd. del Carmen,Ciudad del Carmen,S'judad-del'-Karmen,Ð¡ÑÑÐ´Ð°Ð´-Ð´ÐµÐ»Ñ-ÐÐ°ÑÐ¼ÐµÐ½,Ciudad del Carmen", :latitude => "18.63333", :longitude => "-91.83333").save
City.new(:country_id => "159", :name => "Cintalapa de Figueroa", :aliases => "Cintalapa,Cintalapa de Figueroa,Cintalapa de Figueroa", :latitude => "16.73333", :longitude => "-93.71667").save
City.new(:country_id => "159", :name => "Cholula", :aliases => "Cholula,Cholula de Riva dabia,San Pedro Cholula,Ð§Ð¾Ð»ÑÐ»Ð°,Cholula", :latitude => "19.06406", :longitude => "-98.30352").save
City.new(:country_id => "159", :name => "Chilpancingo de los Bravos", :aliases => "Chilpancingo,Chilpancingo de los Bravo,Chilpancingo de los Bravos,Ciudad Bravos,Chilpancingo de los Bravos", :latitude => "17.55", :longitude => "-99.5").save
City.new(:country_id => "159", :name => "Chilapa de Alvarez", :aliases => "Chilapa,Chilapa de Alvarez,Chilapa de Alvarez", :latitude => "17.6", :longitude => "-99.16667").save
City.new(:country_id => "159", :name => "Chignahuapan", :aliases => ",Chignahuapan", :latitude => "19.83333", :longitude => "-98.03333").save
City.new(:country_id => "159", :name => "Chiconcuac", :aliases => "Chiconcuac,Chiconcuac de Juarez,Chiconcuac de JuÃ¡rez,San Miguel Chiconcuac,Suarez,SuÃ¡rez,Chiconcuac", :latitude => "19.55", :longitude => "-98.9").save
City.new(:country_id => "159", :name => "Chicoloapan de Juarez", :aliases => "Chicoloapan,Chicoloapan de Juarez,Chicoloapan de JuÃ¡rez,San Vicente Chicoloapan,San Vicente Chiloloapan,Chicoloapan de JuÃ¡rez", :latitude => "19.41667", :longitude => "-98.9").save
City.new(:country_id => "159", :name => "Chichen-Itza", :aliases => "Chichen Itza,Chichen-Ica,Chichen-Itza,ChichÃ©n-ItzÃ¡,Ð§Ð¸ÑÐµÐ½-ÐÑÐ°,ChichÃ©n-ItzÃ¡", :latitude => "20.66667", :longitude => "-88.56667").save
City.new(:country_id => "159", :name => "Chiapa de Corzo", :aliases => "Chiapa,Chiapa de Corza,Chiapa de Corzo,Chiapas,Chiapa de Corzo", :latitude => "16.7", :longitude => "-93").save
City.new(:country_id => "159", :name => "Chetumal", :aliases => "Chetumal,Chetumal',Ciudad Chetumal,Payo Obispo,cheto~umaru,Ð§ÐµÑÑÐ¼Ð°Ð»Ñ,ãã§ãã¥ãã«,Chetumal", :latitude => "18.5", :longitude => "-88.3").save
City.new(:country_id => "159", :name => "Champoton", :aliases => "Champoton,ChampotÃ³n,Ð§Ð°Ð¼Ð¿Ð¾ÑÐ¾Ð½,ChampotÃ³n", :latitude => "19.35", :longitude => "-90.71667").save
City.new(:country_id => "159", :name => "Chalco de Diaz Covarrubias", :aliases => "Chalco,Chalco de Diaz Covarrubias,Chalco de DÃ­az Covarrubias,Chalco de DÃ­az Covarrubias", :latitude => "19.26667", :longitude => "-98.9").save
City.new(:country_id => "159", :name => "Cerro Azul", :aliases => ",Cerro Azul", :latitude => "21.2", :longitude => "-97.73333").save
City.new(:country_id => "159", :name => "Catemaco", :aliases => "Catemaco,Catemaco", :latitude => "18.41667", :longitude => "-95.11667").save
City.new(:country_id => "159", :name => "Carlos A. Carrillo", :aliases => "Carlos A. Carrillo,San Cristobal,San CristÃ³bal,Carlos A. Carrillo", :latitude => "18.36667", :longitude => "-95.75").save
City.new(:country_id => "159", :name => "Cardenas", :aliases => "Cardenas,CÃ¡rdenas,Kardenas,ÐÐ°ÑÐ´ÐµÐ½Ð°Ñ,CÃ¡rdenas", :latitude => "22", :longitude => "-99.66667").save
City.new(:country_id => "159", :name => "Cardenas", :aliases => "Cardenas,CÃ¡rdenas,Kardenas,ÐÐ°ÑÐ´ÐµÐ½Ð°Ñ,CÃ¡rdenas", :latitude => "17.98333", :longitude => "-93.36667").save
City.new(:country_id => "159", :name => "Capulhuac", :aliases => "Capulhuac,Capulhuac de Mirafuentes,Mirafuentes,Capulhuac", :latitude => "19.19139", :longitude => "-99.46694").save
City.new(:country_id => "159", :name => "Cancun", :aliases => "Cancun,CancÃºn,Ciudad Cancun,Ciudad CancÃºn,Kankun,Kankunas,kan kun,kankun,ÐÐ°Ð½ÐºÑÐ½,ã«ã³ã¯ã³,åæ,CancÃºn", :latitude => "21.17429", :longitude => "-86.84656").save
City.new(:country_id => "159", :name => "Campeche", :aliases => "Campeche,Kampeche,ÐÐ°Ð¼Ð¿ÐµÑÐµ,Campeche", :latitude => "19.85", :longitude => "-90.53333").save
City.new(:country_id => "159", :name => "Calpulalpan", :aliases => "Calpulalpam,Calpulalpan,Calpulapam,CalpulÃ¡pam,Kal'pulal'pane,San Antonio Calpulapam,San Antonio CalpulÃ¡pam,ÐÐ°Ð»ÑÐ¿ÑÐ»Ð°Ð»ÑÐ¿Ð°Ð½Ðµ,Calpulalpan", :latitude => "19.58333", :longitude => "-98.58333").save
City.new(:country_id => "159", :name => "Cadereyta", :aliases => ",Cadereyta", :latitude => "25.58333", :longitude => "-99.98333").save
City.new(:country_id => "159", :name => "Berriozabal", :aliases => "Berriozaba,Berriozabal,BerriozÃ¡bal,BerriozÃ¡bal", :latitude => "16.8", :longitude => "-93.26667").save
City.new(:country_id => "159", :name => "Banderilla", :aliases => ",Banderilla", :latitude => "19.58333", :longitude => "-96.93333").save
City.new(:country_id => "159", :name => "Azcapotzalco", :aliases => "Atzapotzalco,Atzcapotzalco,Azcapotzalco,Azcapotzalco", :latitude => "19.48889", :longitude => "-99.18361").save
City.new(:country_id => "159", :name => "Axochiapan", :aliases => "Axochiapan,Axochiapan", :latitude => "18.5", :longitude => "-98.76667").save
City.new(:country_id => "159", :name => "Atlixco", :aliases => "Atliksko,Atlixco,ÐÑÐ»Ð¸ÐºÑÐºÐ¾,Atlixco", :latitude => "18.90815", :longitude => "-98.43613").save
City.new(:country_id => "159", :name => "Atlacomulco", :aliases => "Atlacomulco,Atlacomulco de Fabela,Atlakomul'ko,ÐÑÐ»Ð°ÐºÐ¾Ð¼ÑÐ»ÑÐºÐ¾,Atlacomulco", :latitude => "19.79889", :longitude => "-99.87444").save
City.new(:country_id => "159", :name => "Ciudad Lopez Mateos", :aliases => "Atizapan,Atizapan de Zaragoza,AtizapÃ¡n de Zaragoza,Ciudad Lopez Mateos,Ciudad LÃ³pez Mateos,Lopez Mateos,LÃ³pez Mateos,S'judad-Lopes-Mateus,Ð¡ÑÑÐ´Ð°Ð´-ÐÐ¾Ð¿ÐµÑ-ÐÐ°ÑÐµÑÑ,Ciudad LÃ³pez Mateos", :latitude => "19.55833", :longitude => "-99.26139").save
City.new(:country_id => "159", :name => "Apizaco", :aliases => ",Apizaco", :latitude => "19.41667", :longitude => "-98.15").save
City.new(:country_id => "159", :name => "Apan", :aliases => "Apam,Apan,Apan", :latitude => "19.71667", :longitude => "-98.41667").save
City.new(:country_id => "159", :name => "Amozoc de Mota", :aliases => "Amozoc,Amozoc de Mota,Amozoc de Mota", :latitude => "19.03333", :longitude => "-98.05").save
City.new(:country_id => "159", :name => "Amecameca de Juarez", :aliases => "Amecameca,Amecameca de Juarez,Amecameca de JuÃ¡rez,Amecameca de JuÃ¡rez", :latitude => "19.11667", :longitude => "-98.76667").save
City.new(:country_id => "159", :name => "Alvarado", :aliases => "Al'varado,Alvarado,Heroica Alvarado,ÐÐ»ÑÐ²Ð°ÑÐ°Ð´Ð¾,Alvarado", :latitude => "18.76667", :longitude => "-95.76667").save
City.new(:country_id => "159", :name => "Altotonga", :aliases => ",Altotonga", :latitude => "19.76667", :longitude => "-97.23333").save
City.new(:country_id => "159", :name => "Altepexi", :aliases => ",Altepexi", :latitude => "18.35", :longitude => "-97.31667").save
City.new(:country_id => "159", :name => "Altamira", :aliases => "Al'tamira,Altamira,ÐÐ»ÑÑÐ°Ð¼Ð¸ÑÐ°,Altamira", :latitude => "22.4", :longitude => "-97.91667").save
City.new(:country_id => "159", :name => "Allende", :aliases => ",Allende", :latitude => "18.15", :longitude => "-94.4").save
City.new(:country_id => "159", :name => "Alamo", :aliases => ",Ãlamo", :latitude => "20.91667", :longitude => "-97.68333").save
City.new(:country_id => "159", :name => "Ajalpan", :aliases => ",Ajalpan", :latitude => "18.36667", :longitude => "-97.25").save
City.new(:country_id => "159", :name => "Agua Dulce", :aliases => ",Agua Dulce", :latitude => "18.13333", :longitude => "-94.13333").save
City.new(:country_id => "159", :name => "Actopan", :aliases => "Actopan,Actopan", :latitude => "20.26667", :longitude => "-98.93333").save
City.new(:country_id => "159", :name => "Acayucan", :aliases => "Acayucan,Acayucan", :latitude => "17.95", :longitude => "-94.91667").save
City.new(:country_id => "159", :name => "Acatzingo de Hidalgo", :aliases => "Acatzingo,Acatzingo de Hidalgo,Acatzingo de Hidalgo", :latitude => "18.98333", :longitude => "-97.78333").save
City.new(:country_id => "159", :name => "Acatlan de Osorio", :aliases => "Acatlan,Acatlan de Osorio,AcatlÃ¡n,AcatlÃ¡n de Osorio,AcatlÃ¡n de Osorio", :latitude => "18.2", :longitude => "-98.05").save
City.new(:country_id => "159", :name => "Acapulco de Juarez", :aliases => "Acapulco,Acapulco de Juarez,Acapulco de JuÃ¡rez,Akapul'ko,Akapulko,a ka pu er ke,akapulko,akapuruko,ÐÐºÐ°Ð¿ÑÐ»ÐºÐ¾,ÐÐºÐ°Ð¿ÑÐ»ÑÐºÐ¾,ã¢ã«ãã«ã³,é¿å¡æ®å°ç§,ìì¹´íì½,Acapulco de JuÃ¡rez", :latitude => "16.86336", :longitude => "-99.8901").save
City.new(:country_id => "159", :name => "Acajete", :aliases => ",Acajete", :latitude => "19.1", :longitude => "-97.95").save
City.new(:country_id => "159", :name => "San Antonio de la Cal", :aliases => ",San Antonio de la Cal", :latitude => "17.03083", :longitude => "-96.6975").save
City.new(:country_id => "159", :name => "Hidalgo", :aliases => "Hidalgo,Hidalgo", :latitude => "25.8425", :longitude => "-99.61611").save
City.new(:country_id => "159", :name => "Rio de Teapa", :aliases => "Rio de Teapa,RÃ­o de Teapa,RÃ­o de Teapa", :latitude => "17.7875", :longitude => "-92.89583").save
City.new(:country_id => "159", :name => "Huamantla", :aliases => "Heroica Huamantla,Huamantla,Huamantla de Juarez,Huamantla de JuÃ¡rez,San Luis,Uamantla,Ð£Ð°Ð¼Ð°Ð½ÑÐ»Ð°,Huamantla", :latitude => "19.31528", :longitude => "-97.925").save
City.new(:country_id => "159", :name => "Zacatelco", :aliases => "Santa Ines Zacatelco,Santa InÃ©s Zacatelco,Zacatelco,Zacatelco", :latitude => "19.21528", :longitude => "-98.23889").save
City.new(:country_id => "159", :name => "Tlaxcala", :aliases => "Tlaskala,Tlaxcala,Tlaxcala de Xicohtencatl,Tlaxcala de XicohtÃ©ncatl,Tlaxcala de Xicotencatl,Tlaxcala de XicotÃ©ncatl,Ð¢Ð»Ð°ÑÐºÐ°Ð»Ð°,Tlaxcala", :latitude => "19.31389", :longitude => "-98.24167").save
City.new(:country_id => "159", :name => "Papalotla", :aliases => "Papalotla,San Fransico Papalotla,Papalotla", :latitude => "19.1625", :longitude => "-98.20417").save
City.new(:country_id => "159", :name => "Vicente Guerrero", :aliases => "San Pablo del Monte,Vicente Guerrero,Villa Vicente Guerrero,Vicente Guerrero", :latitude => "19.11944", :longitude => "-98.17083").save
City.new(:country_id => "159", :name => "Tonala", :aliases => ",TonalÃ¡", :latitude => "16.08333", :longitude => "-93.75").save
City.new(:country_id => "159", :name => "Arriaga", :aliases => ",Arriaga", :latitude => "16.23333", :longitude => "-93.9").save
City.new(:country_id => "159", :name => "San Mateo Otzacatipan", :aliases => ",San Mateo Otzacatipan", :latitude => "19.32722", :longitude => "-99.60667").save
City.new(:country_id => "159", :name => "San Maria Totoltepec", :aliases => ",San MarÃ­a Totoltepec", :latitude => "19.305", :longitude => "-99.5925").save
City.new(:country_id => "159", :name => "Benito Juarez", :aliases => ",Benito Juarez", :latitude => "19.385", :longitude => "-99.165").save
City.new(:country_id => "159", :name => "Venustiano Carranza", :aliases => "Venustiano Carranza,Venustiano Carranza", :latitude => "19.43", :longitude => "-99.09917").save
City.new(:country_id => "159", :name => "Miguel Hidalgo", :aliases => ",Miguel Hidalgo", :latitude => "19.4225", :longitude => "-99.20278").save
City.new(:country_id => "159", :name => "Cuauhtemoc", :aliases => ",CuauhtÃ©moc", :latitude => "19.41722", :longitude => "-99.15694").save
City.new(:country_id => "159", :name => "Huixquilucan", :aliases => ",Huixquilucan", :latitude => "19.36028", :longitude => "-99.35139").save
City.new(:country_id => "159", :name => "Melchor Ocampo", :aliases => ",Melchor Ocampo", :latitude => "19.69972", :longitude => "-99.1475").save
City.new(:country_id => "159", :name => "Huilango", :aliases => ",Huilango", :latitude => "19.68694", :longitude => "-99.25").save
City.new(:country_id => "159", :name => "Santiago Teyahualco", :aliases => "Santiago Atocan,Santiago Teyahualco,Santiago Teyahualco", :latitude => "19.65889", :longitude => "-99.12694").save
City.new(:country_id => "159", :name => "Gabriel Leyva Solano", :aliases => ",Gabriel Leyva Solano", :latitude => "25.66667", :longitude => "-108.64167").save
City.new(:country_id => "159", :name => "Cihuatlan", :aliases => ",CihuatlÃ¡n", :latitude => "19.2366", :longitude => "-104.56512").save
City.new(:country_id => "159", :name => "Guadalupe Victoria", :aliases => ",Guadalupe Victoria", :latitude => "32.28694", :longitude => "-115.105").save
City.new(:country_id => "159", :name => "Zihuatanejo", :aliases => "Ixtapa Zihuatanejo,Zihuatanejo,Zihuatanejo", :latitude => "17.63333", :longitude => "-101.55").save
City.new(:country_id => "159", :name => "Zapotlanejo", :aliases => ",Zapotlanejo", :latitude => "20.63333", :longitude => "-103.06667").save
City.new(:country_id => "159", :name => "Zapotiltic", :aliases => ",Zapotiltic", :latitude => "19.61667", :longitude => "-103.43333").save
City.new(:country_id => "159", :name => "Zapopan", :aliases => "Zapopan,Zapopan", :latitude => "20.71667", :longitude => "-103.4").save
City.new(:country_id => "159", :name => "Zamora de Hidalgo", :aliases => "Samora-de-Idal'go,Zamora,Zamora de Hidalgo,Ð¡Ð°Ð¼Ð¾ÑÐ°-Ð´Ðµ-ÐÐ´Ð°Ð»ÑÐ³Ð¾,Zamora de Hidalgo", :latitude => "19.98333", :longitude => "-102.26667").save
City.new(:country_id => "159", :name => "Zacoalco de Torres", :aliases => "Zacoalco,Zacoalco de Torre,Zacoalco de Torres,Zacoalco de Torres", :latitude => "20.23333", :longitude => "-103.58333").save
City.new(:country_id => "159", :name => "Zacatecas", :aliases => "Sakatekas,Zacatecas,sakatekasu,Ð¡Ð°ÐºÐ°ÑÐµÐºÐ°Ñ,ãµã«ãã«ã¹,Zacatecas", :latitude => "22.77559", :longitude => "-102.57218").save
City.new(:country_id => "159", :name => "Zacapu", :aliases => "Sakapu,Zacapu,Zacapu de Mier,ZacapÃº,ZacapÃº de Mier,Ð¡Ð°ÐºÐ°Ð¿Ñ,ZacapÃº", :latitude => "19.83333", :longitude => "-101.71667").save
City.new(:country_id => "159", :name => "Yuriria", :aliases => "Villa Yuriria,Yuriria,Yuriria", :latitude => "20.2", :longitude => "-101.15").save
City.new(:country_id => "159", :name => "Yurecuaro", :aliases => ",YurÃ©cuaro", :latitude => "20.33333", :longitude => "-102.3").save
City.new(:country_id => "159", :name => "Villagran", :aliases => "El Guaje,Vil'jagran,Villagran,VillagrÃ¡n,ÐÐ¸Ð»ÑÑÐ³ÑÐ°Ð½,VillagrÃ¡n", :latitude => "20.51667", :longitude => "-100.98333").save
City.new(:country_id => "159", :name => "Villa Frontera", :aliases => "Frontera,Villa Frontera,Villa-Frontera,ÐÐ¸Ð»Ð»Ð°-Ð¤ÑÐ¾Ð½ÑÐµÑÐ°,Villa Frontera", :latitude => "26.93333", :longitude => "-101.45").save
City.new(:country_id => "159", :name => "Villa de Garcia", :aliases => "Garcia,Vil'ja-de-Garsia,Villa de Garcia,Villa de GarcÃ­a,ÐÐ¸Ð»ÑÑ-Ð´Ðµ-ÐÐ°ÑÑÐ¸Ð°,Villa de GarcÃ­a", :latitude => "25.81667", :longitude => "-100.58333").save
City.new(:country_id => "159", :name => "Villa de Alvarez", :aliases => "Vil'ja-de-Al'vares,Villa de Alvarez,ÐÐ¸Ð»ÑÑ-Ð´Ðµ-ÐÐ»ÑÐ²Ð°ÑÐµÑ,Villa de Alvarez", :latitude => "19.25", :longitude => "-103.73333").save
City.new(:country_id => "159", :name => "Valle de Santiago", :aliases => "Ciudad Valle de Santiago,Val'e-de-Sant'jago,Valle de Santiago,ÐÐ°Ð»ÑÐµ-Ð´Ðµ-Ð¡Ð°Ð½ÑÑÑÐ³Ð¾,Valle de Santiago", :latitude => "20.38333", :longitude => "-101.2").save
City.new(:country_id => "159", :name => "Valle de Bravo", :aliases => "Val'e-de-Bravo,Valle de Bravo,ÐÐ°Ð»ÑÐµ-Ð´Ðµ-ÐÑÐ°Ð²Ð¾,Valle de Bravo", :latitude => "19.18333", :longitude => "-100.13333").save
City.new(:country_id => "159", :name => "Uruapan del Progreso", :aliases => "Uruapan,Uruapan del Progreso,Uruapan del Progreso", :latitude => "19.41667", :longitude => "-102.06667").save
City.new(:country_id => "159", :name => "Uriangato", :aliases => "Puriangato,Uriangato,Uriangato", :latitude => "20.15", :longitude => "-101.18333").save
City.new(:country_id => "159", :name => "Tuxpan", :aliases => ",Tuxpan", :latitude => "19.55", :longitude => "-103.4").save
City.new(:country_id => "159", :name => "Torreon", :aliases => "Torreon,TorreÃ³n,toreon,Ð¢Ð¾ÑÑÐµÐ¾Ð½,ãã¬ãªã³,TorreÃ³n", :latitude => "25.55", :longitude => "-103.43333").save
City.new(:country_id => "159", :name => "Tonala", :aliases => "Tonala,TonalÃ¡,Ð¢Ð¾Ð½Ð°Ð»Ð°,TonalÃ¡", :latitude => "20.61667", :longitude => "-103.23333").save
City.new(:country_id => "159", :name => "Tlaquepaque", :aliases => "San Pedro Tlaquepaque,Tlaquepaque,Tlaquepaque", :latitude => "20.65", :longitude => "-103.31667").save
City.new(:country_id => "159", :name => "Tlajomulco de Zuniga", :aliases => "Tlajomulco,Tlajomulco de Zuniga,Tlajomulco de ZÃºÃ±iga,Tlajomulco de ZÃºÃ±iga", :latitude => "20.46667", :longitude => "-103.45").save
City.new(:country_id => "159", :name => "Tijuana", :aliases => "Tia Juana,Tihuana,Tijuana,Tikhuana,TÃ­jÃºana,Zaragoza,tifuana,tihuana,Ð¢Ð¸ÑÑÐ°Ð½Ð°,Ð¢ÑÑÑÐ°Ð½Ð°,ãã£ãã¢ã,í°íìë,Tijuana", :latitude => "32.53333", :longitude => "-117.01667").save
City.new(:country_id => "159", :name => "Tesistan", :aliases => ",TesistÃ¡n", :latitude => "20.78333", :longitude => "-103.48333").save
City.new(:country_id => "159", :name => "Tequila", :aliases => "Santiago de Tequila,Tekila,Tequila,Ð¢ÐµÐºÐ¸Ð»Ð°,Tequila", :latitude => "20.88333", :longitude => "-103.83333").save
City.new(:country_id => "159", :name => "Tepic", :aliases => "Nayarit,TEPEIC,Tepic,tepiku,ããã¯,Tepic", :latitude => "21.5", :longitude => "-104.9").save
City.new(:country_id => "159", :name => "Tepatitlan de Morelos", :aliases => "Tepatitlan,Tepatitlan de Morelos,TepatitlÃ¡n de Morelos,TepatitlÃ¡n de Morelos", :latitude => "20.81667", :longitude => "-102.73333").save
City.new(:country_id => "159", :name => "Tepalcatepec", :aliases => "Tepalcatepec,Tepalcatepec", :latitude => "19.18333", :longitude => "-102.85").save
City.new(:country_id => "159", :name => "Teocaltiche", :aliases => ",Teocaltiche", :latitude => "21.43333", :longitude => "-102.58333").save
City.new(:country_id => "159", :name => "Tejupilco de Hidalgo", :aliases => "Teiupilco,Tejupilco,Tejupilco de Hidalgo,Tejupilco de Hidalgo", :latitude => "18.9", :longitude => "-100.15").save
City.new(:country_id => "159", :name => "Tecoman", :aliases => "Tecoman,TecomÃ¡n,Tekomane,Ð¢ÐµÐºÐ¾Ð¼Ð°Ð½Ðµ,TecomÃ¡n", :latitude => "18.91667", :longitude => "-103.88333").save
City.new(:country_id => "159", :name => "Tecate", :aliases => "Tecate,Tecate", :latitude => "32.56667", :longitude => "-116.63333").save
City.new(:country_id => "159", :name => "Tangancicuaro de Arista", :aliases => "Tangacicuaro,TangacÃ­cuaro,Tangancicuaro,Tangancicuaro de Arista,TangancÃ­cuaro de Arista,TangancÃ­cuaro de Arista", :latitude => "19.9", :longitude => "-102.13333").save
City.new(:country_id => "159", :name => "Tamazula de Gordiano", :aliases => "Tamazula de Gordiano,Tamazula de Gordiano", :latitude => "19.63333", :longitude => "-103.25").save
City.new(:country_id => "159", :name => "Tala", :aliases => ",Tala", :latitude => "20.66667", :longitude => "-103.7").save
City.new(:country_id => "159", :name => "Tacambaro de Codallos", :aliases => "Tacambaro,Tacambaro de Codallos,Tacambaro de Collados,TacÃ¡mbaro de Codallos,TacÃ¡mbaro de Collados,TacÃ¡mbaro de Codallos", :latitude => "19.23333", :longitude => "-101.46667").save
City.new(:country_id => "159", :name => "Sombrerete", :aliases => "Sombrerete,Sombrerete", :latitude => "23.63333", :longitude => "-103.65").save
City.new(:country_id => "159", :name => "Soledad Diez Gutierrez", :aliases => "Diaz Gutierrez,Diez Gutierrez,Diez GutiÃ©rrez,DÃ­az GutiÃ©rrez,Soledad Diaz Gutierrez,Soledad Diez Gutierrez,Soledad DÃ­az GutiÃ©rrez,Soledad DÃ­ez GutiÃ©rrez,Soledad de Diez Gutierrez,Soledad de DÃ­ez GutiÃ©rrez,Soledad DÃ­ez GutiÃ©rrez", :latitude => "22.2", :longitude => "-100.95").save
City.new(:country_id => "159", :name => "Silao", :aliases => ",Silao", :latitude => "20.93333", :longitude => "-101.43333").save
City.new(:country_id => "159", :name => "Sayula", :aliases => ",Sayula", :latitude => "19.86667", :longitude => "-103.61667").save
City.new(:country_id => "159", :name => "Santiago Ixcuintla", :aliases => "Santiago,Santiago Ixcuintla,Santiago Ixcuintla", :latitude => "21.81667", :longitude => "-105.21667").save
City.new(:country_id => "159", :name => "Santiago", :aliases => "Sant'jago,Santiago,Villa de Santiago,Ð¡Ð°Ð½ÑÑÑÐ³Ð¾,Santiago", :latitude => "25.41667", :longitude => "-100.15").save
City.new(:country_id => "159", :name => "Santa Rosa de Jauregui", :aliases => "Santa Rosa,Santa Rosa Jauregui,Santa Rosa JÃ¡uregui,Santa Rosa de Jauregui,Santa Rosa de JÃ¡uregui,Santa Rosa de JÃ¡uregui", :latitude => "20.73333", :longitude => "-100.45").save
City.new(:country_id => "159", :name => "Santa Isabel", :aliases => ",Santa Isabel", :latitude => "28.38333", :longitude => "-113.35").save
City.new(:country_id => "159", :name => "Santa Catarina", :aliases => ",Santa Catarina", :latitude => "25.67325", :longitude => "-100.45813").save
City.new(:country_id => "159", :name => "San Sebastian el Grande", :aliases => ",San SebastiÃ¡n el Grande", :latitude => "20.51667", :longitude => "-103.41667").save
City.new(:country_id => "159", :name => "San Pedro", :aliases => ",San Pedro", :latitude => "25.43333", :longitude => "-103.21667").save
City.new(:country_id => "159", :name => "San Nicolas de los Garza", :aliases => "San Nicolas de los Garsas,San Nicolas de los Garza,San Nicolas de los Garzas,San NicolÃ¡s de los Garsas,San NicolÃ¡s de los Garza,San NicolÃ¡s de los Garzas,San NicolÃ¡s de los Garza", :latitude => "25.75", :longitude => "-100.3").save
City.new(:country_id => "159", :name => "San Miguel el Alto", :aliases => "San Miguel,San Miguel el Alto,San Miguel el Alto", :latitude => "21.01667", :longitude => "-102.35").save
City.new(:country_id => "159", :name => "San Miguel de Papasquiaro", :aliases => "Papasquiaro,San Miguel Papasquiaro,San Miguel de Papasquiaro,Santiago Papasquiaro,San Miguel de Papasquiaro", :latitude => "24.8325", :longitude => "-105.33639").save
City.new(:country_id => "159", :name => "San Miguel de Allende", :aliases => "San Miguel Allende,San Miguel de Allende,San Miguel de Allende", :latitude => "20.91667", :longitude => "-100.75").save
City.new(:country_id => "159", :name => "San Luis Rio Colorado", :aliases => "San Luis,San Luis Rio Colorado,San Luis RÃ­o Colorado,San Luis RÃ­o Colorado", :latitude => "32.46306", :longitude => "-114.77667").save
City.new(:country_id => "159", :name => "San Luis Potosi", :aliases => "San Luis,San Luis Potosi,San Luis PotosÃ­,San Luis PotosÃ­", :latitude => "22.15", :longitude => "-100.98333").save
City.new(:country_id => "159", :name => "San Luis de la Paz", :aliases => ",San Luis de la Paz", :latitude => "21.3", :longitude => "-100.51667").save
City.new(:country_id => "159", :name => "San Luis de la Paz", :aliases => "San Luis de la Paz,San Luis de la Paz", :latitude => "21.3", :longitude => "-100.51667").save
City.new(:country_id => "159", :name => "Cabo San Lucas", :aliases => "Cabo San Lucas,Kabo-San-Lukas,San Lucas,ÐÐ°Ð±Ð¾-Ð¡Ð°Ð½-ÐÑÐºÐ°Ñ,Cabo San Lucas", :latitude => "22.89088", :longitude => "-109.91238").save
City.new(:country_id => "159", :name => "San Juan de los Lagos", :aliases => ",San Juan de los Lagos", :latitude => "21.25", :longitude => "-102.3").save
City.new(:country_id => "159", :name => "San Jose Iturbide", :aliases => "Alvaro Obregon,Iturbide,San Jose Iturbide,San Jose de Iturbide,San JosÃ© Iturbide,San JosÃ© Iturbide", :latitude => "21", :longitude => "-100.38333").save
City.new(:country_id => "159", :name => "San Jose del Cabo", :aliases => "San-Khose-del'-Kabo,Ð¡Ð°Ð½-Ð¥Ð¾ÑÐµ-Ð´ÐµÐ»Ñ-ÐÐ°Ð±Ð¾,San JosÃ© del Cabo", :latitude => "23.05888", :longitude => "-109.69771").save
City.new(:country_id => "159", :name => "San Francisco del Rincon", :aliases => "San Francisco del Rincon,San Francisco del RincÃ³n,San Francisco del RincÃ³n", :latitude => "21.01667", :longitude => "-101.85").save
City.new(:country_id => "159", :name => "San Felipe", :aliases => ",San Felipe", :latitude => "31", :longitude => "-114.86667").save
City.new(:country_id => "159", :name => "San Felipe", :aliases => "Ciudad Doctor Hernandez Alvarez,Ciudad Doctor HernÃ¡ndez Alvarez,Ciudad Gonzales,Doctor Hernandez Alvarez,Gonzales,San Felipe,San Felipe", :latitude => "21.48333", :longitude => "-101.21667").save
City.new(:country_id => "159", :name => "San Buenaventura", :aliases => "San Buenaventura,San Buenaventura", :latitude => "27.08333", :longitude => "-101.53333").save
City.new(:country_id => "159", :name => "San Agustin", :aliases => ",San AgustÃ­n", :latitude => "20.53333", :longitude => "-103.46667").save
City.new(:country_id => "159", :name => "Salvatierra", :aliases => "Ciudad Salvatierra,Sal'vat'erra,Salvatiera,Salvatierra,Ð¡Ð°Ð»ÑÐ²Ð°ÑÑÐµÑÑÐ°,Salvatierra", :latitude => "20.21667", :longitude => "-100.88333").save
City.new(:country_id => "159", :name => "Saltillo", :aliases => "Saltillo,Ð¡Ð°Ð»ÑÐ¸Ð»Ð»Ð¾,Saltillo", :latitude => "25.41667", :longitude => "-101").save
City.new(:country_id => "159", :name => "Salamanca", :aliases => "Ciudad Salamanca,Salamanca,Salamanka,Ð¡Ð°Ð»Ð°Ð¼Ð°Ð½ÐºÐ°,Salamanca", :latitude => "20.56667", :longitude => "-101.2").save
City.new(:country_id => "159", :name => "Sahuayo de Jose Maria Morelos", :aliases => "Sahuayo,Sahuayo de Diaz,Sahuayo de DÃ­az,Sahuayo de Jose Maria Morelos,Sahuayo de JosÃ© MarÃ­a Morelos,Sahuayo de Morelos,Sahuayo de Porfirio Diaz,Sahuayo de Porfirio DÃ­az,Sahuayo de JosÃ© MarÃ­a Morelos", :latitude => "20.06667", :longitude => "-102.71667").save
City.new(:country_id => "159", :name => "Sabinas Hidalgo", :aliases => "Sabinas Hidalgo,Sabinas Hidalgo", :latitude => "26.5", :longitude => "-100.16667").save
City.new(:country_id => "159", :name => "Sabinas", :aliases => ",Sabinas", :latitude => "27.85", :longitude => "-101.11667").save
City.new(:country_id => "159", :name => "Rosarito", :aliases => "Ejido Mazatlan El Rosarito,Rosario,Rosarito,Rosarito Beach Baja,Ð Ð¾ÑÐ°ÑÐ¸ÑÐ¾,Rosarito", :latitude => "32.33333", :longitude => "-117.03333").save
City.new(:country_id => "159", :name => "Romita", :aliases => ",Romita", :latitude => "20.86667", :longitude => "-101.51667").save
City.new(:country_id => "159", :name => "Rio Grande", :aliases => ",RÃ­o Grande", :latitude => "23.83333", :longitude => "-103.03333").save
City.new(:country_id => "159", :name => "Rincon de Romos", :aliases => "Rincon de Romos,RincÃ³n de Romos,Rinkon-de-Romos,Ð Ð¸Ð½ÐºÐ¾Ð½-Ð´Ðµ-Ð Ð¾Ð¼Ð¾Ñ,RincÃ³n de Romos", :latitude => "22.23333", :longitude => "-102.3").save
City.new(:country_id => "159", :name => "Ramos Arizpe", :aliases => "Arizpe,Ramos Arizpe,Ramos-Arispe,Ð Ð°Ð¼Ð¾Ñ-ÐÑÐ¸ÑÐ¿Ðµ,Ramos Arizpe", :latitude => "25.55", :longitude => "-100.96667").save
City.new(:country_id => "159", :name => "Queretaro", :aliases => "Ciudad Queretaro,Keretaro,Queretaro,QuerÃ©taro,ÐÐµÑÐµÑÐ°ÑÐ¾,QuerÃ©taro", :latitude => "20.6", :longitude => "-100.38333").save
City.new(:country_id => "159", :name => "Puruandiro", :aliases => "Ciudad Puruandiro,Puruandiro,Puruandiro de Calderon,PuruÃ¡ndiro,PuruÃ¡ndiro de CalderÃ³n,PuruÃ¡ndiro", :latitude => "20.08333", :longitude => "-101.5").save
City.new(:country_id => "159", :name => "Puerto Vallarta", :aliases => "Las Penas,Las PeÃ±as,Pto Vallarta,Puehrto-Val'jarta,Puerto Vallarta,ÐÑÑÑÑÐ¾-ÐÐ°Ð»ÑÑÑÑÐ°,Puerto Vallarta", :latitude => "20.62041", :longitude => "-105.23066").save
City.new(:country_id => "159", :name => "Puerto Penasco", :aliases => "Puerto Penasco,Puerto PeÃ±asco,Punta Penasca,Punta Penasco,Punta PeÃ±asco,Puerto PeÃ±asco", :latitude => "31.31667", :longitude => "-113.53333").save
City.new(:country_id => "159", :name => "Piedras Negras", :aliases => "Piedras Negras,Piedrasnegras,Piedras Negras", :latitude => "28.7", :longitude => "-100.51667").save
City.new(:country_id => "159", :name => "Petatlan", :aliases => "Petatlan,PetatlÃ¡n,Petlatlan,PetlatlÃ¡n,Potatlan,ÐÐµÑÐ°ÑÐ»Ð°Ð½,PetatlÃ¡n", :latitude => "17.51667", :longitude => "-101.26667").save
City.new(:country_id => "159", :name => "Penjamo", :aliases => "Panjamo,Penjamo,PÃ¡njamo,PÃ©njamo,PÃ©njamo", :latitude => "20.43333", :longitude => "-101.73333").save
City.new(:country_id => "159", :name => "Patzcuaro", :aliases => "Packuaro,Patzcuaro,PÃ¡tzcuaro,ÐÐ°ÑÐºÑÐ°ÑÐ¾,PÃ¡tzcuaro", :latitude => "19.51667", :longitude => "-101.6").save
City.new(:country_id => "159", :name => "Parras de la Fuente", :aliases => "Parras,Parras de la Fuente,ÐÐ°ÑÑÐ°Ñ,Parras de la Fuente", :latitude => "25.41667", :longitude => "-102.18333").save
City.new(:country_id => "159", :name => "Paracho de Verduzco", :aliases => "Paracho,Paracho de Verduzco,Paracho de Verduzco", :latitude => "19.65", :longitude => "-102.06667").save
City.new(:country_id => "159", :name => "Palau", :aliases => "Palahu,PalahÃº,Palau,Palau", :latitude => "27.91667", :longitude => "-101.41667").save
City.new(:country_id => "159", :name => "Ojinaga", :aliases => "Fuerte del Norte,Ojinaga,Presidio del Juntas,Presidio del Norte,Villa de Ojinaga,Ojinaga", :latitude => "29.56667", :longitude => "-104.41667").save
City.new(:country_id => "159", :name => "Ocotlan", :aliases => ",OcotlÃ¡n", :latitude => "20.35", :longitude => "-102.76667").save
City.new(:country_id => "159", :name => "Nuevo Mexico", :aliases => "Nuehvo-Meksiko,Nuevo Mexico,Nuevo MÃ©xico,ÐÑÑÐ²Ð¾-ÐÐµÐºÑÐ¸ÐºÐ¾,Nuevo MÃ©xico", :latitude => "20.75", :longitude => "-103.43333").save
City.new(:country_id => "159", :name => "Nuevo Casas Grandes", :aliases => "Nueva Casa Grande,Nueva Casas Grandes,Nuevo Casas Grandes,Nuevo Casas Grandes", :latitude => "30.41667", :longitude => "-107.91667").save
City.new(:country_id => "159", :name => "Nueva Rosita", :aliases => "Nuehva-Rosita,Nueva Rosita,Rosita,ÐÑÑÐ²Ð°-Ð Ð¾ÑÐ¸ÑÐ°,Nueva Rosita", :latitude => "27.95", :longitude => "-101.21667").save
City.new(:country_id => "159", :name => "Nueva Italia de Ruiz", :aliases => "Nueva Italia,Nueva Italia de Ruiz,Villa de Nueva Italia de Ruiz,Nueva Italia de Ruiz", :latitude => "19.01667", :longitude => "-102.1").save
City.new(:country_id => "159", :name => "Nochistlan", :aliases => ",NochistlÃ¡n", :latitude => "21.36667", :longitude => "-102.85").save
City.new(:country_id => "159", :name => "Navolato", :aliases => "Navolato,Navolato", :latitude => "24.76722", :longitude => "-107.69444").save
City.new(:country_id => "159", :name => "Nava", :aliases => ",Nava", :latitude => "28.41667", :longitude => "-100.76667").save
City.new(:country_id => "159", :name => "Moroleon", :aliases => "Moroleon,MoroleÃ³n,MoroleÃ³n", :latitude => "20.13333", :longitude => "-101.2").save
City.new(:country_id => "159", :name => "Morelia", :aliases => "Morelia,Morelija,mo lei li ya,ÐÐ¾ÑÐµÐ»Ð¸Ñ,è«é·å©äº,Morelia", :latitude => "19.70078", :longitude => "-101.18443").save
City.new(:country_id => "159", :name => "Monterrey", :aliases => "Monterejo,Monterrei,Monterrej,Monterrey,Monterrey City,Tlahtoantepec,TlahtoÄntepÄc,meng te rui,montere,ÐÐ¾Ð½ÑÐµÑÑÐµÐ¹,ã¢ã³ãã¬ã¼,èç¹ç,Monterrey", :latitude => "25.66667", :longitude => "-100.31667").save
City.new(:country_id => "159", :name => "Monclova", :aliases => "Monclova,Monclova", :latitude => "26.9", :longitude => "-101.41667").save
City.new(:country_id => "159", :name => "Mexicali", :aliases => "Mekhikali,Mexicali,ÐÐµÑÐ¸ÐºÐ°Ð»Ð¸,Mexicali", :latitude => "32.65194", :longitude => "-115.46833").save
City.new(:country_id => "159", :name => "Meoqui", :aliases => ",Meoqui", :latitude => "28.28333", :longitude => "-105.48333").save
City.new(:country_id => "159", :name => "Melchor Muzquiz", :aliases => "Melchor Muzquiz,Melchor MÃºzquiz,Mozquiz,Muzguiz,Muzquiz,Melchor MÃºzquiz", :latitude => "27.88333", :longitude => "-101.51667").save
City.new(:country_id => "159", :name => "Mazatlan", :aliases => "Ciudad Mazatlan,Ciudad MazatlÃ¡n,Masatlan,Mazatlan,Mazatlan, Sinaloa,MazatlÃ¡n,MazatlÃ¡n, Sinaloa,masatoran,ÐÐ°ÑÐ°ÑÐ»Ð°Ð½,ããµãã©ã³,MazatlÃ¡n", :latitude => "23.21667", :longitude => "-106.41667").save
City.new(:country_id => "159", :name => "Matehuala", :aliases => "Matehuala,Mateuala,ÐÐ°ÑÐµÑÐ°Ð»Ð°,Matehuala", :latitude => "23.65", :longitude => "-100.65").save
City.new(:country_id => "159", :name => "Matamoros", :aliases => "Matamoros,Matamoros de la Laguna,ÐÐ°ÑÐ°Ð¼Ð¾ÑÐ¾Ñ,Matamoros", :latitude => "25.53333", :longitude => "-103.25").save
City.new(:country_id => "159", :name => "Marfil", :aliases => ",Marfil", :latitude => "21", :longitude => "-101.28333").save
City.new(:country_id => "159", :name => "Maravatio", :aliases => ",MaravatÃ­o", :latitude => "19.9", :longitude => "-100.45").save
City.new(:country_id => "159", :name => "Manzanillo", :aliases => ",Manzanillo", :latitude => "19.05011", :longitude => "-104.31879").save
City.new(:country_id => "159", :name => "Maneadero", :aliases => ",Maneadero", :latitude => "31.71667", :longitude => "-116.56667").save
City.new(:country_id => "159", :name => "Magdalena de Kino", :aliases => "Magdalena,Magdalena de Kino,Magdalena-de-Kino,ÐÐ°Ð³Ð´Ð°Ð»ÐµÐ½Ð°-Ð´Ðµ-ÐÐ¸Ð½Ð¾,Magdalena de Kino", :latitude => "30.63333", :longitude => "-110.95").save
City.new(:country_id => "159", :name => "Madera", :aliases => ",Madera", :latitude => "29.2", :longitude => "-108.11667").save
City.new(:country_id => "159", :name => "Los Reyes", :aliases => ",Los Reyes", :latitude => "19.73333", :longitude => "-100.26667").save
City.new(:country_id => "159", :name => "Los Mochis", :aliases => "Los Mochis,Mochis,Los Mochis", :latitude => "25.76667", :longitude => "-108.96667").save
City.new(:country_id => "159", :name => "Loreto", :aliases => ",Loreto", :latitude => "22.26667", :longitude => "-101.96667").save
City.new(:country_id => "159", :name => "Leon", :aliases => "Ciudad de Leon,Ciudad de LeÃ³n,Leon,Leon Guanajuato,Leon de los Aldama,Leon de los Aldamas,LeÃ³n,LeÃ³n de los Aldama,LeÃ³n de los Aldamas,reon,ã¬ãªã³,LeÃ³n", :latitude => "21.11667", :longitude => "-101.66667").save
City.new(:country_id => "159", :name => "Las Pintas de Arriba", :aliases => ",Las Pintas de Arriba", :latitude => "20.56667", :longitude => "-103.31667").save
City.new(:country_id => "159", :name => "La Piedad Cavadas", :aliases => "La Piedad,La Piedad Cabadas,La Piedad Cavadas,La Piedad de Cabadas,Municipio La Piedad,La Piedad Cavadas", :latitude => "20.35", :longitude => "-102").save
City.new(:country_id => "159", :name => "La Paz", :aliases => "La Paz,La-Pas,ÐÐ°-ÐÐ°Ñ,La Paz", :latitude => "24.16667", :longitude => "-110.3").save
City.new(:country_id => "159", :name => "La Orilla", :aliases => ",La Orilla", :latitude => "17.98333", :longitude => "-102.23333").save
City.new(:country_id => "159", :name => "Lagos de Moreno", :aliases => "Lagos de Moreno,Lagos de Moreno", :latitude => "21.35", :longitude => "-101.91667").save
City.new(:country_id => "159", :name => "La Barca", :aliases => ",La Barca", :latitude => "20.28333", :longitude => "-102.56667").save
City.new(:country_id => "159", :name => "Juventino Rosas", :aliases => "Juventino Rosas,Villa Santa Cruz Galeana,Juventino Rosas", :latitude => "20.65", :longitude => "-101").save
City.new(:country_id => "159", :name => "Jocotepec", :aliases => ",Jocotepec", :latitude => "20.3", :longitude => "-103.43333").save
City.new(:country_id => "159", :name => "Jiquilpan de Juarez", :aliases => "Jilquilpan,Jiquilpan,Jiquilpan de Juarez,Jiquilpan de JuÃ¡rez,Jiquilpan de JuÃ¡rez", :latitude => "19.98333", :longitude => "-102.71667").save
City.new(:country_id => "159", :name => "Jimenez", :aliases => ",JimÃ©nez", :latitude => "28.33333", :longitude => "-105.4").save
City.new(:country_id => "159", :name => "Jerez de Garcia Salinas", :aliases => "Ciudad Garcia,Ciudad Garcia Salinas,Ciudad GarcÃ­a,Ciudad GarcÃ­a Salinas,Jerez,Jerez de Garcia Salinas,Jerez de GarcÃ­a Salinas,Kheres-de-Garsija-Salinas,Ð¥ÐµÑÐµÑ-Ð´Ðµ-ÐÐ°ÑÑÐ¸Ñ-Ð¡Ð°Ð»Ð¸Ð½Ð°Ñ,Jerez de GarcÃ­a Salinas", :latitude => "22.65", :longitude => "-103").save
City.new(:country_id => "159", :name => "Jaral del Progreso", :aliases => "Jaral,Jaral del Progreso,Pueblo Jaral del Progreso,Jaral del Progreso", :latitude => "20.36667", :longitude => "-101.06667").save
City.new(:country_id => "159", :name => "Jamay", :aliases => "Jamay,Jamay", :latitude => "20.3", :longitude => "-102.71667").save
City.new(:country_id => "159", :name => "Jalostotitlan", :aliases => "Jalostotilan,Jalostotitlan,JalostotitlÃ¡n,Khalostotitlan,Ð¥Ð°Ð»Ð¾ÑÑÐ¾ÑÐ¸ÑÐ»Ð°Ð½,JalostotitlÃ¡n", :latitude => "21.2", :longitude => "-102.46667").save
City.new(:country_id => "159", :name => "Ixtlan del Rio", :aliases => "Dei Rio Ixtlan,Ixtlan,Ixtlan del Rio,IxtlÃ¡n,IxtlÃ¡n del RÃ­o,IxtlÃ¡n del RÃ­o", :latitude => "21.03333", :longitude => "-104.36667").save
City.new(:country_id => "159", :name => "Ixtapa", :aliases => ",Ixtapa", :latitude => "20.7", :longitude => "-105.2").save
City.new(:country_id => "159", :name => "Irapuato", :aliases => "Irapuato,Iraputa,ÐÑÐ°Ð¿ÑÐ°ÑÐ¾,Irapuato", :latitude => "20.68333", :longitude => "-101.35").save
City.new(:country_id => "159", :name => "Huetamo de Nunez", :aliases => "Huetamo,Huetamo de Munez,Huetamo de MÃºÃ±ez,Huetamo de Nunez,Huetamo de NÃºÃ±ez,Huetamo de NÃºÃ±ez", :latitude => "18.58333", :longitude => "-100.88333").save
City.new(:country_id => "159", :name => "Huatabampo", :aliases => "Uatabampo,Ð£Ð°ÑÐ°Ð±Ð°Ð¼Ð¿Ð¾,Huatabampo", :latitude => "26.83333", :longitude => "-109.63333").save
City.new(:country_id => "159", :name => "Hidalgo del Parral", :aliases => "Hidalgo del Parral,Paral,Parral,ÐÐ°ÑÐ°Ð»,Hidalgo del Parral", :latitude => "26.93333", :longitude => "-105.66667").save
City.new(:country_id => "159", :name => "Heroica Zitacuaro", :aliases => "Heroica Zitacuaro,Heroica ZitÃ¡cuaro,Zitacuaro,ZitÃ¡cuaro,Heroica ZitÃ¡cuaro", :latitude => "19.4", :longitude => "-100.36667").save
City.new(:country_id => "159", :name => "Heroica Nogales", :aliases => "Heroica Nogales,Los Nogales,Nogales,Heroica Nogales", :latitude => "31.33333", :longitude => "-110.93333").save
City.new(:country_id => "159", :name => "Heroica Caborca", :aliases => "Caborca,Heroica Caborca,Heroica Caborca", :latitude => "30.71667", :longitude => "-112.15").save
City.new(:country_id => "159", :name => "Hermosillo", :aliases => "Ehrmosil'o,Hermosillo,erumoshijo,Ð­ÑÐ¼Ð¾ÑÐ¸Ð»ÑÐ¾,ã¨ã«ã¢ã·ã¼ã¸ã§,Hermosillo", :latitude => "29.06667", :longitude => "-110.96667").save
City.new(:country_id => "159", :name => "Guaymas", :aliases => "Guaymas,Heroica Guaymas,Guaymas", :latitude => "27.93333", :longitude => "-110.9").save
City.new(:country_id => "159", :name => "Guasave", :aliases => "Guasava,Guasave,Guasave", :latitude => "25.56667", :longitude => "-108.45").save
City.new(:country_id => "159", :name => "Guanajuato", :aliases => "Ciudad Guanajuato,Guanajuato,Guanakhuato,guanafuato shi,ÐÑÐ°Ð½Ð°ÑÑÐ°ÑÐ¾,ã°ã¢ããã¢ãå¸,Guanajuato", :latitude => "21.01667", :longitude => "-101.25").save
City.new(:country_id => "159", :name => "Guamuchil", :aliases => "Guamuchil,GuamÃºchil,GuamÃºchil", :latitude => "25.46667", :longitude => "-108.1").save
City.new(:country_id => "159", :name => "Guadalupe", :aliases => "Ciudad Guadalupe,Guadalupe,Gvadalupe,Villa Guadalupe,Villa de Guadalupe,ÐÐ²Ð°Ð´Ð°Ð»ÑÐ¿Ðµ,Guadalupe", :latitude => "25.68333", :longitude => "-100.25").save
City.new(:country_id => "159", :name => "Guadalupe", :aliases => "Guadalupe,Gvadalupe,ÐÐ²Ð°Ð´Ð°Ð»ÑÐ¿Ðµ,Guadalupe", :latitude => "22.75", :longitude => "-102.51667").save
City.new(:country_id => "159", :name => "Guadalajara", :aliases => "Atemaxac,Guadalajara,Gvadalachara,Gvadalaharo,Gvadalakhara,ghwadalakhara,gua da la ha la,guadarahara,gwwdlhrh,Ätemaxac,ÐÐ²Ð°Ð´Ð°Ð»Ð°ÑÐ°ÑÐ°,×××××××¨×,ØºÙØ§Ø¯Ø§ÙØ§Ø®Ø§Ø±Ø§,ã°ã¢ãã©ãã©,çè¾¾æåæ,Guadalajara", :latitude => "20.66667", :longitude => "-103.33333").save
City.new(:country_id => "159", :name => "Gomez Palacio", :aliases => "Gomez Palacio,GÃ³mez Palacio,GÃ³mez Palacio", :latitude => "25.56667", :longitude => "-103.5").save
City.new(:country_id => "159", :name => "General Juan Jose Rios", :aliases => "Colonia Juan Jose Rios,Colonia Juan JosÃ© Rios,General Juan Jose Rios,General Juan JosÃ© RÃ­os,General Juan JosÃ© RÃ­os", :latitude => "25.75", :longitude => "-108.83333").save
City.new(:country_id => "159", :name => "General Escobedo", :aliases => "Ciudad General Escobedo,General Escobedo,Gral. Escobedo,General Escobedo", :latitude => "25.81667", :longitude => "-100.33333").save
City.new(:country_id => "159", :name => "Garza Garcia", :aliases => ",Garza GarcÃ­a", :latitude => "25.66667", :longitude => "-100.4").save
City.new(:country_id => "159", :name => "Fresnillo de Gonzalez Echeverria", :aliases => "Fresnillo,Fresnillo de Gonzalez Echeverria,Fresnillo de GonzÃ¡lez EcheverrÃ­a,Fresnillo de GonzÃ¡lez EcheverrÃ­a", :latitude => "23.16667", :longitude => "-102.88333").save
City.new(:country_id => "159", :name => "Escuinapa de Hidalgo", :aliases => "Escuinapa,Escuinapa de Hidalgo,Escuinapa de Hidalgo", :latitude => "22.85", :longitude => "-105.8").save
City.new(:country_id => "159", :name => "Ensenada", :aliases => "Enseada,Ensenada,ensenada,ã¨ã³ã»ãã¼ã,Ensenada", :latitude => "31.86667", :longitude => "-116.61667").save
City.new(:country_id => "159", :name => "Encarnacion de Diaz", :aliases => "Ehnkarnas'on-de-Dias,Encarnacion,Encarnacion de Diaz,EncarnaciÃ³n de DÃ­az,Ð­Ð½ÐºÐ°ÑÐ½Ð°ÑÑÐ¾Ð½-Ð´Ðµ-ÐÐ¸Ð°Ñ,EncarnaciÃ³n de DÃ­az", :latitude => "21.51667", :longitude => "-102.23333").save
City.new(:country_id => "159", :name => "Empalme", :aliases => "Empalme,Empalme", :latitude => "27.96667", :longitude => "-110.81667").save
City.new(:country_id => "159", :name => "El Salto", :aliases => "Ehl'-Sal'to,El Salto,Pueblo Nuevo,Ð­Ð»Ñ-Ð¡Ð°Ð»ÑÑÐ¾,El Salto", :latitude => "23.38333", :longitude => "-105.38333").save
City.new(:country_id => "159", :name => "El Salto", :aliases => ",El Salto", :latitude => "20.33333", :longitude => "-104.5").save
City.new(:country_id => "159", :name => "El Pueblito", :aliases => ",El Pueblito", :latitude => "20.53333", :longitude => "-100.45").save
City.new(:country_id => "159", :name => "El Grullo", :aliases => ",El Grullo", :latitude => "19.8", :longitude => "-104.21667").save
City.new(:country_id => "159", :name => "Durango", :aliases => "Ciudad de Durango,Durango,Durango City,Victoria de Durango,dulang-go,ÐÑÑÐ°Ð½Ð³Ð¾,ëëê³ ,Durango", :latitude => "24.03333", :longitude => "-104.66667").save
City.new(:country_id => "159", :name => "Culiacan", :aliases => "Cuilacan,Culiacan,CuliacÃ¡n,Kuliakan,kuriakan,ÐÑÐ»Ð¸Ð°ÐºÐ°Ð½,ã¯ãªã¢ã«ã³,CuliacÃ¡n", :latitude => "24.79944", :longitude => "-107.38972").save
City.new(:country_id => "159", :name => "Cuauhtemoc", :aliases => "Ciudad Cuauhtemoc,Ciudad CuauhtÃ©moc,Cuahtemoc,Cuauhtemoc,CuauhtÃ©moc,San Antonio de los Arenales,CuauhtÃ©moc", :latitude => "28.41667", :longitude => "-106.86667").save
City.new(:country_id => "159", :name => "Costa Rica", :aliases => "Costa Rica,Kosta-Rika,Villa de Costa Rica,ÐÐ¾ÑÑÐ°-Ð Ð¸ÐºÐ°,Costa Rica", :latitude => "24.5875", :longitude => "-107.3875").save
City.new(:country_id => "159", :name => "Cortazar", :aliases => "Cortazar,Kortasar,Villa Cortazar,ÐÐ¾ÑÑÐ°ÑÐ°Ñ,Cortazar", :latitude => "20.48333", :longitude => "-100.93333").save
City.new(:country_id => "159", :name => "Compostela", :aliases => ",Compostela", :latitude => "21.23333", :longitude => "-104.91667").save
City.new(:country_id => "159", :name => "Comonfort", :aliases => "Chamacuero de Comonfort,Comonfort,Komonfort,Villa Comonfort,ÐÐ¾Ð¼Ð¾Ð½ÑÐ¾ÑÑ,Comonfort", :latitude => "20.71667", :longitude => "-100.76667").save
City.new(:country_id => "159", :name => "Colima", :aliases => "Colima,Kolima,ÐÐ¾Ð»Ð¸Ð¼Ð°,Colima", :latitude => "19.23333", :longitude => "-103.71667").save
City.new(:country_id => "159", :name => "Ciudad Obregon", :aliases => "Cajeme,Cd Obregon,Cd ObregÃ³n,Cd. Obregon,Cd. ObregÃ³n,Ciudad Obregon,Ciudad ObregÃ³n,Obregon,S'judad-Obregon,Ð¡ÑÑÐ´Ð°Ð´-ÐÐ±ÑÐµÐ³Ð¾Ð½,Ciudad ObregÃ³n", :latitude => "27.48333", :longitude => "-109.93333").save
City.new(:country_id => "159", :name => "Ciudad Lerdo", :aliases => "Ciudad Lerdo,Lerdo,Ciudad Lerdo", :latitude => "25.53333", :longitude => "-103.53333").save
City.new(:country_id => "159", :name => "Ciudad Juarez", :aliases => "Chuaresas,Ciudad Juarez,Ciudad JuÃ¡rez,El Paso del Norte,Juarez,JuÃ¡rez,Lungsod Juarez,Lungsod JuÃ¡rez,Paso del Norte,S'judad-Khuares,Siudad Chuaresas,Ð¡ÑÑÐ´Ð°Ð´-Ð¥ÑÐ°ÑÐµÑ,ã·ã¦ãã¼ã»ãã¢ã¬ã¹,Ciudad JuÃ¡rez", :latitude => "31.73333", :longitude => "-106.48333").save
City.new(:country_id => "159", :name => "Ciudad Hidalgo", :aliases => "Ciudad Hidalgo,Hidalgo,S'judad-Idal'go,Taximaroa,Villa Hidalgo,Ð¡ÑÑÐ´Ð°Ð´-ÐÐ´Ð°Ð»ÑÐ³Ð¾,Ciudad Hidalgo", :latitude => "19.68333", :longitude => "-100.56667").save
City.new(:country_id => "159", :name => "Ciudad Guzman", :aliases => "Cd Guzman,Cd GuzmÃ¡n,Cd. Guzman,Cd. GuzmÃ¡n,Ciudad Guzman,Ciudad GuzmÃ¡n,S'judad-Gusman,Ð¡ÑÑÐ´Ð°Ð´-ÐÑÑÐ¼Ð°Ð½,Ciudad GuzmÃ¡n", :latitude => "19.68333", :longitude => "-103.48333").save
City.new(:country_id => "159", :name => "Ciudad Delicias", :aliases => "Delicias,Delis'jas,Las Delicias,ÐÐµÐ»Ð¸ÑÑÑÑ,Ciudad Delicias", :latitude => "28.19013", :longitude => "-105.47012").save
City.new(:country_id => "159", :name => "Ciudad Constitucion", :aliases => "Ciudad Constitucion,Ciudad ConstituciÃ³n,Constitucion,ConstituciÃ³n,Villa Constitucion,Villa ConstituciÃ³n,Ciudad ConstituciÃ³n", :latitude => "25.03694", :longitude => "-111.66444").save
City.new(:country_id => "159", :name => "Ciudad Camargo", :aliases => "Camargo,Ciudad Camargo,Santa Rosalia,Santa RosalÃ­a,Ciudad Camargo", :latitude => "27.66667", :longitude => "-105.16667").save
City.new(:country_id => "159", :name => "Ciudad Anahuac", :aliases => "Anahuac,AnÃ¡huac,Ciudad Anahuac,Ciudad AnÃ¡huac,Ciudad AnÃ¡huac", :latitude => "27.23333", :longitude => "-100.15").save
City.new(:country_id => "159", :name => "Ciudad Altamirano", :aliases => "Ciudad Altamirano,Pungarabato,S'judad-Al'tamirano,Ð¡ÑÑÐ´Ð°Ð´-ÐÐ»ÑÑÐ°Ð¼Ð¸ÑÐ°Ð½Ð¾,Ciudad Altamirano", :latitude => "18.31667", :longitude => "-100.65").save
City.new(:country_id => "159", :name => "Ciudad Acuna", :aliases => "Acuna,AcuÃ±a,Ciudad Acuna,Ciudad AcuÃ±a,Las Vacas,Villa Acuna,Villa AcuÃ±a,Ciudad AcuÃ±a", :latitude => "29.32322", :longitude => "-100.95217").save
City.new(:country_id => "159", :name => "Chihuahua", :aliases => "Chihuahua,Chiuaua,Cihuahua,Ciuaua,chiwawa,Äihuahua,Äiuaua,Ð§Ð¸ÑÐ°ÑÐ°,ãã¯ã¯,Chihuahua", :latitude => "28.63333", :longitude => "-106.08333").save
City.new(:country_id => "159", :name => "Chapala", :aliases => "Chapala,Chapala", :latitude => "20.3", :longitude => "-103.2").save
City.new(:country_id => "159", :name => "Celaya", :aliases => "Celaya,Celaya", :latitude => "20.51667", :longitude => "-100.81667").save
City.new(:country_id => "159", :name => "Castanos", :aliases => "Castanos,CastaÃ±os,CastaÃ±os", :latitude => "26.78333", :longitude => "-101.41667").save
City.new(:country_id => "159", :name => "Cananea", :aliases => "Cananea,Kananea,ÐÐ°Ð½Ð°Ð½ÐµÐ°,Cananea", :latitude => "30.95", :longitude => "-110.3").save
City.new(:country_id => "159", :name => "Campo Gobierno", :aliases => "Campo Gobierno,Villa Juarez,Villa JuÃ¡rez,Campo Gobierno", :latitude => "24.65361", :longitude => "-107.54111").save
City.new(:country_id => "159", :name => "Calvillo", :aliases => "Calvillo,Calvillo", :latitude => "21.85", :longitude => "-102.71667").save
City.new(:country_id => "159", :name => "Calera Victor Rosales", :aliases => "Calera,Calera Victor Rosales,Calera VÃ­ctor Rosales,Victor Rosales,Calera VÃ­ctor Rosales", :latitude => "22.95", :longitude => "-102.7").save
City.new(:country_id => "159", :name => "Autlan de Navarro", :aliases => "Autlan,Autlan de Navarro,AutlÃ¡n,AutlÃ¡n de Navarro,AutlÃ¡n de Navarro", :latitude => "19.76667", :longitude => "-104.36667").save
City.new(:country_id => "159", :name => "Atoyac de Alvarez", :aliases => "Atojak-de-Al'vares,Atoyac,Atoyac de Alvarez,ÐÑÐ¾ÑÐº-Ð´Ðµ-ÐÐ»ÑÐ²Ð°ÑÐµÑ,Atoyac de Alvarez", :latitude => "17.2", :longitude => "-100.43333").save
City.new(:country_id => "159", :name => "Atotonilco el Alto", :aliases => "Atotonilco,Atotonilco el Alto,Atotonilco el Alto", :latitude => "20.55", :longitude => "-102.51667").save
City.new(:country_id => "159", :name => "Armeria", :aliases => ",ArmerÃ­a", :latitude => "18.93333", :longitude => "-103.96667").save
City.new(:country_id => "159", :name => "Arcelia", :aliases => ",Arcelia", :latitude => "18.28333", :longitude => "-100.26667").save
City.new(:country_id => "159", :name => "Arandas", :aliases => "Arandas,Arandas", :latitude => "20.7", :longitude => "-102.35").save
City.new(:country_id => "159", :name => "Apodaca", :aliases => "Apodaca,Apodaka,ÐÐ¿Ð¾Ð´Ð°ÐºÐ°,Apodaca", :latitude => "25.76667", :longitude => "-100.2").save
City.new(:country_id => "159", :name => "Apatzingan de la Constitucion", :aliases => "Apatzingan,Apatzingan de la Constitucion,ApatzingÃ¡n de la ConstituciÃ³n,ApatzingÃ¡n de la ConstituciÃ³n", :latitude => "19.08333", :longitude => "-102.35").save
City.new(:country_id => "159", :name => "Apaseo el Grande", :aliases => "Apaseo,Apaseo el Grande,Apaseo-ehl'-Grande,Villa Apaseo,ÐÐ¿Ð°ÑÐµÐ¾-ÑÐ»Ñ-ÐÑÐ°Ð½Ð´Ðµ,Apaseo el Grande", :latitude => "20.56667", :longitude => "-100.7").save
City.new(:country_id => "159", :name => "Apaseo el Alto", :aliases => "Apaseo,Apaseo el Alto,Apaseo-ehl'-Al'to,ÐÐ¿Ð°ÑÐµÐ¾-ÑÐ»Ñ-ÐÐ»ÑÑÐ¾,Apaseo el Alto", :latitude => "20.45", :longitude => "-100.61667").save
City.new(:country_id => "159", :name => "Ameca", :aliases => "Ameca,Ameca", :latitude => "20.55", :longitude => "-104.03333").save
City.new(:country_id => "159", :name => "Allende", :aliases => ",Allende", :latitude => "28.33333", :longitude => "-100.85").save
City.new(:country_id => "159", :name => "Allende", :aliases => ",Allende", :latitude => "25.28333", :longitude => "-100.01667").save
City.new(:country_id => "159", :name => "Aguascalientes", :aliases => "Aguascalientes,Aguaskal'entes,Ciudad de Aguascalientes,ÐÐ³ÑÐ°ÑÐºÐ°Ð»ÑÐµÐ½ÑÐµÑ,Aguascalientes", :latitude => "21.88333", :longitude => "-102.3").save
City.new(:country_id => "159", :name => "Agua Prieta", :aliases => "Agua Prieta,Agua Prieta", :latitude => "31.3", :longitude => "-109.56667").save
City.new(:country_id => "159", :name => "Acaponeta", :aliases => "Acaponeta,Acaponeta", :latitude => "22.49639", :longitude => "-105.35944").save
City.new(:country_id => "159", :name => "Acambaro", :aliases => "Acambaro,AcÃ¡mbaro,Akambaro,ÐÐºÐ°Ð¼Ð±Ð°ÑÐ¾,AcÃ¡mbaro", :latitude => "20.03333", :longitude => "-100.73333").save
City.new(:country_id => "159", :name => "Abasolo", :aliases => "Abasolo,Cuitzeo de Abasolo,Cuitzeo de Hidalgo,Villa Abasolo,ÐÐ±Ð°ÑÐ¾Ð»Ð¾,Abasolo", :latitude => "20.45", :longitude => "-101.51667").save
City.new(:country_id => "159", :name => "Dolores Hidalgo", :aliases => "Ciudad de Dolores Hidalgo,Dolores Hidalgo,Dolores Hidalgo", :latitude => "21.15611", :longitude => "-100.93083").save
City.new(:country_id => "159", :name => "Las Guacamayas", :aliases => "Guacamayas,Las Guacamayas,Las Guacamayas", :latitude => "18.01667", :longitude => "-102.21667").save
City.new(:country_id => "159", :name => "Lazaro Cardenas", :aliases => "Ciudad Lazaro Cardenas,Ciudad LÃ¡zaro CÃ¡rdenas,Lazaro Cardenas,LÃ¡zaro CÃ¡rdenas,Melchor Ocampo,Melchor Ocampo del Balsas,LÃ¡zaro CÃ¡rdenas", :latitude => "17.95833", :longitude => "-102.2").save
City.new(:country_id => "159", :name => "Colonia del Valle", :aliases => "Col del valle,Col. del Valle,del Valle,Colonia del Valle", :latitude => "19.38611", :longitude => "-99.16204").save
City.new(:country_id => "159", :name => "Colonia Lindavista", :aliases => "Col Lindavista,Col. Lindavista,Lindavista,Colonia Lindavista", :latitude => "19.49156", :longitude => "-99.12475").save
City.new(:country_id => "159", :name => "Colonia Nativitas", :aliases => "Col Nativitas,Col. Nativitas,Nativitas,Colonia Nativitas", :latitude => "19.38119", :longitude => "-99.13685").save
