City.new(:country_id => "226", :name => "Tunapuna", :aliases => "Tunapuna Village,Tunapuna", :latitude => "10.63333", :longitude => "-61.38333").save
City.new(:country_id => "226", :name => "Paradise", :aliases => ",Paradise", :latitude => "10.63471", :longitude => "-61.36671").save
City.new(:country_id => "226", :name => "Scarborough", :aliases => "Port Louis,Scarborough,Scarborough", :latitude => "11.18333", :longitude => "-60.73333").save
City.new(:country_id => "226", :name => "Sangre Grande", :aliases => "Sangre Grand,Sangre Grande Station,Sangre Grande Town,Sangre Grande", :latitude => "10.58333", :longitude => "-61.11667").save
City.new(:country_id => "226", :name => "San Fernando", :aliases => ",San Fernando", :latitude => "10.28333", :longitude => "-61.46667").save
City.new(:country_id => "226", :name => "Port-of-Spain", :aliases => "City of Port-of-Spain,Port d'Espagne,Port of Spain,Port of Speinas,Port of Spejn,Port oph Spein,Port-au-Spain,Port-d'Espagne,Port-of-Spain,Port-of-Spejn,Puerto Espana,Puerto EspaÃ±a,poteu obeu seupein,poteuobeuseupein,potoobusupein,xi ban ya gang,Î Î¿ÏÏ Î¿Ï Î£ÏÎ­Î¹Î½,ÐÐ¾ÑÑ Ð¾Ñ Ð¡Ð¿ÐµÑÐ½,ÐÐ¾ÑÑ-Ð¾Ñ-Ð¡Ð¿ÐµÐ¹Ð½,×¤××¨× ×××£ ×¡×¤×××,áá­áµ á¦á áµáá,ãã¼ããªãã¹ãã¤ã³,è¥¿ç­çæ¸¯,í¬í¸ ì¤ë¸ ì¤íì¸,í¬í¸ì¤ë¸ì¤íì¸,Port-of-Spain", :latitude => "10.66617", :longitude => "-61.51657").save
City.new(:country_id => "226", :name => "Point Fortin", :aliases => ",Point Fortin", :latitude => "10.18333", :longitude => "-61.68333").save
City.new(:country_id => "226", :name => "Mon Repos", :aliases => ",Mon Repos", :latitude => "10.283", :longitude => "-61.44605").save
City.new(:country_id => "226", :name => "Marabella", :aliases => "Marabella,Marabella", :latitude => "10.30618", :longitude => "-61.44671").save
City.new(:country_id => "226", :name => "Chaguanas", :aliases => ",Chaguanas", :latitude => "10.51667", :longitude => "-61.41667").save
City.new(:country_id => "226", :name => "Arima", :aliases => "Arima,Town of Arima,Arima", :latitude => "10.63333", :longitude => "-61.28333").save
