City.new(:country_id => "47", :name => "Vina del Mar", :aliases => "Vin'ja-del'-Mar,Vina del Mar,ViÃ±a del Mar,ÐÐ¸Ð½ÑÑ-Ð´ÐµÐ»Ñ-ÐÐ°Ñ,ããã£ã»ãã«ã»ãã¼ã«,ViÃ±a del Mar", :latitude => "-33.02457", :longitude => "-71.55183").save
City.new(:country_id => "47", :name => "Villarrica", :aliases => ",Villarrica", :latitude => "-39.28569", :longitude => "-72.2279").save
City.new(:country_id => "47", :name => "Villa Alemana", :aliases => "Villa Alemana,Villa Alemana", :latitude => "-33.04222", :longitude => "-71.37333").save
City.new(:country_id => "47", :name => "Victoria", :aliases => ",Victoria", :latitude => "-38.21667", :longitude => "-72.33333").save
City.new(:country_id => "47", :name => "Valparaiso", :aliases => "Ciudad de Valparaiso,Ciudad de ValparaÃ­so,Val'paraiso,Valparais,Valparaiso,ValparaÃ­so,baruparaiso,wa er pa lai suo,ÐÐ°Ð»Ð¿Ð°ÑÐ°Ð¸ÑÐ¾,ÐÐ°Ð»ÑÐ¿Ð°ÑÐ°Ð¸ÑÐ¾,ãã«ãã©ã¤ã½,ç¦å°å¸è±ç´¢,ValparaÃ­so", :latitude => "-33.03932", :longitude => "-71.62725").save
City.new(:country_id => "47", :name => "Vallenar", :aliases => "Vallenar,Vallenar", :latitude => "-28.57083", :longitude => "-70.75806").save
City.new(:country_id => "47", :name => "Valdivia", :aliases => "Ciudad de Valdivia,Ciudad de ValdivÃ­a,Val'divija,Valdivia,ÐÐ°Ð»ÑÐ´Ð¸Ð²Ð¸Ñ,Valdivia", :latitude => "-39.81422", :longitude => "-73.24589").save
City.new(:country_id => "47", :name => "Tome", :aliases => "Tome,TomÃ©,TomÃ©", :latitude => "-36.61667", :longitude => "-72.95").save
City.new(:country_id => "47", :name => "Tocopilla", :aliases => "Tocopilla,Tokopil'ja,Ð¢Ð¾ÐºÐ¾Ð¿Ð¸Ð»ÑÑ,Tocopilla", :latitude => "-22.09198", :longitude => "-70.19792").save
City.new(:country_id => "47", :name => "Temuco", :aliases => "Ciudad Temuco,Temuco,Temuko,Ð¢ÐµÐ¼ÑÐºÐ¾,Temuco", :latitude => "-38.73333", :longitude => "-72.6").save
City.new(:country_id => "47", :name => "Talcahuano", :aliases => "Talcahuano,Talcahuano", :latitude => "-36.71667", :longitude => "-73.11667").save
City.new(:country_id => "47", :name => "Talca", :aliases => "Tal'ka,Talca,Ð¢Ð°Ð»ÑÐºÐ°,Talca", :latitude => "-35.43333", :longitude => "-71.66667").save
City.new(:country_id => "47", :name => "Talagante", :aliases => ",Talagante", :latitude => "-33.66667", :longitude => "-70.93333").save
City.new(:country_id => "47", :name => "San Vicente", :aliases => ",San Vicente", :latitude => "-34.43333", :longitude => "-71.08333").save
City.new(:country_id => "47", :name => "Santiago", :aliases => "Ciles Santjagas,CiudadSantiago,Sanctiacobi,Sant'jago,Santiago,Santiago de Chile,Santiago de Xile,Santiago del Cile,Santiago do Chile,Santiago du Chili,Santiago du ChÂ·ili,Santjago,Santjago de Chile,Santjago de Chili,Stgo.,santiago,santixako,santyaghw,santyagw,santyyagw,sheng de ya ge,ÄilÄs Santjagas,Î£Î±Î½ÏÎ¹Î¬Î³Î¿,Ð¡Ð°Ð½ÑÑÑÐ³Ð¾,Ð¡Ð°Ð½ÑÑÐ³Ð¾ Ð´Ðµ Ð§Ð¸Ð»Ðµ,Ð¡Ð°Ð½ÑÑÐ³Ð¾ Ð´Ðµ Ð§Ð¸Ð»Ð¸,×¡× ××××× ×× ×¦'×××,Ø³Ø§ÙØªÙÙØ§Ú¯Ù,Ø³Ø§ÙØªÙØ§ØºÙ,Ø³Ø§ÙØªÛØ§Ú¯Ù,à¸à¸±à¸à¸à¸´à¸­à¸²à¹à¸,á¡ááá¢áááá áá á©ááá,á³áá²á«á,ãµã³ãã£ã¢ã´,å£å°äºå¥,ì°í°ìê³ ,Santiago", :latitude => "-33.42628", :longitude => "-70.56656").save
City.new(:country_id => "47", :name => "Santa Cruz", :aliases => "Santa Cruz,Santa-Krus,Ð¡Ð°Ð½ÑÐ°-ÐÑÑÑ,Santa Cruz", :latitude => "-34.63333", :longitude => "-71.36667").save
City.new(:country_id => "47", :name => "San Javier", :aliases => ",San Javier", :latitude => "-35.6", :longitude => "-71.75").save
City.new(:country_id => "47", :name => "San Felipe", :aliases => "San Felipe,San Felipe", :latitude => "-32.75", :longitude => "-70.73333").save
City.new(:country_id => "47", :name => "San Carlos", :aliases => ",San Carlos", :latitude => "-36.42477", :longitude => "-71.958").save
City.new(:country_id => "47", :name => "San Bernardo", :aliases => "San Bernardo,San Bernardo", :latitude => "-33.6", :longitude => "-70.71667").save
City.new(:country_id => "47", :name => "San Antonio", :aliases => "San Antonio,San Antonio", :latitude => "-33.59333", :longitude => "-71.62167").save
City.new(:country_id => "47", :name => "Rio Bueno", :aliases => "Ciudad de Rio Bueno,Ciudad de RÃ­o Bueno,RÃ­o Bueno", :latitude => "-40.31667", :longitude => "-72.96667").save
City.new(:country_id => "47", :name => "Rengo", :aliases => "Rengo,Rengo", :latitude => "-34.41667", :longitude => "-70.86667").save
City.new(:country_id => "47", :name => "Rancagua", :aliases => "Rancagua,Rankagua,Ð Ð°Ð½ÐºÐ°Ð³ÑÐ°,Rancagua", :latitude => "-34.17083", :longitude => "-70.74444").save
City.new(:country_id => "47", :name => "Quilpue", :aliases => "Quilpue,QuilpuÃ©,QuilpuÃ©", :latitude => "-33.045", :longitude => "-71.44944").save
City.new(:country_id => "47", :name => "Quillota", :aliases => "Quillota,Quillota", :latitude => "-32.88333", :longitude => "-71.26667").save
City.new(:country_id => "47", :name => "Punta Arenas", :aliases => "Magallanes,Punta Arehnas,Punta Arenas,Punta Arenasas,peng ta a lei na si,puntaarenasu,ÐÑÐ½ÑÐ° ÐÑÐµÐ½Ð°Ñ,ÐÑÐ½ÑÐ° ÐÑÑÐ½Ð°Ñ,ãã³ã¿ã¢ã¬ãã¹,è¬å¡é¿é·çº³æ¯,Punta Arenas", :latitude => "-53.15", :longitude => "-70.91667").save
City.new(:country_id => "47", :name => "Puerto Varas", :aliases => ",Puerto Varas", :latitude => "-41.31667", :longitude => "-72.98333").save
City.new(:country_id => "47", :name => "Puerto Quellon", :aliases => ",Puerto QuellÃ³n", :latitude => "-43.11667", :longitude => "-73.61667").save
City.new(:country_id => "47", :name => "Puerto Natales", :aliases => "Natales,Puehrto-Natales,Puerto Natales,ÐÑÑÑÑÐ¾-ÐÐ°ÑÐ°Ð»ÐµÑ,Puerto Natales", :latitude => "-51.72363", :longitude => "-72.48745").save
City.new(:country_id => "47", :name => "Puerto Montt", :aliases => "Ciudad de Puerto Montt,Puehrto-Mont,Puerto Mont,Puerto Montt,ÐÑÐµÑÑÐ¾ ÐÐ¾Ð½Ñ,ÐÑÑÑÑÐ¾-ÐÐ¾Ð½Ñ,Puerto Montt", :latitude => "-41.47167", :longitude => "-72.93694").save
City.new(:country_id => "47", :name => "Puerto Aisen", :aliases => "Aisen,AisÃ©n,Aysen,Ciudad de Aysen,Ciudad de AysÃ©n,Puerto Aisen,Puerto AisÃ©n,Puerto Aysen,Puerto AysÃ©n,Puerto AisÃ©n", :latitude => "-45.4", :longitude => "-72.7").save
City.new(:country_id => "47", :name => "Puente Alto", :aliases => "Puente Alto,Puente Alto", :latitude => "-33.61667", :longitude => "-70.58333").save
City.new(:country_id => "47", :name => "Pucon", :aliases => "Pukon,ÐÑÐºÐ¾Ð½,PucÃ³n", :latitude => "-39.28223", :longitude => "-71.95427").save
City.new(:country_id => "47", :name => "Penco", :aliases => "Ciudad de Penco,Penco,Penon,PeÃ±on,Penco", :latitude => "-36.73333", :longitude => "-72.98333").save
City.new(:country_id => "47", :name => "Penaflor", :aliases => "Pen'jaflor,Penaflor,PeÃ±aflor,ÐÐµÐ½ÑÑÑÐ»Ð¾Ñ,PeÃ±aflor", :latitude => "-33.61667", :longitude => "-70.91667").save
City.new(:country_id => "47", :name => "Parral", :aliases => "Parral,Parralja,ÐÐ°ÑÑÐ°Ð»Ñ,Parral", :latitude => "-36.15", :longitude => "-71.83333").save
City.new(:country_id => "47", :name => "Panguipulli", :aliases => ",Panguipulli", :latitude => "-39.63333", :longitude => "-72.33333").save
City.new(:country_id => "47", :name => "Paine", :aliases => "Paine,Pejn,ÐÐµÐ¹Ð½,Paine", :latitude => "-33.81667", :longitude => "-70.75").save
City.new(:country_id => "47", :name => "Ovalle", :aliases => "Oval'e,Ovalle,ÐÐ²Ð°Ð»ÑÐµ,Ovalle", :latitude => "-30.59833", :longitude => "-71.20028").save
City.new(:country_id => "47", :name => "Osorno", :aliases => "Osorno,ÐÑÐ¾ÑÐ½Ð¾,Osorno", :latitude => "-40.56667", :longitude => "-73.15").save
City.new(:country_id => "47", :name => "Nueva Imperial", :aliases => "Nueva Imperial,Nueva Imperial", :latitude => "-38.73333", :longitude => "-72.95").save
City.new(:country_id => "47", :name => "Nacimiento", :aliases => "Nacimiento,Nacimiento", :latitude => "-37.5", :longitude => "-72.66667").save
City.new(:country_id => "47", :name => "Mulchen", :aliases => "Mul'chen,Mulchen,MulchÃ©n,ÐÑÐ»ÑÑÐµÐ½,MulchÃ©n", :latitude => "-37.71667", :longitude => "-72.23333").save
City.new(:country_id => "47", :name => "Molina", :aliases => "Molina,ÐÐ¾Ð»Ð¸Ð½Ð°,Molina", :latitude => "-35.11667", :longitude => "-71.28333").save
City.new(:country_id => "47", :name => "Melipilla", :aliases => "Melipil'ja,Melipilla,Mellipilla,ÐÐµÐ»Ð¸Ð¿Ð¸Ð»ÑÑ,Melipilla", :latitude => "-33.7", :longitude => "-71.21667").save
City.new(:country_id => "47", :name => "Machali", :aliases => ",MachalÃ­", :latitude => "-34.18333", :longitude => "-70.66667").save
City.new(:country_id => "47", :name => "Lota", :aliases => "Lot,Lota,ÐÐ¾Ñ,Lota", :latitude => "-37.08333", :longitude => "-73.16667").save
City.new(:country_id => "47", :name => "Los Angeles", :aliases => "Angeles,Ciudad de Los Anjeles,Los Angeles,Los Anjeles,Los Ãngeles,Los-Andzheles,ÐÐ¾Ñ-ÐÐ½Ð´Ð¶ÐµÐ»ÐµÑ,Los Ãngeles", :latitude => "-37.46667", :longitude => "-72.35").save
City.new(:country_id => "47", :name => "Los Andes", :aliases => "Andes,Ciudad Los Andes,Los-And,ÐÐ¾Ñ-ÐÐ½Ð´,Los Andes", :latitude => "-32.83369", :longitude => "-70.59827").save
City.new(:country_id => "47", :name => "Loncoche", :aliases => ",Loncoche", :latitude => "-39.36667", :longitude => "-72.63333").save
City.new(:country_id => "47", :name => "Llaillay", :aliases => "Llaillai,Llaillay,Llay-Llay,Llaillay", :latitude => "-32.85", :longitude => "-70.96667").save
City.new(:country_id => "47", :name => "Linares", :aliases => "Linares,ÐÐ¸Ð½Ð°ÑÐµÑ,Linares", :latitude => "-35.85", :longitude => "-71.6").save
City.new(:country_id => "47", :name => "Limache", :aliases => "Limache,Limache", :latitude => "-33.01667", :longitude => "-71.26667").save
City.new(:country_id => "47", :name => "Lebu", :aliases => "Ciudad de Lebu,Lebu,Puerto Lebu,Lebu", :latitude => "-37.61667", :longitude => "-73.65").save
City.new(:country_id => "47", :name => "Lautaro", :aliases => ",Lautaro", :latitude => "-38.51667", :longitude => "-72.45").save
City.new(:country_id => "47", :name => "La Union", :aliases => "Ciudad La Union,La UniÃ³n", :latitude => "-40.28333", :longitude => "-73.08333").save
City.new(:country_id => "47", :name => "La Serena", :aliases => "La Serena,La-Serena,ÐÐ°-Ð¡ÐµÑÐµÐ½Ð°,La Serena", :latitude => "-29.90778", :longitude => "-71.25417").save
City.new(:country_id => "47", :name => "Lampa", :aliases => "Lampa,Lampa", :latitude => "-33.28333", :longitude => "-70.9").save
City.new(:country_id => "47", :name => "La Ligua", :aliases => ",La Ligua", :latitude => "-32.45242", :longitude => "-71.23106").save
City.new(:country_id => "47", :name => "La Laja", :aliases => "La Laja,Laja,La Laja", :latitude => "-37.26667", :longitude => "-72.7").save
City.new(:country_id => "47", :name => "Iquique", :aliases => "Ikike,Iquique,ikike,ÐÐºÑÐºÐµ,ÐÐºÐ¸ÐºÐµ,ã¤ã­ã±,Iquique", :latitude => "-20.22083", :longitude => "-70.14306").save
City.new(:country_id => "47", :name => "Illapel", :aliases => "Illapel,Illapel", :latitude => "-31.63083", :longitude => "-71.16528").save
City.new(:country_id => "47", :name => "Hacienda La Calera", :aliases => "Calera,Hacienda La Calera,Hacienda La Calera", :latitude => "-32.78333", :longitude => "-71.21667").save
City.new(:country_id => "47", :name => "Graneros", :aliases => ",Graneros", :latitude => "-34.06667", :longitude => "-70.73333").save
City.new(:country_id => "47", :name => "Frutillar", :aliases => "Frutil'jar,Ð¤ÑÑÑÐ¸Ð»ÑÑÑ,Frutillar", :latitude => "-41.12676", :longitude => "-73.04372").save
City.new(:country_id => "47", :name => "El Monte", :aliases => ",El Monte", :latitude => "-33.68333", :longitude => "-71.01667").save
City.new(:country_id => "47", :name => "Diego de Almagro", :aliases => ",Diego de Almagro", :latitude => "-26.36667", :longitude => "-70.05").save
City.new(:country_id => "47", :name => "Curico", :aliases => "Curico,CuricÃ³,CuricÃ³", :latitude => "-34.98333", :longitude => "-71.23333").save
City.new(:country_id => "47", :name => "Curanilahue", :aliases => ",Curanilahue", :latitude => "-37.46667", :longitude => "-73.35").save
City.new(:country_id => "47", :name => "Coronel", :aliases => "Coronel,Koronel',ÐÐ¾ÑÐ¾Ð½ÐµÐ»Ñ,Coronel", :latitude => "-37.01667", :longitude => "-73.13333").save
City.new(:country_id => "47", :name => "Coquimbo", :aliases => "Ciudad de Coquimbo,Coquimbo,Kokimbo,ÐÐ¾ÐºÐ¸Ð¼Ð±Ð¾,Coquimbo", :latitude => "-29.95333", :longitude => "-71.34361").save
City.new(:country_id => "47", :name => "Copiapo", :aliases => "Copiapo,CopiapÃ³,CopiapÃ³", :latitude => "-27.36667", :longitude => "-70.33333").save
City.new(:country_id => "47", :name => "Constitucion", :aliases => "Constitucion,ConstituciÃ³n,ConstituciÃ³n", :latitude => "-35.33333", :longitude => "-72.41667").save
City.new(:country_id => "47", :name => "Concepcion", :aliases => "Ciudad de Concepcion,Concepcion,ConcepciÃ³n,Konseps'on,ÐÐ¾Ð½ÑÐµÐ¿ÑÑÐ¾Ð½,ConcepciÃ³n", :latitude => "-36.82699", :longitude => "-73.04977").save
City.new(:country_id => "47", :name => "Collipulli", :aliases => "Collipulli,Collipulli", :latitude => "-37.95", :longitude => "-72.43333").save
City.new(:country_id => "47", :name => "Coihaique", :aliases => "Coyhaique,Kojajke,ÐÐ¾Ð¹Ð°Ð¹ÐºÐµ,Coihaique", :latitude => "-45.57524", :longitude => "-72.06619").save
City.new(:country_id => "47", :name => "Chimbarongo", :aliases => "Chimbarongo,Chimbarongo", :latitude => "-34.7", :longitude => "-71.05").save
City.new(:country_id => "47", :name => "Chillan", :aliases => ",ChillÃ¡n", :latitude => "-36.60664", :longitude => "-72.10344").save
City.new(:country_id => "47", :name => "Chiguayante", :aliases => "Chiguayante,Chiguayante", :latitude => "-36.91667", :longitude => "-73.01667").save
City.new(:country_id => "47", :name => "Cauquenes", :aliases => "Cauquenes,De Cauquenes,Kaukenes,ÐÐ°ÑÐºÐµÐ½ÐµÑ,Cauquenes", :latitude => "-35.96667", :longitude => "-72.35").save
City.new(:country_id => "47", :name => "Castro", :aliases => "Kastro,ÐÐ°ÑÑÑÐ¾,Castro", :latitude => "-42.4721", :longitude => "-73.77319").save
City.new(:country_id => "47", :name => "Canete", :aliases => "Canete,CaÃ±ete,CaÃ±ete", :latitude => "-37.8", :longitude => "-73.4").save
City.new(:country_id => "47", :name => "Calama", :aliases => "Calama,Kalama,ÐÐ°Ð»Ð°Ð¼Ð°,Calama", :latitude => "-22.46667", :longitude => "-68.93333").save
City.new(:country_id => "47", :name => "Cabrero", :aliases => "Cabrero,Carrero,Cabrero", :latitude => "-37.03333", :longitude => "-72.4").save
City.new(:country_id => "47", :name => "Buin", :aliases => "Buin,ÐÑÐ¸Ð½,Buin", :latitude => "-33.73333", :longitude => "-70.75").save
City.new(:country_id => "47", :name => "Arica", :aliases => "Arica,Arika,ÐÑÐ¸ÐºÐ°,××¨××§×,Arica", :latitude => "-18.475", :longitude => "-70.30417").save
City.new(:country_id => "47", :name => "Arauco", :aliases => ",Arauco", :latitude => "-37.2463", :longitude => "-73.31752").save
City.new(:country_id => "47", :name => "Antofagasta", :aliases => "Antafagasta,Antofagasta,antofagasuta,antopagaseuta,ÐÐ½ÑÐ°ÑÐ°Ð³Ð°ÑÑÐ°,ÐÐ½ÑÐ¾ÑÐ°Ð³Ð°ÑÑÐ°,ã¢ã³ããã¡ã¬ã¹ã¿,ìí íê°ì¤í,Antofagasta", :latitude => "-23.65", :longitude => "-70.4").save
City.new(:country_id => "47", :name => "Angol", :aliases => "Angol,Angol',ÐÐ½Ð³Ð¾Ð»Ñ,Angol", :latitude => "-37.8", :longitude => "-72.71667").save
City.new(:country_id => "47", :name => "Ancud", :aliases => "Ancud,Ankun,AnkuÃ±,Ancud", :latitude => "-41.86972", :longitude => "-73.82028").save
City.new(:country_id => "47", :name => "Las Animas", :aliases => ",Las Animas", :latitude => "-39.80867", :longitude => "-73.21821").save
City.new(:country_id => "47", :name => "La Pintana", :aliases => "La Pintana,La Pintana", :latitude => "-33.58331", :longitude => "-70.63419").save
City.new(:country_id => "47", :name => "Lo Prado", :aliases => "Lo Prado,Lo Prado", :latitude => "-33.4443", :longitude => "-70.72552").save
