City.new(:country_id => "175", :name => "Vista Alegre", :aliases => ",Vista Alegre", :latitude => "8.93333", :longitude => "-79.7").save
City.new(:country_id => "175", :name => "Veracruz", :aliases => "Camaron,CamarÃ³n,Cameron,CamerÃ³n,Veracruz,Veracruz", :latitude => "8.88333", :longitude => "-79.63333").save
City.new(:country_id => "175", :name => "Tocumen", :aliases => "Tocumen,Tokumen,Ð¢Ð¾ÐºÑÐ¼ÐµÐ½,Tocumen", :latitude => "9.08333", :longitude => "-79.38333").save
City.new(:country_id => "175", :name => "Santiago de Veraguas", :aliases => ",Santiago de Veraguas", :latitude => "8.1", :longitude => "-80.98333").save
City.new(:country_id => "175", :name => "San Miguelito", :aliases => "San Miguel,San Miguelito,San Miguelito", :latitude => "9.03333", :longitude => "-79.5").save
City.new(:country_id => "175", :name => "Puerto Armuelles", :aliases => "Armuelles,Puerto Armuelles,Rabo de Puerco,Puerto Armuelles", :latitude => "8.28333", :longitude => "-82.86667").save
City.new(:country_id => "175", :name => "Pedregal", :aliases => "Pedregal,Puerto Pedregal,Pedregal", :latitude => "8.36667", :longitude => "-82.43333").save
City.new(:country_id => "175", :name => "Panama", :aliases => "Ciudad de Panama,Ciudad de PanamÃ¡,Ciutat de Panama,Ciutat de PanamÃ ,Panama,Panama City,Panama Hiria,Panama by,Panama-Stadt,Panama-Urbo,Panama-stad,Panamurbo,PanamÃ¡,Pole tou Panama,Ziuda de Panama,ZiudÃ¡ de PanamÃ¡,ba na ma cheng,panama si,panama siti,panamashiti,panamasiti,pnmh syty,shhr panama,Î ÏÎ»Î· ÏÎ¿Ï Î Î±Î½Î±Î¼Î¬,ÐÐ°Ð½Ð°Ð¼Ð°,×¤× ×× ×¡×××,Ø´ÙØ± Ù¾Ø§ÙØ§ÙØ§,à¤ªà¤¨à¤¾à¤®à¤¾ à¤¸à¤¿à¤à¥,à¸à¸²à¸à¸²à¸¡à¸²à¸à¸´à¸à¸µ,ááá á¨á°á,ãããã·ãã£,å·´æ¿é¦¬å,íëë§ ì,PanamÃ¡", :latitude => "8.9936", :longitude => "-79.51973").save
City.new(:country_id => "175", :name => "Pacora", :aliases => ",Pacora", :latitude => "9.08333", :longitude => "-79.28333").save
City.new(:country_id => "175", :name => "Nuevo Arraijan", :aliases => ",Nuevo ArraijÃ¡n", :latitude => "8.91667", :longitude => "-79.71667").save
City.new(:country_id => "175", :name => "Las Cumbres", :aliases => ",Las Cumbres", :latitude => "9.08333", :longitude => "-79.53333").save
City.new(:country_id => "175", :name => "La Concepcion", :aliases => "Concepcion,ConcepciÃ³n,La Concepcion,La ConcepciÃ³n,La ConcepciÃ³n", :latitude => "8.51667", :longitude => "-82.61667").save
City.new(:country_id => "175", :name => "La Chorrera", :aliases => "Chorrera,La Chorrera,La Chorrera", :latitude => "8.88028", :longitude => "-79.78333").save
City.new(:country_id => "175", :name => "La Cabima", :aliases => "La Cabima,La Cabina,La Cabima", :latitude => "9.13333", :longitude => "-79.53333").save
City.new(:country_id => "175", :name => "David", :aliases => "Ciudad de David,David,Dehvid,ÐÑÐ²Ð¸Ð´,David", :latitude => "8.42729", :longitude => "-82.43085").save
City.new(:country_id => "175", :name => "Colon", :aliases => "Aspinwall,Ciudad de Colon,Ciudad de ColÃ³n,Colon,ColÃ³n,Kolon,koron,ÐÐ¾Ð»Ð¾Ð½,ã³ã­ã³,ColÃ³n", :latitude => "9.35917", :longitude => "-79.90139").save
City.new(:country_id => "175", :name => "Chitre", :aliases => "Chitre,ChitrÃ©,ChitrÃ©", :latitude => "7.96667", :longitude => "-80.43333").save
City.new(:country_id => "175", :name => "Chilibre", :aliases => ",Chilibre", :latitude => "9.15", :longitude => "-79.61667").save
City.new(:country_id => "175", :name => "Chepo", :aliases => ",Chepo", :latitude => "9.16667", :longitude => "-79.1").save
City.new(:country_id => "175", :name => "Changuinola", :aliases => ",Changuinola", :latitude => "9.43333", :longitude => "-82.51667").save
City.new(:country_id => "175", :name => "Cativa", :aliases => "Cativa,Catival,CativÃ¡,CativÃ¡", :latitude => "9.36056", :longitude => "-79.84361").save
City.new(:country_id => "175", :name => "Arraijan", :aliases => ",ArraijÃ¡n", :latitude => "8.95", :longitude => "-79.65").save
City.new(:country_id => "175", :name => "Alcaldediaz", :aliases => "Alcaldediaz,AlcaldedÃ­az,Penoncito,PeÃ±oncito,AlcaldedÃ­az", :latitude => "9.11667", :longitude => "-79.55").save
City.new(:country_id => "175", :name => "Aguadulce", :aliases => ",Aguadulce", :latitude => "8.25", :longitude => "-80.55").save
