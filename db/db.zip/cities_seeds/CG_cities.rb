City.new(:country_id => "43", :name => "Sibiti", :aliases => "Sibidi,Sibiti,Sibiti", :latitude => "-3.68583", :longitude => "13.34583").save
City.new(:country_id => "43", :name => "Pointe-Noire", :aliases => "Pointe-Noire,Puehnt-Nuar,Puent Nuaras,puaengteunualeu,ÐÑÑÐ½Ñ-ÐÑÐ°Ñ,í¸ìµí¸ëìë¥´,Pointe-Noire", :latitude => "-4.79472", :longitude => "11.84611").save
City.new(:country_id => "43", :name => "Owando", :aliases => "Fort Pousset,Fort-Rousset,Ouando,Ovando,Owando,ÐÐ²Ð°Ð½Ð´Ð¾,Owando", :latitude => "-0.48694", :longitude => "15.90806").save
City.new(:country_id => "43", :name => "Ouesso", :aliases => "Ouesso,OuÃ©sso,OuÃ©sso", :latitude => "1.61361", :longitude => "16.05167").save
City.new(:country_id => "43", :name => "Mossendjo", :aliases => "Massendjo,Mossendio,Mossendjo,Mossendjo", :latitude => "-2.95056", :longitude => "12.72611").save
City.new(:country_id => "43", :name => "Madingou", :aliases => "Madingo,Madingou,Madingu,ÐÐ°Ð´Ð¸Ð½Ð³Ñ,Madingou", :latitude => "-4.15361", :longitude => "13.55").save
City.new(:country_id => "43", :name => "Dolisie", :aliases => "Dolisi,Dolisie,Dolosie,Loubomo,ÐÐ¾Ð»Ð¸ÑÐ¸,Dolisie", :latitude => "-4.19972", :longitude => "12.67389").save
City.new(:country_id => "43", :name => "Loandjili", :aliases => "Loandjili,Louantili,Loandjili", :latitude => "-4.75611", :longitude => "11.85778").save
City.new(:country_id => "43", :name => "Kayes", :aliases => "Jacob,Kai,Kajes,Kaye,Kayes,KaÃ¯,Nkayi,ÐÐ°Ð¹ÐµÑ,Kayes", :latitude => "-4.16556", :longitude => "13.29278").save
City.new(:country_id => "43", :name => "Impfondo", :aliases => "Desbordesville,Impfondo,Imponfo,ÐÐ¼Ð¿ÑÐ¾Ð½Ð´Ð¾,Impfondo", :latitude => "1.63806", :longitude => "18.06667").save
City.new(:country_id => "43", :name => "Gamboma", :aliases => ",Gamboma", :latitude => "-1.87639", :longitude => "15.86444").save
City.new(:country_id => "43", :name => "Brazzaville", :aliases => "Braza,Brazavil,Brazavilis,Brazavilo,Brazzavil',Brazzaville,Maya-Maya,Mprazabil,N'Tamo,beulajabil,brazafyl,brazawyl,brzwwyl,bu la chai wei er,burazavu~iru,ÎÏÏÎ±Î¶Î±Î²Î¯Î»,ÐÑÐ°Ð·Ð·Ð°Ð²Ð¸Ð»Ñ,××¨×××××,Ø¨Ø±Ø§Ø²Ø§ÙÙÙ,Ø¨Ø±Ø§Ø²Ø§ÙÛÙ,á¥á«ááªá,ãã©ã¶ã´ã£ã«,å¸ææ´ç»´å°,ë¸ë¼ìë¹,Brazzaville", :latitude => "-4.2669", :longitude => "15.28327").save
