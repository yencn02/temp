City.new(:country_id => "164", :name => "Birni N Konni", :aliases => "Birni N Konni,Birni n'Kenni,Birni nâKenni,Birni-Koni,Birnin Koni,Birnin Konni,Birnin-Konni,Konni,ÐÐ¸ÑÐ½Ð¸Ð½-ÐÐ¾Ð½Ð½Ð¸,Birni N Konni", :latitude => "13.79562", :longitude => "5.2553").save
City.new(:country_id => "164", :name => "Zinder", :aliases => "Sinder,Zinder,ÐÐ¸Ð½Ð´ÐµÑ,Zinder", :latitude => "13.80487", :longitude => "8.98837").save
City.new(:country_id => "164", :name => "Tillaberi", :aliases => "Tillaberi,Tillabery,TillabÃ©ri,TillabÃ©ry,TillabÃ©ri", :latitude => "14.21167", :longitude => "1.45306").save
City.new(:country_id => "164", :name => "Tibiri", :aliases => ",Tibiri", :latitude => "13.56271", :longitude => "7.04848").save
City.new(:country_id => "164", :name => "Tessaoua", :aliases => "Tessaoua,Tessaoua", :latitude => "13.75737", :longitude => "7.9874").save
City.new(:country_id => "164", :name => "Tera", :aliases => "Tera,TÃ©ra,Ð¢ÐµÑÐ°,TÃ©ra", :latitude => "14.00776", :longitude => "0.75306").save
City.new(:country_id => "164", :name => "Tanout", :aliases => "Tanout,Tanout", :latitude => "14.97089", :longitude => "8.88786").save
City.new(:country_id => "164", :name => "Tahoua", :aliases => "Tahoua,Takhua,Ð¢Ð°ÑÑÐ°,Tahoua", :latitude => "14.8888", :longitude => "5.2692").save
City.new(:country_id => "164", :name => "Niamey", :aliases => "Niamei,Niamej,Niamejus,Niamey,NiamÄjus,ni ya mei,niame,nyamy,ÎÎ¹Î±Î¼Î­Î¹,ÐÐ¸Ð°Ð¼ÐµÐ¹,ÕÕ«Õ¡Õ´Õ¥Õµ,× ××××,ÙÙØ§ÙÙ,áá«á,ãã¢ã¡,å°¼äºç¾,ëìë©,Niamey", :latitude => "13.5125", :longitude => "2.11178").save
City.new(:country_id => "164", :name => "Nguigmi", :aliases => "Ngigmi,Nguigmi,Nguigmi", :latitude => "14.24953", :longitude => "13.10921").save
City.new(:country_id => "164", :name => "Mirya", :aliases => "Miria,Mirria,Mirya,Myrria,ÐÐ¸ÑÑÐ¸Ð°,Mirya", :latitude => "13.70727", :longitude => "9.15013").save
City.new(:country_id => "164", :name => "Mayahi", :aliases => "Majakhi,Mayahi,Mayaki,ÐÐ°Ð¹Ð°ÑÐ¸,Mayahi", :latitude => "13.95532", :longitude => "7.67122").save
City.new(:country_id => "164", :name => "Matamey", :aliases => "Matamey,Matameye,MatamÃ¨ye,Matamey", :latitude => "13.42309", :longitude => "8.47485").save
City.new(:country_id => "164", :name => "Maradi", :aliases => "Maradi,ÐÐ°ÑÐ°Ð´Ð¸,Maradi", :latitude => "13.5", :longitude => "7.10174").save
City.new(:country_id => "164", :name => "Magaria", :aliases => ",Magaria", :latitude => "12.99826", :longitude => "8.90991").save
City.new(:country_id => "164", :name => "Madaoua", :aliases => "Madaoua,Madawa,Madaoua", :latitude => "14.073", :longitude => "5.96").save
City.new(:country_id => "164", :name => "Illela", :aliases => "Ilella,Illela,Illeta,IllÃ©la,IllÃ©ta,IllÃ©la", :latitude => "14.4605", :longitude => "5.2437").save
City.new(:country_id => "164", :name => "Gaya", :aliases => ",Gaya", :latitude => "11.88435", :longitude => "3.44919").save
City.new(:country_id => "164", :name => "Dosso", :aliases => "Dosso,ÐÐ¾ÑÑÐ¾,Dosso", :latitude => "13.049", :longitude => "3.1937").save
City.new(:country_id => "164", :name => "Dogondoutchi", :aliases => "Dogondoutchi,Dogonduchi,Dogondoutchi", :latitude => "13.63933", :longitude => "4.02875").save
City.new(:country_id => "164", :name => "Diffa", :aliases => "Difa,Diffa,ÐÐ¸ÑÑÐ°,Diffa", :latitude => "13.31536", :longitude => "12.61134").save
City.new(:country_id => "164", :name => "Dakoro", :aliases => ",Dakoro", :latitude => "14.51056", :longitude => "6.765").save
City.new(:country_id => "164", :name => "Ayorou", :aliases => "Agorou,Ayorou,Ayorou", :latitude => "14.73075", :longitude => "0.91738").save
City.new(:country_id => "164", :name => "Alaghsas", :aliases => "Alaghsas,Alarsas,Alaghsas", :latitude => "17.0187", :longitude => "8.0168").save
