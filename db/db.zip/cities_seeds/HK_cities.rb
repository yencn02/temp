City.new(:country_id => "97", :name => "Kowloon", :aliases => "Chiu-lung,Czjulun,Kaulunas,Koulun,Kowloon,jiu long,julung,Ð¦Ð·ÑÐ»ÑÐ½,ä¹é¾,ì£¼ë£½,Kowloon", :latitude => "22.31667", :longitude => "114.18333").save
City.new(:country_id => "97", :name => "Hong Kong", :aliases => "Gonkong,Hong Kong,Victoria,ÐÐ¾Ð½ÐºÐ¾Ð½Ð³,Hong Kong", :latitude => "22.28552", :longitude => "114.15769").save
