City.new(:country_id => "231", :name => "Yumbe", :aliases => ",Yumbe", :latitude => "3.44639", :longitude => "31.27028").save
City.new(:country_id => "231", :name => "Wobulenzi", :aliases => "Wobolenzi,Wobulenzil,Wobulenzi", :latitude => "0.72833", :longitude => "32.51222").save
City.new(:country_id => "231", :name => "Wakiso", :aliases => ",Wakiso", :latitude => "0.40444", :longitude => "32.45944").save
City.new(:country_id => "231", :name => "Tororo", :aliases => "Tororo,Tororo", :latitude => "0.68472", :longitude => "34.18111").save
City.new(:country_id => "231", :name => "Soroti", :aliases => "Soroti,Soroti", :latitude => "1.68556", :longitude => "33.61639").save
City.new(:country_id => "231", :name => "Pallisa", :aliases => "Palissa,Pallisa,ÐÐ°Ð»Ð»Ð¸ÑÐ°,Pallisa", :latitude => "1.145", :longitude => "33.70944").save
City.new(:country_id => "231", :name => "Paidha", :aliases => "Pai-ida,Paidha,Payida,Paidha", :latitude => "2.41667", :longitude => "30.98333").save
City.new(:country_id => "231", :name => "Ntungamo", :aliases => ",Ntungamo", :latitude => "-0.88333", :longitude => "29.65").save
City.new(:country_id => "231", :name => "Ntungamo", :aliases => ",Ntungamo", :latitude => "-0.87944", :longitude => "30.26417").save
City.new(:country_id => "231", :name => "Njeru", :aliases => "Daru,Njeru,Njeru", :latitude => "0.41861", :longitude => "33.17306").save
City.new(:country_id => "231", :name => "Nebbi", :aliases => "Nebbi,Nebi,Nebbi", :latitude => "2.47583", :longitude => "31.1025").save
City.new(:country_id => "231", :name => "Namasuba", :aliases => ",Namasuba", :latitude => "0.68944", :longitude => "32.42139").save
City.new(:country_id => "231", :name => "Mukono", :aliases => ",Mukono", :latitude => "0.35333", :longitude => "32.75528").save
City.new(:country_id => "231", :name => "Mubende", :aliases => "Mubende,Mubendi,Mubende", :latitude => "0.58917", :longitude => "31.36").save
City.new(:country_id => "231", :name => "Moyo", :aliases => ",Moyo", :latitude => "3.62806", :longitude => "31.75361").save
City.new(:country_id => "231", :name => "Mityana", :aliases => "Mit'jana,Mitiyana,ÐÐ¸ÑÑÑÐ½Ð°,Mityana", :latitude => "0.4175", :longitude => "32.02278").save
City.new(:country_id => "231", :name => "Mbarara", :aliases => "Mbarara,Mbarara", :latitude => "-0.608", :longitude => "30.65").save
City.new(:country_id => "231", :name => "Mbale", :aliases => "Mbale,ÐÐ±Ð°Ð»Ðµ,Mbale", :latitude => "1.06444", :longitude => "34.17944").save
City.new(:country_id => "231", :name => "Masindi", :aliases => "Masinai,Masindi,ÐÐ°ÑÐ¸Ð½Ð´Ð¸,Masindi", :latitude => "1.67444", :longitude => "31.715").save
City.new(:country_id => "231", :name => "Masaka", :aliases => "Masaka,Masaki,ÐÐ°ÑÐ°ÐºÐ¸,Masaka", :latitude => "-0.31278", :longitude => "31.71306").save
City.new(:country_id => "231", :name => "Luwero", :aliases => ",Luwero", :latitude => "0.84917", :longitude => "32.47306").save
City.new(:country_id => "231", :name => "Lugazi", :aliases => ",Lugazi", :latitude => "0.37722", :longitude => "32.91972").save
City.new(:country_id => "231", :name => "Lira", :aliases => ",Lira", :latitude => "2.235", :longitude => "32.90972").save
City.new(:country_id => "231", :name => "Kyenjojo", :aliases => "Kyanjojo,Kyenjojo,Kyonjojo,Kyenjojo", :latitude => "0.63278", :longitude => "30.62139").save
City.new(:country_id => "231", :name => "Kotido", :aliases => ",Kotido", :latitude => "2.98056", :longitude => "34.13306").save
City.new(:country_id => "231", :name => "Kitgum", :aliases => "Kitgum,Kitgumo,ÐÐ¸ÑÐ³ÑÐ¼,Kitgum", :latitude => "3.27833", :longitude => "32.88667").save
City.new(:country_id => "231", :name => "Kireka", :aliases => ",Kireka", :latitude => "0.3475", :longitude => "32.64917").save
City.new(:country_id => "231", :name => "Kayunga", :aliases => "Kayunga,Kayunga", :latitude => "0.7025", :longitude => "32.88861").save
City.new(:country_id => "231", :name => "Kasese", :aliases => ",Kasese", :latitude => "0.23", :longitude => "29.98833").save
City.new(:country_id => "231", :name => "Kamwenge", :aliases => ",Kamwenge", :latitude => "0.21111", :longitude => "30.42083").save
City.new(:country_id => "231", :name => "Kampala", :aliases => "Campala,Kampala,Kampalo,kampala,kampalla,kan pa la,kanpara,kmbala,qmplh,ÎÎ±Î¼ÏÎ¬Î»Î±,ÐÐ°Ð¼Ð¿Ð°Ð»Ð°,Ô¿Õ¡Õ´ÕºÕ¡Õ¬Õ¡,×§××¤××,ÙÙØ¨Ø§ÙØ§,Ú©Ø§ÙÙ¾Ø§ÙØ§,à¤à¤®à¥à¤ªà¤¾à¤²à¤¾,á«ááá,ã«ã³ãã©,åå¸æ,ìºíë¼,Kampala", :latitude => "0.31628", :longitude => "32.58219").save
City.new(:country_id => "231", :name => "Kabale", :aliases => ",Kabale", :latitude => "-1.32611", :longitude => "30.00389").save
City.new(:country_id => "231", :name => "Jinja", :aliases => "Jinga,Jinja,Jinja", :latitude => "0.42444", :longitude => "33.20417").save
City.new(:country_id => "231", :name => "Iganga", :aliases => "Igang,Iganga,Iganga", :latitude => "0.60917", :longitude => "33.46861").save
City.new(:country_id => "231", :name => "Hoima", :aliases => "Hoima,Hoima", :latitude => "1.43556", :longitude => "31.34361").save
City.new(:country_id => "231", :name => "Gulu", :aliases => "Gul,Gulu,ÐÑÐ»,Gulu", :latitude => "2.76667", :longitude => "32.30556").save
City.new(:country_id => "231", :name => "Fort Portal", :aliases => "Fort Portal,Fort-Portal,Kabarole,Ð¤Ð¾ÑÑ-ÐÐ¾ÑÑÐ°Ð»,Fort Portal", :latitude => "0.69389", :longitude => "30.26639").save
City.new(:country_id => "231", :name => "Entebbe", :aliases => "Entebbe,Entebe,ÐÐ½ÑÐµÐ±Ðµ,×× ×××,Entebbe", :latitude => "0.06444", :longitude => "32.44694").save
City.new(:country_id => "231", :name => "Bwizibwera", :aliases => ",Bwizibwera", :latitude => "-0.59167", :longitude => "30.62861").save
City.new(:country_id => "231", :name => "Buwenge", :aliases => ",Buwenge", :latitude => "0.64222", :longitude => "33.17444").save
City.new(:country_id => "231", :name => "Busia", :aliases => "Busia,Busla,Busia", :latitude => "0.45444", :longitude => "34.07583").save
City.new(:country_id => "231", :name => "Busembatia", :aliases => ",Busembatia", :latitude => "0.76972", :longitude => "33.61306").save
City.new(:country_id => "231", :name => "Bundibugyo", :aliases => "Bundibugyo,Bundibugyo", :latitude => "0.74139", :longitude => "30.04167").save
City.new(:country_id => "231", :name => "Bugiri", :aliases => ",Bugiri", :latitude => "0.57139", :longitude => "33.74167").save
City.new(:country_id => "231", :name => "Arua", :aliases => "Arua,ÐÑÑÐ°,Arua", :latitude => "3.01917", :longitude => "30.93083").save
City.new(:country_id => "231", :name => "Adjumani", :aliases => "Adjumani,Ajumani,Adjumani", :latitude => "3.36139", :longitude => "31.80972").save
