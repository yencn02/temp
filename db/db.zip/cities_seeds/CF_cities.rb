City.new(:country_id => "42", :name => "Mobaye", :aliases => "Mobaye,Mobie,Mobaye", :latitude => "4.31667", :longitude => "21.18333").save
City.new(:country_id => "42", :name => "Ippy", :aliases => "Ippi,Ippy,Ippy", :latitude => "6.25", :longitude => "21.2").save
City.new(:country_id => "42", :name => "Bria", :aliases => "Bria,ÐÑÐ¸Ð°,Bria", :latitude => "6.53333", :longitude => "21.98333").save
City.new(:country_id => "42", :name => "Bangassou", :aliases => "Bangassou,Bangassu,Bangasu,ÐÐ°Ð½Ð³Ð°ÑÑ,Bangassou", :latitude => "4.73333", :longitude => "22.81667").save
City.new(:country_id => "42", :name => "Bambari", :aliases => "Bambari,ÐÐ°Ð¼Ð±Ð°ÑÐ¸,Bambari", :latitude => "5.76194", :longitude => "20.66722").save
City.new(:country_id => "42", :name => "Sibut", :aliases => "Fort-Sibut,Sibut,Ð¡Ð¸Ð±ÑÑ,Sibut", :latitude => "5.712", :longitude => "19.07764").save
City.new(:country_id => "42", :name => "Paoua", :aliases => "Pahua,Paoua,Paoua", :latitude => "7.24388", :longitude => "16.43975").save
City.new(:country_id => "42", :name => "Nola", :aliases => "Djembe,Nola,Nola", :latitude => "3.53333", :longitude => "16.06667").save
City.new(:country_id => "42", :name => "Mbaiki", :aliases => "Mbaiki,MbaÃ¯ki,MbaÃ¯ki", :latitude => "3.88333", :longitude => "18").save
City.new(:country_id => "42", :name => "Kaga Bandoro", :aliases => "Crampel,Fort-Crampel,Kaga Bandoro,Kaga-Bandoro,Kaga Bandoro", :latitude => "6.98333", :longitude => "19.18333").save
City.new(:country_id => "42", :name => "Damara", :aliases => "Damara,ÐÐ°Ð¼Ð°ÑÐ°,Damara", :latitude => "4.96667", :longitude => "18.7").save
City.new(:country_id => "42", :name => "Carnot", :aliases => ",Carnot", :latitude => "4.93333", :longitude => "15.86667").save
City.new(:country_id => "42", :name => "Bozoum", :aliases => "Bosum,Bozoum,Bozum,Bozume,ÐÐ¾Ð·ÑÐ¼Ðµ,Bozoum", :latitude => "6.31667", :longitude => "16.38333").save
City.new(:country_id => "42", :name => "Bouar", :aliases => "Bouar,Buar,Buare,ÐÑÐ°ÑÐµ,Bouar", :latitude => "5.95", :longitude => "15.6").save
City.new(:country_id => "42", :name => "Bossangoa", :aliases => "Amangba,Bosangoa,Bossango,Bossangoa,ÐÐ¾ÑÐ°Ð½Ð³Ð¾Ð°,Bossangoa", :latitude => "6.48333", :longitude => "17.45").save
City.new(:country_id => "42", :name => "Boda", :aliases => ",Boda", :latitude => "4.31667", :longitude => "17.46667").save
City.new(:country_id => "42", :name => "Bimbo", :aliases => "Bimbo,Bimo,Bimbo", :latitude => "4.25671", :longitude => "18.41583").save
City.new(:country_id => "42", :name => "Berberati", :aliases => "Berberati,BerbÃ©rati,ÐÐµÑÐ±ÐµÑÐ°ÑÐ¸,BerbÃ©rati", :latitude => "4.26116", :longitude => "15.79216").save
City.new(:country_id => "42", :name => "Batangafo", :aliases => "Batangafo,Devo,DÃ©vo,Batangafo", :latitude => "7.2954", :longitude => "18.28775").save
City.new(:country_id => "42", :name => "Bangui", :aliases => "Bangi,Bangis,Bangui,Mpan'nkoui,ban ji,bang-gi,bangi,bangwyy,ÎÏÎ±Î½Î³ÎºÎ¿ÏÎ¯,ÐÐ°Ð½Ð³Ð¸,ÐÐ°Ð½Ð³Ñ,×× ××××,Ø¨Ø§ÙÚ¯ÙØ¦Û,á£áá,ãã³ã®,ç­åº,ë°©ê¸°,Bangui", :latitude => "4.36122", :longitude => "18.55496").save
