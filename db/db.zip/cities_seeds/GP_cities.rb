City.new(:country_id => "89", :name => "Sainte-Rose", :aliases => "Sainte-Rose,Sent-Roz,Ð¡ÐµÐ½Ñ-Ð Ð¾Ð·,Sainte-Rose", :latitude => "16.33238", :longitude => "-61.69793").save
City.new(:country_id => "89", :name => "Sainte-Anne", :aliases => "Sainte-Anne,Sainte-Anne", :latitude => "16.22636", :longitude => "-61.37919").save
City.new(:country_id => "89", :name => "Pointe-a-Pitre", :aliases => "La Pointe a Pitre,La Pointe Ã  Pitre,Pointe-a-Pitre,Pointe-Ã -Pitre,Pointe-Ã -Pitre", :latitude => "16.2422", :longitude => "-61.5343").save
City.new(:country_id => "89", :name => "Petit-Bourg", :aliases => "Petit-Bourg,Pti-Burg,ÐÑÐ¸-ÐÑÑÐ³,Petit-Bourg", :latitude => "16.19135", :longitude => "-61.59159").save
City.new(:country_id => "89", :name => "Les Abymes", :aliases => "Abeymes,Abymes,Les Abymes,Les Abymes", :latitude => "16.27095", :longitude => "-61.50451").save
City.new(:country_id => "89", :name => "Le Moule", :aliases => "Le Moule,Moule,Le Moule", :latitude => "16.33315", :longitude => "-61.34728").save
City.new(:country_id => "89", :name => "Le Gosier", :aliases => "Gosier,Gozier,Le Gosier,Le Gosier", :latitude => "16.20685", :longitude => "-61.49329").save
City.new(:country_id => "89", :name => "Capesterre-Belle-Eau", :aliases => "Capesterre,Capesterre-Belle-Eau,Capesterre-Belle-Eau", :latitude => "16.04322", :longitude => "-61.56596").save
City.new(:country_id => "89", :name => "Basse-Terre", :aliases => "Bas-Ter,Basse Terre,Basse-Terre,ÐÐ°Ñ-Ð¢ÐµÑ,Basse-Terre", :latitude => "15.99854", :longitude => "-61.72548").save
City.new(:country_id => "89", :name => "Baie-Mahault", :aliases => "Baie-Mahault,La Baie Mahault,Baie-Mahault", :latitude => "16.26738", :longitude => "-61.58543").save
