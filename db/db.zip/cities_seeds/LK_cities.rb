City.new(:country_id => "132", :name => "Welisara", :aliases => ",Welisara", :latitude => "7.0281", :longitude => "79.9014").save
City.new(:country_id => "132", :name => "Weligama", :aliases => ",Weligama", :latitude => "5.96667", :longitude => "80.41667").save
City.new(:country_id => "132", :name => "Wattala", :aliases => ",Wattala", :latitude => "6.9779", :longitude => "79.8898").save
City.new(:country_id => "132", :name => "Vavuniya", :aliases => "Vavunija,Vavuniya,Vavuniya Town,ÐÐ°Ð²ÑÐ½Ð¸Ñ,Vavuniya", :latitude => "8.7514", :longitude => "80.4971").save
City.new(:country_id => "132", :name => "Valvedditturai", :aliases => "Valvedditturai,Valvettithurai,Valvettiturai,Valvedditturai", :latitude => "9.81667", :longitude => "80.16667").save
City.new(:country_id => "132", :name => "Trincomalee", :aliases => "Trikunamalaja,Trincomalee,Trincomali,Trinkomali,ting ke ma li,tirukkonamalai,trynkwmaly,Ð¢ÑÐ¸Ð½ÐºÐ¾Ð¼Ð°Ð»Ð¸,ØªØ±ÙÙÙÙÙØ§ÙÙ,à®¤à®¿à®°à¯à®à¯à®à¯à®£à®®à®²à¯,äº­å¯é©¬é,Trincomalee", :latitude => "8.5711", :longitude => "81.2335").save
City.new(:country_id => "132", :name => "Ratnapura", :aliases => "Ratnapura,Ratnapury,Ð Ð°ÑÐ½Ð°Ð¿ÑÑÑ,Ratnapura", :latitude => "6.68278", :longitude => "80.39917").save
City.new(:country_id => "132", :name => "Puttalam", :aliases => "Puttalam,Puttalam", :latitude => "8.0362", :longitude => "79.8283").save
City.new(:country_id => "132", :name => "Point Pedro", :aliases => "Point Pedro,Pojnt-Pedro,paruttitturai,ÐÐ¾Ð¹Ð½Ñ-ÐÐµÐ´ÑÐ¾,à®ªà®°à¯à®¤à¯à®¤à®¿à®¤à¯à®¤à¯à®±à¯,Point Pedro", :latitude => "9.81667", :longitude => "80.23333").save
City.new(:country_id => "132", :name => "Pita Kotte", :aliases => ",Pita Kotte", :latitude => "6.8905", :longitude => "79.9015").save
City.new(:country_id => "132", :name => "Peliyagoda", :aliases => ",Peliyagoda", :latitude => "6.9685", :longitude => "79.8836").save
City.new(:country_id => "132", :name => "Panadura", :aliases => "Panadura,Panadure,Pandura,Panadura", :latitude => "6.7132", :longitude => "79.9026").save
City.new(:country_id => "132", :name => "Nuwara Eliya", :aliases => "Nuwara Eliya Town,Nuwari-Eliya,Nuwara Eliya", :latitude => "6.97078", :longitude => "80.78286").save
City.new(:country_id => "132", :name => "Negombo", :aliases => "Negombo,ÐÐµÐ³Ð¾Ð¼Ð±Ð¾,Negombo", :latitude => "7.2083", :longitude => "79.8358").save
City.new(:country_id => "132", :name => "Mulleriyawa", :aliases => ",Mulleriyawa", :latitude => "6.933", :longitude => "79.9297").save
City.new(:country_id => "132", :name => "Moratuwa", :aliases => "Moratuwa,Moratuwa", :latitude => "6.773", :longitude => "79.8816").save
City.new(:country_id => "132", :name => "Matara", :aliases => "Matara,ÐÐ°ÑÐ°ÑÐ°,Matara", :latitude => "5.94851", :longitude => "80.53528").save
City.new(:country_id => "132", :name => "Maharagama", :aliases => "Maharagama,Maharagama", :latitude => "6.848", :longitude => "79.9265").save
City.new(:country_id => "132", :name => "Kurunegala", :aliases => "Kornegalle,Kurunegala,Kurunegald,ÐÑÑÑÐ½ÐµÐ³Ð°Ð»Ð°,Kurunegala", :latitude => "7.4863", :longitude => "80.3623").save
City.new(:country_id => "132", :name => "Sri Jayewardenepura Kotte", :aliases => "Kolompo,Kotte,Shri-Dzhajavardenepura-Kotte,Sri Dzajavardenepura,Sri Jayavardhanapura,Sri Jayawardenapura,Sri Jayawardenepura,Sri Jayawardenepura Kotte,Sri Jayewardanapura Kotte,Sri Jayewardanepura,Sri Jayewardanepura Kotte,kotte,seulijayawaleudanapula,surijayawarudanapurakotte,Å ri DÅ¾ajavardenepura,ÎÎ¿Î»ÏÎ¼ÏÎ¿,Ð¨ÑÐ¸-ÐÐ¶Ð°ÑÐ²Ð°ÑÐ´ÐµÐ½ÐµÐ¿ÑÑÐ°-ÐÐ¾ÑÑÐµ,à®à¯à®à¯à®à¯,ã¹ãªã¸ã£ã¤ã¯ã«ãããã©ã³ãã,ì¤ë¦¬ìì¼ìë¥´ë¤ëí¸ë¼,Sri Jayewardenepura Kotte", :latitude => "6.90278", :longitude => "79.90833").save
City.new(:country_id => "132", :name => "Kotikawatta", :aliases => ",Kotikawatta", :latitude => "6.9269", :longitude => "79.9095").save
City.new(:country_id => "132", :name => "Kolonnawa", :aliases => ",Kolonnawa", :latitude => "6.9329", :longitude => "79.8848").save
City.new(:country_id => "132", :name => "Kelaniya", :aliases => "Kelanai,Kelaniya,Kelaniya", :latitude => "6.9553", :longitude => "79.922").save
City.new(:country_id => "132", :name => "Katunayaka North", :aliases => "Katunayaka,Katunayaka North,Katunayake,Katunayaka North", :latitude => "7.1643", :longitude => "79.8757").save
City.new(:country_id => "132", :name => "Kandy", :aliases => "Kandi,Kandy,Mahanurora,Mahanuvara,Mahanuwara,kandy,kang ti,kanti,ÐÐ°Ð½Ð´Ð¸,ÙØ§ÙØ¯Ù,à®à®£à¯à®à®¿,à·à·à¶à¶à¶©à¶à¶½,åº·æ,Kandy", :latitude => "7.2955", :longitude => "80.6356").save
City.new(:country_id => "132", :name => "Kandana", :aliases => ",Kandana", :latitude => "7.048", :longitude => "79.8937").save
City.new(:country_id => "132", :name => "Kalutara", :aliases => "Kalutara,Kalutara South,ÐÐ°Ð»ÑÑÐ°ÑÐ°,Kalutara", :latitude => "6.5831", :longitude => "79.9593").save
City.new(:country_id => "132", :name => "Kalmunai", :aliases => ",Kalmunai", :latitude => "7.41667", :longitude => "81.81667").save
City.new(:country_id => "132", :name => "Jaffna", :aliases => "Dzhafna,Jaffna,Jaffna Town,yalppanam,ÐÐ¶Ð°ÑÐ½Ð°,à®¯à®¾à®´à¯à®ªà¯à®ªà®¾à®£à®®à¯,Jaffna", :latitude => "9.6567", :longitude => "80.0137").save
City.new(:country_id => "132", :name => "Ja Ela", :aliases => ",Ja Ela", :latitude => "7.0744", :longitude => "79.8919").save
City.new(:country_id => "132", :name => "Homagama", :aliases => ",Homagama", :latitude => "6.844", :longitude => "80.0024").save
City.new(:country_id => "132", :name => "Hendala", :aliases => ",Hendala", :latitude => "6.9909", :longitude => "79.883").save
City.new(:country_id => "132", :name => "Hatton", :aliases => ",Hatton", :latitude => "6.8916", :longitude => "80.5955").save
City.new(:country_id => "132", :name => "Hanwella Ihala", :aliases => ",Hanwella Ihala", :latitude => "6.9012", :longitude => "80.0852").save
City.new(:country_id => "132", :name => "Gampola", :aliases => "Gampola,Gampola Town,Gampola", :latitude => "7.1643", :longitude => "80.5696").save
City.new(:country_id => "132", :name => "Galle", :aliases => "Galla,Galle,kali,ÐÐ°Ð»Ð»Ðµ,à®à®¾à®²à®¿,Galle", :latitude => "6.0367", :longitude => "80.217").save
City.new(:country_id => "132", :name => "Galkissa", :aliases => ",Galkissa", :latitude => "6.8293", :longitude => "79.863").save
City.new(:country_id => "132", :name => "Eravur Town", :aliases => "Ehravure,Eraur,Eravur,Eravur Town,Ð­ÑÐ°Ð²ÑÑÐµ,Eravur Town", :latitude => "7.7782", :longitude => "81.6038").save
City.new(:country_id => "132", :name => "Dambulla", :aliases => "Dambul,Dambulla,tampullai porkovil,ÐÐ°Ð¼Ð±ÑÐ»Ð»Ð°,à®¤à®®à¯à®ªà¯à®³à¯à®³à¯ à®ªà¯à®±à¯à®à¯à®µà®¿à®²à¯,Dambulla", :latitude => "7.86", :longitude => "80.65167").save
City.new(:country_id => "132", :name => "Colombo", :aliases => "Colombo,Columbo,Kolombas,Kolombo,ke lun po,kholambo,kolambo,kollombo,kolumpu,koronbo,kwlwmbw,qwlwmbw,ÐÐ¾Ð»Ð¾Ð¼Ð±Ð¾,×§××××××,ÙÙÙÙÙØ¨Ù,à¤à¥à¤²à¤à¤¬à¥,à®à¯à®´à¯à®®à¯à®ªà¯,à¶à·à·à¶¹,à·à¶à·à·à¶¹,à¹à¸à¸¥à¸±à¸¡à¹à¸,á®ááá¦,ã³ã­ã³ã,å¯å«å¡,ì½ë¡¬ë³´,Colombo", :latitude => "6.93194", :longitude => "79.84778").save
City.new(:country_id => "132", :name => "Chilaw", :aliases => "Chilan,Chilaw,Chilaw Town,Chilaw", :latitude => "7.57583", :longitude => "79.79528").save
City.new(:country_id => "132", :name => "Beruwala", :aliases => ",Beruwala", :latitude => "6.4788", :longitude => "79.9828").save
City.new(:country_id => "132", :name => "Bentota", :aliases => "Bentota,ÐÐµÐ½ÑÐ¾ÑÐ°,Bentota", :latitude => "6.4254", :longitude => "79.9948").save
City.new(:country_id => "132", :name => "Batticaloa", :aliases => "Batticaloa,Batticoloa,Battikaloa,Madakalapuva,Madakalapuwra,Maddakkalabbu,batykalwa,mattakkalappu,ÐÐ°ÑÑÐ¸ÐºÐ°Ð»Ð¾Ð°,Ø¨Ø§ØªÙÙØ§ÙÙØ§,à®®à®à¯à®à®à¯à®à®³à®ªà¯à®ªà¯,Batticaloa", :latitude => "7.7102", :longitude => "81.6924").save
City.new(:country_id => "132", :name => "Battaramulla South", :aliases => "Battaramulla,Battaramulla South,Battaramulla South", :latitude => "6.8964", :longitude => "79.9181").save
City.new(:country_id => "132", :name => "Badulla", :aliases => "Badulla,Badully,ÐÐ°Ð´ÑÐ»Ð»Ñ,Badulla", :latitude => "6.9895", :longitude => "81.0557").save
City.new(:country_id => "132", :name => "Anuradhapura", :aliases => "Aneuradhapura,Anuradhapur,Anuradhapura,Anuradhapura Town,AnurÃ¢dhapura,a nu la de pu lei wang guo,anuradapura,anuradkhapura,anuratapuram,ÐÐ½ÑÑÐ°Ð´ÑÐ°Ð¿ÑÑÐ°,à®à®©à¯à®°à®¾à®¤à®ªà¯à®°à®®à¯,ã¢ãã©ãã¼ãã©,é¿åªæå¾·æ®åçå,Anuradhapura", :latitude => "8.35647", :longitude => "80.41726").save
City.new(:country_id => "132", :name => "Ampara", :aliases => "Ampara,Amparai,Ampari,Ampara", :latitude => "7.28333", :longitude => "81.66667").save
City.new(:country_id => "132", :name => "Ambalangoda", :aliases => "Ambalangoda,Ambalangoddi,Ambalangoda", :latitude => "6.2355", :longitude => "80.0538").save
