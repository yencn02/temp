City.new(:country_id => "198", :name => "Zalingei", :aliases => "Zalingee,Zalingei,Zalinje,ÐÐ°Ð»Ð¸Ð½Ð³ÐµÐµ,Zalingei", :latitude => "12.9", :longitude => "23.48333").save
City.new(:country_id => "198", :name => "Yei", :aliases => "Ej,Yei,Yey,YÄy,ÐÐ¹,Yei", :latitude => "4.09139", :longitude => "30.67861").save
City.new(:country_id => "198", :name => "Yambio", :aliases => "Jambio,Yambio,Yambiyo,Ð¯Ð¼Ð±Ð¸Ð¾,Yambio", :latitude => "4.57056", :longitude => "28.41639").save
City.new(:country_id => "198", :name => "Wau", :aliases => "Vau,Wau,Waw,WÄw,waw,ÐÐ°Ñ,ÙØ§Ù,Wau", :latitude => "7.7", :longitude => "28").save
City.new(:country_id => "198", :name => "Wad Medani", :aliases => "Medani,Wad Madani,Wad Medani,wd mdny,ÙØ¯ ÙØ¯ÙÙ,Wad Medani", :latitude => "14.4056", :longitude => "33.4989").save
City.new(:country_id => "198", :name => "Awel", :aliases => "Aweil,Awel,Eweil,Uwayl,Awel", :latitude => "8.77458", :longitude => "27.39426").save
City.new(:country_id => "198", :name => "Um Ruwwaba", :aliases => "Um Ruaba,Um Ruwwaba,Um RuwwÄba,Umm Ruwaba,Umm Ruwabah,Umm RuwÄba,Umm RuwÄbah,Um RuwwÄba", :latitude => "12.9061", :longitude => "31.2158").save
City.new(:country_id => "198", :name => "Omdurman", :aliases => "Omdourman,Omdurman,Omdurmana,Omdurmanas,OmdurmÄna,Umm Durman,Umm DurmÄn,omdurman,omudo~uruman,ÐÐ¼Ð´ÑÑÐ¼Ð°Ð½,ãªã ãã¥ã«ãã³,Omdurman", :latitude => "15.63611", :longitude => "32.43722").save
City.new(:country_id => "198", :name => "Torit", :aliases => "Torit,Ð¢Ð¾ÑÐ¸Ñ,Torit", :latitude => "4.41333", :longitude => "32.56778").save
City.new(:country_id => "198", :name => "Tonj", :aliases => "At Tonj,Ibba,Ton'gh,Tonj,Tonâgh,Tonj", :latitude => "7.27333", :longitude => "28.68389").save
City.new(:country_id => "198", :name => "Tokar", :aliases => "Tawkar,Tokar,TokÄr,Å¢awkar,TokÄr", :latitude => "18.4254", :longitude => "37.729").save
City.new(:country_id => "198", :name => "Tandalti", :aliases => "Tandalti,TandaltÄ«,Tendelti,TandaltÄ«", :latitude => "13.01667", :longitude => "31.86667").save
City.new(:country_id => "198", :name => "Sinja", :aliases => "Senga,Singa,Sinja,Sinjah,Sinja", :latitude => "13.15", :longitude => "33.93333").save
City.new(:country_id => "198", :name => "Shendi", :aliases => "Shandi,Shendi,Shindi,ShindÃ®,Shendi", :latitude => "16.6915", :longitude => "33.4341").save
City.new(:country_id => "198", :name => "Sawakin", :aliases => "Savakine,Sawakin,SawÄkin,Suakin,Ð¡Ð°Ð²Ð°ÐºÐ¸Ð½Ðµ,SawÄkin", :latitude => "19.1059", :longitude => "37.3321").save
City.new(:country_id => "198", :name => "Sannar", :aliases => "Sannar,SannÄr,Sennaar,Sennar,SennÄr,Sinnar,SannÄr", :latitude => "13.55", :longitude => "33.63333").save
City.new(:country_id => "198", :name => "Rumbek", :aliases => "Rumbek,Rumbeke,Rumbik,rmbyk,Ð ÑÐ¼Ð±ÐµÐºÐµ,Ø±ÙØ¨ÙÙ,Rumbek", :latitude => "6.8039", :longitude => "29.69097").save
City.new(:country_id => "198", :name => "Rabaq", :aliases => "Rabak,Rabaq,rbk,Ø±Ø¨Ù,Rabaq", :latitude => "13.15", :longitude => "32.73333").save
City.new(:country_id => "198", :name => "Malakal", :aliases => "Malakal,Malakal',ÐÐ°Ð»Ð°ÐºÐ°Ð»Ñ,Malakal", :latitude => "9.53694", :longitude => "31.65611").save
City.new(:country_id => "198", :name => "Maiurno", :aliases => ",Maiurno", :latitude => "13.41667", :longitude => "33.66667").save
City.new(:country_id => "198", :name => "Kusti", :aliases => "Costi,Kosti,Kusti,KÅ«stÄ«,rbk,ÐÑÑÑÐ¸,Ø±Ø¨Ù,KÅ«stÄ«", :latitude => "13.16667", :longitude => "32.66667").save
City.new(:country_id => "198", :name => "Kuraymah", :aliases => "Kareima,Karemah,Karima,KarÃªmah,Kuraymah,Kuraymah", :latitude => "18.55", :longitude => "31.85").save
City.new(:country_id => "198", :name => "Kinana", :aliases => "Kenana,Kinana,Kinanah,KinÄna,KinÄnah,KinÄna", :latitude => "14.0361", :longitude => "33.1712").save
City.new(:country_id => "198", :name => "Kassala", :aliases => "Cassala,Kasala,Kassala,Kassale,ksl,ÐÐ°ÑÑÐ°Ð»Ðµ,ÙØ³Ù,Kassala", :latitude => "15.457", :longitude => "36.4001").save
City.new(:country_id => "198", :name => "Kadugli", :aliases => "Kadugli,Kaduqli,KÄduqlÄ«,kadqly,ÐÐ°Ð´ÑÐ³Ð»Ð¸,ÙØ§Ø¯ÙÙÙ,Kadugli", :latitude => "11.01667", :longitude => "29.71667").save
City.new(:country_id => "198", :name => "Juba", :aliases => "Djouba,Dzhuba,Goba,Juba,Uula,g'wbh,ÐÐ¶ÑÐ±Ð°,×'×××,Juba", :latitude => "4.85165", :longitude => "31.58247").save
City.new(:country_id => "198", :name => "Gogrial", :aliases => "Gogrial,Gogriale,Qaqriyal,ÐÐ¾Ð³ÑÐ¸Ð°Ð»Ðµ,Gogrial", :latitude => "8.53341", :longitude => "28.10931").save
City.new(:country_id => "198", :name => "Doka", :aliases => "Doka,Doka", :latitude => "13.51667", :longitude => "35.76667").save
City.new(:country_id => "198", :name => "Dilling", :aliases => "Ad Dalanj,Dilling,ÐÐ¸Ð»Ð»Ð¸Ð½Ð³,Dilling", :latitude => "12.05", :longitude => "29.65").save
City.new(:country_id => "198", :name => "Port Sudan", :aliases => "Bur Sudan,Burt Sudan,BÅ«r SÅ«dÄn,BÅ«rt SÅ«dÄn,New Sawakin,New SawÃ¢kin,Port Sudan,Port-Sudan,Shaikh Barghuth,Shaikh BarghÅ«th,Shaykh Burghuth,Shaykh BurghÅ«th,Sheikh Barghuth,Sheikh BarghÅ«th,bwr swdan,bwrtswdan,potosudan,ÐÐ¾ÑÑ-Ð¡ÑÐ´Ð°Ð½,Ø¨ÙØ± Ø³ÙØ¯Ø§Ù,Ø¨ÙØ±ØªØ³ÙØ¯Ø§Ù,ãã¼ãã¹ã¼ãã³,Port Sudan", :latitude => "19.61583", :longitude => "37.21639").save
City.new(:country_id => "198", :name => "Bor", :aliases => ",Bor", :latitude => "6.21167", :longitude => "31.55473").save
City.new(:country_id => "198", :name => "Berber", :aliases => "Barbar,Berber,Berber", :latitude => "18.02158", :longitude => "33.98299").save
City.new(:country_id => "198", :name => "Barah", :aliases => "Bara,Barah,BÄra,BÄrah,BÄrah", :latitude => "13.7", :longitude => "30.36667").save
City.new(:country_id => "198", :name => "Madent Atbara", :aliases => "Atbara,Atbarah,Atbare,Madent Atbara,`Atbarah,ÐÑÐ±Ð°ÑÐµ,Ø¹Ø·Ø¨Ø±Ø©,âAÅ£barah,Madent Atbara", :latitude => "17.6925", :longitude => "33.9852").save
City.new(:country_id => "198", :name => "As Suki", :aliases => "As Suki,As SÅ«kÄ«,Es Suki,As SÅ«kÄ«", :latitude => "13.31667", :longitude => "33.88333").save
City.new(:country_id => "198", :name => "Ar Ruseris", :aliases => "Ar Roseris,Ar Rusayris,Ar Ruseris,Ar RuÅayriÅ,Er Roseires,Ruseres,Ruá¹£Ãªreá¹£,Ar Ruseris", :latitude => "11.8659", :longitude => "34.3869").save
City.new(:country_id => "198", :name => "Ar Rahad", :aliases => "Ar Rahad,Er Rahad,Rahad,Ar Rahad", :latitude => "12.71667", :longitude => "30.65").save
City.new(:country_id => "198", :name => "An Nuhud", :aliases => "An Nahud,An NahÅ«d,An Nuhud,An NuhÅ«d,En Nahud,En NahÅ«d,Nahad,An NuhÅ«d", :latitude => "12.7", :longitude => "28.43333").save
City.new(:country_id => "198", :name => "El Obeid", :aliases => "Al Obayyid,Al Ubayd,Al Ubayyid,Al Ubayyiá¸,Al-Ubayyid,Al-`Obed,Al-âObÃªd,El Obeid,El Ubeiyad,`Ubed,alaby,ÐÐ» ÐÐ±ÐµÐ¸Ð´,Ø§ÙØ£Ø¨Ù,âUbÃªd,El Obeid", :latitude => "13.18333", :longitude => "30.21667").save
City.new(:country_id => "198", :name => "Al Qitena", :aliases => "Al Qitena,Al QiÅ£ena,Al Qutaynah,Al QuÅ£aynah,El Geteina,El Qeteina,Al QiÅ£ena", :latitude => "14.8648", :longitude => "32.3668").save
City.new(:country_id => "198", :name => "Al Mijlad", :aliases => "Al Mijlad,Al Mujlad,El Muglad,Muglad,Al Mijlad", :latitude => "11.03333", :longitude => "27.73333").save
City.new(:country_id => "198", :name => "Al Manaqil", :aliases => "Al Manaqil,Al ManÄqil,El Managil,El Manaqil,El ManÄqil,Manaqil,Al ManÄqil", :latitude => "14.2459", :longitude => "32.9891").save
City.new(:country_id => "198", :name => "Khartoum", :aliases => "Al Khartum,Al KharÅ£Å«m,Al Khurtum,Al KhurÅ£Å«m,Cartum,CartÃºm,Chartoum,Chartum,Chartumas,ChartÃºm,Hartum,Hartumo,Jartum,Kartum,KartÃºm,Khartoem,Khartoum,Khartoun,Khartum,Khartun - alkhrtwm,KhartÃºn - Ø§ÙØ®Ø±Ø·ÙÙ,haleutum,harutsumu,hrtwm,karttaum,ke tu mu,khartwm,khrtwm,Ä¤artumo,Î§Î±ÏÏÎ¿ÏÎ¼,ÐÐ°ÑÑÑÐ¼,Ð¥Ð°ÑÑÑÐ¼,××¨×××,Ø®Ø§Ø±Ø·ÙÙ,Ø®Ø±Ø·ÙÙ,à®à®¾à®°à¯à®¤à¯à®¤à¯à®®à¯,à½à½¢à¼à½à½´à½,á«á­á±á,ãã«ãã¼ã ,ååç©,íë¥´í¼,Khartoum", :latitude => "15.54665", :longitude => "32.53361").save
City.new(:country_id => "198", :name => "El Geneina", :aliases => "Aj Jinena,Aj JinÄna,Al Geneina,Al Jeneina,Al JinÄna,Al Junaynah,El Geneina,Geneina,Geneina Fort,El Geneina", :latitude => "13.45", :longitude => "22.45").save
City.new(:country_id => "198", :name => "Al Hilaliyya", :aliases => "Al Hilaliyah,Al Hilaliyya,Al HilÄliyya,Al HilÄlÄ«yah,El Hilaliya,El HilÄliya,Hilaliya,Al HilÄliyya", :latitude => "14.9398", :longitude => "33.234").save
City.new(:country_id => "198", :name => "Al Hawatah", :aliases => "Al Hawatah,Al Hawwata,Al á¸¨awÄtah,El Hawata,Al á¸¨awÄtah", :latitude => "13.41667", :longitude => "34.63333").save
City.new(:country_id => "198", :name => "Hasiheisa", :aliases => "Al Hasahisa,Al á¸¨aÅÄá¸©Ä«Åa,El Hasaheisa,El Hasiheisa,Hasiheisa,Hasiheisa", :latitude => "14.7324", :longitude => "33.3019").save
City.new(:country_id => "198", :name => "El Fasher", :aliases => "Al Fashir,Al FÄshir,Al-Faschir,Al-Fashir,Ehl'-Fashir,El Fasher,Tendelti,Ð­Ð»Ñ-Ð¤Ð°ÑÐ¸Ñ,El Fasher", :latitude => "13.63333", :longitude => "25.35").save
City.new(:country_id => "198", :name => "El Bauga", :aliases => "Al Bauga,El Bauga,El Bauga", :latitude => "18.26196", :longitude => "33.90812").save
City.new(:country_id => "198", :name => "Ad Diwem", :aliases => "Ad Diwem,Ad Duwaym,Ad Duwem,Ad DuwÄm,Dueim,Ed Dueim,Ad Diwem", :latitude => "14.0012", :longitude => "32.3116").save
City.new(:country_id => "198", :name => "Ad Dindar", :aliases => ",Ad Dindar", :latitude => "13.2", :longitude => "34.16667").save
City.new(:country_id => "198", :name => "Ed Damer", :aliases => "Ad Damar,Ad Damir,Ad DÄmir,Ad-Damir,Ed Damer,El Damar,Ed Damer", :latitude => "17.59278", :longitude => "33.95917").save
City.new(:country_id => "198", :name => "Ed Damazin", :aliases => "Ad Damazin,Ad DamÄzÄ«n,Ad-Damazin,Damazin,Ed Damazin,aldmazyn,ÐÐ´ ÐÐ°Ð¼Ð°Ð·Ð¸Ð½,Ø§ÙØ¯ÙØ§Ø²ÙÙ,Ed Damazin", :latitude => "11.7891", :longitude => "34.3592").save
City.new(:country_id => "198", :name => "Abu Zabad", :aliases => ",AbÅ« Zabad", :latitude => "12.35", :longitude => "29.25").save
City.new(:country_id => "198", :name => "Abu Jibeha", :aliases => "Abu Gibeyah,Abu Gubeiha,Abu Jibeha,Abu Jubayhah,Abu-Gebeiha,AbÅ« Jubayhah,Abu Jibeha", :latitude => "11.4562", :longitude => "31.2285").save
