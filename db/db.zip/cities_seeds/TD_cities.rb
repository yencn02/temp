City.new(:country_id => "215", :name => "Am Timan", :aliases => "Am Timan,Am Timane,Am Timmane,Umm Timman,Am Timan", :latitude => "11.0297", :longitude => "20.2827").save
City.new(:country_id => "215", :name => "Abeche", :aliases => "Abacher,Abeche,Abecher,Abeshe,AbÃ©cher,AbÃ©chÃ©,abesye,ÐÐ±ÐµÑÐµ,ìë² ì°,AbÃ©chÃ©", :latitude => "13.82916", :longitude => "20.8324").save
City.new(:country_id => "215", :name => "Sagh", :aliases => "Archambault,Fort-Archambault,Sagh,Sahr,Sarh,Sarkh,Shar,Ð¡Ð°ÑÑ,Sagh", :latitude => "9.1429", :longitude => "18.3923").save
City.new(:country_id => "215", :name => "Pala", :aliases => "Pala,Palla,ÐÐ°Ð»Ð°,Pala", :latitude => "9.3642", :longitude => "14.9046").save
City.new(:country_id => "215", :name => "Oum Hadjer", :aliases => ",Oum Hadjer", :latitude => "13.2954", :longitude => "19.6966").save
City.new(:country_id => "215", :name => "N'Djamena", :aliases => "Fort-Lamy,Lamy,N'Djamena,Ndjamena,Ndjemena,Ndzamena,Ndzhamena,NdÅ¼amena,NdÅ¾amena,Njameno,NÄµameno,NâDjamena,NâDjÂ·amÃ¨na,Tzamena,Yamena,anjmyna,en jia mei na,eunjamena,ng'mnh,njamena,Î¤Î¶Î±Î¼Î­Î½Î±,ÐÐ´Ð¶Ð°Ð¼ÐµÐ½Ð°,× ×'×× ×,Ø£ÙØ¬ÙÙÙØ§,áááá,ã³ã¸ã£ã¡ã,æ©è³æ¢ç´,ììë©ë,N'Djamena", :latitude => "12.11058", :longitude => "15.03479").save
City.new(:country_id => "215", :name => "Moussoro", :aliases => "Bahr el Ghazal,Moussoro,Moussoro", :latitude => "13.64084", :longitude => "16.49007").save
City.new(:country_id => "215", :name => "Moundou", :aliases => "Mondou,Mondu,Moundou,Moundu,Mundu,ÐÑÐ½Ð´Ñ,Moundou", :latitude => "8.56667", :longitude => "16.08333").save
City.new(:country_id => "215", :name => "Mongo", :aliases => "Mongo,ÐÐ¾Ð½Ð³Ð¾,Mongo", :latitude => "12.18441", :longitude => "18.69303").save
City.new(:country_id => "215", :name => "Mboursou Lere", :aliases => ",Mboursou LÃ©rÃ©", :latitude => "9.7639", :longitude => "14.1539").save
City.new(:country_id => "215", :name => "Massakory", :aliases => "Dagana,Massakori,Massakory,Massakory", :latitude => "12.996", :longitude => "15.72927").save
City.new(:country_id => "215", :name => "Massaguet", :aliases => "Massa Gueit,Massaguet,Massaguete,Massaguette,Massaquet,Massaguet", :latitude => "12.47554", :longitude => "15.43647").save
City.new(:country_id => "215", :name => "Mao", :aliases => "Mao,Mao", :latitude => "14.12116", :longitude => "15.3103").save
City.new(:country_id => "215", :name => "Lai", :aliases => "Behagie,Behagle,Lai,LaÃ¯,LaÃ¯", :latitude => "9.3952", :longitude => "16.2989").save
City.new(:country_id => "215", :name => "Kyabe", :aliases => "Kiyabe,Kiyabi,KiyabÃ©,Kyabe,KyabÃ©,KyabÃ©", :latitude => "9.45149", :longitude => "18.94493").save
City.new(:country_id => "215", :name => "Koumra", :aliases => "Koumbra,Koumra,Koumra", :latitude => "8.91256", :longitude => "17.55392").save
City.new(:country_id => "215", :name => "Kelo", :aliases => "Kel,Kelo,ÐÐµÐ»,Kelo", :latitude => "9.30859", :longitude => "15.80658").save
City.new(:country_id => "215", :name => "Dourbali", :aliases => "Dourbali,Ndourbali,Dourbali", :latitude => "11.80909", :longitude => "15.86323").save
City.new(:country_id => "215", :name => "Doba", :aliases => "Doba,ÐÐ¾Ð±Ð°,Doba", :latitude => "8.65", :longitude => "16.85").save
City.new(:country_id => "215", :name => "Bongor", :aliases => "Bongor,ÐÐ¾Ð½Ð³Ð¾Ñ,Bongor", :latitude => "10.28056", :longitude => "15.37222").save
City.new(:country_id => "215", :name => "Bitkine", :aliases => "Bitkin,Bitkine,Bitkine", :latitude => "11.9801", :longitude => "18.2138").save
City.new(:country_id => "215", :name => "Benoy", :aliases => "Benoy,Benoye,BÃ©noye,Benoy", :latitude => "8.98327", :longitude => "16.31991").save
City.new(:country_id => "215", :name => "Ati", :aliases => "Ati,ÐÑÐ¸,Ati", :latitude => "13.2154", :longitude => "18.3353").save
